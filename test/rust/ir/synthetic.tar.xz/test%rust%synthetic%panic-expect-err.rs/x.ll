; ModuleID = 'panic_expect_err.3918b55cbdcb2fde-cgu.0'
source_filename = "panic_expect_err.3918b55cbdcb2fde-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs4TVfDmrHHXe_16panic_expect_err, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4TVfDmrHHXe_16panic_expect_err, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4TVfDmrHHXe_16panic_expect_err }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_8d07294c609ce7096eac9b5042193909 = private unnamed_addr constant [3 x i8] c"bad", align 1, !guid !2
@alloc_38725dec10322df2d244d018cc7aac5e = private unnamed_addr constant [9 x i8] c"wanted ok", align 1, !guid !3
@alloc_eeecd73a21d3dbc04f4e23236db791d7 = private unnamed_addr constant [40 x i8] c"test/rust/synthetic/panic-expect-err.rs\00", align 1, !guid !4
@alloc_aa541b74c8a6435fedc0780f6ed4a921 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_eeecd73a21d3dbc04f4e23236db791d7, [16 x i8] c"'\00\00\00\00\00\00\00\06\00\00\00?\00\00\00" }>, align 8, !guid !5
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !6
@vtable.1 = private unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_, [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCs4TVfDmrHHXe_16panic_expect_err }>, align 8, !guid !7

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs4TVfDmrHHXe_16panic_expect_err(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !13 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<core::result::Result<u8, alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6result6ResulthNtNtCs7CppTae75M1_5alloc6string6StringEECs4TVfDmrHHXe_16panic_expect_err(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %dummy) unnamed_addr #1 !guid !14 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %dummy, i64 24, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !15
  ret void
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4TVfDmrHHXe_16panic_expect_err(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !16 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4TVfDmrHHXe_16panic_expect_err(ptr %f) #8
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #8
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4TVfDmrHHXe_16panic_expect_err(ptr align 8 %_1) unnamed_addr #1 !guid !17 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4TVfDmrHHXe_16panic_expect_err(ptr %_4) #9
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs4TVfDmrHHXe_16panic_expect_err() #8
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs4TVfDmrHHXe_16panic_expect_err(i8 %_2) #8
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs4TVfDmrHHXe_16panic_expect_err(ptr %_1) unnamed_addr #1 !guid !18 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4TVfDmrHHXe_16panic_expect_err(ptr %0) #8
  ret i32 %_0
}

; panic_expect_err::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs4TVfDmrHHXe_16panic_expect_err4main() unnamed_addr #0 !guid !19 {
start:
  %0 = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %_4 = alloca [24 x i8], align 8
  %r = alloca [24 x i8], align 8
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4TVfDmrHHXe_16panic_expect_err(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #8
  %_2.0 = extractvalue { ptr, ptr } %1, 0
  %_2.1 = extractvalue { ptr, ptr } %1, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call <str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8 %_5, ptr @alloc_8d07294c609ce7096eac9b5042193909, i64 3) #8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %_5, i64 24, i1 false)
; call core::hint::black_box::<core::result::Result<u8, alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6result6ResulthNtNtCs7CppTae75M1_5alloc6string6StringEECs4TVfDmrHHXe_16panic_expect_err(ptr sret([24 x i8]) align 8 %r, ptr align 8 %_4) #8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %r, i64 24, i1 false)
; call <core::result::Result<u8, alloc::string::String>>::expect
  %_7 = call i8 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtCs7CppTae75M1_5alloc6string6StringE6expectCs4TVfDmrHHXe_16panic_expect_err(ptr align 8 %0, ptr @alloc_38725dec10322df2d244d018cc7aac5e, i64 9, ptr align 8 @alloc_aa541b74c8a6435fedc0780f6ed4a921) #8
; call <core::fmt::Arguments>::from_str
  %2 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4TVfDmrHHXe_16panic_expect_err(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #8
  %_10.0 = extractvalue { ptr, ptr } %2, 0
  %_10.1 = extractvalue { ptr, ptr } %2, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_10.0, ptr %_10.1)
  ret void
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCs4TVfDmrHHXe_16panic_expect_err(ptr align 8 %self) unnamed_addr #1 !guid !20 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8 %self) #8
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs4TVfDmrHHXe_16panic_expect_err(ptr %_2.0, i64 %_2.1) #8
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs4TVfDmrHHXe_16panic_expect_err(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !21 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::result::Result<u8, alloc::string::String>>::expect
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtCs7CppTae75M1_5alloc6string6StringE6expectCs4TVfDmrHHXe_16panic_expect_err(ptr align 8 %self, ptr %msg.0, i64 %msg.1, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !22 {
start:
  %1 = alloca [16 x i8], align 8
  %e = alloca [24 x i8], align 8
  %2 = load i64, ptr %self, align 8
  %3 = icmp eq i64 %2, -1
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %e, ptr align 8 %self, i64 24, i1 false)
; invoke core::result::unwrap_failed
  invoke void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr %msg.0, i64 %msg.1, ptr %e, ptr align 8 @vtable.1, ptr align 8 %0) #10
          to label %unreachable unwind label %cleanup

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load i8, ptr %5, align 8
  ret i8 %t

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %e) #11
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb2
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %1, align 8
  %9 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb4

unreachable:                                      ; preds = %bb2
  unreachable

terminate:                                        ; preds = %bb4
  %10 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #12
  unreachable

bb5:                                              ; preds = %bb4
  %11 = load ptr, ptr %1, align 8
  %12 = getelementptr inbounds i8, ptr %1, i64 8
  %13 = load i32, ptr %12, align 8
  %14 = insertvalue { ptr, i32 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i32 } %14, i32 %13, 1
  resume { ptr, i32 } %15

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4TVfDmrHHXe_16panic_expect_err(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !23 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs4TVfDmrHHXe_16panic_expect_err(ptr %s.0, i64 %s.1) #8
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs4TVfDmrHHXe_16panic_expect_err(ptr %self) unnamed_addr #1 !guid !24 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs4TVfDmrHHXe_16panic_expect_err(i8 %0) unnamed_addr #1 !guid !25 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs4TVfDmrHHXe_16panic_expect_err(ptr %self) #8
  ret i32 %_0
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs4TVfDmrHHXe_16panic_expect_err(ptr %v.0, i64 %v.1) unnamed_addr #1 !guid !26 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs4TVfDmrHHXe_16panic_expect_err() unnamed_addr #1 !guid !27 {
start:
  ret i8 0
}

; <alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCs4TVfDmrHHXe_16panic_expect_err(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !28 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs4TVfDmrHHXe_16panic_expect_err(ptr align 8 %self) #8
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs4TVfDmrHHXe_16panic_expect_err(ptr align 8 %self) unnamed_addr #1 !guid !29 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCs4TVfDmrHHXe_16panic_expect_err(ptr align 8 %self) #8
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4TVfDmrHHXe_16panic_expect_err(ptr %_1) unnamed_addr #1 !guid !30 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4TVfDmrHHXe_16panic_expect_err(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !31 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4TVfDmrHHXe_16panic_expect_err(ptr align 8 %_1) #8
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #3

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #4

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; <str as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #1

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8) unnamed_addr #1

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #0

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #5

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #6

; <str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #7 !guid !32 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs4TVfDmrHHXe_16panic_expect_err(ptr @_RNvCs4TVfDmrHHXe_16panic_expect_err4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nonlazybind "target-cpu"="x86-64" }
attributes #8 = { inlinehint }
attributes #9 = { noinline }
attributes #10 = { noreturn }
attributes #11 = { cold }
attributes #12 = { cold noreturn nounwind }

!llvm.module.flags = !{!8, !9, !10, !11}
!llvm.ident = !{!12}

!0 = !{i64 8503450884828079661}
!1 = !{i64 3853031809908193606}
!2 = !{i64 4518353844514815367}
!3 = !{i64 5557465845079897421}
!4 = !{i64 -4561796746342695649}
!5 = !{i64 826425903137059832}
!6 = !{i64 4887223729270352437}
!7 = !{i64 -5772706719681663015}
!8 = !{i32 8, !"PIC Level", i32 2}
!9 = !{i32 7, !"PIE Level", i32 2}
!10 = !{i32 2, !"RtLibUseGOT", i32 1}
!11 = !{i32 7, !"uwtable", i32 2}
!12 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!13 = !{i64 5021978433339354453}
!14 = !{i64 9080421269977540037}
!15 = !{i64 1313070286940696}
!16 = !{i64 2426047617433882727}
!17 = !{i64 8343569180543937081}
!18 = !{i64 -1269127427523690496}
!19 = !{i64 4903305294471635306}
!20 = !{i64 -7484593506474955194}
!21 = !{i64 -982087385601955082}
!22 = !{i64 8724047787080747775}
!23 = !{i64 471432929145929071}
!24 = !{i64 9184355492869022144}
!25 = !{i64 -5839716693911808282}
!26 = !{i64 -7271427825094929368}
!27 = !{i64 7376505712053973386}
!28 = !{i64 -6177609490922057299}
!29 = !{i64 5870984346229341592}
!30 = !{i64 681077873845479831}
!31 = !{i64 -3806812210479720904}
!32 = !{i64 -2624081020897602054}
