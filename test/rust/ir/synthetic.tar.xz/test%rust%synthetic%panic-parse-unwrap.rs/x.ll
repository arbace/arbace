; ModuleID = 'panic_parse_unwrap.2f8b8cdd822de84c-cgu.0'
source_filename = "panic_parse_unwrap.2f8b8cdd822de84c-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs4553thcH6K6_18panic_parse_unwrap, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4553thcH6K6_18panic_parse_unwrap, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4553thcH6K6_18panic_parse_unwrap }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_cbd749e8f3d792e4f797f9529ee09b34 = private unnamed_addr constant [3 x i8] c"12a", align 1, !guid !2
@alloc_592d7219127687aa883ccef515e2866a = private unnamed_addr constant [42 x i8] c"test/rust/synthetic/panic-parse-unwrap.rs\00", align 1, !guid !3
@alloc_077fe6e3e59a7c439353961fb3bc11f3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_592d7219127687aa883ccef515e2866a, [16 x i8] c")\00\00\00\00\00\00\00\06\00\00\00 \00\00\00" }>, align 8, !guid !4
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !5
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !6
@alloc_00ae4b301f7fab8ac9617c03fcbd7274 = private unnamed_addr constant [43 x i8] c"called `Result::unwrap()` on an `Err` value", align 1, !guid !7
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs4553thcH6K6_18panic_parse_unwrap }>, align 8, !guid !8
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !9
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !10
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !11
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !12
@alloc_5aa1d1250638a5285856df0c8e3018a3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00K\07\00\00\01\00\00\00" }>, align 8, !guid !13
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !14
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !15
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !16

; <str>::parse::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsemECs4553thcH6K6_18panic_parse_unwrap(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !22 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <u32 as core::str::traits::FromStr>::from_str
  %1 = call i64 @_RNvXsA_NtCsl10jNU3mE6R_4core3nummNtNtNtB7_3str6traits7FromStr8from_strCs4553thcH6K6_18panic_parse_unwrap(ptr %self.0, i64 %self.1) #9
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs4553thcH6K6_18panic_parse_unwrap(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !23 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4553thcH6K6_18panic_parse_unwrap(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !24 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4553thcH6K6_18panic_parse_unwrap(ptr %f) #9
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #9
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4553thcH6K6_18panic_parse_unwrap(ptr align 8 %_1) unnamed_addr #0 !guid !25 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4553thcH6K6_18panic_parse_unwrap(ptr %_4) #10
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs4553thcH6K6_18panic_parse_unwrap() #9
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs4553thcH6K6_18panic_parse_unwrap(i8 %_2) #9
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs4553thcH6K6_18panic_parse_unwrap(ptr %_1) unnamed_addr #0 !guid !26 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4553thcH6K6_18panic_parse_unwrap(ptr %0) #9
  ret i32 %_0
}

; panic_parse_unwrap::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs4553thcH6K6_18panic_parse_unwrap4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !27 {
start:
  %e.i = alloca [1 x i8], align 1
  %0 = alloca [8 x i8], align 8
  %self.i = alloca [8 x i8], align 4
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %_11 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_4 = alloca [8 x i8], align 4
  %x = alloca [4 x i8], align 4
; call <core::fmt::Arguments>::from_str
  %3 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4553thcH6K6_18panic_parse_unwrap(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #9
  %_2.0 = extractvalue { ptr, ptr } %3, 0
  %_2.1 = extractvalue { ptr, ptr } %3, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call <str>::parse::<u32>
  %4 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsemECs4553thcH6K6_18panic_parse_unwrap(ptr @alloc_cbd749e8f3d792e4f797f9529ee09b34, i64 3) #9
  store i64 %4, ptr %2, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_4, ptr align 8 %2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 4 %_4, i64 8, i1 false)
  %5 = load i64, ptr %1, align 8
  store i64 %5, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %self.i, ptr align 8 %0, i64 8, i1 false)
  %6 = load i8, ptr %self.i, align 4
  %7 = trunc nuw i8 %6 to i1
  %_2.i = zext i1 %7 to i64
  br i1 %7, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmNtNtNtB4_3num5error13ParseIntErrorE6unwrapCs4553thcH6K6_18panic_parse_unwrap.exit

bb2.i:                                            ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self.i, i64 1
  %9 = load i8, ptr %8, align 1
  store i8 %9, ptr %e.i, align 1
; call core::result::unwrap_failed
  call void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 43, ptr %e.i, ptr align 8 @vtable.1, ptr align 8 @alloc_077fe6e3e59a7c439353961fb3bc11f3) #11
  unreachable

_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmNtNtNtB4_3num5error13ParseIntErrorE6unwrapCs4553thcH6K6_18panic_parse_unwrap.exit: ; preds = %start
  %10 = getelementptr inbounds i8, ptr %self.i, i64 4
  %t.i = load i32, ptr %10, align 4
  store i32 %t.i, ptr %x, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_11, ptr align 4 %x) #9
  %11 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %11, ptr align 8 %_11, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %12 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args) #9
  %_7.0 = extractvalue { ptr, ptr } %12, 0
  %_7.1 = extractvalue { ptr, ptr } %12, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_7.0, ptr %_7.1)
; call <core::fmt::Arguments>::from_str
  %13 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4553thcH6K6_18panic_parse_unwrap(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #9
  %_15.0 = extractvalue { ptr, ptr } %13, 0
  %_15.1 = extractvalue { ptr, ptr } %13, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_15.0, ptr %_15.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs4553thcH6K6_18panic_parse_unwrap(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !28 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4553thcH6K6_18panic_parse_unwrap(i32 %self, i32 %radix) unnamed_addr #0 !guid !29 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4553thcH6K6_18panic_parse_unwrap(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #9
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #11
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4553thcH6K6_18panic_parse_unwrap(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !30 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs4553thcH6K6_18panic_parse_unwrap(ptr %s.0, i64 %s.1) #9
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u32>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_addCs4553thcH6K6_18panic_parse_unwrap(i32 %self, i32 %rhs) unnamed_addr #0 !guid !31 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %_5.0 = add i32 %self, %rhs
  %_5.1 = icmp ult i32 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i32 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_6, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs4553thcH6K6_18panic_parse_unwrap(i32 %self, i32 %rhs) unnamed_addr #0 !guid !32 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u32>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_subCs4553thcH6K6_18panic_parse_unwrap(i32 %self, i32 %rhs) unnamed_addr #0 !guid !33 {
start:
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp ult i32 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i32 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_4, ptr %0, align 4
  store i32 1, ptr %_0, align 4
  br label %bb3

bb1:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i32, ptr %_0, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  %3 = load i32, ptr %2, align 4
  %4 = insertvalue { i32, i32 } poison, i32 %1, 0
  %5 = insertvalue { i32, i32 } %4, i32 %3, 1
  ret { i32, i32 } %5
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs4553thcH6K6_18panic_parse_unwrap(ptr %self) unnamed_addr #0 !guid !34 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <u32>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsB_NtCsl10jNU3mE6R_4core3numm14from_str_radixCs4553thcH6K6_18panic_parse_unwrap(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !35 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
  %1 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %2, 0
  %_3.1 = extractvalue { ptr, i64 } %2, 1
; call <u32>::from_ascii_bytes_radix_impl
  %3 = call i64 @_RNvMsB_NtCsl10jNU3mE6R_4core3numm27from_ascii_bytes_radix_implCs4553thcH6K6_18panic_parse_unwrap(ptr %_3.0, i64 %_3.1, i32 %radix) #9
  store i64 %3, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %4 = load i64, ptr %_0, align 4
  ret i64 %4
}

; <u32>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsB_NtCsl10jNU3mE6R_4core3numm27from_ascii_bytes_radix_implCs4553thcH6K6_18panic_parse_unwrap(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !36 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_91 = alloca [8 x i8], align 4
  %_80 = alloca [8 x i8], align 4
  %mul1 = alloca [8 x i8], align 4
  %_68 = alloca [8 x i8], align 4
  %_57 = alloca [8 x i8], align 4
  %mul = alloca [8 x i8], align 4
  %_43 = alloca [8 x i8], align 4
  %_30 = alloca [8 x i8], align 4
  %result = alloca [4 x i8], align 4
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_5aa1d1250638a5285856df0c8e3018a3) #11
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #9
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i64, ptr %_0, align 4
  ret i64 %4

bb9:                                              ; preds = %bb11, %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %5 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  store i64 %src.1, ptr %6, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %7 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %8 = load i8, ptr %7, align 1
  switch i8 %8, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %9 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %rest.1, ptr %10, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %11 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %12 = sub i64 %src.1, 1
  store ptr %11, ptr %rest, align 8
  %13 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %12, ptr %13, align 8
  br label %bb9

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %14 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %14 to i1
  %15 = getelementptr inbounds i8, ptr %_12, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = getelementptr inbounds i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  store ptr %16, ptr %digits, align 8, !captures !37
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %18, ptr %19, align 8
  store i32 0, ptr %result, align 4
  %_24.0 = load ptr, ptr %digits, align 8
  %20 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %20, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowmECs4553thcH6K6_18panic_parse_unwrap.exit

bb1.i:                                            ; preds = %bb15
  %21 = icmp ule i64 %_24.1, 8
  %22 = zext i1 %21 to i8
  store i8 %22, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowmECs4553thcH6K6_18panic_parse_unwrap.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowmECs4553thcH6K6_18panic_parse_unwrap.exit: ; preds = %bb2.i, %bb1.i
  %23 = load i8, ptr %_0.i, align 1
  %24 = trunc nuw i8 %23 to i1
  br i1 %24, label %bb17, label %bb29

bb14:                                             ; No predecessors!
  store i8 0, ptr %_12, align 8
  %25 = load ptr, ptr %rest, align 8
  %26 = getelementptr inbounds i8, ptr %rest, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %25, ptr %28, align 8
  %29 = getelementptr inbounds i8, ptr %28, i64 8
  store i64 %27, ptr %29, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowmECs4553thcH6K6_18panic_parse_unwrap.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowmECs4553thcH6K6_18panic_parse_unwrap.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %30 = load ptr, ptr %digits, align 8
  %31 = getelementptr inbounds i8, ptr %digits, i64 8
  %_74 = load i64, ptr %31, align 8
  %_75 = icmp uge i64 %_74, 1
  br i1 %_75, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %32 = load ptr, ptr %digits, align 8
  %33 = getelementptr inbounds i8, ptr %digits, i64 8
  %_51 = load i64, ptr %33, align 8
  %_52 = icmp uge i64 %_51, 1
  br i1 %_52, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_97 = load i32, ptr %result, align 4
  %34 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_97, ptr %34, align 4
  store i8 0, ptr %_0, align 4
  br label %bb53

bb42:                                             ; preds = %bb41
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %37 = load i64, ptr %36, align 8
  %c = getelementptr inbounds nuw i8, ptr %35, i64 0
  %38 = load ptr, ptr %digits, align 8
  %39 = getelementptr inbounds i8, ptr %digits, i64 8
  %40 = load i64, ptr %39, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %38, i64 1
  %rest.13 = sub i64 %40, 1
  %_79 = load i32, ptr %result, align 4
; call <u32>::checked_mul
  %41 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs4553thcH6K6_18panic_parse_unwrap(i32 %_79, i32 %radix) #9
  %42 = extractvalue { i32, i32 } %41, 0
  %43 = extractvalue { i32, i32 } %41, 1
  store i32 %42, ptr %mul1, align 4
  %44 = getelementptr inbounds i8, ptr %mul1, i64 4
  store i32 %43, ptr %44, align 4
  %_82 = load i8, ptr %c, align 1
  %_81 = zext i8 %_82 to i32
; call <char>::to_digit
  %45 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4553thcH6K6_18panic_parse_unwrap(i32 %_81, i32 %radix) #9
  %46 = extractvalue { i32, i32 } %45, 0
  %47 = extractvalue { i32, i32 } %45, 1
  store i32 %46, ptr %_80, align 4
  %48 = getelementptr inbounds i8, ptr %_80, i64 4
  store i32 %47, ptr %48, align 4
  %49 = load i32, ptr %_80, align 4
  %50 = getelementptr inbounds i8, ptr %_80, i64 4
  %51 = load i32, ptr %50, align 4
  %_83 = zext i32 %49 to i64
  %52 = trunc nuw i64 %_83 to i1
  br i1 %52, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_80, i64 4
  %x = load i32, ptr %53, align 4
  %54 = load i32, ptr %mul1, align 4
  %55 = getelementptr inbounds i8, ptr %mul1, i64 4
  %56 = load i32, ptr %55, align 4
  %_87 = zext i32 %54 to i64
  %57 = trunc nuw i64 %_87 to i1
  br i1 %57, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %58 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %58, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb48:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %mul1, i64 4
  %value = load i32, ptr %59, align 4
  store i32 %value, ptr %result, align 4
  %_92 = load i32, ptr %result, align 4
; call <u32>::checked_sub
  %60 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_subCs4553thcH6K6_18panic_parse_unwrap(i32 %_92, i32 %x) #9
  %61 = extractvalue { i32, i32 } %60, 0
  %62 = extractvalue { i32, i32 } %60, 1
  store i32 %61, ptr %_91, align 4
  %63 = getelementptr inbounds i8, ptr %_91, i64 4
  store i32 %62, ptr %63, align 4
  %64 = load i32, ptr %_91, align 4
  %65 = getelementptr inbounds i8, ptr %_91, i64 4
  %66 = load i32, ptr %65, align 4
  %_93 = zext i32 %64 to i64
  %67 = trunc nuw i64 %_93 to i1
  br i1 %67, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %68 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %68, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb51:                                             ; preds = %bb48
  %69 = getelementptr inbounds i8, ptr %_91, i64 4
  %value4 = load i32, ptr %69, align 4
  store i32 %value4, ptr %result, align 4
  store ptr %rest.02, ptr %digits, align 8, !captures !37
  %70 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %70, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %71 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %71, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb31:                                             ; preds = %bb30
  %72 = load ptr, ptr %digits, align 8
  %73 = getelementptr inbounds i8, ptr %digits, i64 8
  %74 = load i64, ptr %73, align 8
  %c5 = getelementptr inbounds nuw i8, ptr %72, i64 0
  %75 = load ptr, ptr %digits, align 8
  %76 = getelementptr inbounds i8, ptr %digits, i64 8
  %77 = load i64, ptr %76, align 8
  %rest.06 = getelementptr inbounds nuw i8, ptr %75, i64 1
  %rest.17 = sub i64 %77, 1
  %_56 = load i32, ptr %result, align 4
; call <u32>::checked_mul
  %78 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs4553thcH6K6_18panic_parse_unwrap(i32 %_56, i32 %radix) #9
  %79 = extractvalue { i32, i32 } %78, 0
  %80 = extractvalue { i32, i32 } %78, 1
  store i32 %79, ptr %mul, align 4
  %81 = getelementptr inbounds i8, ptr %mul, i64 4
  store i32 %80, ptr %81, align 4
  %_59 = load i8, ptr %c5, align 1
  %_58 = zext i8 %_59 to i32
; call <char>::to_digit
  %82 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4553thcH6K6_18panic_parse_unwrap(i32 %_58, i32 %radix) #9
  %83 = extractvalue { i32, i32 } %82, 0
  %84 = extractvalue { i32, i32 } %82, 1
  store i32 %83, ptr %_57, align 4
  %85 = getelementptr inbounds i8, ptr %_57, i64 4
  store i32 %84, ptr %85, align 4
  %86 = load i32, ptr %_57, align 4
  %87 = getelementptr inbounds i8, ptr %_57, i64 4
  %88 = load i32, ptr %87, align 4
  %_60 = zext i32 %86 to i64
  %89 = trunc nuw i64 %_60 to i1
  br i1 %89, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %90 = getelementptr inbounds i8, ptr %_57, i64 4
  %x8 = load i32, ptr %90, align 4
  %91 = load i32, ptr %mul, align 4
  %92 = getelementptr inbounds i8, ptr %mul, i64 4
  %93 = load i32, ptr %92, align 4
  %_64 = zext i32 %91 to i64
  %94 = trunc nuw i64 %_64 to i1
  br i1 %94, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %95 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %95, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb37:                                             ; preds = %bb35
  %96 = getelementptr inbounds i8, ptr %mul, i64 4
  %value9 = load i32, ptr %96, align 4
  store i32 %value9, ptr %result, align 4
  %_69 = load i32, ptr %result, align 4
; call <u32>::checked_add
  %97 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_addCs4553thcH6K6_18panic_parse_unwrap(i32 %_69, i32 %x8) #9
  %98 = extractvalue { i32, i32 } %97, 0
  %99 = extractvalue { i32, i32 } %97, 1
  store i32 %98, ptr %_68, align 4
  %100 = getelementptr inbounds i8, ptr %_68, i64 4
  store i32 %99, ptr %100, align 4
  %101 = load i32, ptr %_68, align 4
  %102 = getelementptr inbounds i8, ptr %_68, i64 4
  %103 = load i32, ptr %102, align 4
  %_70 = zext i32 %101 to i64
  %104 = trunc nuw i64 %_70 to i1
  br i1 %104, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %105 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %105, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb40:                                             ; preds = %bb37
  %106 = getelementptr inbounds i8, ptr %_68, i64 4
  %value10 = load i32, ptr %106, align 4
  store i32 %value10, ptr %result, align 4
  store ptr %rest.06, ptr %digits, align 8, !captures !37
  %107 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.17, ptr %107, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %108 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %108, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %109 = load ptr, ptr %digits, align 8
  %110 = getelementptr inbounds i8, ptr %digits, i64 8
  %_38 = load i64, ptr %110, align 8
  %_39 = icmp uge i64 %_38, 1
  br i1 %_39, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %111 = load ptr, ptr %digits, align 8
  %112 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %112, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %113 = load ptr, ptr %digits, align 8
  %114 = getelementptr inbounds i8, ptr %digits, i64 8
  %115 = load i64, ptr %114, align 8
  %c11 = getelementptr inbounds nuw i8, ptr %113, i64 0
  %116 = load ptr, ptr %digits, align 8
  %117 = getelementptr inbounds i8, ptr %digits, i64 8
  %118 = load i64, ptr %117, align 8
  %rest.012 = getelementptr inbounds nuw i8, ptr %116, i64 1
  %rest.113 = sub i64 %118, 1
  %_42 = load i32, ptr %result, align 4
  %119 = mul i32 %_42, %radix
  store i32 %119, ptr %result, align 4
  %_45 = load i8, ptr %c11, align 1
  %_44 = zext i8 %_45 to i32
; call <char>::to_digit
  %120 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4553thcH6K6_18panic_parse_unwrap(i32 %_44, i32 %radix) #9
  %121 = extractvalue { i32, i32 } %120, 0
  %122 = extractvalue { i32, i32 } %120, 1
  store i32 %121, ptr %_43, align 4
  %123 = getelementptr inbounds i8, ptr %_43, i64 4
  store i32 %122, ptr %123, align 4
  %124 = load i32, ptr %_43, align 4
  %125 = getelementptr inbounds i8, ptr %_43, i64 4
  %126 = load i32, ptr %125, align 4
  %_46 = zext i32 %124 to i64
  %127 = trunc nuw i64 %_46 to i1
  br i1 %127, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %128 = getelementptr inbounds i8, ptr %_43, i64 4
  %x14 = load i32, ptr %128, align 4
  %_50 = load i32, ptr %result, align 4
  %129 = sub i32 %_50, %x14
  store i32 %129, ptr %result, align 4
  store ptr %rest.012, ptr %digits, align 8, !captures !37
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.113, ptr %130, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %131 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %131, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb19:                                             ; preds = %bb18
  %132 = load ptr, ptr %digits, align 8
  %133 = getelementptr inbounds i8, ptr %digits, i64 8
  %134 = load i64, ptr %133, align 8
  %c15 = getelementptr inbounds nuw i8, ptr %132, i64 0
  %135 = load ptr, ptr %digits, align 8
  %136 = getelementptr inbounds i8, ptr %digits, i64 8
  %137 = load i64, ptr %136, align 8
  %rest.016 = getelementptr inbounds nuw i8, ptr %135, i64 1
  %rest.117 = sub i64 %137, 1
  %_29 = load i32, ptr %result, align 4
  %138 = mul i32 %_29, %radix
  store i32 %138, ptr %result, align 4
  %_32 = load i8, ptr %c15, align 1
  %_31 = zext i8 %_32 to i32
; call <char>::to_digit
  %139 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4553thcH6K6_18panic_parse_unwrap(i32 %_31, i32 %radix) #9
  %140 = extractvalue { i32, i32 } %139, 0
  %141 = extractvalue { i32, i32 } %139, 1
  store i32 %140, ptr %_30, align 4
  %142 = getelementptr inbounds i8, ptr %_30, i64 4
  store i32 %141, ptr %142, align 4
  %143 = load i32, ptr %_30, align 4
  %144 = getelementptr inbounds i8, ptr %_30, i64 4
  %145 = load i32, ptr %144, align 4
  %_33 = zext i32 %143 to i64
  %146 = trunc nuw i64 %_33 to i1
  br i1 %146, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %147 = getelementptr inbounds i8, ptr %_30, i64 4
  %x18 = load i32, ptr %147, align 4
  %_37 = load i32, ptr %result, align 4
  %148 = add i32 %_37, %x18
  store i32 %148, ptr %result, align 4
  store ptr %rest.016, ptr %digits, align 8, !captures !37
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.117, ptr %149, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %150 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %150, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs4553thcH6K6_18panic_parse_unwrap(i8 %0) unnamed_addr #0 !guid !38 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs4553thcH6K6_18panic_parse_unwrap(ptr %self) #9
  ret i32 %_0
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCs4553thcH6K6_18panic_parse_unwrap() unnamed_addr #3 !guid !39 {
start:
  ret void
}

; <u32 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXsA_NtCsl10jNU3mE6R_4core3nummNtNtNtB7_3str6traits7FromStr8from_strCs4553thcH6K6_18panic_parse_unwrap(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !40 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <u32>::from_str_radix
  %1 = call i64 @_RNvMsB_NtCsl10jNU3mE6R_4core3numm14from_str_radixCs4553thcH6K6_18panic_parse_unwrap(ptr %src.0, i64 %src.1, i32 10) #9
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs4553thcH6K6_18panic_parse_unwrap() unnamed_addr #0 !guid !41 {
start:
  ret i8 0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs4553thcH6K6_18panic_parse_unwrap(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !42 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.2)
  ret i1 %_0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4553thcH6K6_18panic_parse_unwrap(ptr %_1) unnamed_addr #0 !guid !43 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4553thcH6K6_18panic_parse_unwrap(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !44 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4553thcH6K6_18panic_parse_unwrap(ptr align 8 %_1) #9
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #5

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #6

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #6

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #7

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #6

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #8 !guid !45 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs4553thcH6K6_18panic_parse_unwrap(ptr @_RNvCs4553thcH6K6_18panic_parse_unwrap4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { nonlazybind "target-cpu"="x86-64" }
attributes #9 = { inlinehint }
attributes #10 = { noinline }
attributes #11 = { noinline noreturn }

!llvm.module.flags = !{!17, !18, !19, !20}
!llvm.ident = !{!21}

!0 = !{i64 -3479739031550055015}
!1 = !{i64 -7602041736001027321}
!2 = !{i64 4487305566132705925}
!3 = !{i64 -2320747221623182205}
!4 = !{i64 -4683308701913913169}
!5 = !{i64 -4633273492976086008}
!6 = !{i64 8527219995746071517}
!7 = !{i64 5019800859998865591}
!8 = !{i64 1964964119903467256}
!9 = !{i64 -7494239974832069096}
!10 = !{i64 -629162519862217199}
!11 = !{i64 -5616690051050236430}
!12 = !{i64 7511986195786142361}
!13 = !{i64 5338921600422380965}
!14 = !{i64 2922556061890642452}
!15 = !{i64 3111350528013279219}
!16 = !{i64 -2658900378985380609}
!17 = !{i32 8, !"PIC Level", i32 2}
!18 = !{i32 7, !"PIE Level", i32 2}
!19 = !{i32 2, !"RtLibUseGOT", i32 1}
!20 = !{i32 7, !"uwtable", i32 2}
!21 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!22 = !{i64 2163399780128001662}
!23 = !{i64 -5824533239432887940}
!24 = !{i64 -7224479418699016841}
!25 = !{i64 4281199485997037997}
!26 = !{i64 -1058109239557473209}
!27 = !{i64 -6243607405765835002}
!28 = !{i64 8915659706431052693}
!29 = !{i64 -4208732202242693269}
!30 = !{i64 -6204285487052251775}
!31 = !{i64 3033889257737452614}
!32 = !{i64 -7104101431474231250}
!33 = !{i64 7531567724277723138}
!34 = !{i64 4597874591031354084}
!35 = !{i64 -3705281780134427782}
!36 = !{i64 1311815370869924179}
!37 = !{!"address", !"read_provenance"}
!38 = !{i64 -3599006249675541041}
!39 = !{i64 9174692760567320335}
!40 = !{i64 -7902007695176833363}
!41 = !{i64 -1975289175132013779}
!42 = !{i64 -1595981937600693372}
!43 = !{i64 -6179027528087911097}
!44 = !{i64 -6228527455044222738}
!45 = !{i64 -2624081020897602054}
