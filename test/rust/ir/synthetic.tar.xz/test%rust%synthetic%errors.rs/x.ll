; ModuleID = 'errors.32cb63777b269958-cgu.0'
source_filename = "errors.32cb63777b269958-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::result::Result<i32, alloc::string::String>" = type { i64, [2 x i64] }
%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }
%"core::mem::maybe_uninit::MaybeUninit<&str>" = type { [2 x i64] }

@alloc_fc8af3a837bf7fd024fc38e82315f5eb = private unnamed_addr constant [20 x i8] c"core/src/str/mod.rs\00", align 1, !guid !0
@alloc_0fd8e461c4ab8dd9366dfe0b6f984c82 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_fc8af3a837bf7fd024fc38e82315f5eb, [16 x i8] c"\13\00\00\00\00\00\00\00\C0\02\00\00\16\00\00\00" }>, align 8, !guid !1
@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !2
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !3
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !4
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !5
@anon.19a2d63c9399c5c07731ce664756b6ea.0 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 8455505968622657833 to ptr), ptr inttoptr (i64 8360732718684951329 to ptr) }>, align 8, !guid !6
@anon.19a2d63c9399c5c07731ce664756b6ea.1 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 -6123208383386467593 to ptr), ptr inttoptr (i64 -5919693007716975336 to ptr) }>, align 8, !guid !7
@anon.19a2d63c9399c5c07731ce664756b6ea.2 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 187593843043800936 to ptr), ptr inttoptr (i64 -8333485340814475753 to ptr) }>, align 8, !guid !8
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs4mnquxVp34G_6errors, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4mnquxVp34G_6errors, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4mnquxVp34G_6errors }>, align 8, !guid !9
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !10
@alloc_2fc439fdc88563e15d315d43214d38e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\D6\02\00\00\09\00\00\00" }>, align 8, !guid !11
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !12
@alloc_723e2ae408a9572b186db8f845b20161 = private unnamed_addr constant [28 x i8] c"core/src/str/validations.rs\00", align 1, !guid !13
@alloc_4202fd0e53b2664da52f5b453f055200 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\000\00\00\00$\00\00\00" }>, align 8, !guid !14
@alloc_8f9bddbbaa03eec60f2c6205160c2a64 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\007\00\00\00(\00\00\00" }>, align 8, !guid !15
@alloc_87f411d4acc54b1b619e428c06de9910 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\00?\00\00\00,\00\00\00" }>, align 8, !guid !16
@alloc_4a25ca9930abb284a1027ea45af7a631 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\00]\00\00\00)\00\00\00" }>, align 8, !guid !17
@alloc_0d743c13f83ba8690fd970b942745aff = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\00b\00\00\00-\00\00\00" }>, align 8, !guid !18
@alloc_c3e3335a0c490d4e9e40b1812db21613 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\00g\00\00\001\00\00\00" }>, align 8, !guid !19
@alloc_d5d54240cab534dcfdfc9e1f15f834f2 = private unnamed_addr constant [19 x i8] c"alloc/src/slice.rs\00", align 1, !guid !20
@alloc_50f7a04d493c3c635bb162890af45f79 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d5d54240cab534dcfdfc9e1f15f834f2, [16 x i8] c"\12\00\00\00\00\00\00\00\C6\01\00\00$\00\00\00" }>, align 8, !guid !21
@alloc_741b839ab7997434e0f88c7c4ce22049 = private unnamed_addr constant [5 x i8] c"under", align 1, !guid !22
@alloc_cb14111652ceef9a06127e1067a699ad = private unnamed_addr constant [30 x i8] c"test/rust/synthetic/errors.rs\00", align 1, !guid !23
@alloc_42f0df93bf5e199f2d3d123a5f72ba24 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00\1D\00\00\00.\00\00\00" }>, align 8, !guid !24
@alloc_8c0b2c7ba8b468c3eb8b564bd67b0d69 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00\1E\00\00\00c\00\00\00" }>, align 8, !guid !25
@alloc_16d8701a704195662253a9809cf298d1 = private unnamed_addr constant [25 x i8] c"alloc/src/raw_vec/mod.rs\00", align 1, !guid !26
@alloc_c53d1dc14d9dfd00f89649d83c62a8b7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\003\02\00\00X\00\00\00" }>, align 8, !guid !27
@alloc_e90bd9a80b7f188aa76a1bfb741a5999 = private unnamed_addr constant [34 x i8] c"core/src/array/iter/iter_inner.rs\00", align 1, !guid !28
@alloc_ac893681874450253b62899ecf8cf06a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\00 \00\00\00" }>, align 8, !guid !29
@alloc_b0b7c7361940ea6a8360c2bdef76bb12 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\003\00\00\00" }>, align 8, !guid !30
@alloc_84e24ad25dfa3f90d9808e22947b437c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\85\03\00\00G\00\00\00" }>, align 8, !guid !31
@alloc_886f8a5a1647e138943f6947c0f633ae = private unnamed_addr constant [3 x i8] c" 7 ", align 1, !guid !32
@alloc_c8757baa1183d531e5d1480832ff8cd8 = private unnamed_addr constant [2 x i8] c"-3", align 1, !guid !33
@alloc_13af184f83ea529683dab3456027e412 = private unnamed_addr constant [3 x i8] c"abc", align 1, !guid !34
@alloc_f1409953d2233536262a5d1f184787d5 = private unnamed_addr constant [20 x i8] c"99999999999999999999", align 1, !guid !35
@alloc_1419a03891514d90c88076e7bb0fcaa5 = private unnamed_addr constant [2 x i8] c"+5", align 1, !guid !36
@alloc_4cca07c46305327e56b5abbe1b5e418e = private unnamed_addr constant [2 x i8] c"42", align 1, !guid !37
@alloc_26f643e647dbf77f42e670b3488e8932 = private unnamed_addr constant [1 x i8] c"1", align 1, !guid !38
@alloc_2915479852334936e8130753f7743db9 = private unnamed_addr constant [1 x i8] c"2", align 1, !guid !39
@alloc_7d41ec57c1295544fb8684618c5cb662 = private unnamed_addr constant [1 x i8] c"3", align 1, !guid !40
@alloc_f2e1a0544e0e3261362adc50b75d6b0a = private unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @alloc_26f643e647dbf77f42e670b3488e8932, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @alloc_2915479852334936e8130753f7743db9, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @alloc_7d41ec57c1295544fb8684618c5cb662, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !41
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !42
@alloc_37f62a15fae368a2423b3a16c75adcc9 = private unnamed_addr constant [1 x i8] c"x", align 1, !guid !43
@alloc_24a105619a71ab434fb7a61711b3754a = private unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @alloc_26f643e647dbf77f42e670b3488e8932, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !44
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !45
@alloc_24b05860d599286ecb26af7d40c66ae9 = private unnamed_addr constant [2 x i8] c"-1", align 1, !guid !46
@alloc_e7dcb7344fc37504b9418c11c4a9d98f = private unnamed_addr constant [1 x i8] c"q", align 1, !guid !47
@alloc_e8bed5fc7baf93aaf2aece520080d503 = private unnamed_addr constant [3 x i8] c"200", align 1, !guid !48
@alloc_fee8f9451f4957e1f9c91846d5d186b4 = private unnamed_addr constant [8 x i8] c"\01\00\00\00\02\00\00\00", align 4, !guid !49
@alloc_66e0d902dc5512250b9d4edb026cbbeb = private unnamed_addr constant [4 x i8] c"\01\00\00\00", align 4, !guid !50
@alloc_7dad102c4c3f0cd63ff654fb619efe59 = private unnamed_addr constant [8 x i8] c"\FF\FF\FF\7F\01\00\00\00", align 4, !guid !51
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !52
@alloc_7128d5fa802b3d26a0e0642ece79c82a = private unnamed_addr constant [3 x i8] c"256", align 1, !guid !53
@alloc_100177961406f1edbf7781ce01130f24 = private unnamed_addr constant [4 x i8] c"-129", align 1, !guid !54
@alloc_0d1918786fa78d9d4e3016c27bbb890c = private unnamed_addr constant [3 x i8] c"1.5", align 1, !guid !55
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !56
@alloc_361af4a0a0c07a42d46a4e093e4a894b = private unnamed_addr constant [3 x i8] c"tru", align 1, !guid !57
@alloc_c9ee9951a160df092319190fa06505e4 = private unnamed_addr constant [4 x i8] c"true", align 1, !guid !58
@alloc_8d07294c609ce7096eac9b5042193909 = private unnamed_addr constant [3 x i8] c"bad", align 1, !guid !59
@alloc_279256bde0e1d7f7c597641fe0c13aca = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00\19\00\00\00C\00\00\00" }>, align 8, !guid !60
@alloc_c09dc8b7a4b0a680bfb1277db7e949ff = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00\19\00\00\00-\00\00\00" }>, align 8, !guid !61
@alloc_890cb1a408d0b866810322ffa0505985 = private unnamed_addr constant [4 x i8] c"none", align 1, !guid !62
@alloc_c1fa64f4e819a506b7859bc956f830ca = private unnamed_addr constant [1 x i8] c"e", align 1, !guid !63
@alloc_8edde9c1d7592734926bf33e2fe88b51 = private unnamed_addr constant [13 x i8] c"boxed message", align 1, !guid !64
@alloc_dde4797b035e3bd55cef1b113ab283ad = private unnamed_addr constant [4 x i8] c"disk", align 1, !guid !65
@alloc_a120c34eab250664aea21142790ac5ef = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00!\00\00\00(\00\00\00" }>, align 8, !guid !66
@alloc_e117bbd6b19cd82f4413501c8428fb4d = private unnamed_addr constant [10 x i8] c"\05dyn: \C0\01\0A\00", align 1, !guid !67
@alloc_c96b2bdbd1e873b6183a4bda3ab8772c = private unnamed_addr constant [8 x i8] c"\03ok \C0\01\0A\00", align 1, !guid !68
@alloc_e7c21a0b99def4574ccf36ce68976b0f = private unnamed_addr constant [26 x i8] c"\04err \C0\03 / \C0\0A / source \C0\01\0A\00", align 1, !guid !69
@alloc_f0b49fd2af8b2531fe0b760bac9bc2db = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00\0B\00\00\00;\00\00\00" }>, align 8, !guid !70
@alloc_4555ac019c070316ee6a647ac605ae4d = private unnamed_addr constant [7 x i8] c"too big", align 1, !guid !71
@alloc_d0ed77324085cf7311ee02111298f70f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00\0D\00\00\00i\00\00\00" }>, align 8, !guid !72
@alloc_840b688a40aecb72c97f62b0ca67e535 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00\0D\00\00\00<\00\00\00" }>, align 8, !guid !73
@alloc_a51d431727bd96f9d4c9853d837a4a0b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00\0C\00\00\00Q\00\00\00" }>, align 8, !guid !74
@alloc_5eede92c0b13a73666007c7077cc0a4b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb14111652ceef9a06127e1067a699ad, [16 x i8] c"\1D\00\00\00\00\00\00\00\0C\00\00\00V\00\00\00" }>, align 8, !guid !75
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !76
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !77
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsK_NtCsl10jNU3mE6R_4core3fmtNtB5_5ErrorNtB5_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !78
@alloc_04af5354bae90239a24027527d4c463d = private unnamed_addr constant [30 x i8] c"core/src/mem/manually_drop.rs\00", align 1, !guid !79
@alloc_d9607be26b1182115ab3c853f5787a76 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04af5354bae90239a24027527d4c463d, [16 x i8] c"\1D\00\00\00\00\00\00\00\E4\00\00\00\12\00\00\00" }>, align 8, !guid !80
@alloc_988c380202cc7b7a37ca3d8d5930c44f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\AD\00\00\00\1B\00\00\00" }>, align 8, !guid !81
@alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b = private unnamed_addr constant [28 x i8] c"core/src/ops/index_range.rs\00", align 1, !guid !82
@alloc_de9a5d9a80d554992107c1ea3afec081 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b, [16 x i8] c"\1B\00\00\00\00\00\00\00?\00\00\00%\00\00\00" }>, align 8, !guid !83
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !84
@alloc_fad0cd83b7d1858a846a172eb260e593 = private unnamed_addr constant [42 x i8] c"is_aligned_to: align is not a power-of-two", align 1, !guid !85
@alloc_3a97cab01964e354cab63e4d72a95bbc = private unnamed_addr constant [26 x i8] c"core/src/ptr/const_ptr.rs\00", align 1, !guid !86
@alloc_7abc4ceda2d1d9be88f00c5dc522bc84 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3a97cab01964e354cab63e4d72a95bbc, [16 x i8] c"\19\00\00\00\00\00\00\00M\05\00\00\0D\00\00\00" }>, align 8, !guid !87
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !88
@alloc_9e5c5064a9cc4d3581a4b435ddfc6bf3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\F3\00\00\00\12\00\00\00" }>, align 8, !guid !89
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !90
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !91
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !92
@alloc_6379aaa2812385052216e7dc8e3279fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00m\01\00\00\1F\00\00\00" }>, align 8, !guid !93
@alloc_9e1ff22d96cae328e0e878f28b86a5f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00]\01\00\00\11\00\00\00" }>, align 8, !guid !94
@alloc_dc3b17f8cb85ad2cd97bd426be5b5da4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00b\01\00\00\1D\00\00\00" }>, align 8, !guid !95
@alloc_4a0c97dbbf49263ee47df53bd3d86fcc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00b\01\00\00+\00\00\00" }>, align 8, !guid !96
@alloc_a699fef46c42b266f9e12652c07a696a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00`\01\00\00\1B\00\00\00" }>, align 8, !guid !97
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !98
@alloc_3d5b7f261101b120d30419294a27cc6f = private unnamed_addr constant [23 x i8] c"core/src/ptr/unique.rs\00", align 1, !guid !99
@alloc_8e8e5d43991787ef9fba0c8fe53b59fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3d5b7f261101b120d30419294a27cc6f, [16 x i8] c"\16\00\00\00\00\00\00\00X\00\00\00$\00\00\00" }>, align 8, !guid !100
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !101
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !102
@alloc_fb8434897fc981b244a3f03509e5b63a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\A7\03\00\00\12\00\00\00" }>, align 8, !guid !103
@alloc_e469ef44bf39c45bcb672a4bc963b9cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\1A\01\00\00\1B\00\00\00" }>, align 8, !guid !104
@alloc_91bad026f8df33e69ba6aca06b3a4c87 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\AD\02\00\003\00\00\00" }>, align 8, !guid !105
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !106
@alloc_5bb642ca6df5ad9ba078972a9d3a5201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !107
@alloc_85bcb8feb56634093aba2b8644936af9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\7F\02\00\005\00\00\00" }>, align 8, !guid !108
@alloc_17de00c3327446355700bd7db4b78ded = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\80\02\00\00\1E\00\00\00" }>, align 8, !guid !109
@alloc_b9419d44288097f84422e162822ba96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\81\02\00\00 \00\00\00" }>, align 8, !guid !110
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !111
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !112
@alloc_af3623564924928dd3d563c9d84a8a0e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00s\05\00\00\12\00\00\00" }>, align 8, !guid !113
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !114
@alloc_02ed5979549ad728dcb1e213f787b0ae = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00,\02\00\00\11\00\00\00" }>, align 8, !guid !115
@alloc_9c2bc03755f157121052fe1398e358d1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00%\02\00\00\1A\00\00\00" }>, align 8, !guid !116
@alloc_8b924c2e6c70ef47ed23cadbb79c2da4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\11\02\00\00\1C\00\00\00" }>, align 8, !guid !117
@alloc_91dabd4c1d2514ecf79277c06422ef65 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\07\02\00\00\1C\00\00\00" }>, align 8, !guid !118
@alloc_289c68237f406b28ee6ba245eefcd312 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\03\02\00\00)\00\00\00" }>, align 8, !guid !119
@alloc_33dfd402c6ecbe2e6a32e76edf5f31a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\D8\01\00\00L\00\00\00" }>, align 8, !guid !120
@alloc_099d793709fa470a3d5e7c79c938e035 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\C9\01\00\003\00\00\00" }>, align 8, !guid !121
@alloc_51424262946dd0794fad6132df857999 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\B7\01\00\00\15\00\00\00" }>, align 8, !guid !122
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !123
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !124
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !125
@alloc_9420a1aba537dc94842201b7589e1f0c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0C\04\00\00)\00\00\00" }>, align 8, !guid !126
@alloc_ce6d47b03c47f09012a85da1d9cb0822 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0D\04\00\00\0D\00\00\00" }>, align 8, !guid !127
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !128
@alloc_5ea8f0c52284eef1a8a88866fb554c40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\0B\00\00O\00\00\00" }>, align 8, !guid !129
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !130
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !131
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !132
@alloc_5aa1d1250638a5285856df0c8e3018a3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00K\07\00\00\01\00\00\00" }>, align 8, !guid !133
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !134
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !135
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !136
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !137
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !138
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !139
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !140
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !141
@_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space14WHITESPACE_MAP = external global [256 x i8]
@alloc_ba130814536b16b6d7cee6d8f200ab35 = private unnamed_addr constant [33 x i8] c"core/src/unicode/unicode_data.rs\00", align 1, !guid !142
@alloc_ee09ed5182ef49c6cba0ade2ac4a17f6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba130814536b16b6d7cee6d8f200ab35, [16 x i8] c" \00\00\00\00\00\00\00\9A\03\00\00\12\00\00\00" }>, align 8, !guid !143
@alloc_8acebf40d2a4360b5049d1b9f3d146ab = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba130814536b16b6d7cee6d8f200ab35, [16 x i8] c" \00\00\00\00\00\00\00\9C\03\00\00\13\00\00\00" }>, align 8, !guid !144
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !145
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !146
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !147
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !148
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !149
@alloc_dbcce5cb8873847766db4f16f930a00e = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: isize::unchecked_neg cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !150
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !151
@alloc_db07ae5a9ce650d9b7cc970d048e6f0c = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !152
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !153
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !154
@alloc_dd79dfae92e8fdc23813c4c7a1b7cf72 = private unnamed_addr constant [228 x i8] c"unsafe precondition(s) violated: ptr::write_bytes requires that the destination pointer is aligned and non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !155
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !156
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !157
@alloc_75fb06c2453febd814e73f5f2e72ae38 = private unnamed_addr constant [199 x i8] c"unsafe precondition(s) violated: hint::unreachable_unchecked must never be reached\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !158
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !159
@alloc_4dc07e69e5d34e9d1484dfbbef0bb9b1 = private unnamed_addr constant [174 x i8] c"unsafe precondition(s) violated: invalid value for `char`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !160
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !161
@alloc_97d92cbf2a68a6ac45a1b13da79836e4 = private unnamed_addr constant [214 x i8] c"unsafe precondition(s) violated: slice::get_unchecked requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !162
@alloc_5a8fdd84b3281310cbf6b74bb6bf0065 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !163
@alloc_91f2a00ff2cd9cdc4bb205a66832e2bb = private unnamed_addr constant [219 x i8] c"unsafe precondition(s) violated: str::get_unchecked requires that the range is within the string slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !164
@alloc_9b2d63cc508ee049089fe30d211c4567 = private unnamed_addr constant [10 x i8] c"\07parse: \C0\00", align 1, !guid !165
@alloc_8c3d0984f7d266d81329ae47eeea02a7 = private unnamed_addr constant [13 x i8] c"\0Anegative: \C0\00", align 1, !guid !166
@alloc_97f79794e46322a863ea2e7304ef904e = private unnamed_addr constant [7 x i8] c"\04io: \C0\00", align 1, !guid !167
@alloc_c7037efb906203803aa3ca07167c9120 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\13\00\00\00\17\00\00\00" }>, align 8, !guid !168
@alloc_4cf7911ffc1fa65c3bf9af4755f6af39 = private unnamed_addr constant [5 x i8] c"Parse", align 1, !guid !169
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !170
@alloc_b1af39f5823d1b99162e6b24ff932dbf = private unnamed_addr constant [3 x i8] c"Neg", align 1, !guid !171
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRxNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !172
@alloc_24a9d1d9c182d85dcff0523bfa2532d4 = private unnamed_addr constant [2 x i8] c"Io", align 1, !guid !173
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !174
@alloc_252aee8158a2b6b4b1e300c3f8f7bd7a = private unnamed_addr constant [15 x i8] c"ParseFloatError", align 1, !guid !175
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !176
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse14FloatErrorKindNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !177
@alloc_59ba7b9f7211443cd55a366616eef46a = private unnamed_addr constant [5 x i8] c"Empty", align 1, !guid !178
@alloc_6693e43df3406efcf64b4ab3d59228bb = private unnamed_addr constant [7 x i8] c"Invalid", align 1, !guid !179
@vtable.6 = private unnamed_addr constant <{ ptr, [16 x i8], ptr, ptr, ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors, [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_strCs4mnquxVp34G_6errors, ptr @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write10write_charCs4mnquxVp34G_6errors, ptr @_RNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtCs4mnquxVp34G_6errors }>, align 8, !guid !180
@alloc_cc656815297f75969399c3f4b1ad3de4 = private unnamed_addr constant [55 x i8] c"a Display implementation returned an error unexpectedly", align 1, !guid !181
@alloc_7213f65d6896e5c55b82fdf6cd68b1f1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\89\0B\00\00\0E\00\00\00" }>, align 8, !guid !182
@alloc_99ac8a81a24cac863217ce4a5cbfabea = private unnamed_addr constant [5 x i8] c"Error", align 1, !guid !183
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !184
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !185
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !186
@alloc_a455831dd9e3be2d781dae1b5e3ba201 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXs4_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt7Display3fmt }>, align 8, !guid !187
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors, ptr @_RNvXs4_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt7Display3fmt, ptr @alloc_a455831dd9e3be2d781dae1b5e3ba201, ptr @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error6sourceCs4mnquxVp34G_6errors, ptr @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error7type_idCs4mnquxVp34G_6errors, ptr @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error11descriptionCs4mnquxVp34G_6errors, ptr @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error5causeCs4mnquxVp34G_6errors, ptr @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error7provideCs4mnquxVp34G_6errors }>, align 8, !guid !188
@alloc_18387e0fb79f5c7b2d13985332f32f7b = private unnamed_addr constant [14 x i8] c"ParseBoolError", align 1, !guid !189
@alloc_d469ed74493c57966e101c6866714500 = private unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_, [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXCs4mnquxVp34G_6errorsNtB2_8AppErrorNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt }>, align 8, !guid !190
@vtable.9 = private unnamed_addr constant <{ ptr, [16 x i8], ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_, [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1_Cs4mnquxVp34G_6errorsNtB5_8AppErrorNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_, ptr @_RNvXCs4mnquxVp34G_6errorsNtB2_8AppErrorNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt, ptr @alloc_d469ed74493c57966e101c6866714500, ptr @_RNvXs_Cs4mnquxVp34G_6errorsNtB4_8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error6source, ptr @_RNvYNtCs4mnquxVp34G_6errors8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error7type_idB4_, ptr @_RNvYNtCs4mnquxVp34G_6errors8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error11descriptionB4_, ptr @_RNvYNtCs4mnquxVp34G_6errors8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error5causeB4_, ptr @_RNvYNtCs4mnquxVp34G_6errors8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error7provideB4_ }>, align 8, !guid !191
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !192
@vtable.a = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !193
@alloc_454b75be4cdec8bdce16dee7bf5ef0f3 = private unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBL_3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1R_4SendEL_EINtNtB4_7convert4FromNtNtBN_6string6StringE4from11StringErrorECs4mnquxVp34G_6errors, [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs_NvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4fromNtB4_11StringErrorNtNtB11_3fmt7Display3fmt }>, align 8, !guid !194
@vtable.b = private unnamed_addr constant <{ ptr, [16 x i8], ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBL_3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1R_4SendEL_EINtNtB4_7convert4FromNtNtBN_6string6StringE4from11StringErrorECs4mnquxVp34G_6errors, [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs0_NvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBd_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB12_6marker4SyncNtB1z_4SendEL_EINtNtB12_7convert4FromNtNtBf_6string6StringE4fromNtB5_11StringErrorNtNtB12_3fmt5Debug3fmt, ptr @_RNvXs_NvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4fromNtB4_11StringErrorNtNtB11_3fmt7Display3fmt, ptr @alloc_454b75be4cdec8bdce16dee7bf5ef0f3, ptr @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_6sourceCs4mnquxVp34G_6errors, ptr @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_7type_idCs4mnquxVp34G_6errors, ptr @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_11descriptionCs4mnquxVp34G_6errors, ptr @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_5causeCs4mnquxVp34G_6errors, ptr @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_7provideCs4mnquxVp34G_6errors }>, align 8, !guid !195
@alloc_b81e52ca1a07489f49a3e5fe131c4b29 = private unnamed_addr constant [5 x i8] c"false", align 1, !guid !196
@alloc_163806a4180ad6004a5349afe01bf989 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\B9\0F\00\00+\00\00\00" }>, align 8, !guid !197
@alloc_6aa2510d4afa512dbf7e5d3b8ea439bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\BF\0F\00\00\17\00\00\00" }>, align 8, !guid !198
@alloc_00315c78e51d29fe6b3102a4c1ecf6ef = private unnamed_addr constant [12 x i8] c"InvalidDigit", align 1, !guid !199
@alloc_bd3a3f3879e0d5f64554753e977f58d4 = private unnamed_addr constant [11 x i8] c"PosOverflow", align 1, !guid !200
@alloc_0964bb2a4870637395c77a018495bd5c = private unnamed_addr constant [11 x i8] c"NegOverflow", align 1, !guid !201
@alloc_6566120a3a17f930e960a0863fcbd591 = private unnamed_addr constant [4 x i8] c"Zero", align 1, !guid !202
@alloc_6c17bac0c71cba42380f8445f4dcbd16 = private unnamed_addr constant [14 x i8] c"NotAPowerOfTwo", align 1, !guid !203
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !204
@vtable.c = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !205
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !206
@vtable.d = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !207
@vtable.e = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3str5error14ParseBoolErrorNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !208
@vtable.f = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !209
@vtable.g = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse15ParseFloatErrorNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !210
@vtable.h = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !211
@vtable.i = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCs4mnquxVp34G_6errors }>, align 8, !guid !212
@alloc_e0b4b313e4cca696473c8aa4c297f399 = private unnamed_addr constant [35 x i8] c"core/src/iter/traits/exact_size.rs\00", align 1, !guid !213
@alloc_53378387c97726d6569d6d4847e84e24 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e0b4b313e4cca696473c8aa4c297f399, [16 x i8] c"\22\00\00\00\00\00\00\00z\00\00\00\09\00\00\00" }>, align 8, !guid !214
@alloc_04d7ce44d7c86a9a02b346ab945bf155 = private unnamed_addr constant [40 x i8] c"description() is deprecated; use Display", align 1, !guid !215

; <[core::result::Result<i32, alloc::string::String>]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB5_6string6StringE8into_vecNtNtB5_5alloc6GlobalECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !221 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE23into_raw_with_allocatorCs4mnquxVp34G_6errors(ptr align 8 %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE17from_raw_parts_inCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %self) #23
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable
}

; <[u8]>::to_vec_in::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !222 {
start:
; call <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
  call void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #25
  ret void
}

; <str>::trim_matches::<<char>::is_whitespace>
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre12trim_matchesNvMNtNtB5_4char7methodsc13is_whitespaceECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !223 {
start:
  %_11 = alloca [24 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %matcher = alloca [40 x i8], align 8
  %j = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  store i64 0, ptr %i, align 8
  store i64 0, ptr %j, align 8
; call <<char>::is_whitespace as core::str::pattern::Pattern>::into_searcher
  call void @_RNvXsr_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_7Pattern13into_searcherCs4mnquxVp34G_6errors(ptr sret([40 x i8]) align 8 %matcher, ptr %self.0, i64 %self.1) #25
; call <core::str::pattern::CharPredicateSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next_reject
  call void @_RNvXso_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_21CharPredicateSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher11next_rejectCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_6, ptr align 8 %matcher) #25
  br label %bb2

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %_6, align 8
  %0 = trunc nuw i64 %_8 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %bb2
  %1 = getelementptr inbounds i8, ptr %_6, i64 8
  %a = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6, i64 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  %b = load i64, ptr %3, align 8
  store i64 %a, ptr %i, align 8
  store i64 %b, ptr %j, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
; call <core::str::pattern::CharPredicateSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_reject_back
  call void @_RNvXsp_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_21CharPredicateSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher16next_reject_backCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_11, ptr align 8 %matcher) #25
  br label %bb5

bb5:                                              ; preds = %bb4
  %_13 = load i64, ptr %_11, align 8
  %4 = trunc nuw i64 %_13 to i1
  br i1 %4, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %5 = getelementptr inbounds i8, ptr %_11, i64 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %b1 = load i64, ptr %6, align 8
  store i64 %b1, ptr %j, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5
  %_16 = load i64, ptr %i, align 8
  %_17 = load i64, ptr %j, align 8
; call <str>::get_unchecked::<core::ops::range::Range<usize>>
  %7 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre13get_uncheckedINtNtNtB5_3ops5range5RangejEECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1, i64 %_16, i64 %_17) #25
  %_0.0 = extractvalue { ptr, i64 } %7, 0
  %_0.1 = extractvalue { ptr, i64 } %7, 1
  br label %bb8

bb8:                                              ; preds = %bb7
  %8 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %_0.1, 1
  ret { ptr, i64 } %9

bb12:                                             ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <str>::get_unchecked::<core::ops::range::Range<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre13get_uncheckedINtNtNtB5_3ops5range5RangejEECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1, i64 %i.0, i64 %i.1) unnamed_addr #0 !guid !224 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
  %0 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCs4mnquxVp34G_6errors(i64 %i.0, i64 %i.1, ptr %self.0, i64 %self.1, ptr align 8 @alloc_0fd8e461c4ab8dd9366dfe0b6f984c82) #25
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_3.1, 1
  ret { ptr, i64 } %2
}

; <str>::parse::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parseaECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !225 {
start:
; call <i8 as core::str::traits::FromStr>::from_str
  %0 = call { i1, i8 } @_RNvXsk_NtCsl10jNU3mE6R_4core3numaNtNtNtB7_3str6traits7FromStr8from_strCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) #25
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <str>::parse::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsebECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !226 {
start:
; call <bool as core::str::traits::FromStr>::from_str
  %_0 = call i8 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3str6traitsbNtB5_7FromStr8from_strCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) #25
  ret i8 %_0
}

; <str>::parse::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !227 {
start:
; call <f64 as core::str::traits::FromStr>::from_str
  call void @_RNvXs2_NtNtCsl10jNU3mE6R_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #26
  ret void
}

; <str>::parse::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parsehECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !228 {
start:
; call <u8 as core::str::traits::FromStr>::from_str
  %0 = call { i1, i8 } @_RNvXsw_NtCsl10jNU3mE6R_4core3numhNtNtNtB7_3str6traits7FromStr8from_strCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) #25
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <str>::parse::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsexECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !229 {
start:
; call <i64 as core::str::traits::FromStr>::from_str
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core3numxNtNtNtB7_3str6traits7FromStr8from_strCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #25
  ret void
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitReE13get_uncheckedjECs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !230 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitReEE13get_uncheckedCs4mnquxVp34G_6errors(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #25
  ret ptr %_3
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitReE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !231 {
start:
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitReEE17get_unchecked_mutCs4mnquxVp34G_6errors(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #25
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <[i32]>::get::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl3getjECs4mnquxVp34G_6errors(ptr align 4 %self.0, i64 %self.1, i64 %index) unnamed_addr #0 !guid !232 {
start:
; call <usize as core::slice::index::SliceIndex<[i32]>>::get
  %_0 = call align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSlE3getCs4mnquxVp34G_6errors(i64 %index, ptr align 4 %self.0, i64 %self.1) #25
  ret ptr %_0
}

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs4mnquxVp34G_6errors(ptr %0) unnamed_addr #0 !guid !233 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_6, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %7 = load ptr, ptr %_0, align 8
  ret ptr %7

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<char>>::map::<(usize, char), <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptioncE3mapTjcENCNvXs4_NtNtB5_3str4iterNtB10_11CharIndicesNtNtNtNtB5_4iter6traits12double_ended19DoubleEndedIterator9next_back0ECs4mnquxVp34G_6errors(i32 %0, ptr align 8 %f.0, ptr align 8 %f.1) unnamed_addr #0 !guid !234 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [4 x i8], align 4
  store i32 %0, ptr %self, align 4
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load i32, ptr %self, align 4
  %2 = icmp eq i32 %1, -1
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load i32, ptr %self, align 4
  store i8 0, ptr %_8, align 1
; call <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}
  %4 = call { i64, i32 } @_RNCNvXs4_NtNtCsl10jNU3mE6R_4core3str4iterNtB7_11CharIndicesNtNtNtNtBb_4iter6traits12double_ended19DoubleEndedIterator9next_back0Cs4mnquxVp34G_6errors(ptr align 8 %f.0, ptr align 8 %f.1, i32 %x) #25
  %_5.0 = extractvalue { i64, i32 } %4, 0
  %_5.1 = extractvalue { i64, i32 } %4, 1
  store i64 %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_5.1, ptr %5, align 8
  br label %bb7

bb2:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 -1, ptr %6, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %7 = load i8, ptr %_8, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %9 = load i64, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { i64, i32 } poison, i64 %9, 0
  %13 = insertvalue { i64, i32 } %12, i32 %11, 1
  ret { i64, i32 } %13

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<usize>>::map::<&str, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapReNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBY_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECs4mnquxVp34G_6errors(i64 %0, i64 %1, ptr align 8 %f.0, i64 %f.1) unnamed_addr #0 !guid !235 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next::{closure#0}
  %7 = call { ptr, i64 } @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitReEE4next0Cs4mnquxVp34G_6errors(ptr align 8 %f.0, i64 %f.1, i64 %x) #25
  %_5.0 = extractvalue { ptr, i64 } %7, 0
  %_5.1 = extractvalue { ptr, i64 } %7, 1
  store ptr %_5.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %8, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %9 = load i8, ptr %_8, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<usize>>::ok_or::<alloc::collections::TryReserveErrorKind>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE5ok_orNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, i64 %0, i64 %1, i64 %err.0, i64 %err.1) unnamed_addr #0 !guid !236 {
start:
  %_6 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %7, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store i64 %err.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %err.1, ptr %8, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %9 = load i8, ptr %_6, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<i32>>::ok_or::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionlE5ok_orReECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, i32 %0, i32 %1, ptr %err.0, i64 %err.1) unnamed_addr #0 !guid !237 {
start:
  %_6 = alloca [1 x i8], align 1
  %self = alloca [8 x i8], align 4
  store i32 %0, ptr %self, align 4
  %2 = getelementptr inbounds i8, ptr %self, i64 4
  store i32 %1, ptr %2, align 4
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %3 = load i32, ptr %self, align 4
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  %5 = load i32, ptr %4, align 4
  %_3 = zext i32 %3 to i64
  %6 = trunc nuw i64 %_3 to i1
  br i1 %6, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 4
  %v = load i32, ptr %7, align 4
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %v, ptr %8, align 8
  store ptr null, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store ptr %err.0, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %err.1, ptr %9, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %10 = load i8, ptr %_6, align 1
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<i32>>::filter::<errors::main::{closure#4}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionlE6filterNCNvCs4mnquxVp34G_6errors4mains2_0EBV_(i32 %0, i32 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !238 {
start:
  %_10 = alloca [1 x i8], align 1
  %x = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %self = alloca [8 x i8], align 4
  store i32 %0, ptr %self, align 4
  %2 = getelementptr inbounds i8, ptr %self, i64 4
  store i32 %1, ptr %2, align 4
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
  %3 = load i32, ptr %self, align 4
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  %5 = load i32, ptr %4, align 4
  %_3 = zext i32 %3 to i64
  %6 = trunc nuw i64 %_3 to i1
  br i1 %6, label %bb1, label %bb5

bb1:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 4
  %8 = load i32, ptr %7, align 4
  store i32 %8, ptr %x, align 4
  store i8 0, ptr %_10, align 1
; call errors::main::{closure#4}
  %_5 = call zeroext i1 @_RNCNvCs4mnquxVp34G_6errors4mains2_0B3_(ptr align 4 %x) #25
  br label %bb2

bb5:                                              ; preds = %bb4, %start
  store i32 0, ptr %_0, align 4
  %9 = load i8, ptr %_10, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb9, label %bb6

bb2:                                              ; preds = %bb1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %bb2
  br label %bb5

bb3:                                              ; preds = %bb2
  %_9 = load i32, ptr %x, align 4
  %11 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_9, ptr %11, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb9, %bb5, %bb3
  %12 = load i32, ptr %_0, align 4
  %13 = getelementptr inbounds i8, ptr %_0, i64 4
  %14 = load i32, ptr %13, align 4
  %15 = insertvalue { i32, i32 } poison, i32 %12, 0
  %16 = insertvalue { i32, i32 } %15, i32 %14, 1
  ret { i32, i32 } %16

bb9:                                              ; preds = %bb5
  br label %bb6

bb10:                                             ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXNtNtB5_3str4iterNtBU_5CharsNtNtNtNtB5_4iter6traits8iterator8Iterator4next0ECs4mnquxVp34G_6errors(i32 %0, i32 %1) unnamed_addr #0 !guid !239 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %self = alloca [8 x i8], align 4
  store i32 %0, ptr %self, align 4
  %2 = getelementptr inbounds i8, ptr %self, i64 4
  store i32 %1, ptr %2, align 4
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %3 = load i32, ptr %self, align 4
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  %5 = load i32, ptr %4, align 4
  %_3 = zext i32 %3 to i64
  %6 = trunc nuw i64 %_3 to i1
  br i1 %6, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 4
  %x = load i32, ptr %7, align 4
  store i8 0, ptr %_8, align 1
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}
  %_5 = call i32 @_RNCNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB4_5CharsNtNtNtNtB8_4iter6traits8iterator8Iterator4next0Cs4mnquxVp34G_6errors(i32 %x) #25
  store i32 %_5, ptr %_0, align 4
  br label %bb7

bb2:                                              ; preds = %start
  store i32 -1, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_8, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %10 = load i32, ptr %_0, align 4
  ret i32 %10

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXs0_NtNtB5_3str4iterNtBX_5CharsNtNtNtNtB5_4iter6traits12double_ended19DoubleEndedIterator9next_back0ECs4mnquxVp34G_6errors(i32 %0, i32 %1) unnamed_addr #0 !guid !240 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %self = alloca [8 x i8], align 4
  store i32 %0, ptr %self, align 4
  %2 = getelementptr inbounds i8, ptr %self, i64 4
  store i32 %1, ptr %2, align 4
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %3 = load i32, ptr %self, align 4
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  %5 = load i32, ptr %4, align 4
  %_3 = zext i32 %3 to i64
  %6 = trunc nuw i64 %_3 to i1
  br i1 %6, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 4
  %x = load i32, ptr %7, align 4
  store i8 0, ptr %_8, align 1
; call <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}
  %_5 = call i32 @_RNCNvXs0_NtNtCsl10jNU3mE6R_4core3str4iterNtB7_5CharsNtNtNtNtBb_4iter6traits12double_ended19DoubleEndedIterator9next_back0Cs4mnquxVp34G_6errors(i32 %x) #25
  store i32 %_5, ptr %_0, align 4
  br label %bb7

bb2:                                              ; preds = %start
  store i32 -1, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_8, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %10 = load i32, ptr %_0, align 4
  ret i32 %10

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError>>::map_err::<alloc::collections::TryReserveError, <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtNtB5_3ptr8non_null7NonNullShENtNtB5_5alloc10AllocErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvMs5_NtB1S_7raw_vecNtB2O_11RawVecInner11finish_grow0ECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1, ptr align 8 %op) unnamed_addr #0 !guid !241 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_3 = select i1 %7, i64 1, i64 0
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}
  %9 = call { i64, i64 } @_RNCNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB7_11RawVecInner11finish_grow0Cs4mnquxVp34G_6errors(ptr align 8 %op) #25
  %_6.0 = extractvalue { i64, i64 } %9, 0
  %_6.1 = extractvalue { i64, i64 } %9, 1
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 %_6.1, ptr %11, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load ptr, ptr %self, align 8
  %12 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %t.0, ptr %13, align 8
  %14 = getelementptr inbounds i8, ptr %13, i64 8
  store i64 %t.1, ptr %14, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %15 = load i8, ptr %_9, align 1
  %16 = trunc nuw i8 %15 to i1
  br i1 %16, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, i64 %0, i64 %1) unnamed_addr #0 !guid !242 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load i64, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = icmp eq i64 %3, 0
  %_3 = select i1 %6, i64 1, i64 0
  %7 = trunc nuw i64 %_3 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call alloc::raw_vec::layout_array::{closure#0}
  %8 = call { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0Cs4mnquxVp34G_6errors() #25
  %_6.0 = extractvalue { i64, i64 } %8, 0
  %_6.1 = extractvalue { i64, i64 } %8, 1
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %_6.1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load i64, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %t.0, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 8
  store i64 %t.1, ptr %13, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %14 = load i8, ptr %_9, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, &str>>::map_or::<i32, errors::main::{closure#5}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultlReE6map_orlNCNvCs4mnquxVp34G_6errors4mains3_0EBY_(ptr align 8 %self, i32 %default) unnamed_addr #0 personality ptr @rust_eh_personality !guid !243 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_4 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_4 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i32 %default, ptr %_0, align 4
  br label %bb10

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load i32, ptr %4, align 8
  store i8 0, ptr %_8, align 1
; call errors::main::{closure#5}
  %5 = call i32 @_RNCNvCs4mnquxVp34G_6errors4mains3_0B3_(i32 %t) #25
  store i32 %5, ptr %_0, align 4
  br label %bb16

bb16:                                             ; preds = %bb3
  br label %bb10

bb10:                                             ; preds = %bb2, %bb16
  %6 = load i8, ptr %_8, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb9, label %bb4

bb4:                                              ; preds = %bb9, %bb10
  %8 = load i8, ptr %_9, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb11, label %bb5

bb9:                                              ; preds = %bb10
  br label %bb4

bb5:                                              ; preds = %bb11, %bb4
  %10 = load ptr, ptr %self, align 8
  %11 = ptrtoint ptr %10 to i64
  %12 = icmp eq i64 %11, 0
  %_10 = select i1 %12, i64 0, i64 1
  %13 = trunc nuw i64 %_10 to i1
  br i1 %13, label %bb12, label %bb6

bb11:                                             ; preds = %bb4
  br label %bb5

bb12:                                             ; preds = %bb5
  br label %bb6

bb6:                                              ; preds = %bb12, %bb5
  %14 = load i32, ptr %_0, align 4
  ret i32 %14

bb1:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable

bb14:                                             ; No predecessors!
  unreachable

bb15:                                             ; No predecessors!
  unreachable
}

; <core::result::Result<i32, &str>>::and_then::<i32, errors::main::{closure#3}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultlReE8and_thenlNCNvCs4mnquxVp34G_6errors4mains1_0EB10_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !244 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load i64, ptr %4, align 8
  store ptr %e.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.1, ptr %5, align 8
  br label %bb6

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load i32, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call errors::main::{closure#3}
  call void @_RNCNvCs4mnquxVp34G_6errors4mains1_0B3_(ptr sret([16 x i8]) align 8 %_0, i32 %t) #25
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_8, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i64, errors::AppError>>::map_err::<alloc::string::String, errors::main::{closure#2}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultxNtCs4mnquxVp34G_6errors8AppErrorE7map_errNtNtCs7CppTae75M1_5alloc6string6StringNCNvBL_4mains0_0EBL_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !245 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [24 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %e = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %e, ptr align 8 %self, i64 24, i1 false)
  store i8 0, ptr %_9, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_8, ptr align 8 %e, i64 24, i1 false)
; call errors::main::{closure#2}
  call void @_RNCNvCs4mnquxVp34G_6errors4mains0_0B3_(ptr sret([24 x i8]) align 8 %_6, ptr align 8 %_8) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 24, i1 false)
  br label %bb7

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load i64, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %t, ptr %4, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %5 = load i8, ptr %_9, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i64, errors::AppError>>::map_err::<alloc::string::String, errors::main::{closure#1}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultxNtCs4mnquxVp34G_6errors8AppErrorE7map_errNtNtCs7CppTae75M1_5alloc6string6StringNCNvBL_4mains_0EBL_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !246 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [24 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %e = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %e, ptr align 8 %self, i64 24, i1 false)
  store i8 0, ptr %_9, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_8, ptr align 8 %e, i64 24, i1 false)
; call errors::main::{closure#1}
  call void @_RNCNvCs4mnquxVp34G_6errors4mains_0B3_(ptr sret([24 x i8]) align 8 %_6, ptr align 8 %_8) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 24, i1 false)
  br label %bb7

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load i64, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %t, ptr %4, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %5 = load i8, ptr %_9, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<alloc::boxed::Box<dyn core::error::Error>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !247 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB9_5error5ErrorEL_EE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBa_5error5ErrorEL_EE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsm_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtBM_3fmt7Display3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorNtNtB7_6marker4SyncNtB1T_4SendEL_EECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !248 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB9_5error5ErrorNtNtB9_6marker4SyncNtB1O_4SendEL_EE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBa_5error5ErrorNtNtBa_6marker4SyncNtB1P_4SendEL_EE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsm_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBM_6marker4SyncNtB1j_4SendEL_ENtNtBM_3fmt7Display3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<errors::AppError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCs4mnquxVp34G_6errors8AppErrorEB10_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !249 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<errors::AppError>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs4mnquxVp34G_6errors8AppErrorE8from_refBV_(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<errors::AppError>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCs4mnquxVp34G_6errors8AppErrorE4castuEBW_(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXCs4mnquxVp34G_6errorsNtB2_8AppErrorNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<&alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !250 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<&alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtNtCs7CppTae75M1_5alloc6string6StringE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_7Display3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<&core::num::error::ParseIntError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRNtNtNtB7_3num5error13ParseIntErrorECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !251 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&core::num::error::ParseIntError>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtNtNtB9_3num5error13ParseIntErrorE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<&core::num::error::ParseIntError>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtNtNtBa_3num5error13ParseIntErrorE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_7Display3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<&i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRxECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !252 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRxE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<&i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRxE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRxNtB6_7Display3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !253 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs4mnquxVp34G_6errors(ptr %x) #25
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !254 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refCs4mnquxVp34G_6errors(ptr %x) #25
; call <core::ptr::non_null::NonNull<u8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !255 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<usize>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<usize>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !256 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCs4mnquxVp34G_6errors(ptr align 4 %x) #25
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !257 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !258 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i32>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEE8from_refCs4mnquxVp34G_6errors(ptr align 4 %x) #25
; call <core::ptr::non_null::NonNull<core::option::Option<i32>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionlEE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i8, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultaNtNtNtB7_3num5error13ParseIntErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !259 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultaNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs4mnquxVp34G_6errors(ptr %x) #25
; call <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultaNtNtNtBa_3num5error13ParseIntErrorEE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultaNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<bool, core::str::error::ParseBoolError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultbNtNtNtB7_3str5error14ParseBoolErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !260 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<bool, core::str::error::ParseBoolError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultbNtNtNtB9_3str5error14ParseBoolErrorEE8from_refCs4mnquxVp34G_6errors(ptr %x) #25
; call <core::ptr::non_null::NonNull<core::result::Result<bool, core::str::error::ParseBoolError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultbNtNtNtBa_3str5error14ParseBoolErrorEE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultbNtNtNtB7_3str5error14ParseBoolErrorENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<f64, core::num::float_parse::ParseFloatError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !261 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<f64, core::num::float_parse::ParseFloatError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultdNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<core::result::Result<f64, core::num::float_parse::ParseFloatError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultdNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<u8, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResulthNtNtNtB7_3num5error13ParseIntErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !262 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<u8, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResulthNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs4mnquxVp34G_6errors(ptr %x) #25
; call <core::ptr::non_null::NonNull<core::result::Result<u8, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResulthNtNtNtBa_3num5error13ParseIntErrorEE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i32, &str>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultlReEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !263 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i32, &str>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlReEE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<core::result::Result<i32, &str>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlReEE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultlReENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i64, alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !264 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i64, alloc::string::String>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<core::result::Result<i64, alloc::string::String>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtNtCs7CppTae75M1_5alloc6string6StringENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<errors::AppError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCs4mnquxVp34G_6errors8AppErrorEBX_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !265 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<errors::AppError>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs4mnquxVp34G_6errors8AppErrorE8from_refBV_(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<errors::AppError>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCs4mnquxVp34G_6errors8AppErrorE4castuEBW_(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1_Cs4mnquxVp34G_6errorsNtB5_8AppErrorNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !266 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCs4mnquxVp34G_6errors(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCs4mnquxVp34G_6errors, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<dyn core::error::Error>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_5error5ErrorEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !267 {
start:
; call core::mem::align_of_val_raw::<dyn core::error::Error>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_5error5ErrorEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) #25
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs4mnquxVp34G_6errors(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #25
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<dyn core::error::Error + core::marker::Sync + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_5error5ErrorNtNtB7_6marker4SyncNtB1r_4SendEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !268 {
start:
; call core::mem::align_of_val_raw::<dyn core::error::Error + core::marker::Sync + core::marker::Send>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB15_4SendEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) #25
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs4mnquxVp34G_6errors(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #25
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawINtNtB5_12maybe_uninit11MaybeUninitAINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EECs4mnquxVp34G_6errors(ptr %val) unnamed_addr #0 !guid !269 {
start:
; call core::mem::align_of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawINtNtB2_12maybe_uninit11MaybeUninitAINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EECs4mnquxVp34G_6errors(ptr %val) #25
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs4mnquxVp34G_6errors(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #25
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<[core::result::Result<i32, alloc::string::String>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !270 {
start:
; call core::mem::align_of_val_raw::<[core::result::Result<i32, alloc::string::String>]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %val.0, i64 %val.1) #25
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs4mnquxVp34G_6errors(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #25
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of::<core::result::Result<i32, alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors() unnamed_addr #0 !guid !271 {
start:
  ret i64 8
}

; <core::mem::alignment::Alignment>::of::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofhECs4mnquxVp34G_6errors() unnamed_addr #0 !guid !272 {
start:
  ret i64 1
}

; <core::alloc::layout::Layout>::for_value_raw::<dyn core::error::Error>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_5error5ErrorEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !273 {
start:
; call core::mem::size_of_val_raw::<dyn core::error::Error>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_5error5ErrorEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) #25
; call <core::mem::alignment::Alignment>::of_val_raw::<dyn core::error::Error>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_5error5ErrorEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) #25
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs4mnquxVp34G_6errors(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<dyn core::error::Error + core::marker::Sync + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_5error5ErrorNtNtB7_6marker4SyncNtB1q_4SendEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !274 {
start:
; call core::mem::size_of_val_raw::<dyn core::error::Error + core::marker::Sync + core::marker::Send>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB14_4SendEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) #25
; call <core::mem::alignment::Alignment>::of_val_raw::<dyn core::error::Error + core::marker::Sync + core::marker::Send>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_5error5ErrorNtNtB7_6marker4SyncNtB1r_4SendEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) #25
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs4mnquxVp34G_6errors(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawINtNtNtB7_3mem12maybe_uninit11MaybeUninitAINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EECs4mnquxVp34G_6errors(ptr %val) unnamed_addr #0 !guid !275 {
start:
; call core::mem::size_of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawINtNtB2_12maybe_uninit11MaybeUninitAINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EECs4mnquxVp34G_6errors(ptr %val) #25
; call <core::mem::alignment::Alignment>::of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawINtNtB5_12maybe_uninit11MaybeUninitAINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EECs4mnquxVp34G_6errors(ptr %val) #25
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs4mnquxVp34G_6errors(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<[core::result::Result<i32, alloc::string::String>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !276 {
start:
; call core::mem::size_of_val_raw::<[core::result::Result<i32, alloc::string::String>]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %val.0, i64 %val.1) #25
; call <core::mem::alignment::Alignment>::of_val_raw::<[core::result::Result<i32, alloc::string::String>]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %val.0, i64 %val.1) #25
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs4mnquxVp34G_6errors(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<dyn core::error::Error>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_5error5ErrorEL_E4casthECs4mnquxVp34G_6errors(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !277 {
start:
; call <core::ptr::non_null::NonNull<dyn core::error::Error>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_5error5ErrorEL_E4casthECs4mnquxVp34G_6errors(ptr %self.0, ptr align 8 %self.1) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<dyn core::error::Error + core::marker::Sync + core::marker::Send>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_5error5ErrorNtNtBa_6marker4SyncNtB1d_4SendEL_E4casthECs4mnquxVp34G_6errors(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !278 {
start:
; call <core::ptr::non_null::NonNull<dyn core::error::Error + core::marker::Sync + core::marker::Send>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_5error5ErrorNtNtBa_6marker4SyncNtB1g_4SendEL_E4casthECs4mnquxVp34G_6errors(ptr %self.0, ptr align 8 %self.1) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueINtNtNtBa_3mem12maybe_uninit11MaybeUninitAINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EE4casthECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !279 {
start:
; call <core::ptr::non_null::NonNull<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtNtBa_3mem12maybe_uninit11MaybeUninitAINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EE4casthECs4mnquxVp34G_6errors(ptr %self) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<[core::result::Result<i32, alloc::string::String>]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE4casthECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !280 {
start:
; call <core::ptr::non_null::NonNull<[core::result::Result<i32, alloc::string::String>]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE4casthECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<core::result::Result<i32, alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !281 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<core::result::Result<i32, alloc::string::String>>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %self) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !282 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECs4mnquxVp34G_6errors(ptr %self) #25
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<dyn core::error::Error>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_5error5ErrorEL_E4casthECs4mnquxVp34G_6errors(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !283 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<dyn core::error::Error + core::marker::Sync + core::marker::Send>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_5error5ErrorNtNtBa_6marker4SyncNtB1g_4SendEL_E4casthECs4mnquxVp34G_6errors(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !284 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionlEE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !285 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultaNtNtNtBa_3num5error13ParseIntErrorEE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !286 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<bool, core::str::error::ParseBoolError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultbNtNtNtBa_3str5error14ParseBoolErrorEE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !287 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<f64, core::num::float_parse::ParseFloatError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultdNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !288 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<u8, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResulthNtNtNtBa_3num5error13ParseIntErrorEE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !289 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE4casthECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !290 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, &str>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlReEE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !291 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i64, alloc::string::String>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !292 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBa_5error5ErrorEL_EE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !293 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBa_5error5ErrorNtNtBa_6marker4SyncNtB1P_4SendEL_EE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !294 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtNtBa_3mem12maybe_uninit11MaybeUninitAINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EE4casthECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !295 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<errors::AppError>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCs4mnquxVp34G_6errors8AppErrorE4castuEBW_(ptr %self) unnamed_addr #0 !guid !296 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !297 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtNtCs7CppTae75M1_5alloc6string6StringE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !298 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&core::num::error::ParseIntError>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtNtNtBa_3num5error13ParseIntErrorE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !299 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRxE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !300 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[core::result::Result<i32, alloc::string::String>]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE4casthECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !301 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[&str]>>::cast::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSReE4castBV_ECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !302 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !303 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !304 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<core::result::Result<i32, alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !305 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !306 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !307 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<usize>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !308 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !309 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !310 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<core::result::Result<i32, alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB8_6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !311 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<core::result::Result<i32, alloc::string::String>>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB8_6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::ptr::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !312 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u8>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<core::result::Result<i32, alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB8_6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !313 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<core::result::Result<i32, alloc::string::String>>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %_3) #25
; call <core::ptr::unique::Unique<core::result::Result<i32, alloc::string::String>>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE15as_non_null_ptrCs4mnquxVp34G_6errors(ptr %_2) #25
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::non_null::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !314 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECs4mnquxVp34G_6errors(ptr %_3) #25
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCs4mnquxVp34G_6errors(ptr %_2) #25
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<26, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1a_Kj3_ECs4mnquxVp34G_6errors(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !315 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs4mnquxVp34G_6errors(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !316 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<7, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj1_ECs4mnquxVp34G_6errors(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !317 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs4mnquxVp34G_6errors(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !318 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECs4mnquxVp34G_6errors(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !319 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_ECs4mnquxVp34G_6errors(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !320 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs4mnquxVp34G_6errors(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !321 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECs4mnquxVp34G_6errors(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !322 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::any::TypeId>::of::<errors::AppError>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtCs4mnquxVp34G_6errors8AppErrorEBM_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !323 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.19a2d63c9399c5c07731ce664756b6ea.0, i64 16, i1 false)
  ret void
}

; <core::any::TypeId>::of::<core::num::error::ParseIntError>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtNtNtB8_3num5error13ParseIntErrorECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !324 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.19a2d63c9399c5c07731ce664756b6ea.1, i64 16, i1 false)
  ret void
}

; <core::any::TypeId>::of::<<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBU_3BoxDNtNtB8_5error5ErrorNtNtB8_6marker4SyncNtB20_4SendEL_EINtNtB8_7convert4FromNtNtBW_6string6StringE4from11StringErrorECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !325 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.19a2d63c9399c5c07731ce664756b6ea.2, i64 16, i1 false)
  ret void
}

; alloc::raw_vec::new_cap::<core::result::Result<i32, alloc::string::String>>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB4_6string6StringEECs4mnquxVp34G_6errors(i64 %cap) unnamed_addr #1 !guid !326 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs4mnquxVp34G_6errors(i64 %cap) #25
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs4mnquxVp34G_6errors(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !327 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::is_val_statically_known::<bool>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownbECs4mnquxVp34G_6errors(i1 zeroext %_arg) unnamed_addr #2 !guid !328 {
start:
  ret i1 false
}

; core::cmp::max::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECs4mnquxVp34G_6errors(i64 %v1, i64 %v2) unnamed_addr #0 !guid !329 {
start:
; call <usize as core::cmp::Ord>::max
  %_0 = call i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxCs4mnquxVp34G_6errors(i64 %v1, i64 %v2) #25
  ret i64 %_0
}

; core::mem::needs_drop::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropReECs4mnquxVp34G_6errors() unnamed_addr #0 !guid !330 {
start:
  ret i1 false
}

; core::mem::size_of_val_raw::<dyn core::error::Error>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_5error5ErrorEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !331 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %_0 = load i64, ptr %0, align 8, !invariant.load !332
  %1 = getelementptr inbounds i8, ptr %val.1, i64 16
  %2 = load i64, ptr %1, align 8, !invariant.load !332
  ret i64 %_0
}

; core::mem::size_of_val_raw::<dyn core::error::Error + core::marker::Sync + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB14_4SendEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !333 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %_0 = load i64, ptr %0, align 8, !invariant.load !332
  %1 = getelementptr inbounds i8, ptr %val.1, i64 16
  %2 = load i64, ptr %1, align 8, !invariant.load !332
  ret i64 %_0
}

; core::mem::size_of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawINtNtB2_12maybe_uninit11MaybeUninitAINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EECs4mnquxVp34G_6errors(ptr %val) unnamed_addr #0 !guid !334 {
start:
  ret i64 72
}

; core::mem::size_of_val_raw::<[core::result::Result<i32, alloc::string::String>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !335 {
start:
  %_0 = mul nuw nsw i64 %val.1, 24
  ret i64 %_0
}

; core::mem::align_of_val_raw::<dyn core::error::Error>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_5error5ErrorEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !336 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %1 = load i64, ptr %0, align 8, !invariant.load !332
  %2 = getelementptr inbounds i8, ptr %val.1, i64 16
  %_0 = load i64, ptr %2, align 8, !invariant.load !332
  ret i64 %_0
}

; core::mem::align_of_val_raw::<dyn core::error::Error + core::marker::Sync + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB15_4SendEL_ECs4mnquxVp34G_6errors(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !337 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %1 = load i64, ptr %0, align 8, !invariant.load !332
  %2 = getelementptr inbounds i8, ptr %val.1, i64 16
  %_0 = load i64, ptr %2, align 8, !invariant.load !332
  ret i64 %_0
}

; core::mem::align_of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawINtNtB2_12maybe_uninit11MaybeUninitAINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EECs4mnquxVp34G_6errors(ptr %val) unnamed_addr #0 !guid !338 {
start:
  ret i64 8
}

; core::mem::align_of_val_raw::<[core::result::Result<i32, alloc::string::String>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !339 {
start:
  %0 = mul nuw nsw i64 %val.1, 24
  ret i64 8
}

; core::ptr::slice_from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECs4mnquxVp34G_6errors(ptr %data, i64 %len) unnamed_addr #0 !guid !340 {
start:
; call core::ptr::metadata::from_raw_parts::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECs4mnquxVp34G_6errors(ptr %data, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<core::result::Result<i32, alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %data, i64 %len) unnamed_addr #0 !guid !341 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[core::result::Result<i32, alloc::string::String>], core::result::Result<i32, alloc::string::String>>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtB6_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEBX_ECs4mnquxVp34G_6errors(ptr %data, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECs4mnquxVp34G_6errors(ptr %data, i64 %len) unnamed_addr #0 !guid !342 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECs4mnquxVp34G_6errors(ptr %data, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<dyn core::error::Error>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueDNtNtB4_5error5ErrorEL_ECs4mnquxVp34G_6errors(ptr %_1.0, ptr align 8 %_1.1) unnamed_addr #1 !guid !343 {
start:
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 0
  %1 = load ptr, ptr %0, align 8, !invariant.load !332
  %2 = icmp ne ptr %1, null
  br i1 %2, label %is_not_null, label %bb1

is_not_null:                                      ; preds = %start
  call void %1(ptr %_1.0) #25
  br label %bb1

bb1:                                              ; preds = %is_not_null, %start
  ret void
}

; core::ptr::drop_glue::<dyn core::error::Error + core::marker::Sync + core::marker::Send>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtBX_4SendEL_ECs4mnquxVp34G_6errors(ptr %_1.0, ptr align 8 %_1.1) unnamed_addr #1 !guid !344 {
start:
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 0
  %1 = load ptr, ptr %0, align 8, !invariant.load !332
  %2 = icmp ne ptr %1, null
  br i1 %2, label %is_not_null, label %bb1

is_not_null:                                      ; preds = %start
  call void %1(ptr %_1.0) #25
  br label %bb1

bb1:                                              ; preds = %is_not_null, %start
  ret void
}

; core::ptr::drop_glue::<core::result::Result<i32, alloc::string::String>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !345 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<i64, alloc::string::String>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !346 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !347 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtNtBK_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %_1) #23
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !348 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECs4mnquxVp34G_6errors(ptr align 8 %_1) #23
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECs4mnquxVp34G_6errors(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorEL_EECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !349 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6.1, i64 0
  %3 = load ptr, ptr %2, align 8, !invariant.load !332
  %4 = icmp ne ptr %3, null
  br i1 %4, label %is_not_null, label %bb3

is_not_null:                                      ; preds = %start
  invoke void %3(ptr %_6.0)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %is_not_null, %start
; call <alloc::boxed::Box<dyn core::error::Error> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtNtBM_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #25
  ret void

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<dyn core::error::Error> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtNtBM_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #23
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %is_not_null
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb2:                                              ; preds = %bb4
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1w_4SendEL_EECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !350 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6.1, i64 0
  %3 = load ptr, ptr %2, align 8, !invariant.load !332
  %4 = icmp ne ptr %3, null
  br i1 %4, label %is_not_null, label %bb3

is_not_null:                                      ; preds = %start
  invoke void %3(ptr %_6.0)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %is_not_null, %start
; call <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBM_6marker4SyncNtB1j_4SendEL_ENtNtNtBM_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #25
  ret void

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBM_6marker4SyncNtB1j_4SendEL_ENtNtNtBM_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #23
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %is_not_null
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb2:                                              ; preds = %bb4
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; core::ptr::drop_glue::<alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtNtB4_3mem12maybe_uninit11MaybeUninitAINtNtB4_6result6ResultlNtNtBG_6string6StringEj3_EEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !351 {
start:
  %0 = alloca [16 x i8], align 8
  %_6 = load ptr, ptr %_1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtNtCsl10jNU3mE6R_4core3mem12maybe_uninit11MaybeUninitAINtNtBO_6result6ResultlNtNtB7_6string6StringEj3_EENtNtNtBO_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #25
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtNtCsl10jNU3mE6R_4core3mem12maybe_uninit11MaybeUninitAINtNtBO_6result6ResultlNtNtB7_6string6StringEj3_EENtNtNtBO_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #23
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb2:                                              ; preds = %bb4
  %2 = load ptr, ptr %0, align 8
  %3 = getelementptr inbounds i8, ptr %0, i64 8
  %4 = load i32, ptr %3, align 8
  %5 = insertvalue { ptr, i32 } poison, ptr %2, 0
  %6 = insertvalue { ptr, i32 } %5, i32 %4, 1
  resume { ptr, i32 } %6
}

; core::ptr::drop_glue::<alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !352 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
; invoke core::ptr::drop_glue::<[core::result::Result<i32, alloc::string::String>]>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_6.0, i64 %_6.1)
          to label %bb3 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtNtBN_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #23
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb4

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtNtBN_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #25
  ret void

terminate:                                        ; preds = %bb4
  %6 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb2:                                              ; preds = %bb4
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = insertvalue { ptr, i32 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i32 } %10, i32 %9, 1
  resume { ptr, i32 } %11
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !353 {
start:
; call <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtNtBR_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !354 {
start:
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<&str, 4>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterReKj4_EECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !355 {
start:
; call <core::array::iter::IntoIter<&str, 4> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj4_ENtNtNtB9_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #25
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<&str, 7>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterReKj7_EECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !356 {
start:
; call <core::array::iter::IntoIter<&str, 7> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj7_ENtNtNtB9_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #25
  ret void
}

; core::ptr::drop_glue::<alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB4_6result6ResultlNtNtBI_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !357 {
start:
; call <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::ops::drop::Drop>::drop
  call void @_RNvXse_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEENtNtNtB11_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitReEj4_EECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !358 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj4_ENtNtNtBb_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #25
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitReEj7_EECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !359 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj7_ENtNtNtBb_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %_1) #25
  ret void
}

; core::ptr::drop_glue::<<alloc::vec::into_iter::IntoIter<_, _> as core::ops::drop::Drop>::drop::DropGuard<core::result::Result<i32, alloc::string::String>, alloc::alloc::Global>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvXse_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtBK_8IntoIterppENtNtNtB4_3ops4drop4Drop4drop9DropGuardINtNtB4_6result6ResultlNtNtBO_6string6StringENtNtBO_5alloc6GlobalEECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !360 {
start:
; call <<alloc::vec::into_iter::IntoIter<_, _> as core::ops::drop::Drop>::drop::DropGuard<core::result::Result<i32, alloc::string::String>, alloc::alloc::Global> as core::ops::drop::Drop>::drop
  call void @_RNvXNvXse_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB8_8IntoIterppENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropINtB2_9DropGuardINtNtB18_6result6ResultlNtNtBc_6string6StringENtNtBc_5alloc6GlobalEB12_4dropCs4mnquxVp34G_6errors(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<errors::AppError>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %_1) unnamed_addr #1 !guid !361 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = sub i64 %0, -9223372036854775808
  %2 = icmp uge i64 %0, -9223372036854775808
  %_2 = select i1 %2, i64 %1, i64 2
  switch i64 %_2, label %bb2 [
    i64 0, label %bb1
    i64 1, label %bb1
  ]

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr align 8 %_1)
  br label %bb1

bb1:                                              ; preds = %bb2, %start, %start
  ret void
}

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !362 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECs4mnquxVp34G_6errors(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBL_3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1R_4SendEL_EINtNtB4_7convert4FromNtNtBN_6string6StringE4from11StringErrorECs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #1 !guid !363 {
start:
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<[core::result::Result<i32, alloc::string::String>]>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_1.0, i64 %_1.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !364 {
start:
  %0 = alloca [16 x i8], align 8
  %_3 = alloca [8 x i8], align 8
  store i64 0, ptr %_3, align 8
  br label %bb6

bb6:                                              ; preds = %bb5, %start
  %1 = load i64, ptr %_3, align 8
  %_7 = icmp eq i64 %1, %_1.1
  br i1 %_7, label %bb1, label %bb5

bb5:                                              ; preds = %bb6
  %2 = load i64, ptr %_3, align 8
  %_6 = getelementptr inbounds nuw %"core::result::Result<i32, alloc::string::String>", ptr %_1.0, i64 %2
  %3 = load i64, ptr %_3, align 8
  %4 = add i64 %3, 1
  store i64 %4, ptr %_3, align 8
; invoke core::ptr::drop_glue::<core::result::Result<i32, alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_6)
          to label %bb6 unwind label %cleanup

bb1:                                              ; preds = %bb6
  ret void

bb4:                                              ; preds = %bb3, %cleanup
  %5 = load i64, ptr %_3, align 8
  %_5 = icmp eq i64 %5, %_1.1
  br i1 %_5, label %bb2, label %bb3

cleanup:                                          ; preds = %bb5
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb4

bb3:                                              ; preds = %bb4
  %10 = load i64, ptr %_3, align 8
  %_4 = getelementptr inbounds nuw %"core::result::Result<i32, alloc::string::String>", ptr %_1.0, i64 %10
  %11 = load i64, ptr %_3, align 8
  %12 = add i64 %11, 1
  store i64 %12, ptr %_3, align 8
; invoke core::ptr::drop_glue::<core::result::Result<i32, alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_4) #23
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb4
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr inbounds i8, ptr %0, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

terminate:                                        ; preds = %bb3
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable
}

; core::hint::black_box::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxReECs4mnquxVp34G_6errors(ptr %dummy.0, i64 %dummy.1) unnamed_addr #0 !guid !365 {
start:
  %_0 = alloca [16 x i8], align 8
  store ptr %dummy.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %dummy.1, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !366
  %1 = load ptr, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { ptr, i64 } poison, ptr %1, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %3, 1
  ret { ptr, i64 } %5
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECs4mnquxVp34G_6errors() unnamed_addr #0 !guid !367 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !366
  ret void
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4mnquxVp34G_6errors(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !368 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4mnquxVp34G_6errors(ptr %f) #25
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECs4mnquxVp34G_6errors() #25
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECs4mnquxVp34G_6errors(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !369 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[core::result::Result<i32, alloc::string::String>], core::result::Result<i32, alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtB6_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEBX_ECs4mnquxVp34G_6errors(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !370 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECs4mnquxVp34G_6errors(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !371 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&str>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitReEECs4mnquxVp34G_6errors(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !372 {
start:
  ret i64 %ptr.1
}

; core::ptr::metadata::metadata::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECs4mnquxVp34G_6errors(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !373 {
start:
  ret i64 %ptr.1
}

; core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs4mnquxVp34G_6errors(ptr align 8 %bytes) unnamed_addr #0 !guid !374 {
start:
  %ch = alloca [4 x i8], align 4
  %_3 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
  %_4 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %bytes) #25
; call <core::option::Option<&u8> as core::ops::try_trait::Try>::branch
  %0 = call ptr @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRhENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr %_4) #25
  store ptr %0, ptr %_3, align 8
  %1 = load ptr, ptr %_3, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_5 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_5 to i1
  br i1 %4, label %bb5, label %bb4

bb5:                                              ; preds = %start
; call <core::option::Option<u32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  %5 = call { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4mnquxVp34G_6errors() #25
  %6 = extractvalue { i32, i32 } %5, 0
  %7 = extractvalue { i32, i32 } %5, 1
  store i32 %6, ptr %_0, align 4
  %8 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %7, ptr %8, align 4
  br label %bb21

bb4:                                              ; preds = %start
  %val = load ptr, ptr %_3, align 8
  %x = load i8, ptr %val, align 1
  %_7 = icmp ult i8 %x, -128
  br i1 %_7, label %bb6, label %bb7

bb7:                                              ; preds = %bb4
; call core::str::validations::utf8_first_byte
  %init = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCs4mnquxVp34G_6errors(i8 %x, i32 2) #25
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
  %_12 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %bytes) #25
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_11 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCs4mnquxVp34G_6errors(ptr %_12, ptr align 8 @alloc_4202fd0e53b2664da52f5b453f055200) #25
  %y = load i8, ptr %_11, align 1
; call core::str::validations::utf8_acc_cont_byte
  %9 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCs4mnquxVp34G_6errors(i32 %init, i8 %y) #25
  store i32 %9, ptr %ch, align 4
  %_14 = icmp uge i8 %x, -32
  br i1 %_14, label %bb12, label %bb20

bb6:                                              ; preds = %bb4
  %_8 = zext i8 %x to i32
  %10 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_8, ptr %10, align 4
  store i32 1, ptr %_0, align 4
  br label %bb21

bb20:                                             ; preds = %bb16, %bb12, %bb7
  %_29 = load i32, ptr %ch, align 4
  %11 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_29, ptr %11, align 4
  store i32 1, ptr %_0, align 4
  br label %bb21

bb12:                                             ; preds = %bb7
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
  %_17 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %bytes) #25
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_16 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCs4mnquxVp34G_6errors(ptr %_17, ptr align 8 @alloc_8f9bddbbaa03eec60f2c6205160c2a64) #25
  %z = load i8, ptr %_16, align 1
  %_20 = and i8 %y, 63
  %_19 = zext i8 %_20 to i32
; call core::str::validations::utf8_acc_cont_byte
  %y_z = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCs4mnquxVp34G_6errors(i32 %_19, i8 %z) #25
  %_21 = shl i32 %init, 12
  %12 = or i32 %_21, %y_z
  store i32 %12, ptr %ch, align 4
  %_22 = icmp uge i8 %x, -16
  br i1 %_22, label %bb16, label %bb20

bb16:                                             ; preds = %bb12
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
  %_25 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %bytes) #25
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_24 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCs4mnquxVp34G_6errors(ptr %_25, ptr align 8 @alloc_87f411d4acc54b1b619e428c06de9910) #25
  %w = load i8, ptr %_24, align 1
  %_27 = and i32 %init, 7
  %_26 = shl i32 %_27, 18
; call core::str::validations::utf8_acc_cont_byte
  %_28 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCs4mnquxVp34G_6errors(i32 %y_z, i8 %w) #25
  %13 = or i32 %_26, %_28
  store i32 %13, ptr %ch, align 4
  br label %bb20

bb21:                                             ; preds = %bb5, %bb6, %bb20
  %14 = load i32, ptr %_0, align 4
  %15 = getelementptr inbounds i8, ptr %_0, i64 4
  %16 = load i32, ptr %15, align 4
  %17 = insertvalue { i32, i32 } poison, i32 %14, 0
  %18 = insertvalue { i32, i32 } %17, i32 %16, 1
  ret { i32, i32 } %18

bb3:                                              ; No predecessors!
  unreachable
}

; core::str::validations::next_code_point_reverse::<core::slice::iter::Iter<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECs4mnquxVp34G_6errors(ptr align 8 %bytes) unnamed_addr #0 !guid !375 {
start:
  %ch = alloca [4 x i8], align 4
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_3 = call ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs4mnquxVp34G_6errors(ptr align 8 %bytes) #25
; call <core::option::Option<&u8> as core::ops::try_trait::Try>::branch
  %0 = call ptr @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRhENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr %_3) #25
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_4 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb5, label %bb4

bb5:                                              ; preds = %start
; call <core::option::Option<u32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  %5 = call { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4mnquxVp34G_6errors() #25
  %6 = extractvalue { i32, i32 } %5, 0
  %7 = extractvalue { i32, i32 } %5, 1
  store i32 %6, ptr %_0, align 4
  %8 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %7, ptr %8, align 4
  br label %bb26

bb4:                                              ; preds = %start
  %val = load ptr, ptr %_2, align 8
  %_8 = load i8, ptr %val, align 1
  %_7 = icmp ult i8 %_8, -128
  br i1 %_7, label %bb6, label %bb7

bb7:                                              ; preds = %bb4
  %w = load i8, ptr %val, align 1
; call <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_14 = call ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs4mnquxVp34G_6errors(ptr align 8 %bytes) #25
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_13 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCs4mnquxVp34G_6errors(ptr %_14, ptr align 8 @alloc_4a25ca9930abb284a1027ea45af7a631) #25
  %z = load i8, ptr %_13, align 1
; call core::str::validations::utf8_first_byte
  %_15 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCs4mnquxVp34G_6errors(i8 %z, i32 2) #25
  store i32 %_15, ptr %ch, align 4
; call core::str::validations::utf8_is_cont_byte
  %_16 = call zeroext i1 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations17utf8_is_cont_byteCs4mnquxVp34G_6errors(i8 %z) #25
  br i1 %_16, label %bb12, label %bb24

bb6:                                              ; preds = %bb4
  %next_byte = load i8, ptr %val, align 1
  %_9 = zext i8 %next_byte to i32
  %9 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_9, ptr %9, align 4
  store i32 1, ptr %_0, align 4
  br label %bb26

bb24:                                             ; preds = %bb22, %bb7
  %_31 = load i32, ptr %ch, align 4
; call core::str::validations::utf8_acc_cont_byte
  %_30 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCs4mnquxVp34G_6errors(i32 %_31, i8 %w) #25
  store i32 %_30, ptr %ch, align 4
  %_32 = load i32, ptr %ch, align 4
  %10 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_32, ptr %10, align 4
  store i32 1, ptr %_0, align 4
  br label %bb26

bb12:                                             ; preds = %bb7
; call <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_19 = call ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs4mnquxVp34G_6errors(ptr align 8 %bytes) #25
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_18 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCs4mnquxVp34G_6errors(ptr %_19, ptr align 8 @alloc_0d743c13f83ba8690fd970b942745aff) #25
  %y = load i8, ptr %_18, align 1
; call core::str::validations::utf8_first_byte
  %_20 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCs4mnquxVp34G_6errors(i8 %y, i32 3) #25
  store i32 %_20, ptr %ch, align 4
; call core::str::validations::utf8_is_cont_byte
  %_21 = call zeroext i1 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations17utf8_is_cont_byteCs4mnquxVp34G_6errors(i8 %y) #25
  br i1 %_21, label %bb17, label %bb22

bb22:                                             ; preds = %bb17, %bb12
  %_29 = load i32, ptr %ch, align 4
; call core::str::validations::utf8_acc_cont_byte
  %_28 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCs4mnquxVp34G_6errors(i32 %_29, i8 %z) #25
  store i32 %_28, ptr %ch, align 4
  br label %bb24

bb17:                                             ; preds = %bb12
; call <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_24 = call ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs4mnquxVp34G_6errors(ptr align 8 %bytes) #25
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_23 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCs4mnquxVp34G_6errors(ptr %_24, ptr align 8 @alloc_c3e3335a0c490d4e9e40b1812db21613) #25
  %x = load i8, ptr %_23, align 1
; call core::str::validations::utf8_first_byte
  %_25 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCs4mnquxVp34G_6errors(i8 %x, i32 4) #25
  store i32 %_25, ptr %ch, align 4
  %_27 = load i32, ptr %ch, align 4
; call core::str::validations::utf8_acc_cont_byte
  %_26 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCs4mnquxVp34G_6errors(i32 %_27, i8 %y) #25
  store i32 %_26, ptr %ch, align 4
  br label %bb22

bb26:                                             ; preds = %bb5, %bb6, %bb24
  %11 = load i32, ptr %_0, align 4
  %12 = getelementptr inbounds i8, ptr %_0, i64 4
  %13 = load i32, ptr %12, align 4
  %14 = insertvalue { i32, i32 } poison, i32 %11, 0
  %15 = insertvalue { i32, i32 } %14, i32 %13, 1
  ret { i32, i32 } %15

bb3:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECs4mnquxVp34G_6errors(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !376 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECs4mnquxVp34G_6errors(ptr %data, i64 %len) #25
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCs4mnquxVp34G_6errors(ptr %data, i64 1, i64 1, i64 %len, ptr align 8 %0) #27
  br label %bb5
}

; <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
; Function Attrs: cold nonlazybind uwtable
define internal void @_RINvNvMs2_NtCs7CppTae75M1_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4mnquxVp34G_6errors(ptr align 8 %slf, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #4 !guid !377 {
start:
  %_5 = alloca [16 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::grow_amortized
  %0 = call { i64, i64 } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCs4mnquxVp34G_6errors(ptr align 8 %slf, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1)
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_5, align 8
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load i64, ptr %_5, align 8
  %5 = getelementptr inbounds i8, ptr %_5, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = icmp eq i64 %4, -1
  %_6 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_6 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %err.0 = load i64, ptr %_5, align 8
  %9 = getelementptr inbounds i8, ptr %_5, i64 8
  %err.1 = load i64, ptr %9, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #28
  unreachable

bb3:                                              ; preds = %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; core::iter::traits::iterator::Iterator::partition::extend::<core::result::Result<i32, alloc::string::String>, alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>, errors::main::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator9partition6extendINtNtBc_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEINtNtB1H_3vec3VecB1g_ENCNvCs4mnquxVp34G_6errors4main0EB2G_(ptr align 8 %left, ptr align 8 %right) unnamed_addr #0 !guid !378 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %left, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %right, 1
  ret { ptr, ptr } %1
}

; <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::partition::extend<core::result::Result<i32, alloc::string::String>, alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>, errors::main::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXs4_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB6_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtBa_6string6StringEENtNtNtNtB12_4iter6traits8iterator8Iterator4folduNCINvNvB1X_9partition6extendBX_INtB8_3VecBX_ENCNvCs4mnquxVp34G_6errors4main0E0EB3w_(ptr align 8 %self, ptr align 8 %0, ptr align 8 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !379 {
start:
  %2 = alloca [16 x i8], align 8
  %_38 = alloca [1 x i8], align 1
  %_37 = alloca [1 x i8], align 1
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [32 x i8], align 8
  %_32 = alloca [24 x i8], align 8
  %_30 = alloca [24 x i8], align 8
  %tmp = alloca [24 x i8], align 8
  %_21 = alloca [8 x i8], align 8
  %f = alloca [16 x i8], align 8
  store ptr %0, ptr %f, align 8
  %3 = getelementptr inbounds i8, ptr %f, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_38, align 1
  store i8 0, ptr %_37, align 1
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_38, align 1
  store i8 1, ptr %_37, align 1
  br label %bb8

bb8:                                              ; preds = %bb13, %start
  %_19 = getelementptr inbounds i8, ptr %self, i64 8
  %_23 = getelementptr inbounds i8, ptr %self, i64 24
  %4 = load ptr, ptr %_23, align 8
  store ptr %4, ptr %_21, align 8
; invoke <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>> as core::cmp::PartialEq>::ne
  %_18 = invoke zeroext i1 @_RNvYINtNtNtCsl10jNU3mE6R_4core3ptr8non_null7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB9_3cmp9PartialEq2neCs4mnquxVp34G_6errors(ptr align 8 %_19, ptr align 8 %_21)
          to label %bb9 unwind label %cleanup

bb17:                                             ; preds = %bb20, %bb21, %cleanup
  br label %bb25

cleanup:                                          ; preds = %bb10, %bb14, %bb8
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %2, align 8
  %8 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb17

bb9:                                              ; preds = %bb8
  br i1 %_18, label %bb10, label %bb14

bb14:                                             ; preds = %bb9
  store i8 0, ptr %_38, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_34, ptr align 8 %self, i64 32, i1 false)
; invoke <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>::forget_remaining_elements_and_dealloc
  invoke void @_RNvMs0_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEE37forget_remaining_elements_and_deallocCs4mnquxVp34G_6errors(ptr align 8 %_34)
          to label %bb15 unwind label %cleanup

bb10:                                             ; preds = %bb9
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %_25 = load ptr, ptr %9, align 8
; invoke <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>>>::read
  invoke void @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE4readCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %tmp, ptr %_25)
          to label %bb11 unwind label %cleanup

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_37, align 1
  br label %bb16

bb16:                                             ; preds = %bb15
  ret void

bb11:                                             ; preds = %bb10
  store i8 1, ptr %_35, align 1
  %10 = getelementptr inbounds i8, ptr %self, i64 8
  %_27 = load ptr, ptr %10, align 8
  br label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE3addCs4mnquxVp34G_6errors.exit

_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE3addCs4mnquxVp34G_6errors.exit: ; preds = %bb11
  %_3.i = getelementptr inbounds nuw %"core::result::Result<i32, alloc::string::String>", ptr %_27, i64 1
  br label %bb12

bb21:                                             ; preds = %cleanup1
  %11 = load i8, ptr %_35, align 1
  %12 = trunc nuw i8 %11 to i1
  br i1 %12, label %bb20, label %bb17

cleanup1:                                         ; preds = %bb12
  %13 = landingpad { ptr, i32 }
          cleanup
  %14 = extractvalue { ptr, i32 } %13, 0
  %15 = extractvalue { ptr, i32 } %13, 1
  store ptr %14, ptr %2, align 8
  %16 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %15, ptr %16, align 8
  br label %bb21

bb12:                                             ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE3addCs4mnquxVp34G_6errors.exit
  %17 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_3.i, ptr %17, align 8
  store i8 0, ptr %_37, align 1
  store i8 0, ptr %_35, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_32, ptr align 8 %tmp, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_30, ptr align 8 %_32, i64 24, i1 false)
; invoke core::iter::traits::iterator::Iterator::partition::extend::<core::result::Result<i32, alloc::string::String>, alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>, errors::main::{closure#0}>::{closure#0}
  invoke void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator9partition6extendINtNtBe_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEINtNtB1J_3vec3VecB1i_ENCNvCs4mnquxVp34G_6errors4main0E0B2I_(ptr align 8 %f, ptr align 8 %_30)
          to label %bb13 unwind label %cleanup1

bb13:                                             ; preds = %bb12
  store i8 1, ptr %_37, align 1
  store i8 0, ptr %_35, align 1
  br label %bb8

bb20:                                             ; preds = %bb21
; invoke core::ptr::drop_glue::<core::result::Result<i32, alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %tmp) #23
          to label %bb17 unwind label %terminate

terminate:                                        ; preds = %bb26, %bb20
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb25:                                             ; preds = %bb17
  %19 = load i8, ptr %_37, align 1
  %20 = trunc nuw i8 %19 to i1
  br i1 %20, label %bb24, label %bb18

bb18:                                             ; preds = %bb24, %bb25
  %21 = load i8, ptr %_38, align 1
  %22 = trunc nuw i8 %21 to i1
  br i1 %22, label %bb26, label %bb19

bb24:                                             ; preds = %bb25
  br label %bb18

bb19:                                             ; preds = %bb26, %bb18
  %23 = load ptr, ptr %2, align 8
  %24 = getelementptr inbounds i8, ptr %2, i64 8
  %25 = load i32, ptr %24, align 8
  %26 = insertvalue { ptr, i32 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i32 } %26, i32 %25, 1
  resume { ptr, i32 } %27

bb26:                                             ; preds = %bb18
; invoke core::ptr::drop_glue::<alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB4_6result6ResultlNtNtBI_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %self) #23
          to label %bb19 unwind label %terminate

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable
}

; <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !380 {
start:
  %0 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %v = alloca [24 x i8], align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  store i8 0, ptr %_13, align 1
; call <alloc::vec::Vec<u8>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %v, i64 %s.1) #25
  br label %bb1

bb1:                                              ; preds = %start
  %_6 = icmp ugt i64 %s.1, 0
  br i1 %_6, label %bb2, label %bb6

bb6:                                              ; preds = %bb11, %bb1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %v, i64 24, i1 false)
  ret void

bb2:                                              ; preds = %bb1
  br label %bb3

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECs4mnquxVp34G_6errors(ptr align 8 %v) #23
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4, %bb5, %bb3
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
; invoke <alloc::vec::Vec<u8>>::as_mut_ptr
  %_9 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs4mnquxVp34G_6errors(ptr align 8 %v)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke core::ub_checks::check_language_ub
  %_4.i.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
          to label %_4.i.i.noexc unwind label %cleanup

_4.i.i.noexc:                                     ; preds = %bb4
  br i1 %_4.i.i1, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCs4mnquxVp34G_6errors.exit

bb2.i.i:                                          ; preds = %_4.i.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs4mnquxVp34G_6errors(ptr %s.0, ptr %_9, i64 1, i64 1, i64 %s.1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #27
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCs4mnquxVp34G_6errors.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCs4mnquxVp34G_6errors.exit: ; preds = %_4.i.i.noexc, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_9, ptr align 1 %s.0, i64 %s.1, i1 false)
  br label %bb5

bb5:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCs4mnquxVp34G_6errors.exit
; invoke <alloc::vec::Vec<u8>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCs4mnquxVp34G_6errors(ptr align 8 %v, i64 %s.1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb5
  br label %bb6

terminate:                                        ; preds = %bb7
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb10:                                             ; preds = %bb7
  %6 = load i8, ptr %_13, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb9, label %bb8

bb8:                                              ; preds = %bb9, %bb10
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb9:                                              ; preds = %bb10
  br label %bb8
}

; <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::iterator::Iterator>::partition::<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>, errors::main::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvYINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtBa_6string6StringEENtNtNtNtBW_4iter6traits8iterator8Iterator9partitionINtB8_3VecBR_ENCNvCs4mnquxVp34G_6errors4main0EB2Y_(ptr sret([48 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !381 {
start:
  %0 = alloca [16 x i8], align 8
  %_15 = alloca [1 x i8], align 1
  %_14 = alloca [1 x i8], align 1
  %_13 = alloca [1 x i8], align 1
  %_12 = alloca [24 x i8], align 8
  %_11 = alloca [24 x i8], align 8
  %_6 = alloca [32 x i8], align 8
  %right = alloca [24 x i8], align 8
  %left = alloca [24 x i8], align 8
  store i8 0, ptr %_15, align 1
  store i8 0, ptr %_14, align 1
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_15, align 1
  store i8 1, ptr %_14, align 1
; invoke <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::default::Default>::default
  invoke void @_RNvXsq_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtBK_7default7Default7defaultCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %left)
          to label %bb1 unwind label %cleanup

bb12:                                             ; preds = %bb6, %cleanup
  %1 = load i8, ptr %_14, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb11, label %bb7

cleanup:                                          ; preds = %start
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb12

bb1:                                              ; preds = %start
; invoke <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::default::Default>::default
  invoke void @_RNvXsq_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtBK_7default7Default7defaultCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %right)
          to label %bb2 unwind label %cleanup1

bb6:                                              ; preds = %bb5, %cleanup1
; invoke core::ptr::drop_glue::<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %left) #23
          to label %bb12 unwind label %terminate

cleanup1:                                         ; preds = %bb1
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb6

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_15, align 1
  store i8 1, ptr %_13, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_6, ptr align 8 %self, i64 32, i1 false)
  store i8 0, ptr %_14, align 1
; invoke core::iter::traits::iterator::Iterator::partition::extend::<core::result::Result<i32, alloc::string::String>, alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>, errors::main::{closure#0}>
  %11 = invoke { ptr, ptr } @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator9partition6extendINtNtBc_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEINtNtB1H_3vec3VecB1g_ENCNvCs4mnquxVp34G_6errors4main0EB2G_(ptr align 8 %left, ptr align 8 %right)
          to label %bb3 unwind label %cleanup2

bb10:                                             ; preds = %cleanup2
  %12 = load i8, ptr %_13, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb9, label %bb5

cleanup2:                                         ; preds = %bb3, %bb2
  %14 = landingpad { ptr, i32 }
          cleanup
  %15 = extractvalue { ptr, i32 } %14, 0
  %16 = extractvalue { ptr, i32 } %14, 1
  store ptr %15, ptr %0, align 8
  %17 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %16, ptr %17, align 8
  br label %bb10

bb3:                                              ; preds = %bb2
  %_7.0 = extractvalue { ptr, ptr } %11, 0
  %_7.1 = extractvalue { ptr, ptr } %11, 1
  store i8 0, ptr %_13, align 1
; invoke <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::partition::extend<core::result::Result<i32, alloc::string::String>, alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>, errors::main::{closure#0}>::{closure#0}>
  invoke void @_RINvXs4_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB6_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtBa_6string6StringEENtNtNtNtB12_4iter6traits8iterator8Iterator4folduNCINvNvB1X_9partition6extendBX_INtB8_3VecBX_ENCNvCs4mnquxVp34G_6errors4main0E0EB3w_(ptr align 8 %_6, ptr align 8 %_7.0, ptr align 8 %_7.1)
          to label %bb4 unwind label %cleanup2

bb4:                                              ; preds = %bb3
  store i8 0, ptr %_13, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_11, ptr align 8 %left, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_12, ptr align 8 %right, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_11, i64 24, i1 false)
  %18 = getelementptr inbounds i8, ptr %_0, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_12, i64 24, i1 false)
  ret void

bb5:                                              ; preds = %bb9, %bb10
; invoke core::ptr::drop_glue::<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %right) #23
          to label %bb6 unwind label %terminate

bb9:                                              ; preds = %bb10
; invoke core::ptr::drop_glue::<alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB4_6result6ResultlNtNtBI_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %_6) #23
          to label %bb5 unwind label %terminate

terminate:                                        ; preds = %bb13, %bb6, %bb5, %bb9
  %19 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb7:                                              ; preds = %bb11, %bb12
  %20 = load i8, ptr %_15, align 1
  %21 = trunc nuw i8 %20 to i1
  br i1 %21, label %bb13, label %bb8

bb11:                                             ; preds = %bb12
  br label %bb7

bb8:                                              ; preds = %bb13, %bb7
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr inbounds i8, ptr %0, i64 8
  %24 = load i32, ptr %23, align 8
  %25 = insertvalue { ptr, i32 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i32 } %25, i32 %24, 1
  resume { ptr, i32 } %26

bb13:                                             ; preds = %bb7
; invoke core::ptr::drop_glue::<alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB4_6result6ResultlNtNtBI_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %self) #23
          to label %bb8 unwind label %terminate
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #0 !guid !382 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4mnquxVp34G_6errors(ptr %_4) #26
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs4mnquxVp34G_6errors() #25
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs4mnquxVp34G_6errors(i8 %_2) #25
  ret i32 %_0
}

; core::iter::traits::iterator::Iterator::partition::extend::<core::result::Result<i32, alloc::string::String>, alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>, errors::main::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator9partition6extendINtNtBe_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEINtNtB1J_3vec3VecB1i_ENCNvCs4mnquxVp34G_6errors4main0E0B2I_(ptr align 8 %_1, ptr align 8 %x) unnamed_addr #0 personality ptr @rust_eh_personality !guid !383 {
start:
  %0 = alloca [16 x i8], align 8
  %_14 = alloca [1 x i8], align 1
  %_11 = alloca [24 x i8], align 8
  %_9 = alloca [24 x i8], align 8
  store i8 0, ptr %_14, align 1
  store i8 1, ptr %_14, align 1
  %_5 = getelementptr inbounds i8, ptr %_1, i64 16
; invoke errors::main::{closure#0}
  %_4 = invoke zeroext i1 @_RNCNvCs4mnquxVp34G_6errors4main0B3_(ptr %_5, ptr align 8 %x)
          to label %bb1 unwind label %cleanup

bb7:                                              ; preds = %cleanup
  %1 = load i8, ptr %_14, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb6, label %bb5

cleanup:                                          ; preds = %bb2, %bb3, %start
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb7

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  %7 = getelementptr inbounds i8, ptr %_1, i64 8
  %_13 = load ptr, ptr %7, align 8
  store i8 0, ptr %_14, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_11, ptr align 8 %x, i64 24, i1 false)
; invoke <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::iter::traits::collect::Extend<core::result::Result<i32, alloc::string::String>>>::extend_one
  invoke void @_RNvXsj_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEEINtNtNtNtBK_4iter6traits7collect6ExtendBF_E10extend_oneCs4mnquxVp34G_6errors(ptr align 8 %_13, ptr align 8 %_11)
          to label %bb9 unwind label %cleanup

bb2:                                              ; preds = %bb1
  %_12 = load ptr, ptr %_1, align 8
  store i8 0, ptr %_14, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_9, ptr align 8 %x, i64 24, i1 false)
; invoke <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::iter::traits::collect::Extend<core::result::Result<i32, alloc::string::String>>>::extend_one
  invoke void @_RNvXsj_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEEINtNtNtNtBK_4iter6traits7collect6ExtendBF_E10extend_oneCs4mnquxVp34G_6errors(ptr align 8 %_12, ptr align 8 %_9)
          to label %bb8 unwind label %cleanup

bb9:                                              ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb8, %bb9
  ret void

bb8:                                              ; preds = %bb2
  br label %bb4

bb5:                                              ; preds = %bb6, %bb7
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb6:                                              ; preds = %bb7
; invoke core::ptr::drop_glue::<core::result::Result<i32, alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %x) #23
          to label %bb5 unwind label %terminate

terminate:                                        ; preds = %bb6
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable
}

; errors::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvCs4mnquxVp34G_6errors4main0B3_(ptr %_1, ptr align 8 %r) unnamed_addr #0 !guid !384 {
start:
; call <core::result::Result<i32, alloc::string::String>>::is_ok
  %_0 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlNtNtCs7CppTae75M1_5alloc6string6StringE5is_okCs4mnquxVp34G_6errors(ptr align 8 %r) #25
  ret i1 %_0
}

; errors::main::{closure#2}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCs4mnquxVp34G_6errors4mains0_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %e) unnamed_addr #0 personality ptr @rust_eh_personality !guid !385 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <errors::AppError as alloc::string::ToString>::to_string
  invoke void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringNtCs4mnquxVp34G_6errors8AppErrorNtB5_8ToString9to_stringBA_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %e)
          to label %bb1 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<errors::AppError>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %e) #23
          to label %bb4 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb1:                                              ; preds = %start
; call core::ptr::drop_glue::<errors::AppError>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %e)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb4:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; errors::main::{closure#3}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCs4mnquxVp34G_6errors4mains1_0B3_(ptr sret([16 x i8]) align 8 %_0, i32 %x) unnamed_addr #0 !guid !386 {
start:
; call <i32>::checked_sub
  %0 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_subCs4mnquxVp34G_6errors(i32 %x, i32 5) #25
  %_3.0 = extractvalue { i32, i32 } %0, 0
  %_3.1 = extractvalue { i32, i32 } %0, 1
; call <core::option::Option<i32>>::ok_or::<&str>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionlE5ok_orReECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, i32 %_3.0, i32 %_3.1, ptr @alloc_741b839ab7997434e0f88c7c4ce22049, i64 5) #25
  ret void
}

; errors::main::{closure#4}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvCs4mnquxVp34G_6errors4mains2_0B3_(ptr align 4 %x) unnamed_addr #0 !guid !387 {
start:
; call <&i32 as core::ops::arith::Rem<i32>>::rem
  %_3 = call i32 @_RNvXs4J_NtNtCsl10jNU3mE6R_4core3ops5arithRlINtB6_3RemlE3remCs4mnquxVp34G_6errors(ptr align 4 %x, i32 2, ptr align 8 @alloc_42f0df93bf5e199f2d3d123a5f72ba24) #25
  %_0 = icmp eq i32 %_3, 1
  ret i1 %_0
}

; errors::main::{closure#5}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCs4mnquxVp34G_6errors4mains3_0B3_(i32 %x) unnamed_addr #0 !guid !388 {
start:
  %0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %x, i32 2)
  %_3.0 = extractvalue { i32, i1 } %0, 0
  %_3.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_3.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_3.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_8c0b2c7ba8b468c3eb8b564bd67b0d69) #29
  unreachable
}

; errors::main::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCs4mnquxVp34G_6errors4mains_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %e) unnamed_addr #0 personality ptr @rust_eh_personality !guid !389 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <errors::AppError as alloc::string::ToString>::to_string
  invoke void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringNtCs4mnquxVp34G_6errors8AppErrorNtB5_8ToString9to_stringBA_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %e)
          to label %bb1 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<errors::AppError>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %e) #23
          to label %bb4 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb1:                                              ; preds = %start
; call core::ptr::drop_glue::<errors::AppError>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %e)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb4:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB7_11RawVecInner11finish_grow0Cs4mnquxVp34G_6errors(ptr align 8 %_1) unnamed_addr #0 !guid !390 {
start:
  %_4.0 = load i64, ptr %_1, align 8
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_4.1 = load i64, ptr %0, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %1 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs4mnquxVp34G_6errors(i64 %_4.0, i64 %_4.1, ptr align 8 @alloc_c53d1dc14d9dfd00f89649d83c62a8b7) #25
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitReEE4next0Cs4mnquxVp34G_6errors(ptr align 8 %_1.0, i64 %_1.1, i64 %idx) unnamed_addr #0 !guid !391 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&str>]>::get_unchecked::<usize>
  %_3 = call align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitReE13get_uncheckedjECs4mnquxVp34G_6errors(ptr align 8 %_1.0, i64 %_1.1, i64 %idx, ptr align 8 @alloc_ac893681874450253b62899ecf8cf06a) #25
  %_0.0.i.i.i = load ptr, ptr %_3, align 8
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %_0.1.i.i.i = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1.i.i.i, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1.i.i.i, 1
  %5 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_0.1.i.i.i, 1
  %_0.0 = extractvalue { ptr, i64 } %6, 0
  %_0.1 = extractvalue { ptr, i64 } %6, 1
  %7 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %_0.1, 1
  ret { ptr, i64 } %8
}

; alloc::raw_vec::layout_array::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0Cs4mnquxVp34G_6errors() unnamed_addr #0 !guid !392 {
start:
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %0 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs4mnquxVp34G_6errors(i64 0, i64 undef, ptr align 8 @alloc_84e24ad25dfa3f90d9808e22947b437c) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB4_5CharsNtNtNtNtB8_4iter6traits8iterator8Iterator4next0Cs4mnquxVp34G_6errors(i32 %ch) unnamed_addr #0 !guid !393 {
start:
; call <char>::from_u32_unchecked
  %_0 = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc18from_u32_uncheckedCs4mnquxVp34G_6errors(i32 %ch) #25
  ret i32 %_0
}

; <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvXs0_NtNtCsl10jNU3mE6R_4core3str4iterNtB7_5CharsNtNtNtNtBb_4iter6traits12double_ended19DoubleEndedIterator9next_back0Cs4mnquxVp34G_6errors(i32 %ch) unnamed_addr #0 !guid !394 {
start:
; call <char>::from_u32_unchecked
  %_0 = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc18from_u32_uncheckedCs4mnquxVp34G_6errors(i32 %ch) #25
  ret i32 %_0
}

; <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RNCNvXs4_NtNtCsl10jNU3mE6R_4core3str4iterNtB7_11CharIndicesNtNtNtNtBb_4iter6traits12double_ended19DoubleEndedIterator9next_back0Cs4mnquxVp34G_6errors(ptr align 8 %_1.0, ptr align 8 %_1.1, i32 %ch) unnamed_addr #0 !guid !395 {
start:
  %_0.i = alloca [8 x i8], align 8
  %_4 = load i64, ptr %_1.0, align 8
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 8
  %_5.i = load ptr, ptr %0, align 8
  %_6.i = load ptr, ptr %_1.1, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %_5.i, ptr %_6.i) #25
  store i64 %1, ptr %_0.i, align 8
  %2 = load i64, ptr %_0.i, align 8
  %index = add i64 %_4, %2
  %3 = insertvalue { i64, i32 } poison, i64 %index, 0
  %4 = insertvalue { i64, i32 } %3, i32 %ch, 1
  ret { i64, i32 } %4
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs4mnquxVp34G_6errors(ptr %_1) unnamed_addr #0 !guid !396 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4mnquxVp34G_6errors(ptr %0) #25
  ret i32 %_0
}

; errors::opt
; Function Attrs: nonlazybind uwtable
define internal { i32, i32 } @_RNvCs4mnquxVp34G_6errors3opt(ptr align 4 %v.0, i64 %v.1) unnamed_addr #1 !guid !397 {
start:
  %_6 = alloca [8 x i8], align 8
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <[i32]>::get::<usize>
  %_3 = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl3getjECs4mnquxVp34G_6errors(ptr align 4 %v.0, i64 %v.1, i64 0) #25
; call <core::option::Option<&i32> as core::ops::try_trait::Try>::branch
  %0 = call align 4 ptr @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRlENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr align 4 %_3) #25
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_4 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb5, label %bb4

bb5:                                              ; preds = %start
; call <core::option::Option<i32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  %5 = call { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4mnquxVp34G_6errors() #25
  %6 = extractvalue { i32, i32 } %5, 0
  %7 = extractvalue { i32, i32 } %5, 1
  store i32 %6, ptr %_0, align 4
  %8 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %7, ptr %8, align 4
  br label %bb10

bb4:                                              ; preds = %start
  %a = load ptr, ptr %_2, align 8
; call <[i32]>::get::<usize>
  %_7 = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl3getjECs4mnquxVp34G_6errors(ptr align 4 %v.0, i64 %v.1, i64 1) #25
; call <core::option::Option<&i32> as core::ops::try_trait::Try>::branch
  %9 = call align 4 ptr @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRlENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr align 4 %_7) #25
  store ptr %9, ptr %_6, align 8
  %10 = load ptr, ptr %_6, align 8
  %11 = ptrtoint ptr %10 to i64
  %12 = icmp eq i64 %11, 0
  %_8 = select i1 %12, i64 1, i64 0
  %13 = trunc nuw i64 %_8 to i1
  br i1 %13, label %bb9, label %bb8

bb9:                                              ; preds = %bb4
; call <core::option::Option<i32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  %14 = call { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4mnquxVp34G_6errors() #25
  %15 = extractvalue { i32, i32 } %14, 0
  %16 = extractvalue { i32, i32 } %14, 1
  store i32 %15, ptr %_0, align 4
  %17 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %16, ptr %17, align 4
  br label %bb10

bb8:                                              ; preds = %bb4
  %b = load ptr, ptr %_6, align 8
  %_10 = load i32, ptr %a, align 4
  %_11 = load i32, ptr %b, align 4
; call <i32>::checked_add
  %18 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCs4mnquxVp34G_6errors(i32 %_10, i32 %_11) #25
  %19 = extractvalue { i32, i32 } %18, 0
  %20 = extractvalue { i32, i32 } %18, 1
  store i32 %19, ptr %_0, align 4
  %21 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %20, ptr %21, align 4
  br label %bb10

bb10:                                             ; preds = %bb5, %bb9, %bb8
  %22 = load i32, ptr %_0, align 4
  %23 = getelementptr inbounds i8, ptr %_0, i64 4
  %24 = load i32, ptr %23, align 4
  %25 = insertvalue { i32, i32 } poison, i32 %22, 0
  %26 = insertvalue { i32, i32 } %25, i32 %24, 1
  ret { i32, i32 } %26

bb3:                                              ; No predecessors!
  unreachable
}

; errors::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs4mnquxVp34G_6errors4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !398 {
start:
  %0 = alloca [24 x i8], align 8
  %1 = alloca [16 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_251 = alloca [24 x i8], align 8
  %_250 = alloca [24 x i8], align 8
  %_243 = alloca [16 x i8], align 8
  %_242 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_239 = alloca [24 x i8], align 8
  %e21 = alloca [16 x i8], align 8
  %_230 = alloca [16 x i8], align 8
  %_229 = alloca [16 x i8], align 8
  %args20 = alloca [32 x i8], align 8
  %_227 = alloca [16 x i8], align 8
  %_226 = alloca [4 x i8], align 4
  %_223 = alloca [16 x i8], align 8
  %_222 = alloca [4 x i8], align 4
  %_215 = alloca [16 x i8], align 8
  %_214 = alloca [16 x i8], align 8
  %args19 = alloca [32 x i8], align 8
  %_210 = alloca [8 x i8], align 4
  %_207 = alloca [8 x i8], align 4
  %_200 = alloca [16 x i8], align 8
  %args18 = alloca [16 x i8], align 8
  %_197 = alloca [16 x i8], align 8
  %_196 = alloca [16 x i8], align 8
  %_189 = alloca [16 x i8], align 8
  %_188 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_185 = alloca [8 x i8], align 8
  %_182 = alloca [8 x i8], align 8
  %_177 = alloca [32 x i8], align 8
  %_176 = alloca [48 x i8], align 8
  %errs = alloca [24 x i8], align 8
  %oks = alloca [24 x i8], align 8
  %_173 = alloca [24 x i8], align 8
  %_171 = alloca [24 x i8], align 8
  %_170 = alloca [24 x i8], align 8
  %_169 = alloca [24 x i8], align 8
  %_168 = alloca [8 x i8], align 8
  %results = alloca [24 x i8], align 8
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_159 = alloca [1 x i8], align 1
  %_156 = alloca [1 x i8], align 1
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_145 = alloca [16 x i8], align 8
  %_142 = alloca [2 x i8], align 1
  %_135 = alloca [16 x i8], align 8
  %args14 = alloca [16 x i8], align 8
  %r13 = alloca [2 x i8], align 1
  %_125 = alloca [16 x i8], align 8
  %args12 = alloca [16 x i8], align 8
  %r = alloca [2 x i8], align 1
  %_115 = alloca [16 x i8], align 8
  %_114 = alloca [16 x i8], align 8
  %_113 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_109 = alloca [8 x i8], align 4
  %_105 = alloca [8 x i8], align 4
  %_101 = alloca [8 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_94 = alloca [16 x i8], align 8
  %args9 = alloca [16 x i8], align 8
  %e8 = alloca [16 x i8], align 8
  %_85 = alloca [16 x i8], align 8
  %args7 = alloca [16 x i8], align 8
  %n6 = alloca [1 x i8], align 1
  %_77 = alloca [16 x i8], align 8
  %_73 = alloca [16 x i8], align 8
  %iter5 = alloca [80 x i8], align 8
  %_68 = alloca [64 x i8], align 8
  %_67 = alloca [80 x i8], align 8
  %_64 = alloca [16 x i8], align 8
  %args4 = alloca [16 x i8], align 8
  %_60 = alloca [24 x i8], align 8
  %_59 = alloca [24 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %args3 = alloca [16 x i8], align 8
  %_48 = alloca [24 x i8], align 8
  %_47 = alloca [24 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_39 = alloca [16 x i8], align 8
  %_38 = alloca [16 x i8], align 8
  %args2 = alloca [48 x i8], align 8
  %_35 = alloca [16 x i8], align 8
  %_33 = alloca [1 x i8], align 1
  %args1 = alloca [24 x i8], align 8
  %e = alloca [24 x i8], align 8
  %_23 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %n = alloca [8 x i8], align 8
  %_14 = alloca [24 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %iter = alloca [128 x i8], align 8
  %_2 = alloca [112 x i8], align 8
  %_1 = alloca [128 x i8], align 8
  %2 = getelementptr inbounds nuw { ptr, i64 }, ptr %_2, i64 0
  store ptr @alloc_4cca07c46305327e56b5abbe1b5e418e, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 2, ptr %3, align 8
  %4 = getelementptr inbounds nuw { ptr, i64 }, ptr %_2, i64 1
  store ptr @alloc_886f8a5a1647e138943f6947c0f633ae, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 3, ptr %5, align 8
  %6 = getelementptr inbounds nuw { ptr, i64 }, ptr %_2, i64 2
  store ptr @alloc_c8757baa1183d531e5d1480832ff8cd8, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 2, ptr %7, align 8
  %8 = getelementptr inbounds nuw { ptr, i64 }, ptr %_2, i64 3
  store ptr @alloc_13af184f83ea529683dab3456027e412, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 3, ptr %9, align 8
  %10 = getelementptr inbounds nuw { ptr, i64 }, ptr %_2, i64 4
  store ptr inttoptr (i64 1 to ptr), ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 0, ptr %11, align 8
  %12 = getelementptr inbounds nuw { ptr, i64 }, ptr %_2, i64 5
  store ptr @alloc_f1409953d2233536262a5d1f184787d5, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 8
  store i64 20, ptr %13, align 8
  %14 = getelementptr inbounds nuw { ptr, i64 }, ptr %_2, i64 6
  store ptr @alloc_1419a03891514d90c88076e7bb0fcaa5, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %14, i64 8
  store i64 2, ptr %15, align 8
; call <[&str; 7] as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARej7_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs4mnquxVp34G_6errors(ptr sret([128 x i8]) align 8 %_1, ptr align 8 %_2) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter, ptr align 8 %_1, i64 128, i1 false)
  br label %bb2

bb2:                                              ; preds = %bb19, %bb134, %start
; invoke <core::array::iter::IntoIter<&str, 7> as core::iter::traits::iterator::Iterator>::next
  %16 = invoke { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj7_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %iter)
          to label %bb3 unwind label %cleanup

bb130:                                            ; preds = %bb129, %cleanup
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<&str, 7>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterReKj7_EECs4mnquxVp34G_6errors(ptr align 8 %iter) #23
          to label %bb131 unwind label %terminate

cleanup:                                          ; preds = %bb19, %bb12, %bb11, %bb10, %bb7, %bb5, %bb2
  %17 = landingpad { ptr, i32 }
          cleanup
  %18 = extractvalue { ptr, i32 } %17, 0
  %19 = extractvalue { ptr, i32 } %17, 1
  store ptr %18, ptr %1, align 8
  %20 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %19, ptr %20, align 8
  br label %bb130

bb3:                                              ; preds = %bb2
  %21 = extractvalue { ptr, i64 } %16, 0
  %22 = extractvalue { ptr, i64 } %16, 1
  store ptr %21, ptr %_10, align 8
  %23 = getelementptr inbounds i8, ptr %_10, i64 8
  store i64 %22, ptr %23, align 8
  %24 = load ptr, ptr %_10, align 8
  %25 = getelementptr inbounds i8, ptr %_10, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = ptrtoint ptr %24 to i64
  %28 = icmp eq i64 %27, 0
  %_12 = select i1 %28, i64 0, i64 1
  %29 = trunc nuw i64 %_12 to i1
  br i1 %29, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %s.035 = load ptr, ptr %_10, align 8
  %30 = getelementptr inbounds i8, ptr %_10, i64 8
  %s.136 = load i64, ptr %30, align 8
; invoke core::hint::black_box::<&str>
  %31 = invoke { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxReECs4mnquxVp34G_6errors(ptr %s.035, i64 %s.136)
          to label %bb7 unwind label %cleanup

bb6:                                              ; preds = %bb3
; call core::ptr::drop_glue::<core::array::iter::IntoIter<&str, 7>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterReKj7_EECs4mnquxVp34G_6errors(ptr align 8 %iter)
; call errors::sum_all
  call void @_RNvCs4mnquxVp34G_6errors7sum_all(ptr sret([24 x i8]) align 8 %_48, ptr align 8 @alloc_f2e1a0544e0e3261362adc50b75d6b0a, i64 3)
; call <core::result::Result<i64, errors::AppError>>::map_err::<alloc::string::String, errors::main::{closure#1}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultxNtCs4mnquxVp34G_6errors8AppErrorE7map_errNtNtCs7CppTae75M1_5alloc6string6StringNCNvBL_4mains_0EBL_(ptr sret([24 x i8]) align 8 %_47, ptr align 8 %_48) #25
; invoke <core::fmt::rt::Argument>::new_debug::<core::result::Result<i64, alloc::string::String>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_52, ptr align 8 %_47)
          to label %bb23 unwind label %cleanup24

bb128:                                            ; preds = %cleanup24
; invoke core::ptr::drop_glue::<core::result::Result<i64, alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_47) #23
          to label %bb131 unwind label %terminate

cleanup24:                                        ; preds = %bb24, %bb23, %bb6
  %32 = landingpad { ptr, i32 }
          cleanup
  %33 = extractvalue { ptr, i32 } %32, 0
  %34 = extractvalue { ptr, i32 } %32, 1
  store ptr %33, ptr %1, align 8
  %35 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %34, ptr %35, align 8
  br label %bb128

bb23:                                             ; preds = %bb6
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_52, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %37 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args3)
          to label %bb24 unwind label %cleanup24

bb24:                                             ; preds = %bb23
  %_44.0 = extractvalue { ptr, ptr } %37, 0
  %_44.1 = extractvalue { ptr, ptr } %37, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_44.0, ptr %_44.1)
          to label %bb25 unwind label %cleanup24

bb25:                                             ; preds = %bb24
; call core::ptr::drop_glue::<core::result::Result<i64, alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_47)
; call errors::sum_all
  call void @_RNvCs4mnquxVp34G_6errors7sum_all(ptr sret([24 x i8]) align 8 %_60, ptr align 8 @alloc_24a105619a71ab434fb7a61711b3754a, i64 2)
; call <core::result::Result<i64, errors::AppError>>::map_err::<alloc::string::String, errors::main::{closure#2}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultxNtCs4mnquxVp34G_6errors8AppErrorE7map_errNtNtCs7CppTae75M1_5alloc6string6StringNCNvBL_4mains0_0EBL_(ptr sret([24 x i8]) align 8 %_59, ptr align 8 %_60) #25
; invoke <core::fmt::rt::Argument>::new_debug::<core::result::Result<i64, alloc::string::String>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_64, ptr align 8 %_59)
          to label %bb29 unwind label %cleanup25

bb127:                                            ; preds = %cleanup25
; invoke core::ptr::drop_glue::<core::result::Result<i64, alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_59) #23
          to label %bb131 unwind label %terminate

cleanup25:                                        ; preds = %bb30, %bb29, %bb25
  %38 = landingpad { ptr, i32 }
          cleanup
  %39 = extractvalue { ptr, i32 } %38, 0
  %40 = extractvalue { ptr, i32 } %38, 1
  store ptr %39, ptr %1, align 8
  %41 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %40, ptr %41, align 8
  br label %bb127

bb29:                                             ; preds = %bb25
  %42 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %42, ptr align 8 %_64, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %43 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args4)
          to label %bb30 unwind label %cleanup25

bb30:                                             ; preds = %bb29
  %_56.0 = extractvalue { ptr, ptr } %43, 0
  %_56.1 = extractvalue { ptr, ptr } %43, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_56.0, ptr %_56.1)
          to label %bb31 unwind label %cleanup25

bb31:                                             ; preds = %bb30
; call core::ptr::drop_glue::<core::result::Result<i64, alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_59)
  %44 = getelementptr inbounds nuw { ptr, i64 }, ptr %_68, i64 0
  store ptr @alloc_e8bed5fc7baf93aaf2aece520080d503, ptr %44, align 8
  %45 = getelementptr inbounds i8, ptr %44, i64 8
  store i64 3, ptr %45, align 8
  %46 = getelementptr inbounds nuw { ptr, i64 }, ptr %_68, i64 1
  store ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, ptr %46, align 8
  %47 = getelementptr inbounds i8, ptr %46, i64 8
  store i64 3, ptr %47, align 8
  %48 = getelementptr inbounds nuw { ptr, i64 }, ptr %_68, i64 2
  store ptr @alloc_24b05860d599286ecb26af7d40c66ae9, ptr %48, align 8
  %49 = getelementptr inbounds i8, ptr %48, i64 8
  store i64 2, ptr %49, align 8
  %50 = getelementptr inbounds nuw { ptr, i64 }, ptr %_68, i64 3
  store ptr @alloc_e7dcb7344fc37504b9418c11c4a9d98f, ptr %50, align 8
  %51 = getelementptr inbounds i8, ptr %50, i64 8
  store i64 1, ptr %51, align 8
; call <[&str; 4] as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARej4_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs4mnquxVp34G_6errors(ptr sret([80 x i8]) align 8 %_67, ptr align 8 %_68) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter5, ptr align 8 %_67, i64 80, i1 false)
  br label %bb34

bb34:                                             ; preds = %bb45, %bb135, %bb31
; invoke <core::array::iter::IntoIter<&str, 4> as core::iter::traits::iterator::Iterator>::next
  %52 = invoke { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj4_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %iter5)
          to label %bb35 unwind label %cleanup26

bb126:                                            ; preds = %bb125, %cleanup26
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<&str, 4>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterReKj4_EECs4mnquxVp34G_6errors(ptr align 8 %iter5) #23
          to label %bb131 unwind label %terminate

cleanup26:                                        ; preds = %bb45, %bb42, %bb41, %bb40, %bb36, %bb34
  %53 = landingpad { ptr, i32 }
          cleanup
  %54 = extractvalue { ptr, i32 } %53, 0
  %55 = extractvalue { ptr, i32 } %53, 1
  store ptr %54, ptr %1, align 8
  %56 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %55, ptr %56, align 8
  br label %bb126

bb35:                                             ; preds = %bb34
  %57 = extractvalue { ptr, i64 } %52, 0
  %58 = extractvalue { ptr, i64 } %52, 1
  store ptr %57, ptr %_73, align 8
  %59 = getelementptr inbounds i8, ptr %_73, i64 8
  store i64 %58, ptr %59, align 8
  %60 = load ptr, ptr %_73, align 8
  %61 = getelementptr inbounds i8, ptr %_73, i64 8
  %62 = load i64, ptr %61, align 8
  %63 = ptrtoint ptr %60 to i64
  %64 = icmp eq i64 %63, 0
  %_75 = select i1 %64, i64 0, i64 1
  %65 = trunc nuw i64 %_75 to i1
  br i1 %65, label %bb36, label %bb37

bb36:                                             ; preds = %bb35
  %s.0 = load ptr, ptr %_73, align 8
  %66 = getelementptr inbounds i8, ptr %_73, i64 8
  %s.1 = load i64, ptr %66, align 8
; invoke errors::dynerr
  invoke void @_RNvCs4mnquxVp34G_6errors6dynerr(ptr sret([16 x i8]) align 8 %_77, ptr %s.0, i64 %s.1)
          to label %bb38 unwind label %cleanup26

bb37:                                             ; preds = %bb35
; call core::ptr::drop_glue::<core::array::iter::IntoIter<&str, 4>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterReKj4_EECs4mnquxVp34G_6errors(ptr align 8 %iter5)
; call errors::opt
  %67 = call { i32, i32 } @_RNvCs4mnquxVp34G_6errors3opt(ptr align 4 @alloc_fee8f9451f4957e1f9c91846d5d186b4, i64 2)
  %68 = extractvalue { i32, i32 } %67, 0
  %69 = extractvalue { i32, i32 } %67, 1
  store i32 %68, ptr %_101, align 4
  %70 = getelementptr inbounds i8, ptr %_101, i64 4
  store i32 %69, ptr %70, align 4
; call errors::opt
  %71 = call { i32, i32 } @_RNvCs4mnquxVp34G_6errors3opt(ptr align 4 @alloc_66e0d902dc5512250b9d4edb026cbbeb, i64 1)
  %72 = extractvalue { i32, i32 } %71, 0
  %73 = extractvalue { i32, i32 } %71, 1
  store i32 %72, ptr %_105, align 4
  %74 = getelementptr inbounds i8, ptr %_105, i64 4
  store i32 %73, ptr %74, align 4
; call errors::opt
  %75 = call { i32, i32 } @_RNvCs4mnquxVp34G_6errors3opt(ptr align 4 @alloc_7dad102c4c3f0cd63ff654fb619efe59, i64 2)
  %76 = extractvalue { i32, i32 } %75, 0
  %77 = extractvalue { i32, i32 } %75, 1
  store i32 %76, ptr %_109, align 4
  %78 = getelementptr inbounds i8, ptr %_109, i64 4
  store i32 %77, ptr %78, align 4
  store ptr %_101, ptr %args10, align 8
  %79 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_105, ptr %79, align 8
  %80 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_109, ptr %80, align 8
  %_265 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_113, ptr align 4 %_265) #25
  %81 = getelementptr inbounds i8, ptr %args10, i64 8
  %_266 = load ptr, ptr %81, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_114, ptr align 4 %_266) #25
  %82 = getelementptr inbounds i8, ptr %args10, i64 16
  %_267 = load ptr, ptr %82, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_115, ptr align 4 %_267) #25
  %83 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %83, ptr align 8 %_113, i64 16, i1 false)
  %84 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %84, ptr align 8 %_114, i64 16, i1 false)
  %85 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %85, ptr align 8 %_115, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %86 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs4mnquxVp34G_6errors(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #25
  %_98.0 = extractvalue { ptr, ptr } %86, 0
  %_98.1 = extractvalue { ptr, ptr } %86, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_98.0, ptr %_98.1)
; call <str>::parse::<u8>
  %87 = call { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parsehECs4mnquxVp34G_6errors(ptr @alloc_7128d5fa802b3d26a0e0642ece79c82a, i64 3) #25
  %88 = extractvalue { i1, i8 } %87, 0
  %89 = extractvalue { i1, i8 } %87, 1
  %90 = zext i1 %88 to i8
  store i8 %90, ptr %r, align 1
  %91 = getelementptr inbounds i8, ptr %r, i64 1
  store i8 %89, ptr %91, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<u8, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResulthNtNtNtB7_3num5error13ParseIntErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_125, ptr %r) #25
  %92 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %92, ptr align 8 %_125, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %93 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args12) #25
  %_121.0 = extractvalue { ptr, ptr } %93, 0
  %_121.1 = extractvalue { ptr, ptr } %93, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_121.0, ptr %_121.1)
; call <str>::parse::<i8>
  %94 = call { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parseaECs4mnquxVp34G_6errors(ptr @alloc_100177961406f1edbf7781ce01130f24, i64 4) #25
  %95 = extractvalue { i1, i8 } %94, 0
  %96 = extractvalue { i1, i8 } %94, 1
  %97 = zext i1 %95 to i8
  store i8 %97, ptr %r13, align 1
  %98 = getelementptr inbounds i8, ptr %r13, i64 1
  store i8 %96, ptr %98, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i8, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultaNtNtNtB7_3num5error13ParseIntErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_135, ptr %r13) #25
  %99 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %99, ptr align 8 %_135, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %100 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args14) #25
  %_131.0 = extractvalue { ptr, ptr } %100, 0
  %_131.1 = extractvalue { ptr, ptr } %100, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_131.0, ptr %_131.1)
; call <str>::parse::<u8>
  %101 = call { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parsehECs4mnquxVp34G_6errors(ptr inttoptr (i64 1 to ptr), i64 0) #25
  %102 = extractvalue { i1, i8 } %101, 0
  %103 = extractvalue { i1, i8 } %101, 1
  %104 = zext i1 %102 to i8
  store i8 %104, ptr %_142, align 1
  %105 = getelementptr inbounds i8, ptr %_142, i64 1
  store i8 %103, ptr %105, align 1
; call <str>::parse::<f64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_145, ptr @alloc_0d1918786fa78d9d4e3016c27bbb890c, i64 3) #25
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<u8, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResulthNtNtNtB7_3num5error13ParseIntErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_148, ptr %_142) #25
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<f64, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_149, ptr align 8 %_145) #25
  %106 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %106, ptr align 8 %_148, i64 16, i1 false)
  %107 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %108 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs4mnquxVp34G_6errors(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #25
  %_139.0 = extractvalue { ptr, ptr } %108, 0
  %_139.1 = extractvalue { ptr, ptr } %108, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_139.0, ptr %_139.1)
; call <str>::parse::<bool>
  %109 = call i8 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsebECs4mnquxVp34G_6errors(ptr @alloc_361af4a0a0c07a42d46a4e093e4a894b, i64 3) #25
  store i8 %109, ptr %_156, align 1
; call <str>::parse::<bool>
  %110 = call i8 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsebECs4mnquxVp34G_6errors(ptr @alloc_c9ee9951a160df092319190fa06505e4, i64 4) #25
  store i8 %110, ptr %_159, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<bool, core::str::error::ParseBoolError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultbNtNtNtB7_3str5error14ParseBoolErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_162, ptr %_156) #25
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<bool, core::str::error::ParseBoolError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultbNtNtNtB7_3str5error14ParseBoolErrorEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_163, ptr %_159) #25
  %111 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %111, ptr align 8 %_162, i64 16, i1 false)
  %112 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %112, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %113 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs4mnquxVp34G_6errors(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #25
  %_153.0 = extractvalue { ptr, ptr } %113, 0
  %_153.1 = extractvalue { ptr, ptr } %113, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
; call alloc::boxed::box_new_uninit
  %_1.i = call align 8 ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs4mnquxVp34G_6errors(i64 8, i64 72) #25
  store ptr %_1.i, ptr %_168, align 8
  %114 = getelementptr inbounds i8, ptr %_169, i64 8
  store i32 1, ptr %114, align 8
  store i64 -1, ptr %_169, align 8
; invoke <&str as core::convert::Into<alloc::string::String>>::into
  invoke void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_171, ptr @alloc_8d07294c609ce7096eac9b5042193909, i64 3, ptr align 8 @alloc_279256bde0e1d7f7c597641fe0c13aca)
          to label %bb76 unwind label %cleanup27

bb123:                                            ; preds = %cleanup27
; invoke core::ptr::drop_glue::<core::result::Result<i32, alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_169) #23
          to label %bb124 unwind label %terminate

cleanup27:                                        ; preds = %bb37
  %115 = landingpad { ptr, i32 }
          cleanup
  %116 = extractvalue { ptr, i32 } %115, 0
  %117 = extractvalue { ptr, i32 } %115, 1
  store ptr %116, ptr %1, align 8
  %118 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %117, ptr %118, align 8
  br label %bb123

bb76:                                             ; preds = %bb37
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_170, ptr align 8 %_171, i64 24, i1 false)
  %119 = getelementptr inbounds i8, ptr %_173, i64 8
  store i32 3, ptr %119, align 8
  store i64 -1, ptr %_173, align 8
  %_284 = load ptr, ptr %_168, align 8
  %_286 = ptrtoint ptr %_284 to i64
  %_288 = and i64 %_286, 7
  %_289 = icmp eq i64 %_288, 0
  br i1 %_289, label %bb132, label %panic

bb132:                                            ; preds = %bb76
  %_291 = ptrtoint ptr %_284 to i64
  %_293 = icmp eq i64 %_291, 0
  %_294 = and i1 %_293, true
  %_295 = xor i1 %_294, true
  br i1 %_295, label %bb133, label %panic28

panic:                                            ; preds = %bb76
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_286, ptr align 8 @alloc_c09dc8b7a4b0a680bfb1277db7e949ff) #30
  unreachable

bb133:                                            ; preds = %bb132
  %120 = getelementptr inbounds nuw %"core::result::Result<i32, alloc::string::String>", ptr %_284, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %120, ptr align 8 %_169, i64 24, i1 false)
  %121 = getelementptr inbounds nuw %"core::result::Result<i32, alloc::string::String>", ptr %_284, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %121, ptr align 8 %_170, i64 24, i1 false)
  %122 = getelementptr inbounds nuw %"core::result::Result<i32, alloc::string::String>", ptr %_284, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %122, ptr align 8 %_173, i64 24, i1 false)
  %_167 = load ptr, ptr %_168, align 8
; call <[core::result::Result<i32, alloc::string::String>]>::into_vec::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB5_6string6StringE8into_vecNtNtB5_5alloc6GlobalECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %results, ptr align 8 %_167, i64 3) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %results, i64 24, i1 false)
; call <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXsg_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtNtNtBK_4iter6traits7collect12IntoIterator9into_iterCs4mnquxVp34G_6errors(ptr sret([32 x i8]) align 8 %_177, ptr align 8 %0) #25
; call <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::iterator::Iterator>::partition::<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>, errors::main::{closure#0}>
  call void @_RINvYINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtBa_6string6StringEENtNtNtNtBW_4iter6traits8iterator8Iterator9partitionINtB8_3VecBR_ENCNvCs4mnquxVp34G_6errors4main0EB2Y_(ptr sret([48 x i8]) align 8 %_176, ptr align 8 %_177)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %oks, ptr align 8 %_176, i64 24, i1 false)
  %123 = getelementptr inbounds i8, ptr %_176, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %errs, ptr align 8 %123, i64 24, i1 false)
; invoke <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::len
  %124 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE3lenCs4mnquxVp34G_6errors(ptr align 8 %oks)
          to label %bb80 unwind label %cleanup29

panic28:                                          ; preds = %bb132
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_c09dc8b7a4b0a680bfb1277db7e949ff) #30
  unreachable

bb121:                                            ; preds = %bb120, %cleanup29
; invoke core::ptr::drop_glue::<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %errs) #23
          to label %bb122 unwind label %terminate

cleanup29:                                        ; preds = %bb114, %bb102, %bb101, %bb100, %bb99, %bb98, %bb97, %bb96, %bb95, %bb94, %bb93, %bb92, %bb91, %bb90, %bb89, %bb88, %bb87, %bb86, %bb85, %bb84, %bb83, %bb82, %bb81, %bb80, %bb133
  %125 = landingpad { ptr, i32 }
          cleanup
  %126 = extractvalue { ptr, i32 } %125, 0
  %127 = extractvalue { ptr, i32 } %125, 1
  store ptr %126, ptr %1, align 8
  %128 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %127, ptr %128, align 8
  br label %bb121

bb80:                                             ; preds = %bb133
  store i64 %124, ptr %_182, align 8
; invoke <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::len
  %129 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE3lenCs4mnquxVp34G_6errors(ptr align 8 %errs)
          to label %bb81 unwind label %cleanup29

bb81:                                             ; preds = %bb80
  store i64 %129, ptr %_185, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_188, ptr align 8 %_182)
          to label %bb82 unwind label %cleanup29

bb82:                                             ; preds = %bb81
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_189, ptr align 8 %_185)
          to label %bb83 unwind label %cleanup29

bb83:                                             ; preds = %bb82
  %130 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %130, ptr align 8 %_188, i64 16, i1 false)
  %131 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %131, ptr align 8 %_189, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %132 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs4mnquxVp34G_6errors(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17)
          to label %bb84 unwind label %cleanup29

bb84:                                             ; preds = %bb83
  %_179.0 = extractvalue { ptr, ptr } %132, 0
  %_179.1 = extractvalue { ptr, ptr } %132, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_179.0, ptr %_179.1)
          to label %bb85 unwind label %cleanup29

bb85:                                             ; preds = %bb84
; invoke <core::option::Option<i32>>::ok_or::<&str>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionlE5ok_orReECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_197, i32 1, i32 3, ptr @alloc_890cb1a408d0b866810322ffa0505985, i64 4)
          to label %bb86 unwind label %cleanup29

bb86:                                             ; preds = %bb85
; invoke <core::result::Result<i32, &str>>::and_then::<i32, errors::main::{closure#3}>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultlReE8and_thenlNCNvCs4mnquxVp34G_6errors4mains1_0EB10_(ptr sret([16 x i8]) align 8 %_196, ptr align 8 %_197)
          to label %bb87 unwind label %cleanup29

bb87:                                             ; preds = %bb86
; invoke <core::fmt::rt::Argument>::new_debug::<core::result::Result<i32, &str>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultlReEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_200, ptr align 8 %_196)
          to label %bb88 unwind label %cleanup29

bb88:                                             ; preds = %bb87
  %133 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %133, ptr align 8 %_200, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %134 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args18)
          to label %bb89 unwind label %cleanup29

bb89:                                             ; preds = %bb88
  %_193.0 = extractvalue { ptr, ptr } %134, 0
  %_193.1 = extractvalue { ptr, ptr } %134, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_193.0, ptr %_193.1)
          to label %bb90 unwind label %cleanup29

bb90:                                             ; preds = %bb89
; invoke <core::option::Option<i32>>::filter::<errors::main::{closure#4}>
  %135 = invoke { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionlE6filterNCNvCs4mnquxVp34G_6errors4mains2_0EBV_(i32 1, i32 4)
          to label %bb91 unwind label %cleanup29

bb91:                                             ; preds = %bb90
  %136 = extractvalue { i32, i32 } %135, 0
  %137 = extractvalue { i32, i32 } %135, 1
  store i32 %136, ptr %_207, align 4
  %138 = getelementptr inbounds i8, ptr %_207, i64 4
  store i32 %137, ptr %138, align 4
; invoke <core::option::Option<i32>>::xor
  %139 = invoke { i32, i32 } @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE3xorCs4mnquxVp34G_6errors(i32 1, i32 2, i32 0, i32 undef)
          to label %bb92 unwind label %cleanup29

bb92:                                             ; preds = %bb91
  %140 = extractvalue { i32, i32 } %139, 0
  %141 = extractvalue { i32, i32 } %139, 1
  store i32 %140, ptr %_210, align 4
  %142 = getelementptr inbounds i8, ptr %_210, i64 4
  store i32 %141, ptr %142, align 4
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_214, ptr align 4 %_207)
          to label %bb93 unwind label %cleanup29

bb93:                                             ; preds = %bb92
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_215, ptr align 4 %_210)
          to label %bb94 unwind label %cleanup29

bb94:                                             ; preds = %bb93
  %143 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args19, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %143, ptr align 8 %_214, i64 16, i1 false)
  %144 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args19, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %144, ptr align 8 %_215, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %145 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs4mnquxVp34G_6errors(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args19)
          to label %bb95 unwind label %cleanup29

bb95:                                             ; preds = %bb94
  %_204.0 = extractvalue { ptr, ptr } %145, 0
  %_204.1 = extractvalue { ptr, ptr } %145, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_204.0, ptr %_204.1)
          to label %bb96 unwind label %cleanup29

bb96:                                             ; preds = %bb95
  store ptr @alloc_c1fa64f4e819a506b7859bc956f830ca, ptr %_223, align 8
  %146 = getelementptr inbounds i8, ptr %_223, i64 8
  store i64 1, ptr %146, align 8
; invoke <core::result::Result<i32, &str>>::unwrap_or_default
  %147 = invoke i32 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlReE17unwrap_or_defaultCs4mnquxVp34G_6errors(ptr align 8 %_223)
          to label %bb97 unwind label %cleanup29

bb97:                                             ; preds = %bb96
  store i32 %147, ptr %_222, align 4
  %148 = getelementptr inbounds i8, ptr %_227, i64 8
  store i32 5, ptr %148, align 8
  store ptr null, ptr %_227, align 8
; invoke <core::result::Result<i32, &str>>::map_or::<i32, errors::main::{closure#5}>
  %149 = invoke i32 @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultlReE6map_orlNCNvCs4mnquxVp34G_6errors4mains3_0EBY_(ptr align 8 %_227, i32 0)
          to label %bb98 unwind label %cleanup29

bb98:                                             ; preds = %bb97
  store i32 %149, ptr %_226, align 4
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_229, ptr align 4 %_222)
          to label %bb99 unwind label %cleanup29

bb99:                                             ; preds = %bb98
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_230, ptr align 4 %_226)
          to label %bb100 unwind label %cleanup29

bb100:                                            ; preds = %bb99
  %150 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %150, ptr align 8 %_229, i64 16, i1 false)
  %151 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %151, ptr align 8 %_230, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %152 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs4mnquxVp34G_6errors(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args20)
          to label %bb101 unwind label %cleanup29

bb101:                                            ; preds = %bb100
  %_219.0 = extractvalue { ptr, ptr } %152, 0
  %_219.1 = extractvalue { ptr, ptr } %152, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_219.0, ptr %_219.1)
          to label %bb102 unwind label %cleanup29

bb102:                                            ; preds = %bb101
; invoke <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<&str>>::from
  %153 = invoke { ptr, ptr } @_RNvXsh_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBW_6marker4SyncNtB1t_4SendEL_EINtNtBW_7convert4FromReE4fromCs4mnquxVp34G_6errors(ptr @alloc_8edde9c1d7592734926bf33e2fe88b51, i64 13)
          to label %bb103 unwind label %cleanup29

bb103:                                            ; preds = %bb102
  %154 = extractvalue { ptr, ptr } %153, 0
  %155 = extractvalue { ptr, ptr } %153, 1
  store ptr %154, ptr %e21, align 8
  %156 = getelementptr inbounds i8, ptr %e21, i64 8
  store ptr %155, ptr %156, align 8
; invoke <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as alloc::string::ToString>::to_string
  invoke void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringINtNtB7_5boxed3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBV_6marker4SyncNtB1s_4SendEL_ENtB5_8ToString9to_stringCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_239, ptr align 8 %e21)
          to label %bb104 unwind label %cleanup30

bb120:                                            ; preds = %bb119, %bb118, %cleanup30
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1w_4SendEL_EECs4mnquxVp34G_6errors(ptr align 8 %e21) #23
          to label %bb121 unwind label %terminate

cleanup30:                                        ; preds = %bb113, %bb109, %bb108, %bb103
  %157 = landingpad { ptr, i32 }
          cleanup
  %158 = extractvalue { ptr, i32 } %157, 0
  %159 = extractvalue { ptr, i32 } %157, 1
  store ptr %158, ptr %1, align 8
  %160 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %159, ptr %160, align 8
  br label %bb120

bb104:                                            ; preds = %bb103
; invoke <core::fmt::rt::Argument>::new_display::<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorNtNtB7_6marker4SyncNtB1T_4SendEL_EECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_242, ptr align 8 %e21)
          to label %bb105 unwind label %cleanup31

bb119:                                            ; preds = %cleanup31
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr align 8 %_239) #23
          to label %bb120 unwind label %terminate

cleanup31:                                        ; preds = %bb107, %bb106, %bb105, %bb104
  %161 = landingpad { ptr, i32 }
          cleanup
  %162 = extractvalue { ptr, i32 } %161, 0
  %163 = extractvalue { ptr, i32 } %161, 1
  store ptr %162, ptr %1, align 8
  %164 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %163, ptr %164, align 8
  br label %bb119

bb105:                                            ; preds = %bb104
; invoke <core::fmt::rt::Argument>::new_debug::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_243, ptr align 8 %_239)
          to label %bb106 unwind label %cleanup31

bb106:                                            ; preds = %bb105
  %165 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %165, ptr align 8 %_242, i64 16, i1 false)
  %166 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %166, ptr align 8 %_243, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %167 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs4mnquxVp34G_6errors(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22)
          to label %bb107 unwind label %cleanup31

bb107:                                            ; preds = %bb106
  %_235.0 = extractvalue { ptr, ptr } %167, 0
  %_235.1 = extractvalue { ptr, ptr } %167, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_235.0, ptr %_235.1)
          to label %bb108 unwind label %cleanup31

bb108:                                            ; preds = %bb107
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr align 8 %_239)
          to label %bb109 unwind label %cleanup30

bb109:                                            ; preds = %bb108
; invoke <&str as core::convert::Into<alloc::string::String>>::into
  invoke void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_251, ptr @alloc_dde4797b035e3bd55cef1b113ab283ad, i64 4, ptr align 8 @alloc_a120c34eab250664aea21142790ac5ef)
          to label %bb110 unwind label %cleanup30

bb110:                                            ; preds = %bb109
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_250, ptr align 8 %_251, i64 24, i1 false)
; invoke <core::fmt::rt::Argument>::new_display::<errors::AppError>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCs4mnquxVp34G_6errors8AppErrorEB10_(ptr sret([16 x i8]) align 8 %_254, ptr align 8 %_250)
          to label %bb111 unwind label %cleanup32

bb118:                                            ; preds = %cleanup32
; invoke core::ptr::drop_glue::<errors::AppError>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %_250) #23
          to label %bb120 unwind label %terminate

cleanup32:                                        ; preds = %bb112, %bb111, %bb110
  %168 = landingpad { ptr, i32 }
          cleanup
  %169 = extractvalue { ptr, i32 } %168, 0
  %170 = extractvalue { ptr, i32 } %168, 1
  store ptr %169, ptr %1, align 8
  %171 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %170, ptr %171, align 8
  br label %bb118

bb111:                                            ; preds = %bb110
  %172 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %172, ptr align 8 %_254, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %173 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args23)
          to label %bb112 unwind label %cleanup32

bb112:                                            ; preds = %bb111
  %_247.0 = extractvalue { ptr, ptr } %173, 0
  %_247.1 = extractvalue { ptr, ptr } %173, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_247.0, ptr %_247.1)
          to label %bb113 unwind label %cleanup32

bb113:                                            ; preds = %bb112
; invoke core::ptr::drop_glue::<errors::AppError>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %_250)
          to label %bb114 unwind label %cleanup30

bb114:                                            ; preds = %bb113
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1w_4SendEL_EECs4mnquxVp34G_6errors(ptr align 8 %e21)
          to label %bb115 unwind label %cleanup29

bb115:                                            ; preds = %bb114
; invoke core::ptr::drop_glue::<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %errs)
          to label %bb116 unwind label %cleanup33

bb122:                                            ; preds = %bb121, %cleanup33
; invoke core::ptr::drop_glue::<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %oks) #23
          to label %bb131 unwind label %terminate

cleanup33:                                        ; preds = %bb115
  %174 = landingpad { ptr, i32 }
          cleanup
  %175 = extractvalue { ptr, i32 } %174, 0
  %176 = extractvalue { ptr, i32 } %174, 1
  store ptr %175, ptr %1, align 8
  %177 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %176, ptr %177, align 8
  br label %bb122

bb116:                                            ; preds = %bb115
; call core::ptr::drop_glue::<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %oks)
  ret void

terminate:                                        ; preds = %bb130, %bb129, %bb128, %bb127, %bb126, %bb125, %bb124, %bb123, %bb122, %bb121, %bb120, %bb119, %bb118
  %178 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb131:                                            ; preds = %bb130, %bb128, %bb127, %bb126, %bb124, %bb122
  %179 = load ptr, ptr %1, align 8
  %180 = getelementptr inbounds i8, ptr %1, i64 8
  %181 = load i32, ptr %180, align 8
  %182 = insertvalue { ptr, i32 } poison, ptr %179, 0
  %183 = insertvalue { ptr, i32 } %182, i32 %181, 1
  resume { ptr, i32 } %183

bb124:                                            ; preds = %bb123
; invoke core::ptr::drop_glue::<alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtNtB4_3mem12maybe_uninit11MaybeUninitAINtNtB4_6result6ResultlNtNtBG_6string6StringEj3_EEECs4mnquxVp34G_6errors(ptr align 8 %_168) #23
          to label %bb131 unwind label %terminate

bb38:                                             ; preds = %bb36
  %184 = load ptr, ptr %_77, align 8
  %185 = ptrtoint ptr %184 to i64
  %186 = icmp eq i64 %185, 0
  %_78 = select i1 %186, i64 0, i64 1
  %187 = trunc nuw i64 %_78 to i1
  br i1 %187, label %bb39, label %bb40

bb39:                                             ; preds = %bb38
  %188 = load ptr, ptr %_77, align 8
  %189 = getelementptr inbounds i8, ptr %_77, i64 8
  %190 = load ptr, ptr %189, align 8
  store ptr %188, ptr %e8, align 8
  %191 = getelementptr inbounds i8, ptr %e8, i64 8
  store ptr %190, ptr %191, align 8
; invoke <core::fmt::rt::Argument>::new_display::<alloc::boxed::Box<dyn core::error::Error>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_94, ptr align 8 %e8)
          to label %bb43 unwind label %cleanup34

bb40:                                             ; preds = %bb38
  %192 = getelementptr inbounds i8, ptr %_77, i64 8
  %193 = load i8, ptr %192, align 8
  store i8 %193, ptr %n6, align 1
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_85, ptr %n6)
          to label %bb41 unwind label %cleanup26

bb41:                                             ; preds = %bb40
  %194 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %194, ptr align 8 %_85, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %195 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args7)
          to label %bb42 unwind label %cleanup26

bb42:                                             ; preds = %bb41
  %_81.0 = extractvalue { ptr, ptr } %195, 0
  %_81.1 = extractvalue { ptr, ptr } %195, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_81.0, ptr %_81.1)
          to label %bb135 unwind label %cleanup26

bb135:                                            ; preds = %bb42
  br label %bb34

bb125:                                            ; preds = %cleanup34
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorEL_EECs4mnquxVp34G_6errors(ptr align 8 %e8) #23
          to label %bb126 unwind label %terminate

cleanup34:                                        ; preds = %bb44, %bb43, %bb39
  %196 = landingpad { ptr, i32 }
          cleanup
  %197 = extractvalue { ptr, i32 } %196, 0
  %198 = extractvalue { ptr, i32 } %196, 1
  store ptr %197, ptr %1, align 8
  %199 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %198, ptr %199, align 8
  br label %bb125

bb43:                                             ; preds = %bb39
  %200 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %200, ptr align 8 %_94, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 1>
  %201 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_e117bbd6b19cd82f4413501c8428fb4d, ptr align 8 %args9)
          to label %bb44 unwind label %cleanup34

bb44:                                             ; preds = %bb43
  %_90.0 = extractvalue { ptr, ptr } %201, 0
  %_90.1 = extractvalue { ptr, ptr } %201, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_90.0, ptr %_90.1)
          to label %bb45 unwind label %cleanup34

bb45:                                             ; preds = %bb44
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorEL_EECs4mnquxVp34G_6errors(ptr align 8 %e8)
          to label %bb34 unwind label %cleanup26

bb7:                                              ; preds = %bb5
  %_15.0 = extractvalue { ptr, i64 } %31, 0
  %_15.1 = extractvalue { ptr, i64 } %31, 1
; invoke errors::parse
  invoke void @_RNvCs4mnquxVp34G_6errors5parse(ptr sret([24 x i8]) align 8 %_14, ptr %_15.0, i64 %_15.1)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %202 = load i64, ptr %_14, align 8
  %203 = icmp eq i64 %202, -1
  %_16 = select i1 %203, i64 0, i64 1
  %204 = trunc nuw i64 %_16 to i1
  br i1 %204, label %bb9, label %bb10

bb9:                                              ; preds = %bb8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %e, ptr align 8 %_14, i64 24, i1 false)
; invoke <errors::AppError as core::error::Error>::source
  %205 = invoke { ptr, ptr } @_RNvXs_Cs4mnquxVp34G_6errorsNtB4_8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error6source(ptr align 8 %e)
          to label %bb13 unwind label %cleanup37

bb10:                                             ; preds = %bb8
  %206 = getelementptr inbounds i8, ptr %_14, i64 8
  %207 = load i64, ptr %206, align 8
  store i64 %207, ptr %n, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_23, ptr align 8 %n)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
  %208 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %208, ptr align 8 %_23, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %209 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_c96b2bdbd1e873b6183a4bda3ab8772c, ptr align 8 %args)
          to label %bb12 unwind label %cleanup

bb12:                                             ; preds = %bb11
  %_19.0 = extractvalue { ptr, ptr } %209, 0
  %_19.1 = extractvalue { ptr, ptr } %209, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_19.0, ptr %_19.1)
          to label %bb134 unwind label %cleanup

bb134:                                            ; preds = %bb12
  br label %bb2

bb129:                                            ; preds = %cleanup37
; invoke core::ptr::drop_glue::<errors::AppError>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %e) #23
          to label %bb130 unwind label %terminate

cleanup37:                                        ; preds = %bb18, %bb17, %bb16, %bb15, %bb14, %bb13, %bb9
  %210 = landingpad { ptr, i32 }
          cleanup
  %211 = extractvalue { ptr, i32 } %210, 0
  %212 = extractvalue { ptr, i32 } %210, 1
  store ptr %211, ptr %1, align 8
  %213 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %212, ptr %213, align 8
  br label %bb129

bb13:                                             ; preds = %bb9
  %214 = extractvalue { ptr, ptr } %205, 0
  %215 = extractvalue { ptr, ptr } %205, 1
  store ptr %214, ptr %_35, align 8
  %216 = getelementptr inbounds i8, ptr %_35, i64 8
  store ptr %215, ptr %216, align 8
; invoke <core::option::Option<&dyn core::error::Error>>::is_some
  %217 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRDNtNtB4_5error5ErrorEL_E7is_someCs4mnquxVp34G_6errors(ptr align 8 %_35)
          to label %bb14 unwind label %cleanup37

bb14:                                             ; preds = %bb13
  %218 = zext i1 %217 to i8
  store i8 %218, ptr %_33, align 1
  store ptr %e, ptr %args1, align 8
  %219 = getelementptr inbounds i8, ptr %args1, i64 8
  store ptr %e, ptr %219, align 8
  %220 = getelementptr inbounds i8, ptr %args1, i64 16
  store ptr %_33, ptr %220, align 8
  %_258 = load ptr, ptr %args1, align 8
; invoke <core::fmt::rt::Argument>::new_display::<errors::AppError>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCs4mnquxVp34G_6errors8AppErrorEB10_(ptr sret([16 x i8]) align 8 %_38, ptr align 8 %_258)
          to label %bb15 unwind label %cleanup37

bb15:                                             ; preds = %bb14
  %221 = getelementptr inbounds i8, ptr %args1, i64 8
  %_259 = load ptr, ptr %221, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<errors::AppError>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCs4mnquxVp34G_6errors8AppErrorEBX_(ptr sret([16 x i8]) align 8 %_39, ptr align 8 %_259)
          to label %bb16 unwind label %cleanup37

bb16:                                             ; preds = %bb15
  %222 = getelementptr inbounds i8, ptr %args1, i64 16
  %_260 = load ptr, ptr %222, align 8
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_40, ptr %_260)
          to label %bb17 unwind label %cleanup37

bb17:                                             ; preds = %bb16
  %223 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %223, ptr align 8 %_38, i64 16, i1 false)
  %224 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %224, ptr align 8 %_39, i64 16, i1 false)
  %225 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %225, ptr align 8 %_40, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<26, 3>
  %226 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1a_Kj3_ECs4mnquxVp34G_6errors(ptr @alloc_e7c21a0b99def4574ccf36ce68976b0f, ptr align 8 %args2)
          to label %bb18 unwind label %cleanup37

bb18:                                             ; preds = %bb17
  %_28.0 = extractvalue { ptr, ptr } %226, 0
  %_28.1 = extractvalue { ptr, ptr } %226, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_28.0, ptr %_28.1)
          to label %bb19 unwind label %cleanup37

bb19:                                             ; preds = %bb18
; invoke core::ptr::drop_glue::<errors::AppError>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %e)
          to label %bb2 unwind label %cleanup

bb4:                                              ; No predecessors!
  unreachable
}

; errors::parse
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCs4mnquxVp34G_6errors5parse(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !399 {
start:
  %_9 = alloca [24 x i8], align 8
  %_3 = alloca [16 x i8], align 8
  %_2 = alloca [16 x i8], align 8
; call <str>::trim
  %0 = call { ptr, i64 } @_RNvMNtCsl10jNU3mE6R_4core3stre4trimCs4mnquxVp34G_6errors(ptr %s.0, i64 %s.1) #25
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <str>::parse::<i64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsexECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_3, ptr %_4.0, i64 %_4.1) #25
; call <core::result::Result<i64, core::num::error::ParseIntError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtNtNtB7_3num5error13ParseIntErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_2, ptr align 8 %_3) #25
  %1 = load i8, ptr %_2, align 8
  %2 = trunc nuw i8 %1 to i1
  %_5 = zext i1 %2 to i64
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb6, label %bb5

bb6:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %_2, i64 1
  %residual = load i8, ptr %4, align 1
; call <core::result::Result<i64, errors::AppError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::num::error::ParseIntError>>>::from_residual
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtCs4mnquxVp34G_6errors8AppErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtNtNtB7_3num5error13ParseIntErrorEE13from_residualBN_(ptr sret([24 x i8]) align 8 %_0, i8 %residual, ptr align 8 @alloc_f0b49fd2af8b2531fe0b760bac9bc2db) #25
  br label %bb9

bb5:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %n = load i64, ptr %5, align 8
  %_8 = icmp slt i64 %n, 0
  br i1 %_8, label %bb7, label %bb8

bb8:                                              ; preds = %bb5
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %n, ptr %6, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb9

bb7:                                              ; preds = %bb5
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %n, ptr %7, align 8
  store i64 -9223372036854775807, ptr %_9, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_9, i64 24, i1 false)
  br label %bb9

bb9:                                              ; preds = %bb6, %bb7, %bb8
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; errors::dynerr
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCs4mnquxVp34G_6errors6dynerr(ptr sret([16 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !400 {
start:
  %0 = alloca [24 x i8], align 8
  %residual = alloca [24 x i8], align 8
  %_3 = alloca [24 x i8], align 8
  %_2 = alloca [24 x i8], align 8
; call errors::parse
  call void @_RNvCs4mnquxVp34G_6errors5parse(ptr sret([24 x i8]) align 8 %_3, ptr %s.0, i64 %s.1)
; call <core::result::Result<i64, errors::AppError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtCs4mnquxVp34G_6errors8AppErrorENtNtNtB7_3ops9try_trait3Try6branchBN_(ptr sret([24 x i8]) align 8 %_2, ptr align 8 %_3) #25
  %1 = load i64, ptr %_2, align 8
  %2 = icmp eq i64 %1, -1
  %_4 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_4 to i1
  br i1 %3, label %bb5, label %bb4

bb5:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %residual, ptr align 8 %_2, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %residual, i64 24, i1 false)
; call <core::result::Result<u8, alloc::boxed::Box<dyn core::error::Error>> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, errors::AppError>>>::from_residual
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtCs4mnquxVp34G_6errors8AppErrorEE13from_residualB2S_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %0, ptr align 8 @alloc_840b688a40aecb72c97f62b0ca67e535) #25
  br label %bb9

bb4:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %n = load i64, ptr %4, align 8
  %_7 = icmp sgt i64 %n, 255
  br i1 %_7, label %bb6, label %bb8

bb8:                                              ; preds = %bb4
  %_10 = trunc i64 %n to i8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 %_10, ptr %5, align 8
  store ptr null, ptr %_0, align 8
  br label %bb9

bb6:                                              ; preds = %bb4
; call <&str as core::convert::Into<alloc::boxed::Box<dyn core::error::Error>>>::into
  %6 = call { ptr, ptr } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EE4intoCs4mnquxVp34G_6errors(ptr @alloc_4555ac019c070316ee6a647ac605ae4d, i64 7, ptr align 8 @alloc_d0ed77324085cf7311ee02111298f70f) #25
  %_8.0 = extractvalue { ptr, ptr } %6, 0
  %_8.1 = extractvalue { ptr, ptr } %6, 1
  store ptr %_8.0, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %7, align 8
  br label %bb9

bb9:                                              ; preds = %bb5, %bb6, %bb8
  ret void

bb3:                                              ; No predecessors!
  unreachable
}

; errors::sum_all
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCs4mnquxVp34G_6errors7sum_all(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %xs.0, i64 %xs.1) unnamed_addr #1 !guid !401 {
start:
  %0 = alloca [24 x i8], align 8
  %residual = alloca [24 x i8], align 8
  %_10 = alloca [24 x i8], align 8
  %_9 = alloca [24 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %t = alloca [8 x i8], align 8
  store i64 0, ptr %t, align 8
; call <&[&str] as core::iter::traits::collect::IntoIterator>::into_iter
  %1 = call { ptr, ptr } @_RNvXs_NtNtCsl10jNU3mE6R_4core5slice4iterRSReNtNtNtNtB8_4iter6traits7collect12IntoIterator9into_iterCs4mnquxVp34G_6errors(ptr align 8 %xs.0, i64 %xs.1)
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
  store ptr %_3.0, ptr %iter, align 8
  %2 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %2, align 8
  br label %bb2

bb2:                                              ; preds = %bb11, %start
; call <core::slice::iter::Iter<&str> as core::iter::traits::iterator::Iterator>::next
  %3 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterReENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %iter) #25
  store ptr %3, ptr %_5, align 8
  %4 = load ptr, ptr %_5, align 8
  %5 = ptrtoint ptr %4 to i64
  %6 = icmp eq i64 %5, 0
  %_7 = select i1 %6, i64 0, i64 1
  %7 = trunc nuw i64 %_7 to i1
  br i1 %7, label %bb5, label %bb6

bb5:                                              ; preds = %bb2
  %x = load ptr, ptr %_5, align 8
  %_16.0 = load ptr, ptr %x, align 8
  %8 = getelementptr inbounds i8, ptr %x, i64 8
  %_16.1 = load i64, ptr %8, align 8
; call errors::parse
  call void @_RNvCs4mnquxVp34G_6errors5parse(ptr sret([24 x i8]) align 8 %_10, ptr %_16.0, i64 %_16.1)
; call <core::result::Result<i64, errors::AppError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtCs4mnquxVp34G_6errors8AppErrorENtNtNtB7_3ops9try_trait3Try6branchBN_(ptr sret([24 x i8]) align 8 %_9, ptr align 8 %_10) #25
  %9 = load i64, ptr %_9, align 8
  %10 = icmp eq i64 %9, -1
  %_11 = select i1 %10, i64 0, i64 1
  %11 = trunc nuw i64 %_11 to i1
  br i1 %11, label %bb10, label %bb9

bb6:                                              ; preds = %bb2
  %_15 = load i64, ptr %t, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15, ptr %12, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb12

bb12:                                             ; preds = %bb10, %bb6
  ret void

bb10:                                             ; preds = %bb5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %residual, ptr align 8 %_9, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %residual, i64 24, i1 false)
; call <core::result::Result<i64, errors::AppError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, errors::AppError>>>::from_residual
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtCs4mnquxVp34G_6errors8AppErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualBN_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0, ptr align 8 @alloc_5eede92c0b13a73666007c7077cc0a4b) #25
  br label %bb12

bb9:                                              ; preds = %bb5
  %13 = getelementptr inbounds i8, ptr %_9, i64 8
  %val = load i64, ptr %13, align 8
  %14 = load i64, ptr %t, align 8
  %15 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %14, i64 %val)
  %_14.0 = extractvalue { i64, i1 } %15, 0
  %_14.1 = extractvalue { i64, i1 } %15, 1
  br i1 %_14.1, label %panic, label %bb11

bb11:                                             ; preds = %bb9
  store i64 %_14.0, ptr %t, align 8
  br label %bb2

panic:                                            ; preds = %bb9
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_a51d431727bd96f9d4c9853d837a4a0b) #29
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB4_6string6StringEE3newCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !402 {
start:
; call <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB4_6string6StringEE3newCs4mnquxVp34G_6errors()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !403 {
start:
; call <alloc::raw_vec::RawVec<u8>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVechE3newCs4mnquxVp34G_6errors()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <[u8]>::to_vec
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !404 {
start:
; call <[u8]>::to_vec_in::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #25
  ret void
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !405 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !406 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret i64 %_0
}

; <alloc::string::String>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !407 {
start:
  %_1 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_1) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_1, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs4mnquxVp34G_6errors(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !408 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs4mnquxVp34G_6errors(ptr align 8 %self) #25
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs4mnquxVp34G_6errors(i32 %ch) #25
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %ch_len) #25
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs4mnquxVp34G_6errors(i32 %ch, ptr %_0.i) #25
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %_14) #25
  ret void
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !409 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs4mnquxVp34G_6errors(ptr %_2.0, i64 %_2.1) #25
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !410 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::string::String>::push_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %string.0, i64 %string.1) unnamed_addr #0 !guid !411 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %string.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %string.1, 1
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; call <alloc::vec::Vec<u8>>::extend_from_slice
  call void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %_4.0, i64 %_4.1)
  ret void
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB4_6string6StringEE3newCs4mnquxVp34G_6errors() unnamed_addr #1 !guid !412 {
start:
; call <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE6new_inCs4mnquxVp34G_6errors() #25
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<u8>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVechE3newCs4mnquxVp34G_6errors() unnamed_addr #1 !guid !413 {
start:
; call <alloc::raw_vec::RawVec<u8>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE6new_inCs4mnquxVp34G_6errors() #25
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <i8>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs4mnquxVp34G_6errors(i8 %self, i8 %rhs) unnamed_addr #0 !guid !414 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.sadd.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <i8>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs4mnquxVp34G_6errors(i8 %self, i8 %rhs) unnamed_addr #0 !guid !415 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <i8>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_subCs4mnquxVp34G_6errors(i8 %self, i8 %rhs) unnamed_addr #0 !guid !416 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.ssub.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <str>::char_indices
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core3stre12char_indicesCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !417 {
start:
; call <str>::chars
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core3stre5charsCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) #25
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %1, align 8
  store ptr %_2.0, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_2.1, ptr %2, align 8
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !418 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <str>::trim
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCsl10jNU3mE6R_4core3stre4trimCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !419 {
start:
; call <str>::trim_matches::<<char>::is_whitespace>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre12trim_matchesNvMNtNtB5_4char7methodsc13is_whitespaceECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1)
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <str>::chars
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core3stre5charsCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !420 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8]>::iter
  %2 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCs4mnquxVp34G_6errors(ptr %_3.0, i64 %_3.1) #25
  %_2.0 = extractvalue { ptr, ptr } %2, 0
  %_2.1 = extractvalue { ptr, ptr } %2, 1
  %3 = insertvalue { ptr, ptr } poison, ptr %_2.0, 0
  %4 = insertvalue { ptr, ptr } %3, ptr %_2.1, 1
  ret { ptr, ptr } %4
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitReE8is_emptyCs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !421 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[&str]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSRe4iterCs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !422 {
start:
; call <core::slice::iter::Iter<&str>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterReE3newCs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1) #25
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[u8]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !423 {
start:
; call <core::slice::iter::Iter<u8>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) #25
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !424 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <core::option::Option<&dyn core::error::Error>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRDNtNtB4_5error5ErrorEL_E7is_someCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !425 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load ptr, ptr %1, align 8
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_2 to i1
  br i1 %5, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb4:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&str>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionReE7is_someCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !426 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_2 to i1
  br i1 %5, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb4:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&u8>>::unwrap_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCs4mnquxVp34G_6errors(ptr %0, ptr align 8 %1) unnamed_addr #0 !guid !427 {
start:
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = load ptr, ptr %self, align 8
  %3 = ptrtoint ptr %2 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_2 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %val = load ptr, ptr %self, align 8
  ret ptr %val

bb2:                                              ; preds = %start
; call core::hint::unreachable_unchecked
  call void @_RNvNtCsl10jNU3mE6R_4core4hint21unreachable_uncheckedCs4mnquxVp34G_6errors(ptr align 8 %1) #31
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<i32>>::xor
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE3xorCs4mnquxVp34G_6errors(i32 %self.0, i32 %self.1, i32 %optb.0, i32 %optb.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !428 {
start:
  %_10 = alloca [1 x i8], align 1
  %_9 = alloca [1 x i8], align 1
  %_3 = alloca [16 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  store i8 0, ptr %_10, align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_10, align 1
  store i32 %self.0, ptr %_3, align 4
  %0 = getelementptr inbounds i8, ptr %_3, i64 4
  store i32 %self.1, ptr %0, align 4
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i32 %optb.0, ptr %1, align 4
  %2 = getelementptr inbounds i8, ptr %1, i64 4
  store i32 %optb.1, ptr %2, align 4
  %3 = load i32, ptr %_3, align 4
  %4 = getelementptr inbounds i8, ptr %_3, i64 4
  %5 = load i32, ptr %4, align 4
  %_6 = zext i32 %3 to i64
  %6 = trunc nuw i64 %_6 to i1
  br i1 %6, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_3, i64 8
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds i8, ptr %7, i64 4
  %10 = load i32, ptr %9, align 4
  %_4 = zext i32 %8 to i64
  %11 = trunc nuw i64 %_4 to i1
  br i1 %11, label %bb1, label %bb5

bb3:                                              ; preds = %start
  %12 = getelementptr inbounds i8, ptr %_3, i64 8
  %13 = load i32, ptr %12, align 4
  %14 = getelementptr inbounds i8, ptr %12, i64 4
  %15 = load i32, ptr %14, align 4
  %_5 = zext i32 %13 to i64
  %16 = trunc nuw i64 %_5 to i1
  br i1 %16, label %bb4, label %bb1

bb4:                                              ; preds = %bb3
  store i8 0, ptr %_10, align 1
  %17 = getelementptr inbounds i8, ptr %_3, i64 8
  %b.0 = load i32, ptr %17, align 4
  %18 = getelementptr inbounds i8, ptr %17, i64 4
  %b.1 = load i32, ptr %18, align 4
  store i32 %b.0, ptr %_0, align 4
  %19 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %b.1, ptr %19, align 4
  br label %bb13

bb1:                                              ; preds = %bb2, %bb3
  store i32 0, ptr %_0, align 4
  br label %bb13

bb13:                                             ; preds = %bb1, %bb5, %bb4
  %20 = load i8, ptr %_9, align 1
  %21 = trunc nuw i8 %20 to i1
  br i1 %21, label %bb12, label %bb10

bb5:                                              ; preds = %bb2
  store i8 0, ptr %_9, align 1
  %a.0 = load i32, ptr %_3, align 4
  %22 = getelementptr inbounds i8, ptr %_3, i64 4
  %a.1 = load i32, ptr %22, align 4
  store i32 %a.0, ptr %_0, align 4
  %23 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %a.1, ptr %23, align 4
  br label %bb13

bb10:                                             ; preds = %bb12, %bb13
  %24 = load i8, ptr %_10, align 1
  %25 = trunc nuw i8 %24 to i1
  br i1 %25, label %bb11, label %bb6

bb12:                                             ; preds = %bb13
  br label %bb10

bb6:                                              ; preds = %bb11, %bb10
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_10, align 1
  %26 = load i32, ptr %_0, align 4
  %27 = getelementptr inbounds i8, ptr %_0, i64 4
  %28 = load i32, ptr %27, align 4
  %29 = insertvalue { i32, i32 } poison, i32 %26, 0
  %30 = insertvalue { i32, i32 } %29, i32 %28, 1
  ret { i32, i32 } %30

bb11:                                             ; preds = %bb10
  br label %bb6

bb14:                                             ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<char, core::char::convert::CharTryFromError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultcNtNtNtB4_4char7convert16CharTryFromErrorE5is_okCs4mnquxVp34G_6errors(ptr align 4 %self) unnamed_addr #0 !guid !429 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i32, ptr %self, align 4
  %1 = icmp eq i32 %0, -1
  %_2 = select i1 %1, i64 1, i64 0
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, alloc::string::String>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlNtNtCs7CppTae75M1_5alloc6string6StringE5is_okCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !430 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, &str>>::unwrap_or_default
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlReE17unwrap_or_defaultCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !431 {
start:
  %_0 = alloca [4 x i8], align 4
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb10

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i32, ptr %4, align 8
  store i32 %x, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb10, %bb3
  %5 = load ptr, ptr %self, align 8
  %6 = ptrtoint ptr %5 to i64
  %7 = icmp eq i64 %6, 0
  %_4 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_4 to i1
  br i1 %8, label %bb6, label %bb4

bb10:                                             ; preds = %bb2
  br label %bb7

bb6:                                              ; preds = %bb7
  br label %bb4

bb4:                                              ; preds = %bb6, %bb7
  %9 = load i32, ptr %_0, align 4
  ret i32 %9

bb1:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), core::fmt::Error>>::expect
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6expectCs4mnquxVp34G_6errors(i1 zeroext %0, ptr %msg.0, i64 %msg.1, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !432 {
start:
  %e = alloca [0 x i8], align 1
  %self = alloca [1 x i8], align 1
  %2 = zext i1 %0 to i8
  store i8 %2, ptr %self, align 1
  %3 = load i8, ptr %self, align 1
  %4 = trunc nuw i8 %3 to i1
  %_3 = zext i1 %4 to i64
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb2, label %bb3

bb2:                                              ; preds = %start
; call core::result::unwrap_failed
  call void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr %msg.0, i64 %msg.1, ptr %e, ptr align 8 @vtable.1, ptr align 8 %1) #29
  unreachable

bb3:                                              ; preds = %start
  ret void

bb1:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::mem::manually_drop::ManuallyDrop<alloc::alloc::Global>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNtNtCs7CppTae75M1_5alloc5alloc6GlobalE4takeCs4mnquxVp34G_6errors(ptr %slot) unnamed_addr #0 !guid !433 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<alloc::alloc::Global>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtNtCs7CppTae75M1_5alloc5alloc6GlobalE6as_refCs4mnquxVp34G_6errors(ptr %slot)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB6_6result6ResultlNtNtB19_6string6StringEEE3newCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !434 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB6_6result6ResultlNtNtB19_6string6StringEEE6as_refCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !435 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSINtNtB6_6result6ResultlNtNtB19_6string6StringEEE3newCs4mnquxVp34G_6errors(ptr align 8 %x.0, i64 %x.1) unnamed_addr #1 !guid !436 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSINtNtB6_6result6ResultlNtNtB19_6string6StringEEE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !437 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSINtNtB6_6result6ResultlNtNtB19_6string6StringEEE6as_refCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !438 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB6_6result6ResultlNtNtB1b_6string6StringEEE3newCs4mnquxVp34G_6errors(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !439 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 32, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB6_6result6ResultlNtNtB1b_6string6StringEEE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !440 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE3newCs4mnquxVp34G_6errors(ptr sret([80 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !441 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 80, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !442 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj7_EE3newCs4mnquxVp34G_6errors(ptr sret([128 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !443 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 128, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj7_EE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !444 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::alloc::Global>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtNtCs7CppTae75M1_5alloc5alloc6GlobalE3newCs4mnquxVp34G_6errors() unnamed_addr #1 !guid !445 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::alloc::Global>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtNtCs7CppTae75M1_5alloc5alloc6GlobalE6as_refCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #1 !guid !446 {
start:
  ret ptr %self
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs4mnquxVp34G_6errors(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !447 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %align, ptr align 8 %0) #27
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs4mnquxVp34G_6errors(i64 %self) unnamed_addr #0 !guid !448 {
start:
  ret i64 %self
}

; <core::mem::alignment::Alignment>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCs4mnquxVp34G_6errors(i64 %align) unnamed_addr #0 !guid !449 {
start:
  %_0 = alloca [8 x i8], align 8
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs4mnquxVp34G_6errors(i64 %align, ptr align 8 @alloc_988c380202cc7b7a37ca3d8d5930c44f) #25
  store i64 %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::mem::alignment::Alignment>::as_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCs4mnquxVp34G_6errors(i64 %self) unnamed_addr #0 !guid !450 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs4mnquxVp34G_6errors(i64 %self) #25
; call <core::num::nonzero::NonZero<usize>>::get
  %_0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCs4mnquxVp34G_6errors(i64 %_2) #25
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::next_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !451 {
start:
  %value = load i64, ptr %self, align 8
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs4mnquxVp34G_6errors(i64 %value, i64 1, ptr align 8 @alloc_de9a5d9a80d554992107c1ea3afec081) #27
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i64 %value, 1
  store i64 %_0.i, ptr %self, align 8
  ret i64 %value
}

; <core::ops::index_range::IndexRange>::end
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !452 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !453 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_2 = load i64, ptr %0, align 8
  %_3 = load i64, ptr %self, align 8
  %_0 = sub nuw i64 %_2, %_3
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::start
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !454 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::zero_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCs4mnquxVp34G_6errors(i64 %end) unnamed_addr #0 !guid !455 {
start:
  %0 = insertvalue { i64, i64 } { i64 0, i64 poison }, i64 %end, 1
  ret { i64, i64 } %0
}

; <*mut core::result::Result<i32, alloc::string::String>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtB6_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !456 {
start:
; call <*const core::result::Result<i32, alloc::string::String>>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPINtNtB6_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %origin, ptr align 8 %0) #25
  ret i64 %_0
}

; <*mut u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !457 {
start:
; call <*const u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %origin, ptr align 8 %0) #25
  ret i64 %_0
}

; <*mut u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !458 {
start:
; call <*const u8>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCs4mnquxVp34G_6errors(ptr %self) #25
  ret i1 %_0
}

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !459 {
start:
; call <*const ()>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCs4mnquxVp34G_6errors(ptr %self) #25
  ret i1 %_0
}

; <*const core::result::Result<i32, alloc::string::String>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPINtNtB6_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !460 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 24
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs4mnquxVp34G_6errors(ptr %self, ptr %origin, ptr align 8 %0) #27
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #29
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 24, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 24
  ret i64 %_0
}

; <*const u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !461 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 1
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs4mnquxVp34G_6errors(ptr %self, ptr %origin, ptr align 8 %0) #27
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #29
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 1, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 1
  ret i64 %_0
}

; <*const u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !462 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCs4mnquxVp34G_6errors(ptr %self) #25
  ret i1 %_0
}

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCs4mnquxVp34G_6errors(ptr %self, i64 %align) unnamed_addr #0 !guid !463 {
start:
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i1 = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i1, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_fad0cd83b7d1858a846a172eb260e593, i64 42) #25
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 @alloc_7abc4ceda2d1d9be88f00c5dc522bc84) #29
  unreachable

bb2:                                              ; preds = %start
  %_0.i = ptrtoint ptr %self to i64
  %_8 = sub i64 %align, 1
  %_6 = and i64 %_0.i, %_8
  %_0 = icmp eq i64 %_6, 0
  ret i1 %_0
}

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !464 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCs4mnquxVp34G_6errors(ptr %self) #25
  ret i1 %_0
}

; <char>::is_whitespace
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc13is_whitespaceCs4mnquxVp34G_6errors(i32 %self) unnamed_addr #0 !guid !465 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = icmp eq i32 %self, 32
  br i1 %0, label %bb7, label %bb2

bb7:                                              ; preds = %bb3, %start
  store i8 1, ptr %_0, align 1
  br label %bb8

bb2:                                              ; preds = %start
  %_2 = icmp ule i32 9, %self
  br i1 %_2, label %bb3, label %bb1

bb1:                                              ; preds = %bb3, %bb2
  %_4 = icmp ule i32 0, %self
  br i1 %_4, label %bb6, label %bb4

bb3:                                              ; preds = %bb2
  %_3 = icmp ule i32 %self, 13
  br i1 %_3, label %bb7, label %bb1

bb4:                                              ; preds = %bb6, %bb1
; call core::unicode::unicode_data::white_space::lookup
  %1 = call zeroext i1 @_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space6lookupCs4mnquxVp34G_6errors(i32 %self) #25
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_0, align 1
  br label %bb8

bb6:                                              ; preds = %bb1
  %_5 = icmp ule i32 %self, 132
  br i1 %_5, label %bb5, label %bb4

bb5:                                              ; preds = %bb6
  store i8 0, ptr %_0, align 1
  br label %bb8

bb8:                                              ; preds = %bb7, %bb5, %bb4
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4
}

; <char>::from_u32_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc18from_u32_uncheckedCs4mnquxVp34G_6errors(i32 %i) unnamed_addr #0 !guid !466 {
start:
; call core::char::convert::from_u32_unchecked
  %_0 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert18from_u32_uncheckedCs4mnquxVp34G_6errors(i32 %i, ptr align 8 @alloc_9e5c5064a9cc4d3581a4b435ddfc6bf3) #25
  ret i32 %_0
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs4mnquxVp34G_6errors(i32 %self) unnamed_addr #0 !guid !467 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs4mnquxVp34G_6errors(i32 %self) #25
  ret i64 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %self, i32 %radix) unnamed_addr #0 !guid !468 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #25
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #29
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !469 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs4mnquxVp34G_6errors(i64 %_3) #25
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs4mnquxVp34G_6errors(i64 %_2) #25
  ret ptr %_0
}

; <core::alloc::layout::Layout>::repeat_packed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %n) unnamed_addr #0 !guid !470 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %0, align 8
; call <usize>::checked_mul
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs4mnquxVp34G_6errors(i64 %_4, i64 %n) #25
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %size = load i64, ptr %8, align 8
  %_7 = load i64, ptr %self, align 8
; call <core::alloc::layout::Layout>::from_size_alignment
  %9 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCs4mnquxVp34G_6errors(i64 %size, i64 %_7) #25
  %10 = extractvalue { i64, i64 } %9, 0
  %11 = extractvalue { i64, i64 } %9, 1
  store i64 %10, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %13 = load i64, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { i64, i64 } poison, i64 %13, 0
  %17 = insertvalue { i64, i64 } %16, i64 %15, 1
  ret { i64, i64 } %17

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCs4mnquxVp34G_6errors(i64 %size, i64 %alignment) unnamed_addr #0 !guid !471 {
start:
  %_0 = alloca [16 x i8], align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 %alignment, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %size, ptr %0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <core::alloc::layout::Layout>::is_size_align_valid
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCs4mnquxVp34G_6errors(i64 %size, i64 %align) unnamed_addr #0 !guid !472 {
start:
  %_4 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
; call <core::mem::alignment::Alignment>::new
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCs4mnquxVp34G_6errors(i64 %align) #25
  store i64 %0, ptr %_4, align 8
  %1 = load i64, ptr %_4, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %alignment = load i64, ptr %_4, align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %4 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_align_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCs4mnquxVp34G_6errors(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !473 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %size, i64 %align, ptr align 8 %0) #27
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %align, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs4mnquxVp34G_6errors(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !474 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %size, i64 %alignment, ptr align 8 %0) #27
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !475 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::align
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !476 {
start:
  %_2 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_usize
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCs4mnquxVp34G_6errors(i64 %_2) #25
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !477 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::array::iter::IntoIter<&str, 4>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterReKj4_E10unsize_mutCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !478 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 4, 1
  ret { ptr, i64 } %1
}

; <core::array::iter::IntoIter<&str, 7>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterReKj7_E10unsize_mutCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !479 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj7_EE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 7, 1
  ret { ptr, i64 } %1
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs4mnquxVp34G_6errors(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !480 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs4mnquxVp34G_6errors(i64 %3, i64 %5, i1 zeroext %8) #25
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs4mnquxVp34G_6errors(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !481 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs4mnquxVp34G_6errors(ptr %2, i64 %4, i64 %6) #25
  ret void
}

; <alloc::alloc::Global>::grow_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global17grow_impl_runtimeCs4mnquxVp34G_6errors(ptr %self, ptr %ptr, i64 %0, i64 %1, i64 %2, i64 %3, i1 zeroext %zeroed) unnamed_addr #0 !guid !482 {
start:
  %_8.i.i = alloca [1 x i8], align 1
  %_30 = alloca [16 x i8], align 8
  %_21 = alloca [8 x i8], align 8
  %old_size = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %new_layout = alloca [16 x i8], align 8
  %old_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %old_layout, align 8
  %4 = getelementptr inbounds i8, ptr %old_layout, i64 8
  store i64 %1, ptr %4, align 8
  store i64 %2, ptr %new_layout, align 8
  %5 = getelementptr inbounds i8, ptr %new_layout, i64 8
  store i64 %3, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %old_layout) #25
  store i64 %6, ptr %old_size, align 8
  %7 = load i64, ptr %old_size, align 8
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %9 = load i64, ptr %new_layout, align 8
  %10 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %11 = load i64, ptr %10, align 8
; call <alloc::alloc::Global>::alloc_impl
  %12 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs4mnquxVp34G_6errors(ptr %self, i64 %9, i64 %11, i1 zeroext %zeroed) #25
  %13 = extractvalue { ptr, i64 } %12, 0
  %14 = extractvalue { ptr, i64 } %12, 1
  store ptr %13, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %14, ptr %15, align 8
  br label %bb30

bb2:                                              ; preds = %start
; call <core::alloc::layout::Layout>::align
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs4mnquxVp34G_6errors(ptr align 8 %old_layout) #25
; call <core::alloc::layout::Layout>::align
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs4mnquxVp34G_6errors(ptr align 8 %new_layout) #25
  %_9 = icmp eq i64 %_10, %_12
  br i1 %_9, label %bb6, label %bb7

bb30:                                             ; preds = %bb17, %bb20, %bb25, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4mnquxVp34G_6errors.exit, %bb3
  %16 = load ptr, ptr %_0, align 8
  %17 = getelementptr inbounds i8, ptr %_0, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  ret { ptr, i64 } %20

bb7:                                              ; preds = %bb2
  %21 = load i64, ptr %new_layout, align 8
  %22 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %23 = load i64, ptr %22, align 8
; call <alloc::alloc::Global>::alloc_impl
  %24 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs4mnquxVp34G_6errors(ptr %self, i64 %21, i64 %23, i1 zeroext %zeroed) #25
  %_31.0 = extractvalue { ptr, i64 } %24, 0
  %_31.1 = extractvalue { ptr, i64 } %24, 1
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %25 = call { ptr, i64 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr %_31.0, i64 %_31.1) #25
  %26 = extractvalue { ptr, i64 } %25, 0
  %27 = extractvalue { ptr, i64 } %25, 1
  store ptr %26, ptr %_30, align 8
  %28 = getelementptr inbounds i8, ptr %_30, i64 8
  store i64 %27, ptr %28, align 8
  %29 = load ptr, ptr %_30, align 8
  %30 = getelementptr inbounds i8, ptr %_30, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = ptrtoint ptr %29 to i64
  %33 = icmp eq i64 %32, 0
  %_32 = select i1 %33, i64 1, i64 0
  %34 = trunc nuw i64 %_32 to i1
  br i1 %34, label %bb25, label %bb24

bb6:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %new_size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %new_layout) #25
; call <core::alloc::layout::Layout>::size
  %_18 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %old_layout) #25
  %_17 = icmp uge i64 %new_size, %_18
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_2.i, label %bb2.i2, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i2:                                           ; preds = %bb6
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs4mnquxVp34G_6errors(i1 zeroext %_17, ptr align 8 @alloc_9e1ff22d96cae328e0e878f28b86a5f7) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb6, %bb2.i2
  %35 = load i64, ptr %old_layout, align 8
  %36 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %37 = load i64, ptr %36, align 8
; call alloc::alloc::realloc_nonnull
  %raw_ptr = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc15realloc_nonnullCs4mnquxVp34G_6errors(ptr %ptr, i64 %35, i64 %37, i64 %new_size) #25
; call <core::ptr::non_null::NonNull<u8>>::new
  %_23 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs4mnquxVp34G_6errors(ptr %raw_ptr) #25
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_22 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs4mnquxVp34G_6errors(ptr %_23) #25
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %38 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr %_22) #25
  store ptr %38, ptr %_21, align 8
  %39 = load ptr, ptr %_21, align 8
  %40 = ptrtoint ptr %39 to i64
  %41 = icmp eq i64 %40, 0
  %_24 = select i1 %41, i64 1, i64 0
  %42 = trunc nuw i64 %_24 to i1
  br i1 %42, label %bb17, label %bb16

bb25:                                             ; preds = %bb7
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %43 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs4mnquxVp34G_6errors(ptr align 8 @alloc_6379aaa2812385052216e7dc8e3279fb) #25
  %44 = extractvalue { ptr, i64 } %43, 0
  %45 = extractvalue { ptr, i64 } %43, 1
  store ptr %44, ptr %_0, align 8
  %46 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %45, ptr %46, align 8
  br label %bb30

bb24:                                             ; preds = %bb7
  %new_ptr.0 = load ptr, ptr %_30, align 8
  %47 = getelementptr inbounds i8, ptr %_30, i64 8
  %new_ptr.1 = load i64, ptr %47, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_37 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs4mnquxVp34G_6errors(ptr %new_ptr.0, i64 %new_ptr.1) #25
  %48 = load i64, ptr %old_size, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4mnquxVp34G_6errors.exit

bb2.i:                                            ; preds = %bb24
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs4mnquxVp34G_6errors(ptr %ptr, ptr %_37, i64 1, i64 1, i64 %48, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #27
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4mnquxVp34G_6errors.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4mnquxVp34G_6errors.exit: ; preds = %bb24, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_37, ptr align 1 %ptr, i64 %48, i1 false)
  %49 = load i64, ptr %old_layout, align 8
  %50 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %51 = load i64, ptr %50, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs4mnquxVp34G_6errors(ptr %self, ptr %ptr, i64 %49, i64 %51) #25
  store ptr %new_ptr.0, ptr %_0, align 8
  %52 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %new_ptr.1, ptr %52, align 8
  br label %bb30

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %53 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs4mnquxVp34G_6errors(ptr align 8 @alloc_a699fef46c42b266f9e12652c07a696a) #25
  %54 = extractvalue { ptr, i64 } %53, 0
  %55 = extractvalue { ptr, i64 } %53, 1
  store ptr %54, ptr %_0, align 8
  %56 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %55, ptr %56, align 8
  br label %bb30

bb16:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %ptr1 = load ptr, ptr %_21, align 8
  br i1 %zeroed, label %bb18, label %bb20

bb20:                                             ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCs4mnquxVp34G_6errors.exit, %bb16
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %57 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs4mnquxVp34G_6errors(ptr %ptr1, i64 %new_size) #25
  %_29.0 = extractvalue { ptr, i64 } %57, 0
  %_29.1 = extractvalue { ptr, i64 } %57, 1
  store ptr %_29.0, ptr %_0, align 8
  %58 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29.1, ptr %58, align 8
  br label %bb30

bb18:                                             ; preds = %bb16
  %59 = load i64, ptr %old_size, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %raw_ptr, i64 %59
  %60 = load i64, ptr %old_size, align 8
  %_28 = sub i64 %new_size, %60
; call core::ub_checks::check_language_ub
  %_4.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_4.i.i, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCs4mnquxVp34G_6errors.exit

bb2.i.i:                                          ; preds = %bb18
  %61 = icmp eq i64 %_28, 0
  %62 = zext i1 %61 to i8
  store i8 %62, ptr %_8.i.i, align 1
  %63 = load i8, ptr %_8.i.i, align 1
  %64 = trunc nuw i8 %63 to i1
; call core::ptr::write_bytes::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr11write_bytes18precondition_checkCs4mnquxVp34G_6errors(ptr %_0.i, i64 1, i1 zeroext %64, ptr align 8 @alloc_2fc439fdc88563e15d315d43214d38e0) #27
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCs4mnquxVp34G_6errors.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCs4mnquxVp34G_6errors.exit: ; preds = %bb18, %bb2.i.i
  call void @llvm.memset.p0.i64(ptr align 1 %_0.i, i8 0, i64 %_28, i1 false)
  br label %bb20

bb15:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs4mnquxVp34G_6errors(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !483 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs4mnquxVp34G_6errors(ptr %_6, i64 0) #25
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs4mnquxVp34G_6errors(i64 %11, i64 %13) #25
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs4mnquxVp34G_6errors(i64 %15, i64 %17) #25
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs4mnquxVp34G_6errors(ptr %_12) #25
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs4mnquxVp34G_6errors(ptr %_11) #25
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr %_10) #25
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs4mnquxVp34G_6errors(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #25
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs4mnquxVp34G_6errors(ptr %ptr, i64 %size) #25
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs4mnquxVp34G_6errors(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !484 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs4mnquxVp34G_6errors(ptr %ptr, i64 %3, i64 %5) #25
  br label %bb3
}

; <alloc::alloc::Global>::grow_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global9grow_implCs4mnquxVp34G_6errors(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !485 {
start:
  %_6 = alloca [56 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %_6, i64 32
  store ptr %self, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_6, i64 40
  store ptr %ptr, ptr %1, align 8
  store i64 %old_layout.0, ptr %_6, align 8
  %2 = getelementptr inbounds i8, ptr %_6, i64 8
  store i64 %old_layout.1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_6, i64 16
  store i64 %new_layout.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %new_layout.1, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_6, i64 48
  %6 = zext i1 %zeroed to i8
  store i8 %6, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %_6, i64 32
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds i8, ptr %_6, i64 40
  %10 = load ptr, ptr %9, align 8
  %11 = load i64, ptr %_6, align 8
  %12 = getelementptr inbounds i8, ptr %_6, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = getelementptr inbounds i8, ptr %_6, i64 16
  %15 = load i64, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = getelementptr inbounds i8, ptr %_6, i64 48
  %19 = load i8, ptr %18, align 8
  %20 = trunc nuw i8 %19 to i1
; call <alloc::alloc::Global>::grow_impl_runtime
  %21 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global17grow_impl_runtimeCs4mnquxVp34G_6errors(ptr %8, ptr %10, i64 %11, i64 %13, i64 %15, i64 %17, i1 zeroext %20) #25
  %_0.0 = extractvalue { ptr, i64 } %21, 0
  %_0.1 = extractvalue { ptr, i64 } %21, 1
  %22 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %_0.1, 1
  ret { ptr, i64 } %23
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::from_nonnull_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE15from_nonnull_inCs4mnquxVp34G_6errors(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !486 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
; call <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>>>::cast::<u8>
  %ptr1 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE4casthECs4mnquxVp34G_6errors(ptr %ptr) #25
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<core::result::Result<i32, alloc::string::String>>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB4_6string6StringEECs4mnquxVp34G_6errors(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_nonnull_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15from_nonnull_inCs4mnquxVp34G_6errors(ptr %ptr1, i64 %capacity2) #25
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE17from_raw_parts_inCs4mnquxVp34G_6errors(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !487 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<core::result::Result<i32, alloc::string::String>>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB4_6string6StringEECs4mnquxVp34G_6errors(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inCs4mnquxVp34G_6errors(ptr %ptr, i64 %capacity2) #25
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE3ptrCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !488 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<core::result::Result<i32, alloc::string::String>>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB8_6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE6new_inCs4mnquxVp34G_6errors() unnamed_addr #0 personality ptr @rust_eh_personality !guid !489 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<core::result::Result<i32, alloc::string::String>>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors() #25
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCs4mnquxVp34G_6errors(i64 %_4) #25
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE8capacityCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !490 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCs4mnquxVp34G_6errors(ptr align 8 %self, i64 24) #25
  ret i64 %_0
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::non_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE8non_nullCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !491 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<core::result::Result<i32, alloc::string::String>>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB8_6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE9allocatorCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !492 {
start:
; call <alloc::raw_vec::RawVecInner>::allocator
  %_0 = call ptr @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner9allocatorCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u8>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !493 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u8>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u8>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE6new_inCs4mnquxVp34G_6errors() unnamed_addr #0 personality ptr @rust_eh_personality !guid !494 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<u8>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofhECs4mnquxVp34G_6errors() #25
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCs4mnquxVp34G_6errors(i64 %_4) #25
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<u8>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE7reserveCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #0 !guid !495 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %len, i64 %additional, i64 1, i64 1) #25
  ret void
}

; <alloc::raw_vec::RawVec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !496 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCs4mnquxVp34G_6errors(ptr align 8 %self, i64 1) #25
  ret i64 %_0
}

; <i32>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCs4mnquxVp34G_6errors(i32 %self, i32 %rhs) unnamed_addr #0 !guid !497 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_subCs4mnquxVp34G_6errors(i32 %self, i32 %rhs) unnamed_addr #0 !guid !498 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs4mnquxVp34G_6errors(i32 %self) unnamed_addr #0 !guid !499 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs4mnquxVp34G_6errors(i32 %self) #25
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs4mnquxVp34G_6errors(i32 %self) unnamed_addr #0 !guid !500 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>::dealloc_only
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEE12dealloc_onlyCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !501 {
start:
  %_4 = alloca [16 x i8], align 8
  %_3 = getelementptr inbounds i8, ptr %self, i64 32
; call <core::mem::manually_drop::ManuallyDrop<alloc::alloc::Global>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNtNtCs7CppTae75M1_5alloc5alloc6GlobalE4takeCs4mnquxVp34G_6errors(ptr %_3) #25
  %_5 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_6 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::from_nonnull_in
  %1 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE15from_nonnull_inCs4mnquxVp34G_6errors(ptr %_5, i64 %_6) #25
  %2 = extractvalue { i64, ptr } %1, 0
  %3 = extractvalue { i64, ptr } %1, 1
  store i64 %2, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  store ptr %3, ptr %4, align 8
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecINtNtB4_6result6ResultlNtNtBG_6string6StringEEECs4mnquxVp34G_6errors(ptr align 8 %_4)
  ret void
}

; <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>::as_raw_mut_slice
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEE16as_raw_mut_sliceCs4mnquxVp34G_6errors(ptr align 8 %0) unnamed_addr #1 !guid !502 {
start:
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %_3 = load ptr, ptr %2, align 8
; call <&mut alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_4 = call i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB8_6result6ResultlNtNtBX_6string6StringEENtB2_17ExactSizeIterator3lenCs4mnquxVp34G_6errors(ptr align 8 %self)
; call <*mut core::result::Result<i32, alloc::string::String>>::cast_slice
  %3 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtB8_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringE10cast_sliceCs4mnquxVp34G_6errors(ptr %_3, i64 %_4) #25
  %_0.0 = extractvalue { ptr, i64 } %3, 0
  %_0.1 = extractvalue { ptr, i64 } %3, 1
  %4 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_0.1, 1
  ret { ptr, i64 } %5
}

; <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>::forget_remaining_elements_and_dealloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEE37forget_remaining_elements_and_deallocCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !503 {
start:
  %0 = alloca [32 x i8], align 8
  %_2.i = alloca [32 x i8], align 8
  %1 = alloca [32 x i8], align 8
  %this = alloca [32 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %self, i64 32, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 32, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB6_6result6ResultlNtNtB1b_6string6StringEEE3newCs4mnquxVp34G_6errors(ptr sret([32 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %this, ptr align 8 %_2.i, i64 32, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB6_6result6ResultlNtNtB1b_6string6StringEEE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %this)
; call <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>::dealloc_only
  call void @_RNvMs0_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEE12dealloc_onlyCs4mnquxVp34G_6errors(ptr align 8 %_0.i) #25
  ret void
}

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs4mnquxVp34G_6errors(i64 %addr) unnamed_addr #0 !guid !504 {
start:
  %_0 = inttoptr i64 %addr to ptr
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::extend_from_slice
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #1 !guid !505 {
start:
; call <[u8]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCs4mnquxVp34G_6errors(ptr %other.0, i64 %other.1) #25
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
; call <alloc::vec::Vec<u8> as alloc::vec::spec_extend::SpecExtend<&u8, core::slice::iter::Iter<u8>>>::spec_extend
  call void @_RNvXs2_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB7_3VechEINtB5_10SpecExtendRhINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhEE11spec_extendCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %_3.0, ptr %_3.1)
  ret void
}

; <i64>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_addCs4mnquxVp34G_6errors(i64 %self, i64 %rhs) unnamed_addr #0 !guid !506 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <i64>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs4mnquxVp34G_6errors(i64 %self, i64 %rhs) unnamed_addr #0 !guid !507 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <i64>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_subCs4mnquxVp34G_6errors(i64 %self, i64 %rhs) unnamed_addr #0 !guid !508 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <core::ptr::unique::Unique<dyn core::error::Error>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_5error5ErrorEL_E6as_ptrCs4mnquxVp34G_6errors(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !509 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <core::ptr::unique::Unique<dyn core::error::Error + core::marker::Sync + core::marker::Send>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_5error5ErrorNtNtB9_6marker4SyncNtB1c_4SendEL_E6as_ptrCs4mnquxVp34G_6errors(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !510 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <core::ptr::unique::Unique<core::result::Result<i32, alloc::string::String>>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE15as_non_null_ptrCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !511 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueINtNtNtB9_3mem12maybe_uninit11MaybeUninitAINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EE6as_ptrCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !512 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<[core::result::Result<i32, alloc::string::String>]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE6as_ptrCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !513 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::unique::Unique<u8>>::from_non_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCs4mnquxVp34G_6errors(ptr %pointer) unnamed_addr #0 !guid !514 {
start:
  ret ptr %pointer
}

; <core::ptr::unique::Unique<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13new_uncheckedCs4mnquxVp34G_6errors(ptr %ptr) unnamed_addr #0 !guid !515 {
start:
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_2 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCs4mnquxVp34G_6errors(ptr %ptr, ptr align 8 @alloc_8e8e5d43991787ef9fba0c8fe53b59fb) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !516 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEE8from_refCs4mnquxVp34G_6errors(ptr align 4 %r) unnamed_addr #0 !guid !517 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultaNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs4mnquxVp34G_6errors(ptr %r) unnamed_addr #0 !guid !518 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<bool, core::str::error::ParseBoolError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultbNtNtNtB9_3str5error14ParseBoolErrorEE8from_refCs4mnquxVp34G_6errors(ptr %r) unnamed_addr #0 !guid !519 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<f64, core::num::float_parse::ParseFloatError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultdNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !520 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<u8, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResulthNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs4mnquxVp34G_6errors(ptr %r) unnamed_addr #0 !guid !521 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %subtracted) unnamed_addr #0 !guid !522 {
start:
; call <*mut core::result::Result<i32, alloc::string::String>>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtB6_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #25
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>>>::read
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE4readCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self) unnamed_addr #0 !guid !523 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %self, i64 24, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, &str>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlReEE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !524 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i64, alloc::string::String>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultxNtNtCs7CppTae75M1_5alloc6string6StringEE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !525 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB9_5error5ErrorEL_EE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !526 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB9_5error5ErrorNtNtB9_6marker4SyncNtB1O_4SendEL_EE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !527 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<errors::AppError>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs4mnquxVp34G_6errors8AppErrorE8from_refBV_(ptr align 8 %r) unnamed_addr #0 !guid !528 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !529 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !530 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&core::num::error::ParseIntError>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtNtNtB9_3num5error13ParseIntErrorE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !531 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRxE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !532 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[&str]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSReE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r.0, i64 %r.1) unnamed_addr #0 !guid !533 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCs4mnquxVp34G_6errors(ptr %ptr.0, i64 %ptr.1, ptr align 8 %0) unnamed_addr #0 !guid !534 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %ptr.1, 1
  ret { ptr, i64 } %2

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs4mnquxVp34G_6errors(ptr %ptr.0, ptr align 8 %0) #27
  br label %bb3
}

; <core::ptr::non_null::NonNull<[u8]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCs4mnquxVp34G_6errors(ptr %r.0, i64 %r.1) unnamed_addr #0 !guid !535 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs4mnquxVp34G_6errors(ptr %r) unnamed_addr #0 !guid !536 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCs4mnquxVp34G_6errors(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !537 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs4mnquxVp34G_6errors(ptr %ptr, ptr align 8 %0) #27
  br label %bb3
}

; <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %subtracted) unnamed_addr #0 !guid !538 {
start:
; call <*mut u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #25
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs4mnquxVp34G_6errors(ptr %ptr) unnamed_addr #0 !guid !539 {
start:
  %_0 = alloca [8 x i8], align 8
; call <*mut u8>::is_null
  %_2 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCs4mnquxVp34G_6errors(ptr %ptr) #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCs4mnquxVp34G_6errors(ptr %ptr, ptr align 8 @alloc_e469ef44bf39c45bcb672a4bc963b9cb) #25
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <core::ptr::non_null::NonNull<u8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refCs4mnquxVp34G_6errors(ptr %r) unnamed_addr #0 !guid !540 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<usize>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !541 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCs4mnquxVp34G_6errors(ptr align 4 %r) unnamed_addr #0 !guid !542 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs4mnquxVp34G_6errors(ptr align 8 %r) unnamed_addr #0 !guid !543 {
start:
  ret ptr %r
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs4mnquxVp34G_6errors(i64 %val) unnamed_addr #0 !guid !544 {
start:
  ret i64 %val
}

; <core::num::niche_types::UsizeNoHighBit>::as_inner
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs4mnquxVp34G_6errors(i64 %self) unnamed_addr #0 !guid !545 {
start:
  ret i64 %self
}

; <core::slice::iter::Iter<u8>>::next_back_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs2H_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhE19next_back_uncheckedCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !546 {
start:
  %_0.i.i = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %_3 = alloca [8 x i8], align 8
  %_10.i = getelementptr inbounds i8, ptr %self, i64 8
  %_12.i = load ptr, ptr %_10.i, align 8
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_2.i, label %bb2.i, label %_RNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg.exit

bb2.i:                                            ; preds = %start
; call <isize>::unchecked_neg::precondition_check
  call void @_RNvNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg18precondition_checkCs4mnquxVp34G_6errors(i64 1, ptr align 8 @alloc_91bad026f8df33e69ba6aca06b3a4c87) #27
  br label %_RNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg.exit

_RNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg.exit: ; preds = %start, %bb2.i
  %_3.i1.i = getelementptr inbounds i8, ptr %_12.i, i64 -1
  store ptr %_3.i1.i, ptr %_0.i.i, align 8
  %0 = load ptr, ptr %_0.i.i, align 8
  store ptr %0, ptr %_10.i, align 8
  %1 = load ptr, ptr %_10.i, align 8
  store ptr %1, ptr %_0.i, align 8
  %2 = load ptr, ptr %_0.i, align 8
  store ptr %2, ptr %_3, align 8
  %_4.i = load ptr, ptr %_3, align 8
  ret ptr %_4.i
}

; <alloc::raw_vec::RawVecInner>::needs_to_grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #0 !guid !547 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %elem_layout) #25
; call <alloc::raw_vec::RawVecInner>::capacity
  %_6 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %_7) #25
  %_0.i = sub i64 %_6, %len
  %_0 = icmp ugt i64 %additional, %_0.i
  ret i1 %_0
}

; <alloc::raw_vec::RawVecInner>::current_memory
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %0, i64 %1) unnamed_addr #0 !guid !548 {
start:
  %_17 = alloca [24 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %elem_layout) #25
  %_3 = icmp eq i64 %_4, 0
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_7 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs4mnquxVp34G_6errors(i64 %_8) #25
  %_6 = icmp eq i64 %_7, 0
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb2, %start
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %3, align 8
  br label %bb12

bb5:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %elem_layout) #25
  %_13 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_12 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs4mnquxVp34G_6errors(i64 %_13) #25
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

bb2.i:                                            ; preds = %bb5
; call <usize>::unchecked_mul::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCs4mnquxVp34G_6errors(i64 %_10, i64 %_12, ptr align 8 @alloc_85bcb8feb56634093aba2b8644936af9) #27
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit: ; preds = %bb5, %bb2.i
  %_0.i = mul nuw i64 %_10, %_12
; call <core::alloc::layout::Layout>::align
  %_15 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs4mnquxVp34G_6errors(ptr align 8 %elem_layout) #25
; call <core::alloc::layout::Layout>::from_size_align_unchecked
  %4 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCs4mnquxVp34G_6errors(i64 %_0.i, i64 %_15, ptr align 8 @alloc_17de00c3327446355700bd7db4b78ded) #25
  %layout.0 = extractvalue { i64, i64 } %4, 0
  %layout.1 = extractvalue { i64, i64 } %4, 1
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_19 = load ptr, ptr %5, align 8
; call <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
  %_18 = call ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCs4mnquxVp34G_6errors(ptr %_19, ptr align 8 @alloc_b9419d44288097f84422e162822ba96e) #25
  store ptr %_18, ptr %_17, align 8
  %6 = getelementptr inbounds i8, ptr %_17, i64 8
  store i64 %layout.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %layout.1, ptr %7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_17, i64 24, i1 false)
  br label %bb12

bb12:                                             ; preds = %bb4, %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit
  ret void
}

; <alloc::raw_vec::RawVecInner>::from_nonnull_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15from_nonnull_inCs4mnquxVp34G_6errors(ptr %ptr, i64 %cap) unnamed_addr #0 personality ptr @rust_eh_personality !guid !549 {
start:
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_4 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCs4mnquxVp34G_6errors(ptr %ptr) #25
  br label %bb1

bb1:                                              ; preds = %start
  %0 = insertvalue { i64, ptr } poison, i64 %cap, 0
  %1 = insertvalue { i64, ptr } %0, ptr %_4, 1
  ret { i64, ptr } %1

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::set_ptr_and_cap
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15set_ptr_and_capCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %ptr.0, i64 %ptr.1, i64 %cap) unnamed_addr #0 !guid !550 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_5 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs4mnquxVp34G_6errors(ptr %ptr.0, i64 %ptr.1) #25
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_4 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCs4mnquxVp34G_6errors(ptr %_5) #25
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_4, ptr %0, align 8
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_6 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs4mnquxVp34G_6errors(i64 %cap) #25
  store i64 %_6, ptr %self, align 8
  ret void
}

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inCs4mnquxVp34G_6errors(ptr %ptr, i64 %cap) unnamed_addr #0 personality ptr @rust_eh_personality !guid !551 {
start:
; call <core::ptr::unique::Unique<u8>>::new_unchecked
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13new_uncheckedCs4mnquxVp34G_6errors(ptr %ptr) #25
  br label %bb1

bb1:                                              ; preds = %start
  %0 = insertvalue { i64, ptr } poison, i64 %cap, 0
  %1 = insertvalue { i64, ptr } %0, ptr %_4, 1
  ret { i64, ptr } %1

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCs4mnquxVp34G_6errors(i64 %align) unnamed_addr #0 personality ptr @rust_eh_personality !guid !552 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs4mnquxVp34G_6errors(i64 %align) #25
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_4 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs4mnquxVp34G_6errors(i64 %_5) #25
  br label %bb2

bb2:                                              ; preds = %bb1
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %ptr = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCs4mnquxVp34G_6errors(ptr %_4) #25
  br label %bb3

bb3:                                              ; preds = %bb2
  %0 = insertvalue { i64, ptr } { i64 0, ptr poison }, ptr %ptr, 1
  ret { i64, ptr } %0

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 !guid !553 {
start:
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_5 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) #25
  br i1 %_5, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
  call void @_RINvNvMs2_NtCs7CppTae75M1_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4mnquxVp34G_6errors(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1)
  br label %bb3
}

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %elem_size) unnamed_addr #0 !guid !554 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 %elem_size, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs4mnquxVp34G_6errors(i64 %_4) #25
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <alloc::raw_vec::RawVecInner>::allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner9allocatorCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !555 {
start:
  %_0 = getelementptr inbounds i8, ptr %self, i64 16
  ret ptr %_0
}

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs4mnquxVp34G_6errors(ptr %self, i64 %len) unnamed_addr #0 !guid !556 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
  %0 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCs4mnquxVp34G_6errors(ptr %self, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj4_E13new_uncheckedCs4mnquxVp34G_6errors(ptr sret([80 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 8 %data) unnamed_addr #0 !guid !557 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %data, i64 64, i1 false)
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj7_E13new_uncheckedCs4mnquxVp34G_6errors(ptr sret([128 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 8 %data) unnamed_addr #0 !guid !558 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %data, i64 112, i1 false)
  ret void
}

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #1 !guid !559 {
start:
  %_3 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #25
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %ptr = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %layout.0 = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %layout.1 = load i64, ptr %5, align 8
  %_9 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs4mnquxVp34G_6errors(ptr %_9, ptr %ptr, i64 %layout.0, i64 %layout.1) #25
  br label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <isize>::overflowing_neg
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i1 } @_RNvMs3_NtCsl10jNU3mE6R_4core3numi15overflowing_negCs4mnquxVp34G_6errors(i64 %self) unnamed_addr #0 !guid !560 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp eq i64 %self, -9223372036854775808
  br i1 %_3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_4 = sub i64 0, %self
  store i64 %_4, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 0, ptr %2, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 27670116110564327424, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i8, ptr %4, align 8
  %6 = trunc nuw i8 %5 to i1
  %7 = insertvalue { i64, i1 } poison, i64 %3, 0
  %8 = insertvalue { i64, i1 } %7, i1 %6, 1
  ret { i64, i1 } %8
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::grow_one
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE8grow_oneCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #3 !guid !561 {
start:
; call <alloc::raw_vec::RawVecInner>::grow_one
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneCs4mnquxVp34G_6errors(ptr align 8 %self, i64 8, i64 24) #25
  ret void
}

; <alloc::raw_vec::RawVec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCs4mnquxVp34G_6errors(i64 %capacity) unnamed_addr #0 !guid !562 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs4mnquxVp34G_6errors(i64 %capacity, i64 1, i64 1) #25
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::as_statically_known_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments23as_statically_known_strCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !563 {
start:
  %s = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::fmt::Arguments>::as_str
  %0 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %s, align 8
  %3 = getelementptr inbounds i8, ptr %s, i64 8
  store i64 %2, ptr %3, align 8
; call <core::option::Option<&str>>::is_some
  %_4 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionReE7is_someCs4mnquxVp34G_6errors(ptr align 8 %s) #25
  %_3 = call i1 @llvm.is.constant.i1(i1 %_4)
  br i1 %_3, label %bb4, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb4:                                              ; preds = %start
  %4 = load ptr, ptr %s, align 8
  %5 = getelementptr inbounds i8, ptr %s, i64 8
  %6 = load i64, ptr %5, align 8
  store ptr %4, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %6, ptr %7, align 8
  br label %bb6

bb6:                                              ; preds = %bb4, %bb5
  %8 = load ptr, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  %10 = load i64, ptr %9, align 8
  %11 = insertvalue { ptr, i64 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %10, 1
  ret { ptr, i64 } %12
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !564 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECs4mnquxVp34G_6errors(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #25
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs4mnquxVp34G_6errors(ptr %_7.0, i64 %_7.1) #25
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !565 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs4mnquxVp34G_6errors(ptr %s.0, i64 %s.1) #25
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u8>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_addCs4mnquxVp34G_6errors(i8 %self, i8 %rhs) unnamed_addr #0 !guid !566 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %_5.0 = add i8 %self, %rhs
  %_5.1 = icmp ult i8 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i8 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_6, ptr %2, align 1
  store i8 1, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  %5 = getelementptr inbounds i8, ptr %_0, i64 1
  %6 = load i8, ptr %5, align 1
  %7 = insertvalue { i1, i8 } poison, i1 %4, 0
  %8 = insertvalue { i1, i8 } %7, i8 %6, 1
  ret { i1, i8 } %8
}

; <u8>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCs4mnquxVp34G_6errors(i8 %self, i8 %rhs) unnamed_addr #0 !guid !567 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <u8>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_subCs4mnquxVp34G_6errors(i8 %self, i8 %rhs) unnamed_addr #0 !guid !568 {
start:
  %_0 = alloca [2 x i8], align 1
  %_3 = icmp ult i8 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i8 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_4, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i8, ptr %_0, align 1
  %2 = trunc nuw i8 %1 to i1
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  %4 = load i8, ptr %3, align 1
  %5 = insertvalue { i1, i8 } poison, i1 %2, 0
  %6 = insertvalue { i1, i8 } %5, i8 %4, 1
  ret { i1, i8 } %6
}

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !569 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
  %_2 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) #25
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !570 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_0 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1) #25
  ret ptr %_0
}

; <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCs4mnquxVp34G_6errors(ptr %data, i64 %len) unnamed_addr #0 !guid !571 {
start:
; call <*mut u8>::cast_slice
  %0 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCs4mnquxVp34G_6errors(ptr %data, i64 %len) #25
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCs4mnquxVp34G_6errors(ptr %_3.0, i64 %_3.1, ptr align 8 @alloc_af3623564924928dd3d563c9d84a8a0e) #25
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::slice::iter::Iter<&str>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterReE3newCs4mnquxVp34G_6errors(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !572 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[&str]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSReE8from_refCs4mnquxVp34G_6errors(ptr align 8 %slice.0, i64 %slice.1) #25
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[&str]>>::cast::<&str>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSReE4castBV_ECs4mnquxVp34G_6errors(ptr %_4.0, i64 %_4.1) #25
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw { ptr, i64 }, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCs4mnquxVp34G_6errors(ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !573 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[u8]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCs4mnquxVp34G_6errors(ptr %slice.0, i64 %slice.1) #25
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs4mnquxVp34G_6errors(ptr %_4.0, i64 %_4.1) #25
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i8, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE8as_sliceCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !574 {
start:
  %_5.i = alloca [8 x i8], align 8
  %_4.i = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_9.i = load ptr, ptr %0, align 8
  %_10.i = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %_9.i, ptr %_10.i) #25
  store i64 %1, ptr %_5.i, align 8
  %2 = load i64, ptr %_5.i, align 8
; call core::slice::raw::from_raw_parts::<u8>
  %3 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECs4mnquxVp34G_6errors(ptr %_4.i, i64 %2, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #25
  %_0.0.i = extractvalue { ptr, i64 } %3, 0
  %_0.1.i = extractvalue { ptr, i64 } %3, 1
  %_0.0 = extractvalue { ptr, i64 } %3, 0
  %_0.1 = extractvalue { ptr, i64 } %3, 1
  %4 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_0.1, 1
  ret { ptr, i64 } %5
}

; <alloc::raw_vec::RawVecInner>::finish_grow
; Function Attrs: cold nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %cap, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #4 !guid !575 {
start:
  %old_layout = alloca [16 x i8], align 8
  %_11 = alloca [24 x i8], align 8
  %memory = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %new_layout = alloca [16 x i8], align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_6, i64 %cap, i64 %elem_layout.0, i64 %elem_layout.1) #25
; call <core::result::Result<core::alloc::layout::Layout, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtB7_5alloc6layout6LayoutNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %_6) #25
  %_7 = load i64, ptr %_5, align 8
  %0 = trunc nuw i64 %_7 to i1
  br i1 %0, label %bb5, label %bb4

bb5:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_5, i64 8
  %residual.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %residual.1 = load i64, ptr %2, align 8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, i64 %residual.0, i64 %residual.1, ptr align 8 @alloc_9c2bc03755f157121052fe1398e358d1) #25
  br label %bb13

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  %val.0 = load i64, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  %val.1 = load i64, ptr %4, align 8
  store i64 %val.0, ptr %new_layout, align 8
  %5 = getelementptr inbounds i8, ptr %new_layout, i64 8
  store i64 %val.1, ptr %5, align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_11, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #25
  %6 = getelementptr inbounds i8, ptr %_11, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = icmp eq i64 %7, 0
  %_12 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_12 to i1
  br i1 %9, label %bb7, label %bb11

bb7:                                              ; preds = %bb4
  %ptr = load ptr, ptr %_11, align 8
  %10 = getelementptr inbounds i8, ptr %_11, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = getelementptr inbounds i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  store i64 %11, ptr %old_layout, align 8
  %14 = getelementptr inbounds i8, ptr %old_layout, i64 8
  store i64 %13, ptr %14, align 8
; call <core::alloc::layout::Layout>::align
  %_17 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs4mnquxVp34G_6errors(ptr align 8 %old_layout) #25
; call <core::alloc::layout::Layout>::align
  %_19 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs4mnquxVp34G_6errors(ptr align 8 %new_layout) #25
  %_16 = icmp eq i64 %_17, %_19
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb7
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs4mnquxVp34G_6errors(i1 zeroext %_16, ptr align 8 @alloc_02ed5979549ad728dcb1e213f787b0ae) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb7, %bb2.i
  %_21 = getelementptr inbounds i8, ptr %self, i64 16
  %15 = load i64, ptr %old_layout, align 8
  %16 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = load i64, ptr %new_layout, align 8
  %19 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %20 = load i64, ptr %19, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::grow
  %21 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator4growCs4mnquxVp34G_6errors(ptr %_21, ptr %ptr, i64 %15, i64 %17, i64 %18, i64 %20) #25
  %22 = extractvalue { ptr, i64 } %21, 0
  %23 = extractvalue { ptr, i64 } %21, 1
  store ptr %22, ptr %memory, align 8
  %24 = getelementptr inbounds i8, ptr %memory, i64 8
  store i64 %23, ptr %24, align 8
  br label %bb12

bb11:                                             ; preds = %bb4
  %_22 = getelementptr inbounds i8, ptr %self, i64 16
  %25 = load i64, ptr %new_layout, align 8
  %26 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %27 = load i64, ptr %26, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %28 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs4mnquxVp34G_6errors(ptr %_22, i64 %25, i64 %27) #25
  %29 = extractvalue { ptr, i64 } %28, 0
  %30 = extractvalue { ptr, i64 } %28, 1
  store ptr %29, ptr %memory, align 8
  %31 = getelementptr inbounds i8, ptr %memory, i64 8
  store i64 %30, ptr %31, align 8
  br label %bb12

bb12:                                             ; preds = %bb11, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_23.0 = load ptr, ptr %memory, align 8
  %32 = getelementptr inbounds i8, ptr %memory, i64 8
  %_23.1 = load i64, ptr %32, align 8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError>>::map_err::<alloc::collections::TryReserveError, <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtNtB5_3ptr8non_null7NonNullShENtNtB5_5alloc10AllocErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvMs5_NtB1S_7raw_vecNtB2O_11RawVecInner11finish_grow0ECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %_23.0, i64 %_23.1, ptr align 8 %new_layout) #25
  br label %bb13

bb13:                                             ; preds = %bb5, %bb12
  ret void

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::grow_amortized
; Function Attrs: nonlazybind uwtable
define internal { i64, i64 } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #1 !guid !576 {
start:
  %_26 = alloca [24 x i8], align 8
  %_25 = alloca [24 x i8], align 8
  %_11 = alloca [16 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %elem_layout) #25
  %_5 = icmp eq i64 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; call <usize>::checked_add
  %3 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCs4mnquxVp34G_6errors(i64 %len, i64 %additional) #25
  %_12.0 = extractvalue { i64, i64 } %3, 0
  %_12.1 = extractvalue { i64, i64 } %3, 1
; call <core::option::Option<usize>>::ok_or::<alloc::collections::TryReserveErrorKind>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE5ok_orNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_11, i64 %_12.0, i64 %_12.1, i64 0, i64 undef) #25
; call <core::result::Result<usize, alloc::collections::TryReserveErrorKind> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultjNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_10, ptr align 8 %_11) #25
  %4 = load i64, ptr %_10, align 8
  %5 = icmp eq i64 %4, -1
  %_14 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_14 to i1
  br i1 %6, label %bb10, label %bb9

bb2:                                              ; preds = %start
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs4mnquxVp34G_6errors(i64 0, i64 undef, ptr align 8 @alloc_289c68237f406b28ee6ba245eefcd312) #25
  %_8.0 = extractvalue { i64, i64 } %7, 0
  %_8.1 = extractvalue { i64, i64 } %7, 1
  store i64 %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8.1, ptr %8, align 8
  br label %bb21

bb10:                                             ; preds = %bb4
  %residual.02 = load i64, ptr %_10, align 8
  %9 = getelementptr inbounds i8, ptr %_10, i64 8
  %residual.13 = load i64, ptr %9, align 8
; call <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveErrorKind>>>::from_residual
  %10 = call { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtBN_19TryReserveErrorKindEE13from_residualCs4mnquxVp34G_6errors(i64 %residual.02, i64 %residual.13, ptr align 8 @alloc_91dabd4c1d2514ecf79277c06422ef65) #25
  %11 = extractvalue { i64, i64 } %10, 0
  %12 = extractvalue { i64, i64 } %10, 1
  store i64 %11, ptr %_0, align 8
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %12, ptr %13, align 8
  br label %bb21

bb9:                                              ; preds = %bb4
  %14 = getelementptr inbounds i8, ptr %_10, i64 8
  %required_cap = load i64, ptr %14, align 8
  %_20 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_19 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs4mnquxVp34G_6errors(i64 %_20) #25
  %_18 = mul i64 %_19, 2
; call core::cmp::max::<usize>
  %cap = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECs4mnquxVp34G_6errors(i64 %_18, i64 %required_cap) #25
; call <core::alloc::layout::Layout>::size
  %_23 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %elem_layout) #25
; call alloc::raw_vec::min_non_zero_cap
  %_22 = call i64 @_RNvNtCs7CppTae75M1_5alloc7raw_vec16min_non_zero_cap(i64 %_23)
; call core::cmp::max::<usize>
  %cap1 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECs4mnquxVp34G_6errors(i64 %_22, i64 %cap) #25
  %15 = load i64, ptr %elem_layout, align 8
  %16 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %17 = load i64, ptr %16, align 8
; call <alloc::raw_vec::RawVecInner>::finish_grow
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_26, ptr align 8 %self, i64 %cap1, i64 %15, i64 %17)
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_25, ptr align 8 %_26) #25
  %_28 = load i64, ptr %_25, align 8
  %18 = trunc nuw i64 %_28 to i1
  br i1 %18, label %bb19, label %bb18

bb19:                                             ; preds = %bb9
  %19 = getelementptr inbounds i8, ptr %_25, i64 8
  %residual.0 = load i64, ptr %19, align 8
  %20 = getelementptr inbounds i8, ptr %19, i64 8
  %residual.1 = load i64, ptr %20, align 8
; call <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
  %21 = call { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCs4mnquxVp34G_6errors(i64 %residual.0, i64 %residual.1, ptr align 8 @alloc_8b924c2e6c70ef47ed23cadbb79c2da4) #25
  %22 = extractvalue { i64, i64 } %21, 0
  %23 = extractvalue { i64, i64 } %21, 1
  store i64 %22, ptr %_0, align 8
  %24 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %23, ptr %24, align 8
  br label %bb21

bb18:                                             ; preds = %bb9
  %25 = getelementptr inbounds i8, ptr %_25, i64 8
  %ptr.0 = load ptr, ptr %25, align 8
  %26 = getelementptr inbounds i8, ptr %25, i64 8
  %ptr.1 = load i64, ptr %26, align 8
; call <alloc::raw_vec::RawVecInner>::set_ptr_and_cap
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15set_ptr_and_capCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %ptr.0, i64 %ptr.1, i64 %cap1) #25
  store i64 -1, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb2, %bb10, %bb19, %bb18
  %27 = load i64, ptr %_0, align 8
  %28 = getelementptr inbounds i8, ptr %_0, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { i64, i64 } poison, i64 %27, 0
  %31 = insertvalue { i64, i64 } %30, i64 %29, 1
  ret { i64, i64 } %31

bb8:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::try_allocate_in
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, i64 %capacity, i1 zeroext %init, i64 %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !577 {
start:
  %_32 = alloca [1 x i8], align 1
  %_31 = alloca [1 x i8], align 1
  %result = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %layout = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  %alloc = alloca [0 x i8], align 1
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_31, align 1
  store i8 0, ptr %_32, align 1
  store i8 1, ptr %_31, align 1
  %3 = load i64, ptr %elem_layout, align 8
  %4 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_6, i64 %capacity, i64 %3, i64 %5) #25
  br label %bb1

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %_6, align 8
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs4mnquxVp34G_6errors(i64 0, i64 undef, ptr align 8 @alloc_099d793709fa470a3d5e7c79c938e035) #25
  %_9.0 = extractvalue { i64, i64 } %7, 0
  %_9.1 = extractvalue { i64, i64 } %7, 1
  br label %bb5

bb4:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %_6, i64 8
  %layout.0 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %layout.1 = load i64, ptr %9, align 8
  store i64 %layout.0, ptr %layout, align 8
  %10 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %layout.1, ptr %10, align 8
; call <core::alloc::layout::Layout>::size
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
  br label %bb6

bb6:                                              ; preds = %bb4
  %_11 = icmp eq i64 %_12, 0
  br i1 %_11, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  %_19 = zext i1 %init to i64
  %11 = trunc nuw i64 %_19 to i1
  br i1 %11, label %bb11, label %bb12

bb7:                                              ; preds = %bb6
  store i8 0, ptr %_31, align 1
  store i8 1, ptr %_32, align 1
; call <core::alloc::layout::Layout>::alignment
  %_16 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs4mnquxVp34G_6errors(ptr align 8 %elem_layout) #25
  br label %bb8

bb11:                                             ; preds = %bb10
  %12 = load i64, ptr %layout, align 8
  %13 = getelementptr inbounds i8, ptr %layout, i64 8
  %14 = load i64, ptr %13, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
  %15 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCs4mnquxVp34G_6errors(ptr %alloc, i64 %12, i64 %14) #25
  %16 = extractvalue { ptr, i64 } %15, 0
  %17 = extractvalue { ptr, i64 } %15, 1
  store ptr %16, ptr %result, align 8
  %18 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb28

bb12:                                             ; preds = %bb10
  %19 = load i64, ptr %layout, align 8
  %20 = getelementptr inbounds i8, ptr %layout, i64 8
  %21 = load i64, ptr %20, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %22 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs4mnquxVp34G_6errors(ptr %alloc, i64 %19, i64 %21) #25
  %23 = extractvalue { ptr, i64 } %22, 0
  %24 = extractvalue { ptr, i64 } %22, 1
  store ptr %23, ptr %result, align 8
  %25 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %24, ptr %25, align 8
  br label %bb29

bb29:                                             ; preds = %bb12
  br label %bb13

bb13:                                             ; preds = %bb28, %bb29
  %26 = load ptr, ptr %result, align 8
  %27 = getelementptr inbounds i8, ptr %result, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = ptrtoint ptr %26 to i64
  %30 = icmp eq i64 %29, 0
  %_22 = select i1 %30, i64 1, i64 0
  %31 = trunc nuw i64 %_22 to i1
  br i1 %31, label %bb14, label %bb15

bb28:                                             ; preds = %bb11
  br label %bb13

bb14:                                             ; preds = %bb13
  %_25.0 = load i64, ptr %layout, align 8
  %32 = getelementptr inbounds i8, ptr %layout, i64 8
  %_25.1 = load i64, ptr %32, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %33 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs4mnquxVp34G_6errors(i64 %_25.0, i64 %_25.1, ptr align 8 @alloc_33dfd402c6ecbe2e6a32e76edf5f31a5) #25
  %_24.0 = extractvalue { i64, i64 } %33, 0
  %_24.1 = extractvalue { i64, i64 } %33, 1
  br label %bb16

bb15:                                             ; preds = %bb13
  %ptr.0 = load ptr, ptr %result, align 8
  %34 = getelementptr inbounds i8, ptr %result, i64 8
  %ptr.1 = load i64, ptr %34, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_28 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs4mnquxVp34G_6errors(ptr %ptr.0, i64 %ptr.1) #25
  br label %bb17

bb17:                                             ; preds = %bb15
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_27 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCs4mnquxVp34G_6errors(ptr %_28) #25
  br label %bb18

bb18:                                             ; preds = %bb17
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_29 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs4mnquxVp34G_6errors(i64 %capacity) #25
  br label %bb19

bb19:                                             ; preds = %bb18
  store i8 0, ptr %_31, align 1
  %35 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29, ptr %35, align 8
  %36 = getelementptr inbounds i8, ptr %35, i64 8
  store ptr %_27, ptr %36, align 8
  store i64 0, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb23, %bb20, %bb19
  ret void

bb16:                                             ; preds = %bb14
  %37 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_24.0, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %37, i64 8
  store i64 %_24.1, ptr %38, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb20:                                             ; preds = %bb5, %bb9, %bb16
  %39 = load i8, ptr %_31, align 1
  %40 = trunc nuw i8 %39 to i1
  br i1 %40, label %bb23, label %bb21

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_32, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %41 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCs4mnquxVp34G_6errors(i64 %_16) #25
  %_14.0 = extractvalue { i64, ptr } %41, 0
  %_14.1 = extractvalue { i64, ptr } %41, 1
  br label %bb9

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_32, align 1
  %42 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_14.0, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %42, i64 8
  store ptr %_14.1, ptr %43, align 8
  store i64 0, ptr %_0, align 8
  br label %bb20

bb5:                                              ; preds = %bb3
  %44 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_9.0, ptr %44, align 8
  %45 = getelementptr inbounds i8, ptr %44, i64 8
  store i64 %_9.1, ptr %45, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb23:                                             ; preds = %bb20
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable

bb25:                                             ; No predecessors!
  unreachable

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs4mnquxVp34G_6errors(i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !578 {
start:
  %this = alloca [16 x i8], align 8
  %_4 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::try_allocate_in
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_4, i64 %capacity, i1 zeroext false, i64 %elem_layout.0, i64 %elem_layout.1)
  %_6 = load i64, ptr %_4, align 8
  %0 = trunc nuw i64 %_6 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  %err.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %err.1 = load i64, ptr %2, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #28
  unreachable

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load ptr, ptr %5, align 8
  store i64 %4, ptr %this, align 8
  %7 = getelementptr inbounds i8, ptr %this, i64 8
  store ptr %6, ptr %7, align 8
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_10 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCs4mnquxVp34G_6errors(ptr align 8 %this, i64 0, i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) #25
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = xor i1 %_10, true
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb5
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs4mnquxVp34G_6errors(i1 zeroext %_9, ptr align 8 @alloc_51424262946dd0794fad6132df857999) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb5, %bb2.i
  br label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_0.0 = load i64, ptr %this, align 8
  %8 = getelementptr inbounds i8, ptr %this, i64 8
  %_0.1 = load ptr, ptr %8, align 8
  %9 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %10 = insertvalue { i64, ptr } %9, ptr %_0.1, 1
  ret { i64, ptr } %10

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::grow_one
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 !guid !579 {
start:
  %_3 = alloca [16 x i8], align 8
  %_5 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_4 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs4mnquxVp34G_6errors(i64 %_5) #25
; call <alloc::raw_vec::RawVecInner>::grow_amortized
  %0 = call { i64, i64 } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %_4, i64 1, i64 %elem_layout.0, i64 %elem_layout.1)
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_3, align 8
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = icmp eq i64 %4, -1
  %_6 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_6 to i1
  br i1 %8, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %err.0 = load i64, ptr %_3, align 8
  %9 = getelementptr inbounds i8, ptr %_3, i64 8
  %err.1 = load i64, ptr %9, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #28
  unreachable

bb4:                                              ; preds = %start
  ret void

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE23into_raw_with_allocatorCs4mnquxVp34G_6errors(ptr align 8 %b.0, i64 %b.1) unnamed_addr #0 !guid !580 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSINtNtB6_6result6ResultlNtNtB19_6string6StringEEE3newCs4mnquxVp34G_6errors(ptr align 8 %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSINtNtB6_6result6ResultlNtNtB19_6string6StringEEE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSINtNtB6_6result6ResultlNtNtB19_6string6StringEEE6as_refCs4mnquxVp34G_6errors(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEE4nextCs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !581 {
start:
; call <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %self.0) #25
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_5.0 = getelementptr inbounds i8, ptr %self.0, i64 16
; call <core::option::Option<usize>>::map::<&str, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next::{closure#0}>
  %1 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapReNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBY_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECs4mnquxVp34G_6errors(i64 %_2.0, i64 %_2.1, ptr align 8 %_5.0, i64 %self.1) #25
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs4mnquxVp34G_6errors(ptr %self) unnamed_addr #0 !guid !582 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCs4mnquxVp34G_6errors(i64 %self, i64 %rhs) unnamed_addr #0 !guid !583 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5.0 = add i64 %self, %rhs
  %_5.1 = icmp ult i64 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs4mnquxVp34G_6errors(i64 %self, i64 %rhs) unnamed_addr #0 !guid !584 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs4mnquxVp34G_6errors(i64 %self, i64 %other) unnamed_addr #0 !guid !585 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs4mnquxVp34G_6errors(i32 %_0.i) #25
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE4pushCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %value) unnamed_addr #0 !guid !586 {
start:
  %0 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %value, i64 24, i1 false)
; call <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::push_mut
  %_3 = call align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE8push_mutCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %0) #25
  ret void
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::push_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE8push_mutCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %value) unnamed_addr #0 personality ptr @rust_eh_personality !guid !587 {
start:
  %0 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %_12 = alloca [24 x i8], align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %1, align 8
; invoke <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::capacity
  %_5 = invoke i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE8capacityCs4mnquxVp34G_6errors(ptr align 8 %self)
          to label %bb1 unwind label %cleanup

bb9:                                              ; preds = %cleanup
  %2 = load i8, ptr %_13, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb8, label %bb7

cleanup:                                          ; preds = %bb3, %bb2, %start
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb9

bb1:                                              ; preds = %start
  %_4 = icmp eq i64 %len, %_5
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb10, %bb1
; invoke <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::as_mut_ptr
  %_10 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE10as_mut_ptrCs4mnquxVp34G_6errors(ptr align 8 %self)
          to label %bb4 unwind label %cleanup

bb2:                                              ; preds = %bb1
; invoke <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::grow_one
  invoke void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE8grow_oneCs4mnquxVp34G_6errors(ptr align 8 %self)
          to label %bb10 unwind label %cleanup

bb10:                                             ; preds = %bb2
  br label %bb3

bb4:                                              ; preds = %bb3
  %_0.i = getelementptr inbounds nuw %"core::result::Result<i32, alloc::string::String>", ptr %_10, i64 %len
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_13, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_12, ptr align 8 %value, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0.i, ptr align 8 %_12, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb5
  %8 = getelementptr inbounds i8, ptr %self, i64 16
  %9 = add i64 %len, 1
  store i64 %9, ptr %8, align 8
  ret ptr %_0.i

bb7:                                              ; preds = %bb8, %bb9
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14

bb8:                                              ; preds = %bb9
; invoke core::ptr::drop_glue::<core::result::Result<i32, alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %value) #23
          to label %bb7 unwind label %terminate

terminate:                                        ; preds = %bb8
  %15 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable
}

; <alloc::vec::Vec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !588 {
start:
; call <alloc::raw_vec::RawVec<u8>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCs4mnquxVp34G_6errors(i64 %capacity) #25
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs4mnquxVp34G_6errors(i8 %0) unnamed_addr #0 !guid !589 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs4mnquxVp34G_6errors(ptr %self) #25
  ret i32 %_0
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE10as_mut_ptrCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !590 {
start:
; call <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE3ptrCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE17from_raw_parts_inCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !591 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs4mnquxVp34G_6errors(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #27
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE17from_raw_parts_inCs4mnquxVp34G_6errors(ptr %ptr, i64 %capacity) #25
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE3lenCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !592 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 384307168202282325
  ret i64 %len
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE9allocatorCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !593 {
start:
; call <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::allocator
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE9allocatorCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !594 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::append_elements
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE15append_elementsCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !595 {
start:
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECs4mnquxVp34G_6errors(ptr %other.0, i64 %other.1) #25
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %_0.i)
; call <alloc::vec::Vec<u8>>::append_elements_unreserved
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE26append_elements_unreservedCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %other.0, i64 %other.1) #25
  ret void
}

; <alloc::vec::Vec<u8>>::append_elements_unreserved
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE26append_elements_unreservedCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !596 {
start:
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECs4mnquxVp34G_6errors(ptr %other.0, i64 %other.1) #25
; call <alloc::vec::Vec<u8>>::len
  %len = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_6 = icmp ugt i64 %_0.i1, 0
  br i1 %_6, label %bb3, label %bb6

bb6:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4mnquxVp34G_6errors.exit, %start
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i64, ptr %1, align 8
  %3 = add i64 %2, %_0.i1
  store i64 %3, ptr %0, align 8
  ret void

bb3:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4mnquxVp34G_6errors.exit

bb2.i:                                            ; preds = %bb3
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs4mnquxVp34G_6errors(ptr %other.0, ptr %_0.i, i64 1, i64 1, i64 %_0.i1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #27
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4mnquxVp34G_6errors.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4mnquxVp34G_6errors.exit: ; preds = %bb3, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i, ptr align 1 %other.0, i64 %_0.i1, i1 false)
  br label %bb6
}

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !597 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 9223372036854775807
  ret i64 %len
}

; <alloc::vec::Vec<u8>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE6as_ptrCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !598 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret ptr %_2
}

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %additional) unnamed_addr #1 !guid !599 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<u8>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE7reserveCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %_5, i64 %additional) #25
  ret void
}

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !600 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCs4mnquxVp34G_6errors(ptr align 8 %self) #25
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs4mnquxVp34G_6errors(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #27
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !601 {
start:
; call <alloc::vec::Vec<u8>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE6as_ptrCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !602 {
start:
; call <alloc::raw_vec::RawVec<u8>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret i64 %_0
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitReEj4_EE4dropCs4mnquxVp34G_6errors(ptr align 8 %slot) unnamed_addr #0 !guid !603 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitReEj4_EECs4mnquxVp34G_6errors(ptr align 8 %_3)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitReEj7_EE4dropCs4mnquxVp34G_6errors(ptr align 8 %slot) unnamed_addr #0 !guid !604 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj7_EE6as_mutCs4mnquxVp34G_6errors(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitReEj7_EECs4mnquxVp34G_6errors(ptr align 8 %_3)
  ret void
}

; <*mut core::result::Result<i32, alloc::string::String>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtB8_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringE10cast_sliceCs4mnquxVp34G_6errors(ptr %self, i64 %len) unnamed_addr #0 !guid !605 {
start:
; call core::ptr::slice_from_raw_parts_mut::<core::result::Result<i32, alloc::string::String>>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %self, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCs4mnquxVp34G_6errors(ptr %self, i64 %len) unnamed_addr #0 !guid !606 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECs4mnquxVp34G_6errors(ptr %self, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*const u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh10cast_sliceCs4mnquxVp34G_6errors(ptr %self, i64 %len) unnamed_addr #0 !guid !607 {
start:
; call core::ptr::slice_from_raw_parts::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECs4mnquxVp34G_6errors(ptr %self, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::fmt::Formatter>::write_fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #0 !guid !608 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %fmt = alloca [16 x i8], align 8
  store ptr %0, ptr %fmt, align 8
  %2 = getelementptr inbounds i8, ptr %fmt, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_statically_known_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments23as_statically_known_strCs4mnquxVp34G_6errors(ptr align 8 %fmt) #25
  %4 = extractvalue { ptr, i64 } %3, 0
  %5 = extractvalue { ptr, i64 } %3, 1
  store ptr %4, ptr %_3, align 8
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %5, ptr %6, align 8
  %7 = load ptr, ptr %_3, align 8
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = ptrtoint ptr %7 to i64
  %11 = icmp eq i64 %10, 0
  %_5 = select i1 %11, i64 0, i64 1
  %12 = trunc nuw i64 %_5 to i1
  br i1 %12, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %s.0 = load ptr, ptr %_3, align 8
  %13 = getelementptr inbounds i8, ptr %_3, i64 8
  %s.1 = load i64, ptr %13, align 8
  %_7.0 = load ptr, ptr %self, align 8
  %14 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load ptr, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %_7.1, i64 24
  %16 = load ptr, ptr %15, align 8, !invariant.load !332, !nonnull !332
  %17 = call zeroext i1 %16(ptr %_7.0, ptr %s.0, i64 %s.1) #25
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %_8.0 = load ptr, ptr %self, align 8
  %19 = getelementptr inbounds i8, ptr %self, i64 8
  %_8.1 = load ptr, ptr %19, align 8
  %20 = load ptr, ptr %fmt, align 8
  %21 = getelementptr inbounds i8, ptr %fmt, i64 8
  %22 = load ptr, ptr %21, align 8
; call core::fmt::write
  %23 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt5write(ptr %_8.0, ptr align 8 %_8.1, ptr %20, ptr %22)
  %24 = zext i1 %23 to i8
  store i8 %24, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %25 = load i8, ptr %_0, align 1
  %26 = trunc nuw i8 %25 to i1
  ret i1 %26

bb5:                                              ; No predecessors!
  unreachable
}

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCs4mnquxVp34G_6errors(i64 %self) unnamed_addr #0 !guid !609 {
start:
  ret i64 %self
}

; <i8>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa14from_str_radixCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !610 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <i8>::from_ascii_bytes_radix_impl
  %2 = call { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa27from_ascii_bytes_radix_implCs4mnquxVp34G_6errors(ptr %_3.0, i64 %_3.1, i32 %radix) #25
  %_0.0 = extractvalue { i1, i8 } %2, 0
  %_0.1 = extractvalue { i1, i8 } %2, 1
  %3 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %4 = insertvalue { i1, i8 } %3, i8 %_0.1, 1
  ret { i1, i8 } %4
}

; <i8>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa27from_ascii_bytes_radix_implCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !611 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [2 x i8], align 1
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [2 x i8], align 1
  %_74 = alloca [2 x i8], align 1
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [2 x i8], align 1
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [1 x i8], align 1
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [2 x i8], align 1
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #29
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1) #25
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %10 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 %src.1, ptr %11, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %12 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %13 = load i8, ptr %12, align 1
  switch i8 %13, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %14, i64 8
  store i64 %rest.1, ptr %15, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %16 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %17 = sub i64 %src.1, 1
  store ptr %16, ptr %rest, align 8
  %18 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %19 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %19 to i1
  %20 = getelementptr inbounds i8, ptr %_12, i64 8
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr inbounds i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  store ptr %21, ptr %digits, align 8, !captures !612
  %24 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %23, ptr %24, align 8
  store i8 0, ptr %result, align 1
  %_24.0 = load ptr, ptr %digits, align 8
  %25 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %25, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs4mnquxVp34G_6errors.exit

bb1.i:                                            ; preds = %bb15
  %26 = icmp ule i64 %_24.1, 1
  %27 = zext i1 %26 to i8
  store i8 %27, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs4mnquxVp34G_6errors.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs4mnquxVp34G_6errors.exit: ; preds = %bb2.i, %bb1.i
  %28 = load i8, ptr %_0.i, align 1
  %29 = trunc nuw i8 %28 to i1
  br i1 %29, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %30 = load ptr, ptr %rest, align 8
  %31 = getelementptr inbounds i8, ptr %rest, i64 8
  %32 = load i64, ptr %31, align 8
  %33 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %30, ptr %33, align 8
  %34 = getelementptr inbounds i8, ptr %33, i64 8
  store i64 %32, ptr %34, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs4mnquxVp34G_6errors.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs4mnquxVp34G_6errors.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %36, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %38, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i8, ptr %result, align 1
  %39 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_105, ptr %39, align 1
  store i8 0, ptr %_0, align 1
  br label %bb53

bb42:                                             ; preds = %bb41
  %40 = load ptr, ptr %digits, align 8
  %41 = getelementptr inbounds i8, ptr %digits, i64 8
  %42 = load i64, ptr %41, align 8
  %c = getelementptr inbounds nuw i8, ptr %40, i64 0
  %43 = load ptr, ptr %digits, align 8
  %44 = getelementptr inbounds i8, ptr %digits, i64 8
  %45 = load i64, ptr %44, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %43, i64 1
  %rest.13 = sub i64 %45, 1
  %_85 = load i8, ptr %result, align 1
  %_86 = trunc i32 %radix to i8
; call <i8>::checked_mul
  %46 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs4mnquxVp34G_6errors(i8 %_85, i8 %_86) #25
  %47 = extractvalue { i1, i8 } %46, 0
  %48 = extractvalue { i1, i8 } %46, 1
  %49 = zext i1 %47 to i8
  store i8 %49, ptr %mul1, align 1
  %50 = getelementptr inbounds i8, ptr %mul1, i64 1
  store i8 %48, ptr %50, align 1
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %51 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_89, i32 %radix) #25
  %52 = extractvalue { i32, i32 } %51, 0
  %53 = extractvalue { i32, i32 } %51, 1
  store i32 %52, ptr %_88, align 4
  %54 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %53, ptr %54, align 4
  %55 = load i32, ptr %_88, align 4
  %56 = getelementptr inbounds i8, ptr %_88, i64 4
  %57 = load i32, ptr %56, align 4
  %_91 = zext i32 %55 to i64
  %58 = trunc nuw i64 %_91 to i1
  br i1 %58, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %59 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %59, align 4
  %x = trunc i32 %value to i8
  %60 = load i8, ptr %mul1, align 1
  %61 = trunc nuw i8 %60 to i1
  %62 = getelementptr inbounds i8, ptr %mul1, i64 1
  %63 = load i8, ptr %62, align 1
  %_95 = zext i1 %61 to i64
  %64 = trunc nuw i64 %_95 to i1
  br i1 %64, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %65 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %65, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb48:                                             ; preds = %bb46
  %66 = getelementptr inbounds i8, ptr %mul1, i64 1
  %value4 = load i8, ptr %66, align 1
  store i8 %value4, ptr %result, align 1
  %_100 = load i8, ptr %result, align 1
; call <i8>::checked_sub
  %67 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_subCs4mnquxVp34G_6errors(i8 %_100, i8 %x) #25
  %68 = extractvalue { i1, i8 } %67, 0
  %69 = extractvalue { i1, i8 } %67, 1
  %70 = zext i1 %68 to i8
  store i8 %70, ptr %_99, align 1
  %71 = getelementptr inbounds i8, ptr %_99, i64 1
  store i8 %69, ptr %71, align 1
  %72 = load i8, ptr %_99, align 1
  %73 = trunc nuw i8 %72 to i1
  %74 = getelementptr inbounds i8, ptr %_99, i64 1
  %75 = load i8, ptr %74, align 1
  %_101 = zext i1 %73 to i64
  %76 = trunc nuw i64 %_101 to i1
  br i1 %76, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %77 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %77, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb51:                                             ; preds = %bb48
  %78 = getelementptr inbounds i8, ptr %_99, i64 1
  %value5 = load i8, ptr %78, align 1
  store i8 %value5, ptr %result, align 1
  store ptr %rest.02, ptr %digits, align 8, !captures !612
  %79 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %79, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %80 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %80, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb31:                                             ; preds = %bb30
  %81 = load ptr, ptr %digits, align 8
  %82 = getelementptr inbounds i8, ptr %digits, i64 8
  %83 = load i64, ptr %82, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %81, i64 0
  %84 = load ptr, ptr %digits, align 8
  %85 = getelementptr inbounds i8, ptr %digits, i64 8
  %86 = load i64, ptr %85, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %84, i64 1
  %rest.18 = sub i64 %86, 1
  %_60 = load i8, ptr %result, align 1
  %_61 = trunc i32 %radix to i8
; call <i8>::checked_mul
  %87 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs4mnquxVp34G_6errors(i8 %_60, i8 %_61) #25
  %88 = extractvalue { i1, i8 } %87, 0
  %89 = extractvalue { i1, i8 } %87, 1
  %90 = zext i1 %88 to i8
  store i8 %90, ptr %mul, align 1
  %91 = getelementptr inbounds i8, ptr %mul, i64 1
  store i8 %89, ptr %91, align 1
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %92 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_64, i32 %radix) #25
  %93 = extractvalue { i32, i32 } %92, 0
  %94 = extractvalue { i32, i32 } %92, 1
  store i32 %93, ptr %_63, align 4
  %95 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %94, ptr %95, align 4
  %96 = load i32, ptr %_63, align 4
  %97 = getelementptr inbounds i8, ptr %_63, i64 4
  %98 = load i32, ptr %97, align 4
  %_66 = zext i32 %96 to i64
  %99 = trunc nuw i64 %_66 to i1
  br i1 %99, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %100 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %100, align 4
  %x10 = trunc i32 %value9 to i8
  %101 = load i8, ptr %mul, align 1
  %102 = trunc nuw i8 %101 to i1
  %103 = getelementptr inbounds i8, ptr %mul, i64 1
  %104 = load i8, ptr %103, align 1
  %_70 = zext i1 %102 to i64
  %105 = trunc nuw i64 %_70 to i1
  br i1 %105, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %106 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %106, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb37:                                             ; preds = %bb35
  %107 = getelementptr inbounds i8, ptr %mul, i64 1
  %value11 = load i8, ptr %107, align 1
  store i8 %value11, ptr %result, align 1
  %_75 = load i8, ptr %result, align 1
; call <i8>::checked_add
  %108 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs4mnquxVp34G_6errors(i8 %_75, i8 %x10) #25
  %109 = extractvalue { i1, i8 } %108, 0
  %110 = extractvalue { i1, i8 } %108, 1
  %111 = zext i1 %109 to i8
  store i8 %111, ptr %_74, align 1
  %112 = getelementptr inbounds i8, ptr %_74, i64 1
  store i8 %110, ptr %112, align 1
  %113 = load i8, ptr %_74, align 1
  %114 = trunc nuw i8 %113 to i1
  %115 = getelementptr inbounds i8, ptr %_74, i64 1
  %116 = load i8, ptr %115, align 1
  %_76 = zext i1 %114 to i64
  %117 = trunc nuw i64 %_76 to i1
  br i1 %117, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %118 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %118, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb40:                                             ; preds = %bb37
  %119 = getelementptr inbounds i8, ptr %_74, i64 1
  %value12 = load i8, ptr %119, align 1
  store i8 %value12, ptr %result, align 1
  store ptr %rest.07, ptr %digits, align 8, !captures !612
  %120 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %120, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %121 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %121, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %122 = load ptr, ptr %digits, align 8
  %123 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %123, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %124 = load ptr, ptr %digits, align 8
  %125 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %125, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %126 = load ptr, ptr %digits, align 8
  %127 = getelementptr inbounds i8, ptr %digits, i64 8
  %128 = load i64, ptr %127, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %126, i64 0
  %129 = load ptr, ptr %digits, align 8
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  %131 = load i64, ptr %130, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %129, i64 1
  %rest.115 = sub i64 %131, 1
  %_44 = load i8, ptr %result, align 1
  %_45 = trunc i32 %radix to i8
  %132 = mul i8 %_44, %_45
  store i8 %132, ptr %result, align 1
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %133 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_47, i32 %radix) #25
  %134 = extractvalue { i32, i32 } %133, 0
  %135 = extractvalue { i32, i32 } %133, 1
  store i32 %134, ptr %_46, align 4
  %136 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %135, ptr %136, align 4
  %137 = load i32, ptr %_46, align 4
  %138 = getelementptr inbounds i8, ptr %_46, i64 4
  %139 = load i32, ptr %138, align 4
  %_49 = zext i32 %137 to i64
  %140 = trunc nuw i64 %_49 to i1
  br i1 %140, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %141 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %141, align 4
  %_53 = load i8, ptr %result, align 1
  %_54 = trunc i32 %x16 to i8
  %142 = sub i8 %_53, %_54
  store i8 %142, ptr %result, align 1
  store ptr %rest.014, ptr %digits, align 8, !captures !612
  %143 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %143, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %144 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %144, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb19:                                             ; preds = %bb18
  %145 = load ptr, ptr %digits, align 8
  %146 = getelementptr inbounds i8, ptr %digits, i64 8
  %147 = load i64, ptr %146, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %145, i64 0
  %148 = load ptr, ptr %digits, align 8
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  %150 = load i64, ptr %149, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %148, i64 1
  %rest.119 = sub i64 %150, 1
  %_29 = load i8, ptr %result, align 1
  %_30 = trunc i32 %radix to i8
  %151 = mul i8 %_29, %_30
  store i8 %151, ptr %result, align 1
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %152 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_32, i32 %radix) #25
  %153 = extractvalue { i32, i32 } %152, 0
  %154 = extractvalue { i32, i32 } %152, 1
  store i32 %153, ptr %_31, align 4
  %155 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %154, ptr %155, align 4
  %156 = load i32, ptr %_31, align 4
  %157 = getelementptr inbounds i8, ptr %_31, i64 4
  %158 = load i32, ptr %157, align 4
  %_34 = zext i32 %156 to i64
  %159 = trunc nuw i64 %_34 to i1
  br i1 %159, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %160 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %160, align 4
  %_38 = load i8, ptr %result, align 1
  %_39 = trunc i32 %x20 to i8
  %161 = add i8 %_38, %_39
  store i8 %161, ptr %result, align 1
  store ptr %rest.018, ptr %digits, align 8, !captures !612
  %162 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %162, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %163 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %163, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; <i64>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsr_NtCsl10jNU3mE6R_4core3numx14from_str_radixCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !613 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <i64>::from_ascii_bytes_radix_impl
  call void @_RNvMsr_NtCsl10jNU3mE6R_4core3numx27from_ascii_bytes_radix_implCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #25
  ret void
}

; <i64>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsr_NtCsl10jNU3mE6R_4core3numx27from_ascii_bytes_radix_implCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !614 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [16 x i8], align 8
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [16 x i8], align 8
  %_74 = alloca [16 x i8], align 8
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [16 x i8], align 8
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [8 x i8], align 8
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #29
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1) #25
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !612
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i64 0, ptr %result, align 8
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs4mnquxVp34G_6errors.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 15
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs4mnquxVp34G_6errors.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs4mnquxVp34G_6errors.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs4mnquxVp34G_6errors.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs4mnquxVp34G_6errors.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i64, ptr %result, align 8
  %33 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_105, ptr %33, align 8
  store i8 0, ptr %_0, align 8
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i64, ptr %result, align 8
  %_86 = zext i32 %radix to i64
; call <i64>::checked_mul
  %40 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs4mnquxVp34G_6errors(i64 %_85, i64 %_86) #25
  %41 = extractvalue { i64, i64 } %40, 0
  %42 = extractvalue { i64, i64 } %40, 1
  store i64 %41, ptr %mul1, align 8
  %43 = getelementptr inbounds i8, ptr %mul1, i64 8
  store i64 %42, ptr %43, align 8
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %44 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_89, i32 %radix) #25
  %45 = extractvalue { i32, i32 } %44, 0
  %46 = extractvalue { i32, i32 } %44, 1
  store i32 %45, ptr %_88, align 4
  %47 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %46, ptr %47, align 4
  %48 = load i32, ptr %_88, align 4
  %49 = getelementptr inbounds i8, ptr %_88, i64 4
  %50 = load i32, ptr %49, align 4
  %_91 = zext i32 %48 to i64
  %51 = trunc nuw i64 %_91 to i1
  br i1 %51, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %52 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %52, align 4
  %x = zext i32 %value to i64
  %_95 = load i64, ptr %mul1, align 8
  %53 = getelementptr inbounds i8, ptr %mul1, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = trunc nuw i64 %_95 to i1
  br i1 %55, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %56 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %56, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb48:                                             ; preds = %bb46
  %57 = getelementptr inbounds i8, ptr %mul1, i64 8
  %value4 = load i64, ptr %57, align 8
  store i64 %value4, ptr %result, align 8
  %_100 = load i64, ptr %result, align 8
; call <i64>::checked_sub
  %58 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_subCs4mnquxVp34G_6errors(i64 %_100, i64 %x) #25
  %59 = extractvalue { i64, i64 } %58, 0
  %60 = extractvalue { i64, i64 } %58, 1
  store i64 %59, ptr %_99, align 8
  %61 = getelementptr inbounds i8, ptr %_99, i64 8
  store i64 %60, ptr %61, align 8
  %_101 = load i64, ptr %_99, align 8
  %62 = getelementptr inbounds i8, ptr %_99, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = trunc nuw i64 %_101 to i1
  br i1 %64, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %65 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %65, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb51:                                             ; preds = %bb48
  %66 = getelementptr inbounds i8, ptr %_99, i64 8
  %value5 = load i64, ptr %66, align 8
  store i64 %value5, ptr %result, align 8
  store ptr %rest.02, ptr %digits, align 8, !captures !612
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %67, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %68 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %68, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb31:                                             ; preds = %bb30
  %69 = load ptr, ptr %digits, align 8
  %70 = getelementptr inbounds i8, ptr %digits, i64 8
  %71 = load i64, ptr %70, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %69, i64 0
  %72 = load ptr, ptr %digits, align 8
  %73 = getelementptr inbounds i8, ptr %digits, i64 8
  %74 = load i64, ptr %73, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %72, i64 1
  %rest.18 = sub i64 %74, 1
  %_60 = load i64, ptr %result, align 8
  %_61 = zext i32 %radix to i64
; call <i64>::checked_mul
  %75 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs4mnquxVp34G_6errors(i64 %_60, i64 %_61) #25
  %76 = extractvalue { i64, i64 } %75, 0
  %77 = extractvalue { i64, i64 } %75, 1
  store i64 %76, ptr %mul, align 8
  %78 = getelementptr inbounds i8, ptr %mul, i64 8
  store i64 %77, ptr %78, align 8
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %79 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_64, i32 %radix) #25
  %80 = extractvalue { i32, i32 } %79, 0
  %81 = extractvalue { i32, i32 } %79, 1
  store i32 %80, ptr %_63, align 4
  %82 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %81, ptr %82, align 4
  %83 = load i32, ptr %_63, align 4
  %84 = getelementptr inbounds i8, ptr %_63, i64 4
  %85 = load i32, ptr %84, align 4
  %_66 = zext i32 %83 to i64
  %86 = trunc nuw i64 %_66 to i1
  br i1 %86, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %87 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %87, align 4
  %x10 = zext i32 %value9 to i64
  %_70 = load i64, ptr %mul, align 8
  %88 = getelementptr inbounds i8, ptr %mul, i64 8
  %89 = load i64, ptr %88, align 8
  %90 = trunc nuw i64 %_70 to i1
  br i1 %90, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %91, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb37:                                             ; preds = %bb35
  %92 = getelementptr inbounds i8, ptr %mul, i64 8
  %value11 = load i64, ptr %92, align 8
  store i64 %value11, ptr %result, align 8
  %_75 = load i64, ptr %result, align 8
; call <i64>::checked_add
  %93 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_addCs4mnquxVp34G_6errors(i64 %_75, i64 %x10) #25
  %94 = extractvalue { i64, i64 } %93, 0
  %95 = extractvalue { i64, i64 } %93, 1
  store i64 %94, ptr %_74, align 8
  %96 = getelementptr inbounds i8, ptr %_74, i64 8
  store i64 %95, ptr %96, align 8
  %_76 = load i64, ptr %_74, align 8
  %97 = getelementptr inbounds i8, ptr %_74, i64 8
  %98 = load i64, ptr %97, align 8
  %99 = trunc nuw i64 %_76 to i1
  br i1 %99, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %100 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %100, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb40:                                             ; preds = %bb37
  %101 = getelementptr inbounds i8, ptr %_74, i64 8
  %value12 = load i64, ptr %101, align 8
  store i64 %value12, ptr %result, align 8
  store ptr %rest.07, ptr %digits, align 8, !captures !612
  %102 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %102, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %103 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %103, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %104 = load ptr, ptr %digits, align 8
  %105 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %105, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %106 = load ptr, ptr %digits, align 8
  %107 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %107, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %108 = load ptr, ptr %digits, align 8
  %109 = getelementptr inbounds i8, ptr %digits, i64 8
  %110 = load i64, ptr %109, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %108, i64 0
  %111 = load ptr, ptr %digits, align 8
  %112 = getelementptr inbounds i8, ptr %digits, i64 8
  %113 = load i64, ptr %112, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %111, i64 1
  %rest.115 = sub i64 %113, 1
  %_44 = load i64, ptr %result, align 8
  %_45 = zext i32 %radix to i64
  %114 = mul i64 %_44, %_45
  store i64 %114, ptr %result, align 8
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %115 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_47, i32 %radix) #25
  %116 = extractvalue { i32, i32 } %115, 0
  %117 = extractvalue { i32, i32 } %115, 1
  store i32 %116, ptr %_46, align 4
  %118 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %117, ptr %118, align 4
  %119 = load i32, ptr %_46, align 4
  %120 = getelementptr inbounds i8, ptr %_46, i64 4
  %121 = load i32, ptr %120, align 4
  %_49 = zext i32 %119 to i64
  %122 = trunc nuw i64 %_49 to i1
  br i1 %122, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %123 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %123, align 4
  %_53 = load i64, ptr %result, align 8
  %_54 = zext i32 %x16 to i64
  %124 = sub i64 %_53, %_54
  store i64 %124, ptr %result, align 8
  store ptr %rest.014, ptr %digits, align 8, !captures !612
  %125 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %125, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %126 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %126, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb19:                                             ; preds = %bb18
  %127 = load ptr, ptr %digits, align 8
  %128 = getelementptr inbounds i8, ptr %digits, i64 8
  %129 = load i64, ptr %128, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %127, i64 0
  %130 = load ptr, ptr %digits, align 8
  %131 = getelementptr inbounds i8, ptr %digits, i64 8
  %132 = load i64, ptr %131, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %130, i64 1
  %rest.119 = sub i64 %132, 1
  %_29 = load i64, ptr %result, align 8
  %_30 = zext i32 %radix to i64
  %133 = mul i64 %_29, %_30
  store i64 %133, ptr %result, align 8
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %134 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_32, i32 %radix) #25
  %135 = extractvalue { i32, i32 } %134, 0
  %136 = extractvalue { i32, i32 } %134, 1
  store i32 %135, ptr %_31, align 4
  %137 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %136, ptr %137, align 4
  %138 = load i32, ptr %_31, align 4
  %139 = getelementptr inbounds i8, ptr %_31, i64 4
  %140 = load i32, ptr %139, align 4
  %_34 = zext i32 %138 to i64
  %141 = trunc nuw i64 %_34 to i1
  br i1 %141, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %142 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %142, align 4
  %_38 = load i64, ptr %result, align 8
  %_39 = zext i32 %x20 to i64
  %143 = add i64 %_38, %_39
  store i64 %143, ptr %result, align 8
  store ptr %rest.018, ptr %digits, align 8, !captures !612
  %144 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %144, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %145 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %145, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; <u8>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsx_NtCsl10jNU3mE6R_4core3numh14from_str_radixCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !615 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <u8>::from_ascii_bytes_radix_impl
  %2 = call { i1, i8 } @_RNvMsx_NtCsl10jNU3mE6R_4core3numh27from_ascii_bytes_radix_implCs4mnquxVp34G_6errors(ptr %_3.0, i64 %_3.1, i32 %radix) #25
  %_0.0 = extractvalue { i1, i8 } %2, 0
  %_0.1 = extractvalue { i1, i8 } %2, 1
  %3 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %4 = insertvalue { i1, i8 } %3, i8 %_0.1, 1
  ret { i1, i8 } %4
}

; <u8>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsx_NtCsl10jNU3mE6R_4core3numh27from_ascii_bytes_radix_implCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !616 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [2 x i8], align 1
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [2 x i8], align 1
  %_74 = alloca [2 x i8], align 1
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [2 x i8], align 1
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [1 x i8], align 1
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [2 x i8], align 1
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_5aa1d1250638a5285856df0c8e3018a3) #29
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1) #25
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9

bb9:                                              ; preds = %bb11, %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %10 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 %src.1, ptr %11, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %12 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %13 = load i8, ptr %12, align 1
  switch i8 %13, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %14, i64 8
  store i64 %rest.1, ptr %15, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %16 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %17 = sub i64 %src.1, 1
  store ptr %16, ptr %rest, align 8
  %18 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb9

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %19 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %19 to i1
  %20 = getelementptr inbounds i8, ptr %_12, i64 8
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr inbounds i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  store ptr %21, ptr %digits, align 8, !captures !612
  %24 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %23, ptr %24, align 8
  store i8 0, ptr %result, align 1
  %_24.0 = load ptr, ptr %digits, align 8
  %25 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %25, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECs4mnquxVp34G_6errors.exit

bb1.i:                                            ; preds = %bb15
  %26 = icmp ule i64 %_24.1, 2
  %27 = zext i1 %26 to i8
  store i8 %27, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECs4mnquxVp34G_6errors.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECs4mnquxVp34G_6errors.exit: ; preds = %bb2.i, %bb1.i
  %28 = load i8, ptr %_0.i, align 1
  %29 = trunc nuw i8 %28 to i1
  br i1 %29, label %bb17, label %bb29

bb14:                                             ; No predecessors!
  store i8 0, ptr %_12, align 8
  %30 = load ptr, ptr %rest, align 8
  %31 = getelementptr inbounds i8, ptr %rest, i64 8
  %32 = load i64, ptr %31, align 8
  %33 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %30, ptr %33, align 8
  %34 = getelementptr inbounds i8, ptr %33, i64 8
  store i64 %32, ptr %34, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECs4mnquxVp34G_6errors.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECs4mnquxVp34G_6errors.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %36, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %38, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i8, ptr %result, align 1
  %39 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_105, ptr %39, align 1
  store i8 0, ptr %_0, align 1
  br label %bb53

bb42:                                             ; preds = %bb41
  %40 = load ptr, ptr %digits, align 8
  %41 = getelementptr inbounds i8, ptr %digits, i64 8
  %42 = load i64, ptr %41, align 8
  %c = getelementptr inbounds nuw i8, ptr %40, i64 0
  %43 = load ptr, ptr %digits, align 8
  %44 = getelementptr inbounds i8, ptr %digits, i64 8
  %45 = load i64, ptr %44, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %43, i64 1
  %rest.13 = sub i64 %45, 1
  %_85 = load i8, ptr %result, align 1
  %_86 = trunc i32 %radix to i8
; call <u8>::checked_mul
  %46 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCs4mnquxVp34G_6errors(i8 %_85, i8 %_86) #25
  %47 = extractvalue { i1, i8 } %46, 0
  %48 = extractvalue { i1, i8 } %46, 1
  %49 = zext i1 %47 to i8
  store i8 %49, ptr %mul1, align 1
  %50 = getelementptr inbounds i8, ptr %mul1, i64 1
  store i8 %48, ptr %50, align 1
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %51 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_89, i32 %radix) #25
  %52 = extractvalue { i32, i32 } %51, 0
  %53 = extractvalue { i32, i32 } %51, 1
  store i32 %52, ptr %_88, align 4
  %54 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %53, ptr %54, align 4
  %55 = load i32, ptr %_88, align 4
  %56 = getelementptr inbounds i8, ptr %_88, i64 4
  %57 = load i32, ptr %56, align 4
  %_91 = zext i32 %55 to i64
  %58 = trunc nuw i64 %_91 to i1
  br i1 %58, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %59 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %59, align 4
  %x = trunc i32 %value to i8
  %60 = load i8, ptr %mul1, align 1
  %61 = trunc nuw i8 %60 to i1
  %62 = getelementptr inbounds i8, ptr %mul1, i64 1
  %63 = load i8, ptr %62, align 1
  %_95 = zext i1 %61 to i64
  %64 = trunc nuw i64 %_95 to i1
  br i1 %64, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %65 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %65, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb48:                                             ; preds = %bb46
  %66 = getelementptr inbounds i8, ptr %mul1, i64 1
  %value4 = load i8, ptr %66, align 1
  store i8 %value4, ptr %result, align 1
  %_100 = load i8, ptr %result, align 1
; call <u8>::checked_sub
  %67 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_subCs4mnquxVp34G_6errors(i8 %_100, i8 %x) #25
  %68 = extractvalue { i1, i8 } %67, 0
  %69 = extractvalue { i1, i8 } %67, 1
  %70 = zext i1 %68 to i8
  store i8 %70, ptr %_99, align 1
  %71 = getelementptr inbounds i8, ptr %_99, i64 1
  store i8 %69, ptr %71, align 1
  %72 = load i8, ptr %_99, align 1
  %73 = trunc nuw i8 %72 to i1
  %74 = getelementptr inbounds i8, ptr %_99, i64 1
  %75 = load i8, ptr %74, align 1
  %_101 = zext i1 %73 to i64
  %76 = trunc nuw i64 %_101 to i1
  br i1 %76, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %77 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %77, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb51:                                             ; preds = %bb48
  %78 = getelementptr inbounds i8, ptr %_99, i64 1
  %value5 = load i8, ptr %78, align 1
  store i8 %value5, ptr %result, align 1
  store ptr %rest.02, ptr %digits, align 8, !captures !612
  %79 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %79, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %80 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %80, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb31:                                             ; preds = %bb30
  %81 = load ptr, ptr %digits, align 8
  %82 = getelementptr inbounds i8, ptr %digits, i64 8
  %83 = load i64, ptr %82, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %81, i64 0
  %84 = load ptr, ptr %digits, align 8
  %85 = getelementptr inbounds i8, ptr %digits, i64 8
  %86 = load i64, ptr %85, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %84, i64 1
  %rest.18 = sub i64 %86, 1
  %_60 = load i8, ptr %result, align 1
  %_61 = trunc i32 %radix to i8
; call <u8>::checked_mul
  %87 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCs4mnquxVp34G_6errors(i8 %_60, i8 %_61) #25
  %88 = extractvalue { i1, i8 } %87, 0
  %89 = extractvalue { i1, i8 } %87, 1
  %90 = zext i1 %88 to i8
  store i8 %90, ptr %mul, align 1
  %91 = getelementptr inbounds i8, ptr %mul, i64 1
  store i8 %89, ptr %91, align 1
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %92 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_64, i32 %radix) #25
  %93 = extractvalue { i32, i32 } %92, 0
  %94 = extractvalue { i32, i32 } %92, 1
  store i32 %93, ptr %_63, align 4
  %95 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %94, ptr %95, align 4
  %96 = load i32, ptr %_63, align 4
  %97 = getelementptr inbounds i8, ptr %_63, i64 4
  %98 = load i32, ptr %97, align 4
  %_66 = zext i32 %96 to i64
  %99 = trunc nuw i64 %_66 to i1
  br i1 %99, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %100 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %100, align 4
  %x10 = trunc i32 %value9 to i8
  %101 = load i8, ptr %mul, align 1
  %102 = trunc nuw i8 %101 to i1
  %103 = getelementptr inbounds i8, ptr %mul, i64 1
  %104 = load i8, ptr %103, align 1
  %_70 = zext i1 %102 to i64
  %105 = trunc nuw i64 %_70 to i1
  br i1 %105, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %106 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %106, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb37:                                             ; preds = %bb35
  %107 = getelementptr inbounds i8, ptr %mul, i64 1
  %value11 = load i8, ptr %107, align 1
  store i8 %value11, ptr %result, align 1
  %_75 = load i8, ptr %result, align 1
; call <u8>::checked_add
  %108 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_addCs4mnquxVp34G_6errors(i8 %_75, i8 %x10) #25
  %109 = extractvalue { i1, i8 } %108, 0
  %110 = extractvalue { i1, i8 } %108, 1
  %111 = zext i1 %109 to i8
  store i8 %111, ptr %_74, align 1
  %112 = getelementptr inbounds i8, ptr %_74, i64 1
  store i8 %110, ptr %112, align 1
  %113 = load i8, ptr %_74, align 1
  %114 = trunc nuw i8 %113 to i1
  %115 = getelementptr inbounds i8, ptr %_74, i64 1
  %116 = load i8, ptr %115, align 1
  %_76 = zext i1 %114 to i64
  %117 = trunc nuw i64 %_76 to i1
  br i1 %117, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %118 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %118, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb40:                                             ; preds = %bb37
  %119 = getelementptr inbounds i8, ptr %_74, i64 1
  %value12 = load i8, ptr %119, align 1
  store i8 %value12, ptr %result, align 1
  store ptr %rest.07, ptr %digits, align 8, !captures !612
  %120 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %120, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %121 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %121, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %122 = load ptr, ptr %digits, align 8
  %123 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %123, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %124 = load ptr, ptr %digits, align 8
  %125 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %125, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %126 = load ptr, ptr %digits, align 8
  %127 = getelementptr inbounds i8, ptr %digits, i64 8
  %128 = load i64, ptr %127, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %126, i64 0
  %129 = load ptr, ptr %digits, align 8
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  %131 = load i64, ptr %130, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %129, i64 1
  %rest.115 = sub i64 %131, 1
  %_44 = load i8, ptr %result, align 1
  %_45 = trunc i32 %radix to i8
  %132 = mul i8 %_44, %_45
  store i8 %132, ptr %result, align 1
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %133 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_47, i32 %radix) #25
  %134 = extractvalue { i32, i32 } %133, 0
  %135 = extractvalue { i32, i32 } %133, 1
  store i32 %134, ptr %_46, align 4
  %136 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %135, ptr %136, align 4
  %137 = load i32, ptr %_46, align 4
  %138 = getelementptr inbounds i8, ptr %_46, i64 4
  %139 = load i32, ptr %138, align 4
  %_49 = zext i32 %137 to i64
  %140 = trunc nuw i64 %_49 to i1
  br i1 %140, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %141 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %141, align 4
  %_53 = load i8, ptr %result, align 1
  %_54 = trunc i32 %x16 to i8
  %142 = sub i8 %_53, %_54
  store i8 %142, ptr %result, align 1
  store ptr %rest.014, ptr %digits, align 8, !captures !612
  %143 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %143, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %144 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %144, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb19:                                             ; preds = %bb18
  %145 = load ptr, ptr %digits, align 8
  %146 = getelementptr inbounds i8, ptr %digits, i64 8
  %147 = load i64, ptr %146, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %145, i64 0
  %148 = load ptr, ptr %digits, align 8
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  %150 = load i64, ptr %149, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %148, i64 1
  %rest.119 = sub i64 %150, 1
  %_29 = load i8, ptr %result, align 1
  %_30 = trunc i32 %radix to i8
  %151 = mul i8 %_29, %_30
  store i8 %151, ptr %result, align 1
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %152 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs4mnquxVp34G_6errors(i32 %_32, i32 %radix) #25
  %153 = extractvalue { i32, i32 } %152, 0
  %154 = extractvalue { i32, i32 } %152, 1
  store i32 %153, ptr %_31, align 4
  %155 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %154, ptr %155, align 4
  %156 = load i32, ptr %_31, align 4
  %157 = getelementptr inbounds i8, ptr %_31, i64 4
  %158 = load i32, ptr %157, align 4
  %_34 = zext i32 %156 to i64
  %159 = trunc nuw i64 %_34 to i1
  br i1 %159, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %160 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %160, align 4
  %_38 = load i8, ptr %result, align 1
  %_39 = trunc i32 %x20 to i8
  %161 = add i8 %_38, %_39
  store i8 %161, ptr %result, align 1
  store ptr %rest.018, ptr %digits, align 8, !captures !612
  %162 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %162, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %163 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %163, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs4mnquxVp34G_6errors(i64 %0, i64 %1) unnamed_addr #0 !guid !617 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #32
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #32
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs4mnquxVp34G_6errors(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !618 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #32
  ret void
}

; alloc::alloc::realloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc15realloc_nonnullCs4mnquxVp34G_6errors(ptr %ptr, i64 %0, i64 %1, i64 %new_size) unnamed_addr #0 !guid !619 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
; call <core::alloc::layout::Layout>::alignment
  %_6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
; call __rustc::__rust_realloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc14___rust_realloc(ptr %ptr, i64 %_4, i64 %_6, i64 %new_size) #32
  ret ptr %_0
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs4mnquxVp34G_6errors(i64 %0, i64 %1) unnamed_addr #0 !guid !620 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #32
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #32
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs4mnquxVp34G_6errors(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !621 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs4mnquxVp34G_6errors(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #25
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #28
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs4mnquxVp34G_6errors(ptr %ptr.0, i64 %ptr.1) #25
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; alloc::raw_vec::layout_array
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, i64 %cap, i64 %0, i64 %1) unnamed_addr #0 !guid !622 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::repeat_packed
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCs4mnquxVp34G_6errors(ptr align 8 %elem_layout, i64 %cap) #25
  %_3.0 = extractvalue { i64, i64 } %3, 0
  %_3.1 = extractvalue { i64, i64 } %3, 1
; call <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, i64 %_3.0, i64 %_3.1) #25
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCs4mnquxVp34G_6errors() unnamed_addr #5 !guid !623 {
start:
  ret void
}

; core::hint::unreachable_unchecked
; Function Attrs: inlinehint noreturn nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core4hint21unreachable_uncheckedCs4mnquxVp34G_6errors(ptr align 8 %0) unnamed_addr #6 !guid !624 {
start:
; call core::ub_checks::check_language_ub
  %_1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  unreachable

bb2:                                              ; preds = %start
; call core::hint::unreachable_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint21unreachable_unchecked18precondition_checkCs4mnquxVp34G_6errors(ptr align 8 %0) #27
  br label %bb3
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs4mnquxVp34G_6errors(ptr %ptr, i64 %align) unnamed_addr #0 !guid !625 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs4mnquxVp34G_6errors(ptr %ptr, i64 %align) #25
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() unnamed_addr #0 !guid !626 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs4mnquxVp34G_6errors() #25
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs4mnquxVp34G_6errors(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !627 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs4mnquxVp34G_6errors(ptr %3, ptr %5, i64 %7, i64 %9) #25
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs4mnquxVp34G_6errors(i64 %size, i64 %len) unnamed_addr #0 !guid !628 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #29
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs4mnquxVp34G_6errors(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !629 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs4mnquxVp34G_6errors(ptr %ptr, i64 %align) #25
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCs4mnquxVp34G_6errors(ptr %ptr) #25
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::str::validations::utf8_first_byte
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCs4mnquxVp34G_6errors(i8 %byte, i32 %width) unnamed_addr #0 !guid !630 {
start:
  %0 = and i32 %width, 7
  %1 = trunc i32 %0 to i8
  %_4 = lshr i8 127, %1
  %_3 = and i8 %byte, %_4
  %_0 = zext i8 %_3 to i32
  ret i32 %_0
}

; core::str::validations::utf8_is_cont_byte
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations17utf8_is_cont_byteCs4mnquxVp34G_6errors(i8 %byte) unnamed_addr #0 !guid !631 {
start:
  %_0 = icmp slt i8 %byte, -64
  ret i1 %_0
}

; core::str::validations::utf8_acc_cont_byte
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCs4mnquxVp34G_6errors(i32 %ch, i8 %byte) unnamed_addr #0 !guid !632 {
start:
  %_3 = shl i32 %ch, 6
  %_5 = and i8 %byte, 63
  %_4 = zext i8 %_5 to i32
  %_0 = or i32 %_3, %_4
  ret i32 %_0
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs4mnquxVp34G_6errors(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !633 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::char::convert::char_try_from_u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert17char_try_from_u32Cs4mnquxVp34G_6errors(i32 %i) unnamed_addr #0 !guid !634 {
start:
  %_0 = alloca [4 x i8], align 4
  %_4 = xor i32 %i, 55296
  %_0.i = sub i32 %_4, 2048
  %_2 = icmp uge i32 %_0.i, 1112064
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %i, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  store i32 -1, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::char::convert::from_u32_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert18from_u32_uncheckedCs4mnquxVp34G_6errors(i32 %i, ptr align 8 %0) unnamed_addr #0 !guid !635 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i32 %i

bb2:                                              ; preds = %start
; call core::char::convert::from_u32_unchecked::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core4char7convert18from_u32_unchecked18precondition_checkCs4mnquxVp34G_6errors(i32 %i, ptr align 8 %0) #27
  br label %bb3
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs4mnquxVp34G_6errors(i32 %code, ptr %dst) unnamed_addr #0 !guid !636 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs4mnquxVp34G_6errors(i32 %code) #25
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs4mnquxVp34G_6errors(i32 %code) unnamed_addr #0 !guid !637 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::unicode::unicode_data::white_space::lookup
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space6lookupCs4mnquxVp34G_6errors(i32 %c) unnamed_addr #0 !guid !638 {
start:
  %_0 = alloca [1 x i8], align 1
  %_2 = lshr i32 %c, 8
  switch i32 %_2, label %bb1 [
    i32 0, label %bb5
    i32 22, label %bb4
    i32 32, label %bb3
    i32 48, label %bb2
  ]

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb8

bb5:                                              ; preds = %start
  %_8 = zext i32 %c to i64
  %_7 = and i64 %_8, 255
  %_9 = icmp ult i64 %_7, 256
  br i1 %_9, label %bb6, label %panic

bb4:                                              ; preds = %start
  %0 = icmp eq i32 %c, 5760
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb8

bb3:                                              ; preds = %start
  %_15 = zext i32 %c to i64
  %_14 = and i64 %_15, 255
  %_16 = icmp ult i64 %_14, 256
  br i1 %_16, label %bb7, label %panic1

bb2:                                              ; preds = %start
  %2 = icmp eq i32 %c, 12288
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb8

bb6:                                              ; preds = %bb5
  %4 = getelementptr inbounds nuw i8, ptr @_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space14WHITESPACE_MAP, i64 %_7
  %_5 = load i8, ptr %4, align 1
  %_4 = and i8 %_5, 1
  %5 = icmp ne i8 %_4, 0
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb8

panic:                                            ; preds = %bb5
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_7, i64 256, ptr align 8 @alloc_ee09ed5182ef49c6cba0ade2ac4a17f6) #29
  unreachable

bb8:                                              ; preds = %bb1, %bb2, %bb7, %bb4, %bb6
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  ret i1 %8

bb7:                                              ; preds = %bb3
  %9 = getelementptr inbounds nuw i8, ptr @_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space14WHITESPACE_MAP, i64 %_14
  %_12 = load i8, ptr %9, align 1
  %_11 = and i8 %_12, 2
  %10 = icmp ne i8 %_11, 0
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %_0, align 1
  br label %bb8

panic1:                                           ; preds = %bb3
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_14, i64 256, ptr align 8 @alloc_8acebf40d2a4360b5049d1b9f3d146ab) #29
  unreachable
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %align, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !639 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs4mnquxVp34G_6errors(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !640 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCs4mnquxVp34G_6errors(ptr %ptr) unnamed_addr #0 !guid !641 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !642 {
start:
; invoke <core::alloc::layout::Layout>::is_size_align_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCs4mnquxVp34G_6errors(i64 %size, i64 %align)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_1be5ea12ba708d9a11b6e93a7d387a75, i64 281)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !643 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs4mnquxVp34G_6errors(ptr %ptr, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !644 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCs4mnquxVp34G_6errors(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <isize>::unchecked_neg::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg18precondition_checkCs4mnquxVp34G_6errors(i64 %lhs, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !645 {
start:
; invoke <isize>::overflowing_neg
  %1 = invoke { i64, i1 } @_RNvMs3_NtCsl10jNU3mE6R_4core3numi15overflowing_negCs4mnquxVp34G_6errors(i64 %lhs)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  %_3.0 = extractvalue { i64, i1 } %1, 0
  %_3.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_3.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_dbcce5cb8873847766db4f16f930a00e, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %3, 0
  %_5.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs4mnquxVp34G_6errors(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !646 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <usize>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCs4mnquxVp34G_6errors(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !647 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs4mnquxVp34G_6errors(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !648 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs4mnquxVp34G_6errors(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !649 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::ptr::write_bytes::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr11write_bytes18precondition_checkCs4mnquxVp34G_6errors(ptr %addr, i64 %align, i1 zeroext %zero_size, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !650 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_4 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs4mnquxVp34G_6errors(ptr %addr, i64 %align, i1 zeroext %zero_size)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_dd79dfae92e8fdc23813c4c7a1b7cf72, i64 228)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_6.0 = extractvalue { ptr, ptr } %2, 0
  %_6.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs4mnquxVp34G_6errors(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !651 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs4mnquxVp34G_6errors(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs4mnquxVp34G_6errors(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs4mnquxVp34G_6errors(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs4mnquxVp34G_6errors(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !652 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::hint::unreachable_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint21unreachable_unchecked18precondition_checkCs4mnquxVp34G_6errors(ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !653 {
start:
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_75fb06c2453febd814e73f5f2e72ae38, i64 199)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  %_2.0 = extractvalue { ptr, ptr } %1, 0
  %_2.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_2.0, ptr %_2.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs4mnquxVp34G_6errors(ptr %ptr, i64 %align) unnamed_addr #0 !guid !654 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCs4mnquxVp34G_6errors(ptr %ptr, i64 %align) #25
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs4mnquxVp34G_6errors() unnamed_addr #0 !guid !655 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs4mnquxVp34G_6errors(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !656 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs4mnquxVp34G_6errors(i64 %size, i64 %count) #25
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs4mnquxVp34G_6errors(i64 %_0.i2, i64 %_0.i) #25
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #30
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::char::convert::from_u32_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core4char7convert18from_u32_unchecked18precondition_checkCs4mnquxVp34G_6errors(i32 %i, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !657 {
start:
  %_4 = alloca [4 x i8], align 4
; invoke core::char::convert::char_try_from_u32
  %1 = invoke i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert17char_try_from_u32Cs4mnquxVp34G_6errors(i32 %i)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb4, %bb1, %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  store i32 %1, ptr %_4, align 4
; invoke <core::result::Result<char, core::char::convert::CharTryFromError>>::is_ok
  %_2 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultcNtNtNtB4_4char7convert16CharTryFromErrorE5is_okCs4mnquxVp34G_6errors(ptr align 4 %_4)
          to label %bb2 unwind label %terminate

bb2:                                              ; preds = %bb1
  br i1 %_2, label %bb3, label %bb4

bb4:                                              ; preds = %bb2
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_4dc07e69e5d34e9d1484dfbbef0bb9b1, i64 174)
          to label %bb5 unwind label %terminate

bb3:                                              ; preds = %bb2
  ret void

bb5:                                              ; preds = %bb4
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::slice::raw::from_raw_parts::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCs4mnquxVp34G_6errors(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !658 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs4mnquxVp34G_6errors(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_a28e8c8fd5088943a8b5d44af697ff83, i64 279)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs4mnquxVp34G_6errors(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %this, i64 %len, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !659 {
start:
  %_3 = icmp ult i64 %this, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_97d92cbf2a68a6ac45a1b13da79836e4, i64 214)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs4mnquxVp34G_6errors(i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !660 {
start:
  %_3 = icmp ule i64 %end, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_5a8fdd84b3281310cbf6b74bb6bf0065, i64 218)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %start1, i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !661 {
start:
  %_4 = icmp uge i64 %end, %start1
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4mnquxVp34G_6errors(ptr @alloc_91f2a00ff2cd9cdc4bb205a66832e2bb, i64 219)
          to label %bb4 unwind label %terminate

bb1:                                              ; preds = %start
  %_5 = icmp ule i64 %end, %len
  br i1 %_5, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  ret void

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb4:                                              ; preds = %bb3
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_7.0, ptr %_7.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <errors::AppError as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXCs4mnquxVp34G_6errorsNtB2_8AppErrorNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !662 {
start:
  %_25 = alloca [16 x i8], align 8
  %args2 = alloca [16 x i8], align 8
  %s = alloca [8 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %args1 = alloca [16 x i8], align 8
  %n = alloca [8 x i8], align 8
  %_9 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %e = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = sub i64 %0, -9223372036854775808
  %2 = icmp uge i64 %0, -9223372036854775808
  %_3 = select i1 %2, i64 %1, i64 2
  switch i64 %_3, label %bb1 [
    i64 0, label %bb4
    i64 1, label %bb3
    i64 2, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %e, align 8
; call <core::fmt::rt::Argument>::new_display::<&core::num::error::ParseIntError>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRNtNtNtB7_3num5error13ParseIntErrorECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_9, ptr align 8 %e) #25
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_9, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 1>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_9b2d63cc508ee049089fe30d211c4567, ptr align 8 %args) #25
  %_5.0 = extractvalue { ptr, ptr } %5, 0
  %_5.1 = extractvalue { ptr, ptr } %5, 1
; call <core::fmt::Formatter>::write_fmt
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_fmtCs4mnquxVp34G_6errors(ptr align 8 %f, ptr %_5.0, ptr %_5.1) #25
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb11

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %8, ptr %n, align 8
; call <core::fmt::rt::Argument>::new_display::<&i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRxECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_17, ptr align 8 %n) #25
  %9 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 1>
  %10 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_8c3d0984f7d266d81329ae47eeea02a7, ptr align 8 %args1) #25
  %_13.0 = extractvalue { ptr, ptr } %10, 0
  %_13.1 = extractvalue { ptr, ptr } %10, 1
; call <core::fmt::Formatter>::write_fmt
  %11 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_fmtCs4mnquxVp34G_6errors(ptr align 8 %f, ptr %_13.0, ptr %_13.1) #25
  %12 = zext i1 %11 to i8
  store i8 %12, ptr %_0, align 1
  br label %bb11

bb2:                                              ; preds = %start
  store ptr %self, ptr %s, align 8
; call <core::fmt::rt::Argument>::new_display::<&alloc::string::String>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_25, ptr align 8 %s) #25
  %13 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %_25, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 1>
  %14 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj1_ECs4mnquxVp34G_6errors(ptr @alloc_97f79794e46322a863ea2e7304ef904e, ptr align 8 %args2) #25
  %_21.0 = extractvalue { ptr, ptr } %14, 0
  %_21.1 = extractvalue { ptr, ptr } %14, 1
; call <core::fmt::Formatter>::write_fmt
  %15 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_fmtCs4mnquxVp34G_6errors(ptr align 8 %f, ptr %_21.0, ptr %_21.1) #25
  %16 = zext i1 %15 to i8
  store i8 %16, ptr %_0, align 1
  br label %bb11

bb11:                                             ; preds = %bb2, %bb3, %bb4
  %17 = load i8, ptr %_0, align 1
  %18 = trunc nuw i8 %17 to i1
  ret i1 %18
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !663 {
start:
; call core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>
  %0 = call { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_2.0 = extractvalue { i32, i32 } %0, 0
  %_2.1 = extractvalue { i32, i32 } %0, 1
; call <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}>
  %_0 = call i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXNtNtB5_3str4iterNtBU_5CharsNtNtNtNtB5_4iter6traits8iterator8Iterator4next0ECs4mnquxVp34G_6errors(i32 %_2.0, i32 %_2.1) #25
  ret i32 %_0
}

; <[u8] as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core5slice3cmpShNtNtB6_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !664 {
start:
  %_0 = alloca [1 x i8], align 1
  %_4 = icmp eq i64 %self.1, %other.1
  br i1 %_4, label %bb1, label %bb4

bb4:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb5

bb1:                                              ; preds = %start
; call <u8 as core::slice::cmp::SlicePartialEq<u8>>::equal_same_length
  %0 = call zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core5slice3cmphINtB5_14SlicePartialEqhE17equal_same_lengthCs4mnquxVp34G_6errors(ptr %self.0, ptr %other.0, i64 %self.1) #25
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb4
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  ret i1 %3
}

; <&mut alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: nonlazybind uwtable
define internal i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtB8_6result6ResultlNtNtBX_6string6StringEENtB2_17ExactSizeIterator3lenCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !665 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_0 = call i64 @_RNvYINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEENtNtNtNtBV_4iter6traits10exact_size17ExactSizeIterator3lenCs4mnquxVp34G_6errors(ptr align 8 %_3) #25
  ret i64 %_0
}

; <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: nonlazybind uwtable
define internal i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !666 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_0 = call i64 @_RNvXs1_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtNtNtB9_4iter6traits10exact_size17ExactSizeIterator3lenCs4mnquxVp34G_6errors(ptr align 8 %_3) #25
  ret i64 %_0
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitReENtB2_11PartialDrop12partial_dropCs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !667 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&str>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitReE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1, ptr align 8 @alloc_c7037efb906203803aa3ca07167c9120) #25
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<&str>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitReE8is_emptyCs4mnquxVp34G_6errors(ptr align 8 %_3.0, i64 %_3.1) #25
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitReE16assume_init_dropCs4mnquxVp34G_6errors.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitReE16assume_init_dropCs4mnquxVp34G_6errors.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitReE16assume_init_dropCs4mnquxVp34G_6errors.exit: ; preds = %start, %bb2.i
  ret void
}

; <<alloc::vec::into_iter::IntoIter<_, _> as core::ops::drop::Drop>::drop::DropGuard<core::result::Result<i32, alloc::string::String>, alloc::alloc::Global> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNvXse_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB8_8IntoIterppENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropINtB2_9DropGuardINtNtB18_6result6ResultlNtNtBc_6string6StringENtNtBc_5alloc6GlobalEB12_4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !668 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>::dealloc_only
  call void @_RNvMs0_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEE12dealloc_onlyCs4mnquxVp34G_6errors(ptr align 8 %_3) #25
  ret void
}

; <errors::AppError as core::convert::From<core::num::error::ParseIntError>>::from
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs0_Cs4mnquxVp34G_6errorsNtB5_8AppErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtNtNtBJ_3num5error13ParseIntErrorE4from(ptr sret([24 x i8]) align 8 %_0, i8 %e) unnamed_addr #1 !guid !669 {
start:
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 %e, ptr %0, align 8
  store i64 -9223372036854775808, ptr %_0, align 8
  ret void
}

; <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCs4mnquxVp34G_6errors(i64 %kind.0, i64 %kind.1) unnamed_addr #0 !guid !670 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %kind.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %kind.1, 1
  ret { i64, i64 } %1
}

; <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_5CharsNtNtNtNtB9_4iter6traits12double_ended19DoubleEndedIterator9next_backCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !671 {
start:
; call core::str::validations::next_code_point_reverse::<core::slice::iter::Iter<u8>>
  %0 = call { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_2.0 = extractvalue { i32, i32 } %0, 0
  %_2.1 = extractvalue { i32, i32 } %0, 1
; call <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}>
  %_0 = call i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXs0_NtNtB5_3str4iterNtBX_5CharsNtNtNtNtB5_4iter6traits12double_ended19DoubleEndedIterator9next_back0ECs4mnquxVp34G_6errors(i32 %_2.0, i32 %_2.1) #25
  ret i32 %_0
}

; <[&str; 4] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARej4_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs4mnquxVp34G_6errors(ptr sret([80 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !672 {
start:
  %0 = alloca [80 x i8], align 8
  %_2.i = alloca [80 x i8], align 8
  %1 = alloca [80 x i8], align 8
  %2 = alloca [64 x i8], align 8
  %_5 = alloca [80 x i8], align 8
  %inner = alloca [80 x i8], align 8
  %data = alloca [64 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %self, i64 64, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCs4mnquxVp34G_6errors(i64 4) #25
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %data, i64 64, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj4_E13new_uncheckedCs4mnquxVp34G_6errors(ptr sret([80 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 8 %2) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 80, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 80, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE3newCs4mnquxVp34G_6errors(ptr sret([80 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 80, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 80, i1 false)
  ret void
}

; <[&str; 7] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARej7_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs4mnquxVp34G_6errors(ptr sret([128 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !673 {
start:
  %0 = alloca [128 x i8], align 8
  %_2.i = alloca [128 x i8], align 8
  %1 = alloca [128 x i8], align 8
  %2 = alloca [112 x i8], align 8
  %_5 = alloca [128 x i8], align 8
  %inner = alloca [128 x i8], align 8
  %data = alloca [112 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %self, i64 112, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCs4mnquxVp34G_6errors(i64 7) #25
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %data, i64 112, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj7_E13new_uncheckedCs4mnquxVp34G_6errors(ptr sret([128 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 8 %2) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 128, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 128, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj7_EE3newCs4mnquxVp34G_6errors(ptr sret([128 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 128, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 128, i1 false)
  ret void
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitReEE13get_uncheckedCs4mnquxVp34G_6errors(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !674 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4mnquxVp34G_6errors() #25
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&str>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitReEECs4mnquxVp34G_6errors(ptr %slice.0, i64 %slice.1) #25
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<&str>", ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&str>]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitReEECs4mnquxVp34G_6errors(ptr %slice.0, i64 %slice.1) #25
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %self, i64 %_0.i1, ptr align 8 %0) #27
  br label %bb4
}

; <usize as core::slice::index::SliceIndex<[i32]>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSlE3getCs4mnquxVp34G_6errors(i64 %self, ptr align 4 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !675 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp ult i64 %self, %slice.1
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  %_5 = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  store ptr %_5, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <errors::AppError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs1_Cs4mnquxVp34G_6errorsNtB5_8AppErrorNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !676 {
start:
  %__self_02 = alloca [8 x i8], align 8
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = sub i64 %0, -9223372036854775808
  %2 = icmp uge i64 %0, -9223372036854775808
  %_3 = select i1 %2, i64 %1, i64 2
  switch i64 %_3, label %bb1 [
    i64 0, label %bb4
    i64 1, label %bb3
    i64 2, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_4cf7911ffc1fa65c3bf9af4755f6af39, i64 5, ptr %__self_0, ptr align 8 @vtable.2)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %6, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_b1af39f5823d1b99162e6b24ff932dbf, i64 3, ptr %__self_01, ptr align 8 @vtable.3)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb5

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_02, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_24a9d1d9c182d85dcff0523bfa2532d4, i64 2, ptr %__self_02, ptr align 8 @vtable.4)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3, %bb4
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs4mnquxVp34G_6errors(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !677 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs4mnquxVp34G_6errors(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #25
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCs4mnquxVp34G_6errors(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !678 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs4mnquxVp34G_6errors(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext true) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator4growCs4mnquxVp34G_6errors(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1) unnamed_addr #0 !guid !679 {
start:
; call <alloc::alloc::Global>::grow_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global9grow_implCs4mnquxVp34G_6errors(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1, i1 zeroext false) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs4mnquxVp34G_6errors(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !680 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs4mnquxVp34G_6errors(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtNtBR_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !681 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCs4mnquxVp34G_6errors(ptr align 8 %self, i64 8, i64 24)
  ret void
}

; <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !682 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCs4mnquxVp34G_6errors(ptr align 8 %self, i64 1, i64 1)
  ret void
}

; <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %0) unnamed_addr #0 !guid !683 {
start:
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_0 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs4mnquxVp34G_6errors(ptr %self) #25
  ret ptr %_0
}

; <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs4mnquxVp34G_6errors(i64 %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !684 {
start:
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCs4mnquxVp34G_6errors(i64 %self.0, i64 %self.1) #25
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <&str as core::convert::Into<alloc::boxed::Box<dyn core::error::Error>>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EE4intoCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !685 {
start:
; call <alloc::boxed::Box<dyn core::error::Error> as core::convert::From<&str>>::from
  %1 = call { ptr, ptr } @_RNvXsi_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_EINtNtBW_7convert4FromReE4from(ptr %self.0, i64 %self.1)
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <&str as core::convert::Into<alloc::string::String>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !686 {
start:
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #25
  ret void
}

; <core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs1_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtNtNtB9_4iter6traits10exact_size17ExactSizeIterator3lenCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !687 {
start:
; call <core::ops::index_range::IndexRange>::len
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  ret i64 %_0
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitReEE17get_unchecked_mutCs4mnquxVp34G_6errors(i64 %0, i64 %1, ptr %slice.0, i64 %slice.1, ptr align 8 %2) unnamed_addr #0 !guid !688 {
start:
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ops::index_range::IndexRange>::end
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCs4mnquxVp34G_6errors(ptr align 8 %self) #25
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&str>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitReEECs4mnquxVp34G_6errors(ptr %slice.0, i64 %slice.1) #25
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs4mnquxVp34G_6errors(i64 %_5, i64 %_0.i, ptr align 8 %2) #27
  br label %bb4

bb4:                                              ; preds = %bb1
; call <core::ops::index_range::IndexRange>::start
  %_8 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCs4mnquxVp34G_6errors(ptr align 8 %self) #25
; call <core::ops::index_range::IndexRange>::len
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %ptr.i = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<&str>", ptr %slice.0, i64 %_8
  %4 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_10, 1
  %_0.0 = extractvalue { ptr, i64 } %5, 0
  %_0.1 = extractvalue { ptr, i64 } %5, 1
  %6 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %_0.1, 1
  ret { ptr, i64 } %7
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj4_ENtNtNtBb_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !689 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<&str>; 4] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitReEj4_NtB4_11PartialDrop12partial_dropCs4mnquxVp34G_6errors(ptr align 8 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj7_ENtNtNtBb_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !690 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<&str>; 7] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitReEj7_NtB4_11PartialDrop12partial_dropCs4mnquxVp34G_6errors(ptr align 8 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <&alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !691 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <alloc::string::String as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse14FloatErrorKindNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !692 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_14FloatErrorKindNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse15ParseFloatErrorNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !693 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_15ParseFloatErrorNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !694 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !695 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&core::str::error::ParseBoolError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3str5error14ParseBoolErrorNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !696 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::str::error::ParseBoolError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsa_NtNtCsl10jNU3mE6R_4core3str5errorNtB5_14ParseBoolErrorNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&&str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !697 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <&str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtReNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&i8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !698 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCs4mnquxVp34G_6errors(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !699 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs4mnquxVp34G_6errors(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !700 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <f64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtReNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !701 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !702 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCs4mnquxVp34G_6errors(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !703 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i32 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 4 %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&i64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRxNtB6_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !704 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsR_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_7Display3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !705 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <alloc::string::String as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCs4mnquxVp34G_6errors(ptr align 8 %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&core::num::error::ParseIntError as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_7Display3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !706 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXs4_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt7Display3fmt(ptr %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRxNtB6_7Display3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !707 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i64 as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <core::slice::iter::Iter<&str> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterReENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !708 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<&str> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullReENtNtB9_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %ptr, ptr align 8 %_11) #25
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw { ptr, i64 }, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !709 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %ptr, ptr align 8 %_11) #25
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw i8, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !710 {
start:
  %end = alloca [8 x i8], align 8
  %_2 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  br label %bb3

bb3:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_6 = load ptr, ptr %0, align 8
  store ptr %_6, ptr %end, align 8
; call <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
  %1 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %end) #25
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_2, align 1
  br label %bb4

bb4:                                              ; preds = %bb3
  %3 = load i8, ptr %_2, align 1
  %4 = trunc nuw i8 %3 to i1
  br i1 %4, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
; call <core::slice::iter::Iter<u8>>::next_back_unchecked
  %_9 = call ptr @_RNvMs2H_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhE19next_back_uncheckedCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  store ptr %_9, ptr %_0, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store ptr null, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb5, %bb6
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !711 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #25
  ret void
}

; <alloc::vec::Vec<u8> as alloc::vec::spec_extend::SpecExtend<&u8, core::slice::iter::Iter<u8>>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs2_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB7_3VechEINtB5_10SpecExtendRhINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhEE11spec_extendCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #1 !guid !712 {
start:
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %2 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %2, align 8
; call <core::slice::iter::Iter<u8>>::as_slice
  %3 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE8as_sliceCs4mnquxVp34G_6errors(ptr align 8 %iterator) #25
  %slice.0 = extractvalue { ptr, i64 } %3, 0
  %slice.1 = extractvalue { ptr, i64 } %3, 1
; call <alloc::vec::Vec<u8>>::append_elements
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE15append_elementsCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %slice.0, i64 %slice.1) #25
  ret void
}

; <core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_15ParseFloatErrorNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !713 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_252aee8158a2b6b4b1e300c3f8f7bd7a, i64 15, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.5)
  ret i1 %_0
}

; <core::str::iter::CharIndices as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !714 {
start:
  %_0.i1 = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %_4 = alloca [4 x i8], align 4
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.i2 = load ptr, ptr %0, align 8
  %_6.i3 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %_5.i2, ptr %_6.i3) #25
  store i64 %1, ptr %_0.i1, align 8
  %2 = load i64, ptr %_0.i1, align 8
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
  %3 = call i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  store i32 %3, ptr %_4, align 4
  %4 = load i32, ptr %_4, align 4
  %5 = icmp eq i32 %4, -1
  %_6 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_6 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %ch = load i32, ptr %_4, align 4
  %7 = getelementptr inbounds i8, ptr %self, i64 16
  %index = load i64, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.i = load ptr, ptr %8, align 8
  %_6.i = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %9 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %_5.i, ptr %_6.i) #25
  store i64 %9, ptr %_0.i, align 8
  %10 = load i64, ptr %_0.i, align 8
  %_11 = sub i64 %2, %10
  %11 = getelementptr inbounds i8, ptr %self, i64 16
  %12 = getelementptr inbounds i8, ptr %self, i64 16
  %13 = load i64, ptr %12, align 8
  %14 = add i64 %13, %_11
  store i64 %14, ptr %11, align 8
  store i64 %index, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %ch, ptr %15, align 8
  br label %bb7

bb5:                                              ; preds = %start
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 -1, ptr %16, align 8
  br label %bb7

bb7:                                              ; preds = %bb4, %bb5
  %17 = load i64, ptr %_0, align 8
  %18 = getelementptr inbounds i8, ptr %_0, i64 8
  %19 = load i32, ptr %18, align 8
  %20 = insertvalue { i64, i32 } poison, i64 %17, 0
  %21 = insertvalue { i64, i32 } %20, i32 %19, 1
  ret { i64, i32 } %21

bb3:                                              ; No predecessors!
  unreachable
}

; <<char>::is_whitespace as core::str::pattern::MultiCharEq>::matches
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_11MultiCharEq7matchesCs4mnquxVp34G_6errors(ptr %self, i32 %c) unnamed_addr #0 !guid !715 {
start:
; call <<char>::is_whitespace as core::ops::function::FnMut<(char,)>>::call_mut
  %_0 = call zeroext i1 @_RNvYNvMNtNtCsl10jNU3mE6R_4core4char7methodsc13is_whitespaceINtNtNtB9_3ops8function5FnMutTcEE8call_mutCs4mnquxVp34G_6errors(ptr %self, i32 %c) #25
  ret i1 %_0
}

; <core::array::iter::IntoIter<&str, 4> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj4_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !716 {
start:
; call <core::array::iter::IntoIter<&str, 4>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterReKj4_E10unsize_mutCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next
  %1 = call { ptr, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEE4nextCs4mnquxVp34G_6errors(ptr align 8 %_2.0, i64 %_2.1) #25
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::array::iter::IntoIter<&str, 7> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj7_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !717 {
start:
; call <core::array::iter::IntoIter<&str, 7>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterReKj7_E10unsize_mutCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next
  %1 = call { ptr, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEE4nextCs4mnquxVp34G_6errors(ptr align 8 %_2.0, i64 %_2.1) #25
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <u8 as core::slice::cmp::SlicePartialEq<u8>>::equal_same_length
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core5slice3cmphINtB5_14SlicePartialEqhE17equal_same_lengthCs4mnquxVp34G_6errors(ptr %lhs, ptr %rhs, i64 %len) unnamed_addr #0 !guid !718 {
start:
  %size = mul nuw i64 %len, 1
  %_5 = call i32 @memcmp(ptr %lhs, ptr %rhs, i64 %size)
  %_0 = icmp eq i32 %_5, 0
  ret i1 %_0
}

; <&i32 as core::ops::arith::Rem<i32>>::rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs4J_NtNtCsl10jNU3mE6R_4core3ops5arithRlINtB6_3RemlE3remCs4mnquxVp34G_6errors(ptr align 4 %self, i32 %other, ptr align 8 %0) unnamed_addr #0 !guid !719 {
start:
  %_3 = load i32, ptr %self, align 4
; call <i32 as core::ops::arith::Rem>::rem
  %_0 = call i32 @_RNvXs4f_NtNtCsl10jNU3mE6R_4core3ops5arithlNtB6_3Rem3remCs4mnquxVp34G_6errors(i32 %_3, i32 %other, ptr align 8 %0) #25
  ret i32 %_0
}

; <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs4_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEENtNtNtNtB11_4iter6traits8iterator8Iterator9size_hintCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !720 {
start:
  %exact = alloca [8 x i8], align 8
  br label %bb5

bb5:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 24
  %_8 = load ptr, ptr %_10, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_11 = load ptr, ptr %0, align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %_8, ptr %_11) #25
  store i64 %1, ptr %exact, align 8
  br label %bb6

bb6:                                              ; preds = %bb5
  %_12 = load i64, ptr %exact, align 8
  %_14 = load i64, ptr %exact, align 8
  store i64 %_12, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %_14, ptr %3, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits12double_ended19DoubleEndedIterator9next_backCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !721 {
start:
; call <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_2 = call i32 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_5CharsNtNtNtNtB9_4iter6traits12double_ended19DoubleEndedIterator9next_backCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_5 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::option::Option<char>>::map::<(usize, char), <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}>
  %0 = call { i64, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptioncE3mapTjcENCNvXs4_NtNtB5_3str4iterNtB10_11CharIndicesNtNtNtNtB5_4iter6traits12double_ended19DoubleEndedIterator9next_back0ECs4mnquxVp34G_6errors(i32 %_2, ptr align 8 %_5, ptr align 8 %self) #25
  %_0.0 = extractvalue { i64, i32 } %0, 0
  %_0.1 = extractvalue { i64, i32 } %0, 1
  %1 = insertvalue { i64, i32 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i32 } %1, i32 %_0.1, 1
  ret { i64, i32 } %2
}

; <i32 as core::ops::arith::Rem>::rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs4f_NtNtCsl10jNU3mE6R_4core3ops5arithlNtB6_3Rem3remCs4mnquxVp34G_6errors(i32 %self, i32 %other, ptr align 8 %0) unnamed_addr #0 !guid !722 {
start:
  %_3 = icmp eq i32 %other, 0
  br i1 %_3, label %panic, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp eq i32 %other, -1
  %_5 = icmp eq i32 %self, -2147483648
  %_6 = and i1 %_4, %_5
  br i1 %_6, label %panic1, label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 %0) #29
  unreachable

bb2:                                              ; preds = %bb1
  %_0 = srem i32 %self, %other
  ret i32 %_0

panic1:                                           ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 %0) #29
  unreachable
}

; <core::ops::index_range::IndexRange as core::clone::Clone>::clone
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !723 {
start:
  %_2 = load i64, ptr %self, align 8
  %_5 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %_5, align 8
  %0 = insertvalue { i64, i64 } poison, i64 %_2, 0
  %1 = insertvalue { i64, i64 } %0, i64 %_4, 1
  ret { i64, i64 } %1
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCs4mnquxVp34G_6errors(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !724 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECs4mnquxVp34G_6errors(ptr %slice.0, i64 %slice.1) #25
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked::precondition_check
  call void @_RNvNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCs4mnquxVp34G_6errors(i64 %self.0, i64 %self.1, i64 %_0.i1, ptr align 8 %0) #27
  br label %bb3

bb3:                                              ; preds = %bb1
  %new_len = sub nuw i64 %self.1, %self.0
  %_0.i = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self.0
; call <*const u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh10cast_sliceCs4mnquxVp34G_6errors(ptr %_0.i, i64 %new_len) #25
  %_12.0 = extractvalue { ptr, i64 } %1, 0
  %_12.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_12.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_12.1, 1
  ret { ptr, i64 } %3
}

; <core::array::iter::IntoIter<&str, 4> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj4_ENtNtNtB9_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !725 {
start:
; call core::mem::needs_drop::<&str>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropReECs4mnquxVp34G_6errors() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitReEj4_EE4dropCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  br label %bb3
}

; <core::array::iter::IntoIter<&str, 7> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj7_ENtNtNtB9_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !726 {
start:
; call core::mem::needs_drop::<&str>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropReECs4mnquxVp34G_6errors() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 7]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitReEj7_EE4dropCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  br label %bb3
}

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !727 {
start:
; call <[u8]>::to_vec
  call void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #25
  ret void
}

; <&[u8] as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRShNtB7_9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !728 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
  %_4.0 = load ptr, ptr %other, align 8
  %1 = getelementptr inbounds i8, ptr %other, i64 8
  %_4.1 = load i64, ptr %1, align 8
; call <[u8] as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core5slice3cmpShNtNtB6_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr %_3.0, i64 %_3.1, ptr %_4.0, i64 %_4.1) #25
  ret i1 %_0
}

; <core::str::pattern::MultiCharEqPattern<<char>::is_whitespace> as core::str::pattern::Pattern>::into_searcher
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs7_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_18MultiCharEqPatternNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_7Pattern13into_searcherCs4mnquxVp34G_6errors(ptr sret([40 x i8]) align 8 %_0, ptr %haystack.0, i64 %haystack.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !729 {
start:
  %_4 = alloca [24 x i8], align 8
; call <str>::char_indices
  call void @_RNvMNtCsl10jNU3mE6R_4core3stre12char_indicesCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_4, ptr %haystack.0, i64 %haystack.1) #25
  br label %bb1

bb1:                                              ; preds = %start
  store ptr %haystack.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %haystack.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %_4, i64 24, i1 false)
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<dyn core::error::Error> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtNtBM_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !730 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<dyn core::error::Error>>::as_ptr
  %1 = call { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_5error5ErrorEL_E6as_ptrCs4mnquxVp34G_6errors(ptr %ptr.0, ptr align 8 %ptr.1) #25
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<dyn core::error::Error>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_5error5ErrorEL_ECs4mnquxVp34G_6errors(ptr %_5.0, ptr align 8 %_5.1) #25
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<dyn core::error::Error>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_5error5ErrorEL_E4casthECs4mnquxVp34G_6errors(ptr %ptr.0, ptr align 8 %ptr.1) #25
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs4mnquxVp34G_6errors(ptr %_12) #25
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs4mnquxVp34G_6errors(ptr %_10, ptr %_11, i64 %6, i64 %8) #25
  br label %bb7
}

; <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBM_6marker4SyncNtB1j_4SendEL_ENtNtNtBM_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !731 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<dyn core::error::Error + core::marker::Sync + core::marker::Send>>::as_ptr
  %1 = call { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_5error5ErrorNtNtB9_6marker4SyncNtB1c_4SendEL_E6as_ptrCs4mnquxVp34G_6errors(ptr %ptr.0, ptr align 8 %ptr.1) #25
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<dyn core::error::Error + core::marker::Sync + core::marker::Send>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_5error5ErrorNtNtB7_6marker4SyncNtB1q_4SendEL_ECs4mnquxVp34G_6errors(ptr %_5.0, ptr align 8 %_5.1) #25
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<dyn core::error::Error + core::marker::Sync + core::marker::Send>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_5error5ErrorNtNtBa_6marker4SyncNtB1d_4SendEL_E4casthECs4mnquxVp34G_6errors(ptr %ptr.0, ptr align 8 %ptr.1) #25
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs4mnquxVp34G_6errors(ptr %_12) #25
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs4mnquxVp34G_6errors(ptr %_10, ptr %_11, i64 %6, i64 %8) #25
  br label %bb7
}

; <alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtNtCsl10jNU3mE6R_4core3mem12maybe_uninit11MaybeUninitAINtNtBO_6result6ResultlNtNtB7_6string6StringEj3_EENtNtNtBO_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !732 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr = load ptr, ptr %self, align 8
; call <core::ptr::unique::Unique<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>>::as_ptr
  %_5 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueINtNtNtB9_3mem12maybe_uninit11MaybeUninitAINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EE6as_ptrCs4mnquxVp34G_6errors(ptr %ptr) #25
; call <core::alloc::layout::Layout>::for_value_raw::<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>
  %0 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawINtNtNtB7_3mem12maybe_uninit11MaybeUninitAINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EECs4mnquxVp34G_6errors(ptr %_5) #25
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %layout, align 8
  %3 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %2, ptr %3, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ptr::unique::Unique<core::mem::maybe_uninit::MaybeUninit<[core::result::Result<i32, alloc::string::String>; 3]>>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueINtNtNtBa_3mem12maybe_uninit11MaybeUninitAINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEj3_EE4casthECs4mnquxVp34G_6errors(ptr %ptr) #25
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs4mnquxVp34G_6errors(ptr %_12) #25
  %4 = load i64, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs4mnquxVp34G_6errors(ptr %_10, ptr %_11, i64 %4, i64 %6) #25
  br label %bb7
}

; <alloc::boxed::Box<[core::result::Result<i32, alloc::string::String>]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtNtBN_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !733 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[core::result::Result<i32, alloc::string::String>]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE6as_ptrCs4mnquxVp34G_6errors(ptr %ptr.0, i64 %ptr.1) #25
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[core::result::Result<i32, alloc::string::String>]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSINtNtB7_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr %_5.0, i64 %_5.1) #25
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4mnquxVp34G_6errors(ptr align 8 %layout) #25
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[core::result::Result<i32, alloc::string::String>]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSINtNtBa_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEE4casthECs4mnquxVp34G_6errors(ptr %ptr.0, i64 %ptr.1) #25
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs4mnquxVp34G_6errors(ptr %_12) #25
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs4mnquxVp34G_6errors(ptr %_10, ptr %_11, i64 %6, i64 %8) #25
  br label %bb7
}

; <core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_14FloatErrorKindNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !734 {
start:
  %_3 = alloca [16 x i8], align 8
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %_4 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_4 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr @alloc_6693e43df3406efcf64b4ab3d59228bb, ptr %_3, align 8, !captures !612
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 7, ptr %3, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store ptr @alloc_59ba7b9f7211443cd55a366616eef46a, ptr %_3, align 8, !captures !612
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %4, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_3, align 8
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  %7 = load i64, ptr %6, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %5, i64 %7)
  ret i1 %_0

bb1:                                              ; No predecessors!
  unreachable
}

; <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher4nextCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !735 {
start:
  %_0.i1 = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %_5 = alloca [16 x i8], align 8
  %s = getelementptr inbounds i8, ptr %self, i64 16
  %0 = getelementptr inbounds i8, ptr %s, i64 8
  %_5.i2 = load ptr, ptr %0, align 8
  %_6.i3 = load ptr, ptr %s, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %_5.i2, ptr %_6.i3) #25
  store i64 %1, ptr %_0.i1, align 8
  %2 = load i64, ptr %_0.i1, align 8
; call <core::str::iter::CharIndices as core::iter::traits::iterator::Iterator>::next
  %3 = call { i64, i32 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %s) #25
  %4 = extractvalue { i64, i32 } %3, 0
  %5 = extractvalue { i64, i32 } %3, 1
  store i64 %4, ptr %_5, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 8
  store i32 %5, ptr %6, align 8
  %7 = load i64, ptr %_5, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = icmp eq i32 %9, -1
  %_6 = select i1 %10, i64 0, i64 1
  %11 = trunc nuw i64 %_6 to i1
  br i1 %11, label %bb3, label %bb8

bb3:                                              ; preds = %start
  %i = load i64, ptr %_5, align 8
  %12 = getelementptr inbounds i8, ptr %_5, i64 8
  %c = load i32, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %s, i64 8
  %_5.i = load ptr, ptr %13, align 8
  %_6.i = load ptr, ptr %s, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %14 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %_5.i, ptr %_6.i) #25
  store i64 %14, ptr %_0.i, align 8
  %15 = load i64, ptr %_0.i, align 8
  %char_len = sub i64 %2, %15
  %_13 = getelementptr inbounds i8, ptr %self, i64 40
; call <<char>::is_whitespace as core::str::pattern::MultiCharEq>::matches
  %_12 = call zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_11MultiCharEq7matchesCs4mnquxVp34G_6errors(ptr %_13, i32 %c) #25
  br i1 %_12, label %bb6, label %bb7

bb8:                                              ; preds = %start
  store i64 2, ptr %_0, align 8
  br label %bb9

bb7:                                              ; preds = %bb3
  %_15 = add i64 %i, %char_len
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %i, ptr %16, align 8
  %17 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %_15, ptr %17, align 8
  store i64 1, ptr %_0, align 8
  br label %bb9

bb6:                                              ; preds = %bb3
  %_14 = add i64 %i, %char_len
  %18 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %i, ptr %18, align 8
  %19 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %_14, ptr %19, align 8
  store i64 0, ptr %_0, align 8
  br label %bb9

bb9:                                              ; preds = %bb8, %bb6, %bb7
  ret void

bb10:                                             ; No predecessors!
  unreachable
}

; <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs9_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher9next_backCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !736 {
start:
  %_0.i1 = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %_5 = alloca [16 x i8], align 8
  %s = getelementptr inbounds i8, ptr %self, i64 16
  %0 = getelementptr inbounds i8, ptr %s, i64 8
  %_5.i2 = load ptr, ptr %0, align 8
  %_6.i3 = load ptr, ptr %s, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %_5.i2, ptr %_6.i3) #25
  store i64 %1, ptr %_0.i1, align 8
  %2 = load i64, ptr %_0.i1, align 8
; call <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %3 = call { i64, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits12double_ended19DoubleEndedIterator9next_backCs4mnquxVp34G_6errors(ptr align 8 %s) #25
  %4 = extractvalue { i64, i32 } %3, 0
  %5 = extractvalue { i64, i32 } %3, 1
  store i64 %4, ptr %_5, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 8
  store i32 %5, ptr %6, align 8
  %7 = load i64, ptr %_5, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = icmp eq i32 %9, -1
  %_6 = select i1 %10, i64 0, i64 1
  %11 = trunc nuw i64 %_6 to i1
  br i1 %11, label %bb3, label %bb8

bb3:                                              ; preds = %start
  %i = load i64, ptr %_5, align 8
  %12 = getelementptr inbounds i8, ptr %_5, i64 8
  %c = load i32, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %s, i64 8
  %_5.i = load ptr, ptr %13, align 8
  %_6.i = load ptr, ptr %s, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %14 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs4mnquxVp34G_6errors(ptr %_5.i, ptr %_6.i) #25
  store i64 %14, ptr %_0.i, align 8
  %15 = load i64, ptr %_0.i, align 8
  %char_len = sub i64 %2, %15
  %_13 = getelementptr inbounds i8, ptr %self, i64 40
; call <<char>::is_whitespace as core::str::pattern::MultiCharEq>::matches
  %_12 = call zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_11MultiCharEq7matchesCs4mnquxVp34G_6errors(ptr %_13, i32 %c) #25
  br i1 %_12, label %bb6, label %bb7

bb8:                                              ; preds = %start
  store i64 2, ptr %_0, align 8
  br label %bb9

bb7:                                              ; preds = %bb3
  %_15 = add i64 %i, %char_len
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %i, ptr %16, align 8
  %17 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %_15, ptr %17, align 8
  store i64 1, ptr %_0, align 8
  br label %bb9

bb6:                                              ; preds = %bb3
  %_14 = add i64 %i, %char_len
  %18 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %i, ptr %18, align 8
  %19 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %_14, ptr %19, align 8
  store i64 0, ptr %_0, align 8
  br label %bb9

bb9:                                              ; preds = %bb8, %bb6, %bb7
  ret void

bb10:                                             ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringINtNtB7_5boxed3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBV_6marker4SyncNtB1s_4SendEL_ENtB5_8ToString9to_stringCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !737 {
start:
; call <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXsC_NtCs7CppTae75M1_5alloc6stringINtNtB7_5boxed3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBV_6marker4SyncNtB1s_4SendEL_ENtB5_12SpecToString14spec_to_stringCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #25
  ret void
}

; <errors::AppError as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringNtCs4mnquxVp34G_6errors8AppErrorNtB5_8ToString9to_stringBA_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !738 {
start:
; call <errors::AppError as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXsC_NtCs7CppTae75M1_5alloc6stringNtCs4mnquxVp34G_6errors8AppErrorNtB5_12SpecToString14spec_to_stringBA_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #25
  ret void
}

; <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsC_NtCs7CppTae75M1_5alloc6stringINtNtB7_5boxed3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBV_6marker4SyncNtB1s_4SendEL_ENtB5_12SpecToString14spec_to_stringCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !739 {
start:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %_6 = alloca [8 x i8], align 4
  %formatter = alloca [24 x i8], align 8
  %buf = alloca [24 x i8], align 8
; call <alloc::string::String>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %buf) #25
; invoke <core::fmt::FormattingOptions>::new
  %3 = invoke i64 @_RNvMs_NtCsl10jNU3mE6R_4core3fmtNtB4_17FormattingOptions3new()
          to label %bb2 unwind label %cleanup

bb6:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr align 8 %buf) #23
          to label %bb7 unwind label %terminate

cleanup:                                          ; preds = %bb4, %bb3, %bb2, %start
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %2, align 8
  %7 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i64 %3, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_6, ptr align 8 %1, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 4 %_6, i64 8, i1 false)
  %8 = load i64, ptr %0, align 8
; invoke <core::fmt::Formatter>::new
  invoke void @_RNvMs1_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3new(ptr sret([24 x i8]) align 8 %formatter, ptr %buf, ptr align 8 @vtable.6, i64 %8)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %bb2
; invoke <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::fmt::Display>::fmt
  %_8 = invoke zeroext i1 @_RNvXsm_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBM_6marker4SyncNtB1j_4SendEL_ENtNtBM_3fmt7Display3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %formatter)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke <core::result::Result<(), core::fmt::Error>>::expect
  invoke void @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6expectCs4mnquxVp34G_6errors(i1 zeroext %_8, ptr @alloc_cc656815297f75969399c3f4b1ad3de4, i64 55, ptr align 8 @alloc_7213f65d6896e5c55b82fdf6cd68b1f1)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %buf, i64 24, i1 false)
  ret void

terminate:                                        ; preds = %bb6
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb7:                                              ; preds = %bb6
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; <errors::AppError as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsC_NtCs7CppTae75M1_5alloc6stringNtCs4mnquxVp34G_6errors8AppErrorNtB5_12SpecToString14spec_to_stringBA_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !740 {
start:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %_6 = alloca [8 x i8], align 4
  %formatter = alloca [24 x i8], align 8
  %buf = alloca [24 x i8], align 8
; call <alloc::string::String>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %buf) #25
; invoke <core::fmt::FormattingOptions>::new
  %3 = invoke i64 @_RNvMs_NtCsl10jNU3mE6R_4core3fmtNtB4_17FormattingOptions3new()
          to label %bb2 unwind label %cleanup

bb6:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs4mnquxVp34G_6errors(ptr align 8 %buf) #23
          to label %bb7 unwind label %terminate

cleanup:                                          ; preds = %bb4, %bb3, %bb2, %start
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %2, align 8
  %7 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i64 %3, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_6, ptr align 8 %1, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 4 %_6, i64 8, i1 false)
  %8 = load i64, ptr %0, align 8
; invoke <core::fmt::Formatter>::new
  invoke void @_RNvMs1_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3new(ptr sret([24 x i8]) align 8 %formatter, ptr %buf, ptr align 8 @vtable.6, i64 %8)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %bb2
; invoke <errors::AppError as core::fmt::Display>::fmt
  %_8 = invoke zeroext i1 @_RNvXCs4mnquxVp34G_6errorsNtB2_8AppErrorNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt(ptr align 8 %self, ptr align 8 %formatter)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke <core::result::Result<(), core::fmt::Error>>::expect
  invoke void @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6expectCs4mnquxVp34G_6errors(i1 zeroext %_8, ptr @alloc_cc656815297f75969399c3f4b1ad3de4, i64 55, ptr align 8 @alloc_7213f65d6896e5c55b82fdf6cd68b1f1)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %buf, i64 24, i1 false)
  ret void

terminate:                                        ; preds = %bb6
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb7:                                              ; preds = %bb6
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; <core::option::Option<&u8> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRhENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr %0) unnamed_addr #0 !guid !741 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&i32> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRlENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr align 4 %0) unnamed_addr #0 !guid !742 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !743 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #25
  ret void
}

; <core::fmt::Error as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsK_NtCsl10jNU3mE6R_4core3fmtNtB5_5ErrorNtB5_5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !744 {
start:
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_99ac8a81a24cac863217ce4a5cbfabea, i64 5)
  ret i1 %_0
}

; <core::option::Option<i32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4mnquxVp34G_6errors() unnamed_addr #0 !guid !745 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { i32, i32 } { i32 0, i32 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4mnquxVp34G_6errors() unnamed_addr #0 !guid !746 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { i32, i32 } { i32 0, i32 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <i8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !747 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <i32 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !748 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i32 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i32 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i32 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::option::Option<i32> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !749 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i32, ptr %self, align 4
  %1 = getelementptr inbounds i8, ptr %self, i64 4
  %2 = load i32, ptr %1, align 4
  %_3 = zext i32 %0 to i64
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  store ptr %4, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.7)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <i64 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !750 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i64 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsD_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_8LowerHex3fmt(ptr align 8 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i64 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i64 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsF_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_8UpperHex3fmt(ptr align 8 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs4mnquxVp34G_6errors() unnamed_addr #0 !guid !751 {
start:
  ret i8 0
}

; <u8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !752 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <alloc::string::String as core::fmt::Write>::write_char
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write10write_charCs4mnquxVp34G_6errors(ptr align 8 %self, i32 %c) unnamed_addr #0 !guid !753 {
start:
; call <alloc::string::String>::push
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs4mnquxVp34G_6errors(ptr align 8 %self, i32 %c) #25
  ret i1 false
}

; <alloc::string::String as core::fmt::Write>::write_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_strCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !754 {
start:
; call <alloc::string::String>::push_str
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %s.0, i64 %s.1) #25
  ret i1 false
}

; <errors::AppError as core::error::Error>::source
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXs_Cs4mnquxVp34G_6errorsNtB4_8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error6source(ptr align 8 %self) unnamed_addr #1 !guid !755 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = load i64, ptr %self, align 8
  %1 = sub i64 %0, -9223372036854775808
  %2 = icmp uge i64 %0, -9223372036854775808
  %_2 = select i1 %2, i64 %1, i64 2
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %e = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %e, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr @vtable.8, ptr %4, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %5 = load ptr, ptr %_0, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  %7 = load ptr, ptr %6, align 8
  %8 = insertvalue { ptr, ptr } poison, ptr %5, 0
  %9 = insertvalue { ptr, ptr } %8, ptr %7, 1
  ret { ptr, ptr } %9
}

; <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCs4mnquxVp34G_6errors(ptr align 8 %0) unnamed_addr #0 !guid !756 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
; call <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_3 = call i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenCs4mnquxVp34G_6errors(ptr align 8 %self)
  %_2 = icmp ugt i64 %_3, 0
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  %1 = load ptr, ptr %self, align 8
; call <core::ops::index_range::IndexRange>::next_unchecked
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCs4mnquxVp34G_6errors(ptr align 8 %1) #25
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <str as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3str6traitseNtNtB8_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr %self.0, i64 %self.1, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !757 {
start:
  %_6 = alloca [16 x i8], align 8
  %_4 = alloca [16 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %2 = extractvalue { ptr, i64 } %1, 0
  %3 = extractvalue { ptr, i64 } %1, 1
  store ptr %2, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %3, ptr %4, align 8
  %5 = insertvalue { ptr, i64 } poison, ptr %other.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %other.1, 1
  %7 = extractvalue { ptr, i64 } %6, 0
  %8 = extractvalue { ptr, i64 } %6, 1
  store ptr %7, ptr %_6, align 8
  %9 = getelementptr inbounds i8, ptr %_6, i64 8
  store i64 %8, ptr %9, align 8
; call <&[u8] as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRShNtB7_9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %_4, ptr align 8 %_6) #25
  ret i1 %_0
}

; <&[&str] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXs_NtNtCsl10jNU3mE6R_4core5slice4iterRSReNtNtNtNtB8_4iter6traits7collect12IntoIterator9into_iterCs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1) unnamed_addr #1 !guid !758 {
start:
; call <[&str]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSRe4iterCs4mnquxVp34G_6errors(ptr align 8 %self.0, i64 %self.1) #25
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>; 4] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitReEj4_NtB4_11PartialDrop12partial_dropCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !759 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&str>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitReENtB2_11PartialDrop12partial_dropCs4mnquxVp34G_6errors(ptr align 8 %self, i64 4, i64 %alive.0, i64 %alive.1)
  ret void
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>; 7] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitReEj7_NtB4_11PartialDrop12partial_dropCs4mnquxVp34G_6errors(ptr align 8 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !760 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&str>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitReENtB2_11PartialDrop12partial_dropCs4mnquxVp34G_6errors(ptr align 8 %self, i64 7, i64 %alive.0, i64 %alive.1)
  ret void
}

; <&mut alloc::string::String as core::fmt::Write::write_fmt::SpecWriteFmt>::spec_write_fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs_NvNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtQNtNtCs7CppTae75M1_5alloc6string6StringNtB4_12SpecWriteFmt14spec_write_fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #0 !guid !761 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_statically_known_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments23as_statically_known_strCs4mnquxVp34G_6errors(ptr align 8 %args) #25
  %4 = extractvalue { ptr, i64 } %3, 0
  %5 = extractvalue { ptr, i64 } %3, 1
  store ptr %4, ptr %_3, align 8
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %5, ptr %6, align 8
  %7 = load ptr, ptr %_3, align 8
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = ptrtoint ptr %7 to i64
  %11 = icmp eq i64 %10, 0
  %_5 = select i1 %11, i64 0, i64 1
  %12 = trunc nuw i64 %_5 to i1
  br i1 %12, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %s.0 = load ptr, ptr %_3, align 8
  %13 = getelementptr inbounds i8, ptr %_3, i64 8
  %s.1 = load i64, ptr %13, align 8
; call <alloc::string::String as core::fmt::Write>::write_str
  %14 = call zeroext i1 @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_strCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %s.0, i64 %s.1) #25
  %15 = zext i1 %14 to i8
  store i8 %15, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %16 = load ptr, ptr %args, align 8
  %17 = getelementptr inbounds i8, ptr %args, i64 8
  %18 = load ptr, ptr %17, align 8
; call core::fmt::write
  %19 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt5write(ptr %self, ptr align 8 @vtable.6, ptr %16, ptr %18)
  %20 = zext i1 %19 to i8
  store i8 %20, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %21 = load i8, ptr %_0, align 1
  %22 = trunc nuw i8 %21 to i1
  ret i1 %22

bb5:                                              ; No predecessors!
  unreachable
}

; <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCs4mnquxVp34G_6errors(ptr %pointer) unnamed_addr #0 !guid !762 {
start:
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCs4mnquxVp34G_6errors(ptr %pointer) #25
  ret ptr %_0
}

; <core::str::error::ParseBoolError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtNtCsl10jNU3mE6R_4core3str5errorNtB5_14ParseBoolErrorNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !763 {
start:
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_18387e0fb79f5c7b2d13985332f32f7b, i64 14)
  ret i1 %_0
}

; <alloc::boxed::Box<dyn core::error::Error> as core::convert::From<errors::AppError>>::from
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXsd_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_EINtNtBW_7convert4FromNtCs4mnquxVp34G_6errors8AppErrorE4fromB1S_(ptr align 8 %err) unnamed_addr #1 personality ptr @rust_eh_personality !guid !764 {
start:
  %0 = alloca [16 x i8], align 8
  %_4.i = alloca [1 x i8], align 1
  %1 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %err, i64 24, i1 false)
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; invoke alloc::boxed::box_new_uninit
  %_3.i = invoke ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs4mnquxVp34G_6errors(i64 8, i64 24)
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtCs4mnquxVp34G_6errors8AppErrorE3newBG_.exit unwind label %cleanup.i

cleanup.i:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  %6 = load i8, ptr %_4.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3.i, label %bb2.i

bb2.i:                                            ; preds = %bb3.i, %cleanup.i
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb3.i:                                            ; preds = %cleanup.i
; invoke core::ptr::drop_glue::<errors::AppError>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCs4mnquxVp34G_6errors8AppErrorEBD_(ptr align 8 %1) #23
          to label %bb2.i unwind label %terminate.i

terminate.i:                                      ; preds = %bb3.i
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtCs4mnquxVp34G_6errors8AppErrorE3newBG_.exit: ; preds = %start
  store i8 0, ptr %_4.i, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3.i, ptr align 8 %1, i64 24, i1 false)
  %14 = insertvalue { ptr, ptr } poison, ptr %_3.i, 0
  %15 = insertvalue { ptr, ptr } %14, ptr @vtable.9, 1
  ret { ptr, ptr } %15
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !765 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.a)
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB9_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !766 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<&str> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullReENtNtB9_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !767 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !768 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXse_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEENtNtNtB11_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !769 {
start:
  %0 = alloca [16 x i8], align 8
  %guard = alloca [8 x i8], align 8
  store ptr %self, ptr %guard, align 8
  %_5 = load ptr, ptr %guard, align 8
; invoke <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>>>::as_raw_mut_slice
  %1 = invoke { ptr, i64 } @_RNvMs0_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEE16as_raw_mut_sliceCs4mnquxVp34G_6errors(ptr align 8 %_5)
          to label %bb1 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<<alloc::vec::into_iter::IntoIter<_, _> as core::ops::drop::Drop>::drop::DropGuard<core::result::Result<i32, alloc::string::String>, alloc::alloc::Global>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvXse_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtBK_8IntoIterppENtNtNtB4_3ops4drop4Drop4drop9DropGuardINtNtB4_6result6ResultlNtNtBO_6string6StringENtNtBO_5alloc6GlobalEECs4mnquxVp34G_6errors(ptr align 8 %guard) #23
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb1, %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb4

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; invoke core::ptr::drop_glue::<[core::result::Result<i32, alloc::string::String>]>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_4.0, i64 %_4.1)
          to label %_RINvNtCsl10jNU3mE6R_4core3ptr13drop_in_placeSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors.exit unwind label %cleanup

_RINvNtCsl10jNU3mE6R_4core3ptr13drop_in_placeSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors.exit: ; preds = %bb1
  br label %bb2

bb2:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr13drop_in_placeSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors.exit
; call core::ptr::drop_glue::<<alloc::vec::into_iter::IntoIter<_, _> as core::ops::drop::Drop>::drop::DropGuard<core::result::Result<i32, alloc::string::String>, alloc::alloc::Global>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvXse_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtBK_8IntoIterppENtNtNtB4_3ops4drop4Drop4drop9DropGuardINtNtB4_6result6ResultlNtNtBO_6string6StringENtNtBO_5alloc6GlobalEECs4mnquxVp34G_6errors(ptr align 8 %guard)
  ret void

terminate:                                        ; preds = %bb4
  %6 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb5:                                              ; preds = %bb4
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = insertvalue { ptr, i32 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i32 } %10, i32 %9, 1
  resume { ptr, i32 } %11
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !770 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::option::Option<usize> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionjENtNtB7_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !771 {
start:
  %_0 = alloca [1 x i8], align 1
  %_6 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_6 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %_4 = load i64, ptr %other, align 8
  %3 = getelementptr inbounds i8, ptr %other, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_4 to i1
  br i1 %5, label %bb7, label %bb6

bb3:                                              ; preds = %start
  %_5 = load i64, ptr %other, align 8
  %6 = getelementptr inbounds i8, ptr %other, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = trunc nuw i64 %_5 to i1
  br i1 %8, label %bb5, label %bb4

bb5:                                              ; preds = %bb3
  store i8 0, ptr %_0, align 1
  br label %bb8

bb4:                                              ; preds = %bb3
  store i8 1, ptr %_0, align 1
  br label %bb8

bb8:                                              ; preds = %bb7, %bb6, %bb5, %bb4
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb7:                                              ; preds = %bb2
  %l = getelementptr inbounds i8, ptr %self, i64 8
  %r = getelementptr inbounds i8, ptr %other, i64 8
; call <usize as core::cmp::PartialEq>::eq
  %11 = call zeroext i1 @_RNvXsj_NtNtCsl10jNU3mE6R_4core3cmp5implsjNtB7_9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %l, ptr align 8 %r) #25
  %12 = zext i1 %11 to i8
  store i8 %12, ptr %_0, align 1
  br label %bb8

bb6:                                              ; preds = %bb2
  store i8 0, ptr %_0, align 1
  br label %bb8

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBW_6marker4SyncNtB1t_4SendEL_EINtNtBW_7convert4FromNtNtB9_6string6StringE4fromCs4mnquxVp34G_6errors(ptr align 8 %err) unnamed_addr #0 personality ptr @rust_eh_personality !guid !772 {
start:
  %0 = alloca [16 x i8], align 8
  %_4.i = alloca [1 x i8], align 1
  %_3 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3, ptr align 8 %err, i64 24, i1 false)
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; invoke alloc::boxed::box_new_uninit
  %_3.i = invoke ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs4mnquxVp34G_6errors(i64 8, i64 24)
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtNvXsf_NtB2_7convertIBv_DNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB18_6marker4SyncNtB1F_4SendEL_EINtNtB18_7convert4FromNtNtB4_6string6StringE4from11StringErrorE3newCs4mnquxVp34G_6errors.exit unwind label %cleanup.i

cleanup.i:                                        ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  %5 = load i8, ptr %_4.i, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb3.i, label %bb2.i

bb2.i:                                            ; preds = %bb3.i, %cleanup.i
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = insertvalue { ptr, i32 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i32 } %10, i32 %9, 1
  resume { ptr, i32 } %11

bb3.i:                                            ; preds = %cleanup.i
; invoke core::ptr::drop_glue::<<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBL_3BoxDNtNtB4_5error5ErrorNtNtB4_6marker4SyncNtB1R_4SendEL_EINtNtB4_7convert4FromNtNtBN_6string6StringE4from11StringErrorECs4mnquxVp34G_6errors(ptr align 8 %_3) #23
          to label %bb2.i unwind label %terminate.i

terminate.i:                                      ; preds = %bb3.i
  %12 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtNvXsf_NtB2_7convertIBv_DNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB18_6marker4SyncNtB1F_4SendEL_EINtNtB18_7convert4FromNtNtB4_6string6StringE4from11StringErrorE3newCs4mnquxVp34G_6errors.exit: ; preds = %start
  store i8 0, ptr %_4.i, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3.i, ptr align 8 %_3, i64 24, i1 false)
  %13 = insertvalue { ptr, ptr } poison, ptr %_3.i, 0
  %14 = insertvalue { ptr, ptr } %13, ptr @vtable.b, 1
  ret { ptr, ptr } %14
}

; <bool as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3str6traitsbNtB5_7FromStr8from_strCs4mnquxVp34G_6errors(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !773 {
start:
  %_0 = alloca [1 x i8], align 1
; call <str as core::cmp::PartialEq>::eq
  %_3 = call zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3str6traitseNtNtB8_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr %s.0, i64 %s.1, ptr @alloc_c9ee9951a160df092319190fa06505e4, i64 4) #25
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <str as core::cmp::PartialEq>::eq
  %_2 = call zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3str6traitseNtNtB8_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr %s.0, i64 %s.1, ptr @alloc_b81e52ca1a07489f49a3e5fe131c4b29, i64 5) #25
  br i1 %_2, label %bb4, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb7

bb1:                                              ; preds = %bb3
  store i8 2, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb3
  store i8 0, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb4, %bb1
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsg_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtNtNtBK_4iter6traits7collect12IntoIterator9into_iterCs4mnquxVp34G_6errors(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !774 {
start:
  %0 = alloca [24 x i8], align 8
  %_2.i = alloca [24 x i8], align 8
  %1 = alloca [24 x i8], align 8
  %end = alloca [8 x i8], align 8
  %me = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 24, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB6_6result6ResultlNtNtB19_6string6StringEEE3newCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %me, ptr align 8 %_2.i, i64 24, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>>::as_ref
  %_0.i4 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB6_6result6ResultlNtNtB19_6string6StringEEE6as_refCs4mnquxVp34G_6errors(ptr align 8 %me)
; call <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::allocator
  %_6 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE9allocatorCs4mnquxVp34G_6errors(ptr align 8 %_0.i4) #25
; call <core::mem::maybe_dangling::MaybeDangling<alloc::alloc::Global>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtNtCs7CppTae75M1_5alloc5alloc6GlobalE3newCs4mnquxVp34G_6errors()
; call <core::mem::maybe_dangling::MaybeDangling<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>>::as_ref
  %_0.i3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB6_6result6ResultlNtNtB19_6string6StringEEE6as_refCs4mnquxVp34G_6errors(ptr align 8 %me)
; call <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::non_null
  %buf = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE8non_nullCs4mnquxVp34G_6errors(ptr align 8 %_0.i3) #25
  br label %bb13

bb13:                                             ; preds = %start
; call <core::mem::maybe_dangling::MaybeDangling<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>>::as_ref
  %_0.i2 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB6_6result6ResultlNtNtB19_6string6StringEEE6as_refCs4mnquxVp34G_6errors(ptr align 8 %me)
; call <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::len
  %_21 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE3lenCs4mnquxVp34G_6errors(ptr align 8 %_0.i2) #25
  %_0.i = getelementptr inbounds nuw %"core::result::Result<i32, alloc::string::String>", ptr %buf, i64 %_21
  store ptr %_0.i, ptr %end, align 8
  br label %bb17

bb17:                                             ; preds = %bb13
; call <core::mem::maybe_dangling::MaybeDangling<alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>>::as_ref
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB6_6result6ResultlNtNtB19_6string6StringEEE6as_refCs4mnquxVp34G_6errors(ptr align 8 %me)
; call <alloc::raw_vec::RawVec<core::result::Result<i32, alloc::string::String>>>::capacity
  %cap = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE8capacityCs4mnquxVp34G_6errors(ptr align 8 %_0.i1) #25
  %_28 = load ptr, ptr %end, align 8
  store ptr %buf, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %cap, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %buf, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 24
  store ptr %_28, ptr %4, align 8
  ret void

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXsh_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBW_6marker4SyncNtB1t_4SendEL_EINtNtBW_7convert4FromReE4fromCs4mnquxVp34G_6errors(ptr %err.0, i64 %err.1) unnamed_addr #0 !guid !775 {
start:
  %_2 = alloca [24 x i8], align 8
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_2, ptr %err.0, i64 %err.1) #25
; call <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from
  %0 = call { ptr, ptr } @_RNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBW_6marker4SyncNtB1t_4SendEL_EINtNtBW_7convert4FromNtNtB9_6string6StringE4fromCs4mnquxVp34G_6errors(ptr align 8 %_2) #25
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs4mnquxVp34G_6errors(ptr %unique) unnamed_addr #0 !guid !776 {
start:
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCs4mnquxVp34G_6errors(ptr %unique) #25
  ret ptr %_0
}

; <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !777 {
start:
  %_3 = alloca [16 x i8], align 8
  %0 = load i8, ptr %self, align 1
  %_4 = zext i8 %0 to i64
  switch i64 %_4, label %bb1 [
    i64 0, label %bb7
    i64 1, label %bb6
    i64 2, label %bb5
    i64 3, label %bb4
    i64 4, label %bb3
    i64 5, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb7:                                              ; preds = %start
  store ptr @alloc_59ba7b9f7211443cd55a366616eef46a, ptr %_3, align 8, !captures !612
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %1, align 8
  br label %bb8

bb6:                                              ; preds = %start
  store ptr @alloc_00315c78e51d29fe6b3102a4c1ecf6ef, ptr %_3, align 8, !captures !612
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 12, ptr %2, align 8
  br label %bb8

bb5:                                              ; preds = %start
  store ptr @alloc_bd3a3f3879e0d5f64554753e977f58d4, ptr %_3, align 8, !captures !612
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %3, align 8
  br label %bb8

bb4:                                              ; preds = %start
  store ptr @alloc_0964bb2a4870637395c77a018495bd5c, ptr %_3, align 8, !captures !612
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %4, align 8
  br label %bb8

bb3:                                              ; preds = %start
  store ptr @alloc_6566120a3a17f930e960a0863fcbd591, ptr %_3, align 8, !captures !612
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %5, align 8
  br label %bb8

bb2:                                              ; preds = %start
  store ptr @alloc_6c17bac0c71cba42380f8445f4dcbd16, ptr %_3, align 8, !captures !612
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 14, ptr %6, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb3, %bb4, %bb5, %bb6, %bb7
  %7 = load ptr, ptr %_3, align 8
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = load i64, ptr %8, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %7, i64 %9)
  ret i1 %_0
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::iter::traits::collect::Extend<core::result::Result<i32, alloc::string::String>>>::extend_one
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsj_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEEINtNtNtNtBK_4iter6traits7collect6ExtendBF_E10extend_oneCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %item) unnamed_addr #0 !guid !778 {
start:
  %0 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %item, i64 24, i1 false)
; call <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::push
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEE4pushCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %0) #25
  ret void
}

; <usize as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsj_NtNtCsl10jNU3mE6R_4core3cmp5implsjNtB7_9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !779 {
start:
  %_3 = load i64, ptr %self, align 8
  %_4 = load i64, ptr %other, align 8
  %_0 = icmp eq i64 %_3, %_4
  ret i1 %_0
}

; <i8 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXsk_NtCsl10jNU3mE6R_4core3numaNtNtNtB7_3str6traits7FromStr8from_strCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !780 {
start:
; call <i8>::from_str_radix
  %0 = call { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa14from_str_radixCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1, i32 10) #25
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <alloc::boxed::Box<dyn core::error::Error> as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsm_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtBM_3fmt7Display3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !781 {
start:
  %_4.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4.1 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4.1, i64 32
  %2 = load ptr, ptr %1, align 8, !invariant.load !332, !nonnull !332
  %_0 = call zeroext i1 %2(ptr %_4.0, ptr align 8 %f) #25
  ret i1 %_0
}

; <alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsm_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtBM_6marker4SyncNtB1j_4SendEL_ENtNtBM_3fmt7Display3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !782 {
start:
  %_4.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4.1 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4.1, i64 32
  %2 = load ptr, ptr %1, align 8, !invariant.load !332, !nonnull !332
  %_0 = call zeroext i1 %2(ptr %_4.0, ptr align 8 %f) #25
  ret i1 %_0
}

; <core::str::pattern::CharPredicateSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next_reject
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXso_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_21CharPredicateSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher11next_rejectCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !783 {
start:
; call <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next_reject
  call void @_RNvYINtNtNtCsl10jNU3mE6R_4core3str7pattern19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher11next_rejectCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #25
  ret void
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtNtBK_3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !784 {
start:
; call <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB6_6string6StringEE10as_mut_ptrCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut core::result::Result<i32, alloc::string::String>>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtB8_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringE10cast_sliceCs4mnquxVp34G_6errors(ptr %_3, i64 %_4) #25
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
; call core::ptr::drop_glue::<[core::result::Result<i32, alloc::string::String>]>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSINtNtB4_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEECs4mnquxVp34G_6errors(ptr align 8 %_2.0, i64 %_2.1)
  ret void
}

; <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !785 {
start:
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCs4mnquxVp34G_6errors(ptr %_3, i64 %_4) #25
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr %0, i64 %1) unnamed_addr #0 !guid !786 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_2 = select i1 %7, i64 1, i64 0
  %8 = trunc nuw i64 %_2 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %v.1 = load i64, ptr %9, align 8
  store ptr %v.0, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.1, ptr %10, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !787 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = trunc nuw i64 %_2 to i1
  br i1 %0, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %e.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %e.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %e.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v.0 = load ptr, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %v.1 = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %v.0, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 8
  store i64 %v.1, ptr %8, align 8
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr %0) unnamed_addr #0 !guid !788 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtB7_5alloc6layout6LayoutNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !789 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = trunc nuw i64 %_2 to i1
  br i1 %0, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %e.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %e.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %e.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v.0 = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %v.1 = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.0, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 8
  store i64 %v.1, ptr %8, align 8
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<usize, alloc::collections::TryReserveErrorKind> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultjNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !790 {
start:
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load i64, ptr %3, align 8
  store i64 %e.0, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.1, ptr %4, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %6, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i64, errors::AppError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtCs4mnquxVp34G_6errors8AppErrorENtNtNtB7_3ops9try_trait3Try6branchBN_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !791 {
start:
  %_5 = alloca [24 x i8], align 8
  %e = alloca [24 x i8], align 8
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %e, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %e, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb4

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %4, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i64, core::num::error::ParseIntError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtNtNtB7_3num5error13ParseIntErrorENtNtNtB7_3ops9try_trait3Try6branchCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !792 {
start:
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  %e = load i8, ptr %3, align 1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %e, ptr %4, align 1
  store i8 1, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %6, align 8
  store i8 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::str::pattern::CharPredicateSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_reject_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_21CharPredicateSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher16next_reject_backCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !793 {
start:
; call <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_reject_back
  call void @_RNvYINtNtNtCsl10jNU3mE6R_4core3str7pattern19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher16next_reject_backCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #25
  ret void
}

; <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>> as core::default::Default>::default
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsq_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB7_6string6StringEENtNtBK_7default7Default7defaultCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #1 !guid !794 {
start:
; call <alloc::vec::Vec<core::result::Result<i32, alloc::string::String>>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB4_6string6StringEE3newCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0) #25
  ret void
}

; <alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !795 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <i64 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core3numxNtNtNtB7_3str6traits7FromStr8from_strCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !796 {
start:
; call <i64>::from_str_radix
  call void @_RNvMsr_NtCsl10jNU3mE6R_4core3numx14from_str_radixCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 10) #25
  ret void
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs4mnquxVp34G_6errors(ptr align 8 %0) unnamed_addr #0 !guid !797 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { ptr, i64 } { ptr null, i64 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !798 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  %1 = insertvalue { i64, i64 } poison, i64 %residual.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %residual.1, 1
  %_4.0 = extractvalue { i64, i64 } %2, 0
  %_4.1 = extractvalue { i64, i64 } %2, 1
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %_4.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, alloc::boxed::Box<dyn core::error::Error>> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, errors::AppError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtCs4mnquxVp34G_6errors8AppErrorEE13from_residualB2S_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %residual, ptr align 8 %0) unnamed_addr #0 !guid !799 {
start:
  %1 = alloca [24 x i8], align 8
  %e = alloca [24 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %e, ptr align 8 %residual, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %e, i64 24, i1 false)
; call <alloc::boxed::Box<dyn core::error::Error> as core::convert::From<errors::AppError>>::from
  %2 = call { ptr, ptr } @_RNvXsd_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_EINtNtBW_7convert4FromNtCs4mnquxVp34G_6errors8AppErrorE4fromB1S_(ptr align 8 %1)
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
  store ptr %_4.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_4.1, ptr %3, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCs4mnquxVp34G_6errors(i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !800 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  %1 = insertvalue { i64, i64 } poison, i64 %residual.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %residual.1, 1
  %_4.0 = extractvalue { i64, i64 } %2, 0
  %_4.1 = extractvalue { i64, i64 } %2, 1
  %3 = insertvalue { i64, i64 } poison, i64 %_4.0, 0
  %4 = insertvalue { i64, i64 } %3, i64 %_4.1, 1
  ret { i64, i64 } %4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveErrorKind>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtBN_19TryReserveErrorKindEE13from_residualCs4mnquxVp34G_6errors(i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !801 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCs4mnquxVp34G_6errors(i64 %residual.0, i64 %residual.1) #25
  %_4.0 = extractvalue { i64, i64 } %1, 0
  %_4.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_4.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_4.1, 1
  ret { i64, i64 } %3

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i64, errors::AppError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, errors::AppError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtCs4mnquxVp34G_6errors8AppErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualBN_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %residual, ptr align 8 %0) unnamed_addr #0 !guid !802 {
start:
  %1 = alloca [24 x i8], align 8
  %_4 = alloca [24 x i8], align 8
  %e = alloca [24 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %e, ptr align 8 %residual, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %e, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %1, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_4, i64 24, i1 false)
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i64, errors::AppError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::num::error::ParseIntError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtCs4mnquxVp34G_6errors8AppErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtNtNtB7_3num5error13ParseIntErrorEE13from_residualBN_(ptr sret([24 x i8]) align 8 %_0, i8 %residual, ptr align 8 %0) unnamed_addr #0 !guid !803 {
start:
  %_4 = alloca [24 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <errors::AppError as core::convert::From<core::num::error::ParseIntError>>::from
  call void @_RNvXs0_Cs4mnquxVp34G_6errorsNtB5_8AppErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtNtNtBJ_3num5error13ParseIntErrorE4from(ptr sret([24 x i8]) align 8 %_4, i8 %residual)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_4, i64 24, i1 false)
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !804 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <<char>::is_whitespace as core::str::pattern::Pattern>::into_searcher
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsr_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_7Pattern13into_searcherCs4mnquxVp34G_6errors(ptr sret([40 x i8]) align 8 %_0, ptr %haystack.0, i64 %haystack.1) unnamed_addr #0 !guid !805 {
start:
  %_3 = alloca [40 x i8], align 8
; call <core::str::pattern::MultiCharEqPattern<<char>::is_whitespace> as core::str::pattern::Pattern>::into_searcher
  call void @_RNvXs7_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_18MultiCharEqPatternNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_7Pattern13into_searcherCs4mnquxVp34G_6errors(ptr sret([40 x i8]) align 8 %_3, ptr %haystack.0, i64 %haystack.1) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_3, i64 40, i1 false)
  ret void
}

; <core::result::Result<i8, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultaNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !806 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.2)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %8, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.c)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<bool, core::str::error::ParseBoolError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultbNtNtNtB7_3str5error14ParseBoolErrorENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !807 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = icmp eq i8 %0, 2
  %_3 = select i1 %1, i64 1, i64 0
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.e)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.d)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  ret i1 %8

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<f64, core::num::float_parse::ParseFloatError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !808 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.g)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.f)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !809 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.2)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %8, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.h)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, &str> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultlReENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !810 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.i)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.7)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i64, alloc::string::String> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtNtCs7CppTae75M1_5alloc6string6StringENtNtB7_3fmt5Debug3fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !811 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %5, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.3)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <u8 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXsw_NtCsl10jNU3mE6R_4core3numhNtNtNtB7_3str6traits7FromStr8from_strCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !812 {
start:
; call <u8>::from_str_radix
  %0 = call { i1, i8 } @_RNvMsx_NtCsl10jNU3mE6R_4core3numh14from_str_radixCs4mnquxVp34G_6errors(ptr %src.0, i64 %src.1, i32 10) #25
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !813 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCs4mnquxVp34G_6errors(ptr align 8 %self) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4mnquxVp34G_6errors(ptr %_1) unnamed_addr #0 !guid !814 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvYINtNtNtCs7CppTae75M1_5alloc3vec9into_iter8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEENtNtNtNtBV_4iter6traits10exact_size17ExactSizeIterator3lenCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #0 !guid !815 {
start:
  %_7 = alloca [16 x i8], align 8
  %_3 = alloca [24 x i8], align 8
  %upper = alloca [16 x i8], align 8
; call <alloc::vec::into_iter::IntoIter<core::result::Result<i32, alloc::string::String>> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs4_NtNtCs7CppTae75M1_5alloc3vec9into_iterINtB5_8IntoIterINtNtCsl10jNU3mE6R_4core6result6ResultlNtNtB9_6string6StringEENtNtNtNtB11_4iter6traits8iterator8Iterator9size_hintCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %self) #25
  %lower = load i64, ptr %_3, align 8
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = getelementptr inbounds i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
  store i64 %1, ptr %upper, align 8
  %4 = getelementptr inbounds i8, ptr %upper, i64 8
  store i64 %3, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_7, i64 8
  store i64 %lower, ptr %5, align 8
  store i64 1, ptr %_7, align 8
; call <core::option::Option<usize> as core::cmp::PartialEq>::eq
  %_10 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionjENtNtB7_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %upper, ptr align 8 %_7) #25
  br i1 %_10, label %bb3, label %bb4

bb4:                                              ; preds = %start
; call core::panicking::assert_failed::<core::option::Option<usize>, core::option::Option<usize>>
  call void @_RINvNtCsl10jNU3mE6R_4core9panicking13assert_failedINtNtB4_6option6OptionjEBM_EB4_(i8 0, ptr align 8 %upper, ptr align 8 %_7, ptr null, ptr undef, ptr align 8 @alloc_53378387c97726d6569d6d4847e84e24) #29
  unreachable

bb3:                                              ; preds = %start
  ret i64 %lower
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>> as core::cmp::PartialEq>::ne
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvYINtNtNtCsl10jNU3mE6R_4core3ptr8non_null7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB9_3cmp9PartialEq2neCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !816 {
start:
; call <core::ptr::non_null::NonNull<core::result::Result<i32, alloc::string::String>> as core::cmp::PartialEq>::eq
  %_3 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB9_3cmp9PartialEq2eqCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %other) #25
  %_0 = xor i1 %_3, true
  ret i1 %_0
}

; <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_reject_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYINtNtNtCsl10jNU3mE6R_4core3str7pattern19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher16next_reject_backCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !817 {
start:
  %_2 = alloca [24 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %bb1, %start
; call <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_back
  call void @_RNvXs9_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher9next_backCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_2, ptr align 8 %self) #25
  %_3 = load i64, ptr %_2, align 8
  switch i64 %_3, label %bb6 [
    i64 1, label %bb4
    i64 2, label %bb3
    i64 0, label %bb1
  ]

bb6:                                              ; preds = %bb1
  unreachable

bb4:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  %a = load i64, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_2, i64 16
  %b = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %a, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %b, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb1
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next_reject
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYINtNtNtCsl10jNU3mE6R_4core3str7pattern19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher11next_rejectCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !818 {
start:
  %_2 = alloca [24 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %bb1, %start
; call <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next
  call void @_RNvXs8_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher4nextCs4mnquxVp34G_6errors(ptr sret([24 x i8]) align 8 %_2, ptr align 8 %self) #25
  %_3 = load i64, ptr %_2, align 8
  switch i64 %_3, label %bb6 [
    i64 1, label %bb4
    i64 2, label %bb3
    i64 0, label %bb1
  ]

bb6:                                              ; preds = %bb1
  unreachable

bb4:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  %a = load i64, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_2, i64 16
  %b = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %a, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %b, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb1
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4mnquxVp34G_6errors(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !819 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4mnquxVp34G_6errors(ptr align 8 %_1) #25
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <errors::AppError as core::error::Error>::description
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvYNtCs4mnquxVp34G_6errors8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error11descriptionB4_(ptr align 8 %self) unnamed_addr #1 !guid !820 {
start:
  ret { ptr, i64 } { ptr @alloc_04d7ce44d7c86a9a02b346ab945bf155, i64 40 }
}

; <errors::AppError as core::error::Error>::cause
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvYNtCs4mnquxVp34G_6errors8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error5causeB4_(ptr align 8 %self) unnamed_addr #1 !guid !821 {
start:
; call <errors::AppError as core::error::Error>::source
  %0 = call { ptr, ptr } @_RNvXs_Cs4mnquxVp34G_6errorsNtB4_8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error6source(ptr align 8 %self)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <errors::AppError as core::error::Error>::provide
; Function Attrs: nonlazybind uwtable
define internal void @_RNvYNtCs4mnquxVp34G_6errors8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error7provideB4_(ptr align 8 %self, ptr align 8 %request.0, ptr align 8 %request.1) unnamed_addr #1 !guid !822 {
start:
  ret void
}

; <errors::AppError as core::error::Error>::type_id
; Function Attrs: nonlazybind uwtable
define internal void @_RNvYNtCs4mnquxVp34G_6errors8AppErrorNtNtCsl10jNU3mE6R_4core5error5Error7type_idB4_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !823 {
start:
; call <core::any::TypeId>::of::<errors::AppError>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtCs4mnquxVp34G_6errors8AppErrorEBM_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; <alloc::string::String as core::fmt::Write>::write_fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %args.0, ptr %args.1) unnamed_addr #1 !guid !824 {
start:
; call <&mut alloc::string::String as core::fmt::Write::write_fmt::SpecWriteFmt>::spec_write_fmt
  %_0 = call zeroext i1 @_RNvXs_NvNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtQNtNtCs7CppTae75M1_5alloc6string6StringNtB4_12SpecWriteFmt14spec_write_fmtCs4mnquxVp34G_6errors(ptr align 8 %self, ptr %args.0, ptr %args.1) #25
  ret i1 %_0
}

; <core::num::error::ParseIntError as core::error::Error>::description
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error11descriptionCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #1 !guid !825 {
start:
  ret { ptr, i64 } { ptr @alloc_04d7ce44d7c86a9a02b346ab945bf155, i64 40 }
}

; <core::num::error::ParseIntError as core::error::Error>::cause
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error5causeCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #1 !guid !826 {
start:
; call <core::num::error::ParseIntError as core::error::Error>::source
  %0 = call { ptr, ptr } @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error6sourceCs4mnquxVp34G_6errors(ptr %self)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::num::error::ParseIntError as core::error::Error>::source
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error6sourceCs4mnquxVp34G_6errors(ptr %self) unnamed_addr #1 !guid !827 {
start:
  ret { ptr, ptr } { ptr null, ptr undef }
}

; <core::num::error::ParseIntError as core::error::Error>::provide
; Function Attrs: nonlazybind uwtable
define internal void @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error7provideCs4mnquxVp34G_6errors(ptr %self, ptr align 8 %request.0, ptr align 8 %request.1) unnamed_addr #1 !guid !828 {
start:
  ret void
}

; <core::num::error::ParseIntError as core::error::Error>::type_id
; Function Attrs: nonlazybind uwtable
define internal void @_RNvYNtNtNtCsl10jNU3mE6R_4core3num5error13ParseIntErrorNtNtB8_5error5Error7type_idCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr %self) unnamed_addr #1 !guid !829 {
start:
; call <core::any::TypeId>::of::<core::num::error::ParseIntError>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtNtNtB8_3num5error13ParseIntErrorECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; <<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError as core::error::Error>::description
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_11descriptionCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !830 {
start:
  ret { ptr, i64 } { ptr @alloc_04d7ce44d7c86a9a02b346ab945bf155, i64 40 }
}

; <<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError as core::error::Error>::cause
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_5causeCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !831 {
start:
; call <<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError as core::error::Error>::source
  %0 = call { ptr, ptr } @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_6sourceCs4mnquxVp34G_6errors(ptr align 8 %self)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError as core::error::Error>::source
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_6sourceCs4mnquxVp34G_6errors(ptr align 8 %self) unnamed_addr #1 !guid !832 {
start:
  ret { ptr, ptr } { ptr null, ptr undef }
}

; <<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError as core::error::Error>::provide
; Function Attrs: nonlazybind uwtable
define internal void @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_7provideCs4mnquxVp34G_6errors(ptr align 8 %self, ptr align 8 %request.0, ptr align 8 %request.1) unnamed_addr #1 !guid !833 {
start:
  ret void
}

; <<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError as core::error::Error>::type_id
; Function Attrs: nonlazybind uwtable
define internal void @_RNvYNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4from11StringErrorBX_7type_idCs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !834 {
start:
; call <core::any::TypeId>::of::<<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtNvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBU_3BoxDNtNtB8_5error5ErrorNtNtB8_6marker4SyncNtB20_4SendEL_EINtNtB8_7convert4FromNtNtBW_6string6StringE4from11StringErrorECs4mnquxVp34G_6errors(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; <<char>::is_whitespace as core::ops::function::FnMut<(char,)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvYNvMNtNtCsl10jNU3mE6R_4core4char7methodsc13is_whitespaceINtNtNtB9_3ops8function5FnMutTcEE8call_mutCs4mnquxVp34G_6errors(ptr %_1, i32 %0) unnamed_addr #0 !guid !835 {
start:
  %_2 = alloca [4 x i8], align 4
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
; call <char>::is_whitespace
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc13is_whitespaceCs4mnquxVp34G_6errors(i32 %1) #25
  ret i1 %_0
}

; <usize as core::cmp::Ord>::max
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxCs4mnquxVp34G_6errors(i64 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !836 {
start:
  %_7 = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %other = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store i64 %0, ptr %self, align 8
  store i64 %1, ptr %other, align 8
  store i8 0, ptr %_7, align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_7, align 1
  store i8 1, ptr %_6, align 1
  %_3.i = load i64, ptr %other, align 8
  %_4.i = load i64, ptr %self, align 8
  %_0.i = icmp ult i64 %_3.i, %_4.i
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  %2 = load i64, ptr %other, align 8
  store i64 %2, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %3 = load i64, ptr %self, align 8
  store i64 %3, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %4 = load i8, ptr %_6, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb9, label %bb5

bb5:                                              ; preds = %bb9, %bb4
  %6 = load i8, ptr %_7, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb10, label %bb6

bb9:                                              ; preds = %bb4
  br label %bb5

bb6:                                              ; preds = %bb10, %bb5
  %8 = load i64, ptr %_0, align 8
  ret i64 %8

bb10:                                             ; preds = %bb5
  br label %bb6

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #8

; <f64 as core::str::traits::FromStr>::from_str
; Function Attrs: noinline nonlazybind uwtable
declare void @_RNvXs2_NtNtCsl10jNU3mE6R_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str(ptr sret([16 x i8]) align 8, ptr, i64) unnamed_addr #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #9

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <usize as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #10

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64, i64) unnamed_addr #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32) #12

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #13

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #8

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #12

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #13

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.sadd.with.overflow.i8(i8, i8) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.smul.with.overflow.i8(i8, i8) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.ssub.with.overflow.i8(i8, i8) #12

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #13

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #13

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #13

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64) #12

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i1(i1) #14

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.umul.with.overflow.i8(i8, i8) #12

; alloc::raw_vec::min_non_zero_cap
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCs7CppTae75M1_5alloc7raw_vec16min_non_zero_cap(i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #12

; core::fmt::write
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt5write(ptr, ptr align 8, ptr, ptr) unnamed_addr #1

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #13

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #2

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #15

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #16

; __rustc::__rust_realloc
; Function Attrs: nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc14___rust_realloc(ptr allocptr, i64, i64 allocalign, i64) unnamed_addr #17

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #18

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #11

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #13

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #19

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #8

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #20

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #20

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <alloc::boxed::Box<dyn core::error::Error> as core::convert::From<&str>>::from
; Function Attrs: nonlazybind uwtable
declare { ptr, ptr } @_RNvXsi_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_EINtNtBW_7convert4FromReE4from(ptr, i64) unnamed_addr #1

; <f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <core::num::error::ParseIntError as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs4_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
declare i32 @memcmp(ptr, ptr, i64) #21

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #13

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #13

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::FormattingOptions>::new
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvMs_NtCsl10jNU3mE6R_4core3fmtNtB4_17FormattingOptions3new() unnamed_addr #1

; <core::fmt::Formatter>::new
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs1_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3new(ptr sret([24 x i8]) align 8, ptr, ptr align 8, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <i8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsF_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_8UpperHex3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsD_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_8LowerHex3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs0_NvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBd_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB12_6marker4SyncNtB1z_4SendEL_EINtNtB12_7convert4FromNtNtBf_6string6StringE4fromNtB5_11StringErrorNtNtB12_3fmt5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <<alloc::boxed::Box<dyn core::error::Error + core::marker::Sync + core::marker::Send> as core::convert::From<alloc::string::String>>::from::StringError as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NvXsf_NtNtCs7CppTae75M1_5alloc5boxed7convertINtBc_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorNtNtB11_6marker4SyncNtB1y_4SendEL_EINtNtB11_7convert4FromNtNtBe_6string6StringE4fromNtB4_11StringErrorNtNtB11_3fmt7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; core::panicking::assert_failed::<core::option::Option<usize>, core::option::Option<usize>>
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core9panicking13assert_failedINtNtB4_6option6OptionjEBM_EB4_(i8, ptr align 8, ptr align 8, ptr, ptr, ptr align 8) unnamed_addr #19

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #22 !guid !837 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs4mnquxVp34G_6errors(ptr @_RNvCs4mnquxVp34G_6errors4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { inlinehint noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #10 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #11 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #15 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #20 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #21 = { nonlazybind }
attributes #22 = { nonlazybind "target-cpu"="x86-64" }
attributes #23 = { cold }
attributes #24 = { cold noreturn nounwind }
attributes #25 = { inlinehint }
attributes #26 = { noinline }
attributes #27 = { inlinehint nounwind }
attributes #28 = { noreturn }
attributes #29 = { noinline noreturn }
attributes #30 = { noinline noreturn nounwind }
attributes #31 = { inlinehint noreturn }
attributes #32 = { nounwind }

!llvm.module.flags = !{!216, !217, !218, !219}
!llvm.ident = !{!220}

!0 = !{i64 6685579204405589125}
!1 = !{i64 6459393454222520655}
!2 = !{i64 6598176830685218905}
!3 = !{i64 -4327449888882309378}
!4 = !{i64 -3061892129345156390}
!5 = !{i64 8658004953883048179}
!6 = !{i64 4458475011220935975}
!7 = !{i64 -6478138053958049356}
!8 = !{i64 -3741976565756046922}
!9 = !{i64 -1706565148125284304}
!10 = !{i64 -1333103689307467055}
!11 = !{i64 7973387478386253918}
!12 = !{i64 -2114365780591891906}
!13 = !{i64 9117454965136065440}
!14 = !{i64 -7876972857137114652}
!15 = !{i64 6333055089641820104}
!16 = !{i64 -5417243207990956443}
!17 = !{i64 9070445465059174474}
!18 = !{i64 -6307860143338485713}
!19 = !{i64 1047637887572932222}
!20 = !{i64 6535726996425098047}
!21 = !{i64 6446235014784971027}
!22 = !{i64 -3066148403970070334}
!23 = !{i64 -108343630543745507}
!24 = !{i64 -7875691855113727111}
!25 = !{i64 -8336042167123593756}
!26 = !{i64 -3083151592128718074}
!27 = !{i64 -2638623056921830623}
!28 = !{i64 4824253198658331570}
!29 = !{i64 -238271550040003685}
!30 = !{i64 -1964456636802115659}
!31 = !{i64 6554281820841491575}
!32 = !{i64 -867296109380321250}
!33 = !{i64 -3317991621967182314}
!34 = !{i64 -7275532768675274049}
!35 = !{i64 -7632095606715056759}
!36 = !{i64 -5905056985198149820}
!37 = !{i64 2920979565611433603}
!38 = !{i64 3808987074038511548}
!39 = !{i64 -2523430720709264089}
!40 = !{i64 -1639046901085827081}
!41 = !{i64 -9170569257073275260}
!42 = !{i64 -4689523671628250992}
!43 = !{i64 2551232656796138314}
!44 = !{i64 2569900495736488654}
!45 = !{i64 1052806154087913973}
!46 = !{i64 3980688843280600126}
!47 = !{i64 66279890531333167}
!48 = !{i64 -8086659083124598506}
!49 = !{i64 -1536280024768868905}
!50 = !{i64 4779194486207118195}
!51 = !{i64 -6752440301746022247}
!52 = !{i64 -884509442308199199}
!53 = !{i64 3765783471894054301}
!54 = !{i64 1577243584304290448}
!55 = !{i64 -4273454840047919326}
!56 = !{i64 8424686943545098976}
!57 = !{i64 5045955020390695559}
!58 = !{i64 7772422723012944370}
!59 = !{i64 3992576536863606058}
!60 = !{i64 8989889882732961840}
!61 = !{i64 7054880156574364544}
!62 = !{i64 3452064048149035854}
!63 = !{i64 1870894749153427749}
!64 = !{i64 -8020105031537479148}
!65 = !{i64 6159434941413545838}
!66 = !{i64 -7468552576428903310}
!67 = !{i64 3688259717680749562}
!68 = !{i64 -8974852164004662814}
!69 = !{i64 99539555920927829}
!70 = !{i64 -2743616863351263329}
!71 = !{i64 35633528226539539}
!72 = !{i64 6717417737166361114}
!73 = !{i64 1492949557268243047}
!74 = !{i64 -6013219904945299903}
!75 = !{i64 -3081853031132821414}
!76 = !{i64 8882525754225016193}
!77 = !{i64 -7947282341713911588}
!78 = !{i64 3891945565634873588}
!79 = !{i64 -6137158621083553629}
!80 = !{i64 -8491514152086397793}
!81 = !{i64 -2391827846748077035}
!82 = !{i64 3876637920327755997}
!83 = !{i64 -3419082132951344898}
!84 = !{i64 7564094510980115130}
!85 = !{i64 -8662088236373416028}
!86 = !{i64 -6525769042285479825}
!87 = !{i64 9081747314499267016}
!88 = !{i64 2512735439729475814}
!89 = !{i64 -3386916660125524739}
!90 = !{i64 -4846602060521542890}
!91 = !{i64 -4902943056632827309}
!92 = !{i64 -4740122026306645321}
!93 = !{i64 5079695293415993876}
!94 = !{i64 -5300346604533866754}
!95 = !{i64 -1113775506489009298}
!96 = !{i64 -5897060283415923726}
!97 = !{i64 -1984902684654099898}
!98 = !{i64 3349545419256214222}
!99 = !{i64 -3759471101718554159}
!100 = !{i64 6608876543150120441}
!101 = !{i64 929036507187658539}
!102 = !{i64 6315093547137370255}
!103 = !{i64 -6079382969601336438}
!104 = !{i64 3918776534059483563}
!105 = !{i64 792122780013585530}
!106 = !{i64 9086486543405363627}
!107 = !{i64 -9171364630226837418}
!108 = !{i64 1686363069597569197}
!109 = !{i64 3606632486129151669}
!110 = !{i64 -9028575589512743785}
!111 = !{i64 740540724823436881}
!112 = !{i64 -5405368766725684181}
!113 = !{i64 -4387440409177771207}
!114 = !{i64 -4466710552406026369}
!115 = !{i64 7293186611896143825}
!116 = !{i64 -1821758455322735593}
!117 = !{i64 -3744514277461587099}
!118 = !{i64 -7610543968764734038}
!119 = !{i64 6470203001341681627}
!120 = !{i64 -8620842761754962888}
!121 = !{i64 -8444974006885775341}
!122 = !{i64 -192768991023308552}
!123 = !{i64 3980380075417614038}
!124 = !{i64 1695035701117045253}
!125 = !{i64 1334133885824075835}
!126 = !{i64 -4314487873803165228}
!127 = !{i64 6250131945298239392}
!128 = !{i64 -1826070587806070889}
!129 = !{i64 -6510142570150245733}
!130 = !{i64 760126664869026852}
!131 = !{i64 -5142717108406326595}
!132 = !{i64 -2971209829793145541}
!133 = !{i64 163680100814025382}
!134 = !{i64 3476697299533637884}
!135 = !{i64 4061497870916224124}
!136 = !{i64 -3343207705175658861}
!137 = !{i64 -5647933871475987365}
!138 = !{i64 -2180297573481731353}
!139 = !{i64 -7324549963570476915}
!140 = !{i64 -4648925240354489328}
!141 = !{i64 -6136726837883984832}
!142 = !{i64 1906848444429590361}
!143 = !{i64 -985489776506005135}
!144 = !{i64 5244496921981713234}
!145 = !{i64 8139019591039486518}
!146 = !{i64 -4535636742961442432}
!147 = !{i64 1922052369877743250}
!148 = !{i64 -4032739983601050736}
!149 = !{i64 -2117654471189537904}
!150 = !{i64 -3626062129151921898}
!151 = !{i64 7439045303409357312}
!152 = !{i64 3587396339020513870}
!153 = !{i64 -6503756118632577236}
!154 = !{i64 -6502718972426838417}
!155 = !{i64 2391208941279229671}
!156 = !{i64 4563619034051387341}
!157 = !{i64 4945527000179614263}
!158 = !{i64 -7784463684611244061}
!159 = !{i64 7505427684059241371}
!160 = !{i64 5361506271235676484}
!161 = !{i64 -6644317730448954735}
!162 = !{i64 6497509159781813005}
!163 = !{i64 -515596668711388692}
!164 = !{i64 -4959912237813244232}
!165 = !{i64 -8670612896269564789}
!166 = !{i64 8847881255912400469}
!167 = !{i64 -4557559577526707797}
!168 = !{i64 -1825448519851008307}
!169 = !{i64 2363329026005713759}
!170 = !{i64 -2773283996818815626}
!171 = !{i64 -7050588734961911977}
!172 = !{i64 -4633311782329183518}
!173 = !{i64 994862904540513945}
!174 = !{i64 8918981879533929798}
!175 = !{i64 -6297725999479529006}
!176 = !{i64 7393882520553128933}
!177 = !{i64 3308693014622873628}
!178 = !{i64 2709177147978445063}
!179 = !{i64 6038413703296557833}
!180 = !{i64 -4113478939663802017}
!181 = !{i64 4817936920138260994}
!182 = !{i64 -431932686161899426}
!183 = !{i64 -97282760618302141}
!184 = !{i64 -7496956430520419766}
!185 = !{i64 1687977455092644858}
!186 = !{i64 168620001450004535}
!187 = !{i64 4743519840749520493}
!188 = !{i64 7592643776677860716}
!189 = !{i64 4170077486652360543}
!190 = !{i64 -4168689288502138664}
!191 = !{i64 -7124098464887071747}
!192 = !{i64 -3996154536914341214}
!193 = !{i64 -2734625056437823928}
!194 = !{i64 6914069061355869922}
!195 = !{i64 -8223613243467395501}
!196 = !{i64 -914946254638111170}
!197 = !{i64 2275767791151160469}
!198 = !{i64 1090949381607425410}
!199 = !{i64 7193117376813323529}
!200 = !{i64 -3599696126369094102}
!201 = !{i64 4426277211150196610}
!202 = !{i64 5284647979414827526}
!203 = !{i64 -8054485237010563803}
!204 = !{i64 1093261824107683944}
!205 = !{i64 -6326211204889449218}
!206 = !{i64 1483888435046523352}
!207 = !{i64 -8371210747686297678}
!208 = !{i64 -8970876290731078056}
!209 = !{i64 -6814509571857809060}
!210 = !{i64 9080636016737750998}
!211 = !{i64 7646467202822638916}
!212 = !{i64 -7055724756150260029}
!213 = !{i64 -7884871545016810989}
!214 = !{i64 -4095004962064395581}
!215 = !{i64 6224175046345925901}
!216 = !{i32 8, !"PIC Level", i32 2}
!217 = !{i32 7, !"PIE Level", i32 2}
!218 = !{i32 2, !"RtLibUseGOT", i32 1}
!219 = !{i32 7, !"uwtable", i32 2}
!220 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!221 = !{i64 1459888982406322245}
!222 = !{i64 -5413786962767084457}
!223 = !{i64 8167016446138630381}
!224 = !{i64 3673931225463259198}
!225 = !{i64 -5597773831905379789}
!226 = !{i64 1206539890828463491}
!227 = !{i64 -8807088202866979634}
!228 = !{i64 2745958808086216980}
!229 = !{i64 -6576914432077761537}
!230 = !{i64 5103386322393480322}
!231 = !{i64 -7881058134936110676}
!232 = !{i64 1575391538409306415}
!233 = !{i64 6320047537689774893}
!234 = !{i64 -1185484251415576372}
!235 = !{i64 9110394214663978}
!236 = !{i64 -4253869931052551472}
!237 = !{i64 -5212591763288235562}
!238 = !{i64 -7149093325940008780}
!239 = !{i64 4092760507430999459}
!240 = !{i64 -4821039285944781328}
!241 = !{i64 1504759357685101482}
!242 = !{i64 -5149177345262444308}
!243 = !{i64 204753785284136968}
!244 = !{i64 1200603740875292603}
!245 = !{i64 -3129469604341354386}
!246 = !{i64 2603682634257664389}
!247 = !{i64 -5706689483946939690}
!248 = !{i64 -4485186886366352445}
!249 = !{i64 5709093928664333411}
!250 = !{i64 4059787702314339201}
!251 = !{i64 -8533504316448444552}
!252 = !{i64 -5483246376117612600}
!253 = !{i64 -6574534659944740229}
!254 = !{i64 -8007886513626410119}
!255 = !{i64 -7621685115275636542}
!256 = !{i64 -5352742859400726507}
!257 = !{i64 -7472523192767183240}
!258 = !{i64 1529830041978052551}
!259 = !{i64 587019911609609481}
!260 = !{i64 -6928493007645740445}
!261 = !{i64 -1561587882741168380}
!262 = !{i64 1214525813119575541}
!263 = !{i64 7546984862768587391}
!264 = !{i64 -8851889800943491787}
!265 = !{i64 4472117741754873088}
!266 = !{i64 -3991905255738340724}
!267 = !{i64 -6754403288082287053}
!268 = !{i64 7316620691834061375}
!269 = !{i64 -241193539833295482}
!270 = !{i64 -4113663041138166673}
!271 = !{i64 -972100269628400918}
!272 = !{i64 -3873723904922454180}
!273 = !{i64 8873332387079664852}
!274 = !{i64 -361923774448665600}
!275 = !{i64 -3157705383923813968}
!276 = !{i64 -1442316735137304077}
!277 = !{i64 2942656991128847152}
!278 = !{i64 -5103396506383276478}
!279 = !{i64 7198463928484754550}
!280 = !{i64 4122993859387215591}
!281 = !{i64 4451670671440236322}
!282 = !{i64 -5751301892410169967}
!283 = !{i64 1762168894957064083}
!284 = !{i64 -8298709733689050586}
!285 = !{i64 -6757737700831475080}
!286 = !{i64 2911875160707411583}
!287 = !{i64 4293380363331643280}
!288 = !{i64 3320445234305707148}
!289 = !{i64 5061982371640567996}
!290 = !{i64 6421470537581174973}
!291 = !{i64 -159381409256017462}
!292 = !{i64 -6126423607272978014}
!293 = !{i64 5466956423040181693}
!294 = !{i64 7752080004524767679}
!295 = !{i64 -8862873552898411936}
!296 = !{i64 5990366536226940815}
!297 = !{i64 -1078658222447087380}
!298 = !{i64 5388212052224754265}
!299 = !{i64 -750422998627128653}
!300 = !{i64 -1616874565559733339}
!301 = !{i64 -1662903552046516807}
!302 = !{i64 -5072788199672737476}
!303 = !{i64 -146332859069985707}
!304 = !{i64 -5608960835002225431}
!305 = !{i64 -142245349097698071}
!306 = !{i64 -8821760539035890363}
!307 = !{i64 7133115661109494097}
!308 = !{i64 5610929300253537629}
!309 = !{i64 320746126878112239}
!310 = !{i64 1282549237467928317}
!311 = !{i64 -7582415297337151876}
!312 = !{i64 -6200622477488557881}
!313 = !{i64 -2192996428817290951}
!314 = !{i64 -8547784477852781108}
!315 = !{i64 7007527924589764967}
!316 = !{i64 3092730601549112192}
!317 = !{i64 3435955012387432604}
!318 = !{i64 2359902185604106815}
!319 = !{i64 8035232445926931229}
!320 = !{i64 -9087089811871852739}
!321 = !{i64 -627535223598972943}
!322 = !{i64 8969355990277524074}
!323 = !{i64 -246734034290890629}
!324 = !{i64 -5960926921091754300}
!325 = !{i64 -4703820354930196197}
!326 = !{i64 -7200617824451679130}
!327 = !{i64 7071966299364314068}
!328 = !{i64 -4974384259822195370}
!329 = !{i64 -1274178061955183492}
!330 = !{i64 -2518963576652528123}
!331 = !{i64 -3114906562249097731}
!332 = !{}
!333 = !{i64 -9088112564323795598}
!334 = !{i64 -6155803309404018854}
!335 = !{i64 2779166389767792904}
!336 = !{i64 2234030856570211608}
!337 = !{i64 4490361619813474991}
!338 = !{i64 -6695026422080419261}
!339 = !{i64 3631283005754485082}
!340 = !{i64 -7115737165027080198}
!341 = !{i64 -4140101883605591835}
!342 = !{i64 -6013758679175404164}
!343 = !{i64 -3177915039598199817}
!344 = !{i64 4738762965284730973}
!345 = !{i64 -1780848991933773}
!346 = !{i64 5345050062362019766}
!347 = !{i64 3034037387432776649}
!348 = !{i64 9073396856318493489}
!349 = !{i64 6716426184930711245}
!350 = !{i64 -7724920364375806999}
!351 = !{i64 5775599038811292538}
!352 = !{i64 5706947523519137057}
!353 = !{i64 2000149010585227778}
!354 = !{i64 6279301802883805821}
!355 = !{i64 -5977466617218856044}
!356 = !{i64 566849548280210116}
!357 = !{i64 1202303303329037616}
!358 = !{i64 -7621338235185604151}
!359 = !{i64 662658227221303036}
!360 = !{i64 7153586647957171128}
!361 = !{i64 -6750292052903973232}
!362 = !{i64 9072099170822011753}
!363 = !{i64 3752008180349036750}
!364 = !{i64 -3221217965574429426}
!365 = !{i64 5477720292113477504}
!366 = !{i64 1397006832825967}
!367 = !{i64 -8770832277126659131}
!368 = !{i64 -7536564154025643446}
!369 = !{i64 6712908063020608911}
!370 = !{i64 -6362522461969229150}
!371 = !{i64 2118468949816876124}
!372 = !{i64 -5136735079273936869}
!373 = !{i64 -1256088074228391200}
!374 = !{i64 3072234879994913998}
!375 = !{i64 7944106112413192138}
!376 = !{i64 5807969362718062140}
!377 = !{i64 6696697891526507625}
!378 = !{i64 8410865359602568798}
!379 = !{i64 -5012818704145090827}
!380 = !{i64 8519675263729846831}
!381 = !{i64 4944577855099649472}
!382 = !{i64 -6009291610532091520}
!383 = !{i64 -8284392673971131197}
!384 = !{i64 3829271543402048699}
!385 = !{i64 1183662382098317557}
!386 = !{i64 -4406753552298270548}
!387 = !{i64 -1563951638229906220}
!388 = !{i64 -6709992163311748879}
!389 = !{i64 5004514006440413338}
!390 = !{i64 -3280341511534762339}
!391 = !{i64 -2092608914646789817}
!392 = !{i64 -7275269890431058484}
!393 = !{i64 -1744486677014341928}
!394 = !{i64 6184287189831060076}
!395 = !{i64 4424093517692039433}
!396 = !{i64 6281585217612993838}
!397 = !{i64 7395719585514592795}
!398 = !{i64 -4384374000160414460}
!399 = !{i64 -6890783939929247779}
!400 = !{i64 3792960706908213389}
!401 = !{i64 -5518013685732946450}
!402 = !{i64 -3891929637683476154}
!403 = !{i64 7667771149920469028}
!404 = !{i64 4589941185367362708}
!405 = !{i64 3223695930593982823}
!406 = !{i64 -2775886347672046573}
!407 = !{i64 9200390310054396647}
!408 = !{i64 7181460445789346443}
!409 = !{i64 -6902396493265040871}
!410 = !{i64 -3845754687880289642}
!411 = !{i64 8681676668273793508}
!412 = !{i64 -3805550057546671322}
!413 = !{i64 -4190433709186961714}
!414 = !{i64 2712106611310394046}
!415 = !{i64 2191859063573363401}
!416 = !{i64 3666192884681082280}
!417 = !{i64 7345564174969519579}
!418 = !{i64 5413259263625731967}
!419 = !{i64 8695342864715241461}
!420 = !{i64 1839807268958798706}
!421 = !{i64 -3488662710030813370}
!422 = !{i64 -3042455474408569576}
!423 = !{i64 7727604329408386847}
!424 = !{i64 -1529621779364744246}
!425 = !{i64 -4662164511523736317}
!426 = !{i64 2648204771373088007}
!427 = !{i64 4109172996606673621}
!428 = !{i64 -366929569281014875}
!429 = !{i64 1681885404506242112}
!430 = !{i64 9166805592324834210}
!431 = !{i64 2784740668711568369}
!432 = !{i64 -3257093057635789672}
!433 = !{i64 -4470654109827570883}
!434 = !{i64 -3290424735326443911}
!435 = !{i64 -7968549458336864550}
!436 = !{i64 4715643181621938943}
!437 = !{i64 -7113738102509971170}
!438 = !{i64 5620887191917675831}
!439 = !{i64 3856846396837831094}
!440 = !{i64 -2079387666281645963}
!441 = !{i64 2343495763529693726}
!442 = !{i64 -7934041028470931486}
!443 = !{i64 -7683287055570951632}
!444 = !{i64 5960054003274016107}
!445 = !{i64 -5114261079317012371}
!446 = !{i64 2399141292282664723}
!447 = !{i64 4506699519213978790}
!448 = !{i64 1958430369586688462}
!449 = !{i64 7193717116741194522}
!450 = !{i64 -1666442805011460501}
!451 = !{i64 4243943776434356280}
!452 = !{i64 1708215308036987928}
!453 = !{i64 -7267706860613243897}
!454 = !{i64 -2708150563963046169}
!455 = !{i64 1173968127649070987}
!456 = !{i64 4194206982709368378}
!457 = !{i64 3054471121861114485}
!458 = !{i64 -8403767350277651566}
!459 = !{i64 -3823351263734471882}
!460 = !{i64 -8166821651718224033}
!461 = !{i64 5490459971616970410}
!462 = !{i64 -1181392774773899882}
!463 = !{i64 1160764079357722705}
!464 = !{i64 4661577875373802668}
!465 = !{i64 7895907872875174263}
!466 = !{i64 -4038451424819540535}
!467 = !{i64 -543121553003342572}
!468 = !{i64 -5882037960855692291}
!469 = !{i64 -1994344045802630924}
!470 = !{i64 -5701440958824372785}
!471 = !{i64 -5260873466231497000}
!472 = !{i64 6422323157506244756}
!473 = !{i64 3535659178657150592}
!474 = !{i64 7325581365697923303}
!475 = !{i64 985794476366128328}
!476 = !{i64 5644181637225631580}
!477 = !{i64 4293475895465235087}
!478 = !{i64 1821798226542266212}
!479 = !{i64 -8073483707485137407}
!480 = !{i64 6606690544148850918}
!481 = !{i64 5817745681820277341}
!482 = !{i64 5228103601723424327}
!483 = !{i64 -7579142035956146702}
!484 = !{i64 5564531510467663724}
!485 = !{i64 507601993627962533}
!486 = !{i64 -2087034956235440600}
!487 = !{i64 -8881191381408082824}
!488 = !{i64 -3533097099103437992}
!489 = !{i64 6370524179860479862}
!490 = !{i64 -1050771638543577562}
!491 = !{i64 4027754477857955190}
!492 = !{i64 -7410741297907808089}
!493 = !{i64 6996994239861598799}
!494 = !{i64 4530237319814601651}
!495 = !{i64 -842019601885251088}
!496 = !{i64 -8952667718367479157}
!497 = !{i64 -2444102249650431443}
!498 = !{i64 -2028924219532348134}
!499 = !{i64 7502960986079844119}
!500 = !{i64 -7472853092929148301}
!501 = !{i64 -4173139453091190892}
!502 = !{i64 -5544110732374682518}
!503 = !{i64 7811254771909830976}
!504 = !{i64 545946855601265084}
!505 = !{i64 5690905016340187603}
!506 = !{i64 -7956211647032269884}
!507 = !{i64 -7492874719201522156}
!508 = !{i64 5491301090239810429}
!509 = !{i64 -4204791843575982993}
!510 = !{i64 3978956554964627582}
!511 = !{i64 1992303576861819264}
!512 = !{i64 4070173113434827243}
!513 = !{i64 -7412711012679254968}
!514 = !{i64 7739237905948787599}
!515 = !{i64 2996649005600218152}
!516 = !{i64 -4249214187902248603}
!517 = !{i64 -3274189608666815519}
!518 = !{i64 -5992269473116843707}
!519 = !{i64 -9150063733188147015}
!520 = !{i64 2225991552251915822}
!521 = !{i64 3390185741494796329}
!522 = !{i64 970387176058806422}
!523 = !{i64 -73455210400057288}
!524 = !{i64 -8633256497021985921}
!525 = !{i64 -3325025051168743787}
!526 = !{i64 -8262710281880010591}
!527 = !{i64 -192820870514446471}
!528 = !{i64 2843688612555119495}
!529 = !{i64 450818873092768728}
!530 = !{i64 -3064393101112321883}
!531 = !{i64 2632038329738059657}
!532 = !{i64 -3092206707132438454}
!533 = !{i64 1740773536674387919}
!534 = !{i64 7376336474734421127}
!535 = !{i64 -2974188139178774706}
!536 = !{i64 549753508001511825}
!537 = !{i64 -6940092740309127013}
!538 = !{i64 5957199092033818318}
!539 = !{i64 1359688966547608677}
!540 = !{i64 2383016782013034003}
!541 = !{i64 6762078011567430980}
!542 = !{i64 8330461800995925342}
!543 = !{i64 -3673025858069096884}
!544 = !{i64 3612384585047716618}
!545 = !{i64 8563991646431774092}
!546 = !{i64 -5328487687671024729}
!547 = !{i64 6254002882488337031}
!548 = !{i64 2388422774687719381}
!549 = !{i64 3571952528635981998}
!550 = !{i64 4147858454903562733}
!551 = !{i64 2535925868194893326}
!552 = !{i64 1864152550256845771}
!553 = !{i64 -192658579930011189}
!554 = !{i64 7760511603658621827}
!555 = !{i64 9050013379789797737}
!556 = !{i64 7215165570917084641}
!557 = !{i64 -4757649559870732285}
!558 = !{i64 -3067206760105977352}
!559 = !{i64 -1730867919076875604}
!560 = !{i64 7151468766860314183}
!561 = !{i64 -4833698111352981317}
!562 = !{i64 -7473445913621305580}
!563 = !{i64 137511369682913153}
!564 = !{i64 -2662468233691685054}
!565 = !{i64 869965940661069968}
!566 = !{i64 7437426520044075154}
!567 = !{i64 -8110687684978116492}
!568 = !{i64 2493976967574016877}
!569 = !{i64 4064387578008879931}
!570 = !{i64 -1021703635299449802}
!571 = !{i64 -3358335437622715764}
!572 = !{i64 -4189445519979819757}
!573 = !{i64 -5454615620595162629}
!574 = !{i64 -3842668990259206545}
!575 = !{i64 -5306038682566610557}
!576 = !{i64 -7496032520489140220}
!577 = !{i64 8573175559875694391}
!578 = !{i64 4696299247245416034}
!579 = !{i64 -4756101574817611291}
!580 = !{i64 2052725080708496443}
!581 = !{i64 3611674081672054414}
!582 = !{i64 -1718286040538289415}
!583 = !{i64 -467707719616942102}
!584 = !{i64 -8970420531375730243}
!585 = !{i64 -3303384056499058396}
!586 = !{i64 -4770513577138048585}
!587 = !{i64 -7291998242918530753}
!588 = !{i64 -6152855146569334373}
!589 = !{i64 -6355788836131099166}
!590 = !{i64 -1299465145024735277}
!591 = !{i64 -7336151468309956788}
!592 = !{i64 -3799757621169382973}
!593 = !{i64 -5991196560742307961}
!594 = !{i64 6982453873435438445}
!595 = !{i64 -6712065364921924306}
!596 = !{i64 -7028685616004680839}
!597 = !{i64 -6546263874465606629}
!598 = !{i64 3800957650351058467}
!599 = !{i64 -2532070006114060425}
!600 = !{i64 -7870475197616270976}
!601 = !{i64 8323368377412253926}
!602 = !{i64 -7473395960451057556}
!603 = !{i64 1971175110112390436}
!604 = !{i64 -1145768090483163672}
!605 = !{i64 8499904514922855026}
!606 = !{i64 -5059301799095877193}
!607 = !{i64 -838315898924665983}
!608 = !{i64 9161377619384815993}
!609 = !{i64 -3514799488100885967}
!610 = !{i64 4905772831271234385}
!611 = !{i64 -2665358517301549618}
!612 = !{!"address", !"read_provenance"}
!613 = !{i64 2382474451287872747}
!614 = !{i64 7150637583185655128}
!615 = !{i64 -4169759975335101544}
!616 = !{i64 -6735618619621694688}
!617 = !{i64 8712472989727695657}
!618 = !{i64 1469511510451783739}
!619 = !{i64 8988793960684063552}
!620 = !{i64 6656080428904090018}
!621 = !{i64 -1097979443096584987}
!622 = !{i64 4862798928565624468}
!623 = !{i64 -3713270844827108275}
!624 = !{i64 3032937143146993956}
!625 = !{i64 -6424234816360775792}
!626 = !{i64 -4306267214665314877}
!627 = !{i64 1043557843870804372}
!628 = !{i64 -8753658977095330146}
!629 = !{i64 2298471269179945024}
!630 = !{i64 1015901644516598797}
!631 = !{i64 5362431090101568286}
!632 = !{i64 7480046222705422908}
!633 = !{i64 529326055585314815}
!634 = !{i64 -6859575227972990626}
!635 = !{i64 -2551159779351767652}
!636 = !{i64 -250569873142739288}
!637 = !{i64 -847758016676802515}
!638 = !{i64 7555619293691552719}
!639 = !{i64 8159990173129743769}
!640 = !{i64 5525395200397036132}
!641 = !{i64 2987683835768779691}
!642 = !{i64 3460780197984713202}
!643 = !{i64 -4349891302914322646}
!644 = !{i64 3815428322393988431}
!645 = !{i64 6895650897526517062}
!646 = !{i64 1158446112123810331}
!647 = !{i64 8338813823162790873}
!648 = !{i64 -1467538936957592155}
!649 = !{i64 -7071879336188233135}
!650 = !{i64 8260027399818178065}
!651 = !{i64 -4207133031981745797}
!652 = !{i64 2131391309826459815}
!653 = !{i64 -1942556742725193614}
!654 = !{i64 4233244246781758727}
!655 = !{i64 1192891343394088110}
!656 = !{i64 -2659340080132054645}
!657 = !{i64 -7037059023508529874}
!658 = !{i64 -8754287253505802746}
!659 = !{i64 -7244699609601033652}
!660 = !{i64 -1777446958805526125}
!661 = !{i64 5778229526215143219}
!662 = !{i64 2435199188390481761}
!663 = !{i64 5450138652161237555}
!664 = !{i64 1261901639969948666}
!665 = !{i64 2585286698601739428}
!666 = !{i64 4525252228257952587}
!667 = !{i64 -4727355212232974107}
!668 = !{i64 6878855063634678570}
!669 = !{i64 8409377668653316052}
!670 = !{i64 8600163064384262585}
!671 = !{i64 6788934906309983563}
!672 = !{i64 -7095245475877684028}
!673 = !{i64 -7595690560925038367}
!674 = !{i64 756384289622289894}
!675 = !{i64 -7701217348896211208}
!676 = !{i64 3518260176735830621}
!677 = !{i64 -7410906129467740125}
!678 = !{i64 284824950107336224}
!679 = !{i64 7635461276762801110}
!680 = !{i64 -3164625374760547231}
!681 = !{i64 5405504886415475831}
!682 = !{i64 -7129164386013303005}
!683 = !{i64 -6812393458589552592}
!684 = !{i64 -4088750612994437099}
!685 = !{i64 -970947573642171302}
!686 = !{i64 -2384676920186919354}
!687 = !{i64 869213190608155645}
!688 = !{i64 -2960088534821585254}
!689 = !{i64 7796796021267488579}
!690 = !{i64 -4514168834975063574}
!691 = !{i64 4478942541917124869}
!692 = !{i64 -1964960432589770034}
!693 = !{i64 -4068859795867418301}
!694 = !{i64 8513611727609373816}
!695 = !{i64 984088985609619881}
!696 = !{i64 5660888834992719312}
!697 = !{i64 4859055355518127999}
!698 = !{i64 -4559373361416763792}
!699 = !{i64 8767281834205503641}
!700 = !{i64 7056704158540937677}
!701 = !{i64 -3876305690886584172}
!702 = !{i64 -3979945672295193753}
!703 = !{i64 -8153754158313830995}
!704 = !{i64 -1217705224049557231}
!705 = !{i64 7910853943429204912}
!706 = !{i64 2977951043883494705}
!707 = !{i64 4016289826893551150}
!708 = !{i64 8493560299017045244}
!709 = !{i64 -1287084553823244669}
!710 = !{i64 -7488163647137086120}
!711 = !{i64 3627094965208802618}
!712 = !{i64 -3075499067987217921}
!713 = !{i64 -1075217245876553360}
!714 = !{i64 -7058852207930281330}
!715 = !{i64 5517778553186527823}
!716 = !{i64 -370482527952382529}
!717 = !{i64 -1729297767665833078}
!718 = !{i64 4889449123601946410}
!719 = !{i64 -5402840252268188798}
!720 = !{i64 -7878758151743855014}
!721 = !{i64 5482327994794376741}
!722 = !{i64 1931544389587989617}
!723 = !{i64 8237040358499031410}
!724 = !{i64 -6344192970109585652}
!725 = !{i64 -399089191934494178}
!726 = !{i64 -2085701020112913384}
!727 = !{i64 5877028171247465966}
!728 = !{i64 -4516722521531846636}
!729 = !{i64 6469107086119101412}
!730 = !{i64 655001661863581990}
!731 = !{i64 1647087122894145124}
!732 = !{i64 6990425324452557153}
!733 = !{i64 6138934067362735358}
!734 = !{i64 7243089695917623339}
!735 = !{i64 6031039796802515342}
!736 = !{i64 7737412364531995976}
!737 = !{i64 -4458570373820736601}
!738 = !{i64 7277112931286665759}
!739 = !{i64 3366222285507564454}
!740 = !{i64 5875398870040348199}
!741 = !{i64 7200559061980967166}
!742 = !{i64 4056255336862637828}
!743 = !{i64 -3712942419661079995}
!744 = !{i64 6440227040958131102}
!745 = !{i64 2126007094830521700}
!746 = !{i64 6490385370509670103}
!747 = !{i64 -3223089946413499050}
!748 = !{i64 -5968037022568275271}
!749 = !{i64 -6096957479675402062}
!750 = !{i64 2572408485892833069}
!751 = !{i64 7649166870823963122}
!752 = !{i64 306586515444056951}
!753 = !{i64 -3832070642981381860}
!754 = !{i64 -6398085800827508499}
!755 = !{i64 -3289924118703427549}
!756 = !{i64 -5415059218631109882}
!757 = !{i64 9036651288445640070}
!758 = !{i64 -8947254479434552974}
!759 = !{i64 621136697232926083}
!760 = !{i64 4489699505084561305}
!761 = !{i64 1949323741636573414}
!762 = !{i64 -5222051249124527889}
!763 = !{i64 -4314819467106372839}
!764 = !{i64 2900789412219653485}
!765 = !{i64 4702706863728763961}
!766 = !{i64 -566147385698152786}
!767 = !{i64 -8796906219972846370}
!768 = !{i64 -7340739138075740842}
!769 = !{i64 -5766662561455776745}
!770 = !{i64 -5623527750918531385}
!771 = !{i64 -8725448480364519409}
!772 = !{i64 -6039415316830340551}
!773 = !{i64 -9209383652485070590}
!774 = !{i64 -6225430830573692437}
!775 = !{i64 3864904580509443147}
!776 = !{i64 -7676243554895317677}
!777 = !{i64 5985722876172640843}
!778 = !{i64 1142555792605614122}
!779 = !{i64 378351729267767188}
!780 = !{i64 1657818043133034166}
!781 = !{i64 4259256632427579766}
!782 = !{i64 -5161842510845702673}
!783 = !{i64 -8586685904562392090}
!784 = !{i64 5131970988689285240}
!785 = !{i64 -8524481729135816236}
!786 = !{i64 7022053893489987828}
!787 = !{i64 5856386991077624619}
!788 = !{i64 -2283966722376465798}
!789 = !{i64 7460799183444613289}
!790 = !{i64 -5577560797834684051}
!791 = !{i64 4070057172975218439}
!792 = !{i64 4009358273780908772}
!793 = !{i64 -7799728575953409823}
!794 = !{i64 6595846416549431155}
!795 = !{i64 -1007716017673814563}
!796 = !{i64 -2363548744869846229}
!797 = !{i64 -104786475377671330}
!798 = !{i64 4931360207136130464}
!799 = !{i64 -2262740152031429560}
!800 = !{i64 6660862270822784560}
!801 = !{i64 -4881152991375891415}
!802 = !{i64 -5400986124115053709}
!803 = !{i64 2311177513279250356}
!804 = !{i64 1249521554542180108}
!805 = !{i64 4774730707760471489}
!806 = !{i64 4334656835839747163}
!807 = !{i64 -809432286687050790}
!808 = !{i64 -8705326129874102471}
!809 = !{i64 48937104006155625}
!810 = !{i64 -5402077058021514427}
!811 = !{i64 2431083705673754226}
!812 = !{i64 -2187745651487196202}
!813 = !{i64 -3642251330718753593}
!814 = !{i64 -807266340263326786}
!815 = !{i64 4572095563501120173}
!816 = !{i64 -8029895721245900765}
!817 = !{i64 3876365264826102352}
!818 = !{i64 -3991020099626699492}
!819 = !{i64 -7087741269806342299}
!820 = !{i64 4774020127950497261}
!821 = !{i64 -6091554636720586017}
!822 = !{i64 7506301231485853753}
!823 = !{i64 5307997766400740232}
!824 = !{i64 4652111667894542305}
!825 = !{i64 8237349385399014731}
!826 = !{i64 -8635483010140952015}
!827 = !{i64 -3441291132807082840}
!828 = !{i64 8280136656137220642}
!829 = !{i64 -2137970097639469491}
!830 = !{i64 1214802841395150475}
!831 = !{i64 -2017922513069399904}
!832 = !{i64 -8545914191012915016}
!833 = !{i64 -4803736553744992756}
!834 = !{i64 -8540103896951823936}
!835 = !{i64 6551184263529675812}
!836 = !{i64 -7811884445888478367}
!837 = !{i64 -2624081020897602054}
