; ModuleID = 'panic_refcell.cdbd51a832fbde8b-cgu.0'
source_filename = "panic_refcell.cdbd51a832fbde8b-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshF95OWYD5pv_13panic_refcell, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshF95OWYD5pv_13panic_refcell, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshF95OWYD5pv_13panic_refcell }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_8b366bf1a73b31468ac99bd60b1c4f95 = private unnamed_addr constant [37 x i8] c"test/rust/synthetic/panic-refcell.rs\00", align 1, !guid !2
@alloc_f0c4731339e495e37cfd1808d9338843 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8b366bf1a73b31468ac99bd60b1c4f95, [16 x i8] c"$\00\00\00\00\00\00\00\06\00\00\004\00\00\00" }>, align 8, !guid !3
@alloc_9ecd77ad4959c689ce3d66c39fef1f13 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8b366bf1a73b31468ac99bd60b1c4f95, [16 x i8] c"$\00\00\00\00\00\00\00\06\00\00\00M\00\00\00" }>, align 8, !guid !4
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !5
@alloc_d9efa9b520a36466fb4b57328b184287 = private unnamed_addr constant [17 x i8] c"core/src/cell.rs\00", align 1, !guid !6
@alloc_98f5b470f40a597b568a6efe978d8c0e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d9efa9b520a36466fb4b57328b184287, [16 x i8] c"\10\00\00\00\00\00\00\00\F3\04\00\00&\00\00\00" }>, align 8, !guid !7
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !8

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshF95OWYD5pv_13panic_refcell(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !14 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::mem::replace::<isize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem7replaceiECshF95OWYD5pv_13panic_refcell(ptr align 8 %dest, i64 %src) unnamed_addr #1 !guid !15 {
start:
  %result = load i64, ptr %dest, align 8
  store i64 %src, ptr %dest, align 8
  ret i64 %result
}

; core::ptr::drop_glue::<core::cell::RefMut<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutlEECshF95OWYD5pv_13panic_refcell(ptr align 8 %_1) unnamed_addr #0 !guid !16 {
start:
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<core::cell::BorrowRefMut>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtB4_4cell12BorrowRefMutECshF95OWYD5pv_13panic_refcell(ptr align 8 %0)
  ret void
}

; core::ptr::drop_glue::<core::cell::BorrowRefMut>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtB4_4cell12BorrowRefMutECshF95OWYD5pv_13panic_refcell(ptr align 8 %_1) unnamed_addr #0 !guid !17 {
start:
; call <core::cell::BorrowRefMut as core::ops::drop::Drop>::drop
  call void @_RNvXsO_NtCsl10jNU3mE6R_4core4cellNtB5_12BorrowRefMutNtNtNtB7_3ops4drop4Drop4dropCshF95OWYD5pv_13panic_refcell(ptr align 8 %_1) #9
  ret void
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECshF95OWYD5pv_13panic_refcell() unnamed_addr #1 !guid !18 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !19
  ret void
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshF95OWYD5pv_13panic_refcell(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !20 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshF95OWYD5pv_13panic_refcell(ptr %f) #9
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECshF95OWYD5pv_13panic_refcell() #9
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshF95OWYD5pv_13panic_refcell(ptr align 8 %_1) unnamed_addr #1 !guid !21 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshF95OWYD5pv_13panic_refcell(ptr %_4) #10
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshF95OWYD5pv_13panic_refcell() #9
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshF95OWYD5pv_13panic_refcell(i8 %_2) #9
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshF95OWYD5pv_13panic_refcell(ptr %_1) unnamed_addr #1 !guid !22 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshF95OWYD5pv_13panic_refcell(ptr %0) #9
  ret i32 %_0
}

; panic_refcell::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCshF95OWYD5pv_13panic_refcell4main() unnamed_addr #0 personality ptr @rust_eh_personality !guid !23 {
start:
  %0 = alloca [16 x i8], align 8
  %_b = alloca [16 x i8], align 8
  %_a = alloca [16 x i8], align 8
  %c = alloca [16 x i8], align 8
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshF95OWYD5pv_13panic_refcell(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #9
  %_2.0 = extractvalue { ptr, ptr } %1, 0
  %_2.1 = extractvalue { ptr, ptr } %1, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call <core::cell::RefCell<i32>>::new
  %2 = call { i64, i32 } @_RNvMss_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCelllE3newCshF95OWYD5pv_13panic_refcell(i32 1) #9
  %3 = extractvalue { i64, i32 } %2, 0
  %4 = extractvalue { i64, i32 } %2, 1
  store i64 %3, ptr %c, align 8
  %5 = getelementptr inbounds i8, ptr %c, i64 8
  store i32 %4, ptr %5, align 8
; call <core::cell::RefCell<i32>>::borrow_mut
  %6 = call { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCelllE10borrow_mutCshF95OWYD5pv_13panic_refcell(ptr align 8 %c, ptr align 8 @alloc_f0c4731339e495e37cfd1808d9338843) #9
  %7 = extractvalue { ptr, ptr } %6, 0
  %8 = extractvalue { ptr, ptr } %6, 1
  store ptr %7, ptr %_a, align 8
  %9 = getelementptr inbounds i8, ptr %_a, i64 8
  store ptr %8, ptr %9, align 8
; invoke <core::cell::RefCell<i32>>::borrow_mut
  %10 = invoke { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCelllE10borrow_mutCshF95OWYD5pv_13panic_refcell(ptr align 8 %c, ptr align 8 @alloc_9ecd77ad4959c689ce3d66c39fef1f13)
          to label %bb5 unwind label %cleanup

bb11:                                             ; preds = %bb10, %cleanup
; invoke core::ptr::drop_glue::<core::cell::RefMut<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutlEECshF95OWYD5pv_13panic_refcell(ptr align 8 %_a) #11
          to label %bb12 unwind label %terminate

cleanup:                                          ; preds = %bb7, %start
  %11 = landingpad { ptr, i32 }
          cleanup
  %12 = extractvalue { ptr, i32 } %11, 0
  %13 = extractvalue { ptr, i32 } %11, 1
  store ptr %12, ptr %0, align 8
  %14 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %13, ptr %14, align 8
  br label %bb11

bb5:                                              ; preds = %start
  %15 = extractvalue { ptr, ptr } %10, 0
  %16 = extractvalue { ptr, ptr } %10, 1
  store ptr %15, ptr %_b, align 8
  %17 = getelementptr inbounds i8, ptr %_b, i64 8
  store ptr %16, ptr %17, align 8
; invoke <core::fmt::Arguments>::from_str
  %18 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshF95OWYD5pv_13panic_refcell(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12)
          to label %bb6 unwind label %cleanup1

bb10:                                             ; preds = %cleanup1
; invoke core::ptr::drop_glue::<core::cell::RefMut<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutlEECshF95OWYD5pv_13panic_refcell(ptr align 8 %_b) #11
          to label %bb11 unwind label %terminate

cleanup1:                                         ; preds = %bb6, %bb5
  %19 = landingpad { ptr, i32 }
          cleanup
  %20 = extractvalue { ptr, i32 } %19, 0
  %21 = extractvalue { ptr, i32 } %19, 1
  store ptr %20, ptr %0, align 8
  %22 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %21, ptr %22, align 8
  br label %bb10

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %18, 0
  %_9.1 = extractvalue { ptr, ptr } %18, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
          to label %bb7 unwind label %cleanup1

bb7:                                              ; preds = %bb6
; invoke core::ptr::drop_glue::<core::cell::RefMut<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutlEECshF95OWYD5pv_13panic_refcell(ptr align 8 %_b)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
; call core::ptr::drop_glue::<core::cell::RefMut<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutlEECshF95OWYD5pv_13panic_refcell(ptr align 8 %_a)
  ret void

terminate:                                        ; preds = %bb11, %bb10
  %23 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #12
  unreachable

bb12:                                             ; preds = %bb11
  %24 = load ptr, ptr %0, align 8
  %25 = getelementptr inbounds i8, ptr %0, i64 8
  %26 = load i32, ptr %25, align 8
  %27 = insertvalue { ptr, i32 } poison, ptr %24, 0
  %28 = insertvalue { ptr, i32 } %27, i32 %26, 1
  resume { ptr, i32 } %28
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshF95OWYD5pv_13panic_refcell(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !24 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCshF95OWYD5pv_13panic_refcell(ptr %self) unnamed_addr #1 !guid !25 {
start:
; call <*const ()>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCshF95OWYD5pv_13panic_refcell(ptr %self) #9
  ret i1 %_0
}

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCshF95OWYD5pv_13panic_refcell(ptr %self) unnamed_addr #1 !guid !26 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCshF95OWYD5pv_13panic_refcell(ptr %self) #9
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<i32>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE13new_uncheckedCshF95OWYD5pv_13panic_refcell(ptr %ptr, ptr align 8 %0) unnamed_addr #1 !guid !27 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshF95OWYD5pv_13panic_refcell() #9
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCshF95OWYD5pv_13panic_refcell(ptr %ptr, ptr align 8 %0) #13
  br label %bb3
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshF95OWYD5pv_13panic_refcell(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !28 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshF95OWYD5pv_13panic_refcell(ptr %s.0, i64 %s.1) #9
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::cell::Cell<isize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE3newCshF95OWYD5pv_13panic_refcell(i64 %value) unnamed_addr #1 !guid !29 {
start:
  ret i64 %value
}

; <core::cell::Cell<isize>>::replace
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE7replaceCshF95OWYD5pv_13panic_refcell(ptr align 8 %self, i64 %val) unnamed_addr #1 personality ptr @rust_eh_personality !guid !30 {
start:
  %_7 = alloca [1 x i8], align 1
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_7, align 1
; call core::mem::replace::<isize>
  %_0 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem7replaceiECshF95OWYD5pv_13panic_refcell(ptr align 8 %self, i64 %val) #9
  br label %bb2

bb2:                                              ; preds = %bb1
  ret i64 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::cell::Cell<isize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE3getCshF95OWYD5pv_13panic_refcell(ptr align 8 %self) unnamed_addr #1 !guid !31 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshF95OWYD5pv_13panic_refcell(ptr %self) unnamed_addr #1 !guid !32 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshF95OWYD5pv_13panic_refcell(i8 %0) unnamed_addr #1 !guid !33 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshF95OWYD5pv_13panic_refcell(ptr %self) #9
  ret i32 %_0
}

; <core::cell::BorrowRefMut>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMsP_NtCsl10jNU3mE6R_4core4cellNtB5_12BorrowRefMut3newCshF95OWYD5pv_13panic_refcell(ptr align 8 %borrow) unnamed_addr #1 !guid !34 {
start:
  %_0 = alloca [8 x i8], align 8
; call <core::cell::Cell<isize>>::get
  %_2 = call i64 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE3getCshF95OWYD5pv_13panic_refcell(ptr align 8 %borrow) #9
  %0 = icmp eq i64 %_2, 0
  br i1 %0, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::cell::Cell<isize>>::replace
  %_3 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE7replaceCshF95OWYD5pv_13panic_refcell(ptr align 8 %borrow, i64 -1) #9
  store ptr %borrow, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3
  %1 = load ptr, ptr %_0, align 8
  ret ptr %1
}

; <core::cell::RefCell<i32>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RNvMss_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCelllE3newCshF95OWYD5pv_13panic_refcell(i32 %value) unnamed_addr #1 personality ptr @rust_eh_personality !guid !35 {
start:
; call <core::cell::Cell<isize>>::new
  %_3 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE3newCshF95OWYD5pv_13panic_refcell(i64 0) #9
  br label %bb2

bb2:                                              ; preds = %start
  %0 = insertvalue { i64, i32 } poison, i64 %_3, 0
  %1 = insertvalue { i64, i32 } %0, i32 %value, 1
  ret { i64, i32 } %1

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::cell::RefCell<i32>>::borrow_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCelllE10borrow_mutCshF95OWYD5pv_13panic_refcell(ptr align 8 %self, ptr align 8 %0) unnamed_addr #1 !guid !36 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::cell::RefCell<i32>>::try_borrow_mut
  %1 = call { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCelllE14try_borrow_mutCshF95OWYD5pv_13panic_refcell(ptr align 8 %self) #9
  %2 = extractvalue { ptr, ptr } %1, 0
  %3 = extractvalue { ptr, ptr } %1, 1
  store ptr %2, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr %3, ptr %4, align 8
  %5 = load ptr, ptr %_2, align 8
  %6 = getelementptr inbounds i8, ptr %_2, i64 8
  %7 = load ptr, ptr %6, align 8
  %8 = ptrtoint ptr %5 to i64
  %9 = icmp eq i64 %8, 0
  %_3 = select i1 %9, i64 1, i64 0
  %10 = trunc nuw i64 %_3 to i1
  br i1 %10, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call core::cell::panic_already_borrowed
  call void @_RNvNtCsl10jNU3mE6R_4core4cell22panic_already_borrowed(ptr align 8 %0) #14
  unreachable

bb4:                                              ; preds = %start
  %b.0 = load ptr, ptr %_2, align 8
  %11 = getelementptr inbounds i8, ptr %_2, i64 8
  %b.1 = load ptr, ptr %11, align 8
  %12 = insertvalue { ptr, ptr } poison, ptr %b.0, 0
  %13 = insertvalue { ptr, ptr } %12, ptr %b.1, 1
  ret { ptr, ptr } %13

bb2:                                              ; No predecessors!
  unreachable
}

; <core::cell::RefCell<i32>>::try_borrow_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCelllE14try_borrow_mutCshF95OWYD5pv_13panic_refcell(ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !37 {
start:
  %0 = alloca [16 x i8], align 8
  %b = alloca [8 x i8], align 8
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::cell::BorrowRefMut>::new
  %1 = call align 8 ptr @_RNvMsP_NtCsl10jNU3mE6R_4core4cellNtB5_12BorrowRefMut3newCshF95OWYD5pv_13panic_refcell(ptr align 8 %self) #9
  store ptr %1, ptr %_2, align 8
  %2 = load ptr, ptr %_2, align 8
  %3 = ptrtoint ptr %2 to i64
  %4 = icmp eq i64 %3, 0
  %_4 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_4 to i1
  br i1 %5, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %6 = load ptr, ptr %_2, align 8
  store ptr %6, ptr %b, align 8
  %_8 = getelementptr inbounds i8, ptr %self, i64 8
  br label %bb5

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb3
  %7 = load ptr, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  %9 = load ptr, ptr %8, align 8
  %10 = insertvalue { ptr, ptr } poison, ptr %7, 0
  %11 = insertvalue { ptr, ptr } %10, ptr %9, 1
  ret { ptr, ptr } %11

bb8:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::cell::BorrowRefMut>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtB4_4cell12BorrowRefMutECshF95OWYD5pv_13panic_refcell(ptr align 8 %b) #11
          to label %bb9 unwind label %terminate

cleanup:                                          ; preds = %bb5
  %12 = landingpad { ptr, i32 }
          cleanup
  %13 = extractvalue { ptr, i32 } %12, 0
  %14 = extractvalue { ptr, i32 } %12, 1
  store ptr %13, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %14, ptr %15, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
; invoke <core::ptr::non_null::NonNull<i32>>::new_unchecked
  %value = invoke ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE13new_uncheckedCshF95OWYD5pv_13panic_refcell(ptr %_8, ptr align 8 @alloc_98f5b470f40a597b568a6efe978d8c0e)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  %_10 = load ptr, ptr %b, align 8
  store ptr %value, ptr %_0, align 8
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_10, ptr %16, align 8
  br label %bb7

terminate:                                        ; preds = %bb8
  %17 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #12
  unreachable

bb9:                                              ; preds = %bb8
  %18 = load ptr, ptr %0, align 8
  %19 = getelementptr inbounds i8, ptr %0, i64 8
  %20 = load i32, ptr %19, align 8
  %21 = insertvalue { ptr, i32 } poison, ptr %18, 0
  %22 = insertvalue { ptr, i32 } %21, i32 %20, 1
  resume { ptr, i32 } %22

bb2:                                              ; No predecessors!
  unreachable
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshF95OWYD5pv_13panic_refcell() unnamed_addr #1 !guid !38 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCshF95OWYD5pv_13panic_refcell() #9
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCshF95OWYD5pv_13panic_refcell(ptr %ptr) unnamed_addr #1 !guid !39 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCshF95OWYD5pv_13panic_refcell(ptr %ptr, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !40 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCshF95OWYD5pv_13panic_refcell(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #12
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshF95OWYD5pv_13panic_refcell(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #15
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCshF95OWYD5pv_13panic_refcell() unnamed_addr #1 !guid !41 {
start:
  ret i1 true
}

; <core::cell::BorrowRefMut as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsO_NtCsl10jNU3mE6R_4core4cellNtB5_12BorrowRefMutNtNtNtB7_3ops4drop4Drop4dropCshF95OWYD5pv_13panic_refcell(ptr align 8 %self) unnamed_addr #1 !guid !42 {
start:
  %_5 = load ptr, ptr %self, align 8
; call <core::cell::Cell<isize>>::get
  %borrow = call i64 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE3getCshF95OWYD5pv_13panic_refcell(ptr align 8 %_5) #9
  %_6 = load ptr, ptr %self, align 8
  %_4 = add i64 %borrow, 1
; call <core::cell::Cell<isize>>::replace
  %_3 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE7replaceCshF95OWYD5pv_13panic_refcell(ptr align 8 %_6, i64 %_4) #9
  ret void
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshF95OWYD5pv_13panic_refcell() unnamed_addr #1 !guid !43 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshF95OWYD5pv_13panic_refcell(ptr %_1) unnamed_addr #1 !guid !44 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshF95OWYD5pv_13panic_refcell(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !45 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshF95OWYD5pv_13panic_refcell(ptr align 8 %_1) #9
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #4

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #5

; core::cell::panic_already_borrowed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core4cell22panic_already_borrowed(ptr align 8) unnamed_addr #6

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #5

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #7

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #8 !guid !46 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshF95OWYD5pv_13panic_refcell(ptr @_RNvCshF95OWYD5pv_13panic_refcell4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { nonlazybind "target-cpu"="x86-64" }
attributes #9 = { inlinehint }
attributes #10 = { noinline }
attributes #11 = { cold }
attributes #12 = { cold noreturn nounwind }
attributes #13 = { inlinehint nounwind }
attributes #14 = { noinline noreturn }
attributes #15 = { noinline noreturn nounwind }

!llvm.module.flags = !{!9, !10, !11, !12}
!llvm.ident = !{!13}

!0 = !{i64 3452256874549422485}
!1 = !{i64 7503229740407130365}
!2 = !{i64 1689755750506550956}
!3 = !{i64 -373555181450522625}
!4 = !{i64 -7686889385056345156}
!5 = !{i64 -2031575534178110059}
!6 = !{i64 -339934457676547145}
!7 = !{i64 -5913310911460679122}
!8 = !{i64 -11096679055970870}
!9 = !{i32 8, !"PIC Level", i32 2}
!10 = !{i32 7, !"PIE Level", i32 2}
!11 = !{i32 2, !"RtLibUseGOT", i32 1}
!12 = !{i32 7, !"uwtable", i32 2}
!13 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!14 = !{i64 4641664543364575522}
!15 = !{i64 -5829524279845503590}
!16 = !{i64 -544124167849665007}
!17 = !{i64 -3607057892680843597}
!18 = !{i64 -6131836881042071145}
!19 = !{i64 1313100351711775}
!20 = !{i64 -6373015962813074969}
!21 = !{i64 6233215916893518448}
!22 = !{i64 181222953298829408}
!23 = !{i64 9063060595655283796}
!24 = !{i64 2565021182910789712}
!25 = !{i64 -5398775792795507740}
!26 = !{i64 -4200347613074393053}
!27 = !{i64 884397266350844544}
!28 = !{i64 79326387895801493}
!29 = !{i64 -6362026189991302793}
!30 = !{i64 1428517544961756660}
!31 = !{i64 -1937307448563232762}
!32 = !{i64 5749440322581221163}
!33 = !{i64 1576214646676814043}
!34 = !{i64 3147256786855648239}
!35 = !{i64 -4402326156363629544}
!36 = !{i64 309408276692047102}
!37 = !{i64 7462308736078736083}
!38 = !{i64 -4054945903056504109}
!39 = !{i64 7791184828300577283}
!40 = !{i64 -8311408070473754993}
!41 = !{i64 -7510429889665426699}
!42 = !{i64 -5365704987028386958}
!43 = !{i64 4218175675171341962}
!44 = !{i64 -5247445047181962401}
!45 = !{i64 2360646527633845173}
!46 = !{i64 -2624081020897602054}
