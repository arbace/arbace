; ModuleID = 'int_ops_u128.b84ce05c5f0484f0-cgu.0'
source_filename = "int_ops_u128.b84ce05c5f0484f0-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsfP1CzEAVZUO_12int_ops_u128, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsfP1CzEAVZUO_12int_ops_u128, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsfP1CzEAVZUO_12int_ops_u128 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !3
@alloc_8ef33618ae8ccb51a896393da2a634dc = private unnamed_addr constant [4 x i8] c"\80\00\00\00", align 4, !guid !4
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !5
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !7
@alloc_9473b0678f6a3ef4f88e09e441107e20 = private unnamed_addr constant [36 x i8] c"test/rust/synthetic/int-ops-u128.rs\00", align 1, !guid !8
@alloc_82b9f80d57ee99b909a846079071af6f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9473b0678f6a3ef4f88e09e441107e20, [16 x i8] c"#\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !9
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !10
@alloc_b596db19e65fc8f7ce36fc83684c8699 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9473b0678f6a3ef4f88e09e441107e20, [16 x i8] c"#\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !11
@alloc_6b495e81891e5eed06f352c5a2d02b98 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9473b0678f6a3ef4f88e09e441107e20, [16 x i8] c"#\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !12
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !13
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !14
@alloc_39fdd3c937f373cc7ca65d98d0e2c0cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9473b0678f6a3ef4f88e09e441107e20, [16 x i8] c"#\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !15
@alloc_f940fa70e7eac236630fd0904c3aa141 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9473b0678f6a3ef4f88e09e441107e20, [16 x i8] c"#\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !16
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !17
@alloc_0a4898c27747e5e0bee47b18a3f320ec = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9473b0678f6a3ef4f88e09e441107e20, [16 x i8] c"#\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !18
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !19
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !20
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !21
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !22
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !23
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !24
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !25
@alloc_c2df0f2eed0ee910e76dda7517cc7a45 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\05\00\00\05\00\00\00" }>, align 8, !guid !26
@alloc_5aa1d1250638a5285856df0c8e3018a3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00K\07\00\00\01\00\00\00" }>, align 8, !guid !27
@anon.c315984353131a6bca32d403680bc46d.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !28
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !29
@alloc_dd07830ff498a5ad3af27fc9310868e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E5\00\00\00\12\00\00\00" }>, align 8, !guid !30
@alloc_73a63def61abd19c5b285b7e5bba6f74 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E6\00\00\00\05\00\00\00" }>, align 8, !guid !31
@alloc_c9c619c258f652778f0098fbdacd3593 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F1\00\00\00\12\00\00\00" }>, align 8, !guid !32
@alloc_debe392282102e1a17f340d9b53f07df = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F2\00\00\00\12\00\00\00" }>, align 8, !guid !33
@alloc_d1e64d3a180065bd6a022925cad00717 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F3\00\00\00\05\00\00\00" }>, align 8, !guid !34
@alloc_9a4d1999757609695fb8537fcdec871b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FE\00\00\00\12\00\00\00" }>, align 8, !guid !35
@alloc_ffea377e021bf2f87b4ad4aac9bcd041 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FF\00\00\00\12\00\00\00" }>, align 8, !guid !36
@alloc_3410a5a3f8bc9abd6709ddad50da91f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\00\01\00\00\12\00\00\00" }>, align 8, !guid !37
@alloc_cb646754bd05cd238e749888201337e6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\01\01\00\00\05\00\00\00" }>, align 8, !guid !38
@alloc_eda7b11e07c58ae313ac1fad01d041e9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\0C\01\00\00\12\00\00\00" }>, align 8, !guid !39
@alloc_6042291b1954087ab71387f1f17f0449 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\0D\01\00\00\12\00\00\00" }>, align 8, !guid !40
@alloc_ce4d3b1f48911fd97fc8507578e88cdb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\0E\01\00\00\12\00\00\00" }>, align 8, !guid !41
@alloc_2a09b92e9319e8cf7ffdc293d51a865d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\0F\01\00\00\12\00\00\00" }>, align 8, !guid !42
@alloc_cdc8401a47de3b375010692dbb496696 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\10\01\00\00\05\00\00\00" }>, align 8, !guid !43
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !44
@alloc_8889105080bbd684fa4b755988461744 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: u128::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !45
@alloc_8efb6cb47e437ad05e23651986f609b7 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: u128::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !46
@alloc_3e2bc8b0102fca1babff0a50e98b5638 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: u128::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !47
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !48
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRoNtB6_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128 }>, align 8, !guid !49
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128 }>, align 8, !guid !50
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !51
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !52
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !53
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !54
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !55
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !56
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !57
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128 }>, align 8, !guid !58

; <str>::parse::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !64 {
start:
; call <u128 as core::str::traits::FromStr>::from_str
  call void @_RNvXsE_NtCsl10jNU3mE6R_4core3numoNtNtNtB7_3str6traits7FromStr8from_strCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, ptr %self.0, i64 %self.1) #17
  ret void
}

; <core::fmt::rt::Argument>::new_binary::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !65 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsG_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !66 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !67 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !68 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 4 %x) #17
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !69 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !70 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !71 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<u128>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionoEE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<core::option::Option<u128>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionoEE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionoENtNtB7_3fmt5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<u128, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultoNtNtNtB7_3num5error13ParseIntErrorEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !72 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultoNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultoNtNtNtBa_3num5error13ParseIntErrorEE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultoNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(u128, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTobEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !73 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(u128, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTobEE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<(u128, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTobEE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTobENtB6_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !74 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octaloECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !75 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsI_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::option::Option<u128>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionoEE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %self) unnamed_addr #0 !guid !76 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultoNtNtNtBa_3num5error13ParseIntErrorEE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %self) unnamed_addr #0 !guid !77 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<(u128, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTobEE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %self) unnamed_addr #0 !guid !78 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %self) unnamed_addr #0 !guid !79 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %self) unnamed_addr #0 !guid !80 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsfP1CzEAVZUO_12int_ops_u128(ptr %self) unnamed_addr #0 !guid !81 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsfP1CzEAVZUO_12int_ops_u128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !82 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsfP1CzEAVZUO_12int_ops_u128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !83 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsfP1CzEAVZUO_12int_ops_u128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !84 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsfP1CzEAVZUO_12int_ops_u128(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !85 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u128>
; Function Attrs: nounwind nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftoECsfP1CzEAVZUO_12int_ops_u128(i128 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !86 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 16 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i128
  %_0 = call i128 @llvm.fshl.i128(i128 %x, i128 %x, i128 %1)
  ret i128 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u128>
; Function Attrs: nounwind nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightoECsfP1CzEAVZUO_12int_ops_u128(i128 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !87 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 16 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i128
  %_0 = call i128 @llvm.fshr.i128(i128 %x, i128 %x, i128 %1)
  ret i128 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsfP1CzEAVZUO_12int_ops_u128(i32 %dummy) unnamed_addr #0 !guid !88 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !89
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsfP1CzEAVZUO_12int_ops_u128(i32 %dummy) unnamed_addr #0 !guid !90 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !89
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECsfP1CzEAVZUO_12int_ops_u128(i128 %dummy) unnamed_addr #0 !guid !91 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !89
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsfP1CzEAVZUO_12int_ops_u128(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !92 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfP1CzEAVZUO_12int_ops_u128(ptr %f) #17
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #17
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %_1) unnamed_addr #0 !guid !93 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsfP1CzEAVZUO_12int_ops_u128(ptr %_4) #20
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsfP1CzEAVZUO_12int_ops_u128() #17
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsfP1CzEAVZUO_12int_ops_u128(i8 %_2) #17
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsfP1CzEAVZUO_12int_ops_u128(ptr %_1) unnamed_addr #0 !guid !94 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfP1CzEAVZUO_12int_ops_u128(ptr %0) #17
  ret i32 %_0
}

; int_ops_u128::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsfP1CzEAVZUO_12int_ops_u1284main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !95 {
start:
  %0 = alloca [16 x i8], align 8
  %_288 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_283 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_278 = alloca [24 x i8], align 8
  %_277 = alloca [24 x i8], align 8
  %_273 = alloca [24 x i8], align 8
  %_270 = alloca [8 x i8], align 8
  %_263 = alloca [16 x i8], align 8
  %_262 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_258 = alloca [4 x i8], align 4
  %_256 = alloca [16 x i8], align 16
  %_249 = alloca [16 x i8], align 8
  %_248 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_246 = alloca [4 x i8], align 4
  %_244 = alloca [4 x i8], align 4
  %_237 = alloca [16 x i8], align 8
  %_236 = alloca [16 x i8], align 8
  %_235 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_233 = alloca [8 x i8], align 8
  %_231 = alloca [4 x i8], align 4
  %_227 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_220 = alloca [16 x i8], align 8
  %_219 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_216 = alloca [32 x i8], align 16
  %_214 = alloca [1 x i8], align 1
  %_210 = alloca [32 x i8], align 16
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_200 = alloca [16 x i8], align 16
  %_197 = alloca [16 x i8], align 16
  %_190 = alloca [16 x i8], align 8
  %_189 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_187 = alloca [32 x i8], align 16
  %_184 = alloca [32 x i8], align 16
  %_177 = alloca [16 x i8], align 8
  %_176 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_173 = alloca [16 x i8], align 16
  %_170 = alloca [16 x i8], align 16
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [16 x i8], align 16
  %_156 = alloca [16 x i8], align 16
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [16 x i8], align 16
  %_144 = alloca [16 x i8], align 16
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [16 x i8], align 16
  %_130 = alloca [16 x i8], align 16
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [32 x i8], align 16
  %_98 = alloca [32 x i8], align 16
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [16 x i8], align 16
  %_86 = alloca [16 x i8], align 16
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [16 x i8], align 16
  %_74 = alloca [16 x i8], align 16
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [16 x i8], align 16
  %_62 = alloca [16 x i8], align 16
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [32 x i8], align 16
  %_50 = alloca [32 x i8], align 16
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [32 x i8], align 16
  %_38 = alloca [32 x i8], align 16
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [16 x i8], align 16
  %min = alloca [16 x i8], align 16
; call core::hint::black_box::<u128>
  %_4 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECsfP1CzEAVZUO_12int_ops_u128(i128 0) #17
; call core::hint::black_box::<u128>
  %_5 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECsfP1CzEAVZUO_12int_ops_u128(i128 -1) #17
  store i128 %_4, ptr %min, align 16
  store i128 %_5, ptr %max, align 16
; call core::hint::black_box::<u128>
  %one = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECsfP1CzEAVZUO_12int_ops_u128(i128 1) #17
; call core::hint::black_box::<u128>
  %three = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECsfP1CzEAVZUO_12int_ops_u128(i128 3) #17
  store ptr %min, ptr %args, align 8
  %1 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_8ef33618ae8ccb51a896393da2a634dc, ptr %2, align 8
  %_291 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_15, ptr align 16 %_291) #17
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  %_292 = load ptr, ptr %3, align 8
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_16, ptr align 16 %_292) #17
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  %_293 = load ptr, ptr %4, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_293) #17
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_15, i64 16, i1 false)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_16, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsfP1CzEAVZUO_12int_ops_u128(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #17
  %_9.0 = extractvalue { ptr, ptr } %8, 0
  %_9.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %9 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %11, align 8
  %_294 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoEB7_(ptr sret([16 x i8]) align 8 %_28, ptr align 16 %_294) #17
  %12 = getelementptr inbounds i8, ptr %args2, i64 8
  %_295 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_binary::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_29, ptr align 16 %_295) #17
  %13 = getelementptr inbounds i8, ptr %args2, i64 16
  %_296 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_octal::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octaloECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_30, ptr align 16 %_296) #17
  %14 = getelementptr inbounds i8, ptr %args2, i64 24
  %_297 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_31, ptr align 16 %_297) #17
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_28, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_29, i64 16, i1 false)
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_30, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsfP1CzEAVZUO_12int_ops_u128(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #17
  %_21.0 = extractvalue { ptr, ptr } %19, 0
  %_21.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %20 = load i128, ptr %max, align 16
; call <u128>::checked_add
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_38, i128 %20, i128 %one) #17
  %21 = load i128, ptr %min, align 16
; call <u128>::checked_add
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_40, i128 %21, i128 %one) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_42, ptr align 16 %_38) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_43, ptr align 16 %_40) #17
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_42, i64 16, i1 false)
  %23 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %23, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %24 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #17
  %_35.0 = extractvalue { ptr, ptr } %24, 0
  %_35.1 = extractvalue { ptr, ptr } %24, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %25 = load i128, ptr %max, align 16
  %_5.0.i = add i128 %25, %one
  %_5.1.i = icmp ult i128 %_5.0.i, %25
  store i128 %_5.0.i, ptr %_50, align 16
  %26 = getelementptr inbounds i8, ptr %_50, i64 16
  %27 = zext i1 %_5.1.i to i8
  store i8 %27, ptr %26, align 16
  %28 = load i128, ptr %min, align 16
  %_5.0.i53 = sub i128 %28, %one
  %_5.1.i54 = icmp ult i128 %28, %one
  store i128 %_5.0.i53, ptr %_52, align 16
  %29 = getelementptr inbounds i8, ptr %_52, i64 16
  %30 = zext i1 %_5.1.i54 to i8
  store i8 %30, ptr %29, align 16
; call <core::fmt::rt::Argument>::new_debug::<(u128, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTobEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_54, ptr align 16 %_50) #17
; call <core::fmt::rt::Argument>::new_debug::<(u128, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTobEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_55, ptr align 16 %_52) #17
  %31 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %31, ptr align 8 %_54, i64 16, i1 false)
  %32 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %33 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #17
  %_47.0 = extractvalue { ptr, ptr } %33, 0
  %_47.1 = extractvalue { ptr, ptr } %33, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %34 = load i128, ptr %max, align 16
  %_0.i35 = add i128 %34, %one
  store i128 %_0.i35, ptr %_62, align 16
  %35 = load i128, ptr %min, align 16
  %_0.i41 = sub i128 %35, %one
  store i128 %_0.i41, ptr %_64, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_66, ptr align 16 %_62) #17
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_67, ptr align 16 %_64) #17
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_66, i64 16, i1 false)
  %37 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %37, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %38 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #17
  %_59.0 = extractvalue { ptr, ptr } %38, 0
  %_59.1 = extractvalue { ptr, ptr } %38, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %39 = load i128, ptr %max, align 16
  %_0.i49 = call i128 @llvm.uadd.sat.i128(i128 %39, i128 %three)
  store i128 %_0.i49, ptr %_74, align 16
  %40 = load i128, ptr %min, align 16
  %_0.i50 = call i128 @llvm.usub.sat.i128(i128 %40, i128 %three)
  store i128 %_0.i50, ptr %_76, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_78, ptr align 16 %_74) #17
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_79, ptr align 16 %_76) #17
  %41 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %41, ptr align 8 %_78, i64 16, i1 false)
  %42 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %42, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %43 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #17
  %_71.0 = extractvalue { ptr, ptr } %43, 0
  %_71.1 = extractvalue { ptr, ptr } %43, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %44 = load i128, ptr %max, align 16
  %_0.i37 = mul i128 %44, %three
  store i128 %_0.i37, ptr %_86, align 16
  %45 = load i128, ptr %max, align 16
  %46 = load i128, ptr %max, align 16
  %_0.i36 = mul i128 %45, %46
  store i128 %_0.i36, ptr %_88, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_90, ptr align 16 %_86) #17
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_91, ptr align 16 %_88) #17
  %47 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %47, ptr align 8 %_90, i64 16, i1 false)
  %48 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %48, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %49 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #17
  %_83.0 = extractvalue { ptr, ptr } %49, 0
  %_83.1 = extractvalue { ptr, ptr } %49, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %50 = load i128, ptr %max, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_98, i128 %50, i128 %three) #17
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsfP1CzEAVZUO_12int_ops_u128(i32 5) #17
; call <u128>::checked_pow
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_powCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_100, i128 %three, i32 %_101) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_103, ptr align 16 %_98) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_104, ptr align 16 %_100) #17
  %51 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %_103, i64 16, i1 false)
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %53 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #17
  %_95.0 = extractvalue { ptr, ptr } %53, 0
  %_95.1 = extractvalue { ptr, ptr } %53, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %54 = load i128, ptr %max, align 16
  %55 = call i128 @llvm.ctpop.i128(i128 %54)
  %_0.i = trunc i128 %55 to i32
  store i32 %_0.i, ptr %_111, align 4
  %56 = load i128, ptr %max, align 16
  %57 = call i128 @llvm.ctlz.i128(i128 %56, i1 false)
  %_0.i43 = trunc i128 %57 to i32
  store i32 %_0.i43, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsfP1CzEAVZUO_12int_ops_u128(i32 3) #17
  %_119 = icmp ult i32 %_117, 128
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %58 = and i32 %_117, 127
  %59 = zext i32 %58 to i128
  %_116 = shl i128 %one, %59
  %60 = call i128 @llvm.cttz.i128(i128 %_116, i1 false)
  %_0.i52 = trunc i128 %60 to i32
  store i32 %_0.i52, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %61 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %61, align 8
  %62 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %62, align 8
  %_310 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_310) #17
  %63 = getelementptr inbounds i8, ptr %args10, i64 8
  %_311 = load ptr, ptr %63, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_311) #17
  %64 = getelementptr inbounds i8, ptr %args10, i64 16
  %_312 = load ptr, ptr %64, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_312) #17
  %65 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %65, ptr align 8 %_121, i64 16, i1 false)
  %66 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %66, ptr align 8 %_122, i64 16, i1 false)
  %67 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %67, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %68 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsfP1CzEAVZUO_12int_ops_u128(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #17
  %_108.0 = extractvalue { ptr, ptr } %68, 0
  %_108.1 = extractvalue { ptr, ptr } %68, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsfP1CzEAVZUO_12int_ops_u128(i32 5) #17
  %69 = load i128, ptr %max, align 16
; call core::intrinsics::rotate_left::<u128>
  %_0.i31 = call i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftoECsfP1CzEAVZUO_12int_ops_u128(i128 %69, i32 %_131) #21
  store i128 %_0.i31, ptr %_130, align 16
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsfP1CzEAVZUO_12int_ops_u128(i32 7) #17
  %70 = load i128, ptr %min, align 16
; call core::intrinsics::rotate_right::<u128>
  %_0.i34 = call i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightoECsfP1CzEAVZUO_12int_ops_u128(i128 %70, i32 %_134) #21
  store i128 %_0.i34, ptr %_133, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_136, ptr align 16 %_130) #17
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_137, ptr align 16 %_133) #17
  %71 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %71, ptr align 8 %_136, i64 16, i1 false)
  %72 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %72, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %73 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #17
  %_127.0 = extractvalue { ptr, ptr } %73, 0
  %_127.1 = extractvalue { ptr, ptr } %73, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %74 = load i128, ptr %max, align 16
  %_0.i30 = call i128 @llvm.bswap.i128(i128 %74)
  store i128 %_0.i30, ptr %_144, align 16
  %75 = load i128, ptr %max, align 16
  %_0.i33 = call i128 @llvm.bitreverse.i128(i128 %75)
  store i128 %_0.i33, ptr %_146, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_148, ptr align 16 %_144) #17
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_149, ptr align 16 %_146) #17
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_148, i64 16, i1 false)
  %77 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %77, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %78 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #17
  %_141.0 = extractvalue { ptr, ptr } %78, 0
  %_141.1 = extractvalue { ptr, ptr } %78, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsfP1CzEAVZUO_12int_ops_u128(i32 70) #17
  %79 = load i128, ptr %max, align 16
  %_3.i = and i32 %_157, 127
; call core::ub_checks::check_language_ub
  %_3.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_3.i44, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <u128>::unchecked_shl::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i32 %_3.i, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %80 = zext i32 %_3.i to i128
  %_0.i45 = shl i128 %79, %80
  store i128 %_0.i45, ptr %_156, align 16
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsfP1CzEAVZUO_12int_ops_u128(i32 66) #17
  %81 = load i128, ptr %min, align 16
  %_3.i39 = and i32 %_160, 127
; call core::ub_checks::check_language_ub
  %_3.i46 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_3.i46, label %bb2.i48, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shr.exit

bb2.i48:                                          ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit
; call <u128>::unchecked_shr::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shr18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i32 %_3.i39, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shr.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shr.exit: ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit, %bb2.i48
  %82 = zext i32 %_3.i39 to i128
  %_0.i47 = lshr i128 %81, %82
  store i128 %_0.i47, ptr %_159, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_162, ptr align 16 %_156) #17
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_163, ptr align 16 %_159) #17
  %83 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %83, ptr align 8 %_162, i64 16, i1 false)
  %84 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %84, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %85 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #17
  %_153.0 = extractvalue { ptr, ptr } %85, 0
  %_153.1 = extractvalue { ptr, ptr } %85, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i128 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_82b9f80d57ee99b909a846079071af6f) #23
  unreachable

bb85:                                             ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shr.exit
  %86 = load i128, ptr %max, align 16
  %87 = udiv i128 %86, %three
  store i128 %87, ptr %_170, align 16
  %_174 = icmp eq i128 %three, 0
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_b596db19e65fc8f7ce36fc83684c8699) #23
  unreachable

bb86:                                             ; preds = %bb85
  %88 = load i128, ptr %max, align 16
  %89 = urem i128 %88, %three
  store i128 %89, ptr %_173, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_176, ptr align 16 %_170) #17
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_177, ptr align 16 %_173) #17
  %90 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %90, ptr align 8 %_176, i64 16, i1 false)
  %91 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %91, ptr align 8 %_177, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %92 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #17
  %_167.0 = extractvalue { ptr, ptr } %92, 0
  %_167.1 = extractvalue { ptr, ptr } %92, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<u128>
  %_185 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECsfP1CzEAVZUO_12int_ops_u128(i128 0) #17
  %93 = load i128, ptr %max, align 16
; call <u128>::checked_div
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_divCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_184, i128 %93, i128 %_185) #17
  %94 = load i128, ptr %max, align 16
; call <u128>::checked_rem
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_remCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_187, i128 %94, i128 %three) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_189, ptr align 16 %_184) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_190, ptr align 16 %_187) #17
  %95 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %95, ptr align 8 %_189, i64 16, i1 false)
  %96 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %96, ptr align 8 %_190, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %97 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #17
  %_181.0 = extractvalue { ptr, ptr } %97, 0
  %_181.1 = extractvalue { ptr, ptr } %97, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_181.0, ptr %_181.1)
; call core::hint::black_box::<u32>
  %_198 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsfP1CzEAVZUO_12int_ops_u128(i32 4) #17
; call <u128>::pow
  %98 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCsfP1CzEAVZUO_12int_ops_u128(i128 %three, i32 %_198) #17
  store i128 %98, ptr %_197, align 16
  %99 = load i128, ptr %max, align 16
  %100 = load i128, ptr %min, align 16
; call <u128>::abs_diff
  %101 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo8abs_diffCsfP1CzEAVZUO_12int_ops_u128(i128 %99, i128 %100) #17
  store i128 %101, ptr %_200, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_202, ptr align 16 %_197) #17
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_203, ptr align 16 %_200) #17
  %102 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %102, ptr align 8 %_202, i64 16, i1 false)
  %103 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %103, ptr align 8 %_203, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %104 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #17
  %_194.0 = extractvalue { ptr, ptr } %104, 0
  %_194.1 = extractvalue { ptr, ptr } %104, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_194.0, ptr %_194.1)
; call core::hint::black_box::<u32>
  %_212 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsfP1CzEAVZUO_12int_ops_u128(i32 7) #17
; call <u128>::from_str_radix
  call void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo14from_str_radixCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_210, ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_212) #17
; call <str>::parse::<u128>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_216, ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #17
; call <core::result::Result<u128, core::num::error::ParseIntError>>::is_ok
  %105 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE5is_okCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %_216) #17
  %106 = zext i1 %105 to i8
  store i8 %106, ptr %_214, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<u128, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultoNtNtNtB7_3num5error13ParseIntErrorEECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_219, ptr align 16 %_210) #17
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_220, ptr %_214) #17
  %107 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_219, i64 16, i1 false)
  %108 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %108, ptr align 8 %_220, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %109 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #17
  %_207.0 = extractvalue { ptr, ptr } %109, 0
  %_207.1 = extractvalue { ptr, ptr } %109, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_207.0, ptr %_207.1)
  %110 = load i128, ptr %max, align 16
  %_229 = uitofp i128 %110 to double
  %_228 = call i128 @llvm.fptoui.sat.i128.f64(double %_229)
  %111 = load i128, ptr %max, align 16
  %112 = icmp eq i128 %_228, %111
  %113 = zext i1 %112 to i8
  store i8 %113, ptr %_227, align 1
  %114 = load i128, ptr %max, align 16
  %115 = uitofp i128 %114 to float
  store float %115, ptr %_231, align 4
  %116 = load i128, ptr %min, align 16
  %117 = uitofp i128 %116 to double
  store double %117, ptr %_233, align 8
  store ptr %_227, ptr %args19, align 8
  %118 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_231, ptr %118, align 8
  %119 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_233, ptr %119, align 8
  %_327 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_235, ptr %_327) #17
  %120 = getelementptr inbounds i8, ptr %args19, i64 8
  %_328 = load ptr, ptr %120, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_236, ptr align 4 %_328) #17
  %121 = getelementptr inbounds i8, ptr %args19, i64 16
  %_329 = load ptr, ptr %121, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_237, ptr align 8 %_329) #17
  %122 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %122, ptr align 8 %_235, i64 16, i1 false)
  %123 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %123, ptr align 8 %_236, i64 16, i1 false)
  %124 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %124, ptr align 8 %_237, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %125 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsfP1CzEAVZUO_12int_ops_u128(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #17
  %_224.0 = extractvalue { ptr, ptr } %125, 0
  %_224.1 = extractvalue { ptr, ptr } %125, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_224.0, ptr %_224.1)
  %126 = load i128, ptr %max, align 16
  %_2.i = xor i128 %126, -1
  %127 = call i128 @llvm.ctlz.i128(i128 %_2.i, i1 false)
  %_0.i42 = trunc i128 %127 to i32
  store i32 %_0.i42, ptr %_244, align 4
  %128 = load i128, ptr %min, align 16
  %129 = call i128 @llvm.cttz.i128(i128 %128, i1 false)
  %_0.i51 = trunc i128 %129 to i32
  store i32 %_0.i51, ptr %_246, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_248, ptr align 4 %_244) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_249, ptr align 4 %_246) #17
  %130 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %130, ptr align 8 %_248, i64 16, i1 false)
  %131 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %131, ptr align 8 %_249, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %132 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #17
  %_241.0 = extractvalue { ptr, ptr } %132, 0
  %_241.1 = extractvalue { ptr, ptr } %132, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_241.0, ptr %_241.1)
  %133 = load i128, ptr %max, align 16
; call <u128>::isqrt
  %134 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5isqrtCsfP1CzEAVZUO_12int_ops_u128(i128 %133) #17
  store i128 %134, ptr %_256, align 16
  %135 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %three, i128 %three)
  %_260.0 = extractvalue { i128, i1 } %135, 0
  %_260.1 = extractvalue { i128, i1 } %135, 1
  br i1 %_260.1, label %panic27, label %bb125

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_6b495e81891e5eed06f352c5a2d02b98) #23
  unreachable

bb125:                                            ; preds = %bb86
; call <u128>::ilog2
  %136 = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2CsfP1CzEAVZUO_12int_ops_u128(i128 %_260.0, ptr align 8 @alloc_f940fa70e7eac236630fd0904c3aa141) #17
  store i32 %136, ptr %_258, align 4
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_262, ptr align 16 %_256) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_263, ptr align 4 %_258) #17
  %137 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %137, ptr align 8 %_262, i64 16, i1 false)
  %138 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %138, ptr align 8 %_263, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %139 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #17
  %_253.0 = extractvalue { ptr, ptr } %139, 0
  %_253.1 = extractvalue { ptr, ptr } %139, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_253.0, ptr %_253.1)
; call <u128 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringoNtB5_8ToString9to_stringCsfP1CzEAVZUO_12int_ops_u128(ptr sret([24 x i8]) align 8 %_273, ptr align 16 %max) #17
; invoke <alloc::string::String>::len
  %_271 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %_273)
          to label %bb132 unwind label %cleanup

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_39fdd3c937f373cc7ca65d98d0e2c0cb) #23
  unreachable

bb145:                                            ; preds = %bb144, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_273) #24
          to label %bb146 unwind label %terminate

cleanup:                                          ; preds = %bb141, %bb134, %bb133, %bb132, %bb125
  %140 = landingpad { ptr, i32 }
          cleanup
  %141 = extractvalue { ptr, i32 } %140, 0
  %142 = extractvalue { ptr, i32 } %140, 1
  store ptr %141, ptr %0, align 8
  %143 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %142, ptr %143, align 8
  br label %bb145

bb132:                                            ; preds = %bb125
; invoke <core::fmt::rt::Argument>::new_display::<u128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsfP1CzEAVZUO_12int_ops_u128(ptr sret([16 x i8]) align 8 %_283, ptr align 16 %min)
          to label %bb133 unwind label %cleanup

bb133:                                            ; preds = %bb132
  %144 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %144, ptr align 8 %_283, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %145 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb134 unwind label %cleanup

bb134:                                            ; preds = %bb133
  %_279.0 = extractvalue { ptr, ptr } %145, 0
  %_279.1 = extractvalue { ptr, ptr } %145, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsfP1CzEAVZUO_12int_ops_u128(ptr sret([24 x i8]) align 8 %_278, ptr %_279.0, ptr %_279.1)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_277, ptr align 8 %_278, i64 24, i1 false)
  br label %bb136

bb136:                                            ; preds = %bb135
; invoke <alloc::string::String>::len
  %_275 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %_277)
          to label %bb137 unwind label %cleanup28

bb144:                                            ; preds = %cleanup28
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_277) #24
          to label %bb145 unwind label %terminate

cleanup28:                                        ; preds = %bb140, %bb139, %bb138, %panic29, %bb136
  %146 = landingpad { ptr, i32 }
          cleanup
  %147 = extractvalue { ptr, i32 } %146, 0
  %148 = extractvalue { ptr, i32 } %146, 1
  store ptr %147, ptr %0, align 8
  %149 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %148, ptr %149, align 8
  br label %bb144

bb137:                                            ; preds = %bb136
  %_286.0 = add i64 %_271, %_275
  %_286.1 = icmp ult i64 %_286.0, %_271
  br i1 %_286.1, label %panic29, label %bb138

bb138:                                            ; preds = %bb137
  store i64 %_286.0, ptr %_270, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_288, ptr align 8 %_270)
          to label %bb139 unwind label %cleanup28

panic29:                                          ; preds = %bb137
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_0a4898c27747e5e0bee47b18a3f320ec) #19
          to label %unreachable unwind label %cleanup28

unreachable:                                      ; preds = %panic29
  unreachable

bb139:                                            ; preds = %bb138
  %150 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %150, ptr align 8 %_288, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %151 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb140 unwind label %cleanup28

bb140:                                            ; preds = %bb139
  %_267.0 = extractvalue { ptr, ptr } %151, 0
  %_267.1 = extractvalue { ptr, ptr } %151, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_267.0, ptr %_267.1)
          to label %bb141 unwind label %cleanup28

bb141:                                            ; preds = %bb140
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_277)
          to label %bb142 unwind label %cleanup

bb142:                                            ; preds = %bb141
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_273)
  ret void

terminate:                                        ; preds = %bb145, %bb144
  %152 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable

bb146:                                            ; preds = %bb145
  %153 = load ptr, ptr %0, align 8
  %154 = getelementptr inbounds i8, ptr %0, i64 8
  %155 = load i32, ptr %154, align 8
  %156 = insertvalue { ptr, i32 } poison, ptr %153, 0
  %157 = insertvalue { ptr, i32 } %156, i32 %155, 1
  resume { ptr, i32 } %157
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %self) unnamed_addr #0 !guid !96 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #17
  ret i64 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsfP1CzEAVZUO_12int_ops_u128(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !97 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::result::Result<u128, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE5is_okCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %self) unnamed_addr #0 !guid !98 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsfP1CzEAVZUO_12int_ops_u128(i32 %self, i32 %radix) unnamed_addr #0 !guid !99 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfP1CzEAVZUO_12int_ops_u128(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #17
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #23
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsfP1CzEAVZUO_12int_ops_u128(i32 %self) unnamed_addr #0 !guid !100 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsfP1CzEAVZUO_12int_ops_u128(i32 %self) #17
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsfP1CzEAVZUO_12int_ops_u128(i32 %self) unnamed_addr #0 !guid !101 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::num::nonzero::NonZero<u128>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE13leading_zerosCsfP1CzEAVZUO_12int_ops_u128(i128 %self) unnamed_addr #0 !guid !102 {
start:
; call <core::num::nonzero::NonZero<u128>>::get
  %_2 = call i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3getB9_(i128 %self) #17
  %0 = call i128 @llvm.ctlz.i128(i128 %_2, i1 true)
  %_0 = trunc i128 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u128>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE5ilog2CsfP1CzEAVZUO_12int_ops_u128(i128 %self) unnamed_addr #0 !guid !103 {
start:
; call <core::num::nonzero::NonZero<u128>>::leading_zeros
  %_3 = call i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE13leading_zerosCsfP1CzEAVZUO_12int_ops_u128(i128 %self) #17
  %_0 = sub i32 127, %_3
  ret i32 %_0
}

; <core::ptr::non_null::NonNull<core::option::Option<u128>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionoEE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %r) unnamed_addr #0 !guid !104 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultoNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %r) unnamed_addr #0 !guid !105 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<(u128, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTobEE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %r) unnamed_addr #0 !guid !106 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr %r) unnamed_addr #0 !guid !107 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %r) unnamed_addr #0 !guid !108 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsfP1CzEAVZUO_12int_ops_u128(ptr align 4 %r) unnamed_addr #0 !guid !109 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %self) unnamed_addr #0 !guid !110 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #17
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsfP1CzEAVZUO_12int_ops_u128(ptr %_7.0, i64 %_7.1) #17
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfP1CzEAVZUO_12int_ops_u128(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !111 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsfP1CzEAVZUO_12int_ops_u128(ptr %s.0, i64 %s.1) #17
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsfP1CzEAVZUO_12int_ops_u128(i32 %self, i32 %rhs) unnamed_addr #0 !guid !112 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u128>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo10strict_powCsfP1CzEAVZUO_12int_ops_u128(i128 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !113 {
start:
  %_3 = alloca [32 x i8], align 16
; call <u128>::checked_pow
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_powCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_3, i128 %self, i32 %exp) #17
  %1 = load i128, ptr %_3, align 16
  %2 = getelementptr inbounds i8, ptr %_3, i64 16
  %3 = load i128, ptr %2, align 16
  %_4 = trunc i128 %1 to i64
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %_3, i64 16
  %a = load i128, ptr %5, align 16
  ret i128 %a

bb4:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <u128>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !114 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_5.0 = add i128 %self, %rhs
  %_5.1 = icmp ult i128 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i128 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_6, ptr %2, align 16
  store i128 1, ptr %_0, align 16
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void
}

; <u128>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_divCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !115 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = icmp eq i128 %rhs, 0
  br i1 %_4, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_5 = udiv i128 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5, ptr %2, align 16
  store i128 1, ptr %_0, align 16
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void
}

; <u128>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !116 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <u128>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_powCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !117 {
start:
  %_49 = alloca [32 x i8], align 16
  %_40 = alloca [32 x i8], align 16
  %_30 = alloca [32 x i8], align 16
  %_24 = alloca [32 x i8], align 16
  %_11 = alloca [8 x i8], align 4
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  %_6 = load i128, ptr %base, align 16
  %_5 = call i1 @llvm.is.constant.i128(i128 %_6)
  br i1 %_5, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_16 = load i32, ptr %exp, align 4
  %_15 = icmp eq i32 %_16, 0
  br i1 %_15, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_8 = load i128, ptr %base, align 16
  %1 = call i128 @llvm.ctpop.i128(i128 %_8)
  %_0.i.i = trunc i128 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_10 = load i128, ptr %base, align 16
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2CsfP1CzEAVZUO_12int_ops_u128(i128 %_10, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #17
  %_12 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsfP1CzEAVZUO_12int_ops_u128(i32 %k, i32 %_12) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_11, align 4
  %5 = getelementptr inbounds i8, ptr %_11, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_11, align 4
  %7 = getelementptr inbounds i8, ptr %_11, i64 4
  %8 = load i32, ptr %7, align 4
  %_13 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_13 to i1
  br i1 %9, label %bb9, label %bb8

bb12:                                             ; preds = %bb10
  %_18 = load i32, ptr %exp, align 4
  %_17 = call i1 @llvm.is.constant.i32(i32 %_18)
  br i1 %_17, label %bb14, label %bb26

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 1, ptr %10, align 16
  store i128 1, ptr %_0, align 16
  br label %bb37

bb26:                                             ; preds = %bb36, %bb12
  %_39 = load i32, ptr %exp, align 4
  %_38 = and i32 %_39, 1
  %_37 = icmp eq i32 %_38, 1
  br i1 %_37, label %bb27, label %bb32

bb14:                                             ; preds = %bb24, %bb12
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp ugt i32 %_20, 1
  br i1 %_19, label %bb15, label %bb25

bb32:                                             ; preds = %bb30, %bb26
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_50 = load i128, ptr %base, align 16
  %_51 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_49, i128 %_50, i128 %_51) #17
  %13 = load i128, ptr %_49, align 16
  %14 = getelementptr inbounds i8, ptr %_49, i64 16
  %15 = load i128, ptr %14, align 16
  %_52 = trunc i128 %13 to i64
  %16 = trunc nuw i64 %_52 to i1
  br i1 %16, label %bb36, label %bb35

bb27:                                             ; preds = %bb26
  %_41 = load i128, ptr %acc, align 16
  %_42 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_40, i128 %_41, i128 %_42) #17
  %17 = load i128, ptr %_40, align 16
  %18 = getelementptr inbounds i8, ptr %_40, i64 16
  %19 = load i128, ptr %18, align 16
  %_43 = trunc i128 %17 to i64
  %20 = trunc nuw i64 %_43 to i1
  br i1 %20, label %bb30, label %bb29

bb30:                                             ; preds = %bb27
  %21 = getelementptr inbounds i8, ptr %_40, i64 16
  %x = load i128, ptr %21, align 16
  store i128 %x, ptr %acc, align 16
  %_46 = load i32, ptr %exp, align 4
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb31, label %bb32

bb29:                                             ; preds = %bb27
  store i128 0, ptr %_0, align 16
  br label %bb37

bb37:                                             ; preds = %bb9, %bb8, %bb11, %bb23, %bb18, %bb25, %bb31, %bb35, %bb29
  ret void

bb31:                                             ; preds = %bb30
  %_47 = load i128, ptr %acc, align 16
  %22 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_47, ptr %22, align 16
  store i128 1, ptr %_0, align 16
  br label %bb37

bb36:                                             ; preds = %bb32
  %23 = getelementptr inbounds i8, ptr %_49, i64 16
  %x1 = load i128, ptr %23, align 16
  store i128 %x1, ptr %base, align 16
  br label %bb26

bb35:                                             ; preds = %bb32
  store i128 0, ptr %_0, align 16
  br label %bb37

bb25:                                             ; preds = %bb14
  %_35 = load i128, ptr %acc, align 16
  %_36 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 %_35, i128 %_36) #17
  br label %bb37

bb15:                                             ; preds = %bb14
  %_23 = load i32, ptr %exp, align 4
  %_22 = and i32 %_23, 1
  %_21 = icmp eq i32 %_22, 1
  br i1 %_21, label %bb16, label %bb20

bb20:                                             ; preds = %bb19, %bb15
  %24 = load i32, ptr %exp, align 4
  %25 = udiv i32 %24, 2
  store i32 %25, ptr %exp, align 4
  %_31 = load i128, ptr %base, align 16
  %_32 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_30, i128 %_31, i128 %_32) #17
  %26 = load i128, ptr %_30, align 16
  %27 = getelementptr inbounds i8, ptr %_30, i64 16
  %28 = load i128, ptr %27, align 16
  %_33 = trunc i128 %26 to i64
  %29 = trunc nuw i64 %_33 to i1
  br i1 %29, label %bb24, label %bb23

bb16:                                             ; preds = %bb15
  %_25 = load i128, ptr %acc, align 16
  %_26 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_24, i128 %_25, i128 %_26) #17
  %30 = load i128, ptr %_24, align 16
  %31 = getelementptr inbounds i8, ptr %_24, i64 16
  %32 = load i128, ptr %31, align 16
  %_27 = trunc i128 %30 to i64
  %33 = trunc nuw i64 %_27 to i1
  br i1 %33, label %bb19, label %bb18

bb19:                                             ; preds = %bb16
  %34 = getelementptr inbounds i8, ptr %_24, i64 16
  %x2 = load i128, ptr %34, align 16
  store i128 %x2, ptr %acc, align 16
  br label %bb20

bb18:                                             ; preds = %bb16
  store i128 0, ptr %_0, align 16
  br label %bb37

bb24:                                             ; preds = %bb20
  %35 = getelementptr inbounds i8, ptr %_30, i64 16
  %x3 = load i128, ptr %35, align 16
  store i128 %x3, ptr %base, align 16
  br label %bb14

bb23:                                             ; preds = %bb20
  store i128 0, ptr %_0, align 16
  br label %bb37

bb9:                                              ; preds = %bb4
  %36 = getelementptr inbounds i8, ptr %_11, i64 4
  %shift = load i32, ptr %36, align 4
; call <u128>::checked_shl
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_shlCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 1, i32 %shift) #17
  br label %bb37

bb8:                                              ; preds = %bb4
  store i128 0, ptr %_0, align 16
  br label %bb37

bb7:                                              ; No predecessors!
  unreachable
}

; <u128>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_remCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !118 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = icmp eq i128 %rhs, 0
  br i1 %_4, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_5 = urem i128 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5, ptr %2, align 16
  store i128 1, ptr %_0, align 16
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void
}

; <u128>::checked_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_shlCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %rhs) unnamed_addr #0 !guid !119 {
start:
  %_3 = icmp ult i32 %rhs, 128
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb4

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u128>::unchecked_shl::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i32 %rhs, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i128
  %_0.i = shl i128 %self, %0
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_0.i, ptr %1, align 16
  store i128 1, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit, %bb3
  ret void
}

; <u128>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_subCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !120 {
start:
  %_3 = icmp ult i128 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i128 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_4, ptr %0, align 16
  store i128 1, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  ret void
}

; <u128>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo12wrapping_powCsfP1CzEAVZUO_12int_ops_u128(i128 %self, i32 %exp) unnamed_addr #0 !guid !121 {
start:
  %0 = alloca [32 x i8], align 16
; call <u128>::overflowing_pow
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo15overflowing_powCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %0, i128 %self, i32 %exp) #17
  %_3.0 = load i128, ptr %0, align 16
  %1 = getelementptr inbounds i8, ptr %0, i64 16
  %2 = load i8, ptr %1, align 16
  %_3.1 = trunc nuw i8 %2 to i1
  ret i128 %_3.0
}

; <u128>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13checked_ilog2CsfP1CzEAVZUO_12int_ops_u128(i128 %self) unnamed_addr #0 !guid !122 {
start:
  %_2 = alloca [16 x i8], align 16
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u128>>::new
  %0 = call i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3newB9_(i128 %self) #17
  store i128 %0, ptr %_2, align 16
  %1 = load i128, ptr %_2, align 16
  %2 = icmp eq i128 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i128, ptr %_2, align 16
; call <core::num::nonzero::NonZero<u128>>::ilog2
  %_5 = call i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE5ilog2CsfP1CzEAVZUO_12int_ops_u128(i128 %x) #17
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u128>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unbounded_shlCsfP1CzEAVZUO_12int_ops_u128(i128 %self, i32 %rhs) unnamed_addr #0 !guid !123 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp ult i32 %rhs, 128
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u128>::unchecked_shl::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i32 %rhs, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i128
  %_0.i = shl i128 %self, %0
  store i128 %_0.i, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit, %bb2
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; <u128>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo15overflowing_powCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !124 {
start:
  %1 = alloca [32 x i8], align 16
  %2 = alloca [32 x i8], align 16
  %3 = alloca [32 x i8], align 16
  %4 = alloca [32 x i8], align 16
  %5 = alloca [32 x i8], align 16
  %_14 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  store i8 0, ptr %overflow, align 1
  %_8 = load i128, ptr %base, align 16
  %_7 = call i1 @llvm.is.constant.i128(i128 %_8)
  br i1 %_7, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp eq i32 %_20, 0
  br i1 %_19, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_10 = load i128, ptr %base, align 16
  %6 = call i128 @llvm.ctpop.i128(i128 %_10)
  %_0.i.i = trunc i128 %6 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_12 = load i128, ptr %base, align 16
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2CsfP1CzEAVZUO_12int_ops_u128(i128 %_12, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #17
  %_15 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %7 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsfP1CzEAVZUO_12int_ops_u128(i32 %k, i32 %_15) #17
  %8 = extractvalue { i32, i32 } %7, 0
  %9 = extractvalue { i32, i32 } %7, 1
  store i32 %8, ptr %_14, align 4
  %10 = getelementptr inbounds i8, ptr %_14, i64 4
  store i32 %9, ptr %10, align 4
  %11 = load i32, ptr %_14, align 4
  %12 = getelementptr inbounds i8, ptr %_14, i64 4
  %13 = load i32, ptr %12, align 4
  %_16 = zext i32 %11 to i64
  %14 = trunc nuw i64 %_16 to i1
  br i1 %14, label %bb7, label %bb8

bb12:                                             ; preds = %bb10
  %_22 = load i32, ptr %exp, align 4
  %_21 = call i1 @llvm.is.constant.i32(i32 %_22)
  br i1 %_21, label %bb14, label %bb23

bb11:                                             ; preds = %bb10
  store i128 1, ptr %_0, align 16
  %15 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 0, ptr %15, align 16
  br label %bb30

bb23:                                             ; preds = %bb27, %bb12
  %_51 = load i32, ptr %exp, align 4
  %_50 = and i32 %_51, 1
  %_49 = icmp eq i32 %_50, 1
  br i1 %_49, label %bb24, label %bb27

bb14:                                             ; preds = %bb18, %bb12
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp ugt i32 %_24, 1
  br i1 %_23, label %bb15, label %bb21

bb27:                                             ; preds = %bb24, %bb23
  %16 = load i32, ptr %exp, align 4
  %17 = udiv i32 %16, 2
  store i32 %17, ptr %exp, align 4
  %_66 = load i128, ptr %base, align 16
  %_67 = load i128, ptr %base, align 16
  %18 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_66, i128 %_67)
  %_5.0.i5 = extractvalue { i128, i1 } %18, 0
  %_5.1.i6 = extractvalue { i128, i1 } %18, 1
  store i128 %_5.0.i5, ptr %4, align 16
  %19 = getelementptr inbounds i8, ptr %4, i64 16
  %20 = zext i1 %_5.1.i6 to i8
  store i8 %20, ptr %19, align 16
  %_65.0 = load i128, ptr %4, align 16
  %21 = getelementptr inbounds i8, ptr %4, i64 16
  %22 = load i8, ptr %21, align 16
  %_65.1 = trunc nuw i8 %22 to i1
  store i128 %_65.0, ptr %base, align 16
  %23 = zext i1 %_65.1 to i8
  store i8 %23, ptr %tmp_overflow, align 1
  %24 = load i8, ptr %tmp_overflow, align 1
  %_68 = trunc nuw i8 %24 to i1
  %25 = load i8, ptr %overflow, align 1
  %26 = trunc nuw i8 %25 to i1
  %27 = or i1 %26, %_68
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %overflow, align 1
  br label %bb23

bb24:                                             ; preds = %bb23
  %_55 = load i128, ptr %acc, align 16
  %_56 = load i128, ptr %base, align 16
  %29 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_55, i128 %_56)
  %_5.0.i7 = extractvalue { i128, i1 } %29, 0
  %_5.1.i8 = extractvalue { i128, i1 } %29, 1
  store i128 %_5.0.i7, ptr %5, align 16
  %30 = getelementptr inbounds i8, ptr %5, i64 16
  %31 = zext i1 %_5.1.i8 to i8
  store i8 %31, ptr %30, align 16
  %_54.0 = load i128, ptr %5, align 16
  %32 = getelementptr inbounds i8, ptr %5, i64 16
  %33 = load i8, ptr %32, align 16
  %_54.1 = trunc nuw i8 %33 to i1
  store i128 %_54.0, ptr %acc, align 16
  %34 = zext i1 %_54.1 to i8
  store i8 %34, ptr %tmp_overflow, align 1
  %35 = load i8, ptr %tmp_overflow, align 1
  %_57 = trunc nuw i8 %35 to i1
  %36 = load i8, ptr %overflow, align 1
  %37 = trunc nuw i8 %36 to i1
  %38 = or i1 %37, %_57
  %39 = zext i1 %38 to i8
  store i8 %39, ptr %overflow, align 1
  %_59 = load i32, ptr %exp, align 4
  %_58 = icmp eq i32 %_59, 1
  br i1 %_58, label %bb26, label %bb27

bb26:                                             ; preds = %bb24
  %_60 = load i128, ptr %acc, align 16
  %40 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %40 to i1
  store i128 %_60, ptr %_0, align 16
  %41 = getelementptr inbounds i8, ptr %_0, i64 16
  %42 = zext i1 %_61 to i8
  store i8 %42, ptr %41, align 16
  br label %bb30

bb30:                                             ; preds = %bb8, %bb7, %bb11, %bb21, %bb26
  ret void

bb21:                                             ; preds = %bb14
  %_44 = load i128, ptr %acc, align 16
  %_45 = load i128, ptr %base, align 16
  %43 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_44, i128 %_45)
  %_5.0.i3 = extractvalue { i128, i1 } %43, 0
  %_5.1.i4 = extractvalue { i128, i1 } %43, 1
  store i128 %_5.0.i3, ptr %3, align 16
  %44 = getelementptr inbounds i8, ptr %3, i64 16
  %45 = zext i1 %_5.1.i4 to i8
  store i8 %45, ptr %44, align 16
  %_43.0 = load i128, ptr %3, align 16
  %46 = getelementptr inbounds i8, ptr %3, i64 16
  %47 = load i8, ptr %46, align 16
  %_43.1 = trunc nuw i8 %47 to i1
  store i128 %_43.0, ptr %acc, align 16
  %48 = zext i1 %_43.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_46
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  %_47 = load i128, ptr %acc, align 16
  %54 = load i8, ptr %overflow, align 1
  %_48 = trunc nuw i8 %54 to i1
  store i128 %_47, ptr %_0, align 16
  %55 = getelementptr inbounds i8, ptr %_0, i64 16
  %56 = zext i1 %_48 to i8
  store i8 %56, ptr %55, align 16
  br label %bb30

bb15:                                             ; preds = %bb14
  %_27 = load i32, ptr %exp, align 4
  %_26 = and i32 %_27, 1
  %_25 = icmp eq i32 %_26, 1
  br i1 %_25, label %bb16, label %bb18

bb18:                                             ; preds = %bb16, %bb15
  %57 = load i32, ptr %exp, align 4
  %58 = udiv i32 %57, 2
  store i32 %58, ptr %exp, align 4
  %_38 = load i128, ptr %base, align 16
  %_39 = load i128, ptr %base, align 16
  %59 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_38, i128 %_39)
  %_5.0.i = extractvalue { i128, i1 } %59, 0
  %_5.1.i = extractvalue { i128, i1 } %59, 1
  store i128 %_5.0.i, ptr %1, align 16
  %60 = getelementptr inbounds i8, ptr %1, i64 16
  %61 = zext i1 %_5.1.i to i8
  store i8 %61, ptr %60, align 16
  %_37.0 = load i128, ptr %1, align 16
  %62 = getelementptr inbounds i8, ptr %1, i64 16
  %63 = load i8, ptr %62, align 16
  %_37.1 = trunc nuw i8 %63 to i1
  store i128 %_37.0, ptr %base, align 16
  %64 = zext i1 %_37.1 to i8
  store i8 %64, ptr %tmp_overflow, align 1
  %65 = load i8, ptr %tmp_overflow, align 1
  %_40 = trunc nuw i8 %65 to i1
  %66 = load i8, ptr %overflow, align 1
  %67 = trunc nuw i8 %66 to i1
  %68 = or i1 %67, %_40
  %69 = zext i1 %68 to i8
  store i8 %69, ptr %overflow, align 1
  br label %bb14

bb16:                                             ; preds = %bb15
  %_31 = load i128, ptr %acc, align 16
  %_32 = load i128, ptr %base, align 16
  %70 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_31, i128 %_32)
  %_5.0.i1 = extractvalue { i128, i1 } %70, 0
  %_5.1.i2 = extractvalue { i128, i1 } %70, 1
  store i128 %_5.0.i1, ptr %2, align 16
  %71 = getelementptr inbounds i8, ptr %2, i64 16
  %72 = zext i1 %_5.1.i2 to i8
  store i8 %72, ptr %71, align 16
  %_30.0 = load i128, ptr %2, align 16
  %73 = getelementptr inbounds i8, ptr %2, i64 16
  %74 = load i8, ptr %73, align 16
  %_30.1 = trunc nuw i8 %74 to i1
  store i128 %_30.0, ptr %acc, align 16
  %75 = zext i1 %_30.1 to i8
  store i8 %75, ptr %tmp_overflow, align 1
  %76 = load i8, ptr %tmp_overflow, align 1
  %_33 = trunc nuw i8 %76 to i1
  %77 = load i8, ptr %overflow, align 1
  %78 = trunc nuw i8 %77 to i1
  %79 = or i1 %78, %_33
  %80 = zext i1 %79 to i8
  store i8 %80, ptr %overflow, align 1
  br label %bb18

bb7:                                              ; preds = %bb4
  %81 = getelementptr inbounds i8, ptr %_14, i64 4
  %shift = load i32, ptr %81, align 4
; call <u128>::unbounded_shl
  %_17 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unbounded_shlCsfP1CzEAVZUO_12int_ops_u128(i128 1, i32 %shift) #17
  %_18 = icmp uge i32 %shift, 128
  store i128 %_17, ptr %_0, align 16
  %82 = getelementptr inbounds i8, ptr %_0, i64 16
  %83 = zext i1 %_18 to i8
  store i8 %83, ptr %82, align 16
  br label %bb30

bb8:                                              ; preds = %bb4
  store i128 0, ptr %_0, align 16
  %84 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 1, ptr %84, align 16
  br label %bb30

bb31:                                             ; No predecessors!
  unreachable
}

; <u128>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCsfP1CzEAVZUO_12int_ops_u128(i128 %self, i32 %exp) unnamed_addr #0 !guid !125 {
start:
  %_0 = alloca [16 x i8], align 16
  br label %bb1

bb1:                                              ; preds = %start
; call <u128>::strict_pow
  %0 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo10strict_powCsfP1CzEAVZUO_12int_ops_u128(i128 %self, i32 %exp, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #17
  store i128 %0, ptr %_0, align 16
  br label %bb3

bb2:                                              ; No predecessors!
; call <u128>::wrapping_pow
  %1 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo12wrapping_powCsfP1CzEAVZUO_12int_ops_u128(i128 %self, i32 %exp) #17
  store i128 %1, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i128, ptr %_0, align 16
  ret i128 %2
}

; <u128>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2CsfP1CzEAVZUO_12int_ops_u128(i128 %self, ptr align 8 %0) unnamed_addr #0 !guid !126 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u128>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13checked_ilog2CsfP1CzEAVZUO_12int_ops_u128(i128 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u128>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5isqrtCsfP1CzEAVZUO_12int_ops_u128(i128 %self) unnamed_addr #0 !guid !127 {
start:
; call core::num::imp::int_sqrt::u128
  %result = call i128 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt4u128CsfP1CzEAVZUO_12int_ops_u128(i128 %self) #17
  %_3 = icmp ule i128 %result, 18446744073709551615
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_3, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i128 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u128>::unchecked_mul::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i128 %result, i128 %result, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i128 %result, %result
  %_8 = icmp ule i128 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_8, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i128 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_11, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i128 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i128 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_6, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <u128>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo8abs_diffCsfP1CzEAVZUO_12int_ops_u128(i128 %self, i128 %other) unnamed_addr #0 !guid !128 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp eq i64 16, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i128 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i128 %self to i32
  %_8 = trunc i128 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsfP1CzEAVZUO_12int_ops_u128(i32 %_0.i) #17
  %0 = zext i32 %_5 to i128
  store i128 %0, ptr %_0, align 16
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i128 %self, %other
  store i128 %1, ptr %_0, align 16
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i128 %other, %self
  store i128 %2, ptr %_0, align 16
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i128, ptr %_0, align 16
  ret i128 %3
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsfP1CzEAVZUO_12int_ops_u128(ptr %self) unnamed_addr #0 !guid !129 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <u128>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo14from_str_radixCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !130 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <u128>::from_ascii_bytes_radix_impl
  call void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo27from_ascii_bytes_radix_implCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #17
  ret void
}

; <u128>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo27from_ascii_bytes_radix_implCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !131 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [32 x i8], align 16
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [32 x i8], align 16
  %_74 = alloca [32 x i8], align 16
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [32 x i8], align 16
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [16 x i8], align 16
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_5aa1d1250638a5285856df0c8e3018a3) #23
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #17
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb11, %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb9

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !132
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i128 0, ptr %result, align 16
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECsfP1CzEAVZUO_12int_ops_u128.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 32
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECsfP1CzEAVZUO_12int_ops_u128.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECsfP1CzEAVZUO_12int_ops_u128.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; No predecessors!
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECsfP1CzEAVZUO_12int_ops_u128.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECsfP1CzEAVZUO_12int_ops_u128.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i128, ptr %result, align 16
  %33 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_105, ptr %33, align 16
  store i8 0, ptr %_0, align 16
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i128, ptr %result, align 16
  %_86 = zext i32 %radix to i128
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %mul1, i128 %_85, i128 %_86) #17
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %40 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsfP1CzEAVZUO_12int_ops_u128(i32 %_89, i32 %radix) #17
  %41 = extractvalue { i32, i32 } %40, 0
  %42 = extractvalue { i32, i32 } %40, 1
  store i32 %41, ptr %_88, align 4
  %43 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %42, ptr %43, align 4
  %44 = load i32, ptr %_88, align 4
  %45 = getelementptr inbounds i8, ptr %_88, i64 4
  %46 = load i32, ptr %45, align 4
  %_91 = zext i32 %44 to i64
  %47 = trunc nuw i64 %_91 to i1
  br i1 %47, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %48, align 4
  %x = zext i32 %value to i128
  %49 = load i128, ptr %mul1, align 16
  %50 = getelementptr inbounds i8, ptr %mul1, i64 16
  %51 = load i128, ptr %50, align 16
  %_95 = trunc i128 %49 to i64
  %52 = trunc nuw i64 %_95 to i1
  br i1 %52, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %53, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb48:                                             ; preds = %bb46
  %54 = getelementptr inbounds i8, ptr %mul1, i64 16
  %value4 = load i128, ptr %54, align 16
  store i128 %value4, ptr %result, align 16
  %_100 = load i128, ptr %result, align 16
; call <u128>::checked_sub
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_subCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_99, i128 %_100, i128 %x) #17
  %55 = load i128, ptr %_99, align 16
  %56 = getelementptr inbounds i8, ptr %_99, i64 16
  %57 = load i128, ptr %56, align 16
  %_101 = trunc i128 %55 to i64
  %58 = trunc nuw i64 %_101 to i1
  br i1 %58, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %59, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb51:                                             ; preds = %bb48
  %60 = getelementptr inbounds i8, ptr %_99, i64 16
  %value5 = load i128, ptr %60, align 16
  store i128 %value5, ptr %result, align 16
  store ptr %rest.02, ptr %digits, align 8, !captures !132
  %61 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %61, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %62 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %62, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb31:                                             ; preds = %bb30
  %63 = load ptr, ptr %digits, align 8
  %64 = getelementptr inbounds i8, ptr %digits, i64 8
  %65 = load i64, ptr %64, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %63, i64 0
  %66 = load ptr, ptr %digits, align 8
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  %68 = load i64, ptr %67, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %66, i64 1
  %rest.18 = sub i64 %68, 1
  %_60 = load i128, ptr %result, align 16
  %_61 = zext i32 %radix to i128
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %mul, i128 %_60, i128 %_61) #17
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %69 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsfP1CzEAVZUO_12int_ops_u128(i32 %_64, i32 %radix) #17
  %70 = extractvalue { i32, i32 } %69, 0
  %71 = extractvalue { i32, i32 } %69, 1
  store i32 %70, ptr %_63, align 4
  %72 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %71, ptr %72, align 4
  %73 = load i32, ptr %_63, align 4
  %74 = getelementptr inbounds i8, ptr %_63, i64 4
  %75 = load i32, ptr %74, align 4
  %_66 = zext i32 %73 to i64
  %76 = trunc nuw i64 %_66 to i1
  br i1 %76, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %77 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %77, align 4
  %x10 = zext i32 %value9 to i128
  %78 = load i128, ptr %mul, align 16
  %79 = getelementptr inbounds i8, ptr %mul, i64 16
  %80 = load i128, ptr %79, align 16
  %_70 = trunc i128 %78 to i64
  %81 = trunc nuw i64 %_70 to i1
  br i1 %81, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %82 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %82, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb37:                                             ; preds = %bb35
  %83 = getelementptr inbounds i8, ptr %mul, i64 16
  %value11 = load i128, ptr %83, align 16
  store i128 %value11, ptr %result, align 16
  %_75 = load i128, ptr %result, align 16
; call <u128>::checked_add
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_74, i128 %_75, i128 %x10) #17
  %84 = load i128, ptr %_74, align 16
  %85 = getelementptr inbounds i8, ptr %_74, i64 16
  %86 = load i128, ptr %85, align 16
  %_76 = trunc i128 %84 to i64
  %87 = trunc nuw i64 %_76 to i1
  br i1 %87, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %88 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %88, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb40:                                             ; preds = %bb37
  %89 = getelementptr inbounds i8, ptr %_74, i64 16
  %value12 = load i128, ptr %89, align 16
  store i128 %value12, ptr %result, align 16
  store ptr %rest.07, ptr %digits, align 8, !captures !132
  %90 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %90, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %91, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %92 = load ptr, ptr %digits, align 8
  %93 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %93, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %94 = load ptr, ptr %digits, align 8
  %95 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %95, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %96 = load ptr, ptr %digits, align 8
  %97 = getelementptr inbounds i8, ptr %digits, i64 8
  %98 = load i64, ptr %97, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %96, i64 0
  %99 = load ptr, ptr %digits, align 8
  %100 = getelementptr inbounds i8, ptr %digits, i64 8
  %101 = load i64, ptr %100, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %99, i64 1
  %rest.115 = sub i64 %101, 1
  %_44 = load i128, ptr %result, align 16
  %_45 = zext i32 %radix to i128
  %102 = mul i128 %_44, %_45
  store i128 %102, ptr %result, align 16
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %103 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsfP1CzEAVZUO_12int_ops_u128(i32 %_47, i32 %radix) #17
  %104 = extractvalue { i32, i32 } %103, 0
  %105 = extractvalue { i32, i32 } %103, 1
  store i32 %104, ptr %_46, align 4
  %106 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %105, ptr %106, align 4
  %107 = load i32, ptr %_46, align 4
  %108 = getelementptr inbounds i8, ptr %_46, i64 4
  %109 = load i32, ptr %108, align 4
  %_49 = zext i32 %107 to i64
  %110 = trunc nuw i64 %_49 to i1
  br i1 %110, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %111 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %111, align 4
  %_53 = load i128, ptr %result, align 16
  %_54 = zext i32 %x16 to i128
  %112 = sub i128 %_53, %_54
  store i128 %112, ptr %result, align 16
  store ptr %rest.014, ptr %digits, align 8, !captures !132
  %113 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %113, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %114 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %114, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb19:                                             ; preds = %bb18
  %115 = load ptr, ptr %digits, align 8
  %116 = getelementptr inbounds i8, ptr %digits, i64 8
  %117 = load i64, ptr %116, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %115, i64 0
  %118 = load ptr, ptr %digits, align 8
  %119 = getelementptr inbounds i8, ptr %digits, i64 8
  %120 = load i64, ptr %119, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %118, i64 1
  %rest.119 = sub i64 %120, 1
  %_29 = load i128, ptr %result, align 16
  %_30 = zext i32 %radix to i128
  %121 = mul i128 %_29, %_30
  store i128 %121, ptr %result, align 16
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %122 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsfP1CzEAVZUO_12int_ops_u128(i32 %_32, i32 %radix) #17
  %123 = extractvalue { i32, i32 } %122, 0
  %124 = extractvalue { i32, i32 } %122, 1
  store i32 %123, ptr %_31, align 4
  %125 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %124, ptr %125, align 4
  %126 = load i32, ptr %_31, align 4
  %127 = getelementptr inbounds i8, ptr %_31, i64 4
  %128 = load i32, ptr %127, align 4
  %_34 = zext i32 %126 to i64
  %129 = trunc nuw i64 %_34 to i1
  br i1 %129, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %130 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %130, align 4
  %_38 = load i128, ptr %result, align 16
  %_39 = zext i32 %x20 to i128
  %131 = add i128 %_38, %_39
  store i128 %131, ptr %result, align 16
  store ptr %rest.018, ptr %digits, align 8, !captures !132
  %132 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %132, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %133 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %133, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsfP1CzEAVZUO_12int_ops_u128(i8 %0) unnamed_addr #0 !guid !133 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsfP1CzEAVZUO_12int_ops_u128(ptr %self) #17
  ret i32 %_0
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsfP1CzEAVZUO_12int_ops_u128(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !134 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %args) #17
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #17
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsfP1CzEAVZUO_12int_ops_u128() unnamed_addr #4 !guid !135 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() unnamed_addr #0 !guid !136 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsfP1CzEAVZUO_12int_ops_u128(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !137 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::num::imp::int_sqrt::u16_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsfP1CzEAVZUO_12int_ops_u128(i16 %n) unnamed_addr #0 !guid !138 {
start:
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n1 = lshr i16 %n, 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.c315984353131a6bca32d403680bc46d.0, i64 512, i1 false)
  %_9 = zext i16 %n1 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s2 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s2, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_12, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb1, %bb2.i
  %lo = and i16 %n, 255
  %_16 = zext i8 %r to i16
  %_15 = shl i16 %_16, 4
  %_17 = lshr i16 %lo, 4
  %numerator = or i16 %_15, %_17
  %_19 = zext i8 %s2 to i16
  %denominator = shl i16 %_19, 1
  %_21 = icmp eq i16 %denominator, 0
  br i1 %_21, label %panic3, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q = udiv i16 %numerator, %denominator
  %_24 = shl i8 %s2, 4
  %_23 = zext i8 %_24 to i16
  %3 = add i16 %_23, %q
  store i16 %3, ptr %s, align 2
  %_28 = load i16, ptr %s, align 2
  %_29 = load i16, ptr %s, align 2
  %4 = call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %_28, i16 %_29)
  %_5.0.i = extractvalue { i16, i1 } %4, 0
  %_5.1.i = extractvalue { i16, i1 } %4, 1
  %_27.0 = extractvalue { i16, i1 } %4, 0
  %_27.1 = extractvalue { i16, i1 } %4, 1
  br i1 %_27.1, label %bb6, label %bb5

panic3:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_73a63def61abd19c5b285b7e5bba6f74) #23
  unreachable

bb5:                                              ; preds = %bb3
  %_30 = icmp ugt i16 %_27.0, %n
  br i1 %_30, label %bb6, label %bb7

bb6:                                              ; preds = %bb5, %bb3
  %5 = load i16, ptr %s, align 2
  %6 = sub i16 %5, 1
  store i16 %6, ptr %s, align 2
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5
  %_0 = load i16, ptr %s, align 2
  ret i16 %_0
}

; core::num::imp::int_sqrt::u32_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsfP1CzEAVZUO_12int_ops_u128(i32 %n) unnamed_addr #0 !guid !139 {
start:
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n2 = lshr i32 %n, 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.c315984353131a6bca32d403680bc46d.0, i64 512, i1 false)
  %_9 = zext i32 %n2 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s3 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r4 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s3, 0
; call core::ub_checks::check_language_ub
  %_2.i15 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i15, label %bb2.i16, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

bb2.i16:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_12, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17: ; preds = %bb1, %bb2.i16
  %_17 = lshr i32 %n, 16
  %n5 = trunc i32 %_17 to i16
  %lo = and i16 %n5, 255
  %_21 = zext i8 %r4 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s3 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic6, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic7, label %bb4

panic6:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s3, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic7:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_45, ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb8, %bb2.i
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %lo8 = and i32 %n, 65535
  %_52 = zext i16 %_48 to i32
  %_51 = shl i32 %_52, 8
  %_53 = lshr i32 %lo8, 8
  %numerator9 = or i32 %_51, %_53
  %_55 = zext i16 %_47 to i32
  %denominator10 = shl i32 %_55, 1
  %_57 = icmp eq i32 %denominator10, 0
  br i1 %_57, label %panic11, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q12 = udiv i32 %numerator9, %denominator10
  %_60 = shl i16 %_47, 8
  %_59 = zext i16 %_60 to i32
  %8 = add i32 %_59, %q12
  store i32 %8, ptr %s1, align 4
  %_64 = load i32, ptr %s1, align 4
  %_65 = load i32, ptr %s1, align 4
  %9 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_64, i32 %_65)
  %_5.0.i13 = extractvalue { i32, i1 } %9, 0
  %_5.1.i14 = extractvalue { i32, i1 } %9, 1
  %_63.0 = extractvalue { i32, i1 } %9, 0
  %_63.1 = extractvalue { i32, i1 } %9, 1
  br i1 %_63.1, label %bb13, label %bb12

panic11:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_d1e64d3a180065bd6a022925cad00717) #23
  unreachable

bb12:                                             ; preds = %bb10
  %_66 = icmp ugt i32 %_63.0, %n
  br i1 %_66, label %bb13, label %bb14

bb13:                                             ; preds = %bb12, %bb10
  %10 = load i32, ptr %s1, align 4
  %11 = sub i32 %10, 1
  store i32 %11, ptr %s1, align 4
  br label %bb14

bb14:                                             ; preds = %bb13, %bb12
  %_0 = load i32, ptr %s1, align 4
  ret i32 %_0
}

; core::num::imp::int_sqrt::u64_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCsfP1CzEAVZUO_12int_ops_u128(i64 %n) unnamed_addr #0 !guid !140 {
start:
  %s3 = alloca [8 x i8], align 8
  %r2 = alloca [4 x i8], align 4
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n4 = lshr i64 %n, 56
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.c315984353131a6bca32d403680bc46d.0, i64 512, i1 false)
  %_10 = icmp ult i64 %n4, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %s5 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r6 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s5, 0
; call core::ub_checks::check_language_ub
  %_2.i31 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i31, label %bb2.i32, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

bb2.i32:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_12, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33: ; preds = %bb1, %bb2.i32
  %_17 = lshr i64 %n, 48
  %n7 = trunc i64 %_17 to i16
  %lo = and i16 %n7, 255
  %_21 = zext i8 %r6 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s5 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic8, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %n4, i64 256, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic9, label %bb4

panic8:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s5, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic9:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i28 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i28, label %bb2.i29, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

bb2.i29:                                          ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_45, ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30: ; preds = %bb8, %bb2.i29
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %_53 = lshr i64 %n, 32
  %n10 = trunc i64 %_53 to i32
  %lo11 = and i32 %n10, 65535
  %_57 = zext i16 %_48 to i32
  %_56 = shl i32 %_57, 8
  %_58 = lshr i32 %lo11, 8
  %numerator12 = or i32 %_56, %_58
  %_60 = zext i16 %_47 to i32
  %denominator13 = shl i32 %_60, 1
  %_62 = icmp eq i32 %denominator13, 0
  br i1 %_62, label %panic14, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
  %q15 = udiv i32 %numerator12, %denominator13
  %_64 = icmp eq i32 %denominator13, 0
  br i1 %_64, label %panic16, label %bb11

panic14:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #23
  unreachable

bb11:                                             ; preds = %bb10
  %u17 = urem i32 %numerator12, %denominator13
  %_67 = shl i16 %_47, 8
  %_66 = zext i16 %_67 to i32
  %8 = add i32 %_66, %q15
  store i32 %8, ptr %s1, align 4
  %_72 = shl i32 %u17, 8
  %_73 = and i32 %lo11, 255
  %_71 = or i32 %_72, %_73
  %_74 = mul i32 %q15, %q15
  %_5.0.i24 = sub i32 %_71, %_74
  %_5.1.i25 = icmp ult i32 %_71, %_74
  %9 = insertvalue { i32, i1 } poison, i32 %_5.0.i24, 0
  %10 = insertvalue { i32, i1 } %9, i1 %_5.1.i25, 1
  %_70.0 = extractvalue { i32, i1 } %10, 0
  %_70.1 = extractvalue { i32, i1 } %10, 1
  store i32 %_70.0, ptr %r2, align 4
  br i1 %_70.1, label %bb13, label %bb15

panic16:                                          ; preds = %bb10
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #23
  unreachable

bb15:                                             ; preds = %bb13, %bb11
  %_82 = load i32, ptr %s1, align 4
  %_81 = icmp ne i32 %_82, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb15
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_81, ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb15, %bb2.i
  %_83 = load i32, ptr %s1, align 4
  %_84 = load i32, ptr %r2, align 4
  %lo18 = and i64 %n, 4294967295
  %_88 = zext i32 %_84 to i64
  %_87 = shl i64 %_88, 16
  %_89 = lshr i64 %lo18, 16
  %numerator19 = or i64 %_87, %_89
  %_91 = zext i32 %_83 to i64
  %denominator20 = shl i64 %_91, 1
  %_93 = icmp eq i64 %denominator20, 0
  br i1 %_93, label %panic21, label %bb17

bb13:                                             ; preds = %bb11
  %_76 = load i32, ptr %r2, align 4
  %_79 = load i32, ptr %s1, align 4
  %_78 = mul i32 2, %_79
  %_77 = sub i32 %_78, 1
  %_0.i23 = add i32 %_76, %_77
  store i32 %_0.i23, ptr %r2, align 4
  %11 = load i32, ptr %s1, align 4
  %12 = sub i32 %11, 1
  store i32 %12, ptr %s1, align 4
  br label %bb15

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q22 = udiv i64 %numerator19, %denominator20
  %_96 = shl i32 %_83, 16
  %_95 = zext i32 %_96 to i64
  %13 = add i64 %_95, %q22
  store i64 %13, ptr %s3, align 8
  %_100 = load i64, ptr %s3, align 8
  %_101 = load i64, ptr %s3, align 8
  %14 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_100, i64 %_101)
  %_5.0.i26 = extractvalue { i64, i1 } %14, 0
  %_5.1.i27 = extractvalue { i64, i1 } %14, 1
  %_99.0 = extractvalue { i64, i1 } %14, 0
  %_99.1 = extractvalue { i64, i1 } %14, 1
  br i1 %_99.1, label %bb20, label %bb19

panic21:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cb646754bd05cd238e749888201337e6) #23
  unreachable

bb19:                                             ; preds = %bb17
  %_102 = icmp ugt i64 %_99.0, %n
  br i1 %_102, label %bb20, label %bb21

bb20:                                             ; preds = %bb19, %bb17
  %15 = load i64, ptr %s3, align 8
  %16 = sub i64 %15, 1
  store i64 %16, ptr %s3, align 8
  br label %bb21

bb21:                                             ; preds = %bb20, %bb19
  %_0 = load i64, ptr %s3, align 8
  ret i64 %_0
}

; core::num::imp::int_sqrt::u128_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt11u128_stagesCsfP1CzEAVZUO_12int_ops_u128(i128 %n) unnamed_addr #0 !guid !141 {
start:
  %0 = alloca [32 x i8], align 16
  %s5 = alloca [16 x i8], align 16
  %r4 = alloca [8 x i8], align 8
  %s3 = alloca [8 x i8], align 8
  %r2 = alloca [4 x i8], align 4
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n6 = lshr i128 %n, 120
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.c315984353131a6bca32d403680bc46d.0, i64 512, i1 false)
  %_9 = trunc i128 %n6 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s7 = load i8, ptr %1, align 1
  %2 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %3 = getelementptr inbounds i8, ptr %2, i64 1
  %r8 = load i8, ptr %3, align 1
  %_12 = icmp ne i8 %s7, 0
; call core::ub_checks::check_language_ub
  %_2.i47 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i47, label %bb2.i48, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49

bb2.i48:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_12, ptr align 8 @alloc_eda7b11e07c58ae313ac1fad01d041e9) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49: ; preds = %bb1, %bb2.i48
  %_17 = lshr i128 %n, 112
  %n9 = trunc i128 %_17 to i16
  %lo = and i16 %n9, 255
  %_21 = zext i8 %r8 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s7 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic10, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_eda7b11e07c58ae313ac1fad01d041e9) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic11, label %bb4

panic10:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_6042291b1954087ab71387f1f17f0449) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s7, 4
  %_30 = zext i8 %_31 to i16
  %4 = add i16 %_30, %q
  store i16 %4, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %5 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %6 = insertvalue { i16, i1 } %5, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %6, 0
  %_34.1 = extractvalue { i16, i1 } %6, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic11:                                          ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_6042291b1954087ab71387f1f17f0449) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i44, label %bb2.i45, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46

bb2.i45:                                          ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_45, ptr align 8 @alloc_6042291b1954087ab71387f1f17f0449) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46: ; preds = %bb8, %bb2.i45
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %_53 = lshr i128 %n, 96
  %n12 = trunc i128 %_53 to i32
  %lo13 = and i32 %n12, 65535
  %_57 = zext i16 %_48 to i32
  %_56 = shl i32 %_57, 8
  %_58 = lshr i32 %lo13, 8
  %numerator14 = or i32 %_56, %_58
  %_60 = zext i16 %_47 to i32
  %denominator15 = shl i32 %_60, 1
  %_62 = icmp eq i32 %denominator15, 0
  br i1 %_62, label %panic16, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %7 = load i16, ptr %s, align 2
  %8 = sub i16 %7, 1
  store i16 %8, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46
  %q17 = udiv i32 %numerator14, %denominator15
  %_64 = icmp eq i32 %denominator15, 0
  br i1 %_64, label %panic18, label %bb11

panic16:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_ce4d3b1f48911fd97fc8507578e88cdb) #23
  unreachable

bb11:                                             ; preds = %bb10
  %u19 = urem i32 %numerator14, %denominator15
  %_67 = shl i16 %_47, 8
  %_66 = zext i16 %_67 to i32
  %9 = add i32 %_66, %q17
  store i32 %9, ptr %s1, align 4
  %_72 = shl i32 %u19, 8
  %_73 = and i32 %lo13, 255
  %_71 = or i32 %_72, %_73
  %_74 = mul i32 %q17, %q17
  %_5.0.i34 = sub i32 %_71, %_74
  %_5.1.i35 = icmp ult i32 %_71, %_74
  %10 = insertvalue { i32, i1 } poison, i32 %_5.0.i34, 0
  %11 = insertvalue { i32, i1 } %10, i1 %_5.1.i35, 1
  %_70.0 = extractvalue { i32, i1 } %11, 0
  %_70.1 = extractvalue { i32, i1 } %11, 1
  store i32 %_70.0, ptr %r2, align 4
  br i1 %_70.1, label %bb13, label %bb15

panic18:                                          ; preds = %bb10
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_ce4d3b1f48911fd97fc8507578e88cdb) #23
  unreachable

bb15:                                             ; preds = %bb13, %bb11
  %_82 = load i32, ptr %s1, align 4
  %_81 = icmp ne i32 %_82, 0
; call core::ub_checks::check_language_ub
  %_2.i41 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i41, label %bb2.i42, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43

bb2.i42:                                          ; preds = %bb15
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_81, ptr align 8 @alloc_ce4d3b1f48911fd97fc8507578e88cdb) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43: ; preds = %bb15, %bb2.i42
  %_83 = load i32, ptr %s1, align 4
  %_84 = load i32, ptr %r2, align 4
  %_89 = lshr i128 %n, 64
  %n20 = trunc i128 %_89 to i64
  %lo21 = and i64 %n20, 4294967295
  %_93 = zext i32 %_84 to i64
  %_92 = shl i64 %_93, 16
  %_94 = lshr i64 %lo21, 16
  %numerator22 = or i64 %_92, %_94
  %_96 = zext i32 %_83 to i64
  %denominator23 = shl i64 %_96, 1
  %_98 = icmp eq i64 %denominator23, 0
  br i1 %_98, label %panic24, label %bb17

bb13:                                             ; preds = %bb11
  %_76 = load i32, ptr %r2, align 4
  %_79 = load i32, ptr %s1, align 4
  %_78 = mul i32 2, %_79
  %_77 = sub i32 %_78, 1
  %_0.i33 = add i32 %_76, %_77
  store i32 %_0.i33, ptr %r2, align 4
  %12 = load i32, ptr %s1, align 4
  %13 = sub i32 %12, 1
  store i32 %13, ptr %s1, align 4
  br label %bb15

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43
  %q25 = udiv i64 %numerator22, %denominator23
  %_100 = icmp eq i64 %denominator23, 0
  br i1 %_100, label %panic26, label %bb18

panic24:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_2a09b92e9319e8cf7ffdc293d51a865d) #23
  unreachable

bb18:                                             ; preds = %bb17
  %u27 = urem i64 %numerator22, %denominator23
  %_103 = shl i32 %_83, 16
  %_102 = zext i32 %_103 to i64
  %14 = add i64 %_102, %q25
  store i64 %14, ptr %s3, align 8
  %_108 = shl i64 %u27, 16
  %_109 = and i64 %lo21, 65535
  %_107 = or i64 %_108, %_109
  %_110 = mul i64 %q25, %q25
  %_5.0.i37 = sub i64 %_107, %_110
  %_5.1.i38 = icmp ult i64 %_107, %_110
  %15 = insertvalue { i64, i1 } poison, i64 %_5.0.i37, 0
  %16 = insertvalue { i64, i1 } %15, i1 %_5.1.i38, 1
  %_106.0 = extractvalue { i64, i1 } %16, 0
  %_106.1 = extractvalue { i64, i1 } %16, 1
  store i64 %_106.0, ptr %r4, align 8
  br i1 %_106.1, label %bb20, label %bb22

panic26:                                          ; preds = %bb17
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_2a09b92e9319e8cf7ffdc293d51a865d) #23
  unreachable

bb22:                                             ; preds = %bb20, %bb18
  %_118 = load i64, ptr %s3, align 8
  %_117 = icmp ne i64 %_118, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsfP1CzEAVZUO_12int_ops_u128() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb22
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %_117, ptr align 8 @alloc_2a09b92e9319e8cf7ffdc293d51a865d) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb22, %bb2.i
  %_119 = load i64, ptr %s3, align 8
  %_120 = load i64, ptr %r4, align 8
  %lo28 = and i128 %n, 18446744073709551615
  %_124 = zext i64 %_120 to i128
  %_123 = shl i128 %_124, 32
  %_125 = lshr i128 %lo28, 32
  %numerator29 = or i128 %_123, %_125
  %_127 = zext i64 %_119 to i128
  %denominator30 = shl i128 %_127, 1
  %_129 = icmp eq i128 %denominator30, 0
  br i1 %_129, label %panic31, label %bb24

bb20:                                             ; preds = %bb18
  %_112 = load i64, ptr %r4, align 8
  %_115 = load i64, ptr %s3, align 8
  %_114 = mul i64 2, %_115
  %_113 = sub i64 %_114, 1
  %_0.i36 = add i64 %_112, %_113
  store i64 %_0.i36, ptr %r4, align 8
  %17 = load i64, ptr %s3, align 8
  %18 = sub i64 %17, 1
  store i64 %18, ptr %s3, align 8
  br label %bb22

bb24:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q32 = udiv i128 %numerator29, %denominator30
  %_132 = shl i64 %_119, 32
  %_131 = zext i64 %_132 to i128
  %19 = add i128 %_131, %q32
  store i128 %19, ptr %s5, align 16
  %_136 = load i128, ptr %s5, align 16
  %_137 = load i128, ptr %s5, align 16
  %20 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_136, i128 %_137)
  %_5.0.i39 = extractvalue { i128, i1 } %20, 0
  %_5.1.i40 = extractvalue { i128, i1 } %20, 1
  store i128 %_5.0.i39, ptr %0, align 16
  %21 = getelementptr inbounds i8, ptr %0, i64 16
  %22 = zext i1 %_5.1.i40 to i8
  store i8 %22, ptr %21, align 16
  %_135.0 = load i128, ptr %0, align 16
  %23 = getelementptr inbounds i8, ptr %0, i64 16
  %24 = load i8, ptr %23, align 16
  %_135.1 = trunc nuw i8 %24 to i1
  br i1 %_135.1, label %bb27, label %bb26

panic31:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cdc8401a47de3b375010692dbb496696) #23
  unreachable

bb26:                                             ; preds = %bb24
  %_138 = icmp ugt i128 %_135.0, %n
  br i1 %_138, label %bb27, label %bb28

bb27:                                             ; preds = %bb26, %bb24
  %25 = load i128, ptr %s5, align 16
  %26 = sub i128 %25, 1
  store i128 %26, ptr %s5, align 16
  br label %bb28

bb28:                                             ; preds = %bb27, %bb26
  %_0 = load i128, ptr %s5, align 16
  ret i128 %_0
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsfP1CzEAVZUO_12int_ops_u128(i8 %n) unnamed_addr #0 !guid !142 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.c315984353131a6bca32d403680bc46d.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #23
  unreachable
}

; core::num::imp::int_sqrt::u16
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsfP1CzEAVZUO_12int_ops_u128(i16 %0) unnamed_addr #0 !guid !143 {
start:
  %_0 = alloca [2 x i8], align 2
  %n = alloca [2 x i8], align 2
  store i16 %0, ptr %n, align 2
  %_3 = load i16, ptr %n, align 2
  %_2 = icmp ule i16 %_3, 255
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i16, ptr %n, align 2
  %1 = call i16 @llvm.ctlz.i16(i16 %_10, i1 false)
  %_0.i = zext i16 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i16, ptr %n, align 2
  %3 = and i32 %normalization_shift, 15
  %4 = trunc i32 %3 to i16
  %5 = shl i16 %2, %4
  store i16 %5, ptr %n, align 2
  %_12 = load i16, ptr %n, align 2
; call core::num::imp::int_sqrt::u16_stages
  %s = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsfP1CzEAVZUO_12int_ops_u128(i16 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 15
  %7 = trunc i32 %6 to i16
  %8 = lshr i16 %s, %7
  store i16 %8, ptr %_0, align 2
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i16, ptr %n, align 2
  %_6 = trunc i16 %_7 to i8
; call core::num::imp::int_sqrt::u8
  %_5 = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsfP1CzEAVZUO_12int_ops_u128(i8 %_6) #17
  %9 = zext i8 %_5 to i16
  store i16 %9, ptr %_0, align 2
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i16, ptr %_0, align 2
  ret i16 %10
}

; core::num::imp::int_sqrt::u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32CsfP1CzEAVZUO_12int_ops_u128(i32 %0) unnamed_addr #0 !guid !144 {
start:
  %_0 = alloca [4 x i8], align 4
  %n = alloca [4 x i8], align 4
  store i32 %0, ptr %n, align 4
  %_3 = load i32, ptr %n, align 4
  %_2 = icmp ule i32 %_3, 65535
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i32, ptr %n, align 4
  %_0.i = call i32 @llvm.ctlz.i32(i32 %_10, i1 false)
  %normalization_shift = and i32 %_0.i, -2
  %1 = load i32, ptr %n, align 4
  %2 = and i32 %normalization_shift, 31
  %3 = shl i32 %1, %2
  store i32 %3, ptr %n, align 4
  %_12 = load i32, ptr %n, align 4
; call core::num::imp::int_sqrt::u32_stages
  %s = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsfP1CzEAVZUO_12int_ops_u128(i32 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %4 = and i32 %denormalization_shift, 31
  %5 = lshr i32 %s, %4
  store i32 %5, ptr %_0, align 4
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i32, ptr %n, align 4
  %_6 = trunc i32 %_7 to i16
; call core::num::imp::int_sqrt::u16
  %_5 = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsfP1CzEAVZUO_12int_ops_u128(i16 %_6) #17
  %6 = zext i16 %_5 to i32
  store i32 %6, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %7 = load i32, ptr %_0, align 4
  ret i32 %7
}

; core::num::imp::int_sqrt::u64
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64CsfP1CzEAVZUO_12int_ops_u128(i64 %0) unnamed_addr #0 !guid !145 {
start:
  %_0 = alloca [8 x i8], align 8
  %n = alloca [8 x i8], align 8
  store i64 %0, ptr %n, align 8
  %_3 = load i64, ptr %n, align 8
  %_2 = icmp ule i64 %_3, 4294967295
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i64, ptr %n, align 8
  %1 = call i64 @llvm.ctlz.i64(i64 %_10, i1 false)
  %_0.i = trunc i64 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i64, ptr %n, align 8
  %3 = and i32 %normalization_shift, 63
  %4 = zext i32 %3 to i64
  %5 = shl i64 %2, %4
  store i64 %5, ptr %n, align 8
  %_12 = load i64, ptr %n, align 8
; call core::num::imp::int_sqrt::u64_stages
  %s = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCsfP1CzEAVZUO_12int_ops_u128(i64 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 63
  %7 = zext i32 %6 to i64
  %8 = lshr i64 %s, %7
  store i64 %8, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %n, align 8
  %_6 = trunc i64 %_7 to i32
; call core::num::imp::int_sqrt::u32
  %_5 = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32CsfP1CzEAVZUO_12int_ops_u128(i32 %_6) #17
  %9 = zext i32 %_5 to i64
  store i64 %9, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i64, ptr %_0, align 8
  ret i64 %10
}

; core::num::imp::int_sqrt::u128
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt4u128CsfP1CzEAVZUO_12int_ops_u128(i128 %0) unnamed_addr #0 !guid !146 {
start:
  %_0 = alloca [16 x i8], align 16
  %n = alloca [16 x i8], align 16
  store i128 %0, ptr %n, align 16
  %_3 = load i128, ptr %n, align 16
  %_2 = icmp ule i128 %_3, 18446744073709551615
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i128, ptr %n, align 16
  %1 = call i128 @llvm.ctlz.i128(i128 %_10, i1 false)
  %_0.i = trunc i128 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i128, ptr %n, align 16
  %3 = and i32 %normalization_shift, 127
  %4 = zext i32 %3 to i128
  %5 = shl i128 %2, %4
  store i128 %5, ptr %n, align 16
  %_12 = load i128, ptr %n, align 16
; call core::num::imp::int_sqrt::u128_stages
  %s = call i128 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt11u128_stagesCsfP1CzEAVZUO_12int_ops_u128(i128 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 127
  %7 = zext i32 %6 to i128
  %8 = lshr i128 %s, %7
  store i128 %8, ptr %_0, align 16
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i128, ptr %n, align 16
  %_6 = trunc i128 %_7 to i64
; call core::num::imp::int_sqrt::u64
  %_5 = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64CsfP1CzEAVZUO_12int_ops_u128(i64 %_6) #17
  %9 = zext i64 %_5 to i128
  store i128 %9, ptr %_0, align 16
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i128, ptr %_0, align 16
  ret i128 %10
}

; <u128>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i128 %lhs, i128 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !147 {
start:
  %1 = alloca [32 x i8], align 16
  %2 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %lhs, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %2, 0
  %_5.1.i = extractvalue { i128, i1 } %2, 1
  store i128 %_5.0.i, ptr %1, align 16
  %3 = getelementptr inbounds i8, ptr %1, i64 16
  %4 = zext i1 %_5.1.i to i8
  store i8 %4, ptr %3, align 16
  br label %bb1

terminate:                                        ; preds = %bb2
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = load i128, ptr %1, align 16
  %6 = getelementptr inbounds i8, ptr %1, i64 16
  %7 = load i8, ptr %6, align 16
  %_4.1 = trunc nuw i8 %7 to i1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %8 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfP1CzEAVZUO_12int_ops_u128(ptr @alloc_8889105080bbd684fa4b755988461744, i64 185)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %8, 0
  %_6.1 = extractvalue { ptr, ptr } %8, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <u128>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !148 {
start:
  %_2 = icmp ult i32 %rhs, 128
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfP1CzEAVZUO_12int_ops_u128(ptr @alloc_8efb6cb47e437ad05e23651986f609b7, i64 185)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <u128>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shr18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !149 {
start:
  %_2 = icmp ult i32 %rhs, 128
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfP1CzEAVZUO_12int_ops_u128(ptr @alloc_3e2bc8b0102fca1babff0a50e98b5638, i64 185)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsfP1CzEAVZUO_12int_ops_u128(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !150 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfP1CzEAVZUO_12int_ops_u128(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsfP1CzEAVZUO_12int_ops_u128() unnamed_addr #0 !guid !151 {
start:
  ret i1 true
}

; <(u128, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTobENtB6_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #1 !guid !152 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <u128 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1R_NtCs7CppTae75M1_5alloc6stringoNtB6_12SpecToString14spec_to_stringCsfP1CzEAVZUO_12int_ops_u128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) unnamed_addr #0 !guid !153 {
start:
  %buf = alloca [39 x i8], align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 39, i1 false)
  %_5 = load i128, ptr %self, align 16
; call <u128>::_fmt
  %0 = call { ptr, i64 } @_RNvMs0_NtNtCsl10jNU3mE6R_4core3fmt3numo4__fmt(i128 %_5, ptr %buf, i64 39)
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8 %_0, ptr %_4.0, i64 %_4.1) #17
  ret void
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !154 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !155 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&u128 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRoNtB6_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !156 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u128 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <u128 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringoNtB5_8ToString9to_stringCsfP1CzEAVZUO_12int_ops_u128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) unnamed_addr #0 !guid !157 {
start:
; call <u128 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1R_NtCs7CppTae75M1_5alloc6stringoNtB6_12SpecToString14spec_to_stringCsfP1CzEAVZUO_12int_ops_u128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) #17
  ret void
}

; <u128 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsE_NtCsl10jNU3mE6R_4core3numoNtNtNtB7_3str6traits7FromStr8from_strCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !158 {
start:
; call <u128>::from_str_radix
  call void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo14from_str_radixCsfP1CzEAVZUO_12int_ops_u128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 10) #17
  ret void
}

; <core::option::Option<u128> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionoENtNtB7_3fmt5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !159 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i128, ptr %self, align 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i128, ptr %1, align 16
  %_3 = trunc i128 %0 to i64
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %4, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.1)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsfP1CzEAVZUO_12int_ops_u128() unnamed_addr #0 !guid !160 {
start:
  ret i8 0
}

; <u128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !161 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !162 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !163 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::result::Result<u128, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultoNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsfP1CzEAVZUO_12int_ops_u128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !164 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfP1CzEAVZUO_12int_ops_u128(ptr %_1) unnamed_addr #0 !guid !165 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfP1CzEAVZUO_12int_ops_u128(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !166 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsfP1CzEAVZUO_12int_ops_u128(ptr align 8 %_1) #17
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<u128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16) unnamed_addr #0

; <core::ptr::non_null::NonNull<u128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr) unnamed_addr #0

; <u128 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsG_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_6Binary3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsI_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Octal3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fshl.i128(i128, i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fshr.i128(i128, i128, i128) #9

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_lower_hex::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoEB7_(ptr sret([16 x i8]) align 8, ptr align 16) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptoui.sat.i128.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.umul.with.overflow.i128(i128, i128) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; <core::num::nonzero::NonZero<u128>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3getB9_(i128) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctlz.i128(i128, i1 immarg) #10

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctlz.i16(i16, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.umul.with.overflow.i16(i16, i16) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctpop.i128(i128) #9

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.bswap.i128(i128) #9

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i128(i128) #12

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.bitreverse.i128(i128) #9

; <core::num::nonzero::NonZero<u128>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3newB9_(i128) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.uadd.sat.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.usub.sat.i128(i128, i128) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.cttz.i128(i128, i1 immarg) #10

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #11

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #13

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #14

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #15

; <u128>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMs0_NtNtCsl10jNU3mE6R_4core3fmt3numo4__fmt(i128, ptr, i64) unnamed_addr #1

; <str as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #0

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <u128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #16 !guid !167 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsfP1CzEAVZUO_12int_ops_u128(ptr @_RNvCsfP1CzEAVZUO_12int_ops_u1284main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #13 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #16 = { nonlazybind "target-cpu"="x86-64" }
attributes #17 = { inlinehint }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noreturn }
attributes #20 = { noinline }
attributes #21 = { nounwind }
attributes #22 = { inlinehint nounwind }
attributes #23 = { noinline noreturn }
attributes #24 = { cold }
attributes #25 = { noinline noreturn nounwind }

!llvm.module.flags = !{!59, !60, !61, !62}
!llvm.ident = !{!63}

!0 = !{i64 5436683537163879037}
!1 = !{i64 -767459256153192347}
!2 = !{i64 -6181489006963629855}
!3 = !{i64 -6033513658909349507}
!4 = !{i64 7459533157950329718}
!5 = !{i64 -5329225182359631343}
!6 = !{i64 1275414686894337112}
!7 = !{i64 -882980615058299229}
!8 = !{i64 -6087903885666171512}
!9 = !{i64 1052970814888655391}
!10 = !{i64 2090592115133535471}
!11 = !{i64 -8111519723754341132}
!12 = !{i64 -7879682584277265186}
!13 = !{i64 4717162447530456653}
!14 = !{i64 -9093410475974071321}
!15 = !{i64 -3826223132148731808}
!16 = !{i64 -4561174657753312352}
!17 = !{i64 8687332516575954578}
!18 = !{i64 -2788343444986546441}
!19 = !{i64 2682087760356731718}
!20 = !{i64 2157049034187539697}
!21 = !{i64 -6984755158978263099}
!22 = !{i64 1650278932075368128}
!23 = !{i64 -6600687062172711976}
!24 = !{i64 -1908531251705999733}
!25 = !{i64 6783974404530268695}
!26 = !{i64 -6218700819191853668}
!27 = !{i64 6010864142336495241}
!28 = !{i64 521994230960393559}
!29 = !{i64 3968183851938714935}
!30 = !{i64 -8932310154499412924}
!31 = !{i64 5266668318133669091}
!32 = !{i64 -5454320694173625814}
!33 = !{i64 7672387071302908004}
!34 = !{i64 2358929060695200572}
!35 = !{i64 -5604662174855843465}
!36 = !{i64 1970648561586615829}
!37 = !{i64 -2982399008646979545}
!38 = !{i64 9051231537203093860}
!39 = !{i64 5200912267373897551}
!40 = !{i64 4419860803865810407}
!41 = !{i64 1143110206563416098}
!42 = !{i64 -3267030052730959632}
!43 = !{i64 504013623813934040}
!44 = !{i64 5440026993331461211}
!45 = !{i64 -5168319077368965566}
!46 = !{i64 7588983244107091613}
!47 = !{i64 -4152234736509842487}
!48 = !{i64 -3513531484221841227}
!49 = !{i64 -4905357523616231439}
!50 = !{i64 -1506208413992099899}
!51 = !{i64 7290478085216253305}
!52 = !{i64 1778076270862329015}
!53 = !{i64 2640943388741404043}
!54 = !{i64 -2138085388011527103}
!55 = !{i64 -8540376813389625413}
!56 = !{i64 8471061960560748526}
!57 = !{i64 2875728778401470442}
!58 = !{i64 -4902312020851310262}
!59 = !{i32 8, !"PIC Level", i32 2}
!60 = !{i32 7, !"PIE Level", i32 2}
!61 = !{i32 2, !"RtLibUseGOT", i32 1}
!62 = !{i32 7, !"uwtable", i32 2}
!63 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!64 = !{i64 5405021154355639464}
!65 = !{i64 8225623639599389338}
!66 = !{i64 -7193899926041074831}
!67 = !{i64 -3070304125368658376}
!68 = !{i64 4145925235749059164}
!69 = !{i64 3394902266660167200}
!70 = !{i64 3498896960079185096}
!71 = !{i64 -7675009452345054489}
!72 = !{i64 1274917008457689439}
!73 = !{i64 3558431119475301150}
!74 = !{i64 2144505352018596274}
!75 = !{i64 3657961873502786455}
!76 = !{i64 8285490462786379554}
!77 = !{i64 -7420579894515750768}
!78 = !{i64 -81261787564525326}
!79 = !{i64 1747520910446170876}
!80 = !{i64 1817363402873785386}
!81 = !{i64 4195264753408753877}
!82 = !{i64 977810574717109989}
!83 = !{i64 6170489132182791344}
!84 = !{i64 8542662179946857263}
!85 = !{i64 -5602752851858883362}
!86 = !{i64 -4850195937431884282}
!87 = !{i64 -9087817979776084206}
!88 = !{i64 1677483541819361721}
!89 = !{i64 1318434701094649}
!90 = !{i64 2308873627389700239}
!91 = !{i64 3799166552798655828}
!92 = !{i64 -1519985137147339844}
!93 = !{i64 -1334526239425865022}
!94 = !{i64 -2374754147975927084}
!95 = !{i64 7729520591424648397}
!96 = !{i64 7257630066787731010}
!97 = !{i64 5745858629349494914}
!98 = !{i64 -7591287352176604819}
!99 = !{i64 6867925075434531704}
!100 = !{i64 351556983625967840}
!101 = !{i64 8025499836032451877}
!102 = !{i64 -3258048839605533015}
!103 = !{i64 6874317248439116174}
!104 = !{i64 7702141436925834942}
!105 = !{i64 30972825640002574}
!106 = !{i64 -4357654431276022613}
!107 = !{i64 4154555405677311666}
!108 = !{i64 -3969581120221447600}
!109 = !{i64 8465782933121830360}
!110 = !{i64 -2819071558618245134}
!111 = !{i64 4858466882406421578}
!112 = !{i64 8448122013052924386}
!113 = !{i64 -2465275575540866055}
!114 = !{i64 -2523778718070003553}
!115 = !{i64 7208436328641490902}
!116 = !{i64 2528474609692170975}
!117 = !{i64 4772173232884174240}
!118 = !{i64 -2086675239571665386}
!119 = !{i64 -7613181797098158282}
!120 = !{i64 2261644288951433808}
!121 = !{i64 4149414551265544613}
!122 = !{i64 -1423483661856269240}
!123 = !{i64 1487006041865335837}
!124 = !{i64 -2312434086841523942}
!125 = !{i64 -4298381101433514655}
!126 = !{i64 5043938625718669882}
!127 = !{i64 -4721012909761610153}
!128 = !{i64 8633749208234158136}
!129 = !{i64 8048352703960200403}
!130 = !{i64 -2913929254101162745}
!131 = !{i64 -3067000630331959640}
!132 = !{!"address", !"read_provenance"}
!133 = !{i64 8479524031737642161}
!134 = !{i64 -7604465542382220129}
!135 = !{i64 -626506902697406797}
!136 = !{i64 6984573664485851885}
!137 = !{i64 6361186076108302414}
!138 = !{i64 7445168482373248498}
!139 = !{i64 8193911160811866295}
!140 = !{i64 -4076511446988802116}
!141 = !{i64 -2615619426913550830}
!142 = !{i64 1003637616008811650}
!143 = !{i64 -2496844678874036692}
!144 = !{i64 1132819957878760526}
!145 = !{i64 5888258586197980829}
!146 = !{i64 1153011405193089197}
!147 = !{i64 8212529222163633116}
!148 = !{i64 -1769421310796860767}
!149 = !{i64 7651316801014795779}
!150 = !{i64 4080317465962594210}
!151 = !{i64 -778818915805344586}
!152 = !{i64 4988797099451304844}
!153 = !{i64 -6896557374632730669}
!154 = !{i64 -7616238586447162441}
!155 = !{i64 6057592828882985890}
!156 = !{i64 -6748445178464027854}
!157 = !{i64 3765948176773650724}
!158 = !{i64 -7605410409476185585}
!159 = !{i64 -800067983827898036}
!160 = !{i64 -5705824039151359661}
!161 = !{i64 2018598321470690913}
!162 = !{i64 -3889986431934243806}
!163 = !{i64 -8490327299253577115}
!164 = !{i64 1895336808012078918}
!165 = !{i64 6228917387158588295}
!166 = !{i64 -2796817182440053738}
!167 = !{i64 -2624081020897602054}
