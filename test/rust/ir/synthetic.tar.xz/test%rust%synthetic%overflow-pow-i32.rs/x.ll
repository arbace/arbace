; ModuleID = 'overflow_pow_i32.38e0fa333f546e5-cgu.0'
source_filename = "overflow_pow_i32.38e0fa333f546e5-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsiVdchs2Ysr_16overflow_pow_i32, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsiVdchs2Ysr_16overflow_pow_i32, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsiVdchs2Ysr_16overflow_pow_i32 }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_aba2f1a5110ca0d659951e181c97d362 = private unnamed_addr constant [20 x i8] c"\0Cunreachable \C0\01 \C0\01\0A\00", align 1, !guid !2
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !3
@alloc_321cb53071ed634b0d814fda86198fe8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\AD\01\00\00\05\00\00\00" }>, align 8, !guid !4
@alloc_eea3b4108fd45221c9468d112de34f4d = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: i32::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !5

; <core::fmt::Arguments>::new::<20, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj2_ECsiVdchs2Ysr_16overflow_pow_i32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !11 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsiVdchs2Ysr_16overflow_pow_i32(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !12 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::is_val_statically_known::<i32>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownlECsiVdchs2Ysr_16overflow_pow_i32(i32 %_arg) unnamed_addr #2 !guid !13 {
start:
  ret i1 false
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsiVdchs2Ysr_16overflow_pow_i32(i32 %dummy) unnamed_addr #0 !guid !14 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !15
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsiVdchs2Ysr_16overflow_pow_i32(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !16 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsiVdchs2Ysr_16overflow_pow_i32(ptr %f) #14
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #14
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsiVdchs2Ysr_16overflow_pow_i32(ptr align 8 %_1) unnamed_addr #0 !guid !17 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsiVdchs2Ysr_16overflow_pow_i32(ptr %_4) #15
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsiVdchs2Ysr_16overflow_pow_i32() #14
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsiVdchs2Ysr_16overflow_pow_i32(i8 %_2) #14
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsiVdchs2Ysr_16overflow_pow_i32(ptr %_1) unnamed_addr #0 !guid !18 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsiVdchs2Ysr_16overflow_pow_i32(ptr %0) #14
  ret i32 %_0
}

; overflow_pow_i32::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsiVdchs2Ysr_16overflow_pow_i324main() unnamed_addr #1 !guid !19 {
start:
  %_13 = alloca [16 x i8], align 8
  %_12 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %r = alloca [4 x i8], align 4
  %b = alloca [4 x i8], align 4
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsiVdchs2Ysr_16overflow_pow_i32(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #14
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<i32>
  %a = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsiVdchs2Ysr_16overflow_pow_i32(i32 3) #14
; call core::hint::black_box::<i32>
  %1 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsiVdchs2Ysr_16overflow_pow_i32(i32 0) #14
  store i32 %1, ptr %b, align 4
; call <i32>::pow
  %2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl3powCsiVdchs2Ysr_16overflow_pow_i32(i32 %a, i32 40) #14
  store i32 %2, ptr %r, align 4
; call <core::fmt::rt::Argument>::new_debug::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuglECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8 %_12, ptr align 4 %r) #14
; call <core::fmt::rt::Argument>::new_debug::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuglECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8 %_13, ptr align 4 %b) #14
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_12, i64 16, i1 false)
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_13, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<20, 2>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj2_ECsiVdchs2Ysr_16overflow_pow_i32(ptr @alloc_aba2f1a5110ca0d659951e181c97d362, ptr align 8 %args) #14
  %_7.0 = extractvalue { ptr, ptr } %5, 0
  %_7.1 = extractvalue { ptr, ptr } %5, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_7.0, ptr %_7.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsiVdchs2Ysr_16overflow_pow_i32(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !20 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<i32>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE7is_noneCsiVdchs2Ysr_16overflow_pow_i32(ptr align 4 %self) unnamed_addr #0 !guid !21 {
start:
; call <core::option::Option<i32>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE7is_someCsddYV2PBJW9h_3std(ptr align 4 %self) #14
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <i32>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl10strict_powCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !22 {
start:
  %_3 = alloca [8 x i8], align 4
; call <i32>::checked_pow
  %1 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_powCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %exp) #14
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_3, align 4
  %4 = getelementptr inbounds i8, ptr %_3, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_3, align 4
  %6 = getelementptr inbounds i8, ptr %_3, i64 4
  %7 = load i32, ptr %6, align 4
  %_4 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_4 to i1
  br i1 %8, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_3, i64 4
  %x = load i32, ptr %9, align 4
  ret i32 %x

bb3:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #16
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !23 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_powCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %0) unnamed_addr #0 !guid !24 {
start:
  %_57 = alloca [8 x i8], align 4
  %_48 = alloca [8 x i8], align 4
  %_38 = alloca [8 x i8], align 4
  %_32 = alloca [8 x i8], align 4
  %_13 = alloca [8 x i8], align 4
  %acc = alloca [4 x i8], align 4
  %base = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i32 %self, ptr %base, align 4
  store i32 1, ptr %acc, align 4
  %_6 = load i32, ptr %base, align 4
  %_5 = call i1 @llvm.is.constant.i32(i32 %_6)
  br i1 %_5, label %bb2, label %bb16

bb16:                                             ; preds = %bb2, %start
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp eq i32 %_24, 0
  br i1 %_23, label %bb17, label %bb18

bb2:                                              ; preds = %start
  %_9 = load i32, ptr %base, align 4
; call <i32>::unsigned_abs
  %_8 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsiVdchs2Ysr_16overflow_pow_i32(i32 %_9) #14
  %_0.i.i = call i32 @llvm.ctpop.i32(i32 %_8)
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb16

bb5:                                              ; preds = %bb2
  %_12 = load i32, ptr %base, align 4
; call <i32>::unsigned_abs
  %_11 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsiVdchs2Ysr_16overflow_pow_i32(i32 %_12) #14
; call <u32>::ilog2
  %k = call i32 @_RNvMs6_NtCsl10jNU3mE6R_4core3numm5ilog2CsiVdchs2Ysr_16overflow_pow_i32(i32 %_11, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #14
  %_14 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %1 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsiVdchs2Ysr_16overflow_pow_i32(i32 %k, i32 %_14) #14
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_13, align 4
  %4 = getelementptr inbounds i8, ptr %_13, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_13, align 4
  %6 = getelementptr inbounds i8, ptr %_13, i64 4
  %7 = load i32, ptr %6, align 4
  %_15 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_15 to i1
  br i1 %8, label %bb11, label %bb10

bb18:                                             ; preds = %bb16
  %_26 = load i32, ptr %exp, align 4
  %_25 = call i1 @llvm.is.constant.i32(i32 %_26)
  br i1 %_25, label %bb20, label %bb32

bb17:                                             ; preds = %bb16
  %9 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 1, ptr %9, align 4
  store i32 1, ptr %_0, align 4
  br label %bb43

bb32:                                             ; preds = %bb42, %bb18
  %_47 = load i32, ptr %exp, align 4
  %_46 = and i32 %_47, 1
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb33, label %bb38

bb20:                                             ; preds = %bb30, %bb18
  %_28 = load i32, ptr %exp, align 4
  %_27 = icmp ugt i32 %_28, 1
  br i1 %_27, label %bb21, label %bb31

bb38:                                             ; preds = %bb36, %bb32
  %10 = load i32, ptr %exp, align 4
  %11 = udiv i32 %10, 2
  store i32 %11, ptr %exp, align 4
  %_58 = load i32, ptr %base, align 4
  %_59 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %12 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsiVdchs2Ysr_16overflow_pow_i32(i32 %_58, i32 %_59) #14
  %13 = extractvalue { i32, i32 } %12, 0
  %14 = extractvalue { i32, i32 } %12, 1
  store i32 %13, ptr %_57, align 4
  %15 = getelementptr inbounds i8, ptr %_57, i64 4
  store i32 %14, ptr %15, align 4
  %16 = load i32, ptr %_57, align 4
  %17 = getelementptr inbounds i8, ptr %_57, i64 4
  %18 = load i32, ptr %17, align 4
  %_60 = zext i32 %16 to i64
  %19 = trunc nuw i64 %_60 to i1
  br i1 %19, label %bb42, label %bb41

bb33:                                             ; preds = %bb32
  %_49 = load i32, ptr %acc, align 4
  %_50 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %20 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsiVdchs2Ysr_16overflow_pow_i32(i32 %_49, i32 %_50) #14
  %21 = extractvalue { i32, i32 } %20, 0
  %22 = extractvalue { i32, i32 } %20, 1
  store i32 %21, ptr %_48, align 4
  %23 = getelementptr inbounds i8, ptr %_48, i64 4
  store i32 %22, ptr %23, align 4
  %24 = load i32, ptr %_48, align 4
  %25 = getelementptr inbounds i8, ptr %_48, i64 4
  %26 = load i32, ptr %25, align 4
  %_51 = zext i32 %24 to i64
  %27 = trunc nuw i64 %_51 to i1
  br i1 %27, label %bb36, label %bb35

bb36:                                             ; preds = %bb33
  %28 = getelementptr inbounds i8, ptr %_48, i64 4
  %x = load i32, ptr %28, align 4
  store i32 %x, ptr %acc, align 4
  %_54 = load i32, ptr %exp, align 4
  %_53 = icmp eq i32 %_54, 1
  br i1 %_53, label %bb37, label %bb38

bb35:                                             ; preds = %bb33
  store i32 0, ptr %_0, align 4
  br label %bb43

bb43:                                             ; preds = %bb14, %bb15, %bb10, %bb17, %bb29, %bb24, %bb31, %bb37, %bb41, %bb35
  %29 = load i32, ptr %_0, align 4
  %30 = getelementptr inbounds i8, ptr %_0, i64 4
  %31 = load i32, ptr %30, align 4
  %32 = insertvalue { i32, i32 } poison, i32 %29, 0
  %33 = insertvalue { i32, i32 } %32, i32 %31, 1
  ret { i32, i32 } %33

bb37:                                             ; preds = %bb36
  %_55 = load i32, ptr %acc, align 4
  %34 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_55, ptr %34, align 4
  store i32 1, ptr %_0, align 4
  br label %bb43

bb42:                                             ; preds = %bb38
  %35 = getelementptr inbounds i8, ptr %_57, i64 4
  %x1 = load i32, ptr %35, align 4
  store i32 %x1, ptr %base, align 4
  br label %bb32

bb41:                                             ; preds = %bb38
  store i32 0, ptr %_0, align 4
  br label %bb43

bb31:                                             ; preds = %bb20
  %_43 = load i32, ptr %acc, align 4
  %_44 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %36 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsiVdchs2Ysr_16overflow_pow_i32(i32 %_43, i32 %_44) #14
  %37 = extractvalue { i32, i32 } %36, 0
  %38 = extractvalue { i32, i32 } %36, 1
  store i32 %37, ptr %_0, align 4
  %39 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %38, ptr %39, align 4
  br label %bb43

bb21:                                             ; preds = %bb20
  %_31 = load i32, ptr %exp, align 4
  %_30 = and i32 %_31, 1
  %_29 = icmp eq i32 %_30, 1
  br i1 %_29, label %bb22, label %bb26

bb26:                                             ; preds = %bb25, %bb21
  %40 = load i32, ptr %exp, align 4
  %41 = udiv i32 %40, 2
  store i32 %41, ptr %exp, align 4
  %_39 = load i32, ptr %base, align 4
  %_40 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %42 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsiVdchs2Ysr_16overflow_pow_i32(i32 %_39, i32 %_40) #14
  %43 = extractvalue { i32, i32 } %42, 0
  %44 = extractvalue { i32, i32 } %42, 1
  store i32 %43, ptr %_38, align 4
  %45 = getelementptr inbounds i8, ptr %_38, i64 4
  store i32 %44, ptr %45, align 4
  %46 = load i32, ptr %_38, align 4
  %47 = getelementptr inbounds i8, ptr %_38, i64 4
  %48 = load i32, ptr %47, align 4
  %_41 = zext i32 %46 to i64
  %49 = trunc nuw i64 %_41 to i1
  br i1 %49, label %bb30, label %bb29

bb22:                                             ; preds = %bb21
  %_33 = load i32, ptr %acc, align 4
  %_34 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %50 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsiVdchs2Ysr_16overflow_pow_i32(i32 %_33, i32 %_34) #14
  %51 = extractvalue { i32, i32 } %50, 0
  %52 = extractvalue { i32, i32 } %50, 1
  store i32 %51, ptr %_32, align 4
  %53 = getelementptr inbounds i8, ptr %_32, i64 4
  store i32 %52, ptr %53, align 4
  %54 = load i32, ptr %_32, align 4
  %55 = getelementptr inbounds i8, ptr %_32, i64 4
  %56 = load i32, ptr %55, align 4
  %_35 = zext i32 %54 to i64
  %57 = trunc nuw i64 %_35 to i1
  br i1 %57, label %bb25, label %bb24

bb25:                                             ; preds = %bb22
  %58 = getelementptr inbounds i8, ptr %_32, i64 4
  %x2 = load i32, ptr %58, align 4
  store i32 %x2, ptr %acc, align 4
  br label %bb26

bb24:                                             ; preds = %bb22
  store i32 0, ptr %_0, align 4
  br label %bb43

bb30:                                             ; preds = %bb26
  %59 = getelementptr inbounds i8, ptr %_38, i64 4
  %x3 = load i32, ptr %59, align 4
  store i32 %x3, ptr %base, align 4
  br label %bb20

bb29:                                             ; preds = %bb26
  store i32 0, ptr %_0, align 4
  br label %bb43

bb11:                                             ; preds = %bb5
  %60 = getelementptr inbounds i8, ptr %_13, i64 4
  %shift = load i32, ptr %60, align 4
  %_18 = load i32, ptr %base, align 4
  %_17 = icmp slt i32 %_18, 0
  br i1 %_17, label %bb12, label %bb15

bb10:                                             ; preds = %bb5
  store i32 0, ptr %_0, align 4
  br label %bb43

bb15:                                             ; preds = %bb12, %bb11
; call <i32>::shl_exact
  %61 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl9shl_exactCsiVdchs2Ysr_16overflow_pow_i32(i32 1, i32 %shift) #14
  %62 = extractvalue { i32, i32 } %61, 0
  %63 = extractvalue { i32, i32 } %61, 1
  store i32 %62, ptr %_0, align 4
  %64 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %63, ptr %64, align 4
  br label %bb43

bb12:                                             ; preds = %bb11
  %_21 = load i32, ptr %exp, align 4
  %_20 = urem i32 %_21, 2
  %_19 = icmp eq i32 %_20, 1
  br i1 %_19, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
; call <i32>::shl_exact
  %65 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl9shl_exactCsiVdchs2Ysr_16overflow_pow_i32(i32 -1, i32 %shift) #14
  %66 = extractvalue { i32, i32 } %65, 0
  %67 = extractvalue { i32, i32 } %65, 1
  store i32 %66, ptr %_0, align 4
  %68 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %67, ptr %68, align 4
  br label %bb43

bb9:                                              ; No predecessors!
  unreachable
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsiVdchs2Ysr_16overflow_pow_i32(i32 %self) unnamed_addr #0 !guid !25 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsiVdchs2Ysr_16overflow_pow_i32(i32 %self) #14
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsiVdchs2Ysr_16overflow_pow_i32(i32 %self) unnamed_addr #0 !guid !26 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <i32>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_powCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %exp) unnamed_addr #0 !guid !27 {
start:
; call <i32>::overflowing_pow
  %0 = call { i32, i1 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl15overflowing_powCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %exp) #14
  %_3.0 = extractvalue { i32, i1 } %0, 0
  %_3.1 = extractvalue { i32, i1 } %0, 1
  ret i32 %_3.0
}

; <i32>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unbounded_shlCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !28 {
start:
  %_0 = alloca [4 x i8], align 4
  %_3 = icmp ult i32 %rhs, 32
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiVdchs2Ysr_16overflow_pow_i32() #14
  br i1 %_3.i, label %bb2.i, label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <i32>::unchecked_shl::precondition_check
  call void @_RNvNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl18precondition_checkCsiVdchs2Ysr_16overflow_pow_i32(i32 %rhs, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #17
  br label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %_0.i = shl i32 %self, %rhs
  store i32 %_0.i, ptr %_0, align 4
  br label %bb3

bb3:                                              ; preds = %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit, %bb2
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <i32>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i1 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl15overflowing_powCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %0) unnamed_addr #0 !guid !29 {
start:
  %_30 = alloca [8 x i8], align 4
  %base1 = alloca [4 x i8], align 4
  %_16 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [4 x i8], align 4
  %base = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i32 %self, ptr %base, align 4
  store i32 1, ptr %acc, align 4
  store i8 0, ptr %overflow, align 1
  %_8 = load i32, ptr %base, align 4
  %_7 = call i1 @llvm.is.constant.i32(i32 %_8)
  br i1 %_7, label %bb2, label %bb19

bb19:                                             ; preds = %bb2, %start
  %_33 = load i32, ptr %exp, align 4
  %_32 = icmp eq i32 %_33, 0
  br i1 %_32, label %bb20, label %bb21

bb2:                                              ; preds = %start
  %_11 = load i32, ptr %base, align 4
; call <i32>::unsigned_abs
  %_10 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsiVdchs2Ysr_16overflow_pow_i32(i32 %_11) #14
  %_0.i.i = call i32 @llvm.ctpop.i32(i32 %_10)
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb19

bb5:                                              ; preds = %bb2
  %_14 = load i32, ptr %base, align 4
; call <i32>::unsigned_abs
  %_13 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsiVdchs2Ysr_16overflow_pow_i32(i32 %_14) #14
; call <u32>::ilog2
  %k = call i32 @_RNvMs6_NtCsl10jNU3mE6R_4core3numm5ilog2CsiVdchs2Ysr_16overflow_pow_i32(i32 %_13, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #14
  %_17 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %1 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsiVdchs2Ysr_16overflow_pow_i32(i32 %k, i32 %_17) #14
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_16, align 4
  %4 = getelementptr inbounds i8, ptr %_16, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_16, align 4
  %6 = getelementptr inbounds i8, ptr %_16, i64 4
  %7 = load i32, ptr %6, align 4
  %_18 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_18 to i1
  br i1 %8, label %bb9, label %bb10

bb21:                                             ; preds = %bb19
  %_35 = load i32, ptr %exp, align 4
  %_34 = call i1 @llvm.is.constant.i32(i32 %_35)
  br i1 %_34, label %bb23, label %bb32

bb20:                                             ; preds = %bb19
  store i64 1, ptr %_0, align 4
  br label %bb39

bb32:                                             ; preds = %bb36, %bb21
  %_64 = load i32, ptr %exp, align 4
  %_63 = and i32 %_64, 1
  %_62 = icmp eq i32 %_63, 1
  br i1 %_62, label %bb33, label %bb36

bb23:                                             ; preds = %bb27, %bb21
  %_37 = load i32, ptr %exp, align 4
  %_36 = icmp ugt i32 %_37, 1
  br i1 %_36, label %bb24, label %bb30

bb36:                                             ; preds = %bb33, %bb32
  %9 = load i32, ptr %exp, align 4
  %10 = udiv i32 %9, 2
  store i32 %10, ptr %exp, align 4
  %_79 = load i32, ptr %base, align 4
  %_80 = load i32, ptr %base, align 4
  %11 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_79, i32 %_80)
  %_5.0.i6 = extractvalue { i32, i1 } %11, 0
  %_5.1.i7 = extractvalue { i32, i1 } %11, 1
  %_78.0 = extractvalue { i32, i1 } %11, 0
  %_78.1 = extractvalue { i32, i1 } %11, 1
  store i32 %_78.0, ptr %base, align 4
  %12 = zext i1 %_78.1 to i8
  store i8 %12, ptr %tmp_overflow, align 1
  %13 = load i8, ptr %tmp_overflow, align 1
  %_81 = trunc nuw i8 %13 to i1
  %14 = load i8, ptr %overflow, align 1
  %15 = trunc nuw i8 %14 to i1
  %16 = or i1 %15, %_81
  %17 = zext i1 %16 to i8
  store i8 %17, ptr %overflow, align 1
  br label %bb32

bb33:                                             ; preds = %bb32
  %_68 = load i32, ptr %acc, align 4
  %_69 = load i32, ptr %base, align 4
  %18 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_68, i32 %_69)
  %_5.0.i8 = extractvalue { i32, i1 } %18, 0
  %_5.1.i9 = extractvalue { i32, i1 } %18, 1
  %_67.0 = extractvalue { i32, i1 } %18, 0
  %_67.1 = extractvalue { i32, i1 } %18, 1
  store i32 %_67.0, ptr %acc, align 4
  %19 = zext i1 %_67.1 to i8
  store i8 %19, ptr %tmp_overflow, align 1
  %20 = load i8, ptr %tmp_overflow, align 1
  %_70 = trunc nuw i8 %20 to i1
  %21 = load i8, ptr %overflow, align 1
  %22 = trunc nuw i8 %21 to i1
  %23 = or i1 %22, %_70
  %24 = zext i1 %23 to i8
  store i8 %24, ptr %overflow, align 1
  %_72 = load i32, ptr %exp, align 4
  %_71 = icmp eq i32 %_72, 1
  br i1 %_71, label %bb35, label %bb36

bb35:                                             ; preds = %bb33
  %_73 = load i32, ptr %acc, align 4
  %25 = load i8, ptr %overflow, align 1
  %_74 = trunc nuw i8 %25 to i1
  store i32 %_73, ptr %_0, align 4
  %26 = getelementptr inbounds i8, ptr %_0, i64 4
  %27 = zext i1 %_74 to i8
  store i8 %27, ptr %26, align 4
  br label %bb39

bb39:                                             ; preds = %bb10, %bb15, %bb20, %bb30, %bb35
  %28 = load i32, ptr %_0, align 4
  %29 = getelementptr inbounds i8, ptr %_0, i64 4
  %30 = load i8, ptr %29, align 4
  %31 = trunc nuw i8 %30 to i1
  %32 = insertvalue { i32, i1 } poison, i32 %28, 0
  %33 = insertvalue { i32, i1 } %32, i1 %31, 1
  ret { i32, i1 } %33

bb30:                                             ; preds = %bb23
  %_57 = load i32, ptr %acc, align 4
  %_58 = load i32, ptr %base, align 4
  %34 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_57, i32 %_58)
  %_5.0.i4 = extractvalue { i32, i1 } %34, 0
  %_5.1.i5 = extractvalue { i32, i1 } %34, 1
  %_56.0 = extractvalue { i32, i1 } %34, 0
  %_56.1 = extractvalue { i32, i1 } %34, 1
  store i32 %_56.0, ptr %acc, align 4
  %35 = zext i1 %_56.1 to i8
  store i8 %35, ptr %tmp_overflow, align 1
  %36 = load i8, ptr %tmp_overflow, align 1
  %_59 = trunc nuw i8 %36 to i1
  %37 = load i8, ptr %overflow, align 1
  %38 = trunc nuw i8 %37 to i1
  %39 = or i1 %38, %_59
  %40 = zext i1 %39 to i8
  store i8 %40, ptr %overflow, align 1
  %_60 = load i32, ptr %acc, align 4
  %41 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %41 to i1
  store i32 %_60, ptr %_0, align 4
  %42 = getelementptr inbounds i8, ptr %_0, i64 4
  %43 = zext i1 %_61 to i8
  store i8 %43, ptr %42, align 4
  br label %bb39

bb24:                                             ; preds = %bb23
  %_40 = load i32, ptr %exp, align 4
  %_39 = and i32 %_40, 1
  %_38 = icmp eq i32 %_39, 1
  br i1 %_38, label %bb25, label %bb27

bb27:                                             ; preds = %bb25, %bb24
  %44 = load i32, ptr %exp, align 4
  %45 = udiv i32 %44, 2
  store i32 %45, ptr %exp, align 4
  %_51 = load i32, ptr %base, align 4
  %_52 = load i32, ptr %base, align 4
  %46 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_51, i32 %_52)
  %_5.0.i = extractvalue { i32, i1 } %46, 0
  %_5.1.i = extractvalue { i32, i1 } %46, 1
  %_50.0 = extractvalue { i32, i1 } %46, 0
  %_50.1 = extractvalue { i32, i1 } %46, 1
  store i32 %_50.0, ptr %base, align 4
  %47 = zext i1 %_50.1 to i8
  store i8 %47, ptr %tmp_overflow, align 1
  %48 = load i8, ptr %tmp_overflow, align 1
  %_53 = trunc nuw i8 %48 to i1
  %49 = load i8, ptr %overflow, align 1
  %50 = trunc nuw i8 %49 to i1
  %51 = or i1 %50, %_53
  %52 = zext i1 %51 to i8
  store i8 %52, ptr %overflow, align 1
  br label %bb23

bb25:                                             ; preds = %bb24
  %_44 = load i32, ptr %acc, align 4
  %_45 = load i32, ptr %base, align 4
  %53 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_44, i32 %_45)
  %_5.0.i2 = extractvalue { i32, i1 } %53, 0
  %_5.1.i3 = extractvalue { i32, i1 } %53, 1
  %_43.0 = extractvalue { i32, i1 } %53, 0
  %_43.1 = extractvalue { i32, i1 } %53, 1
  store i32 %_43.0, ptr %acc, align 4
  %54 = zext i1 %_43.1 to i8
  store i8 %54, ptr %tmp_overflow, align 1
  %55 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %55 to i1
  %56 = load i8, ptr %overflow, align 1
  %57 = trunc nuw i8 %56 to i1
  %58 = or i1 %57, %_46
  %59 = zext i1 %58 to i8
  store i8 %59, ptr %overflow, align 1
  br label %bb27

bb9:                                              ; preds = %bb5
  %60 = getelementptr inbounds i8, ptr %_16, i64 4
  %shift = load i32, ptr %60, align 4
  %_21 = load i32, ptr %base, align 4
  %_20 = icmp slt i32 %_21, 0
  br i1 %_20, label %bb11, label %bb14

bb10:                                             ; preds = %bb5
  store i64 4294967296, ptr %_0, align 4
  br label %bb39

bb14:                                             ; preds = %bb11, %bb9
  store i32 1, ptr %base1, align 4
  br label %bb15

bb11:                                             ; preds = %bb9
  %_24 = load i32, ptr %exp, align 4
  %_23 = urem i32 %_24, 2
  %_22 = icmp ne i32 %_23, 0
  br i1 %_22, label %bb13, label %bb14

bb13:                                             ; preds = %bb11
  store i32 -1, ptr %base1, align 4
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_27 = load i32, ptr %base1, align 4
; call <i32>::unbounded_shl
  %_26 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unbounded_shlCsiVdchs2Ysr_16overflow_pow_i32(i32 %_27, i32 %shift) #14
  %_31 = load i32, ptr %base1, align 4
; call <i32>::shl_exact
  %61 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl9shl_exactCsiVdchs2Ysr_16overflow_pow_i32(i32 %_31, i32 %shift) #14
  %62 = extractvalue { i32, i32 } %61, 0
  %63 = extractvalue { i32, i32 } %61, 1
  store i32 %62, ptr %_30, align 4
  %64 = getelementptr inbounds i8, ptr %_30, i64 4
  store i32 %63, ptr %64, align 4
; call <core::option::Option<i32>>::is_none
  %_28 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE7is_noneCsiVdchs2Ysr_16overflow_pow_i32(ptr align 4 %_30) #14
  store i32 %_26, ptr %_0, align 4
  %65 = getelementptr inbounds i8, ptr %_0, i64 4
  %66 = zext i1 %_28 to i8
  store i8 %66, ptr %65, align 4
  br label %bb39

bb40:                                             ; No predecessors!
  unreachable
}

; <i32>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl3powCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %exp) unnamed_addr #0 !guid !30 {
start:
  %_0 = alloca [4 x i8], align 4
  br label %bb1

bb1:                                              ; preds = %start
; call <i32>::strict_pow
  %0 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl10strict_powCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %exp, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #14
  store i32 %0, ptr %_0, align 4
  br label %bb3

bb2:                                              ; No predecessors!
; call <i32>::wrapping_pow
  %1 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_powCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %exp) #14
  store i32 %1, ptr %_0, align 4
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i32, ptr %_0, align 4
  ret i32 %2
}

; <i32>::shl_exact
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl9shl_exactCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !31 {
start:
  %_0 = alloca [8 x i8], align 4
  %_0.i4 = call i32 @llvm.ctlz.i32(i32 %self, i1 false)
  %_3 = icmp ult i32 %rhs, %_0.i4
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_2.i = xor i32 %self, -1
  %_0.i = call i32 @llvm.ctlz.i32(i32 %_2.i, i1 false)
  %_5 = icmp ult i32 %rhs, %_0.i
  br i1 %_5, label %bb4, label %bb6

bb4:                                              ; preds = %bb2, %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiVdchs2Ysr_16overflow_pow_i32() #14
  br i1 %_3.i, label %bb2.i, label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

bb2.i:                                            ; preds = %bb4
; call <i32>::unchecked_shl::precondition_check
  call void @_RNvNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl18precondition_checkCsiVdchs2Ysr_16overflow_pow_i32(i32 %rhs, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #17
  br label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit: ; preds = %bb4, %bb2.i
  %_0.i2 = shl i32 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_0.i2, ptr %0, align 4
  store i32 1, ptr %_0, align 4
  br label %bb7

bb6:                                              ; preds = %bb2
  store i32 0, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit, %bb6
  %1 = load i32, ptr %_0, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  %3 = load i32, ptr %2, align 4
  %4 = insertvalue { i32, i32 } poison, i32 %1, 0
  %5 = insertvalue { i32, i32 } %4, i32 %3, 1
  ret { i32, i32 } %5
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsiVdchs2Ysr_16overflow_pow_i32(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !32 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsiVdchs2Ysr_16overflow_pow_i32(ptr %s.0, i64 %s.1) #14
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsiVdchs2Ysr_16overflow_pow_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !33 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u32>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm13checked_ilog2CsiVdchs2Ysr_16overflow_pow_i32(i32 %self) unnamed_addr #0 !guid !34 {
start:
  %_2 = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u32>>::new
  %0 = call i32 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE3newB9_(i32 %self) #14
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
  %2 = icmp eq i32 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i32, ptr %_2, align 4
; call <core::num::nonzero::NonZero<u32>>::ilog2
  %_5 = call i32 @_RNvMsU_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE5ilog2CsiVdchs2Ysr_16overflow_pow_i32(i32 %x) #14
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u32>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs6_NtCsl10jNU3mE6R_4core3numm5ilog2CsiVdchs2Ysr_16overflow_pow_i32(i32 %self, ptr align 8 %0) unnamed_addr #0 !guid !35 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u32>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm13checked_ilog2CsiVdchs2Ysr_16overflow_pow_i32(i32 %self) #14
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #16
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsiVdchs2Ysr_16overflow_pow_i32(ptr %self) unnamed_addr #0 !guid !36 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsiVdchs2Ysr_16overflow_pow_i32(i8 %0) unnamed_addr #0 !guid !37 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsiVdchs2Ysr_16overflow_pow_i32(ptr %self) #14
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u32>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsU_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE13leading_zerosCsiVdchs2Ysr_16overflow_pow_i32(i32 %self) unnamed_addr #0 !guid !38 {
start:
; call <core::num::nonzero::NonZero<u32>>::get
  %_2 = call i32 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE3getB9_(i32 %self) #14
  %_0 = call i32 @llvm.ctlz.i32(i32 %_2, i1 true)
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u32>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsU_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE5ilog2CsiVdchs2Ysr_16overflow_pow_i32(i32 %self) unnamed_addr #0 !guid !39 {
start:
; call <core::num::nonzero::NonZero<u32>>::leading_zeros
  %_3 = call i32 @_RNvMsU_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE13leading_zerosCsiVdchs2Ysr_16overflow_pow_i32(i32 %self) #14
  %_0 = sub i32 31, %_3
  ret i32 %_0
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsiVdchs2Ysr_16overflow_pow_i32() unnamed_addr #4 !guid !40 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiVdchs2Ysr_16overflow_pow_i32() unnamed_addr #0 !guid !41 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsiVdchs2Ysr_16overflow_pow_i32() #14
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; <i32>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl18precondition_checkCsiVdchs2Ysr_16overflow_pow_i32(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !42 {
start:
  %_2 = icmp ult i32 %rhs, 32
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsiVdchs2Ysr_16overflow_pow_i32(ptr @alloc_eea3b4108fd45221c9468d112de34f4d, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsiVdchs2Ysr_16overflow_pow_i32() unnamed_addr #0 !guid !43 {
start:
  ret i1 true
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsiVdchs2Ysr_16overflow_pow_i32() unnamed_addr #0 !guid !44 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsiVdchs2Ysr_16overflow_pow_i32(ptr %_1) unnamed_addr #0 !guid !45 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsiVdchs2Ysr_16overflow_pow_i32(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !46 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsiVdchs2Ysr_16overflow_pow_i32(ptr align 8 %_1) #14
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_debug::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuglECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <core::option::Option<i32>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE7is_someCsddYV2PBJW9h_3std(ptr align 4) unnamed_addr #0

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #7

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctpop.i32(i32) #9

; <core::num::nonzero::NonZero<u32>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i32 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE3newB9_(i32) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #7

; <core::num::nonzero::NonZero<u32>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i32 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE3getB9_(i32) unnamed_addr #0

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #11

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #12

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #13 !guid !47 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsiVdchs2Ysr_16overflow_pow_i32(ptr @_RNvCsiVdchs2Ysr_16overflow_pow_i324main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { nonlazybind "target-cpu"="x86-64" }
attributes #14 = { inlinehint }
attributes #15 = { noinline }
attributes #16 = { noreturn }
attributes #17 = { inlinehint nounwind }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noinline noreturn nounwind }

!llvm.module.flags = !{!6, !7, !8, !9}
!llvm.ident = !{!10}

!0 = !{i64 -8946218085210493607}
!1 = !{i64 -5444282635201743589}
!2 = !{i64 -4975822998227846929}
!3 = !{i64 8758326712794271963}
!4 = !{i64 2526345752683170315}
!5 = !{i64 669081011046102492}
!6 = !{i32 8, !"PIC Level", i32 2}
!7 = !{i32 7, !"PIE Level", i32 2}
!8 = !{i32 2, !"RtLibUseGOT", i32 1}
!9 = !{i32 7, !"uwtable", i32 2}
!10 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!11 = !{i64 4163100134177476229}
!12 = !{i64 5666944183647004678}
!13 = !{i64 954378673210961614}
!14 = !{i64 6605394323004918531}
!15 = !{i64 1312696624785857}
!16 = !{i64 8864377340745910510}
!17 = !{i64 1532373845396453163}
!18 = !{i64 -8914562986439953935}
!19 = !{i64 8729933288994662680}
!20 = !{i64 5830750975954381280}
!21 = !{i64 -3953145771608877410}
!22 = !{i64 -1837610030518498653}
!23 = !{i64 -444756683740570836}
!24 = !{i64 2058088138352412365}
!25 = !{i64 -7025971529549953400}
!26 = !{i64 -8937782015696981025}
!27 = !{i64 7329387822135980775}
!28 = !{i64 7608097896408445135}
!29 = !{i64 426600849736472344}
!30 = !{i64 -4738416750826208921}
!31 = !{i64 4321843223791954637}
!32 = !{i64 7780405297205309445}
!33 = !{i64 -1592226685947692284}
!34 = !{i64 2018100787311383789}
!35 = !{i64 8405953572478381172}
!36 = !{i64 2557327727008041603}
!37 = !{i64 5090613101875974422}
!38 = !{i64 3386159268384748820}
!39 = !{i64 -5417803925926022857}
!40 = !{i64 -4997871387460529518}
!41 = !{i64 -2404301453411615954}
!42 = !{i64 -3219797233488434521}
!43 = !{i64 1725386900126288163}
!44 = !{i64 3505953976764858549}
!45 = !{i64 -6951652142511571585}
!46 = !{i64 2789813136547529769}
!47 = !{i64 -2624081020897602054}
