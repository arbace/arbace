; ModuleID = 'panic_vec_remove.26560aadd4f5248a-cgu.0'
source_filename = "panic_vec_remove.26560aadd4f5248a-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs3i3QXdlBbp6_16panic_vec_remove, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs3i3QXdlBbp6_16panic_vec_remove, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs3i3QXdlBbp6_16panic_vec_remove }>, align 8, !guid !4
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !5
@alloc_9c04098d1f5b2a23ccf9ca333796c0a8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\8C\02\00\00\09\00\00\00" }>, align 8, !guid !6
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !7
@alloc_9056df8dbd39f1dba79e981a380e9d47 = private unnamed_addr constant [40 x i8] c"test/rust/synthetic/panic-vec-remove.rs\00", align 1, !guid !8
@alloc_5ec4f150542bb57dedb76fd09eb4234c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9056df8dbd39f1dba79e981a380e9d47, [16 x i8] c"'\00\00\00\00\00\00\00\06\00\00\00\11\00\00\00" }>, align 8, !guid !9
@alloc_3c696d18ab12c8f21bd02439fff0d343 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9056df8dbd39f1dba79e981a380e9d47, [16 x i8] c"'\00\00\00\00\00\00\00\06\00\00\00\1C\00\00\00" }>, align 8, !guid !10
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !11
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !12
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !13
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !14
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !15
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !16
@alloc_d57f55e9b6af1701fd9de9702359cd82 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\8B\09\00\00-\00\00\00" }>, align 8, !guid !17
@alloc_df8cf2a5a5c89ca4f9f99c5bd84f5957 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\8E\09\00\00\17\00\00\00" }>, align 8, !guid !18
@alloc_0d77a59642c5a3c35311ff5ab8da5ad9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\91\09\00\00\1F\00\00\00" }>, align 8, !guid !19
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !20
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !21
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !22
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !23
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !24
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !25
@alloc_5ee6cd0de5bab89c84438a39fb5fb08c = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: ptr::copy requires that both pointer arguments are aligned and non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !26

; <[i32]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSl8into_vecNtNtB5_5alloc6GlobalECs3i3QXdlBbp6_16panic_vec_remove(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !32 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[i32]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlE23into_raw_with_allocatorCs3i3QXdlBbp6_16panic_vec_remove(ptr align 4 %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<i32>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE17from_raw_parts_inCs3i3QXdlBbp6_16panic_vec_remove(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[i32]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #15
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #16
  unreachable
}

; <core::mem::alignment::Alignment>::of_val_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSlECs3i3QXdlBbp6_16panic_vec_remove(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !33 {
start:
; call core::mem::align_of_val_raw::<[i32]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSlECs3i3QXdlBbp6_16panic_vec_remove(ptr %val.0, i64 %val.1) #17
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs3i3QXdlBbp6_16panic_vec_remove(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #17
  ret i64 %_0
}

; <core::alloc::layout::Layout>::for_value_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSlECs3i3QXdlBbp6_16panic_vec_remove(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !34 {
start:
; call core::mem::size_of_val_raw::<[i32]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSlECs3i3QXdlBbp6_16panic_vec_remove(ptr %val.0, i64 %val.1) #17
; call <core::mem::alignment::Alignment>::of_val_raw::<[i32]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSlECs3i3QXdlBbp6_16panic_vec_remove(ptr %val.0, i64 %val.1) #17
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs3i3QXdlBbp6_16panic_vec_remove(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #17
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<[i32]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSlE4casthECs3i3QXdlBbp6_16panic_vec_remove(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !35 {
start:
; call <core::ptr::non_null::NonNull<[i32]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4casthECs3i3QXdlBbp6_16panic_vec_remove(ptr %self.0, i64 %self.1) #17
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castlECs3i3QXdlBbp6_16panic_vec_remove(ptr %self) unnamed_addr #0 !guid !36 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<i32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castlECs3i3QXdlBbp6_16panic_vec_remove(ptr %self) #17
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[i32]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4casthECs3i3QXdlBbp6_16panic_vec_remove(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !37 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<u8>>::cast::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castlECs3i3QXdlBbp6_16panic_vec_remove(ptr %self) unnamed_addr #0 !guid !38 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrlECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !39 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<i32>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nulllECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #17
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nulllECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !40 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<i32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castlECs3i3QXdlBbp6_16panic_vec_remove(ptr %_3) #17
; call <core::ptr::unique::Unique<i32>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquelE15as_non_null_ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr %_2) #17
  ret ptr %_0
}

; alloc::raw_vec::new_cap::<i32>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_caplECs3i3QXdlBbp6_16panic_vec_remove(i64 %cap) unnamed_addr #1 !guid !41 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs3i3QXdlBbp6_16panic_vec_remove(i64 %cap) #17
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs3i3QXdlBbp6_16panic_vec_remove(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !42 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::mem::size_of_val_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSlECs3i3QXdlBbp6_16panic_vec_remove(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !43 {
start:
  %_0 = mul nuw nsw i64 %val.1, 4
  ret i64 %_0
}

; core::mem::align_of_val_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSlECs3i3QXdlBbp6_16panic_vec_remove(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !44 {
start:
  %0 = mul nuw nsw i64 %val.1, 4
  ret i64 4
}

; core::ptr::slice_from_raw_parts_mut::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECs3i3QXdlBbp6_16panic_vec_remove(ptr %data, i64 %len) unnamed_addr #0 !guid !45 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[i32], i32>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSllECs3i3QXdlBbp6_16panic_vec_remove(ptr %data, i64 %len) #17
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<alloc::vec::Vec<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !46 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<i32> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeclEECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1) #15
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeclEECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #16
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<[i32]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !47 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[i32]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1) #17
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<[i32]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1) #15
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #16
  unreachable

bb2:                                              ; preds = %bb4
  %3 = load ptr, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8
  %6 = insertvalue { ptr, i32 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i32 } %6, i32 %5, 1
  resume { ptr, i32 } %7
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeclEECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1) unnamed_addr #1 !guid !48 {
start:
; call <alloc::raw_vec::RawVec<i32> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECs3i3QXdlBbp6_16panic_vec_remove(i64 %dummy) unnamed_addr #0 !guid !49 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !50
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs3i3QXdlBbp6_16panic_vec_remove(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !51 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs3i3QXdlBbp6_16panic_vec_remove(ptr %f) #17
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #17
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts_mut::<[i32], i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSllECs3i3QXdlBbp6_16panic_vec_remove(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !52 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1) unnamed_addr #0 !guid !53 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs3i3QXdlBbp6_16panic_vec_remove(ptr %_4) #18
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs3i3QXdlBbp6_16panic_vec_remove() #17
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs3i3QXdlBbp6_16panic_vec_remove(i8 %_2) #17
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs3i3QXdlBbp6_16panic_vec_remove(ptr %_1) unnamed_addr #0 !guid !54 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs3i3QXdlBbp6_16panic_vec_remove(ptr %0) #17
  ret i32 %_0
}

; panic_vec_remove::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs3i3QXdlBbp6_16panic_vec_remove4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !55 {
start:
  %0 = alloca [16 x i8], align 8
  %v = alloca [24 x i8], align 8
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs3i3QXdlBbp6_16panic_vec_remove(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #17
  %_2.0 = extractvalue { ptr, ptr } %1, 0
  %_2.1 = extractvalue { ptr, ptr } %1, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call alloc::boxed::box_new_uninit
  %_1.i = call align 4 ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs3i3QXdlBbp6_16panic_vec_remove(i64 4, i64 4) #17
  %_12 = ptrtoint ptr %_1.i to i64
  %_14 = and i64 %_12, 3
  %_15 = icmp eq i64 %_14, 0
  br i1 %_15, label %bb12, label %panic

bb12:                                             ; preds = %start
  %_17 = ptrtoint ptr %_1.i to i64
  %_19 = icmp eq i64 %_17, 0
  %_20 = and i1 %_19, true
  %_21 = xor i1 %_20, true
  br i1 %_21, label %bb13, label %panic1

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 4, i64 %_12, ptr align 8 @alloc_5ec4f150542bb57dedb76fd09eb4234c) #19
  unreachable

bb13:                                             ; preds = %bb12
  %2 = getelementptr inbounds nuw i32, ptr %_1.i, i64 0
  store i32 1, ptr %2, align 4
; call <[i32]>::into_vec::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSl8into_vecNtNtB5_5alloc6GlobalECs3i3QXdlBbp6_16panic_vec_remove(ptr sret([24 x i8]) align 8 %v, ptr align 4 %_1.i, i64 1) #17
; invoke core::hint::black_box::<usize>
  %_7 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECs3i3QXdlBbp6_16panic_vec_remove(i64 3)
          to label %bb5 unwind label %cleanup

panic1:                                           ; preds = %bb12
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_5ec4f150542bb57dedb76fd09eb4234c) #19
  unreachable

bb10:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %v) #15
          to label %bb11 unwind label %terminate

cleanup:                                          ; preds = %bb7, %bb6, %bb5, %bb13
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb10

bb5:                                              ; preds = %bb13
; invoke <alloc::vec::Vec<i32>>::remove
  %_5 = invoke i32 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE6removeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %v, i64 %_7, ptr align 8 @alloc_3c696d18ab12c8f21bd02439fff0d343)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
; invoke <core::fmt::Arguments>::from_str
  %7 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs3i3QXdlBbp6_16panic_vec_remove(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
  %_9.0 = extractvalue { ptr, ptr } %7, 0
  %_9.1 = extractvalue { ptr, ptr } %7, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
; call core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %v)
  ret void

terminate:                                        ; preds = %bb10
  %8 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #16
  unreachable

bb11:                                             ; preds = %bb10
  %9 = load ptr, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { ptr, i32 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i32 } %12, i32 %11, 1
  resume { ptr, i32 } %13
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs3i3QXdlBbp6_16panic_vec_remove(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !56 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE3newCs3i3QXdlBbp6_16panic_vec_remove(ptr align 4 %x.0, i64 %x.1) unnamed_addr #1 !guid !57 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_mutCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #1 !guid !58 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_refCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #1 !guid !59 {
start:
  ret ptr %self
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs3i3QXdlBbp6_16panic_vec_remove(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !60 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs3i3QXdlBbp6_16panic_vec_remove() #17
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(i64 %align, ptr align 8 %0) #20
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs3i3QXdlBbp6_16panic_vec_remove(i64 %self) unnamed_addr #0 !guid !61 {
start:
  ret i64 %self
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !62 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs3i3QXdlBbp6_16panic_vec_remove(i64 %_3) #17
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #17
  ret ptr %_0
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs3i3QXdlBbp6_16panic_vec_remove(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !63 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(i64 %size, i64 %alignment, ptr align 8 %0) #20
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !64 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !65 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs3i3QXdlBbp6_16panic_vec_remove(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !66 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs3i3QXdlBbp6_16panic_vec_remove(i64 %3, i64 %5, i1 zeroext %8) #17
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs3i3QXdlBbp6_16panic_vec_remove(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !67 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs3i3QXdlBbp6_16panic_vec_remove(ptr %2, i64 %4, i64 %6) #17
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs3i3QXdlBbp6_16panic_vec_remove(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !68 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #17
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs3i3QXdlBbp6_16panic_vec_remove(i64 %11, i64 %13) #17
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs3i3QXdlBbp6_16panic_vec_remove(i64 %15, i64 %17) #17
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #17
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #17
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #17
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #17
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #17
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !69 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %3, i64 %5) #17
  br label %bb3
}

; <alloc::raw_vec::RawVec<i32>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE17from_raw_parts_inCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !70 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<i32>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_caplECs3i3QXdlBbp6_16panic_vec_remove(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr %ptr, i64 %capacity2) #17
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<i32>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE3ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !71 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<i32>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrlECs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #17
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<i32>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE8capacityCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !72 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 4) #17
  ret i64 %_0
}

; <core::ptr::unique::Unique<[i32]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSlE6as_ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !73 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::unique::Unique<i32>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquelE15as_non_null_ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr %self) unnamed_addr #0 !guid !74 {
start:
  ret ptr %self
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs3i3QXdlBbp6_16panic_vec_remove(i64 %val) unnamed_addr #0 !guid !75 {
start:
  ret i64 %val
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs3i3QXdlBbp6_16panic_vec_remove(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !76 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs3i3QXdlBbp6_16panic_vec_remove(ptr %s.0, i64 %s.1) #17
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <alloc::boxed::Box<[i32]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlE23into_raw_with_allocatorCs3i3QXdlBbp6_16panic_vec_remove(ptr align 4 %b.0, i64 %b.1) unnamed_addr #0 !guid !77 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE3newCs3i3QXdlBbp6_16panic_vec_remove(ptr align 4 %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_mutCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_refCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs3i3QXdlBbp6_16panic_vec_remove(ptr %self) unnamed_addr #0 !guid !78 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs3i3QXdlBbp6_16panic_vec_remove(i8 %0) unnamed_addr #0 !guid !79 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs3i3QXdlBbp6_16panic_vec_remove(ptr %self) #17
  ret i32 %_0
}

; <alloc::vec::Vec<i32>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !80 {
start:
; call <alloc::raw_vec::RawVec<i32>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE3ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #17
  ret ptr %_0
}

; <alloc::vec::Vec<i32>>::try_remove
; Function Attrs: nonlazybind uwtable
define internal { i32, i32 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10try_removeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self, i64 %index) unnamed_addr #1 personality ptr @rust_eh_personality !guid !81 {
start:
  %_9.i = alloca [1 x i8], align 1
  %_19 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  store i8 0, ptr %_19, align 1
; call <alloc::vec::Vec<i32>>::len
  %len = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE3lenCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #17
  %_5 = icmp uge i64 %index, %len
  br i1 %_5, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <alloc::vec::Vec<i32>>::as_mut_ptr
  %_8 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #17
  br label %bb4

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb10

bb4:                                              ; preds = %bb3
  %_0.i2 = getelementptr inbounds nuw i32, ptr %_8, i64 %index
  br label %bb5

bb5:                                              ; preds = %bb4
  %_0.i = load i32, ptr %_0.i2, align 4
  br label %bb6

bb6:                                              ; preds = %bb5
  store i8 1, ptr %_19, align 1
  %_0.i1 = getelementptr inbounds nuw i32, ptr %_0.i2, i64 1
  br label %bb7

bb7:                                              ; preds = %bb6
  %_15 = sub i64 %len, %index
  %_14 = sub i64 %_15, 1
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs3i3QXdlBbp6_16panic_vec_remove() #17
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr4copylECs3i3QXdlBbp6_16panic_vec_remove.exit

bb2.i:                                            ; preds = %bb7
  %0 = icmp eq i64 %_14, 0
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_9.i, align 1
  %2 = load i8, ptr %_9.i, align 1
  %3 = trunc nuw i8 %2 to i1
; call core::ptr::copy::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr4copy18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(ptr %_0.i1, ptr %_0.i2, i64 4, i1 zeroext %3, ptr align 8 @alloc_9c04098d1f5b2a23ccf9ca333796c0a8) #20
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr4copylECs3i3QXdlBbp6_16panic_vec_remove.exit

_RINvNtCsl10jNU3mE6R_4core3ptr4copylECs3i3QXdlBbp6_16panic_vec_remove.exit: ; preds = %bb7, %bb2.i
  %4 = mul nuw nsw i64 4, %_14
  call void @llvm.memmove.p0.p0.i64(ptr align 4 %_0.i2, ptr align 4 %_0.i1, i64 %4, i1 false)
  br label %bb8

bb8:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr4copylECs3i3QXdlBbp6_16panic_vec_remove.exit
  %_17 = sub i64 %len, 1
; call <alloc::vec::Vec<i32>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE7set_lenCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self, i64 %_17) #17
  br label %bb9

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_19, align 1
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_0.i, ptr %5, align 4
  store i32 1, ptr %_0, align 4
  store i8 0, ptr %_19, align 1
  br label %bb10

bb10:                                             ; preds = %bb2, %bb9
  %6 = load i32, ptr %_0, align 4
  %7 = getelementptr inbounds i8, ptr %_0, i64 4
  %8 = load i32, ptr %7, align 4
  %9 = insertvalue { i32, i32 } poison, i32 %6, 0
  %10 = insertvalue { i32, i32 } %9, i32 %8, 1
  ret { i32, i32 } %10

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<i32>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE17from_raw_parts_inCs3i3QXdlBbp6_16panic_vec_remove(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !82 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #20
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<i32>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE17from_raw_parts_inCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %capacity) #17
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<i32>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE3lenCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !83 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 2305843009213693951
  ret i64 %len
}

; <alloc::vec::Vec<i32>>::remove
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE6removeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 !guid !84 {
start:
  %_3 = alloca [8 x i8], align 4
; call <alloc::vec::Vec<i32>>::try_remove
  %1 = call { i32, i32 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10try_removeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self, i64 %index)
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_3, align 4
  %4 = getelementptr inbounds i8, ptr %_3, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_3, align 4
  %6 = getelementptr inbounds i8, ptr %_3, i64 4
  %7 = load i32, ptr %6, align 4
  %_4 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_4 to i1
  br i1 %8, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_3, i64 4
  %elem = load i32, ptr %9, align 4
  ret i32 %elem

bb3:                                              ; preds = %start
; call <alloc::vec::Vec<i32>>::len
  %_6 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE3lenCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #17
; call <alloc::vec::Vec<_, _>>::remove::assert_failed
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE6remove13assert_failed(i64 %index, i64 %_6, ptr align 8 %0) #21
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<i32>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE7set_lenCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !85 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<i32>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE8capacityCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #17
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #20
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<i32>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE8capacityCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !86 {
start:
; call <alloc::raw_vec::RawVec<i32>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE8capacityCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #17
  ret i64 %_0
}

; <*mut i32>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl10cast_sliceCs3i3QXdlBbp6_16panic_vec_remove(ptr %self, i64 %len) unnamed_addr #0 !guid !87 {
start:
; call core::ptr::slice_from_raw_parts_mut::<i32>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECs3i3QXdlBbp6_16panic_vec_remove(ptr %self, i64 %len) #17
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs3i3QXdlBbp6_16panic_vec_remove(i64 %0, i64 %1) unnamed_addr #0 !guid !88 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #22
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #22
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !89 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #22
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs3i3QXdlBbp6_16panic_vec_remove(i64 %0, i64 %1) unnamed_addr #0 !guid !90 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #22
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #22
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs3i3QXdlBbp6_16panic_vec_remove(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !91 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs3i3QXdlBbp6_16panic_vec_remove(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #17
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #23
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #17
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %align) unnamed_addr #0 !guid !92 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %align) #17
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs3i3QXdlBbp6_16panic_vec_remove() unnamed_addr #0 !guid !93 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs3i3QXdlBbp6_16panic_vec_remove() #17
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !94 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %align) #17
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr %ptr) #17
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(i64 %align, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !95 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #16
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs3i3QXdlBbp6_16panic_vec_remove(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !96 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #16
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs3i3QXdlBbp6_16panic_vec_remove(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !97 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs3i3QXdlBbp6_16panic_vec_remove(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #16
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !98 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs3i3QXdlBbp6_16panic_vec_remove(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #16
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; core::ptr::copy::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr4copy18precondition_checkCs3i3QXdlBbp6_16panic_vec_remove(ptr %src, ptr %dst, i64 %align, i1 zeroext %zero_size, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !99 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs3i3QXdlBbp6_16panic_vec_remove(ptr %src, i64 %align, i1 zeroext %zero_size)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #16
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs3i3QXdlBbp6_16panic_vec_remove(ptr @alloc_5ee6cd0de5bab89c84438a39fb5fb08c, i64 221)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs3i3QXdlBbp6_16panic_vec_remove(ptr %dst, i64 %align, i1 zeroext %zero_size)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr, i64 %align) unnamed_addr #0 !guid !100 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr %ptr, i64 %align) #17
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs3i3QXdlBbp6_16panic_vec_remove() unnamed_addr #0 !guid !101 {
start:
  ret i1 true
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs3i3QXdlBbp6_16panic_vec_remove(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !102 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs3i3QXdlBbp6_16panic_vec_remove(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #17
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs3i3QXdlBbp6_16panic_vec_remove(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !103 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs3i3QXdlBbp6_16panic_vec_remove(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #17
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #1 !guid !104 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 4, i64 4)
  ret void
}

; <alloc::boxed::Box<[i32]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #0 !guid !105 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[i32]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSlE6as_ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr.0, i64 %ptr.1) #17
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[i32]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSlECs3i3QXdlBbp6_16panic_vec_remove(ptr %_5.0, i64 %_5.1) #17
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %layout) #17
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[i32]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSlE4casthECs3i3QXdlBbp6_16panic_vec_remove(ptr %ptr.0, i64 %ptr.1) #17
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #17
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs3i3QXdlBbp6_16panic_vec_remove(ptr %_10, ptr %_11, i64 %6, i64 %8) #17
  br label %bb7
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs3i3QXdlBbp6_16panic_vec_remove() unnamed_addr #0 !guid !106 {
start:
  ret i8 0
}

; <alloc::vec::Vec<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) unnamed_addr #1 !guid !107 {
start:
; call <alloc::vec::Vec<i32>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %self) #17
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut i32>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl10cast_sliceCs3i3QXdlBbp6_16panic_vec_remove(ptr %_3, i64 %_4) #17
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs3i3QXdlBbp6_16panic_vec_remove(ptr %_1) unnamed_addr #0 !guid !108 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs3i3QXdlBbp6_16panic_vec_remove(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !109 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs3i3QXdlBbp6_16panic_vec_remove(ptr align 8 %_1) #17
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #4

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #5

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #6

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #5

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #5

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr, i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8, i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #7

; <alloc::vec::Vec<_, _>>::remove::assert_failed
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE6remove13assert_failed(i64, i64, ptr align 8) unnamed_addr #8

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #4

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #9

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #10

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #11

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #12

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr) unnamed_addr #0

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #5

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #13

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr, i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8, i64, i64) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #14 !guid !110 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs3i3QXdlBbp6_16panic_vec_remove(ptr @_RNvCs3i3QXdlBbp6_16panic_vec_remove4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { nonlazybind "target-cpu"="x86-64" }
attributes #15 = { cold }
attributes #16 = { cold noreturn nounwind }
attributes #17 = { inlinehint }
attributes #18 = { noinline }
attributes #19 = { noinline noreturn nounwind }
attributes #20 = { inlinehint nounwind }
attributes #21 = { noinline noreturn }
attributes #22 = { nounwind }
attributes #23 = { noreturn }

!llvm.module.flags = !{!27, !28, !29, !30}
!llvm.ident = !{!31}

!0 = !{i64 -5417293639910617812}
!1 = !{i64 -6508722420261176396}
!2 = !{i64 -8095021496141898586}
!3 = !{i64 -8894998008084868958}
!4 = !{i64 4685933328252153652}
!5 = !{i64 4818413385827989966}
!6 = !{i64 760879797709297504}
!7 = !{i64 8128670053435476176}
!8 = !{i64 2456516944639448587}
!9 = !{i64 -4864206368973780318}
!10 = !{i64 -609247578414527001}
!11 = !{i64 -8075628472909072155}
!12 = !{i64 8097311846394249711}
!13 = !{i64 -4495664655036244792}
!14 = !{i64 9058876032454680750}
!15 = !{i64 -1522736944410982704}
!16 = !{i64 -1531575812295516276}
!17 = !{i64 6154597600792557532}
!18 = !{i64 2659456313391214174}
!19 = !{i64 360238320539285771}
!20 = !{i64 -4457231333300356364}
!21 = !{i64 4608576297237116437}
!22 = !{i64 2993252128089787639}
!23 = !{i64 6745301468165842014}
!24 = !{i64 -7470054396392192773}
!25 = !{i64 -3505873968447275805}
!26 = !{i64 189022287780490113}
!27 = !{i32 8, !"PIC Level", i32 2}
!28 = !{i32 7, !"PIE Level", i32 2}
!29 = !{i32 2, !"RtLibUseGOT", i32 1}
!30 = !{i32 7, !"uwtable", i32 2}
!31 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!32 = !{i64 -1303214748058422082}
!33 = !{i64 -6951633654426639560}
!34 = !{i64 -5049543111692284049}
!35 = !{i64 1409656601889037955}
!36 = !{i64 4620772054551676037}
!37 = !{i64 5491659152389686735}
!38 = !{i64 -3184215312835924076}
!39 = !{i64 -217420973468672039}
!40 = !{i64 4069687178282386025}
!41 = !{i64 -7028059413501464403}
!42 = !{i64 1717693831975282934}
!43 = !{i64 2590342670830465222}
!44 = !{i64 6028931364533330222}
!45 = !{i64 1487247098947481627}
!46 = !{i64 -381837816733950735}
!47 = !{i64 -6070232519315433439}
!48 = !{i64 2013284170464449254}
!49 = !{i64 -4832828135476553939}
!50 = !{i64 1312700919753154}
!51 = !{i64 4967631176196738702}
!52 = !{i64 -7968825978538851854}
!53 = !{i64 -5260862625063367199}
!54 = !{i64 -7011478310281276939}
!55 = !{i64 2030224126348907436}
!56 = !{i64 -3750940557720150363}
!57 = !{i64 -1705393155302265488}
!58 = !{i64 3706974473529881802}
!59 = !{i64 4213048458653918186}
!60 = !{i64 -7372114170799642957}
!61 = !{i64 6676314879638897219}
!62 = !{i64 3196069452063933144}
!63 = !{i64 8027696548730174786}
!64 = !{i64 -8306738577029234757}
!65 = !{i64 66223077230077776}
!66 = !{i64 8627736141022835711}
!67 = !{i64 3930650111452144947}
!68 = !{i64 -1319721104263910654}
!69 = !{i64 -3163159649439498401}
!70 = !{i64 6471240814770960554}
!71 = !{i64 -1461392158959748047}
!72 = !{i64 -6087869202171401329}
!73 = !{i64 4184422362460724349}
!74 = !{i64 7441362039543185501}
!75 = !{i64 1834629359156685018}
!76 = !{i64 -1334617191325872649}
!77 = !{i64 -1707689107779349135}
!78 = !{i64 3208214598315598799}
!79 = !{i64 6599385435727348790}
!80 = !{i64 5263816539013477734}
!81 = !{i64 1594587050554522468}
!82 = !{i64 8096974465856993634}
!83 = !{i64 -926026640305245479}
!84 = !{i64 7051796120740674294}
!85 = !{i64 6224805219873683250}
!86 = !{i64 -5388230272465905839}
!87 = !{i64 -4909517151552733708}
!88 = !{i64 -5652706282557943136}
!89 = !{i64 7099670719405020635}
!90 = !{i64 -8865632731110686073}
!91 = !{i64 -4375415944305957773}
!92 = !{i64 1325152980927516983}
!93 = !{i64 7225653301569663706}
!94 = !{i64 -4958056099716118472}
!95 = !{i64 8248040699746628567}
!96 = !{i64 -6648355062337632126}
!97 = !{i64 -3571819539152914692}
!98 = !{i64 8780314054060073373}
!99 = !{i64 -6979266771635546564}
!100 = !{i64 7166954058230327366}
!101 = !{i64 7628239942076268664}
!102 = !{i64 -2102086720271612554}
!103 = !{i64 4850975809499501642}
!104 = !{i64 4704667858188902403}
!105 = !{i64 4420150182114542533}
!106 = !{i64 1794681288461266335}
!107 = !{i64 -1027486595765032767}
!108 = !{i64 -6201623587855238122}
!109 = !{i64 2505125161552034936}
!110 = !{i64 -2624081020897602054}
