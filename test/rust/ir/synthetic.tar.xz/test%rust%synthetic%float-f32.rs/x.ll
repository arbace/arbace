; ModuleID = 'float_f32.6378fa33d4e183ee-cgu.0'
source_filename = "float_f32.6378fa33d4e183ee-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs8xuo75rCwfG_9float_f32, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8xuo75rCwfG_9float_f32, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8xuo75rCwfG_9float_f32 }>, align 8, !guid !0
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !1
@alloc_5bb642ca6df5ad9ba078972a9d3a5201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !2
@alloc_8df3287b4fbc190437d91041421e919b = private unnamed_addr constant [30 x i8] c"core/src/iter/traits/accum.rs\00", align 1, !guid !3
@alloc_c9e69792a4316033abad0d4adaadd679 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8df3287b4fbc190437d91041421e919b, [16 x i8] c"\1D\00\00\00\00\00\00\00\D0\00\00\00\01\00\00\00" }>, align 8, !guid !4
@alloc_6a96e47ef75dbf6fc4eb5423ba7bb768 = private unnamed_addr constant [16 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !5
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_d4f9eee8b3859a4cb2c5427791046c70 = private unnamed_addr constant [13 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !7
@alloc_1de177168114d4a447b57eedc7626360 = private unnamed_addr constant [4 x i8] c"\00\00\C0\BF", align 4, !guid !8
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !9
@alloc_89ca5133652a5226da26adbdfa0e2f97 = private unnamed_addr constant [4 x i8] c"3.14", align 1, !guid !10
@alloc_13af184f83ea529683dab3456027e412 = private unnamed_addr constant [3 x i8] c"abc", align 1, !guid !11
@alloc_bb740835b54142edad8629f403440288 = private unnamed_addr constant [3 x i8] c"1e3", align 1, !guid !12
@alloc_6c433d3c07b7c6453f8a17b49b46c496 = private unnamed_addr constant [3 x i8] c"inf", align 1, !guid !13
@alloc_09041e75dc84c4f90838ba63407d8bea = private unnamed_addr constant [4 x i8] c"-nan", align 1, !guid !14
@alloc_6e6e78314388fe4f511b82ed72e9a0ae = private unnamed_addr constant [2 x i8] c".5", align 1, !guid !15
@alloc_6a4a4cf2fe98a583a56dc651d4feb763 = private unnamed_addr constant [8 x i8] c"\00\00\C0?\00\00 @", align 4, !guid !16
@alloc_4f9e0d52b704c48a48195dee1a39f8e6 = private unnamed_addr constant [36 x i8] c"\C7 \00\00y\08\00\03\00\01 \C7 \00\00\18\08\00\01\00\02| \C7 \00\00X\09\00\02\00\02|\0A\00", align 1, !guid !17
@alloc_d5393a73b9ab337550d973a0f32943c1 = private unnamed_addr constant [40 x i8] c"\C0\01 \C0\01 \C0\01 \C5 \00\00p\03\00\01 \C7 \00\00x\0A\00\02\00\01 \C1 \00 `\01 \C0\01\0A\00", align 1, !guid !18
@alloc_cccb6efcb3e8ed52cc9a761656499c1c = private unnamed_addr constant [20 x i8] c"core/src/num/f32.rs\00", align 1, !guid !19
@alloc_64c10d70f810eee046206a21c0dd1f68 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cccb6efcb3e8ed52cc9a761656499c1c, [16 x i8] c"\13\00\00\00\00\00\00\00E\06\00\00\09\00\00\00" }>, align 8, !guid !20
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !21
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !22
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !23
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !24
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !25
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !26
@alloc_30f7ecc1496f966bde691d01731e6f8e = private unnamed_addr constant [49 x i8] c"$min > max, or either was NaN. min = \C0\08, max = \C0\00", align 1, !guid !27
@alloc_a9c61c9f249d39e49475c00b6de04ee0 = private unnamed_addr constant [4 x i8] c"Less", align 1, !guid !28
@alloc_cd17b9cbc635e79a5454e667c96efc06 = private unnamed_addr constant [5 x i8] c"Equal", align 1, !guid !29
@alloc_a2975b4a9399ac4e26287fc3f00ae96d = private unnamed_addr constant [7 x i8] c"Greater", align 1, !guid !30
@alloc_252aee8158a2b6b4b1e300c3f8f7bd7a = private unnamed_addr constant [15 x i8] c"ParseFloatError", align 1, !guid !31
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !32
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse14FloatErrorKindNtB6_5Debug3fmtCs8xuo75rCwfG_9float_f32 }>, align 8, !guid !33
@alloc_59ba7b9f7211443cd55a366616eef46a = private unnamed_addr constant [5 x i8] c"Empty", align 1, !guid !34
@alloc_6693e43df3406efcf64b4ab3d59228bb = private unnamed_addr constant [7 x i8] c"Invalid", align 1, !guid !35
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !36
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs8xuo75rCwfG_9float_f32 }>, align 8, !guid !37
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !38
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse15ParseFloatErrorNtB6_5Debug3fmtCs8xuo75rCwfG_9float_f32 }>, align 8, !guid !39
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRfNtB6_5Debug3fmtCs8xuo75rCwfG_9float_f32 }>, align 8, !guid !40

; <str>::parse::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsefECs8xuo75rCwfG_9float_f32(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !46 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <f32 as core::str::traits::FromStr>::from_str
  %1 = call i64 @_RNvXs1_NtNtCsl10jNU3mE6R_4core3num11float_parsefNtNtNtB9_3str6traits7FromStr8from_str(ptr %self.0, i64 %self.1) #12
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <core::result::Result<f32, core::num::float_parse::ParseFloatError>>::map::<bool, float_f32::main::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultfNtNtNtB5_3num11float_parse15ParseFloatErrorE3mapbNCNvCs8xuo75rCwfG_9float_f324main0EB1A_(i64 %0) unnamed_addr #0 !guid !47 {
start:
  %_9 = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %1 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 4
  store i64 %0, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %self, ptr align 8 %1, i64 8, i1 false)
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %2 = load i8, ptr %self, align 4
  %3 = trunc nuw i8 %2 to i1
  %_3 = zext i1 %3 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  %6 = load i8, ptr %5, align 1
  %e = trunc nuw i8 %6 to i1
  %7 = getelementptr inbounds i8, ptr %_0, i64 1
  %8 = zext i1 %e to i8
  store i8 %8, ptr %7, align 1
  store i8 1, ptr %_0, align 1
  br label %bb7

bb3:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %self, i64 4
  %t = load float, ptr %9, align 4
  store i8 0, ptr %_9, align 1
; call float_f32::main::{closure#0}
  %_5 = call zeroext i1 @_RNCNvCs8xuo75rCwfG_9float_f324main0B3_(float %t) #13
  %10 = getelementptr inbounds i8, ptr %_0, i64 1
  %11 = zext i1 %_5 to i8
  store i8 %11, ptr %10, align 1
  store i8 0, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %12 = load i8, ptr %_9, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %14 = load i8, ptr %_0, align 1
  %15 = trunc nuw i8 %14 to i1
  %16 = getelementptr inbounds i8, ptr %_0, i64 1
  %17 = load i8, ptr %16, align 1
  %18 = insertvalue { i1, i8 } poison, i1 %15, 0
  %19 = insertvalue { i1, i8 } %18, i8 %17, 1
  ret { i1, i8 } %19

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !48 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs8xuo75rCwfG_9float_f32(ptr %x) #13
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !49 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs8xuo75rCwfG_9float_f32(ptr align 4 %x) #13
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !50 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCs8xuo75rCwfG_9float_f32(ptr align 16 %x) #13
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !51 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs8xuo75rCwfG_9float_f32(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_exp::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !52 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs8xuo75rCwfG_9float_f32(ptr align 4 %x) #13
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs4_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_8LowerExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_exp::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_expfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !53 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs8xuo75rCwfG_9float_f32(ptr align 4 %x) #13
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs5_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_8UpperExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<bool, core::num::float_parse::ParseFloatError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultbNtNtNtB7_3num11float_parse15ParseFloatErrorEECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !54 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<bool, core::num::float_parse::ParseFloatError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultbNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCs8xuo75rCwfG_9float_f32(ptr %x) #13
; call <core::ptr::non_null::NonNull<core::result::Result<bool, core::num::float_parse::ParseFloatError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultbNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultbNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<f32, core::num::float_parse::ParseFloatError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultfNtNtNtB7_3num11float_parse15ParseFloatErrorEECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !55 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<f32, core::num::float_parse::ParseFloatError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultfNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCs8xuo75rCwfG_9float_f32(ptr align 4 %x) #13
; call <core::ptr::non_null::NonNull<core::result::Result<f32, core::num::float_parse::ParseFloatError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultfNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultfNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::cmp::Ordering>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_3cmp8OrderingECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !56 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::cmp::Ordering>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_3cmp8OrderingE8from_refCs8xuo75rCwfG_9float_f32(ptr %x) #13
; call <core::ptr::non_null::NonNull<core::cmp::Ordering>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_3cmp8OrderingE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtCsl10jNU3mE6R_4core3cmpNtB5_8OrderingNtNtB7_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !57 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs8xuo75rCwfG_9float_f32(ptr %x) #13
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs8xuo75rCwfG_9float_f32, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !58 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs8xuo75rCwfG_9float_f32(ptr align 4 %x) #13
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs8xuo75rCwfG_9float_f32(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs2_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_5Debug3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::result::Result<bool, core::num::float_parse::ParseFloatError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultbNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECs8xuo75rCwfG_9float_f32(ptr %self) unnamed_addr #0 !guid !59 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<f32, core::num::float_parse::ParseFloatError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultfNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECs8xuo75rCwfG_9float_f32(ptr %self) unnamed_addr #0 !guid !60 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::cmp::Ordering>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_3cmp8OrderingE4castuECs8xuo75rCwfG_9float_f32(ptr %self) unnamed_addr #0 !guid !61 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[f32]>>::cast::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSfE4castfECs8xuo75rCwfG_9float_f32(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !62 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs8xuo75rCwfG_9float_f32(ptr %self) unnamed_addr #0 !guid !63 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs8xuo75rCwfG_9float_f32(ptr %self) unnamed_addr #0 !guid !64 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECs8xuo75rCwfG_9float_f32(ptr %self) unnamed_addr #0 !guid !65 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs8xuo75rCwfG_9float_f32(ptr %self) unnamed_addr #0 !guid !66 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<16, 5>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECs8xuo75rCwfG_9float_f32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !67 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<36, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj24_Kj3_ECs8xuo75rCwfG_9float_f32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !68 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<40, 7>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj28_Kj7_ECs8xuo75rCwfG_9float_f32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !69 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8xuo75rCwfG_9float_f32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !70 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs8xuo75rCwfG_9float_f32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !71 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs8xuo75rCwfG_9float_f32(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !72 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs8xuo75rCwfG_9float_f32(double %dummy) unnamed_addr #0 !guid !73 {
start:
  %_0 = alloca [8 x i8], align 8
  store double %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load double, ptr %_0, align 8
  ret double %0
}

; core::hint::black_box::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float %dummy) unnamed_addr #0 !guid !75 {
start:
  %_0 = alloca [4 x i8], align 4
  store float %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load float, ptr %_0, align 4
  ret float %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs8xuo75rCwfG_9float_f32(i32 %dummy) unnamed_addr #0 !guid !76 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8xuo75rCwfG_9float_f32(i32 %dummy) unnamed_addr #0 !guid !77 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs8xuo75rCwfG_9float_f32(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !78 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8xuo75rCwfG_9float_f32(ptr %f) #13
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #13
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::iter::adapters::map::map_fold::<&f32, f32, f32, <f32 as core::clone::Clone>::clone, <f32>::max>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRfffNvYfNtNtB8_5clone5Clone5cloneNvMNtB8_3f32f3maxECs8xuo75rCwfG_9float_f32() unnamed_addr #1 !guid !79 {
start:
  ret void
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<f32>, <f32 as core::clone::Clone>::clone> as core::iter::traits::iterator::Iterator>::fold::<f32, <f32>::max>
; Function Attrs: nonlazybind uwtable
define internal float @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterfENvYfNtNtBc_5clone5Clone5cloneENtNtNtBa_6traits8iterator8Iterator4foldfNvMNtBc_3f32f3maxECs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1, float %init) unnamed_addr #1 personality ptr @rust_eh_personality !guid !80 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
; call core::iter::adapters::map::map_fold::<&f32, f32, f32, <f32 as core::clone::Clone>::clone, <f32>::max>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRfffNvYfNtNtB8_5clone5Clone5cloneNvMNtB8_3f32f3maxECs8xuo75rCwfG_9float_f32()
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::fold::<f32, core::iter::adapters::map::map_fold<&f32, f32, f32, <f32 as core::clone::Clone>::clone, <f32>::max>::{closure#0}>
  %_0 = call float @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterfENtNtNtNtBb_4iter6traits8iterator8Iterator4foldfNCINvNtNtBY_8adapters3map8map_foldRfffNvYfNtNtBb_5clone5Clone5cloneNvMNtBb_3f32f3maxE0ECs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1, float %init) #13
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_9, align 1
  ret float %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <f32 as core::iter::traits::accum::Sum<&f32>>::sum::<core::slice::iter::Iter<f32>>
; Function Attrs: nonlazybind uwtable
define internal float @_RINvXs24_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumfINtB7_3SumRfE3sumINtNtNtBd_5slice4iter4IterfEECs8xuo75rCwfG_9float_f32(ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !81 {
start:
; call <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::fold::<f32, <f32 as core::iter::traits::accum::Sum<&f32>>::sum<core::slice::iter::Iter<f32>>::{closure#0}>
  %_0 = call float @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterfENtNtNtNtBb_4iter6traits8iterator8Iterator4foldfNCINvXs24_NtBW_5accumfINtB1N_3SumRfE3sumBF_E0ECs8xuo75rCwfG_9float_f32(ptr %iter.0, ptr %iter.1, float -0.000000e+00) #13
  ret float %_0
}

; <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::fold::<f32, core::iter::adapters::map::map_fold<&f32, f32, f32, <f32 as core::clone::Clone>::clone, <f32>::max>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterfENtNtNtNtBb_4iter6traits8iterator8Iterator4foldfNCINvNtNtBY_8adapters3map8map_foldRfffNvYfNtNtBb_5clone5Clone5cloneNvMNtBb_3f32f3maxE0ECs8xuo75rCwfG_9float_f32(ptr %0, ptr %1, float %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !82 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %acc = alloca [4 x i8], align 4
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %f = alloca [0 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %3, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<f32> as core::cmp::PartialEq>::eq
  %4 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfENtNtB9_3cmp9PartialEq2eqCs8xuo75rCwfG_9float_f32(ptr align 8 %self, ptr align 8 %end) #13
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %6 = load i8, ptr %_4, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store float %init, ptr %acc, align 4
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store float %init, ptr %_0, align 4
  br label %bb16

bb8:                                              ; preds = %bb6
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %8, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<f32>>::offset_from_unsigned
  %9 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE20offset_from_unsignedCs8xuo75rCwfG_9float_f32(ptr %_17, ptr %_18) #13
  store i64 %9, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_22 = load float, ptr %acc, align 4
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw float, ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call core::iter::adapters::map::map_fold::<&f32, f32, f32, <f32 as core::clone::Clone>::clone, <f32>::max>::{closure#0}
  %_19 = call float @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRfffNvYfNtNtBa_5clone5Clone5cloneNvMNtBa_3f32f3maxE0Cs8xuo75rCwfG_9float_f32(ptr %f, float %_22, ptr align 4 %_3.i) #13
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  store float %_19, ptr %acc, align 4
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8xuo75rCwfG_9float_f32() #13
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs8xuo75rCwfG_9float_f32(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #14
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  %10 = load float, ptr %acc, align 4
  store float %10, ptr %_0, align 4
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  %11 = load float, ptr %_0, align 4
  ret float %11

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::fold::<f32, <f32 as core::iter::traits::accum::Sum<&f32>>::sum<core::slice::iter::Iter<f32>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterfENtNtNtNtBb_4iter6traits8iterator8Iterator4foldfNCINvXs24_NtBW_5accumfINtB1N_3SumRfE3sumBF_E0ECs8xuo75rCwfG_9float_f32(ptr %0, ptr %1, float %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !83 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %acc = alloca [4 x i8], align 4
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %f = alloca [0 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %3, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<f32> as core::cmp::PartialEq>::eq
  %4 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfENtNtB9_3cmp9PartialEq2eqCs8xuo75rCwfG_9float_f32(ptr align 8 %self, ptr align 8 %end) #13
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %6 = load i8, ptr %_4, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store float %init, ptr %acc, align 4
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store float %init, ptr %_0, align 4
  br label %bb16

bb8:                                              ; preds = %bb6
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %8, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<f32>>::offset_from_unsigned
  %9 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE20offset_from_unsignedCs8xuo75rCwfG_9float_f32(ptr %_17, ptr %_18) #13
  store i64 %9, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_22 = load float, ptr %acc, align 4
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw float, ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call <f32 as core::iter::traits::accum::Sum<&f32>>::sum::<core::slice::iter::Iter<f32>>::{closure#0}
  %_19 = call float @_RNCINvXs24_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumfINtB9_3SumRfE3sumINtNtNtBf_5slice4iter4IterfEE0Cs8xuo75rCwfG_9float_f32(ptr %f, float %_22, ptr align 4 %_3.i) #13
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  store float %_19, ptr %acc, align 4
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8xuo75rCwfG_9float_f32() #13
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs8xuo75rCwfG_9float_f32(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #14
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  %10 = load float, ptr %acc, align 4
  store float %10, ptr %_0, align 4
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  %11 = load float, ptr %_0, align 4
  ret float %11

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<f32>> as core::iter::traits::iterator::Iterator>::fold::<f32, <f32>::max>
; Function Attrs: nonlazybind uwtable
define internal float @_RINvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB5_6ClonedINtNtNtBb_5slice4iter4IterfEENtNtNtB9_6traits8iterator8Iterator4foldfNvMNtBb_3f32f3maxECs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1, float %init) unnamed_addr #1 personality ptr @rust_eh_personality !guid !84 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
; call <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::map::<f32, <f32 as core::clone::Clone>::clone>
  %0 = call { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterfENtNtNtNtBa_4iter6traits8iterator8Iterator3mapfNvYfNtNtBa_5clone5Clone5cloneECs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1) #13
  %_4.0 = extractvalue { ptr, ptr } %0, 0
  %_4.1 = extractvalue { ptr, ptr } %0, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<f32>, <f32 as core::clone::Clone>::clone> as core::iter::traits::iterator::Iterator>::fold::<f32, <f32>::max>
  %_0 = call float @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterfENvYfNtNtBc_5clone5Clone5cloneENtNtNtBa_6traits8iterator8Iterator4foldfNvMNtBc_3f32f3maxECs8xuo75rCwfG_9float_f32(ptr %_4.0, ptr %_4.1, float %init)
  br label %bb2

bb2:                                              ; preds = %bb1
  ret float %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::map::<f32, <f32 as core::clone::Clone>::clone>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterfENtNtNtNtBa_4iter6traits8iterator8Iterator3mapfNvYfNtNtBa_5clone5Clone5cloneECs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !85 {
start:
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<f32>, <f32 as core::clone::Clone>::clone>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4IterfENvYfNtNtB8_5clone5Clone5cloneE3newCs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::sum::<f32>
; Function Attrs: nonlazybind uwtable
define internal float @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterfENtNtNtNtBa_4iter6traits8iterator8Iterator3sumfECs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !86 {
start:
; call <f32 as core::iter::traits::accum::Sum<&f32>>::sum::<core::slice::iter::Iter<f32>>
  %_0 = call float @_RINvXs24_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumfINtB7_3SumRfE3sumINtNtNtBd_5slice4iter4IterfEECs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1)
  ret float %_0
}

; <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::cloned::<f32>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterfENtNtNtNtBa_4iter6traits8iterator8Iterator6clonedfECs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !87 {
start:
; call <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<f32>>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB2_6ClonedINtNtNtB8_5slice4iter4IterfEE3newCs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8xuo75rCwfG_9float_f32(ptr align 8 %_1) unnamed_addr #0 !guid !88 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs8xuo75rCwfG_9float_f32(ptr %_4) #12
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs8xuo75rCwfG_9float_f32() #13
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs8xuo75rCwfG_9float_f32(i8 %_2) #13
  ret i32 %_0
}

; core::iter::adapters::map::map_fold::<&f32, f32, f32, <f32 as core::clone::Clone>::clone, <f32>::max>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRfffNvYfNtNtBa_5clone5Clone5cloneNvMNtBa_3f32f3maxE0Cs8xuo75rCwfG_9float_f32(ptr %_1, float %acc, ptr align 4 %elt) unnamed_addr #0 personality ptr @rust_eh_personality !guid !89 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
; call <<f32 as core::clone::Clone>::clone as core::ops::function::FnMut<(&f32,)>>::call_mut
  %_7 = call float @_RNvYNvYfNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBa_3ops8function5FnMutTRfEE8call_mutCs8xuo75rCwfG_9float_f32(ptr %_1, ptr align 4 %elt) #13
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call <<f32>::max as core::ops::function::FnMut<(f32, f32)>>::call_mut
  %_0 = call float @_RNvYNvMNtCsl10jNU3mE6R_4core3f32f3maxINtNtNtB7_3ops8function5FnMutTffEE8call_mutCs8xuo75rCwfG_9float_f32(ptr %_1, float %acc, float %_7) #13
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_10, align 1
  ret float %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <f32 as core::iter::traits::accum::Sum<&f32>>::sum::<core::slice::iter::Iter<f32>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNCINvXs24_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumfINtB9_3SumRfE3sumINtNtNtBf_5slice4iter4IterfEE0Cs8xuo75rCwfG_9float_f32(ptr %_1, float %a, ptr align 4 %b) unnamed_addr #0 !guid !90 {
start:
; call <f32 as core::ops::arith::Add<&f32>>::add
  %_0 = call float @_RNvXsS_NtNtCsl10jNU3mE6R_4core3ops5arithfINtB5_3AddRfE3addCs8xuo75rCwfG_9float_f32(float %a, ptr align 4 %b, ptr align 8 @alloc_c9e69792a4316033abad0d4adaadd679) #13
  ret float %_0
}

; float_f32::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvCs8xuo75rCwfG_9float_f324main0B3_(float %x) unnamed_addr #0 !guid !91 {
start:
; call <f32>::is_nan
  %_0 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f6is_nanCs8xuo75rCwfG_9float_f32(float %x) #13
  ret i1 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs8xuo75rCwfG_9float_f32(ptr %_1) unnamed_addr #0 !guid !92 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8xuo75rCwfG_9float_f32(ptr %0) #13
  ret i32 %_0
}

; float_f32::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs8xuo75rCwfG_9float_f324main() unnamed_addr #1 !guid !93 {
start:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %3 = alloca [8 x i8], align 8
  %4 = alloca [8 x i8], align 8
  %5 = alloca [8 x i8], align 8
  %6 = alloca [8 x i8], align 8
  %_290 = alloca [16 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %_288 = alloca [16 x i8], align 8
  %args26 = alloca [48 x i8], align 8
  %args25 = alloca [24 x i8], align 8
  %_278 = alloca [16 x i8], align 8
  %_277 = alloca [16 x i8], align 8
  %args24 = alloca [32 x i8], align 8
  %_271 = alloca [4 x i8], align 4
  %_266 = alloca [4 x i8], align 4
  %_259 = alloca [16 x i8], align 8
  %_258 = alloca [16 x i8], align 8
  %args23 = alloca [32 x i8], align 8
  %_254 = alloca [16 x i8], align 16
  %_250 = alloca [8 x i8], align 8
  %_243 = alloca [16 x i8], align 8
  %_242 = alloca [16 x i8], align 8
  %_241 = alloca [16 x i8], align 8
  %args22 = alloca [48 x i8], align 8
  %_239 = alloca [4 x i8], align 4
  %_235 = alloca [1 x i8], align 1
  %_231 = alloca [1 x i8], align 1
  %args21 = alloca [24 x i8], align 8
  %_224 = alloca [16 x i8], align 8
  %_223 = alloca [16 x i8], align 8
  %_222 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_218 = alloca [4 x i8], align 4
  %_215 = alloca [4 x i8], align 4
  %_213 = alloca [4 x i8], align 4
  %_210 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_198 = alloca [4 x i8], align 4
  %_196 = alloca [4 x i8], align 4
  %_189 = alloca [16 x i8], align 8
  %_188 = alloca [16 x i8], align 8
  %_187 = alloca [16 x i8], align 8
  %args17 = alloca [48 x i8], align 8
  %_184 = alloca [8 x i8], align 4
  %_181 = alloca [8 x i8], align 4
  %_180 = alloca [2 x i8], align 1
  %_177 = alloca [8 x i8], align 4
  %args16 = alloca [24 x i8], align 8
  %_170 = alloca [16 x i8], align 8
  %_169 = alloca [16 x i8], align 8
  %_168 = alloca [16 x i8], align 8
  %args15 = alloca [48 x i8], align 8
  %_165 = alloca [8 x i8], align 4
  %_162 = alloca [8 x i8], align 4
  %_160 = alloca [1 x i8], align 1
  %_157 = alloca [8 x i8], align 4
  %args14 = alloca [24 x i8], align 8
  %_150 = alloca [16 x i8], align 8
  %_149 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [4 x i8], align 4
  %_142 = alloca [4 x i8], align 4
  %_135 = alloca [16 x i8], align 8
  %_134 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_131 = alloca [4 x i8], align 4
  %_124 = alloca [16 x i8], align 8
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_120 = alloca [4 x i8], align 4
  %_118 = alloca [4 x i8], align 4
  %_116 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_109 = alloca [16 x i8], align 8
  %_108 = alloca [16 x i8], align 8
  %_107 = alloca [16 x i8], align 8
  %_106 = alloca [16 x i8], align 8
  %args9 = alloca [64 x i8], align 8
  %_103 = alloca [4 x i8], align 4
  %_101 = alloca [4 x i8], align 4
  %_99 = alloca [4 x i8], align 4
  %_97 = alloca [4 x i8], align 4
  %args8 = alloca [32 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %_89 = alloca [16 x i8], align 8
  %_88 = alloca [16 x i8], align 8
  %_87 = alloca [16 x i8], align 8
  %args7 = alloca [64 x i8], align 8
  %_85 = alloca [4 x i8], align 4
  %_82 = alloca [4 x i8], align 4
  %_79 = alloca [4 x i8], align 4
  %_77 = alloca [4 x i8], align 4
  %args6 = alloca [32 x i8], align 8
  %a = alloca [4 x i8], align 4
  %_69 = alloca [16 x i8], align 8
  %_68 = alloca [16 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %args5 = alloca [48 x i8], align 8
  %_65 = alloca [1 x i8], align 1
  %_63 = alloca [1 x i8], align 1
  %_61 = alloca [1 x i8], align 1
  %args4 = alloca [24 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %_53 = alloca [16 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %_51 = alloca [16 x i8], align 8
  %_50 = alloca [16 x i8], align 8
  %args3 = alloca [80 x i8], align 8
  %_48 = alloca [1 x i8], align 1
  %_46 = alloca [1 x i8], align 1
  %_44 = alloca [4 x i8], align 4
  %args2 = alloca [40 x i8], align 8
  %inf = alloca [4 x i8], align 4
  %nan = alloca [4 x i8], align 4
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %_27 = alloca [16 x i8], align 8
  %_26 = alloca [16 x i8], align 8
  %_25 = alloca [16 x i8], align 8
  %_24 = alloca [16 x i8], align 8
  %args1 = alloca [112 x i8], align 8
  %args = alloca [56 x i8], align 8
  %x = alloca [4 x i8], align 4
  %_8 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %xs = alloca [48 x i8], align 4
  %7 = getelementptr inbounds nuw float, ptr %xs, i64 0
  store float 0.000000e+00, ptr %7, align 4
  %8 = getelementptr inbounds nuw float, ptr %xs, i64 1
  store float -0.000000e+00, ptr %8, align 4
  %9 = getelementptr inbounds nuw float, ptr %xs, i64 2
  store float 1.000000e+00, ptr %9, align 4
  %10 = getelementptr inbounds nuw float, ptr %xs, i64 3
  store float 1.000000e-01, ptr %10, align 4
  %11 = getelementptr inbounds nuw float, ptr %xs, i64 4
  store float f0x3EAAAAAB, ptr %11, align 4
  %12 = getelementptr inbounds nuw float, ptr %xs, i64 5
  store float f0x47F12065, ptr %12, align 4
  %13 = getelementptr inbounds nuw float, ptr %xs, i64 6
  store float 1.000000e+10, ptr %13, align 4
  %14 = getelementptr inbounds nuw float, ptr %xs, i64 7
  store float 1.000000e-07, ptr %14, align 4
  %15 = getelementptr inbounds nuw float, ptr %xs, i64 8
  store float f0x7F7FFFFF, ptr %15, align 4
  %16 = getelementptr inbounds nuw float, ptr %xs, i64 9
  store float f0x00800000, ptr %16, align 4
  %17 = getelementptr inbounds nuw float, ptr %xs, i64 10
  store float f0x34000000, ptr %17, align 4
  %18 = getelementptr inbounds nuw float, ptr %xs, i64 11
  store float 2.500000e+00, ptr %18, align 4
; call <[f32]>::iter
  %19 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSf4iterCs8xuo75rCwfG_9float_f32(ptr align 4 %xs, i64 12) #13
  %_4.0 = extractvalue { ptr, ptr } %19, 0
  %_4.1 = extractvalue { ptr, ptr } %19, 1
; call <core::slice::iter::Iter<f32> as core::iter::traits::collect::IntoIterator>::into_iter
  %20 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterfENtB2_12IntoIterator9into_iterCs8xuo75rCwfG_9float_f32(ptr %_4.0, ptr %_4.1) #13
  %_3.0 = extractvalue { ptr, ptr } %20, 0
  %_3.1 = extractvalue { ptr, ptr } %20, 1
  store ptr %_3.0, ptr %iter, align 8
  %21 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %21, align 8
  br label %bb3

bb3:                                              ; preds = %bb6, %start
; call <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::next
  %22 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterfENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs8xuo75rCwfG_9float_f32(ptr align 8 %iter) #13
  store ptr %22, ptr %_8, align 8
  %23 = load ptr, ptr %_8, align 8
  %24 = ptrtoint ptr %23 to i64
  %25 = icmp eq i64 %24, 0
  %_10 = select i1 %25, i64 0, i64 1
  %26 = trunc nuw i64 %_10 to i1
  br i1 %26, label %bb6, label %bb7

bb6:                                              ; preds = %bb3
  %_293 = load ptr, ptr %_8, align 8
  %x27 = load float, ptr %_293, align 4
; call core::hint::black_box::<f32>
  %27 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float %x27) #13
  store float %27, ptr %x, align 4
  store ptr %x, ptr %args, align 8
  %28 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %x, ptr %28, align 8
  %29 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr %x, ptr %29, align 8
  %30 = getelementptr inbounds i8, ptr %args, i64 24
  store ptr %x, ptr %30, align 8
  %31 = getelementptr inbounds i8, ptr %args, i64 32
  store ptr %x, ptr %31, align 8
  %32 = getelementptr inbounds i8, ptr %args, i64 40
  store ptr %x, ptr %32, align 8
  %33 = getelementptr inbounds i8, ptr %args, i64 48
  store ptr %x, ptr %33, align 8
  %_294 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_24, ptr align 4 %_294) #13
  %34 = getelementptr inbounds i8, ptr %args, i64 8
  %_295 = load ptr, ptr %34, align 8
; call <core::fmt::rt::Argument>::new_debug::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_25, ptr align 4 %_295) #13
  %35 = getelementptr inbounds i8, ptr %args, i64 16
  %_296 = load ptr, ptr %35, align 8
; call <core::fmt::rt::Argument>::new_lower_exp::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_26, ptr align 4 %_296) #13
  %36 = getelementptr inbounds i8, ptr %args, i64 24
  %_297 = load ptr, ptr %36, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_27, ptr align 4 %_297) #13
  %37 = getelementptr inbounds i8, ptr %args, i64 32
  %_298 = load ptr, ptr %37, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_28, ptr align 4 %_298) #13
  %38 = getelementptr inbounds i8, ptr %args, i64 40
  %_299 = load ptr, ptr %38, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_29, ptr align 4 %_299) #13
  %39 = getelementptr inbounds i8, ptr %args, i64 48
  %_300 = load ptr, ptr %39, align 8
; call <core::fmt::rt::Argument>::new_upper_exp::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_expfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_30, ptr align 4 %_300) #13
  %40 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %40, ptr align 8 %_24, i64 16, i1 false)
  %41 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %41, ptr align 8 %_25, i64 16, i1 false)
  %42 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %42, ptr align 8 %_26, i64 16, i1 false)
  %43 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %43, ptr align 8 %_27, i64 16, i1 false)
  %44 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %44, ptr align 8 %_28, i64 16, i1 false)
  %45 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %45, ptr align 8 %_29, i64 16, i1 false)
  %46 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 6
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %46, ptr align 8 %_30, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<40, 7>
  %47 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj28_Kj7_ECs8xuo75rCwfG_9float_f32(ptr @alloc_d5393a73b9ab337550d973a0f32943c1, ptr align 8 %args1) #13
  %_14.0 = extractvalue { ptr, ptr } %47, 0
  %_14.1 = extractvalue { ptr, ptr } %47, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_14.0, ptr %_14.1)
  br label %bb3

bb7:                                              ; preds = %bb3
; call core::hint::black_box::<f32>
  %_36 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float +qnan) #13
; call core::hint::black_box::<f32>
  %_37 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float +inf) #13
  store float %_36, ptr %nan, align 4
  store float %_37, ptr %inf, align 4
  %48 = load float, ptr %inf, align 4
  %49 = fneg float %48
  store float %49, ptr %_44, align 4
  %50 = load float, ptr %nan, align 4
  %51 = load float, ptr %nan, align 4
  %52 = fcmp oeq float %50, %51
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %_46, align 1
  %54 = load float, ptr %nan, align 4
  %55 = load float, ptr %inf, align 4
  %56 = fcmp olt float %54, %55
  %57 = zext i1 %56 to i8
  store i8 %57, ptr %_48, align 1
  store ptr %nan, ptr %args2, align 8
  %58 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %inf, ptr %58, align 8
  %59 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %_44, ptr %59, align 8
  %60 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %_46, ptr %60, align 8
  %61 = getelementptr inbounds i8, ptr %args2, i64 32
  store ptr %_48, ptr %61, align 8
  %_301 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_50, ptr align 4 %_301) #13
  %62 = getelementptr inbounds i8, ptr %args2, i64 8
  %_302 = load ptr, ptr %62, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_51, ptr align 4 %_302) #13
  %63 = getelementptr inbounds i8, ptr %args2, i64 16
  %_303 = load ptr, ptr %63, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_52, ptr align 4 %_303) #13
  %64 = getelementptr inbounds i8, ptr %args2, i64 24
  %_304 = load ptr, ptr %64, align 8
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_53, ptr %_304) #13
  %65 = getelementptr inbounds i8, ptr %args2, i64 32
  %_305 = load ptr, ptr %65, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_54, ptr %_305) #13
  %66 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %66, ptr align 8 %_50, i64 16, i1 false)
  %67 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %67, ptr align 8 %_51, i64 16, i1 false)
  %68 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %68, ptr align 8 %_52, i64 16, i1 false)
  %69 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %69, ptr align 8 %_53, i64 16, i1 false)
  %70 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %70, ptr align 8 %_54, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<16, 5>
  %71 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECs8xuo75rCwfG_9float_f32(ptr @alloc_6a96e47ef75dbf6fc4eb5423ba7bb768, ptr align 8 %args3) #13
  %_39.0 = extractvalue { ptr, ptr } %71, 0
  %_39.1 = extractvalue { ptr, ptr } %71, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_39.0, ptr %_39.1)
  %72 = load float, ptr %nan, align 4
; call <f32>::is_nan
  %73 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f6is_nanCs8xuo75rCwfG_9float_f32(float %72) #13
  %74 = zext i1 %73 to i8
  store i8 %74, ptr %_61, align 1
  %75 = load float, ptr %inf, align 4
; call <f32>::is_infinite
  %76 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f11is_infiniteCs8xuo75rCwfG_9float_f32(float %75) #13
  %77 = zext i1 %76 to i8
  store i8 %77, ptr %_63, align 1
; call <f32>::is_sign_negative
  %78 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f16is_sign_negativeCs8xuo75rCwfG_9float_f32(float -0.000000e+00) #13
  %79 = zext i1 %78 to i8
  store i8 %79, ptr %_65, align 1
  store ptr %_61, ptr %args4, align 8
  %80 = getelementptr inbounds i8, ptr %args4, i64 8
  store ptr %_63, ptr %80, align 8
  %81 = getelementptr inbounds i8, ptr %args4, i64 16
  store ptr %_65, ptr %81, align 8
  %_306 = load ptr, ptr %args4, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_67, ptr %_306) #13
  %82 = getelementptr inbounds i8, ptr %args4, i64 8
  %_307 = load ptr, ptr %82, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_68, ptr %_307) #13
  %83 = getelementptr inbounds i8, ptr %args4, i64 16
  %_308 = load ptr, ptr %83, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_69, ptr %_308) #13
  %84 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %84, ptr align 8 %_67, i64 16, i1 false)
  %85 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %85, ptr align 8 %_68, i64 16, i1 false)
  %86 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %86, ptr align 8 %_69, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %87 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8xuo75rCwfG_9float_f32(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args5) #13
  %_58.0 = extractvalue { ptr, ptr } %87, 0
  %_58.1 = extractvalue { ptr, ptr } %87, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_58.0, ptr %_58.1)
; call core::hint::black_box::<f32>
  %88 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 2.000000e+00) #13
  store float %88, ptr %a, align 4
  %89 = load float, ptr %a, align 4
; call <f32>::sqrt
  %90 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f4sqrtCs8xuo75rCwfG_9float_f32(float %89) #13
  store float %90, ptr %_77, align 4
; call core::hint::black_box::<i32>
  %_80 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs8xuo75rCwfG_9float_f32(i32 10) #13
  %91 = load float, ptr %a, align 4
; call <f32>::powi
  %92 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f4powiCs8xuo75rCwfG_9float_f32(float %91, i32 %_80) #13
  store float %92, ptr %_79, align 4
; call core::hint::black_box::<f32>
  %_83 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 5.000000e-01) #13
  %93 = load float, ptr %a, align 4
; call <f32>::powf
  %94 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f4powfCs8xuo75rCwfG_9float_f32(float %93, float %_83) #13
  store float %94, ptr %_82, align 4
  %95 = load float, ptr %a, align 4
; call <f32>::ln
  %96 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f2lnCs8xuo75rCwfG_9float_f32(float %95) #13
  store float %96, ptr %_85, align 4
  store ptr %_77, ptr %args6, align 8
  %97 = getelementptr inbounds i8, ptr %args6, i64 8
  store ptr %_79, ptr %97, align 8
  %98 = getelementptr inbounds i8, ptr %args6, i64 16
  store ptr %_82, ptr %98, align 8
  %99 = getelementptr inbounds i8, ptr %args6, i64 24
  store ptr %_85, ptr %99, align 8
  %_309 = load ptr, ptr %args6, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_87, ptr align 4 %_309) #13
  %100 = getelementptr inbounds i8, ptr %args6, i64 8
  %_310 = load ptr, ptr %100, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_88, ptr align 4 %_310) #13
  %101 = getelementptr inbounds i8, ptr %args6, i64 16
  %_311 = load ptr, ptr %101, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_89, ptr align 4 %_311) #13
  %102 = getelementptr inbounds i8, ptr %args6, i64 24
  %_312 = load ptr, ptr %102, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_90, ptr align 4 %_312) #13
  %103 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %103, ptr align 8 %_87, i64 16, i1 false)
  %104 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %104, ptr align 8 %_88, i64 16, i1 false)
  %105 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %105, ptr align 8 %_89, i64 16, i1 false)
  %106 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %106, ptr align 8 %_90, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 4>
  %107 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs8xuo75rCwfG_9float_f32(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args7) #13
  %_74.0 = extractvalue { ptr, ptr } %107, 0
  %_74.1 = extractvalue { ptr, ptr } %107, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_74.0, ptr %_74.1)
  %108 = load float, ptr %a, align 4
; call <f32>::exp
  %109 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f3expCs8xuo75rCwfG_9float_f32(float %108) #13
  store float %109, ptr %_97, align 4
  %110 = load float, ptr %a, align 4
; call <f32>::sin
  %111 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f3sinCs8xuo75rCwfG_9float_f32(float %110) #13
  store float %111, ptr %_99, align 4
  %112 = load float, ptr %a, align 4
; call <f32>::cos
  %113 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f3cosCs8xuo75rCwfG_9float_f32(float %112) #13
  store float %113, ptr %_101, align 4
; call core::hint::black_box::<f32>
  %_104 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 3.000000e+00) #13
  %114 = load float, ptr %a, align 4
; call <f32>::atan2
  %115 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f5atan2Cs8xuo75rCwfG_9float_f32(float %114, float %_104) #13
  store float %115, ptr %_103, align 4
  store ptr %_97, ptr %args8, align 8
  %116 = getelementptr inbounds i8, ptr %args8, i64 8
  store ptr %_99, ptr %116, align 8
  %117 = getelementptr inbounds i8, ptr %args8, i64 16
  store ptr %_101, ptr %117, align 8
  %118 = getelementptr inbounds i8, ptr %args8, i64 24
  store ptr %_103, ptr %118, align 8
  %_313 = load ptr, ptr %args8, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_106, ptr align 4 %_313) #13
  %119 = getelementptr inbounds i8, ptr %args8, i64 8
  %_314 = load ptr, ptr %119, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_107, ptr align 4 %_314) #13
  %120 = getelementptr inbounds i8, ptr %args8, i64 16
  %_315 = load ptr, ptr %120, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_108, ptr align 4 %_315) #13
  %121 = getelementptr inbounds i8, ptr %args8, i64 24
  %_316 = load ptr, ptr %121, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_109, ptr align 4 %_316) #13
  %122 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %122, ptr align 8 %_106, i64 16, i1 false)
  %123 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %123, ptr align 8 %_107, i64 16, i1 false)
  %124 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %124, ptr align 8 %_108, i64 16, i1 false)
  %125 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %125, ptr align 8 %_109, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 4>
  %126 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs8xuo75rCwfG_9float_f32(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args9) #13
  %_94.0 = extractvalue { ptr, ptr } %126, 0
  %_94.1 = extractvalue { ptr, ptr } %126, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_94.0, ptr %_94.1)
; call <f32>::floor
  %127 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f5floorCs8xuo75rCwfG_9float_f32(float 7.500000e+00) #13
  store float %127, ptr %_116, align 4
; call <f32>::round
  %128 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f5roundCs8xuo75rCwfG_9float_f32(float 7.500000e+00) #13
  store float %128, ptr %_118, align 4
; call <f32>::trunc
  %129 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f5truncCs8xuo75rCwfG_9float_f32(float -7.500000e+00) #13
  store float %129, ptr %_120, align 4
  store ptr %_116, ptr %args10, align 8
  %130 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_118, ptr %130, align 8
  %131 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_120, ptr %131, align 8
  %_317 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_317) #13
  %132 = getelementptr inbounds i8, ptr %args10, i64 8
  %_318 = load ptr, ptr %132, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_318) #13
  %133 = getelementptr inbounds i8, ptr %args10, i64 16
  %_319 = load ptr, ptr %133, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_124, ptr align 4 %_319) #13
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_122, i64 16, i1 false)
  %135 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %135, ptr align 8 %_123, i64 16, i1 false)
  %136 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %136, ptr align 8 %_124, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %137 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8xuo75rCwfG_9float_f32(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #13
  %_113.0 = extractvalue { ptr, ptr } %137, 0
  %_113.1 = extractvalue { ptr, ptr } %137, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_113.0, ptr %_113.1)
; call <f32>::rem_euclid
  %138 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f10rem_euclidCs8xuo75rCwfG_9float_f32(float 7.500000e+00, float 2.000000e+00) #13
  store float %138, ptr %_131, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_134, ptr align 4 %_131) #13
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_135, ptr align 4 @alloc_1de177168114d4a447b57eedc7626360) #13
  %139 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %139, ptr align 8 %_134, i64 16, i1 false)
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_135, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %141 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #13
  %_128.0 = extractvalue { ptr, ptr } %141, 0
  %_128.1 = extractvalue { ptr, ptr } %141, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_128.0, ptr %_128.1)
; call core::hint::black_box::<f32>
  %_143 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 3.000000e+00) #13
; call core::hint::black_box::<f32>
  %_144 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 1.000000e+00) #13
  %142 = load float, ptr %a, align 4
; call <f32>::mul_add
  %143 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f7mul_addCs8xuo75rCwfG_9float_f32(float %142, float %_143, float %_144) #13
  store float %143, ptr %_142, align 4
; call core::hint::black_box::<f32>
  %_147 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 3.000000e+00) #13
  %144 = load float, ptr %a, align 4
; call <f32>::hypot
  %145 = call float @_RNvMNtCsddYV2PBJW9h_3std3f32f5hypotCs8xuo75rCwfG_9float_f32(float %144, float %_147) #13
  store float %145, ptr %_146, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_149, ptr align 4 %_142) #13
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_150, ptr align 4 %_146) #13
  %146 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %146, ptr align 8 %_149, i64 16, i1 false)
  %147 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %147, ptr align 8 %_150, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %148 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #13
  %_139.0 = extractvalue { ptr, ptr } %148, 0
  %_139.1 = extractvalue { ptr, ptr } %148, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_139.0, ptr %_139.1)
; call <str>::parse::<f32>
  %149 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsefECs8xuo75rCwfG_9float_f32(ptr @alloc_89ca5133652a5226da26adbdfa0e2f97, i64 4) #13
  store i64 %149, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_157, ptr align 8 %6, i64 8, i1 false)
; call <str>::parse::<f32>
  %150 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsefECs8xuo75rCwfG_9float_f32(ptr @alloc_13af184f83ea529683dab3456027e412, i64 3) #13
  store i64 %150, ptr %5, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_162, ptr align 8 %5, i64 8, i1 false)
; call <core::result::Result<f32, core::num::float_parse::ParseFloatError>>::is_err
  %151 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultfNtNtNtB4_3num11float_parse15ParseFloatErrorE6is_errCs8xuo75rCwfG_9float_f32(ptr align 4 %_162) #13
  %152 = zext i1 %151 to i8
  store i8 %152, ptr %_160, align 1
; call <str>::parse::<f32>
  %153 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsefECs8xuo75rCwfG_9float_f32(ptr @alloc_bb740835b54142edad8629f403440288, i64 3) #13
  store i64 %153, ptr %4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_165, ptr align 8 %4, i64 8, i1 false)
  store ptr %_157, ptr %args14, align 8
  %154 = getelementptr inbounds i8, ptr %args14, i64 8
  store ptr %_160, ptr %154, align 8
  %155 = getelementptr inbounds i8, ptr %args14, i64 16
  store ptr %_165, ptr %155, align 8
  %_324 = load ptr, ptr %args14, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<f32, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultfNtNtNtB7_3num11float_parse15ParseFloatErrorEECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_168, ptr align 4 %_324) #13
  %156 = getelementptr inbounds i8, ptr %args14, i64 8
  %_325 = load ptr, ptr %156, align 8
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_169, ptr %_325) #13
  %157 = getelementptr inbounds i8, ptr %args14, i64 16
  %_326 = load ptr, ptr %157, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<f32, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultfNtNtNtB7_3num11float_parse15ParseFloatErrorEECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_170, ptr align 4 %_326) #13
  %158 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %158, ptr align 8 %_168, i64 16, i1 false)
  %159 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %159, ptr align 8 %_169, i64 16, i1 false)
  %160 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %160, ptr align 8 %_170, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %161 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8xuo75rCwfG_9float_f32(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args15) #13
  %_154.0 = extractvalue { ptr, ptr } %161, 0
  %_154.1 = extractvalue { ptr, ptr } %161, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_154.0, ptr %_154.1)
; call <str>::parse::<f32>
  %162 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsefECs8xuo75rCwfG_9float_f32(ptr @alloc_6c433d3c07b7c6453f8a17b49b46c496, i64 3) #13
  store i64 %162, ptr %3, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_177, ptr align 8 %3, i64 8, i1 false)
; call <str>::parse::<f32>
  %163 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsefECs8xuo75rCwfG_9float_f32(ptr @alloc_09041e75dc84c4f90838ba63407d8bea, i64 4) #13
  store i64 %163, ptr %2, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_181, ptr align 8 %2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 4 %_181, i64 8, i1 false)
  %164 = load i64, ptr %1, align 8
; call <core::result::Result<f32, core::num::float_parse::ParseFloatError>>::map::<bool, float_f32::main::{closure#0}>
  %165 = call { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultfNtNtNtB5_3num11float_parse15ParseFloatErrorE3mapbNCNvCs8xuo75rCwfG_9float_f324main0EB1A_(i64 %164) #13
  %166 = extractvalue { i1, i8 } %165, 0
  %167 = extractvalue { i1, i8 } %165, 1
  %168 = zext i1 %166 to i8
  store i8 %168, ptr %_180, align 1
  %169 = getelementptr inbounds i8, ptr %_180, i64 1
  store i8 %167, ptr %169, align 1
; call <str>::parse::<f32>
  %170 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsefECs8xuo75rCwfG_9float_f32(ptr @alloc_6e6e78314388fe4f511b82ed72e9a0ae, i64 2) #13
  store i64 %170, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_184, ptr align 8 %0, i64 8, i1 false)
  store ptr %_177, ptr %args16, align 8
  %171 = getelementptr inbounds i8, ptr %args16, i64 8
  store ptr %_180, ptr %171, align 8
  %172 = getelementptr inbounds i8, ptr %args16, i64 16
  store ptr %_184, ptr %172, align 8
  %_327 = load ptr, ptr %args16, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<f32, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultfNtNtNtB7_3num11float_parse15ParseFloatErrorEECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_187, ptr align 4 %_327) #13
  %173 = getelementptr inbounds i8, ptr %args16, i64 8
  %_328 = load ptr, ptr %173, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<bool, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultbNtNtNtB7_3num11float_parse15ParseFloatErrorEECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_188, ptr %_328) #13
  %174 = getelementptr inbounds i8, ptr %args16, i64 16
  %_329 = load ptr, ptr %174, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<f32, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultfNtNtNtB7_3num11float_parse15ParseFloatErrorEECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_189, ptr align 4 %_329) #13
  %175 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %175, ptr align 8 %_187, i64 16, i1 false)
  %176 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %176, ptr align 8 %_188, i64 16, i1 false)
  %177 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %177, ptr align 8 %_189, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %178 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8xuo75rCwfG_9float_f32(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args17) #13
  %_174.0 = extractvalue { ptr, ptr } %178, 0
  %_174.1 = extractvalue { ptr, ptr } %178, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_174.0, ptr %_174.1)
  %179 = load float, ptr %a, align 4
; call <f32>::to_bits
  %180 = call i32 @_RNvMNtCsl10jNU3mE6R_4core3f32f7to_bitsCs8xuo75rCwfG_9float_f32(float %179) #13
  store i32 %180, ptr %_196, align 4
  %181 = load float, ptr %a, align 4
; call <f32>::to_bits
  %_200 = call i32 @_RNvMNtCsl10jNU3mE6R_4core3f32f7to_bitsCs8xuo75rCwfG_9float_f32(float %181) #13
; call core::hint::black_box::<u32>
  %_199 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8xuo75rCwfG_9float_f32(i32 %_200) #13
; call <f32>::from_bits
  %182 = call float @_RNvMNtCsl10jNU3mE6R_4core3f32f9from_bitsCs8xuo75rCwfG_9float_f32(i32 %_199) #13
  store float %182, ptr %_198, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_202, ptr align 4 %_196) #13
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_203, ptr align 4 %_198) #13
  %183 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %183, ptr align 8 %_202, i64 16, i1 false)
  %184 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %184, ptr align 8 %_203, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %185 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #13
  %_193.0 = extractvalue { ptr, ptr } %185, 0
  %_193.1 = extractvalue { ptr, ptr } %185, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_193.0, ptr %_193.1)
; call core::hint::black_box::<f32>
  %186 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 3.000000e+00) #13
  store float %186, ptr %_213, align 4
; call <f32>::total_cmp
  %187 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3f32f9total_cmpCs8xuo75rCwfG_9float_f32(ptr align 4 %a, ptr align 4 %_213) #13
  store i8 %187, ptr %_210, align 1
; call core::hint::black_box::<f32>
  %_216 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 1.500000e+00) #13
  %188 = load float, ptr %a, align 4
; call <f32>::min
  %189 = call float @_RNvMNtCsl10jNU3mE6R_4core3f32f3minCs8xuo75rCwfG_9float_f32(float %188, float %_216) #13
  store float %189, ptr %_215, align 4
; call core::hint::black_box::<f32>
  %_219 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 2.500000e+00) #13
; call core::hint::black_box::<f32>
  %_220 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs8xuo75rCwfG_9float_f32(float 3.000000e+00) #13
  %190 = load float, ptr %a, align 4
; call <f32>::clamp
  %191 = call float @_RNvMNtCsl10jNU3mE6R_4core3f32f5clampCs8xuo75rCwfG_9float_f32(float %190, float %_219, float %_220) #13
  store float %191, ptr %_218, align 4
  store ptr %_210, ptr %args19, align 8
  %192 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_215, ptr %192, align 8
  %193 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_218, ptr %193, align 8
  %_332 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::cmp::Ordering>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_3cmp8OrderingECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_222, ptr %_332) #13
  %194 = getelementptr inbounds i8, ptr %args19, i64 8
  %_333 = load ptr, ptr %194, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_223, ptr align 4 %_333) #13
  %195 = getelementptr inbounds i8, ptr %args19, i64 16
  %_334 = load ptr, ptr %195, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_224, ptr align 4 %_334) #13
  %196 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %196, ptr align 8 %_222, i64 16, i1 false)
  %197 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %197, ptr align 8 %_223, i64 16, i1 false)
  %198 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %198, ptr align 8 %_224, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %199 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8xuo75rCwfG_9float_f32(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #13
  %_207.0 = extractvalue { ptr, ptr } %199, 0
  %_207.1 = extractvalue { ptr, ptr } %199, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_207.0, ptr %_207.1)
; call core::hint::black_box::<f64>
  %_233 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs8xuo75rCwfG_9float_f32(double 3.007000e+02) #13
  %_232 = fptrunc double %_233 to float
  %200 = call i8 @llvm.fptoui.sat.i8.f32(float %_232)
  store i8 %200, ptr %_231, align 1
; call core::hint::black_box::<f64>
  %_237 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs8xuo75rCwfG_9float_f32(double -5.000000e+00) #13
  %_236 = fptrunc double %_237 to float
  %201 = call i8 @llvm.fptoui.sat.i8.f32(float %_236)
  store i8 %201, ptr %_235, align 1
  %202 = load float, ptr %nan, align 4
  %203 = call i32 @llvm.fptosi.sat.i32.f32(float %202)
  store i32 %203, ptr %_239, align 4
  store ptr %_231, ptr %args21, align 8
  %204 = getelementptr inbounds i8, ptr %args21, i64 8
  store ptr %_235, ptr %204, align 8
  %205 = getelementptr inbounds i8, ptr %args21, i64 16
  store ptr %_239, ptr %205, align 8
  %_335 = load ptr, ptr %args21, align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_241, ptr %_335) #13
  %206 = getelementptr inbounds i8, ptr %args21, i64 8
  %_336 = load ptr, ptr %206, align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_242, ptr %_336) #13
  %207 = getelementptr inbounds i8, ptr %args21, i64 16
  %_337 = load ptr, ptr %207, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_243, ptr align 4 %_337) #13
  %208 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %208, ptr align 8 %_241, i64 16, i1 false)
  %209 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %209, ptr align 8 %_242, i64 16, i1 false)
  %210 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %210, ptr align 8 %_243, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %211 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8xuo75rCwfG_9float_f32(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args22) #13
  %_228.0 = extractvalue { ptr, ptr } %211, 0
  %_228.1 = extractvalue { ptr, ptr } %211, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_228.0, ptr %_228.1)
; call core::hint::black_box::<f64>
  %_252 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs8xuo75rCwfG_9float_f32(double 1.000000e+30) #13
  %_251 = fptrunc double %_252 to float
  %212 = call i64 @llvm.fptosi.sat.i64.f32(float %_251)
  store i64 %212, ptr %_250, align 8
; call core::hint::black_box::<f64>
  %_256 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs8xuo75rCwfG_9float_f32(double -1.000000e+30) #13
  %_255 = fptrunc double %_256 to float
  %213 = call i128 @llvm.fptosi.sat.i128.f32(float %_255)
  store i128 %213, ptr %_254, align 16
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_258, ptr align 8 %_250) #13
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_259, ptr align 16 %_254) #13
  %214 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %214, ptr align 8 %_258, i64 16, i1 false)
  %215 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %215, ptr align 8 %_259, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %216 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args23) #13
  %_247.0 = extractvalue { ptr, ptr } %216, 0
  %_247.1 = extractvalue { ptr, ptr } %216, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_247.0, ptr %_247.1)
; call <[f32]>::iter
  %217 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSf4iterCs8xuo75rCwfG_9float_f32(ptr align 4 @alloc_6a4a4cf2fe98a583a56dc651d4feb763, i64 2) #13
  %_267.0 = extractvalue { ptr, ptr } %217, 0
  %_267.1 = extractvalue { ptr, ptr } %217, 1
; call <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::sum::<f32>
  %218 = call float @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterfENtNtNtNtBa_4iter6traits8iterator8Iterator3sumfECs8xuo75rCwfG_9float_f32(ptr %_267.0, ptr %_267.1)
  store float %218, ptr %_266, align 4
; call <[f32]>::iter
  %219 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSf4iterCs8xuo75rCwfG_9float_f32(ptr align 4 @alloc_6a4a4cf2fe98a583a56dc651d4feb763, i64 2) #13
  %_273.0 = extractvalue { ptr, ptr } %219, 0
  %_273.1 = extractvalue { ptr, ptr } %219, 1
; call <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::cloned::<f32>
  %220 = call { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterfENtNtNtNtBa_4iter6traits8iterator8Iterator6clonedfECs8xuo75rCwfG_9float_f32(ptr %_273.0, ptr %_273.1)
  %_272.0 = extractvalue { ptr, ptr } %220, 0
  %_272.1 = extractvalue { ptr, ptr } %220, 1
; call <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<f32>> as core::iter::traits::iterator::Iterator>::fold::<f32, <f32>::max>
  %221 = call float @_RINvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB5_6ClonedINtNtNtBb_5slice4iter4IterfEENtNtNtB9_6traits8iterator8Iterator4foldfNvMNtBb_3f32f3maxECs8xuo75rCwfG_9float_f32(ptr %_272.0, ptr %_272.1, float f0xFF7FFFFF)
  store float %221, ptr %_271, align 4
; call <core::fmt::rt::Argument>::new_debug::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_277, ptr align 4 %_266) #13
; call <core::fmt::rt::Argument>::new_debug::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_278, ptr align 4 %_271) #13
  %222 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %222, ptr align 8 %_277, i64 16, i1 false)
  %223 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %223, ptr align 8 %_278, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %224 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args24) #13
  %_263.0 = extractvalue { ptr, ptr } %224, 0
  %_263.1 = extractvalue { ptr, ptr } %224, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_263.0, ptr %_263.1)
  store ptr %a, ptr %args25, align 8
  %225 = getelementptr inbounds i8, ptr %args25, i64 8
  store ptr %a, ptr %225, align 8
  %226 = getelementptr inbounds i8, ptr %args25, i64 16
  store ptr %a, ptr %226, align 8
  %_342 = load ptr, ptr %args25, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_288, ptr align 4 %_342) #13
  %227 = getelementptr inbounds i8, ptr %args25, i64 8
  %_343 = load ptr, ptr %227, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_289, ptr align 4 %_343) #13
  %228 = getelementptr inbounds i8, ptr %args25, i64 16
  %_344 = load ptr, ptr %228, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_290, ptr align 4 %_344) #13
  %229 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %229, ptr align 8 %_288, i64 16, i1 false)
  %230 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %230, ptr align 8 %_289, i64 16, i1 false)
  %231 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %231, ptr align 8 %_290, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<36, 3>
  %232 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj24_Kj3_ECs8xuo75rCwfG_9float_f32(ptr @alloc_4f9e0d52b704c48a48195dee1a39f8e6, ptr align 8 %args26) #13
  %_282.0 = extractvalue { ptr, ptr } %232, 0
  %_282.1 = extractvalue { ptr, ptr } %232, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_282.0, ptr %_282.1)
  ret void

bb5:                                              ; No predecessors!
  unreachable
}

; <f32>::rem_euclid
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f10rem_euclidCs8xuo75rCwfG_9float_f32(float %self, float %rhs) unnamed_addr #0 !guid !94 {
start:
; call core::f32::math::rem_euclid
  %_0 = call float @_RNvNtNtCsl10jNU3mE6R_4core3f324math10rem_euclidCs8xuo75rCwfG_9float_f32(float %self, float %rhs) #13
  ret float %_0
}

; <f32>::ln
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f2lnCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !95 {
start:
  %_0 = call float @llvm.log.f32(float %self)
  ret float %_0
}

; <f32>::cos
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f3cosCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !96 {
start:
  %_0 = call float @llvm.cos.f32(float %self)
  ret float %_0
}

; <f32>::exp
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f3expCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !97 {
start:
  %_0 = call float @llvm.exp.f32(float %self)
  ret float %_0
}

; <f32>::sin
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f3sinCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !98 {
start:
  %_0 = call float @llvm.sin.f32(float %self)
  ret float %_0
}

; <f32>::powf
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f4powfCs8xuo75rCwfG_9float_f32(float %self, float %n) unnamed_addr #0 !guid !99 {
start:
  %_0 = call float @llvm.pow.f32(float %self, float %n)
  ret float %_0
}

; <f32>::powi
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f4powiCs8xuo75rCwfG_9float_f32(float %self, i32 %n) unnamed_addr #0 !guid !100 {
start:
; call core::f32::math::powi
  %_0 = call float @_RNvNtNtCsl10jNU3mE6R_4core3f324math4powiCs8xuo75rCwfG_9float_f32(float %self, i32 %n) #13
  ret float %_0
}

; <f32>::sqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f4sqrtCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !101 {
start:
; call core::f32::math::sqrt
  %_0 = call float @_RNvNtNtCsl10jNU3mE6R_4core3f324math4sqrtCs8xuo75rCwfG_9float_f32(float %self) #13
  ret float %_0
}

; <f32>::atan2
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f5atan2Cs8xuo75rCwfG_9float_f32(float %self, float %other) unnamed_addr #0 !guid !102 {
start:
  %_0 = call float @atan2f(float %self, float %other) #15
  ret float %_0
}

; <f32>::floor
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f5floorCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !103 {
start:
; call core::f32::math::floor
  %_0 = call float @_RNvNtNtCsl10jNU3mE6R_4core3f324math5floorCs8xuo75rCwfG_9float_f32(float %self) #13
  ret float %_0
}

; <f32>::hypot
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f5hypotCs8xuo75rCwfG_9float_f32(float %self, float %other) unnamed_addr #0 !guid !104 {
start:
  %_0 = call float @hypotf(float %self, float %other) #15
  ret float %_0
}

; <f32>::round
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f5roundCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !105 {
start:
; call core::f32::math::round
  %_0 = call float @_RNvNtNtCsl10jNU3mE6R_4core3f324math5roundCs8xuo75rCwfG_9float_f32(float %self) #13
  ret float %_0
}

; <f32>::trunc
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f5truncCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !106 {
start:
; call core::f32::math::trunc
  %_0 = call float @_RNvNtNtCsl10jNU3mE6R_4core3f324math5truncCs8xuo75rCwfG_9float_f32(float %self) #13
  ret float %_0
}

; <f32>::mul_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f7mul_addCs8xuo75rCwfG_9float_f32(float %self, float %a, float %b) unnamed_addr #0 !guid !107 {
start:
; call core::f32::math::mul_add
  %_0 = call float @_RNvNtNtCsl10jNU3mE6R_4core3f324math7mul_addCs8xuo75rCwfG_9float_f32(float %self, float %a, float %b) #13
  ret float %_0
}

; <f32>::is_infinite
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f11is_infiniteCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !108 {
start:
  %_2 = fcmp oeq float %self, +inf
  %_3 = fcmp oeq float %self, -inf
  %_0 = or i1 %_2, %_3
  ret i1 %_0
}

; <f32>::is_sign_negative
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f16is_sign_negativeCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !109 {
start:
; call <f32>::to_bits
  %_3 = call i32 @_RNvMNtCsl10jNU3mE6R_4core3f32f7to_bitsCs8xuo75rCwfG_9float_f32(float %self) #13
  %_2 = and i32 %_3, -2147483648
  %_0 = icmp ne i32 %_2, 0
  ret i1 %_0
}

; <f32>::abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsl10jNU3mE6R_4core3f32f3absCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !110 {
start:
  %_0 = call float @llvm.fabs.f32(float %self)
  ret float %_0
}

; <f32>::max
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsl10jNU3mE6R_4core3f32f3maxCs8xuo75rCwfG_9float_f32(float %self, float %other) unnamed_addr #0 !guid !111 {
start:
  %_0 = call nsz float @llvm.maximumnum.f32(float %self, float %other)
  ret float %_0
}

; <f32>::min
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsl10jNU3mE6R_4core3f32f3minCs8xuo75rCwfG_9float_f32(float %self, float %other) unnamed_addr #0 !guid !112 {
start:
  %_0 = call nsz float @llvm.minimumnum.f32(float %self, float %other)
  ret float %_0
}

; <f32>::clamp
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsl10jNU3mE6R_4core3f32f5clampCs8xuo75rCwfG_9float_f32(float %0, float %min, float %max) unnamed_addr #0 !guid !113 {
start:
  %self = alloca [4 x i8], align 4
  store float %0, ptr %self, align 4
  %_4 = fcmp ole float %min, %max
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call <f32>::clamp::do_panic::runtime
  call void @_RNvNvNvMNtCsl10jNU3mE6R_4core3f32f5clamp8do_panic7runtimeCs8xuo75rCwfG_9float_f32(float %min, float %max, ptr align 8 @alloc_64c10d70f810eee046206a21c0dd1f68) #16
  unreachable

_RNvNvMNtCsl10jNU3mE6R_4core3f32f5clamp8do_panic.exit: ; No predecessors!
  unreachable

bb1:                                              ; preds = %start
  %_7 = load float, ptr %self, align 4
  %_6 = fcmp olt float %_7, %min
  br i1 %_6, label %bb3, label %bb4

bb4:                                              ; preds = %bb3, %bb1
  %_9 = load float, ptr %self, align 4
  %_8 = fcmp ogt float %_9, %max
  br i1 %_8, label %bb5, label %bb6

bb3:                                              ; preds = %bb1
  store float %min, ptr %self, align 4
  br label %bb4

bb6:                                              ; preds = %bb5, %bb4
  %_0 = load float, ptr %self, align 4
  ret float %_0

bb5:                                              ; preds = %bb4
  store float %max, ptr %self, align 4
  br label %bb6
}

; <f32>::is_nan
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f6is_nanCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !114 {
start:
  %_0 = fcmp une float %self, %self
  ret i1 %_0
}

; <f32>::to_bits
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtCsl10jNU3mE6R_4core3f32f7to_bitsCs8xuo75rCwfG_9float_f32(float %self) unnamed_addr #0 !guid !115 {
start:
  %_0 = bitcast float %self to i32
  ret i32 %_0
}

; <f32>::from_bits
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsl10jNU3mE6R_4core3f32f9from_bitsCs8xuo75rCwfG_9float_f32(i32 %v) unnamed_addr #0 !guid !116 {
start:
  %_0 = bitcast i32 %v to float
  ret float %_0
}

; <f32>::total_cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3f32f9total_cmpCs8xuo75rCwfG_9float_f32(ptr align 4 %self, ptr align 4 %other) unnamed_addr #0 !guid !117 {
start:
  %right = alloca [4 x i8], align 4
  %left = alloca [4 x i8], align 4
  %_5 = load float, ptr %self, align 4
; call <f32>::to_bits
  %_4 = call i32 @_RNvMNtCsl10jNU3mE6R_4core3f32f7to_bitsCs8xuo75rCwfG_9float_f32(float %_5) #13
  store i32 %_4, ptr %left, align 4
  %_8 = load float, ptr %other, align 4
; call <f32>::to_bits
  %_7 = call i32 @_RNvMNtCsl10jNU3mE6R_4core3f32f7to_bitsCs8xuo75rCwfG_9float_f32(float %_8) #13
  store i32 %_7, ptr %right, align 4
  %_13 = load i32, ptr %left, align 4
  %_12 = ashr i32 %_13, 31
  %_10 = lshr i32 %_12, 1
  %0 = load i32, ptr %left, align 4
  %1 = xor i32 %0, %_10
  store i32 %1, ptr %left, align 4
  %_18 = load i32, ptr %right, align 4
  %_17 = ashr i32 %_18, 31
  %_15 = lshr i32 %_17, 1
  %2 = load i32, ptr %right, align 4
  %3 = xor i32 %2, %_15
  store i32 %3, ptr %right, align 4
; call <i32 as core::cmp::Ord>::cmp
  %_0 = call i8 @_RNvXs1d_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB8_3Ord3cmpCs8xuo75rCwfG_9float_f32(ptr align 4 %left, ptr align 4 %right) #13
  ret i8 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs8xuo75rCwfG_9float_f32(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !118 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <[f32]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSf4iterCs8xuo75rCwfG_9float_f32(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !119 {
start:
; call <core::slice::iter::Iter<f32>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterfE3newCs8xuo75rCwfG_9float_f32(ptr align 4 %self.0, i64 %self.1) #13
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::result::Result<f32, core::num::float_parse::ParseFloatError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultfNtNtNtB4_3num11float_parse15ParseFloatErrorE5is_okCs8xuo75rCwfG_9float_f32(ptr align 4 %self) unnamed_addr #0 !guid !120 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 4
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<f32, core::num::float_parse::ParseFloatError>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultfNtNtNtB4_3num11float_parse15ParseFloatErrorE6is_errCs8xuo75rCwfG_9float_f32(ptr align 4 %self) unnamed_addr #0 !guid !121 {
start:
; call <core::result::Result<f32, core::num::float_parse::ParseFloatError>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultfNtNtNtB4_3num11float_parse15ParseFloatErrorE5is_okCs8xuo75rCwfG_9float_f32(ptr align 4 %self) #13
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <*mut f32>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOf20offset_from_unsignedCs8xuo75rCwfG_9float_f32(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !122 {
start:
; call <*const f32>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPf20offset_from_unsignedCs8xuo75rCwfG_9float_f32(ptr %self, ptr %origin, ptr align 8 %0) #13
  ret i64 %_0
}

; <*const f32>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPf20offset_from_unsignedCs8xuo75rCwfG_9float_f32(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !123 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8xuo75rCwfG_9float_f32() #13
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 4
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs8xuo75rCwfG_9float_f32(ptr %self, ptr %origin, ptr align 8 %0) #14
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #17
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 4, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 4
  ret i64 %_0
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<f32>, <f32 as core::clone::Clone>::clone>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4IterfENvYfNtNtB8_5clone5Clone5cloneE3newCs8xuo75rCwfG_9float_f32(ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !124 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %iter.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %iter.1, 1
  ret { ptr, ptr } %1
}

; <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<f32>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB2_6ClonedINtNtNtB8_5slice4iter4IterfEE3newCs8xuo75rCwfG_9float_f32(ptr %it.0, ptr %it.1) unnamed_addr #1 !guid !125 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %it.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %it.1, 1
  ret { ptr, ptr } %1
}

; <core::ptr::non_null::NonNull<core::result::Result<bool, core::num::float_parse::ParseFloatError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultbNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCs8xuo75rCwfG_9float_f32(ptr %r) unnamed_addr #0 !guid !126 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<f32, core::num::float_parse::ParseFloatError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultfNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCs8xuo75rCwfG_9float_f32(ptr align 4 %r) unnamed_addr #0 !guid !127 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::cmp::Ordering>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_3cmp8OrderingE8from_refCs8xuo75rCwfG_9float_f32(ptr %r) unnamed_addr #0 !guid !128 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[f32]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSfE8from_refCs8xuo75rCwfG_9float_f32(ptr align 4 %r.0, i64 %r.1) unnamed_addr #0 !guid !129 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs8xuo75rCwfG_9float_f32(ptr %r) unnamed_addr #0 !guid !130 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE20offset_from_unsignedCs8xuo75rCwfG_9float_f32(ptr %self, ptr %subtracted) unnamed_addr #0 !guid !131 {
start:
; call <*mut f32>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOf20offset_from_unsignedCs8xuo75rCwfG_9float_f32(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #13
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs8xuo75rCwfG_9float_f32(ptr align 4 %r) unnamed_addr #0 !guid !132 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCs8xuo75rCwfG_9float_f32(ptr align 16 %r) unnamed_addr #0 !guid !133 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs8xuo75rCwfG_9float_f32(ptr align 8 %r) unnamed_addr #0 !guid !134 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8xuo75rCwfG_9float_f32(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !135 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs8xuo75rCwfG_9float_f32(ptr %s.0, i64 %s.1) #13
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<f32>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterfE3newCs8xuo75rCwfG_9float_f32(ptr align 4 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !136 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[f32]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSfE8from_refCs8xuo75rCwfG_9float_f32(ptr align 4 %slice.0, i64 %slice.1) #13
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[f32]>>::cast::<f32>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSfE4castfECs8xuo75rCwfG_9float_f32(ptr %_4.0, i64 %_4.1) #13
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw float, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs8xuo75rCwfG_9float_f32(ptr %self) unnamed_addr #0 !guid !137 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs8xuo75rCwfG_9float_f32(i8 %0) unnamed_addr #0 !guid !138 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs8xuo75rCwfG_9float_f32(ptr %self) #13
  ret i32 %_0
}

; core::intrinsics::maximum_number_nsz_f32
; Function Attrs: nounwind nonlazybind uwtable
define internal float @_RNvNtCsl10jNU3mE6R_4core10intrinsics22maximum_number_nsz_f32Cs8xuo75rCwfG_9float_f32(float %x, float %y) unnamed_addr #3 personality ptr @rust_eh_personality !guid !139 {
start:
  %_0 = alloca [4 x i8], align 4
; invoke <f32>::is_nan
  %_3 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f6is_nanCs8xuo75rCwfG_9float_f32(float %x)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb3, label %bb2

bb2:                                              ; preds = %bb1
  %_4 = fcmp oge float %y, %x
  br i1 %_4, label %bb3, label %bb4

bb3:                                              ; preds = %bb2, %bb1
  store float %y, ptr %_0, align 4
  br label %bb5

bb4:                                              ; preds = %bb2
  store float %x, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %1 = load float, ptr %_0, align 4
  ret float %1
}

; core::intrinsics::minimum_number_nsz_f32
; Function Attrs: nounwind nonlazybind uwtable
define internal float @_RNvNtCsl10jNU3mE6R_4core10intrinsics22minimum_number_nsz_f32Cs8xuo75rCwfG_9float_f32(float %x, float %y) unnamed_addr #3 personality ptr @rust_eh_personality !guid !140 {
start:
  %_0 = alloca [4 x i8], align 4
; invoke <f32>::is_nan
  %_3 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f6is_nanCs8xuo75rCwfG_9float_f32(float %x)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb3, label %bb2

bb2:                                              ; preds = %bb1
  %_4 = fcmp ole float %y, %x
  br i1 %_4, label %bb3, label %bb4

bb3:                                              ; preds = %bb2, %bb1
  store float %y, ptr %_0, align 4
  br label %bb5

bb4:                                              ; preds = %bb2
  store float %x, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %1 = load float, ptr %_0, align 4
  ret float %1
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8xuo75rCwfG_9float_f32() unnamed_addr #0 !guid !141 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs8xuo75rCwfG_9float_f32() #13
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::f32::math::rem_euclid
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvNtNtCsl10jNU3mE6R_4core3f324math10rem_euclidCs8xuo75rCwfG_9float_f32(float %x, float %rhs) unnamed_addr #0 !guid !142 {
start:
  %_0 = alloca [4 x i8], align 4
  %r = frem float %x, %rhs
  %_4 = fcmp olt float %r, 0.000000e+00
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store float %r, ptr %_0, align 4
  br label %bb4

bb1:                                              ; preds = %start
; call <f32>::abs
  %_5 = call float @_RNvMNtCsl10jNU3mE6R_4core3f32f3absCs8xuo75rCwfG_9float_f32(float %rhs) #13
  %0 = fadd float %r, %_5
  store float %0, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb1, %bb3
  %1 = load float, ptr %_0, align 4
  ret float %1
}

; core::f32::math::powi
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvNtNtCsl10jNU3mE6R_4core3f324math4powiCs8xuo75rCwfG_9float_f32(float %x, i32 %n) unnamed_addr #0 !guid !143 {
start:
  %_0 = call float @llvm.powi.f32.i32(float %x, i32 %n)
  ret float %_0
}

; core::f32::math::sqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvNtNtCsl10jNU3mE6R_4core3f324math4sqrtCs8xuo75rCwfG_9float_f32(float %x) unnamed_addr #0 !guid !144 {
start:
  %_0 = call float @llvm.sqrt.f32(float %x)
  ret float %_0
}

; core::f32::math::floor
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvNtNtCsl10jNU3mE6R_4core3f324math5floorCs8xuo75rCwfG_9float_f32(float %x) unnamed_addr #0 !guid !145 {
start:
  %_0 = call float @llvm.floor.f32(float %x)
  ret float %_0
}

; core::f32::math::round
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvNtNtCsl10jNU3mE6R_4core3f324math5roundCs8xuo75rCwfG_9float_f32(float %x) unnamed_addr #0 !guid !146 {
start:
  %_0 = call float @llvm.round.f32(float %x)
  ret float %_0
}

; core::f32::math::trunc
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvNtNtCsl10jNU3mE6R_4core3f324math5truncCs8xuo75rCwfG_9float_f32(float %x) unnamed_addr #0 !guid !147 {
start:
  %_0 = call float @llvm.trunc.f32(float %x)
  ret float %_0
}

; core::f32::math::mul_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvNtNtCsl10jNU3mE6R_4core3f324math7mul_addCs8xuo75rCwfG_9float_f32(float %x, float %y, float %z) unnamed_addr #0 !guid !148 {
start:
  %_0 = call float @llvm.fma.f32(float %x, float %y, float %z)
  ret float %_0
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs8xuo75rCwfG_9float_f32(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !149 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8xuo75rCwfG_9float_f32(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs8xuo75rCwfG_9float_f32(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !150 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8xuo75rCwfG_9float_f32(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs8xuo75rCwfG_9float_f32() unnamed_addr #0 !guid !151 {
start:
  ret i1 true
}

; <f32>::clamp::do_panic::runtime
; Function Attrs: inlinehint noreturn nonlazybind uwtable
define internal void @_RNvNvNvMNtCsl10jNU3mE6R_4core3f32f5clamp8do_panic7runtimeCs8xuo75rCwfG_9float_f32(float %0, float %1, ptr align 8 %2) unnamed_addr #5 !guid !152 {
start:
  %_10 = alloca [16 x i8], align 8
  %_9 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %max = alloca [4 x i8], align 4
  %min = alloca [4 x i8], align 4
  store float %0, ptr %min, align 4
  store float %1, ptr %max, align 4
; call <core::fmt::rt::Argument>::new_debug::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_9, ptr align 4 %min) #13
; call <core::fmt::rt::Argument>::new_debug::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECs8xuo75rCwfG_9float_f32(ptr sret([16 x i8]) align 8 %_10, ptr align 4 %max) #13
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_9, i64 16, i1 false)
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_10, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<49, 2>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj31_Kj2_EB8_(ptr @alloc_30f7ecc1496f966bde691d01731e6f8e, ptr align 8 %args) #13
  %_4.0 = extractvalue { ptr, ptr } %5, 0
  %_4.1 = extractvalue { ptr, ptr } %5, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_4.0, ptr %_4.1, ptr align 8 %2) #17
  unreachable
}

; <core::slice::iter::Iter<f32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterfENtB2_12IntoIterator9into_iterCs8xuo75rCwfG_9float_f32(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !153 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <i32 as core::cmp::Ord>::cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXs1d_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB8_3Ord3cmpCs8xuo75rCwfG_9float_f32(ptr align 4 %self, ptr align 4 %other) unnamed_addr #0 !guid !154 {
start:
  %_3 = load i32, ptr %self, align 4
  %_4 = load i32, ptr %other, align 4
  %_0 = call i8 @llvm.scmp.i8.i32(i32 %_3, i32 %_4)
  ret i8 %_0
}

; <&core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse14FloatErrorKindNtB6_5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !155 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_14FloatErrorKindNtNtB9_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr %_3, ptr align 8 %f) #13
  ret i1 %_0
}

; <&core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse15ParseFloatErrorNtB6_5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !156 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_15ParseFloatErrorNtNtB9_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr %_3, ptr align 8 %f) #13
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !157 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr %_3, ptr align 8 %f) #13
  ret i1 %_0
}

; <&f32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRfNtB6_5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !158 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <f32 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs2_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_5Debug3fmt(ptr align 4 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <core::slice::iter::Iter<f32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterfENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs8xuo75rCwfG_9float_f32(ptr align 8 %self) unnamed_addr #0 !guid !159 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<f32> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfENtNtB9_3cmp9PartialEq2eqCs8xuo75rCwfG_9float_f32(ptr align 8 %ptr, ptr align 8 %_11) #13
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw float, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::cmp::Ordering as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtCsl10jNU3mE6R_4core3cmpNtB5_8OrderingNtNtB7_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !160 {
start:
  %_3 = alloca [16 x i8], align 8
  %_4 = load i8, ptr %self, align 1
  switch i8 %_4, label %bb1 [
    i8 -1, label %bb4
    i8 0, label %bb3
    i8 1, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb4:                                              ; preds = %start
  store ptr @alloc_a9c61c9f249d39e49475c00b6de04ee0, ptr %_3, align 8, !captures !161
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %0, align 8
  br label %bb5

bb3:                                              ; preds = %start
  store ptr @alloc_cd17b9cbc635e79a5454e667c96efc06, ptr %_3, align 8, !captures !161
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %1, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr @alloc_a2975b4a9399ac4e26287fc3f00ae96d, ptr %_3, align 8, !captures !161
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 7, ptr %2, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3, %bb4
  %3 = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %5 = load i64, ptr %4, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %3, i64 %5)
  ret i1 %_0
}

; <core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_15ParseFloatErrorNtNtB9_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !162 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_252aee8158a2b6b4b1e300c3f8f7bd7a, i64 15, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.1)
  ret i1 %_0
}

; <core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_14FloatErrorKindNtNtB9_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !163 {
start:
  %_3 = alloca [16 x i8], align 8
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %_4 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_4 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr @alloc_6693e43df3406efcf64b4ab3d59228bb, ptr %_3, align 8, !captures !161
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 7, ptr %3, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store ptr @alloc_59ba7b9f7211443cd55a366616eef46a, ptr %_3, align 8, !captures !161
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %4, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_3, align 8
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  %7 = load i64, ptr %6, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %5, i64 %7)
  ret i1 %_0

bb1:                                              ; No predecessors!
  unreachable
}

; <f32 as core::ops::arith::Add<&f32>>::add
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvXsS_NtNtCsl10jNU3mE6R_4core3ops5arithfINtB5_3AddRfE3addCs8xuo75rCwfG_9float_f32(float %self, ptr align 4 %other, ptr align 8 %0) unnamed_addr #0 !guid !164 {
start:
  %_3 = load float, ptr %other, align 4
; call <f32 as core::ops::arith::Add>::add
  %_0 = call float @_RNvXsb_NtNtCsl10jNU3mE6R_4core3ops5arithfNtB5_3Add3addCs8xuo75rCwfG_9float_f32(float %self, float %_3, ptr align 8 %0) #13
  ret float %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs8xuo75rCwfG_9float_f32() unnamed_addr #0 !guid !165 {
start:
  ret i8 0
}

; <f32 as core::ops::arith::Add>::add
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvXsb_NtNtCsl10jNU3mE6R_4core3ops5arithfNtB5_3Add3addCs8xuo75rCwfG_9float_f32(float %self, float %other, ptr align 8 %0) unnamed_addr #0 !guid !166 {
start:
  %_0 = fadd float %self, %other
  ret float %_0
}

; <core::ptr::non_null::NonNull<f32> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfENtNtB9_3cmp9PartialEq2eqCs8xuo75rCwfG_9float_f32(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !167 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !168 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::result::Result<bool, core::num::float_parse::ParseFloatError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultbNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !169 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.3)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %8, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.2)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<f32, core::num::float_parse::ParseFloatError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultfNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCs8xuo75rCwfG_9float_f32(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !170 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 4
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.3)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 4
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8xuo75rCwfG_9float_f32(ptr %_1) unnamed_addr #0 !guid !171 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8xuo75rCwfG_9float_f32(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !172 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8xuo75rCwfG_9float_f32(ptr align 8 %_1) #13
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<f32>::max as core::ops::function::FnMut<(f32, f32)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvYNvMNtCsl10jNU3mE6R_4core3f32f3maxINtNtNtB7_3ops8function5FnMutTffEE8call_mutCs8xuo75rCwfG_9float_f32(ptr %_1, float %0, float %1) unnamed_addr #0 !guid !173 {
start:
  %_2 = alloca [8 x i8], align 4
  store float %0, ptr %_2, align 4
  %2 = getelementptr inbounds i8, ptr %_2, i64 4
  store float %1, ptr %2, align 4
  %3 = load float, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  %5 = load float, ptr %4, align 4
; call <f32>::max
  %_0 = call float @_RNvMNtCsl10jNU3mE6R_4core3f32f3maxCs8xuo75rCwfG_9float_f32(float %3, float %5) #13
  ret float %_0
}

; <<f32 as core::clone::Clone>::clone as core::ops::function::FnMut<(&f32,)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvYNvYfNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBa_3ops8function5FnMutTRfEE8call_mutCs8xuo75rCwfG_9float_f32(ptr %_1, ptr align 4 %0) unnamed_addr #0 !guid !174 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
  %_0.i = load float, ptr %1, align 4
  ret float %_0.i
}

; <f32 as core::str::traits::FromStr>::from_str
; Function Attrs: noinline nonlazybind uwtable
declare i64 @_RNvXs1_NtNtCsl10jNU3mE6R_4core3num11float_parsefNtNtNtB9_3str6traits7FromStr8from_str(ptr, i64) unnamed_addr #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::LowerExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs4_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_8LowerExp3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::UpperExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs5_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_8UpperExp3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs2_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_5Debug3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptoui.sat.i8.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptosi.sat.i32.f32(float) #7

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptosi.sat.i64.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptosi.sat.i128.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.log.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.cos.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.exp.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sin.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.pow.f32(float, float) #7

; Function Attrs: nounwind nonlazybind uwtable
declare float @atan2f(float, float) unnamed_addr #3

; Function Attrs: nounwind nonlazybind uwtable
declare float @hypotf(float, float) unnamed_addr #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximumnum.f32(float, float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.minimumnum.f32(float, float) #7

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #8

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.powi.f32.i32(float, i32) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.floor.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.round.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.trunc.f32(float) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #7

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #10

; <core::fmt::Arguments>::new::<49, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj31_Kj2_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.scmp.i8.i32(i32, i32) #7

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #11 !guid !175 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs8xuo75rCwfG_9float_f32(ptr @_RNvCs8xuo75rCwfG_9float_f324main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nonlazybind "target-cpu"="x86-64" }
attributes #12 = { noinline }
attributes #13 = { inlinehint }
attributes #14 = { inlinehint nounwind }
attributes #15 = { nounwind }
attributes #16 = { inlinehint noreturn }
attributes #17 = { noinline noreturn }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noinline noreturn nounwind }

!llvm.module.flags = !{!41, !42, !43, !44}
!llvm.ident = !{!45}

!0 = !{i64 -1300888744749061825}
!1 = !{i64 -4690941545554089504}
!2 = !{i64 747661618001277238}
!3 = !{i64 67101316731468634}
!4 = !{i64 728958979617192871}
!5 = !{i64 -212754009209539933}
!6 = !{i64 -6629130827335741961}
!7 = !{i64 -7544167846096600899}
!8 = !{i64 2161126284790519356}
!9 = !{i64 4678980200963079765}
!10 = !{i64 937592030090207735}
!11 = !{i64 2774301736612743362}
!12 = !{i64 1679585793945843166}
!13 = !{i64 -3557464049718831466}
!14 = !{i64 3677137666491083119}
!15 = !{i64 -1056481369412156559}
!16 = !{i64 -106717215707117544}
!17 = !{i64 1378260395836539911}
!18 = !{i64 8321311986322360573}
!19 = !{i64 -1893103794078396148}
!20 = !{i64 6517193457680170045}
!21 = !{i64 -5843564970536456177}
!22 = !{i64 -8581432798974522365}
!23 = !{i64 -8183785046800019094}
!24 = !{i64 -6683502145230424783}
!25 = !{i64 656554117964370621}
!26 = !{i64 -2768500794001032668}
!27 = !{i64 -1345298016837054535}
!28 = !{i64 -6800185793829862892}
!29 = !{i64 6650951134244376070}
!30 = !{i64 -7422043751001108866}
!31 = !{i64 -2702762664418402167}
!32 = !{i64 -1092941882226057460}
!33 = !{i64 -4786671915794758427}
!34 = !{i64 6623503895996929199}
!35 = !{i64 -1029658647011935948}
!36 = !{i64 -5917678158976393358}
!37 = !{i64 4005968985152710285}
!38 = !{i64 -6713316027834607254}
!39 = !{i64 1346042712754881286}
!40 = !{i64 -7267607273661110906}
!41 = !{i32 8, !"PIC Level", i32 2}
!42 = !{i32 7, !"PIE Level", i32 2}
!43 = !{i32 2, !"RtLibUseGOT", i32 1}
!44 = !{i32 7, !"uwtable", i32 2}
!45 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!46 = !{i64 3255886496604892671}
!47 = !{i64 -4187782631617578064}
!48 = !{i64 5740897760485911235}
!49 = !{i64 5789939341714701106}
!50 = !{i64 -1835884313004812642}
!51 = !{i64 -8823337604659407718}
!52 = !{i64 -5057635917121398739}
!53 = !{i64 -8702746601644329092}
!54 = !{i64 -5374975088059406360}
!55 = !{i64 -2063501281441770176}
!56 = !{i64 -9054816091210612881}
!57 = !{i64 -3770255935865453776}
!58 = !{i64 -5120263100720935004}
!59 = !{i64 7811823724461597137}
!60 = !{i64 246818946409510892}
!61 = !{i64 -6837430972550335108}
!62 = !{i64 5721207138957975029}
!63 = !{i64 5667833690779884744}
!64 = !{i64 6255747657924985727}
!65 = !{i64 -5628225799914346464}
!66 = !{i64 -545067042849800003}
!67 = !{i64 4196834293942463185}
!68 = !{i64 -2258108263764722624}
!69 = !{i64 -3672269326824456133}
!70 = !{i64 -3017589810802567582}
!71 = !{i64 -7841279081755033738}
!72 = !{i64 2823775739353111299}
!73 = !{i64 1383847194273350522}
!74 = !{i64 1318739643772736}
!75 = !{i64 2022005040877193053}
!76 = !{i64 -2596656352704905677}
!77 = !{i64 5112678636939406211}
!78 = !{i64 -2142136728055598685}
!79 = !{i64 -3850564112143376554}
!80 = !{i64 7638098040149281399}
!81 = !{i64 6975020508193230204}
!82 = !{i64 -8051544187956734090}
!83 = !{i64 5242071801578087065}
!84 = !{i64 7683974464788003695}
!85 = !{i64 -1680375333701853936}
!86 = !{i64 3074531854850578085}
!87 = !{i64 4633755137757355595}
!88 = !{i64 260657845908235726}
!89 = !{i64 1979569857175982364}
!90 = !{i64 -44595393964036292}
!91 = !{i64 -853541977650381371}
!92 = !{i64 5624070597722950805}
!93 = !{i64 -3376059225163908594}
!94 = !{i64 7919235827993504813}
!95 = !{i64 -8640853626387378303}
!96 = !{i64 6386275524652521363}
!97 = !{i64 -3023872814184798506}
!98 = !{i64 -5829060013490290543}
!99 = !{i64 1991756241414951192}
!100 = !{i64 -7429926441209464115}
!101 = !{i64 -2399759004172268461}
!102 = !{i64 -1674290104778409740}
!103 = !{i64 -6370070157936634712}
!104 = !{i64 7256755463368170003}
!105 = !{i64 -7326618368099962640}
!106 = !{i64 -71402172257777420}
!107 = !{i64 7605285944246721601}
!108 = !{i64 2898981611850385270}
!109 = !{i64 -5715468433461254640}
!110 = !{i64 7283766943979115331}
!111 = !{i64 -2418752549787690220}
!112 = !{i64 -2321096351030980939}
!113 = !{i64 17606254678473141}
!114 = !{i64 -4302936218125480838}
!115 = !{i64 43888913779431687}
!116 = !{i64 -4154768663048338147}
!117 = !{i64 -5250902749158777025}
!118 = !{i64 -8482372948392094612}
!119 = !{i64 -3473988921515273588}
!120 = !{i64 1099016201744559725}
!121 = !{i64 8953218247567075617}
!122 = !{i64 -851849353428416673}
!123 = !{i64 -179282094282874731}
!124 = !{i64 8164684999921136090}
!125 = !{i64 1006300219012477007}
!126 = !{i64 -2245262133642776557}
!127 = !{i64 -1668078692724039376}
!128 = !{i64 84334394029793504}
!129 = !{i64 -9140392795927157022}
!130 = !{i64 7640075468283374800}
!131 = !{i64 -8998215809225470181}
!132 = !{i64 -8084767256285873432}
!133 = !{i64 -8269882386226027128}
!134 = !{i64 768326515235467466}
!135 = !{i64 193523642860075300}
!136 = !{i64 5741199199787215607}
!137 = !{i64 -8802332070434405779}
!138 = !{i64 -8553927472958279686}
!139 = !{i64 -1826753209519699426}
!140 = !{i64 -665135708074408534}
!141 = !{i64 5204891798140603996}
!142 = !{i64 7220496916323059891}
!143 = !{i64 7849013441539467950}
!144 = !{i64 -8178048992509582966}
!145 = !{i64 2690724680821326647}
!146 = !{i64 5680871749590609438}
!147 = !{i64 5668793255729971514}
!148 = !{i64 7237991164842627090}
!149 = !{i64 8040308035793843712}
!150 = !{i64 -4077900424686136409}
!151 = !{i64 -4675215399172367906}
!152 = !{i64 5297279042878568261}
!153 = !{i64 1272893298905080166}
!154 = !{i64 -5991674184147403878}
!155 = !{i64 8887666856017502274}
!156 = !{i64 -1256596634127064100}
!157 = !{i64 -2482377046227723451}
!158 = !{i64 -3327397204244550512}
!159 = !{i64 -3085998183204677502}
!160 = !{i64 -2014308940831994862}
!161 = !{!"address", !"read_provenance"}
!162 = !{i64 -5680370749002756554}
!163 = !{i64 -8218347174086582162}
!164 = !{i64 46181447138036464}
!165 = !{i64 2851410677440113965}
!166 = !{i64 -6876025516545602993}
!167 = !{i64 2909790054777279607}
!168 = !{i64 -5711506766584826915}
!169 = !{i64 -2390731373183778037}
!170 = !{i64 8917580110603908646}
!171 = !{i64 1131511432484842811}
!172 = !{i64 -7370310108118679413}
!173 = !{i64 -6545499494998250146}
!174 = !{i64 8784785231708350894}
!175 = !{i64 -2624081020897602054}
