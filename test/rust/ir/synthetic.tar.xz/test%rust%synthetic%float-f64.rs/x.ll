; ModuleID = 'float_f64.7ebec6ebaaba948d-cgu.0'
source_filename = "float_f64.7ebec6ebaaba948d-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsaSF28CXLCD9_9float_f64, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaSF28CXLCD9_9float_f64, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaSF28CXLCD9_9float_f64 }>, align 8, !guid !0
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !1
@alloc_5bb642ca6df5ad9ba078972a9d3a5201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !2
@alloc_8df3287b4fbc190437d91041421e919b = private unnamed_addr constant [30 x i8] c"core/src/iter/traits/accum.rs\00", align 1, !guid !3
@alloc_c9e69792a4316033abad0d4adaadd679 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8df3287b4fbc190437d91041421e919b, [16 x i8] c"\1D\00\00\00\00\00\00\00\D0\00\00\00\01\00\00\00" }>, align 8, !guid !4
@alloc_6a96e47ef75dbf6fc4eb5423ba7bb768 = private unnamed_addr constant [16 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !5
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_d4f9eee8b3859a4cb2c5427791046c70 = private unnamed_addr constant [13 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !7
@alloc_0e127f19757cb04e22d0ee81c1de547e = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00\00\F8\BF", align 8, !guid !8
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !9
@alloc_89ca5133652a5226da26adbdfa0e2f97 = private unnamed_addr constant [4 x i8] c"3.14", align 1, !guid !10
@alloc_13af184f83ea529683dab3456027e412 = private unnamed_addr constant [3 x i8] c"abc", align 1, !guid !11
@alloc_bb740835b54142edad8629f403440288 = private unnamed_addr constant [3 x i8] c"1e3", align 1, !guid !12
@alloc_6c433d3c07b7c6453f8a17b49b46c496 = private unnamed_addr constant [3 x i8] c"inf", align 1, !guid !13
@alloc_09041e75dc84c4f90838ba63407d8bea = private unnamed_addr constant [4 x i8] c"-nan", align 1, !guid !14
@alloc_6e6e78314388fe4f511b82ed72e9a0ae = private unnamed_addr constant [2 x i8] c".5", align 1, !guid !15
@alloc_dd7b99992a9c8295d5a6eb4440ee070f = private unnamed_addr constant [16 x i8] c"\00\00\00\00\00\00\F8?\00\00\00\00\00\00\04@", align 8, !guid !16
@alloc_4f9e0d52b704c48a48195dee1a39f8e6 = private unnamed_addr constant [36 x i8] c"\C7 \00\00y\08\00\03\00\01 \C7 \00\00\18\08\00\01\00\02| \C7 \00\00X\09\00\02\00\02|\0A\00", align 1, !guid !17
@alloc_d5393a73b9ab337550d973a0f32943c1 = private unnamed_addr constant [40 x i8] c"\C0\01 \C0\01 \C0\01 \C5 \00\00p\03\00\01 \C7 \00\00x\0A\00\02\00\01 \C1 \00 `\01 \C0\01\0A\00", align 1, !guid !18
@alloc_89b34d7fec2a8f2734794e189aa3d491 = private unnamed_addr constant [20 x i8] c"core/src/num/f64.rs\00", align 1, !guid !19
@alloc_268e62c1ed567eb1c8f14587d73f3e3a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_89b34d7fec2a8f2734794e189aa3d491, [16 x i8] c"\13\00\00\00\00\00\00\001\06\00\00\09\00\00\00" }>, align 8, !guid !20
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !21
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !22
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !23
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !24
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !25
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !26
@alloc_30f7ecc1496f966bde691d01731e6f8e = private unnamed_addr constant [49 x i8] c"$min > max, or either was NaN. min = \C0\08, max = \C0\00", align 1, !guid !27
@alloc_a9c61c9f249d39e49475c00b6de04ee0 = private unnamed_addr constant [4 x i8] c"Less", align 1, !guid !28
@alloc_cd17b9cbc635e79a5454e667c96efc06 = private unnamed_addr constant [5 x i8] c"Equal", align 1, !guid !29
@alloc_a2975b4a9399ac4e26287fc3f00ae96d = private unnamed_addr constant [7 x i8] c"Greater", align 1, !guid !30
@alloc_252aee8158a2b6b4b1e300c3f8f7bd7a = private unnamed_addr constant [15 x i8] c"ParseFloatError", align 1, !guid !31
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !32
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse14FloatErrorKindNtB6_5Debug3fmtCsaSF28CXLCD9_9float_f64 }>, align 8, !guid !33
@alloc_59ba7b9f7211443cd55a366616eef46a = private unnamed_addr constant [5 x i8] c"Empty", align 1, !guid !34
@alloc_6693e43df3406efcf64b4ab3d59228bb = private unnamed_addr constant [7 x i8] c"Invalid", align 1, !guid !35
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !36
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsaSF28CXLCD9_9float_f64 }>, align 8, !guid !37
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !38
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse15ParseFloatErrorNtB6_5Debug3fmtCsaSF28CXLCD9_9float_f64 }>, align 8, !guid !39
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCsaSF28CXLCD9_9float_f64 }>, align 8, !guid !40

; <str>::parse::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !46 {
start:
; call <f64 as core::str::traits::FromStr>::from_str
  call void @_RNvXs2_NtNtCsl10jNU3mE6R_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #12
  ret void
}

; <core::result::Result<f64, core::num::float_parse::ParseFloatError>>::map::<bool, float_f64::main::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultdNtNtNtB5_3num11float_parse15ParseFloatErrorE3mapbNCNvCsaSF28CXLCD9_9float_f644main0EB1A_(ptr align 8 %self) unnamed_addr #0 !guid !47 {
start:
  %_9 = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  %4 = load i8, ptr %3, align 1
  %e = trunc nuw i8 %4 to i1
  %5 = getelementptr inbounds i8, ptr %_0, i64 1
  %6 = zext i1 %e to i8
  store i8 %6, ptr %5, align 1
  store i8 1, ptr %_0, align 1
  br label %bb7

bb3:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load double, ptr %7, align 8
  store i8 0, ptr %_9, align 1
; call float_f64::main::{closure#0}
  %_5 = call zeroext i1 @_RNCNvCsaSF28CXLCD9_9float_f644main0B3_(double %t) #13
  %8 = getelementptr inbounds i8, ptr %_0, i64 1
  %9 = zext i1 %_5 to i8
  store i8 %9, ptr %8, align 1
  store i8 0, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %10 = load i8, ptr %_9, align 1
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %12 = load i8, ptr %_0, align 1
  %13 = trunc nuw i8 %12 to i1
  %14 = getelementptr inbounds i8, ptr %_0, i64 1
  %15 = load i8, ptr %14, align 1
  %16 = insertvalue { i1, i8 } poison, i1 %13, 0
  %17 = insertvalue { i1, i8 } %16, i8 %15, 1
  ret { i1, i8 } %17

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !48 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsaSF28CXLCD9_9float_f64(ptr %x) #13
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !49 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !50 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCsaSF28CXLCD9_9float_f64(ptr align 16 %x) #13
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !51 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_exp::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !52 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs8_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8LowerExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_exp::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_expdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !53 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs9_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8UpperExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<bool, core::num::float_parse::ParseFloatError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultbNtNtNtB7_3num11float_parse15ParseFloatErrorEECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !54 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<bool, core::num::float_parse::ParseFloatError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultbNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCsaSF28CXLCD9_9float_f64(ptr %x) #13
; call <core::ptr::non_null::NonNull<core::result::Result<bool, core::num::float_parse::ParseFloatError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultbNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultbNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<f64, core::num::float_parse::ParseFloatError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorEECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !55 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<f64, core::num::float_parse::ParseFloatError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultdNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<core::result::Result<f64, core::num::float_parse::ParseFloatError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultdNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::cmp::Ordering>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_3cmp8OrderingECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !56 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::cmp::Ordering>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_3cmp8OrderingE8from_refCsaSF28CXLCD9_9float_f64(ptr %x) #13
; call <core::ptr::non_null::NonNull<core::cmp::Ordering>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_3cmp8OrderingE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtCsl10jNU3mE6R_4core3cmpNtB5_8OrderingNtNtB7_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !57 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsaSF28CXLCD9_9float_f64(ptr %x) #13
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsaSF28CXLCD9_9float_f64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !58 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsaSF28CXLCD9_9float_f64(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::result::Result<bool, core::num::float_parse::ParseFloatError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultbNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECsaSF28CXLCD9_9float_f64(ptr %self) unnamed_addr #0 !guid !59 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<f64, core::num::float_parse::ParseFloatError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultdNtNtNtBa_3num11float_parse15ParseFloatErrorEE4castuECsaSF28CXLCD9_9float_f64(ptr %self) unnamed_addr #0 !guid !60 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::cmp::Ordering>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_3cmp8OrderingE4castuECsaSF28CXLCD9_9float_f64(ptr %self) unnamed_addr #0 !guid !61 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[f64]>>::cast::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSdE4castdECsaSF28CXLCD9_9float_f64(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !62 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsaSF28CXLCD9_9float_f64(ptr %self) unnamed_addr #0 !guid !63 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsaSF28CXLCD9_9float_f64(ptr %self) unnamed_addr #0 !guid !64 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECsaSF28CXLCD9_9float_f64(ptr %self) unnamed_addr #0 !guid !65 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECsaSF28CXLCD9_9float_f64(ptr %self) unnamed_addr #0 !guid !66 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<16, 5>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECsaSF28CXLCD9_9float_f64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !67 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<36, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj24_Kj3_ECsaSF28CXLCD9_9float_f64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !68 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<40, 7>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj28_Kj7_ECsaSF28CXLCD9_9float_f64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !69 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaSF28CXLCD9_9float_f64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !70 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECsaSF28CXLCD9_9float_f64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !71 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsaSF28CXLCD9_9float_f64(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !72 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double %dummy) unnamed_addr #0 !guid !73 {
start:
  %_0 = alloca [8 x i8], align 8
  store double %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load double, ptr %_0, align 8
  ret double %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsaSF28CXLCD9_9float_f64(i32 %dummy) unnamed_addr #0 !guid !75 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaSF28CXLCD9_9float_f64(i64 %dummy) unnamed_addr #0 !guid !76 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsaSF28CXLCD9_9float_f64(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !77 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaSF28CXLCD9_9float_f64(ptr %f) #13
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #13
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::iter::adapters::map::map_fold::<&f64, f64, f64, <f64 as core::clone::Clone>::clone, <f64>::max>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRdddNvYdNtNtB8_5clone5Clone5cloneNvMNtB8_3f64d3maxECsaSF28CXLCD9_9float_f64() unnamed_addr #1 !guid !78 {
start:
  ret void
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<f64>, <f64 as core::clone::Clone>::clone> as core::iter::traits::iterator::Iterator>::fold::<f64, <f64>::max>
; Function Attrs: nonlazybind uwtable
define internal double @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterdENvYdNtNtBc_5clone5Clone5cloneENtNtNtBa_6traits8iterator8Iterator4folddNvMNtBc_3f64d3maxECsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1, double %init) unnamed_addr #1 personality ptr @rust_eh_personality !guid !79 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
; call core::iter::adapters::map::map_fold::<&f64, f64, f64, <f64 as core::clone::Clone>::clone, <f64>::max>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRdddNvYdNtNtB8_5clone5Clone5cloneNvMNtB8_3f64d3maxECsaSF28CXLCD9_9float_f64()
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::fold::<f64, core::iter::adapters::map::map_fold<&f64, f64, f64, <f64 as core::clone::Clone>::clone, <f64>::max>::{closure#0}>
  %_0 = call double @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterdENtNtNtNtBb_4iter6traits8iterator8Iterator4folddNCINvNtNtBY_8adapters3map8map_foldRdddNvYdNtNtBb_5clone5Clone5cloneNvMNtBb_3f64d3maxE0ECsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1, double %init) #13
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_9, align 1
  ret double %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <f64 as core::iter::traits::accum::Sum<&f64>>::sum::<core::slice::iter::Iter<f64>>
; Function Attrs: nonlazybind uwtable
define internal double @_RINvXs28_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumdINtB7_3SumRdE3sumINtNtNtBd_5slice4iter4IterdEECsaSF28CXLCD9_9float_f64(ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !80 {
start:
; call <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::fold::<f64, <f64 as core::iter::traits::accum::Sum<&f64>>::sum<core::slice::iter::Iter<f64>>::{closure#0}>
  %_0 = call double @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterdENtNtNtNtBb_4iter6traits8iterator8Iterator4folddNCINvXs28_NtBW_5accumdINtB1N_3SumRdE3sumBF_E0ECsaSF28CXLCD9_9float_f64(ptr %iter.0, ptr %iter.1, double -0.000000e+00) #13
  ret double %_0
}

; <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::fold::<f64, core::iter::adapters::map::map_fold<&f64, f64, f64, <f64 as core::clone::Clone>::clone, <f64>::max>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterdENtNtNtNtBb_4iter6traits8iterator8Iterator4folddNCINvNtNtBY_8adapters3map8map_foldRdddNvYdNtNtBb_5clone5Clone5cloneNvMNtBb_3f64d3maxE0ECsaSF28CXLCD9_9float_f64(ptr %0, ptr %1, double %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !81 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %acc = alloca [8 x i8], align 8
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %f = alloca [0 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %3, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
  %4 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %end) #13
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %6 = load i8, ptr %_4, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store double %init, ptr %acc, align 8
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store double %init, ptr %_0, align 8
  br label %bb16

bb8:                                              ; preds = %bb6
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %8, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<f64>>::offset_from_unsigned
  %9 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE20offset_from_unsignedCsaSF28CXLCD9_9float_f64(ptr %_17, ptr %_18) #13
  store i64 %9, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_22 = load double, ptr %acc, align 8
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw double, ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call core::iter::adapters::map::map_fold::<&f64, f64, f64, <f64 as core::clone::Clone>::clone, <f64>::max>::{closure#0}
  %_19 = call double @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRdddNvYdNtNtBa_5clone5Clone5cloneNvMNtBa_3f64d3maxE0CsaSF28CXLCD9_9float_f64(ptr %f, double %_22, ptr align 8 %_3.i) #13
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  store double %_19, ptr %acc, align 8
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaSF28CXLCD9_9float_f64() #13
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCsaSF28CXLCD9_9float_f64(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #14
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  %10 = load double, ptr %acc, align 8
  store double %10, ptr %_0, align 8
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  %11 = load double, ptr %_0, align 8
  ret double %11

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::fold::<f64, <f64 as core::iter::traits::accum::Sum<&f64>>::sum<core::slice::iter::Iter<f64>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterdENtNtNtNtBb_4iter6traits8iterator8Iterator4folddNCINvXs28_NtBW_5accumdINtB1N_3SumRdE3sumBF_E0ECsaSF28CXLCD9_9float_f64(ptr %0, ptr %1, double %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !82 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %acc = alloca [8 x i8], align 8
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %f = alloca [0 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %3, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
  %4 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %end) #13
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %6 = load i8, ptr %_4, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store double %init, ptr %acc, align 8
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store double %init, ptr %_0, align 8
  br label %bb16

bb8:                                              ; preds = %bb6
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %8, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<f64>>::offset_from_unsigned
  %9 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE20offset_from_unsignedCsaSF28CXLCD9_9float_f64(ptr %_17, ptr %_18) #13
  store i64 %9, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_22 = load double, ptr %acc, align 8
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw double, ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call <f64 as core::iter::traits::accum::Sum<&f64>>::sum::<core::slice::iter::Iter<f64>>::{closure#0}
  %_19 = call double @_RNCINvXs28_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumdINtB9_3SumRdE3sumINtNtNtBf_5slice4iter4IterdEE0CsaSF28CXLCD9_9float_f64(ptr %f, double %_22, ptr align 8 %_3.i) #13
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  store double %_19, ptr %acc, align 8
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaSF28CXLCD9_9float_f64() #13
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCsaSF28CXLCD9_9float_f64(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #14
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  %10 = load double, ptr %acc, align 8
  store double %10, ptr %_0, align 8
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  %11 = load double, ptr %_0, align 8
  ret double %11

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<f64>> as core::iter::traits::iterator::Iterator>::fold::<f64, <f64>::max>
; Function Attrs: nonlazybind uwtable
define internal double @_RINvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB5_6ClonedINtNtNtBb_5slice4iter4IterdEENtNtNtB9_6traits8iterator8Iterator4folddNvMNtBb_3f64d3maxECsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1, double %init) unnamed_addr #1 personality ptr @rust_eh_personality !guid !83 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
; call <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::map::<f64, <f64 as core::clone::Clone>::clone>
  %0 = call { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator3mapdNvYdNtNtBa_5clone5Clone5cloneECsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1) #13
  %_4.0 = extractvalue { ptr, ptr } %0, 0
  %_4.1 = extractvalue { ptr, ptr } %0, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<f64>, <f64 as core::clone::Clone>::clone> as core::iter::traits::iterator::Iterator>::fold::<f64, <f64>::max>
  %_0 = call double @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterdENvYdNtNtBc_5clone5Clone5cloneENtNtNtBa_6traits8iterator8Iterator4folddNvMNtBc_3f64d3maxECsaSF28CXLCD9_9float_f64(ptr %_4.0, ptr %_4.1, double %init)
  br label %bb2

bb2:                                              ; preds = %bb1
  ret double %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::map::<f64, <f64 as core::clone::Clone>::clone>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator3mapdNvYdNtNtBa_5clone5Clone5cloneECsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !84 {
start:
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<f64>, <f64 as core::clone::Clone>::clone>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4IterdENvYdNtNtB8_5clone5Clone5cloneE3newCsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::sum::<f64>
; Function Attrs: nonlazybind uwtable
define internal double @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator3sumdECsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !85 {
start:
; call <f64 as core::iter::traits::accum::Sum<&f64>>::sum::<core::slice::iter::Iter<f64>>
  %_0 = call double @_RINvXs28_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumdINtB7_3SumRdE3sumINtNtNtBd_5slice4iter4IterdEECsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1)
  ret double %_0
}

; <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::cloned::<f64>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator6cloneddECsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !86 {
start:
; call <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<f64>>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB2_6ClonedINtNtNtB8_5slice4iter4IterdEE3newCsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaSF28CXLCD9_9float_f64(ptr align 8 %_1) unnamed_addr #0 !guid !87 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsaSF28CXLCD9_9float_f64(ptr %_4) #12
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsaSF28CXLCD9_9float_f64() #13
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsaSF28CXLCD9_9float_f64(i8 %_2) #13
  ret i32 %_0
}

; core::iter::adapters::map::map_fold::<&f64, f64, f64, <f64 as core::clone::Clone>::clone, <f64>::max>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRdddNvYdNtNtBa_5clone5Clone5cloneNvMNtBa_3f64d3maxE0CsaSF28CXLCD9_9float_f64(ptr %_1, double %acc, ptr align 8 %elt) unnamed_addr #0 personality ptr @rust_eh_personality !guid !88 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
; call <<f64 as core::clone::Clone>::clone as core::ops::function::FnMut<(&f64,)>>::call_mut
  %_7 = call double @_RNvYNvYdNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBa_3ops8function5FnMutTRdEE8call_mutCsaSF28CXLCD9_9float_f64(ptr %_1, ptr align 8 %elt) #13
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call <<f64>::max as core::ops::function::FnMut<(f64, f64)>>::call_mut
  %_0 = call double @_RNvYNvMNtCsl10jNU3mE6R_4core3f64d3maxINtNtNtB7_3ops8function5FnMutTddEE8call_mutCsaSF28CXLCD9_9float_f64(ptr %_1, double %acc, double %_7) #13
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_10, align 1
  ret double %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <f64 as core::iter::traits::accum::Sum<&f64>>::sum::<core::slice::iter::Iter<f64>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNCINvXs28_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumdINtB9_3SumRdE3sumINtNtNtBf_5slice4iter4IterdEE0CsaSF28CXLCD9_9float_f64(ptr %_1, double %a, ptr align 8 %b) unnamed_addr #0 !guid !89 {
start:
; call <f64 as core::ops::arith::Add<&f64>>::add
  %_0 = call double @_RNvXsV_NtNtCsl10jNU3mE6R_4core3ops5arithdINtB5_3AddRdE3addCsaSF28CXLCD9_9float_f64(double %a, ptr align 8 %b, ptr align 8 @alloc_c9e69792a4316033abad0d4adaadd679) #13
  ret double %_0
}

; float_f64::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvCsaSF28CXLCD9_9float_f644main0B3_(double %x) unnamed_addr #0 !guid !90 {
start:
; call <f64>::is_nan
  %_0 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d6is_nanCsaSF28CXLCD9_9float_f64(double %x) #13
  ret i1 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsaSF28CXLCD9_9float_f64(ptr %_1) unnamed_addr #0 !guid !91 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaSF28CXLCD9_9float_f64(ptr %0) #13
  ret i32 %_0
}

; float_f64::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsaSF28CXLCD9_9float_f644main() unnamed_addr #1 !guid !92 {
start:
  %_286 = alloca [16 x i8], align 8
  %_285 = alloca [16 x i8], align 8
  %_284 = alloca [16 x i8], align 8
  %args26 = alloca [48 x i8], align 8
  %args25 = alloca [24 x i8], align 8
  %_274 = alloca [16 x i8], align 8
  %_273 = alloca [16 x i8], align 8
  %args24 = alloca [32 x i8], align 8
  %_267 = alloca [8 x i8], align 8
  %_262 = alloca [8 x i8], align 8
  %_255 = alloca [16 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %args23 = alloca [32 x i8], align 8
  %_251 = alloca [16 x i8], align 16
  %_248 = alloca [8 x i8], align 8
  %_241 = alloca [16 x i8], align 8
  %_240 = alloca [16 x i8], align 8
  %_239 = alloca [16 x i8], align 8
  %args22 = alloca [48 x i8], align 8
  %_237 = alloca [4 x i8], align 4
  %_234 = alloca [1 x i8], align 1
  %_231 = alloca [1 x i8], align 1
  %args21 = alloca [24 x i8], align 8
  %_224 = alloca [16 x i8], align 8
  %_223 = alloca [16 x i8], align 8
  %_222 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_218 = alloca [8 x i8], align 8
  %_215 = alloca [8 x i8], align 8
  %_213 = alloca [8 x i8], align 8
  %_210 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_198 = alloca [8 x i8], align 8
  %_196 = alloca [8 x i8], align 8
  %_189 = alloca [16 x i8], align 8
  %_188 = alloca [16 x i8], align 8
  %_187 = alloca [16 x i8], align 8
  %args17 = alloca [48 x i8], align 8
  %_184 = alloca [16 x i8], align 8
  %_181 = alloca [16 x i8], align 8
  %_180 = alloca [2 x i8], align 1
  %_177 = alloca [16 x i8], align 8
  %args16 = alloca [24 x i8], align 8
  %_170 = alloca [16 x i8], align 8
  %_169 = alloca [16 x i8], align 8
  %_168 = alloca [16 x i8], align 8
  %args15 = alloca [48 x i8], align 8
  %_165 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %_160 = alloca [1 x i8], align 1
  %_157 = alloca [16 x i8], align 8
  %args14 = alloca [24 x i8], align 8
  %_150 = alloca [16 x i8], align 8
  %_149 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [8 x i8], align 8
  %_142 = alloca [8 x i8], align 8
  %_135 = alloca [16 x i8], align 8
  %_134 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_131 = alloca [8 x i8], align 8
  %_124 = alloca [16 x i8], align 8
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_120 = alloca [8 x i8], align 8
  %_118 = alloca [8 x i8], align 8
  %_116 = alloca [8 x i8], align 8
  %args10 = alloca [24 x i8], align 8
  %_109 = alloca [16 x i8], align 8
  %_108 = alloca [16 x i8], align 8
  %_107 = alloca [16 x i8], align 8
  %_106 = alloca [16 x i8], align 8
  %args9 = alloca [64 x i8], align 8
  %_103 = alloca [8 x i8], align 8
  %_101 = alloca [8 x i8], align 8
  %_99 = alloca [8 x i8], align 8
  %_97 = alloca [8 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %_89 = alloca [16 x i8], align 8
  %_88 = alloca [16 x i8], align 8
  %_87 = alloca [16 x i8], align 8
  %args7 = alloca [64 x i8], align 8
  %_85 = alloca [8 x i8], align 8
  %_82 = alloca [8 x i8], align 8
  %_79 = alloca [8 x i8], align 8
  %_77 = alloca [8 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %a = alloca [8 x i8], align 8
  %_69 = alloca [16 x i8], align 8
  %_68 = alloca [16 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %args5 = alloca [48 x i8], align 8
  %_65 = alloca [1 x i8], align 1
  %_63 = alloca [1 x i8], align 1
  %_61 = alloca [1 x i8], align 1
  %args4 = alloca [24 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %_53 = alloca [16 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %_51 = alloca [16 x i8], align 8
  %_50 = alloca [16 x i8], align 8
  %args3 = alloca [80 x i8], align 8
  %_48 = alloca [1 x i8], align 1
  %_46 = alloca [1 x i8], align 1
  %_44 = alloca [8 x i8], align 8
  %args2 = alloca [40 x i8], align 8
  %inf = alloca [8 x i8], align 8
  %nan = alloca [8 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %_27 = alloca [16 x i8], align 8
  %_26 = alloca [16 x i8], align 8
  %_25 = alloca [16 x i8], align 8
  %_24 = alloca [16 x i8], align 8
  %args1 = alloca [112 x i8], align 8
  %args = alloca [56 x i8], align 8
  %x = alloca [8 x i8], align 8
  %_8 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %xs = alloca [96 x i8], align 8
  %0 = getelementptr inbounds nuw double, ptr %xs, i64 0
  store double 0.000000e+00, ptr %0, align 8
  %1 = getelementptr inbounds nuw double, ptr %xs, i64 1
  store double -0.000000e+00, ptr %1, align 8
  %2 = getelementptr inbounds nuw double, ptr %xs, i64 2
  store double 1.000000e+00, ptr %2, align 8
  %3 = getelementptr inbounds nuw double, ptr %xs, i64 3
  store double 1.000000e-01, ptr %3, align 8
  %4 = getelementptr inbounds nuw double, ptr %xs, i64 4
  store double f0x3FD5555555555555, ptr %4, align 8
  %5 = getelementptr inbounds nuw double, ptr %xs, i64 5
  store double f0x40FE240C9FBE76C9, ptr %5, align 8
  %6 = getelementptr inbounds nuw double, ptr %xs, i64 6
  store double 1.000000e+10, ptr %6, align 8
  %7 = getelementptr inbounds nuw double, ptr %xs, i64 7
  store double f0x3E7AD7F29ABCAF48, ptr %7, align 8
  %8 = getelementptr inbounds nuw double, ptr %xs, i64 8
  store double f0x7FEFFFFFFFFFFFFF, ptr %8, align 8
  %9 = getelementptr inbounds nuw double, ptr %xs, i64 9
  store double f0x0010000000000000, ptr %9, align 8
  %10 = getelementptr inbounds nuw double, ptr %xs, i64 10
  store double f0x3CB0000000000000, ptr %10, align 8
  %11 = getelementptr inbounds nuw double, ptr %xs, i64 11
  store double 2.500000e+00, ptr %11, align 8
; call <[f64]>::iter
  %12 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCsaSF28CXLCD9_9float_f64(ptr align 8 %xs, i64 12) #13
  %_4.0 = extractvalue { ptr, ptr } %12, 0
  %_4.1 = extractvalue { ptr, ptr } %12, 1
; call <core::slice::iter::Iter<f64> as core::iter::traits::collect::IntoIterator>::into_iter
  %13 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterdENtB2_12IntoIterator9into_iterCsaSF28CXLCD9_9float_f64(ptr %_4.0, ptr %_4.1) #13
  %_3.0 = extractvalue { ptr, ptr } %13, 0
  %_3.1 = extractvalue { ptr, ptr } %13, 1
  store ptr %_3.0, ptr %iter, align 8
  %14 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %14, align 8
  br label %bb3

bb3:                                              ; preds = %bb6, %start
; call <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::next
  %15 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsaSF28CXLCD9_9float_f64(ptr align 8 %iter) #13
  store ptr %15, ptr %_8, align 8
  %16 = load ptr, ptr %_8, align 8
  %17 = ptrtoint ptr %16 to i64
  %18 = icmp eq i64 %17, 0
  %_10 = select i1 %18, i64 0, i64 1
  %19 = trunc nuw i64 %_10 to i1
  br i1 %19, label %bb6, label %bb7

bb6:                                              ; preds = %bb3
  %_289 = load ptr, ptr %_8, align 8
  %x27 = load double, ptr %_289, align 8
; call core::hint::black_box::<f64>
  %20 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double %x27) #13
  store double %20, ptr %x, align 8
  store ptr %x, ptr %args, align 8
  %21 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %x, ptr %21, align 8
  %22 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr %x, ptr %22, align 8
  %23 = getelementptr inbounds i8, ptr %args, i64 24
  store ptr %x, ptr %23, align 8
  %24 = getelementptr inbounds i8, ptr %args, i64 32
  store ptr %x, ptr %24, align 8
  %25 = getelementptr inbounds i8, ptr %args, i64 40
  store ptr %x, ptr %25, align 8
  %26 = getelementptr inbounds i8, ptr %args, i64 48
  store ptr %x, ptr %26, align 8
  %_290 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_24, ptr align 8 %_290) #13
  %27 = getelementptr inbounds i8, ptr %args, i64 8
  %_291 = load ptr, ptr %27, align 8
; call <core::fmt::rt::Argument>::new_debug::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_25, ptr align 8 %_291) #13
  %28 = getelementptr inbounds i8, ptr %args, i64 16
  %_292 = load ptr, ptr %28, align 8
; call <core::fmt::rt::Argument>::new_lower_exp::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_26, ptr align 8 %_292) #13
  %29 = getelementptr inbounds i8, ptr %args, i64 24
  %_293 = load ptr, ptr %29, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_27, ptr align 8 %_293) #13
  %30 = getelementptr inbounds i8, ptr %args, i64 32
  %_294 = load ptr, ptr %30, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_28, ptr align 8 %_294) #13
  %31 = getelementptr inbounds i8, ptr %args, i64 40
  %_295 = load ptr, ptr %31, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_29, ptr align 8 %_295) #13
  %32 = getelementptr inbounds i8, ptr %args, i64 48
  %_296 = load ptr, ptr %32, align 8
; call <core::fmt::rt::Argument>::new_upper_exp::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_expdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_30, ptr align 8 %_296) #13
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_24, i64 16, i1 false)
  %34 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %34, ptr align 8 %_25, i64 16, i1 false)
  %35 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %35, ptr align 8 %_26, i64 16, i1 false)
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_27, i64 16, i1 false)
  %37 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %37, ptr align 8 %_28, i64 16, i1 false)
  %38 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %38, ptr align 8 %_29, i64 16, i1 false)
  %39 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 6
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %39, ptr align 8 %_30, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<40, 7>
  %40 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj28_Kj7_ECsaSF28CXLCD9_9float_f64(ptr @alloc_d5393a73b9ab337550d973a0f32943c1, ptr align 8 %args1) #13
  %_14.0 = extractvalue { ptr, ptr } %40, 0
  %_14.1 = extractvalue { ptr, ptr } %40, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_14.0, ptr %_14.1)
  br label %bb3

bb7:                                              ; preds = %bb3
; call core::hint::black_box::<f64>
  %_36 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double +qnan) #13
; call core::hint::black_box::<f64>
  %_37 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double +inf) #13
  store double %_36, ptr %nan, align 8
  store double %_37, ptr %inf, align 8
  %41 = load double, ptr %inf, align 8
  %42 = fneg double %41
  store double %42, ptr %_44, align 8
  %43 = load double, ptr %nan, align 8
  %44 = load double, ptr %nan, align 8
  %45 = fcmp oeq double %43, %44
  %46 = zext i1 %45 to i8
  store i8 %46, ptr %_46, align 1
  %47 = load double, ptr %nan, align 8
  %48 = load double, ptr %inf, align 8
  %49 = fcmp olt double %47, %48
  %50 = zext i1 %49 to i8
  store i8 %50, ptr %_48, align 1
  store ptr %nan, ptr %args2, align 8
  %51 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %inf, ptr %51, align 8
  %52 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %_44, ptr %52, align 8
  %53 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %_46, ptr %53, align 8
  %54 = getelementptr inbounds i8, ptr %args2, i64 32
  store ptr %_48, ptr %54, align 8
  %_297 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_50, ptr align 8 %_297) #13
  %55 = getelementptr inbounds i8, ptr %args2, i64 8
  %_298 = load ptr, ptr %55, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_51, ptr align 8 %_298) #13
  %56 = getelementptr inbounds i8, ptr %args2, i64 16
  %_299 = load ptr, ptr %56, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_52, ptr align 8 %_299) #13
  %57 = getelementptr inbounds i8, ptr %args2, i64 24
  %_300 = load ptr, ptr %57, align 8
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_53, ptr %_300) #13
  %58 = getelementptr inbounds i8, ptr %args2, i64 32
  %_301 = load ptr, ptr %58, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_54, ptr %_301) #13
  %59 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %59, ptr align 8 %_50, i64 16, i1 false)
  %60 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %60, ptr align 8 %_51, i64 16, i1 false)
  %61 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %61, ptr align 8 %_52, i64 16, i1 false)
  %62 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %62, ptr align 8 %_53, i64 16, i1 false)
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_54, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<16, 5>
  %64 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECsaSF28CXLCD9_9float_f64(ptr @alloc_6a96e47ef75dbf6fc4eb5423ba7bb768, ptr align 8 %args3) #13
  %_39.0 = extractvalue { ptr, ptr } %64, 0
  %_39.1 = extractvalue { ptr, ptr } %64, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_39.0, ptr %_39.1)
  %65 = load double, ptr %nan, align 8
; call <f64>::is_nan
  %66 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d6is_nanCsaSF28CXLCD9_9float_f64(double %65) #13
  %67 = zext i1 %66 to i8
  store i8 %67, ptr %_61, align 1
  %68 = load double, ptr %inf, align 8
; call <f64>::is_infinite
  %69 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d11is_infiniteCsaSF28CXLCD9_9float_f64(double %68) #13
  %70 = zext i1 %69 to i8
  store i8 %70, ptr %_63, align 1
; call <f64>::is_sign_negative
  %71 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d16is_sign_negativeCsaSF28CXLCD9_9float_f64(double -0.000000e+00) #13
  %72 = zext i1 %71 to i8
  store i8 %72, ptr %_65, align 1
  store ptr %_61, ptr %args4, align 8
  %73 = getelementptr inbounds i8, ptr %args4, i64 8
  store ptr %_63, ptr %73, align 8
  %74 = getelementptr inbounds i8, ptr %args4, i64 16
  store ptr %_65, ptr %74, align 8
  %_302 = load ptr, ptr %args4, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_67, ptr %_302) #13
  %75 = getelementptr inbounds i8, ptr %args4, i64 8
  %_303 = load ptr, ptr %75, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_68, ptr %_303) #13
  %76 = getelementptr inbounds i8, ptr %args4, i64 16
  %_304 = load ptr, ptr %76, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_69, ptr %_304) #13
  %77 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %77, ptr align 8 %_67, i64 16, i1 false)
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_68, i64 16, i1 false)
  %79 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %79, ptr align 8 %_69, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %80 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaSF28CXLCD9_9float_f64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args5) #13
  %_58.0 = extractvalue { ptr, ptr } %80, 0
  %_58.1 = extractvalue { ptr, ptr } %80, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_58.0, ptr %_58.1)
; call core::hint::black_box::<f64>
  %81 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 2.000000e+00) #13
  store double %81, ptr %a, align 8
  %82 = load double, ptr %a, align 8
; call <f64>::sqrt
  %83 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d4sqrtCsaSF28CXLCD9_9float_f64(double %82) #13
  store double %83, ptr %_77, align 8
; call core::hint::black_box::<i32>
  %_80 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsaSF28CXLCD9_9float_f64(i32 10) #13
  %84 = load double, ptr %a, align 8
; call <f64>::powi
  %85 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d4powiCsaSF28CXLCD9_9float_f64(double %84, i32 %_80) #13
  store double %85, ptr %_79, align 8
; call core::hint::black_box::<f64>
  %_83 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 5.000000e-01) #13
  %86 = load double, ptr %a, align 8
; call <f64>::powf
  %87 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d4powfCsaSF28CXLCD9_9float_f64(double %86, double %_83) #13
  store double %87, ptr %_82, align 8
  %88 = load double, ptr %a, align 8
; call <f64>::ln
  %89 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d2lnCsaSF28CXLCD9_9float_f64(double %88) #13
  store double %89, ptr %_85, align 8
  store ptr %_77, ptr %args6, align 8
  %90 = getelementptr inbounds i8, ptr %args6, i64 8
  store ptr %_79, ptr %90, align 8
  %91 = getelementptr inbounds i8, ptr %args6, i64 16
  store ptr %_82, ptr %91, align 8
  %92 = getelementptr inbounds i8, ptr %args6, i64 24
  store ptr %_85, ptr %92, align 8
  %_305 = load ptr, ptr %args6, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_87, ptr align 8 %_305) #13
  %93 = getelementptr inbounds i8, ptr %args6, i64 8
  %_306 = load ptr, ptr %93, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_88, ptr align 8 %_306) #13
  %94 = getelementptr inbounds i8, ptr %args6, i64 16
  %_307 = load ptr, ptr %94, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_89, ptr align 8 %_307) #13
  %95 = getelementptr inbounds i8, ptr %args6, i64 24
  %_308 = load ptr, ptr %95, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_90, ptr align 8 %_308) #13
  %96 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %96, ptr align 8 %_87, i64 16, i1 false)
  %97 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %97, ptr align 8 %_88, i64 16, i1 false)
  %98 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %98, ptr align 8 %_89, i64 16, i1 false)
  %99 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %99, ptr align 8 %_90, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 4>
  %100 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECsaSF28CXLCD9_9float_f64(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args7) #13
  %_74.0 = extractvalue { ptr, ptr } %100, 0
  %_74.1 = extractvalue { ptr, ptr } %100, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_74.0, ptr %_74.1)
  %101 = load double, ptr %a, align 8
; call <f64>::exp
  %102 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d3expCsaSF28CXLCD9_9float_f64(double %101) #13
  store double %102, ptr %_97, align 8
  %103 = load double, ptr %a, align 8
; call <f64>::sin
  %104 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d3sinCsaSF28CXLCD9_9float_f64(double %103) #13
  store double %104, ptr %_99, align 8
  %105 = load double, ptr %a, align 8
; call <f64>::cos
  %106 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d3cosCsaSF28CXLCD9_9float_f64(double %105) #13
  store double %106, ptr %_101, align 8
; call core::hint::black_box::<f64>
  %_104 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 3.000000e+00) #13
  %107 = load double, ptr %a, align 8
; call <f64>::atan2
  %108 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d5atan2CsaSF28CXLCD9_9float_f64(double %107, double %_104) #13
  store double %108, ptr %_103, align 8
  store ptr %_97, ptr %args8, align 8
  %109 = getelementptr inbounds i8, ptr %args8, i64 8
  store ptr %_99, ptr %109, align 8
  %110 = getelementptr inbounds i8, ptr %args8, i64 16
  store ptr %_101, ptr %110, align 8
  %111 = getelementptr inbounds i8, ptr %args8, i64 24
  store ptr %_103, ptr %111, align 8
  %_309 = load ptr, ptr %args8, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_106, ptr align 8 %_309) #13
  %112 = getelementptr inbounds i8, ptr %args8, i64 8
  %_310 = load ptr, ptr %112, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_107, ptr align 8 %_310) #13
  %113 = getelementptr inbounds i8, ptr %args8, i64 16
  %_311 = load ptr, ptr %113, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_108, ptr align 8 %_311) #13
  %114 = getelementptr inbounds i8, ptr %args8, i64 24
  %_312 = load ptr, ptr %114, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_109, ptr align 8 %_312) #13
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_106, i64 16, i1 false)
  %116 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %116, ptr align 8 %_107, i64 16, i1 false)
  %117 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %117, ptr align 8 %_108, i64 16, i1 false)
  %118 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %118, ptr align 8 %_109, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 4>
  %119 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECsaSF28CXLCD9_9float_f64(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args9) #13
  %_94.0 = extractvalue { ptr, ptr } %119, 0
  %_94.1 = extractvalue { ptr, ptr } %119, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_94.0, ptr %_94.1)
; call <f64>::floor
  %120 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d5floorCsaSF28CXLCD9_9float_f64(double 7.500000e+00) #13
  store double %120, ptr %_116, align 8
; call <f64>::round
  %121 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d5roundCsaSF28CXLCD9_9float_f64(double 7.500000e+00) #13
  store double %121, ptr %_118, align 8
; call <f64>::trunc
  %122 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d5truncCsaSF28CXLCD9_9float_f64(double -7.500000e+00) #13
  store double %122, ptr %_120, align 8
  store ptr %_116, ptr %args10, align 8
  %123 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_118, ptr %123, align 8
  %124 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_120, ptr %124, align 8
  %_313 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_122, ptr align 8 %_313) #13
  %125 = getelementptr inbounds i8, ptr %args10, i64 8
  %_314 = load ptr, ptr %125, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_123, ptr align 8 %_314) #13
  %126 = getelementptr inbounds i8, ptr %args10, i64 16
  %_315 = load ptr, ptr %126, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_124, ptr align 8 %_315) #13
  %127 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %127, ptr align 8 %_122, i64 16, i1 false)
  %128 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %128, ptr align 8 %_123, i64 16, i1 false)
  %129 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %129, ptr align 8 %_124, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %130 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaSF28CXLCD9_9float_f64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #13
  %_113.0 = extractvalue { ptr, ptr } %130, 0
  %_113.1 = extractvalue { ptr, ptr } %130, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_113.0, ptr %_113.1)
; call <f64>::rem_euclid
  %131 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d10rem_euclidCsaSF28CXLCD9_9float_f64(double 7.500000e+00, double 2.000000e+00) #13
  store double %131, ptr %_131, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_134, ptr align 8 %_131) #13
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_135, ptr align 8 @alloc_0e127f19757cb04e22d0ee81c1de547e) #13
  %132 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %132, ptr align 8 %_134, i64 16, i1 false)
  %133 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %133, ptr align 8 %_135, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %134 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #13
  %_128.0 = extractvalue { ptr, ptr } %134, 0
  %_128.1 = extractvalue { ptr, ptr } %134, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_128.0, ptr %_128.1)
; call core::hint::black_box::<f64>
  %_143 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 3.000000e+00) #13
; call core::hint::black_box::<f64>
  %_144 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 1.000000e+00) #13
  %135 = load double, ptr %a, align 8
; call <f64>::mul_add
  %136 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d7mul_addCsaSF28CXLCD9_9float_f64(double %135, double %_143, double %_144) #13
  store double %136, ptr %_142, align 8
; call core::hint::black_box::<f64>
  %_147 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 3.000000e+00) #13
  %137 = load double, ptr %a, align 8
; call <f64>::hypot
  %138 = call double @_RNvMNtCsddYV2PBJW9h_3std3f64d5hypotCsaSF28CXLCD9_9float_f64(double %137, double %_147) #13
  store double %138, ptr %_146, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_149, ptr align 8 %_142) #13
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_150, ptr align 8 %_146) #13
  %139 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %139, ptr align 8 %_149, i64 16, i1 false)
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_150, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %141 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #13
  %_139.0 = extractvalue { ptr, ptr } %141, 0
  %_139.1 = extractvalue { ptr, ptr } %141, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_139.0, ptr %_139.1)
; call <str>::parse::<f64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_157, ptr @alloc_89ca5133652a5226da26adbdfa0e2f97, i64 4) #13
; call <str>::parse::<f64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_162, ptr @alloc_13af184f83ea529683dab3456027e412, i64 3) #13
; call <core::result::Result<f64, core::num::float_parse::ParseFloatError>>::is_err
  %142 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultdNtNtNtB4_3num11float_parse15ParseFloatErrorE6is_errCsaSF28CXLCD9_9float_f64(ptr align 8 %_162) #13
  %143 = zext i1 %142 to i8
  store i8 %143, ptr %_160, align 1
; call <str>::parse::<f64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_165, ptr @alloc_bb740835b54142edad8629f403440288, i64 3) #13
  store ptr %_157, ptr %args14, align 8
  %144 = getelementptr inbounds i8, ptr %args14, i64 8
  store ptr %_160, ptr %144, align 8
  %145 = getelementptr inbounds i8, ptr %args14, i64 16
  store ptr %_165, ptr %145, align 8
  %_320 = load ptr, ptr %args14, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<f64, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorEECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_168, ptr align 8 %_320) #13
  %146 = getelementptr inbounds i8, ptr %args14, i64 8
  %_321 = load ptr, ptr %146, align 8
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_169, ptr %_321) #13
  %147 = getelementptr inbounds i8, ptr %args14, i64 16
  %_322 = load ptr, ptr %147, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<f64, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorEECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_170, ptr align 8 %_322) #13
  %148 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %148, ptr align 8 %_168, i64 16, i1 false)
  %149 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %149, ptr align 8 %_169, i64 16, i1 false)
  %150 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %150, ptr align 8 %_170, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %151 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaSF28CXLCD9_9float_f64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args15) #13
  %_154.0 = extractvalue { ptr, ptr } %151, 0
  %_154.1 = extractvalue { ptr, ptr } %151, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_154.0, ptr %_154.1)
; call <str>::parse::<f64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_177, ptr @alloc_6c433d3c07b7c6453f8a17b49b46c496, i64 3) #13
; call <str>::parse::<f64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_181, ptr @alloc_09041e75dc84c4f90838ba63407d8bea, i64 4) #13
; call <core::result::Result<f64, core::num::float_parse::ParseFloatError>>::map::<bool, float_f64::main::{closure#0}>
  %152 = call { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultdNtNtNtB5_3num11float_parse15ParseFloatErrorE3mapbNCNvCsaSF28CXLCD9_9float_f644main0EB1A_(ptr align 8 %_181) #13
  %153 = extractvalue { i1, i8 } %152, 0
  %154 = extractvalue { i1, i8 } %152, 1
  %155 = zext i1 %153 to i8
  store i8 %155, ptr %_180, align 1
  %156 = getelementptr inbounds i8, ptr %_180, i64 1
  store i8 %154, ptr %156, align 1
; call <str>::parse::<f64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_184, ptr @alloc_6e6e78314388fe4f511b82ed72e9a0ae, i64 2) #13
  store ptr %_177, ptr %args16, align 8
  %157 = getelementptr inbounds i8, ptr %args16, i64 8
  store ptr %_180, ptr %157, align 8
  %158 = getelementptr inbounds i8, ptr %args16, i64 16
  store ptr %_184, ptr %158, align 8
  %_323 = load ptr, ptr %args16, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<f64, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorEECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_187, ptr align 8 %_323) #13
  %159 = getelementptr inbounds i8, ptr %args16, i64 8
  %_324 = load ptr, ptr %159, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<bool, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultbNtNtNtB7_3num11float_parse15ParseFloatErrorEECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_188, ptr %_324) #13
  %160 = getelementptr inbounds i8, ptr %args16, i64 16
  %_325 = load ptr, ptr %160, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<f64, core::num::float_parse::ParseFloatError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorEECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_189, ptr align 8 %_325) #13
  %161 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %161, ptr align 8 %_187, i64 16, i1 false)
  %162 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %162, ptr align 8 %_188, i64 16, i1 false)
  %163 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %163, ptr align 8 %_189, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %164 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaSF28CXLCD9_9float_f64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args17) #13
  %_174.0 = extractvalue { ptr, ptr } %164, 0
  %_174.1 = extractvalue { ptr, ptr } %164, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_174.0, ptr %_174.1)
  %165 = load double, ptr %a, align 8
; call <f64>::to_bits
  %166 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3f64d7to_bitsCsaSF28CXLCD9_9float_f64(double %165) #13
  store i64 %166, ptr %_196, align 8
  %167 = load double, ptr %a, align 8
; call <f64>::to_bits
  %_200 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3f64d7to_bitsCsaSF28CXLCD9_9float_f64(double %167) #13
; call core::hint::black_box::<u64>
  %_199 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaSF28CXLCD9_9float_f64(i64 %_200) #13
; call <f64>::from_bits
  %168 = call double @_RNvMNtCsl10jNU3mE6R_4core3f64d9from_bitsCsaSF28CXLCD9_9float_f64(i64 %_199) #13
  store double %168, ptr %_198, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_202, ptr align 8 %_196) #13
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_203, ptr align 8 %_198) #13
  %169 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %169, ptr align 8 %_202, i64 16, i1 false)
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_203, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %171 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #13
  %_193.0 = extractvalue { ptr, ptr } %171, 0
  %_193.1 = extractvalue { ptr, ptr } %171, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_193.0, ptr %_193.1)
; call core::hint::black_box::<f64>
  %172 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 3.000000e+00) #13
  store double %172, ptr %_213, align 8
; call <f64>::total_cmp
  %173 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3f64d9total_cmpCsaSF28CXLCD9_9float_f64(ptr align 8 %a, ptr align 8 %_213) #13
  store i8 %173, ptr %_210, align 1
; call core::hint::black_box::<f64>
  %_216 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 1.500000e+00) #13
  %174 = load double, ptr %a, align 8
; call <f64>::min
  %175 = call double @_RNvMNtCsl10jNU3mE6R_4core3f64d3minCsaSF28CXLCD9_9float_f64(double %174, double %_216) #13
  store double %175, ptr %_215, align 8
; call core::hint::black_box::<f64>
  %_219 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 2.500000e+00) #13
; call core::hint::black_box::<f64>
  %_220 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 3.000000e+00) #13
  %176 = load double, ptr %a, align 8
; call <f64>::clamp
  %177 = call double @_RNvMNtCsl10jNU3mE6R_4core3f64d5clampCsaSF28CXLCD9_9float_f64(double %176, double %_219, double %_220) #13
  store double %177, ptr %_218, align 8
  store ptr %_210, ptr %args19, align 8
  %178 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_215, ptr %178, align 8
  %179 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_218, ptr %179, align 8
  %_328 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::cmp::Ordering>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_3cmp8OrderingECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_222, ptr %_328) #13
  %180 = getelementptr inbounds i8, ptr %args19, i64 8
  %_329 = load ptr, ptr %180, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_223, ptr align 8 %_329) #13
  %181 = getelementptr inbounds i8, ptr %args19, i64 16
  %_330 = load ptr, ptr %181, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_224, ptr align 8 %_330) #13
  %182 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %182, ptr align 8 %_222, i64 16, i1 false)
  %183 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %183, ptr align 8 %_223, i64 16, i1 false)
  %184 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %184, ptr align 8 %_224, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %185 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaSF28CXLCD9_9float_f64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #13
  %_207.0 = extractvalue { ptr, ptr } %185, 0
  %_207.1 = extractvalue { ptr, ptr } %185, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_207.0, ptr %_207.1)
; call core::hint::black_box::<f64>
  %_232 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 3.007000e+02) #13
  %186 = call i8 @llvm.fptoui.sat.i8.f64(double %_232)
  store i8 %186, ptr %_231, align 1
; call core::hint::black_box::<f64>
  %_235 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double -5.000000e+00) #13
  %187 = call i8 @llvm.fptoui.sat.i8.f64(double %_235)
  store i8 %187, ptr %_234, align 1
  %188 = load double, ptr %nan, align 8
  %189 = call i32 @llvm.fptosi.sat.i32.f64(double %188)
  store i32 %189, ptr %_237, align 4
  store ptr %_231, ptr %args21, align 8
  %190 = getelementptr inbounds i8, ptr %args21, i64 8
  store ptr %_234, ptr %190, align 8
  %191 = getelementptr inbounds i8, ptr %args21, i64 16
  store ptr %_237, ptr %191, align 8
  %_331 = load ptr, ptr %args21, align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_239, ptr %_331) #13
  %192 = getelementptr inbounds i8, ptr %args21, i64 8
  %_332 = load ptr, ptr %192, align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_240, ptr %_332) #13
  %193 = getelementptr inbounds i8, ptr %args21, i64 16
  %_333 = load ptr, ptr %193, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_241, ptr align 4 %_333) #13
  %194 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %194, ptr align 8 %_239, i64 16, i1 false)
  %195 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %195, ptr align 8 %_240, i64 16, i1 false)
  %196 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %196, ptr align 8 %_241, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %197 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaSF28CXLCD9_9float_f64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args22) #13
  %_228.0 = extractvalue { ptr, ptr } %197, 0
  %_228.1 = extractvalue { ptr, ptr } %197, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_228.0, ptr %_228.1)
; call core::hint::black_box::<f64>
  %_249 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double 1.000000e+30) #13
  %198 = call i64 @llvm.fptosi.sat.i64.f64(double %_249)
  store i64 %198, ptr %_248, align 8
; call core::hint::black_box::<f64>
  %_252 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECsaSF28CXLCD9_9float_f64(double -1.000000e+30) #13
  %199 = call i128 @llvm.fptosi.sat.i128.f64(double %_252)
  store i128 %199, ptr %_251, align 16
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_254, ptr align 8 %_248) #13
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_255, ptr align 16 %_251) #13
  %200 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %200, ptr align 8 %_254, i64 16, i1 false)
  %201 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %201, ptr align 8 %_255, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %202 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args23) #13
  %_245.0 = extractvalue { ptr, ptr } %202, 0
  %_245.1 = extractvalue { ptr, ptr } %202, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_245.0, ptr %_245.1)
; call <[f64]>::iter
  %203 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCsaSF28CXLCD9_9float_f64(ptr align 8 @alloc_dd7b99992a9c8295d5a6eb4440ee070f, i64 2) #13
  %_263.0 = extractvalue { ptr, ptr } %203, 0
  %_263.1 = extractvalue { ptr, ptr } %203, 1
; call <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::sum::<f64>
  %204 = call double @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator3sumdECsaSF28CXLCD9_9float_f64(ptr %_263.0, ptr %_263.1)
  store double %204, ptr %_262, align 8
; call <[f64]>::iter
  %205 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCsaSF28CXLCD9_9float_f64(ptr align 8 @alloc_dd7b99992a9c8295d5a6eb4440ee070f, i64 2) #13
  %_269.0 = extractvalue { ptr, ptr } %205, 0
  %_269.1 = extractvalue { ptr, ptr } %205, 1
; call <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::cloned::<f64>
  %206 = call { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator6cloneddECsaSF28CXLCD9_9float_f64(ptr %_269.0, ptr %_269.1)
  %_268.0 = extractvalue { ptr, ptr } %206, 0
  %_268.1 = extractvalue { ptr, ptr } %206, 1
; call <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<f64>> as core::iter::traits::iterator::Iterator>::fold::<f64, <f64>::max>
  %207 = call double @_RINvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB5_6ClonedINtNtNtBb_5slice4iter4IterdEENtNtNtB9_6traits8iterator8Iterator4folddNvMNtBb_3f64d3maxECsaSF28CXLCD9_9float_f64(ptr %_268.0, ptr %_268.1, double f0xFFEFFFFFFFFFFFFF)
  store double %207, ptr %_267, align 8
; call <core::fmt::rt::Argument>::new_debug::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_273, ptr align 8 %_262) #13
; call <core::fmt::rt::Argument>::new_debug::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_274, ptr align 8 %_267) #13
  %208 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %208, ptr align 8 %_273, i64 16, i1 false)
  %209 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %209, ptr align 8 %_274, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %210 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args24) #13
  %_259.0 = extractvalue { ptr, ptr } %210, 0
  %_259.1 = extractvalue { ptr, ptr } %210, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_259.0, ptr %_259.1)
  store ptr %a, ptr %args25, align 8
  %211 = getelementptr inbounds i8, ptr %args25, i64 8
  store ptr %a, ptr %211, align 8
  %212 = getelementptr inbounds i8, ptr %args25, i64 16
  store ptr %a, ptr %212, align 8
  %_338 = load ptr, ptr %args25, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_284, ptr align 8 %_338) #13
  %213 = getelementptr inbounds i8, ptr %args25, i64 8
  %_339 = load ptr, ptr %213, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_285, ptr align 8 %_339) #13
  %214 = getelementptr inbounds i8, ptr %args25, i64 16
  %_340 = load ptr, ptr %214, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_286, ptr align 8 %_340) #13
  %215 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %215, ptr align 8 %_284, i64 16, i1 false)
  %216 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %216, ptr align 8 %_285, i64 16, i1 false)
  %217 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %217, ptr align 8 %_286, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<36, 3>
  %218 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj24_Kj3_ECsaSF28CXLCD9_9float_f64(ptr @alloc_4f9e0d52b704c48a48195dee1a39f8e6, ptr align 8 %args26) #13
  %_278.0 = extractvalue { ptr, ptr } %218, 0
  %_278.1 = extractvalue { ptr, ptr } %218, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_278.0, ptr %_278.1)
  ret void

bb5:                                              ; No predecessors!
  unreachable
}

; <f64>::rem_euclid
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d10rem_euclidCsaSF28CXLCD9_9float_f64(double %self, double %rhs) unnamed_addr #0 !guid !93 {
start:
; call core::f64::math::rem_euclid
  %_0 = call double @_RNvNtNtCsl10jNU3mE6R_4core3f644math10rem_euclidCsaSF28CXLCD9_9float_f64(double %self, double %rhs) #13
  ret double %_0
}

; <f64>::ln
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d2lnCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !94 {
start:
  %_0 = call double @llvm.log.f64(double %self)
  ret double %_0
}

; <f64>::cos
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d3cosCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !95 {
start:
  %_0 = call double @llvm.cos.f64(double %self)
  ret double %_0
}

; <f64>::exp
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d3expCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !96 {
start:
  %_0 = call double @llvm.exp.f64(double %self)
  ret double %_0
}

; <f64>::sin
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d3sinCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !97 {
start:
  %_0 = call double @llvm.sin.f64(double %self)
  ret double %_0
}

; <f64>::powf
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d4powfCsaSF28CXLCD9_9float_f64(double %self, double %n) unnamed_addr #0 !guid !98 {
start:
  %_0 = call double @llvm.pow.f64(double %self, double %n)
  ret double %_0
}

; <f64>::powi
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d4powiCsaSF28CXLCD9_9float_f64(double %self, i32 %n) unnamed_addr #0 !guid !99 {
start:
; call core::f64::math::powi
  %_0 = call double @_RNvNtNtCsl10jNU3mE6R_4core3f644math4powiCsaSF28CXLCD9_9float_f64(double %self, i32 %n) #13
  ret double %_0
}

; <f64>::sqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d4sqrtCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !100 {
start:
; call core::f64::math::sqrt
  %_0 = call double @_RNvNtNtCsl10jNU3mE6R_4core3f644math4sqrtCsaSF28CXLCD9_9float_f64(double %self) #13
  ret double %_0
}

; <f64>::atan2
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d5atan2CsaSF28CXLCD9_9float_f64(double %self, double %other) unnamed_addr #0 !guid !101 {
start:
  %_0 = call double @atan2(double %self, double %other) #15
  ret double %_0
}

; <f64>::floor
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d5floorCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !102 {
start:
; call core::f64::math::floor
  %_0 = call double @_RNvNtNtCsl10jNU3mE6R_4core3f644math5floorCsaSF28CXLCD9_9float_f64(double %self) #13
  ret double %_0
}

; <f64>::hypot
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d5hypotCsaSF28CXLCD9_9float_f64(double %self, double %other) unnamed_addr #0 !guid !103 {
start:
  %_0 = call double @hypot(double %self, double %other) #15
  ret double %_0
}

; <f64>::round
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d5roundCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !104 {
start:
; call core::f64::math::round
  %_0 = call double @_RNvNtNtCsl10jNU3mE6R_4core3f644math5roundCsaSF28CXLCD9_9float_f64(double %self) #13
  ret double %_0
}

; <f64>::trunc
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d5truncCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !105 {
start:
; call core::f64::math::trunc
  %_0 = call double @_RNvNtNtCsl10jNU3mE6R_4core3f644math5truncCsaSF28CXLCD9_9float_f64(double %self) #13
  ret double %_0
}

; <f64>::mul_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d7mul_addCsaSF28CXLCD9_9float_f64(double %self, double %a, double %b) unnamed_addr #0 !guid !106 {
start:
; call core::f64::math::mul_add
  %_0 = call double @_RNvNtNtCsl10jNU3mE6R_4core3f644math7mul_addCsaSF28CXLCD9_9float_f64(double %self, double %a, double %b) #13
  ret double %_0
}

; <f64>::is_infinite
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d11is_infiniteCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !107 {
start:
  %_2 = fcmp oeq double %self, +inf
  %_3 = fcmp oeq double %self, -inf
  %_0 = or i1 %_2, %_3
  ret i1 %_0
}

; <f64>::is_sign_negative
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d16is_sign_negativeCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !108 {
start:
; call <f64>::to_bits
  %_3 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3f64d7to_bitsCsaSF28CXLCD9_9float_f64(double %self) #13
  %_2 = and i64 %_3, -9223372036854775808
  %_0 = icmp ne i64 %_2, 0
  ret i1 %_0
}

; <f64>::abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsl10jNU3mE6R_4core3f64d3absCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !109 {
start:
  %_0 = call double @llvm.fabs.f64(double %self)
  ret double %_0
}

; <f64>::max
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsl10jNU3mE6R_4core3f64d3maxCsaSF28CXLCD9_9float_f64(double %self, double %other) unnamed_addr #0 !guid !110 {
start:
  %_0 = call nsz double @llvm.maximumnum.f64(double %self, double %other)
  ret double %_0
}

; <f64>::min
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsl10jNU3mE6R_4core3f64d3minCsaSF28CXLCD9_9float_f64(double %self, double %other) unnamed_addr #0 !guid !111 {
start:
  %_0 = call nsz double @llvm.minimumnum.f64(double %self, double %other)
  ret double %_0
}

; <f64>::clamp
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsl10jNU3mE6R_4core3f64d5clampCsaSF28CXLCD9_9float_f64(double %0, double %min, double %max) unnamed_addr #0 !guid !112 {
start:
  %self = alloca [8 x i8], align 8
  store double %0, ptr %self, align 8
  %_4 = fcmp ole double %min, %max
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call <f64>::clamp::do_panic::runtime
  call void @_RNvNvNvMNtCsl10jNU3mE6R_4core3f64d5clamp8do_panic7runtimeCsaSF28CXLCD9_9float_f64(double %min, double %max, ptr align 8 @alloc_268e62c1ed567eb1c8f14587d73f3e3a) #16
  unreachable

_RNvNvMNtCsl10jNU3mE6R_4core3f64d5clamp8do_panic.exit: ; No predecessors!
  unreachable

bb1:                                              ; preds = %start
  %_7 = load double, ptr %self, align 8
  %_6 = fcmp olt double %_7, %min
  br i1 %_6, label %bb3, label %bb4

bb4:                                              ; preds = %bb3, %bb1
  %_9 = load double, ptr %self, align 8
  %_8 = fcmp ogt double %_9, %max
  br i1 %_8, label %bb5, label %bb6

bb3:                                              ; preds = %bb1
  store double %min, ptr %self, align 8
  br label %bb4

bb6:                                              ; preds = %bb5, %bb4
  %_0 = load double, ptr %self, align 8
  ret double %_0

bb5:                                              ; preds = %bb4
  store double %max, ptr %self, align 8
  br label %bb6
}

; <f64>::is_nan
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d6is_nanCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !113 {
start:
  %_0 = fcmp une double %self, %self
  ret i1 %_0
}

; <f64>::to_bits
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3f64d7to_bitsCsaSF28CXLCD9_9float_f64(double %self) unnamed_addr #0 !guid !114 {
start:
  %_0 = bitcast double %self to i64
  ret i64 %_0
}

; <f64>::from_bits
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsl10jNU3mE6R_4core3f64d9from_bitsCsaSF28CXLCD9_9float_f64(i64 %v) unnamed_addr #0 !guid !115 {
start:
  %_0 = bitcast i64 %v to double
  ret double %_0
}

; <f64>::total_cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3f64d9total_cmpCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !116 {
start:
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  %_5 = load double, ptr %self, align 8
; call <f64>::to_bits
  %_4 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3f64d7to_bitsCsaSF28CXLCD9_9float_f64(double %_5) #13
  store i64 %_4, ptr %left, align 8
  %_8 = load double, ptr %other, align 8
; call <f64>::to_bits
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3f64d7to_bitsCsaSF28CXLCD9_9float_f64(double %_8) #13
  store i64 %_7, ptr %right, align 8
  %_13 = load i64, ptr %left, align 8
  %_12 = ashr i64 %_13, 63
  %_10 = lshr i64 %_12, 1
  %0 = load i64, ptr %left, align 8
  %1 = xor i64 %0, %_10
  store i64 %1, ptr %left, align 8
  %_18 = load i64, ptr %right, align 8
  %_17 = ashr i64 %_18, 63
  %_15 = lshr i64 %_17, 1
  %2 = load i64, ptr %right, align 8
  %3 = xor i64 %2, %_15
  store i64 %3, ptr %right, align 8
; call <i64 as core::cmp::Ord>::cmp
  %_0 = call i8 @_RNvXs1f_NtNtCsl10jNU3mE6R_4core3cmp5implsxNtB8_3Ord3cmpCsaSF28CXLCD9_9float_f64(ptr align 8 %left, ptr align 8 %right) #13
  ret i8 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsaSF28CXLCD9_9float_f64(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !117 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <[f64]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCsaSF28CXLCD9_9float_f64(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !118 {
start:
; call <core::slice::iter::Iter<f64>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterdE3newCsaSF28CXLCD9_9float_f64(ptr align 8 %self.0, i64 %self.1) #13
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::result::Result<f64, core::num::float_parse::ParseFloatError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultdNtNtNtB4_3num11float_parse15ParseFloatErrorE5is_okCsaSF28CXLCD9_9float_f64(ptr align 8 %self) unnamed_addr #0 !guid !119 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<f64, core::num::float_parse::ParseFloatError>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultdNtNtNtB4_3num11float_parse15ParseFloatErrorE6is_errCsaSF28CXLCD9_9float_f64(ptr align 8 %self) unnamed_addr #0 !guid !120 {
start:
; call <core::result::Result<f64, core::num::float_parse::ParseFloatError>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultdNtNtNtB4_3num11float_parse15ParseFloatErrorE5is_okCsaSF28CXLCD9_9float_f64(ptr align 8 %self) #13
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <*mut f64>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOd20offset_from_unsignedCsaSF28CXLCD9_9float_f64(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !121 {
start:
; call <*const f64>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPd20offset_from_unsignedCsaSF28CXLCD9_9float_f64(ptr %self, ptr %origin, ptr align 8 %0) #13
  ret i64 %_0
}

; <*const f64>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPd20offset_from_unsignedCsaSF28CXLCD9_9float_f64(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !122 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaSF28CXLCD9_9float_f64() #13
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 8
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCsaSF28CXLCD9_9float_f64(ptr %self, ptr %origin, ptr align 8 %0) #14
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #17
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 8, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 8
  ret i64 %_0
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<f64>, <f64 as core::clone::Clone>::clone>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4IterdENvYdNtNtB8_5clone5Clone5cloneE3newCsaSF28CXLCD9_9float_f64(ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !123 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %iter.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %iter.1, 1
  ret { ptr, ptr } %1
}

; <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<f64>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB2_6ClonedINtNtNtB8_5slice4iter4IterdEE3newCsaSF28CXLCD9_9float_f64(ptr %it.0, ptr %it.1) unnamed_addr #1 !guid !124 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %it.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %it.1, 1
  ret { ptr, ptr } %1
}

; <core::ptr::non_null::NonNull<core::result::Result<bool, core::num::float_parse::ParseFloatError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultbNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCsaSF28CXLCD9_9float_f64(ptr %r) unnamed_addr #0 !guid !125 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<f64, core::num::float_parse::ParseFloatError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultdNtNtNtB9_3num11float_parse15ParseFloatErrorEE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %r) unnamed_addr #0 !guid !126 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::cmp::Ordering>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_3cmp8OrderingE8from_refCsaSF28CXLCD9_9float_f64(ptr %r) unnamed_addr #0 !guid !127 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[f64]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSdE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %r.0, i64 %r.1) unnamed_addr #0 !guid !128 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsaSF28CXLCD9_9float_f64(ptr %r) unnamed_addr #0 !guid !129 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE20offset_from_unsignedCsaSF28CXLCD9_9float_f64(ptr %self, ptr %subtracted) unnamed_addr #0 !guid !130 {
start:
; call <*mut f64>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOd20offset_from_unsignedCsaSF28CXLCD9_9float_f64(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #13
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %r) unnamed_addr #0 !guid !131 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCsaSF28CXLCD9_9float_f64(ptr align 16 %r) unnamed_addr #0 !guid !132 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %r) unnamed_addr #0 !guid !133 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaSF28CXLCD9_9float_f64(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !134 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsaSF28CXLCD9_9float_f64(ptr %s.0, i64 %s.1) #13
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<f64>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterdE3newCsaSF28CXLCD9_9float_f64(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !135 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[f64]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSdE8from_refCsaSF28CXLCD9_9float_f64(ptr align 8 %slice.0, i64 %slice.1) #13
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[f64]>>::cast::<f64>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSdE4castdECsaSF28CXLCD9_9float_f64(ptr %_4.0, i64 %_4.1) #13
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw double, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsaSF28CXLCD9_9float_f64(ptr %self) unnamed_addr #0 !guid !136 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsaSF28CXLCD9_9float_f64(i8 %0) unnamed_addr #0 !guid !137 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsaSF28CXLCD9_9float_f64(ptr %self) #13
  ret i32 %_0
}

; core::intrinsics::maximum_number_nsz_f64
; Function Attrs: nounwind nonlazybind uwtable
define internal double @_RNvNtCsl10jNU3mE6R_4core10intrinsics22maximum_number_nsz_f64CsaSF28CXLCD9_9float_f64(double %x, double %y) unnamed_addr #3 personality ptr @rust_eh_personality !guid !138 {
start:
  %_0 = alloca [8 x i8], align 8
; invoke <f64>::is_nan
  %_3 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d6is_nanCsaSF28CXLCD9_9float_f64(double %x)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb3, label %bb2

bb2:                                              ; preds = %bb1
  %_4 = fcmp oge double %y, %x
  br i1 %_4, label %bb3, label %bb4

bb3:                                              ; preds = %bb2, %bb1
  store double %y, ptr %_0, align 8
  br label %bb5

bb4:                                              ; preds = %bb2
  store double %x, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %1 = load double, ptr %_0, align 8
  ret double %1
}

; core::intrinsics::minimum_number_nsz_f64
; Function Attrs: nounwind nonlazybind uwtable
define internal double @_RNvNtCsl10jNU3mE6R_4core10intrinsics22minimum_number_nsz_f64CsaSF28CXLCD9_9float_f64(double %x, double %y) unnamed_addr #3 personality ptr @rust_eh_personality !guid !139 {
start:
  %_0 = alloca [8 x i8], align 8
; invoke <f64>::is_nan
  %_3 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d6is_nanCsaSF28CXLCD9_9float_f64(double %x)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb3, label %bb2

bb2:                                              ; preds = %bb1
  %_4 = fcmp ole double %y, %x
  br i1 %_4, label %bb3, label %bb4

bb3:                                              ; preds = %bb2, %bb1
  store double %y, ptr %_0, align 8
  br label %bb5

bb4:                                              ; preds = %bb2
  store double %x, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %1 = load double, ptr %_0, align 8
  ret double %1
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaSF28CXLCD9_9float_f64() unnamed_addr #0 !guid !140 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsaSF28CXLCD9_9float_f64() #13
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::f64::math::rem_euclid
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvNtNtCsl10jNU3mE6R_4core3f644math10rem_euclidCsaSF28CXLCD9_9float_f64(double %x, double %rhs) unnamed_addr #0 !guid !141 {
start:
  %_0 = alloca [8 x i8], align 8
  %r = frem double %x, %rhs
  %_4 = fcmp olt double %r, 0.000000e+00
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store double %r, ptr %_0, align 8
  br label %bb4

bb1:                                              ; preds = %start
; call <f64>::abs
  %_5 = call double @_RNvMNtCsl10jNU3mE6R_4core3f64d3absCsaSF28CXLCD9_9float_f64(double %rhs) #13
  %0 = fadd double %r, %_5
  store double %0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb1, %bb3
  %1 = load double, ptr %_0, align 8
  ret double %1
}

; core::f64::math::powi
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvNtNtCsl10jNU3mE6R_4core3f644math4powiCsaSF28CXLCD9_9float_f64(double %x, i32 %n) unnamed_addr #0 !guid !142 {
start:
  %_0 = call double @llvm.powi.f64.i32(double %x, i32 %n)
  ret double %_0
}

; core::f64::math::sqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvNtNtCsl10jNU3mE6R_4core3f644math4sqrtCsaSF28CXLCD9_9float_f64(double %x) unnamed_addr #0 !guid !143 {
start:
  %_0 = call double @llvm.sqrt.f64(double %x)
  ret double %_0
}

; core::f64::math::floor
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvNtNtCsl10jNU3mE6R_4core3f644math5floorCsaSF28CXLCD9_9float_f64(double %x) unnamed_addr #0 !guid !144 {
start:
  %_0 = call double @llvm.floor.f64(double %x)
  ret double %_0
}

; core::f64::math::round
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvNtNtCsl10jNU3mE6R_4core3f644math5roundCsaSF28CXLCD9_9float_f64(double %x) unnamed_addr #0 !guid !145 {
start:
  %_0 = call double @llvm.round.f64(double %x)
  ret double %_0
}

; core::f64::math::trunc
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvNtNtCsl10jNU3mE6R_4core3f644math5truncCsaSF28CXLCD9_9float_f64(double %x) unnamed_addr #0 !guid !146 {
start:
  %_0 = call double @llvm.trunc.f64(double %x)
  ret double %_0
}

; core::f64::math::mul_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvNtNtCsl10jNU3mE6R_4core3f644math7mul_addCsaSF28CXLCD9_9float_f64(double %x, double %a, double %b) unnamed_addr #0 !guid !147 {
start:
  %_0 = call double @llvm.fma.f64(double %x, double %a, double %b)
  ret double %_0
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCsaSF28CXLCD9_9float_f64(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !148 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaSF28CXLCD9_9float_f64(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCsaSF28CXLCD9_9float_f64(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !149 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaSF28CXLCD9_9float_f64(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsaSF28CXLCD9_9float_f64() unnamed_addr #0 !guid !150 {
start:
  ret i1 true
}

; <f64>::clamp::do_panic::runtime
; Function Attrs: inlinehint noreturn nonlazybind uwtable
define internal void @_RNvNvNvMNtCsl10jNU3mE6R_4core3f64d5clamp8do_panic7runtimeCsaSF28CXLCD9_9float_f64(double %0, double %1, ptr align 8 %2) unnamed_addr #5 !guid !151 {
start:
  %_10 = alloca [16 x i8], align 8
  %_9 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %max = alloca [8 x i8], align 8
  %min = alloca [8 x i8], align 8
  store double %0, ptr %min, align 8
  store double %1, ptr %max, align 8
; call <core::fmt::rt::Argument>::new_debug::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_9, ptr align 8 %min) #13
; call <core::fmt::rt::Argument>::new_debug::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECsaSF28CXLCD9_9float_f64(ptr sret([16 x i8]) align 8 %_10, ptr align 8 %max) #13
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_9, i64 16, i1 false)
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_10, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<49, 2>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj31_Kj2_EB8_(ptr @alloc_30f7ecc1496f966bde691d01731e6f8e, ptr align 8 %args) #13
  %_4.0 = extractvalue { ptr, ptr } %5, 0
  %_4.1 = extractvalue { ptr, ptr } %5, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_4.0, ptr %_4.1, ptr align 8 %2) #17
  unreachable
}

; <core::slice::iter::Iter<f64> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterdENtB2_12IntoIterator9into_iterCsaSF28CXLCD9_9float_f64(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !152 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <i64 as core::cmp::Ord>::cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXs1f_NtNtCsl10jNU3mE6R_4core3cmp5implsxNtB8_3Ord3cmpCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !153 {
start:
  %_3 = load i64, ptr %self, align 8
  %_4 = load i64, ptr %other, align 8
  %_0 = call i8 @llvm.scmp.i8.i64(i64 %_3, i64 %_4)
  ret i8 %_0
}

; <&core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse14FloatErrorKindNtB6_5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !154 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_14FloatErrorKindNtNtB9_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr %_3, ptr align 8 %f) #13
  ret i1 %_0
}

; <&core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse15ParseFloatErrorNtB6_5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !155 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_15ParseFloatErrorNtNtB9_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr %_3, ptr align 8 %f) #13
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !156 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr %_3, ptr align 8 %f) #13
  ret i1 %_0
}

; <&f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !157 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <f64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsaSF28CXLCD9_9float_f64(ptr align 8 %self) unnamed_addr #0 !guid !158 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCsaSF28CXLCD9_9float_f64(ptr align 8 %ptr, ptr align 8 %_11) #13
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw double, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::cmp::Ordering as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtCsl10jNU3mE6R_4core3cmpNtB5_8OrderingNtNtB7_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !159 {
start:
  %_3 = alloca [16 x i8], align 8
  %_4 = load i8, ptr %self, align 1
  switch i8 %_4, label %bb1 [
    i8 -1, label %bb4
    i8 0, label %bb3
    i8 1, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb4:                                              ; preds = %start
  store ptr @alloc_a9c61c9f249d39e49475c00b6de04ee0, ptr %_3, align 8, !captures !160
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %0, align 8
  br label %bb5

bb3:                                              ; preds = %start
  store ptr @alloc_cd17b9cbc635e79a5454e667c96efc06, ptr %_3, align 8, !captures !160
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %1, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr @alloc_a2975b4a9399ac4e26287fc3f00ae96d, ptr %_3, align 8, !captures !160
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 7, ptr %2, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3, %bb4
  %3 = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %5 = load i64, ptr %4, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %3, i64 %5)
  ret i1 %_0
}

; <core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_15ParseFloatErrorNtNtB9_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !161 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_252aee8158a2b6b4b1e300c3f8f7bd7a, i64 15, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.1)
  ret i1 %_0
}

; <core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_14FloatErrorKindNtNtB9_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !162 {
start:
  %_3 = alloca [16 x i8], align 8
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %_4 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_4 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr @alloc_6693e43df3406efcf64b4ab3d59228bb, ptr %_3, align 8, !captures !160
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 7, ptr %3, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store ptr @alloc_59ba7b9f7211443cd55a366616eef46a, ptr %_3, align 8, !captures !160
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %4, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_3, align 8
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  %7 = load i64, ptr %6, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %5, i64 %7)
  ret i1 %_0

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsaSF28CXLCD9_9float_f64() unnamed_addr #0 !guid !163 {
start:
  ret i8 0
}

; <f64 as core::ops::arith::Add<&f64>>::add
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvXsV_NtNtCsl10jNU3mE6R_4core3ops5arithdINtB5_3AddRdE3addCsaSF28CXLCD9_9float_f64(double %self, ptr align 8 %other, ptr align 8 %0) unnamed_addr #0 !guid !164 {
start:
  %_3 = load double, ptr %other, align 8
; call <f64 as core::ops::arith::Add>::add
  %_0 = call double @_RNvXsc_NtNtCsl10jNU3mE6R_4core3ops5arithdNtB5_3Add3addCsaSF28CXLCD9_9float_f64(double %self, double %_3, ptr align 8 %0) #13
  ret double %_0
}

; <f64 as core::ops::arith::Add>::add
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvXsc_NtNtCsl10jNU3mE6R_4core3ops5arithdNtB5_3Add3addCsaSF28CXLCD9_9float_f64(double %self, double %other, ptr align 8 %0) unnamed_addr #0 !guid !165 {
start:
  %_0 = fadd double %self, %other
  ret double %_0
}

; <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !166 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !167 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::result::Result<bool, core::num::float_parse::ParseFloatError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultbNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !168 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.3)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %8, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.2)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<f64, core::num::float_parse::ParseFloatError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultdNtNtNtB7_3num11float_parse15ParseFloatErrorENtNtB7_3fmt5Debug3fmtCsaSF28CXLCD9_9float_f64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !169 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.3)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaSF28CXLCD9_9float_f64(ptr %_1) unnamed_addr #0 !guid !170 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaSF28CXLCD9_9float_f64(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !171 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaSF28CXLCD9_9float_f64(ptr align 8 %_1) #13
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<f64>::max as core::ops::function::FnMut<(f64, f64)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvYNvMNtCsl10jNU3mE6R_4core3f64d3maxINtNtNtB7_3ops8function5FnMutTddEE8call_mutCsaSF28CXLCD9_9float_f64(ptr %_1, double %0, double %1) unnamed_addr #0 !guid !172 {
start:
  %_2 = alloca [16 x i8], align 8
  store double %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store double %1, ptr %2, align 8
  %3 = load double, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load double, ptr %4, align 8
; call <f64>::max
  %_0 = call double @_RNvMNtCsl10jNU3mE6R_4core3f64d3maxCsaSF28CXLCD9_9float_f64(double %3, double %5) #13
  ret double %_0
}

; <<f64 as core::clone::Clone>::clone as core::ops::function::FnMut<(&f64,)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvYNvYdNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBa_3ops8function5FnMutTRdEE8call_mutCsaSF28CXLCD9_9float_f64(ptr %_1, ptr align 8 %0) unnamed_addr #0 !guid !173 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
  %_0.i = load double, ptr %1, align 8
  ret double %_0.i
}

; <f64 as core::str::traits::FromStr>::from_str
; Function Attrs: noinline nonlazybind uwtable
declare void @_RNvXs2_NtNtCsl10jNU3mE6R_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str(ptr sret([16 x i8]) align 8, ptr, i64) unnamed_addr #2

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::LowerExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8LowerExp3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::UpperExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8UpperExp3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptoui.sat.i8.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptosi.sat.i32.f64(double) #7

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptosi.sat.i64.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptosi.sat.i128.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.pow.f64(double, double) #7

; Function Attrs: nounwind nonlazybind uwtable
declare double @atan2(double, double) unnamed_addr #3

; Function Attrs: nounwind nonlazybind uwtable
declare double @hypot(double, double) unnamed_addr #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.maximumnum.f64(double, double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.minimumnum.f64(double, double) #7

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #8

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.powi.f64.i32(double, i32) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.round.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.trunc.f64(double) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fma.f64(double, double, double) #7

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #10

; <core::fmt::Arguments>::new::<49, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj31_Kj2_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.scmp.i8.i64(i64, i64) #7

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #11 !guid !174 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsaSF28CXLCD9_9float_f64(ptr @_RNvCsaSF28CXLCD9_9float_f644main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nonlazybind "target-cpu"="x86-64" }
attributes #12 = { noinline }
attributes #13 = { inlinehint }
attributes #14 = { inlinehint nounwind }
attributes #15 = { nounwind }
attributes #16 = { inlinehint noreturn }
attributes #17 = { noinline noreturn }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noinline noreturn nounwind }

!llvm.module.flags = !{!41, !42, !43, !44}
!llvm.ident = !{!45}

!0 = !{i64 -2468238788130019501}
!1 = !{i64 -2528954861247219596}
!2 = !{i64 -2268723642298419087}
!3 = !{i64 5104685010968403931}
!4 = !{i64 -5177272751241120043}
!5 = !{i64 7282072756369330184}
!6 = !{i64 5190426958289154867}
!7 = !{i64 6997615020948522205}
!8 = !{i64 -867618113496432262}
!9 = !{i64 4964491512495451309}
!10 = !{i64 3752646593342844936}
!11 = !{i64 8362354497992441019}
!12 = !{i64 5271076852543853095}
!13 = !{i64 -3388023423986056108}
!14 = !{i64 -5804037948707386423}
!15 = !{i64 4683024262733437906}
!16 = !{i64 1000252214325143503}
!17 = !{i64 -3929750041206842780}
!18 = !{i64 401204110517305537}
!19 = !{i64 5745572327496284664}
!20 = !{i64 2309351917835184050}
!21 = !{i64 -7628666597183419708}
!22 = !{i64 6140289980640796625}
!23 = !{i64 6800522568908834350}
!24 = !{i64 -5186683536515904276}
!25 = !{i64 -2372433901022909816}
!26 = !{i64 -839227428619167116}
!27 = !{i64 7609982457802034034}
!28 = !{i64 9011416143514306634}
!29 = !{i64 6357600300915282347}
!30 = !{i64 -7279616658723123964}
!31 = !{i64 176524698791103270}
!32 = !{i64 -32525470372799762}
!33 = !{i64 -5584526080741444633}
!34 = !{i64 -8189714118051495596}
!35 = !{i64 -6283063406228933319}
!36 = !{i64 8510049130122194999}
!37 = !{i64 7229566905415579871}
!38 = !{i64 -2131198813381925172}
!39 = !{i64 2694392678136650012}
!40 = !{i64 -5616974469969882805}
!41 = !{i32 8, !"PIC Level", i32 2}
!42 = !{i32 7, !"PIE Level", i32 2}
!43 = !{i32 2, !"RtLibUseGOT", i32 1}
!44 = !{i32 7, !"uwtable", i32 2}
!45 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!46 = !{i64 -6290756865384093935}
!47 = !{i64 -3520724095265555918}
!48 = !{i64 5047511980510243186}
!49 = !{i64 2761346533341258782}
!50 = !{i64 -359390490598508926}
!51 = !{i64 805413325102555026}
!52 = !{i64 4928271845921445295}
!53 = !{i64 4023854951046627886}
!54 = !{i64 3763164011844167690}
!55 = !{i64 1568233076633711239}
!56 = !{i64 -476133106876337502}
!57 = !{i64 -6937470743699921432}
!58 = !{i64 2978779058693017887}
!59 = !{i64 -3804553439098340338}
!60 = !{i64 5549887969109860992}
!61 = !{i64 2606661052585305715}
!62 = !{i64 5225125564019812324}
!63 = !{i64 -5446144730931812417}
!64 = !{i64 -516772652785269281}
!65 = !{i64 6689252880061505188}
!66 = !{i64 6660860049081050646}
!67 = !{i64 -1385799245953891795}
!68 = !{i64 -1656661352020351757}
!69 = !{i64 6709896822176848335}
!70 = !{i64 4915462204847096695}
!71 = !{i64 8141017343412723675}
!72 = !{i64 4327100592011354343}
!73 = !{i64 -5596730212100677049}
!74 = !{i64 1318739643772736}
!75 = !{i64 -7777453473922126580}
!76 = !{i64 -6082745976112647885}
!77 = !{i64 7673460683733542088}
!78 = !{i64 8873331380161895769}
!79 = !{i64 -2774138064316795241}
!80 = !{i64 -669632213327946920}
!81 = !{i64 -3656431973208533945}
!82 = !{i64 -5448373936544057504}
!83 = !{i64 -3034098343543421702}
!84 = !{i64 2918595343797764242}
!85 = !{i64 -496120087848228234}
!86 = !{i64 -5125571414036667946}
!87 = !{i64 -3116484636764739172}
!88 = !{i64 1656527697392539320}
!89 = !{i64 -215674203682237735}
!90 = !{i64 6013087388293377489}
!91 = !{i64 3585040261907591598}
!92 = !{i64 -118211712481959295}
!93 = !{i64 -2633303175291367915}
!94 = !{i64 -5452112468785826582}
!95 = !{i64 -3378688774366701446}
!96 = !{i64 -251398250610314011}
!97 = !{i64 -233620561153399607}
!98 = !{i64 2225060991416783113}
!99 = !{i64 433977367558010693}
!100 = !{i64 -3058449269651501794}
!101 = !{i64 -2179748506110209981}
!102 = !{i64 -1994831257418373292}
!103 = !{i64 -1730153094408874852}
!104 = !{i64 -8575739133001615115}
!105 = !{i64 6517305134238918374}
!106 = !{i64 8447208272188837912}
!107 = !{i64 -1290915874823001725}
!108 = !{i64 -7385054604161588723}
!109 = !{i64 -1765142875480414154}
!110 = !{i64 4155489113115079141}
!111 = !{i64 8000208601393475414}
!112 = !{i64 1204695172169848913}
!113 = !{i64 330565568156554105}
!114 = !{i64 1879159234341136145}
!115 = !{i64 121741992581919230}
!116 = !{i64 -2848276247881653868}
!117 = !{i64 3260401908698085120}
!118 = !{i64 5117452815357778681}
!119 = !{i64 6727190447061535722}
!120 = !{i64 5757731355185000031}
!121 = !{i64 6493387747032902475}
!122 = !{i64 4569800415083465281}
!123 = !{i64 853212961454710194}
!124 = !{i64 8687933629714777212}
!125 = !{i64 7040429828688746188}
!126 = !{i64 8147447348301924920}
!127 = !{i64 -2369967706513358315}
!128 = !{i64 -197909283074377277}
!129 = !{i64 -651790152577197160}
!130 = !{i64 5606155610828576044}
!131 = !{i64 6120409742905922744}
!132 = !{i64 1470034453076392913}
!133 = !{i64 6936899408359628001}
!134 = !{i64 3147074974361244812}
!135 = !{i64 589012299619865649}
!136 = !{i64 -7698826257674190213}
!137 = !{i64 175714441272413886}
!138 = !{i64 -4872802368808486505}
!139 = !{i64 8383155504434417191}
!140 = !{i64 -6082672659074888119}
!141 = !{i64 -4140391168177156999}
!142 = !{i64 -4495235298622373092}
!143 = !{i64 -3336862363173761781}
!144 = !{i64 9192466695922136400}
!145 = !{i64 6111118566652227874}
!146 = !{i64 -331717433971303396}
!147 = !{i64 2241049234859016476}
!148 = !{i64 -3164157842408047019}
!149 = !{i64 690844928399306160}
!150 = !{i64 -2414613161439808114}
!151 = !{i64 7700644499453242882}
!152 = !{i64 -490272785435250797}
!153 = !{i64 959091415668869665}
!154 = !{i64 -1841506480405082074}
!155 = !{i64 -4135125921320960403}
!156 = !{i64 7685628741456065023}
!157 = !{i64 -3833260783841205819}
!158 = !{i64 1350646028249914742}
!159 = !{i64 -6341263017826528573}
!160 = !{!"address", !"read_provenance"}
!161 = !{i64 2111740203714168353}
!162 = !{i64 18173464306438985}
!163 = !{i64 8730615913261114192}
!164 = !{i64 -2639569608192064766}
!165 = !{i64 -6408709126728603984}
!166 = !{i64 9071820041261157817}
!167 = !{i64 -8916422047066494632}
!168 = !{i64 -2504339364399500361}
!169 = !{i64 7731672441957148075}
!170 = !{i64 -7260552753248913148}
!171 = !{i64 2535528341157965957}
!172 = !{i64 4653728893834517610}
!173 = !{i64 -3485550392769871663}
!174 = !{i64 -2624081020897602054}
