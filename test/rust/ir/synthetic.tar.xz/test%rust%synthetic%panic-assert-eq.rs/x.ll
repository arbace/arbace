; ModuleID = 'panic_assert_eq.91be0b249d41a6c2-cgu.0'
source_filename = "panic_assert_eq.91be0b249d41a6c2-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCscvMyqoVlvsk_15panic_assert_eq, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CscvMyqoVlvsk_15panic_assert_eq, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CscvMyqoVlvsk_15panic_assert_eq }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_d1416a62b06b1e3a08821e46f9042983 = private unnamed_addr constant [39 x i8] c"test/rust/synthetic/panic-assert-eq.rs\00", align 1, !guid !2
@alloc_1c41ca7fbf97d72df3aba1fce3f6b9c7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d1416a62b06b1e3a08821e46f9042983, [16 x i8] c"&\00\00\00\00\00\00\00\06\00\00\00\10\00\00\00" }>, align 8, !guid !3
@alloc_bc6c24833cc57d8ab679f3fbe0b0ac4a = private unnamed_addr constant [4 x i8] c"\03\00\00\00", align 4, !guid !4
@alloc_4e573deb19b8b17ad0ab61246e5a5ce9 = private unnamed_addr constant [6 x i8] c"math 1", align 1, !guid !5
@alloc_80727a0789d7b43066f82ebb2acd26be = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d1416a62b06b1e3a08821e46f9042983, [16 x i8] c"&\00\00\00\00\00\00\00\06\00\00\00\05\00\00\00" }>, align 8, !guid !6
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !7

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECscvMyqoVlvsk_15panic_assert_eq(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !13 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECscvMyqoVlvsk_15panic_assert_eq(i32 %dummy) unnamed_addr #1 !guid !14 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !15
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscvMyqoVlvsk_15panic_assert_eq(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !16 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCscvMyqoVlvsk_15panic_assert_eq(ptr %f) #8
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #8
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CscvMyqoVlvsk_15panic_assert_eq(ptr align 8 %_1) unnamed_addr #1 !guid !17 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscvMyqoVlvsk_15panic_assert_eq(ptr %_4) #9
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCscvMyqoVlvsk_15panic_assert_eq() #8
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CscvMyqoVlvsk_15panic_assert_eq(i8 %_2) #8
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCscvMyqoVlvsk_15panic_assert_eq(ptr %_1) unnamed_addr #1 !guid !18 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCscvMyqoVlvsk_15panic_assert_eq(ptr %0) #8
  ret i32 %_0
}

; panic_assert_eq::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCscvMyqoVlvsk_15panic_assert_eq4main() unnamed_addr #0 !guid !19 {
start:
  %_5 = alloca [4 x i8], align 4
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscvMyqoVlvsk_15panic_assert_eq(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #8
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<i32>
  %_6 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECscvMyqoVlvsk_15panic_assert_eq(i32 1) #8
  %1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %_6, i32 1)
  %_7.0 = extractvalue { i32, i1 } %1, 0
  %_7.1 = extractvalue { i32, i1 } %1, 1
  br i1 %_7.1, label %panic, label %bb4

bb4:                                              ; preds = %start
  store i32 %_7.0, ptr %_5, align 4
  %_12 = load i32, ptr %_5, align 4
  %_13 = load i32, ptr @alloc_bc6c24833cc57d8ab679f3fbe0b0ac4a, align 4
  %_11 = icmp eq i32 %_12, %_13
  br i1 %_11, label %bb5, label %bb6

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_1c41ca7fbf97d72df3aba1fce3f6b9c7) #10
  unreachable

bb6:                                              ; preds = %bb4
; call <core::fmt::Arguments>::from_str_nonconst
  %2 = call { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCscvMyqoVlvsk_15panic_assert_eq(ptr @alloc_4e573deb19b8b17ad0ab61246e5a5ce9, i64 6) #8
  %_17.0 = extractvalue { ptr, ptr } %2, 0
  %_17.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::assert_failed::<i32, i32>
  call void @_RINvNtCsl10jNU3mE6R_4core9panicking13assert_failedllECsddYV2PBJW9h_3std(i8 0, ptr align 4 %_5, ptr align 4 @alloc_bc6c24833cc57d8ab679f3fbe0b0ac4a, ptr %_17.0, ptr %_17.1, ptr align 8 @alloc_80727a0789d7b43066f82ebb2acd26be) #10
  unreachable

bb5:                                              ; preds = %bb4
; call <core::fmt::Arguments>::from_str
  %3 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscvMyqoVlvsk_15panic_assert_eq(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #8
  %_19.0 = extractvalue { ptr, ptr } %3, 0
  %_19.1 = extractvalue { ptr, ptr } %3, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_19.0, ptr %_19.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCscvMyqoVlvsk_15panic_assert_eq(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !20 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::fmt::Arguments>::from_str_nonconst
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCscvMyqoVlvsk_15panic_assert_eq(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !21 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscvMyqoVlvsk_15panic_assert_eq(ptr %s.0, i64 %s.1) #8
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscvMyqoVlvsk_15panic_assert_eq(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !22 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCscvMyqoVlvsk_15panic_assert_eq(ptr %s.0, i64 %s.1) #8
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CscvMyqoVlvsk_15panic_assert_eq(ptr %self) unnamed_addr #1 !guid !23 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CscvMyqoVlvsk_15panic_assert_eq(i8 %0) unnamed_addr #1 !guid !24 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CscvMyqoVlvsk_15panic_assert_eq(ptr %self) #8
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCscvMyqoVlvsk_15panic_assert_eq() unnamed_addr #1 !guid !25 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCscvMyqoVlvsk_15panic_assert_eq(ptr %_1) unnamed_addr #1 !guid !26 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCscvMyqoVlvsk_15panic_assert_eq(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !27 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CscvMyqoVlvsk_15panic_assert_eq(ptr align 8 %_1) #8
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #4

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #5

; core::panicking::assert_failed::<i32, i32>
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core9panicking13assert_failedllECsddYV2PBJW9h_3std(i8, ptr align 4, ptr align 4, ptr, ptr, ptr align 8) unnamed_addr #6

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #7 !guid !28 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECscvMyqoVlvsk_15panic_assert_eq(ptr @_RNvCscvMyqoVlvsk_15panic_assert_eq4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nonlazybind "target-cpu"="x86-64" }
attributes #8 = { inlinehint }
attributes #9 = { noinline }
attributes #10 = { noinline noreturn }

!llvm.module.flags = !{!8, !9, !10, !11}
!llvm.ident = !{!12}

!0 = !{i64 1294529371749294965}
!1 = !{i64 7010630640517054068}
!2 = !{i64 -2567012985339075523}
!3 = !{i64 24829227201583438}
!4 = !{i64 -5493520728107101769}
!5 = !{i64 6913401558288675503}
!6 = !{i64 -4398158115095014240}
!7 = !{i64 5520416638693796616}
!8 = !{i32 8, !"PIC Level", i32 2}
!9 = !{i32 7, !"PIE Level", i32 2}
!10 = !{i32 2, !"RtLibUseGOT", i32 1}
!11 = !{i32 7, !"uwtable", i32 2}
!12 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!13 = !{i64 2239560792626705954}
!14 = !{i64 8612684830685919404}
!15 = !{i64 1312722394589639}
!16 = !{i64 -3201293743221702320}
!17 = !{i64 5565484160727398101}
!18 = !{i64 -7065564004631149763}
!19 = !{i64 -1020042059173241891}
!20 = !{i64 834777283243213349}
!21 = !{i64 -1300754860348271359}
!22 = !{i64 1934746163497783786}
!23 = !{i64 5785565659816443089}
!24 = !{i64 -8188227836647822221}
!25 = !{i64 -4398578821921316235}
!26 = !{i64 8071385009093173829}
!27 = !{i64 2612354533702717081}
!28 = !{i64 -2624081020897602054}
