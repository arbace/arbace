; ModuleID = 'fmt.d0c4af9fcf594538-cgu.0'
source_filename = "fmt.d0c4af9fcf594538-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }
%"core::option::Option<i32>" = type { i32, [1 x i32] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAlj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !0
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionlENtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !1
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !2
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !3
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshVgFdEre0pE_3fmt, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshVgFdEre0pE_3fmt, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshVgFdEre0pE_3fmt }>, align 8, !guid !4
@alloc_058ed9c984ace2f2df2878d2b6a7ab17 = private unnamed_addr constant [86 x i8] c"\01[\C3 \00\00h\05\00\03] [\C3 \00\00\08\05\00\03] [\C3 \00\00H\05\00\03] [\C3 \00\00(\05\00\03] [\C3 \00\00i\05\00\03] [\C1 \00 `\03] [\C1 \00\80`\03] [\C3 \00\80i\0A\00\02]\0A\00", align 1, !guid !5
@alloc_16cc22b75c9c3452d6258d4ae7173928 = private unnamed_addr constant [3 x i8] c"mid", align 1, !guid !6
@alloc_a06b157fbc4fea4c9656215c4f90058c = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_16cc22b75c9c3452d6258d4ae7173928, [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8, !guid !7
@alloc_c7ca2384edadb766999f3f810e9a1faa = private unnamed_addr constant [1 x i8] c"r", align 1, !guid !8
@alloc_116173a2102397b8b6fd81096c83cfc9 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_c7ca2384edadb766999f3f810e9a1faa, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !9
@alloc_fc67a14388b97431c7788bc1ec3532d5 = private unnamed_addr constant [1 x i8] c"l", align 1, !guid !10
@alloc_3bff007dbe99da6ff02a2194c6277311 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_fc67a14388b97431c7788bc1ec3532d5, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !11
@alloc_7e4bbc79e2378daf3eeafb7b7df22ee0 = private unnamed_addr constant [35 x i8] c"\01[\C3*\00\00H\09\00\03] [\C3-\00\00(\07\00\03] [\C3_\00\00\08\06\00\02]\0A\00", align 1, !guid !12
@alloc_8c4e06e927edde26594c713b91192e5a = private unnamed_addr constant [8 x i8] c"\F1\D4\C8S\FB!\09@", align 8, !guid !13
@alloc_f85406d658e94b9c37cd2112f10307ee = private unnamed_addr constant [8 x i8] c"\02\00\00\00\00\00\00\00", align 8, !guid !14
@alloc_cdde77e819f554b9b7f533765281c183 = private unnamed_addr constant [8 x i8] c"\90\F7\AA\95\09\BF\05@", align 8, !guid !15
@alloc_600bea9355adff585e97c5fff9ed0f73 = private unnamed_addr constant [27 x i8] c"test/rust/synthetic/fmt.rs\00", align 1, !guid !16
@alloc_7a793d85dca71c7dc1dea8251d3c81a6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\15\00\00\00\05\00\00\00" }>, align 8, !guid !17
@alloc_33b2945736ef38a27c6e677ffcd45b44 = private unnamed_addr constant [41 x i8] c"\01[\D3 \00\00h\01\00\03] [\FF \00\008\01\00\03\00\02\00\03] [\ED \00\00p\05\00\04\00\02]\0A\00", align 1, !guid !18
@alloc_1ee9e55db95863be6ebd980ddbf9d982 = private unnamed_addr constant [2 x i8] c"nm", align 1, !guid !19
@alloc_9f8d7ceb5d76cacbca201a50ff8c4371 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_1ee9e55db95863be6ebd980ddbf9d982, [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8, !guid !20
@alloc_95ee1cd2eaa09486cb2b0fd227d38feb = private unnamed_addr constant [14 x i8] c"\09a b a nm \C0\01\0A\00", align 1, !guid !21
@alloc_84452d4c362ef91ce628cf4a12e63db7 = private unnamed_addr constant [3 x i8] c"cap", align 1, !guid !22
@alloc_96f2619f19364aea06eebc9b5a1fb7d7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\18\00\00\00\05\00\00\00" }>, align 8, !guid !23
@alloc_9f628f80319a062de0e97a0dc03419f7 = private unnamed_addr constant [34 x i8] c"\D3 \00\00(\01\00\01|\C8\02\00\01|\C3 \00\80i\06\00\0B|{literal}\0A\00", align 1, !guid !24
@alloc_b120f3228a2aa0acd63c1931e0ccccd5 = private unnamed_addr constant [4 x i8] c"q\00\00\00", align 4, !guid !25
@alloc_3e7031f3d0c6d290661936e0852caa58 = private unnamed_addr constant [2 x i8] c"s\0A", align 1, !guid !26
@alloc_adbc948e1297c274cac6e15d4baf9312 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_3e7031f3d0c6d290661936e0852caa58, [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8, !guid !27
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !28
@alloc_938b60fd0bf7f9b98ca251eb559dc6f5 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\F8?", align 8, !guid !29
@alloc_9d4d590161390a2420b41fde992773bb = private unnamed_addr constant <{ [1 x i8], [1 x i8] }> <{ [1 x i8] zeroinitializer, [1 x i8] undef }>, align 1, !guid !30
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !31
@alloc_070ca2e2ae6721b8fbf222c3a28fff78 = private unnamed_addr constant [1 x i8] c"t", align 1, !guid !32
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !33
@alloc_c3b1946345a8630bc4d2f804c02f8ade = private unnamed_addr constant [8 x i8] c"\C1 \00\80`\01\0A\00", align 1, !guid !34
@alloc_f9894cef7d80ce1597e4af1bee2cc81d = private unnamed_addr constant <{ [1 x i8], [31 x i8] }> <{ [1 x i8] zeroinitializer, [31 x i8] undef }>, align 8, !guid !35
@alloc_37f62a15fae368a2423b3a16c75adcc9 = private unnamed_addr constant [1 x i8] c"x", align 1, !guid !36
@alloc_ad5ee50880169519f12eb2aee1c80306 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\1E\00\00\002\00\00\00" }>, align 8, !guid !37
@alloc_9c7fb62c24638c4cee5ee34bf542b723 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\1F\00\00\00#\00\00\00" }>, align 8, !guid !38
@alloc_babee5271e6e42dc125a96e0272fa27d = private unnamed_addr constant [3 x i8] c"two", align 1, !guid !39
@alloc_b0c6f7e20c8b1e174b89edc6baca02fc = private unnamed_addr constant <{ ptr, [12 x i8], [4 x i8], [16 x i8] }> <{ ptr @alloc_babee5271e6e42dc125a96e0272fa27d, [12 x i8] c"\03\00\00\00\00\00\00\00\01\00\00\00", [4 x i8] undef, [16 x i8] c"\00\00\00\00\00\00\08@\00\00\00\00\00\00\12@" }>, align 8, !guid !40
@alloc_0db41ab121065f14f332cc5e3cf612a8 = private unnamed_addr constant [8 x i8] c"90\00\00\00\00\00\00", align 8, !guid !41
@alloc_33e8ada5b6178afcb200a31f257552b1 = private unnamed_addr constant [8 x i8] c"\05\00\00\00\00\00\00\00", align 8, !guid !42
@alloc_eabeddbc27aba20163f110a6ba7d77e7 = private unnamed_addr constant [8 x i8] c"\9F\86\01\00\00\00\00\00", align 8, !guid !43
@alloc_79674baf410e37291a6607f958b7b1fe = private unnamed_addr constant [8 x i8] c"d\00\00\00\00\00\00\00", align 8, !guid !44
@alloc_80c3197a743f5124a0a564937a745665 = private unnamed_addr constant [40 x i8] c"\01[\C0\03] [\C3 \00\00(\0A\00\03] [\C3 \00\00\08\0A\00\03] [\C3 \00\00H\0A\00\02]\0A\00", align 1, !guid !45
@alloc_201c3ee118050b09cec852f4540cef71 = private unnamed_addr constant [4 x i8] c"\FF\00\00\00", align 4, !guid !46
@alloc_2496decc21825f3f9b238b54f8d5e33f = private unnamed_addr constant [20 x i8] c"\C0\01 \C1 \00\80`\01 \C3 \00\00i\08\00\01\0A\00", align 1, !guid !47
@alloc_e0f292073631866f6c61fe5668d1ab0c = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00J\93@", align 8, !guid !48
@alloc_18e849d5c0b47b9a1071d700260ded41 = private unnamed_addr constant [8 x i8] c"i\1DUM\10u\1F?", align 8, !guid !49
@alloc_cdbdeba67b052fefbde5996b437aa24e = private unnamed_addr constant [4 x i8] c"\05\00\00\00", align 4, !guid !50
@alloc_f93507f8ba4b5780b14b2c2584609be0 = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00\00\F0?", align 8, !guid !51
@alloc_91984e5afffc475237697b8bd6a3e206 = private unnamed_addr constant [4 x i8] c"\9A\99\99>", align 4, !guid !52
@alloc_ddd207f36435cdb5a6b231356b1990e9 = private unnamed_addr constant [8 x i8] c"P\EF\E2\D6\E4\1AKD", align 8, !guid !53
@alloc_86fe2e14e8aee3cbc4747be45abbb75c = private unnamed_addr constant [8 x i8] c"\FF\FF\FF\FF\FF\FF\EF\7F", align 8, !guid !54
@alloc_3fd4ac1bd4aabc745420009965a8d1ac = private unnamed_addr constant [4 x i8] c"\00\00\80\00", align 4, !guid !55
@alloc_4e3160e3e5d83eeb2e7a3db504240512 = private unnamed_addr constant [8 x i8] c"\BB\BD\D7\D9\DF|\DB=", align 8, !guid !56
@alloc_8821998f047ca62cad40e6bc4e4d87c4 = private unnamed_addr constant [1 x i8] c"\01", align 1, !guid !57
@alloc_5b64c5758b3793302fbedcd0481de01a = private unnamed_addr constant [4 x i8] c"c\00\00\00", align 4, !guid !58
@alloc_0ae0accb60b700fe8d2e90793be18e2c = private unnamed_addr constant [2 x i8] c"ab", align 1, !guid !59
@alloc_c05f8b186ecd5789d56bb5d9e682c6d7 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_0ae0accb60b700fe8d2e90793be18e2c, [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8, !guid !60
@alloc_50ab75e5eb17b3d68555764b0a52038b = private unnamed_addr constant [1 x i8] c"z", align 1, !guid !61
@alloc_2baa0b6208900c4f9b90e2cbbfb2ca47 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_50ab75e5eb17b3d68555764b0a52038b, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !62
@alloc_12541e1a1260b3fd7e4655df6b8014be = private unnamed_addr constant [37 x i8] c"\C3 \00\00h\05\00\01|\C3 \00\00\08\05\00\01|\C3 \00\00H\05\00\01|\C3 \00\00(\05\00\01\0A\00", align 1, !guid !63
@alloc_f19792d8e6fca51f99519584a77b3470 = private unnamed_addr constant <{ [12 x i8], [4 x i8] }> <{ [12 x i8] c"\01\00\00\00\01\00\00\00\00\00\00\00", [4 x i8] undef }>, align 4, !guid !64
@alloc_68d244bd4070015bf9253d1ac51d25f8 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\02\00\00\00\03\00\00\00\04\00\00\00", align 4, !guid !65
@alloc_fc18870ebd3bffa18e161a5a63775070 = private unnamed_addr constant [4 x i8] c"\07\00\00\00", align 4, !guid !66
@alloc_a0256699fdc8ea22b569d2c1ec13c81f = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00\00#@", align 8, !guid !67
@alloc_352fcb003cd53a19ca29091d17651ce3 = private unnamed_addr constant [30 x i8] c"\C3 \00\00i\02\00\01:\C3 \00\00i\02\00\01:\C7 \00\00y\06\00\03\00\01\0A\00", align 1, !guid !68
@alloc_cbaed04ca755d7df81f067609aba73ed = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00$\FE@", align 8, !guid !69
@alloc_4b42cd106c262d3d9a145d6f4764eeaf = private unnamed_addr constant [8 x i8] c"\01\00\00\00\01\00\00\00", align 4, !guid !70
@alloc_5a1a9e6358d5f90dcb98724ce1d54ed0 = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00\00\02@", align 8, !guid !71
@alloc_5d68c547652bb8e5dddfa04dc983f46a = private unnamed_addr constant [32 x i8] c"\C7 \00\00x\0A\00\03\00\01|\C3 \00\00\08\0C\00\01|\C7 \00 8\08\00\01\00\01\0A\00", align 1, !guid !72
@alloc_214cd245ef08d32d3c495a75f259c468 = private unnamed_addr constant [4 x i8] c"1 2\0A", align 1, !guid !73
@alloc_0fa510a23a05a548dfd86788ed688330 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !74
@alloc_f1045206bd356f04ecf6c5daa5616281 = private unnamed_addr constant [5 x i8] c"\021-\C0\00", align 1, !guid !75
@alloc_ea556a6fc27bebb9c43699dd3a5fa3f3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00-\00\00\00\22\00\00\00" }>, align 8, !guid !76
@alloc_aa8949e1fb3783c4ba3f17396bbaa3bf = private unnamed_addr constant [2 x i8] c"!\0A", align 1, !guid !77
@alloc_a7aedc039a5bce5f90b5974852c9f0c9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00-\00\00\00=\00\00\00" }>, align 8, !guid !78
@alloc_0c812808379efded5a4fb82d2790b556 = private unnamed_addr constant [2 x i8] c"\C0\00", align 1, !guid !79
@alloc_9beb045410d021e66c87fb3fce4c6912 = private unnamed_addr constant [12 x i8] c"to stderr 1\0A", align 1, !guid !80
@alloc_b7cbb96fa2fbc2c33cfdce3b367921a6 = private unnamed_addr constant [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\80", align 16, !guid !81
@alloc_d0776666182ad032bd1011cf266e2f3a = private unnamed_addr constant [16 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF", align 16, !guid !82
@alloc_2aed27a01081c9f91b0f84d085de36d9 = private unnamed_addr constant [4 x i8] c"\F4\FF\FF\FF", align 4, !guid !83
@alloc_c424b10c3bbe424e4bad8e7fe84cacd4 = private unnamed_addr constant [29 x i8] c"\C3 \00\00(\06\00\01|\C3 \00\00\08\06\00\01|\C3 \00\00H\06\00\02|\0A\00", align 1, !guid !84
@alloc_53973d2fe29b4adba8bb7390b5678745 = private unnamed_addr constant [8 x i8] zeroinitializer, align 8, !guid !85
@alloc_783ee260e8ae01216c1a7e8d97dd7885 = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00\00\F0C", align 8, !guid !86
@alloc_b03741e4fa93f143426998f2aacbbd7f = private unnamed_addr constant [2 x i8] c"\C3\A9", align 1, !guid !87
@alloc_9b2bf7077a3c4b95a732f8a187d9d5ed = private unnamed_addr constant [4 x i8] c"\E9\00\00\00", align 4, !guid !88
@alloc_00ae4b301f7fab8ac9617c03fcbd7274 = private unnamed_addr constant [43 x i8] c"called `Result::unwrap()` on an `Err` value", align 1, !guid !89
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsK_NtCsl10jNU3mE6R_4core3fmtNtB5_5ErrorNtB5_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !90
@alloc_bed8969a4b39b5529597d14a2d5628f2 = private unnamed_addr constant [32 x i8] c"Formatting argument out of range", align 1, !guid !91
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !92
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !93
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !94
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !95
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !96
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !97
@alloc_78648a3da0583c3a93ec45d48e44c913 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\0B\00\00\00&\00\00\00" }>, align 8, !guid !98
@alloc_2a7a4456520952dbf8a616376b1f7793 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\0B\00\00\004\00\00\00" }>, align 8, !guid !99
@alloc_6ddf87a275032c244ec296015b313b7a = private unnamed_addr constant [13 x i8] c"\01$\C0\01.\C3 \00\00i\02\00\00", align 1, !guid !100
@alloc_bf0ef947d182249ea2203578272460c5 = private unnamed_addr constant [5 x i8] c"Point", align 1, !guid !101
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !102
@alloc_cd51bc84b49b21a3fdb2800731f25c21 = private unnamed_addr constant [1 x i8] c"y", align 1, !guid !103
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @_RNvXs2_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_5Debug3fmt }>, align 8, !guid !104
@alloc_125af81ac88d8b2d4254bab0c6fa4f63 = private unnamed_addr constant [3 x i8] c"tag", align 1, !guid !105
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionReENtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !106
@vtable.9 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !107
@vtable.a = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAdj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !108
@vtable.b = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !109
@vtable.c = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !110
@alloc_13c56e54a9571211dcad2a135c9eaa2b = private unnamed_addr constant [4 x i8] c"Unit", align 1, !guid !111
@alloc_8388317ddce58f972b519ce81ee4ed85 = private unnamed_addr constant [3 x i8] c"Tup", align 1, !guid !112
@vtable.d = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !113
@vtable.e = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !114
@alloc_3b31bdf1fe846135477a792935103ed1 = private unnamed_addr constant [3 x i8] c"Rec", align 1, !guid !115
@alloc_3827bbb606bbdb0f0c926011c14ccc34 = private unnamed_addr constant [1 x i8] c"a", align 1, !guid !116
@vtable.f = private unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEEBG_, [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !117
@alloc_ab7766fee1e1b94f8c00ce7ffec41c7e = private unnamed_addr constant [1 x i8] c"b", align 1, !guid !118
@vtable.g = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRTabENtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !119
@alloc_99ac8a81a24cac863217ce4a5cbfabea = private unnamed_addr constant [5 x i8] c"Error", align 1, !guid !120
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !121
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !122
@alloc_0d0353b85363a9d264096e7bdbfe6900 = private unnamed_addr constant [22 x i8] c"core/src/array/mod.rs\00", align 1, !guid !123
@alloc_bb689cb4c05c0bf38d31dd7cd71b8150 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d0353b85363a9d264096e7bdbfe6900, [16 x i8] c"\15\00\00\00\00\00\00\00e\01\00\00\1F\00\00\00" }>, align 8, !guid !124
@alloc_ae6dc619079e3c3b08144a35532ecff7 = private unnamed_addr constant [2 x i8] c"()", align 1, !guid !125

; <core::fmt::rt::Argument>::new_binary::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !131 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refB9_(ptr align 4 %x) #11
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuEBa_(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<fmt::Money>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !132 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<fmt::Money>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt5MoneyE8from_refBV_(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<fmt::Money>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt5MoneyE4castuEBW_(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXCshVgFdEre0pE_3fmtNtB2_5MoneyNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !133 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !134 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCshVgFdEre0pE_3fmt(ptr %x) #11
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !135 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !136 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #11
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !137 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_pointer::<*const u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_pointerPhECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !138 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<*const u8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullPhE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<*const u8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullPhE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsl_NtCsl10jNU3mE6R_4core3fmtPhNtB5_7Pointer3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_exp::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !139 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs8_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8LowerExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_exp::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expmECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !140 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refB9_(ptr align 4 %x) #11
; call <core::ptr::non_null::NonNull<u32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuEBa_(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsw_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_8LowerExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<fmt::Hex>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexNtCshVgFdEre0pE_3fmt3HexEB12_(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !141 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<fmt::Hex>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt3HexE8from_refBV_(ptr align 4 %x) #11
; call <core::ptr::non_null::NonNull<fmt::Hex>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt3HexE4castuEBW_(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_CshVgFdEre0pE_3fmtNtB4_3HexNtNtCsl10jNU3mE6R_4core3fmt8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_exp::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !142 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs9_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8UpperExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<[[i32; 2]; 2]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAAlj2_BY_ECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !143 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<[[i32; 2]; 2]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAAlj2_BW_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #11
; call <core::ptr::non_null::NonNull<[[i32; 2]; 2]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAAlj2_BX_E4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAAlj2_Bz_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<[core::option::Option<i32>; 2]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAINtNtB7_6option6OptionlEj2_ECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !144 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<[core::option::Option<i32>; 2]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAINtNtB9_6option6OptionlEj2_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #11
; call <core::ptr::non_null::NonNull<[core::option::Option<i32>; 2]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAINtNtBa_6option6OptionlEj2_E4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAINtNtB7_6option6OptionlEj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<f64>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptiondEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !145 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<f64>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptiondEE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<core::option::Option<f64>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptiondEE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptiondENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !146 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<u8>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionhEE8from_refCshVgFdEre0pE_3fmt(ptr %x) #11
; call <core::ptr::non_null::NonNull<core::option::Option<u8>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionhEE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionhENtNtB7_3fmt5Debug3fmtCs7CppTae75M1_5alloc, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !147 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i32>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #11
; call <core::ptr::non_null::NonNull<core::option::Option<i32>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionlEE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<fmt::E>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt1EEBX_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !148 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<fmt::E>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt1EE8from_refBV_(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<fmt::E>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt1EE4castuEBW_(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_CshVgFdEre0pE_3fmtNtB5_1ENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<fmt::Point>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt5PointEBX_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !149 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<fmt::Point>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt5PointE8from_refBV_(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<fmt::Point>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt5PointE4castuEBW_(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs0_CshVgFdEre0pE_3fmtNtB5_5PointNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::time::Duration>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_4time8DurationECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !150 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::time::Duration>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_4time8DurationE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<core::time::Duration>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_4time8DurationE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core4timeNtB5_8DurationNtNtB7_3fmt5Debug3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !151 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(i32, &str, [f64; 2])>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTlReAdj2_EECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !152 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(i32, &str, [f64; 2])>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTlReAdj2_EE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<(i32, &str, [f64; 2])>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTlReAdj2_EE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1F_NtCsl10jNU3mE6R_4core3fmtTlReAdj2_ENtB6_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !153 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #11
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !154 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #11
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs2_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_5Debug3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugnECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !155 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCshVgFdEre0pE_3fmt(ptr align 16 %x) #11
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugoECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !156 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #11
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuguECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !157 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<()>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulluE8from_refCshVgFdEre0pE_3fmt(ptr %x) #11
; call <core::ptr::non_null::NonNull<()>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulluE4castuECshVgFdEre0pE_3fmt(ptr %_4) #11
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXss_NtCsl10jNU3mE6R_4core3fmtuNtB5_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<[[i32; 2]; 2]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAAlj2_BX_E4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !158 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[core::option::Option<i32>; 2]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAINtNtBa_6option6OptionlEj2_E4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !159 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<f64>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptiondEE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !160 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<u8>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionhEE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !161 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionlEE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !162 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<fmt::E>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt1EE4castuEBW_(ptr %self) unnamed_addr #0 !guid !163 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<fmt::Hex>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt3HexE4castuEBW_(ptr %self) unnamed_addr #0 !guid !164 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<fmt::Money>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt5MoneyE4castuEBW_(ptr %self) unnamed_addr #0 !guid !165 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<fmt::Point>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt5PointE4castuEBW_(ptr %self) unnamed_addr #0 !guid !166 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::time::Duration>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_4time8DurationE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !167 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !168 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<*const u8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullPhE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !169 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[[i32; 2]]>>::cast::<[i32; 2]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAlj2_E4castBV_ECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !170 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[core::option::Option<i32>]>>::cast::<core::option::Option<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSINtNtBa_6option6OptionlEE4castBV_ECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !171 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[f64]>>::cast::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSdE4castdECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !172 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<(i32, &str, [f64; 2])>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTlReAdj2_EE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !173 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !174 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !175 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !176 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !177 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<()>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulluE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !178 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !179 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<20, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !180 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<29, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1d_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !181 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<30, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1e_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !182 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<32, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj20_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !183 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<34, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj22_Kj4_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !184 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<35, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj23_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !185 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<37, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj25_Kj4_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !186 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<40, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj28_Kj4_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !187 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<41, 6>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj29_Kj6_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !188 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<86, 8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj56_Kj8_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !189 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<5, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj5_Kj1_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !190 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !191 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::builders::DebugList>::entries::<&[i32; 2], core::slice::iter::Iter<[i32; 2]>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRAlj2_INtNtNtBa_5slice4iter4IterB14_EECshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !192 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<[i32; 2]> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterAlj2_ENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %entries.0, ptr %entries.1) #11
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<[i32; 2]> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterAlj2_ENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %iter) #11
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !193
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.0)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&core::option::Option<i32>, core::slice::iter::Iter<core::option::Option<i32>>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRINtNtBa_6option6OptionlEINtNtNtBa_5slice4iter4IterB14_EECshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !194 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<core::option::Option<i32>> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterINtNtB8_6option6OptionlEENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %entries.0, ptr %entries.1) #11
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<core::option::Option<i32>> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterINtNtBa_6option6OptionlEENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %iter) #11
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !193
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.1)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&f64, core::slice::iter::Iter<f64>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRdINtNtNtBa_5slice4iter4IterdEECshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !195 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<f64> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterdENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %entries.0, ptr %entries.1) #11
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %iter) #11
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !193
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.2)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !196 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %entries.0, ptr %entries.1) #11
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 8 %iter) #11
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !193
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.3)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshVgFdEre0pE_3fmt(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !197 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.4, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::ptr::drop_glue::<fmt::E>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_1) unnamed_addr #1 !guid !198 {
start:
  %0 = load i8, ptr %_1, align 8
  %_2 = zext i8 %0 to i64
  switch i64 %_2, label %bb3 [
    i64 0, label %bb1
    i64 1, label %bb2
  ]

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEEBG_(ptr align 8 %1)
  br label %bb1

bb1:                                              ; preds = %bb3, %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %2 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %2)
  br label %bb1
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECshVgFdEre0pE_3fmt(i64 %dummy) unnamed_addr #0 !guid !199 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !200
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshVgFdEre0pE_3fmt(i32 %dummy) unnamed_addr #0 !guid !201 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !200
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshVgFdEre0pE_3fmt(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !202 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshVgFdEre0pE_3fmt(ptr %f) #11
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #11
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshVgFdEre0pE_3fmt(ptr align 8 %_1) unnamed_addr #0 !guid !203 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshVgFdEre0pE_3fmt(ptr %_4) #12
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshVgFdEre0pE_3fmt() #11
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshVgFdEre0pE_3fmt(i8 %_2) #11
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshVgFdEre0pE_3fmt(ptr %_1) unnamed_addr #0 !guid !204 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshVgFdEre0pE_3fmt(ptr %0) #11
  ret i32 %_0
}

; fmt::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCshVgFdEre0pE_3fmt4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !205 {
start:
  %e.i47 = alloca [0 x i8], align 1
  %self.i48 = alloca [1 x i8], align 1
  %e.i = alloca [0 x i8], align 1
  %self.i = alloca [1 x i8], align 1
  %0 = alloca [16 x i8], align 8
  %_349 = alloca [16 x i8], align 8
  %_348 = alloca [16 x i8], align 8
  %args42 = alloca [32 x i8], align 8
  %_345 = alloca [24 x i8], align 8
  %_338 = alloca [16 x i8], align 8
  %args41 = alloca [16 x i8], align 8
  %_330 = alloca [16 x i8], align 8
  %args40 = alloca [16 x i8], align 8
  %_328 = alloca [16 x i8], align 8
  %_321 = alloca [16 x i8], align 8
  %args39 = alloca [16 x i8], align 8
  %_313 = alloca [16 x i8], align 8
  %_312 = alloca [16 x i8], align 8
  %_311 = alloca [16 x i8], align 8
  %args38 = alloca [48 x i8], align 8
  %args37 = alloca [24 x i8], align 8
  %_301 = alloca [16 x i8], align 8
  %_300 = alloca [16 x i8], align 8
  %args36 = alloca [32 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %args35 = alloca [16 x i8], align 8
  %_277 = alloca [16 x i8], align 8
  %args34 = alloca [16 x i8], align 8
  %s = alloca [24 x i8], align 8
  %_264 = alloca [16 x i8], align 8
  %_263 = alloca [16 x i8], align 8
  %_262 = alloca [16 x i8], align 8
  %args33 = alloca [48 x i8], align 8
  %args32 = alloca [24 x i8], align 8
  %_252 = alloca [16 x i8], align 8
  %_251 = alloca [16 x i8], align 8
  %_250 = alloca [16 x i8], align 8
  %args31 = alloca [48 x i8], align 8
  %args30 = alloca [24 x i8], align 8
  %_240 = alloca [16 x i8], align 8
  %_239 = alloca [16 x i8], align 8
  %args29 = alloca [32 x i8], align 8
  %_230 = alloca [16 x i8], align 8
  %_229 = alloca [16 x i8], align 8
  %_228 = alloca [16 x i8], align 8
  %_227 = alloca [16 x i8], align 8
  %args28 = alloca [64 x i8], align 8
  %args27 = alloca [32 x i8], align 8
  %_216 = alloca [16 x i8], align 8
  %_215 = alloca [16 x i8], align 8
  %_214 = alloca [16 x i8], align 8
  %args26 = alloca [48 x i8], align 8
  %args25 = alloca [24 x i8], align 8
  %_204 = alloca [16 x i8], align 8
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args24 = alloca [48 x i8], align 8
  %args23 = alloca [24 x i8], align 8
  %_192 = alloca [16 x i8], align 8
  %_191 = alloca [16 x i8], align 8
  %_190 = alloca [16 x i8], align 8
  %args22 = alloca [48 x i8], align 8
  %args21 = alloca [24 x i8], align 8
  %_180 = alloca [16 x i8], align 8
  %_179 = alloca [16 x i8], align 8
  %_178 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %args19 = alloca [24 x i8], align 8
  %_168 = alloca [16 x i8], align 8
  %_167 = alloca [16 x i8], align 8
  %_166 = alloca [16 x i8], align 8
  %_165 = alloca [16 x i8], align 8
  %args18 = alloca [64 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_154 = alloca [16 x i8], align 8
  %args16 = alloca [16 x i8], align 8
  %_146 = alloca [16 x i8], align 8
  %args15 = alloca [16 x i8], align 8
  %_142 = alloca [24 x i8], align 8
  %_141 = alloca [32 x i8], align 8
  %_134 = alloca [16 x i8], align 8
  %_133 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_130 = alloca [24 x i8], align 8
  %_129 = alloca [32 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args13 = alloca [16 x i8], align 8
  %_113 = alloca [16 x i8], align 8
  %args12 = alloca [16 x i8], align 8
  %pt = alloca [24 x i8], align 8
  %_102 = alloca [16 x i8], align 8
  %_101 = alloca [16 x i8], align 8
  %args11 = alloca [32 x i8], align 8
  %_92 = alloca [16 x i8], align 8
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args10 = alloca [48 x i8], align 8
  %args9 = alloca [24 x i8], align 8
  %_80 = alloca [16 x i8], align 8
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %_77 = alloca [16 x i8], align 8
  %args8 = alloca [64 x i8], align 8
  %args7 = alloca [24 x i8], align 8
  %width = alloca [8 x i8], align 8
  %name = alloca [16 x i8], align 8
  %_65 = alloca [16 x i8], align 8
  %args6 = alloca [16 x i8], align 8
  %_57 = alloca [16 x i8], align 8
  %_56 = alloca [16 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %_53 = alloca [16 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %args5 = alloca [96 x i8], align 8
  %args4 = alloca [48 x i8], align 8
  %_39 = alloca [16 x i8], align 8
  %_38 = alloca [16 x i8], align 8
  %_37 = alloca [16 x i8], align 8
  %args3 = alloca [48 x i8], align 8
  %args2 = alloca [24 x i8], align 8
  %_27 = alloca [16 x i8], align 8
  %_26 = alloca [16 x i8], align 8
  %_25 = alloca [16 x i8], align 8
  %_24 = alloca [16 x i8], align 8
  %_23 = alloca [16 x i8], align 8
  %_22 = alloca [16 x i8], align 8
  %_21 = alloca [16 x i8], align 8
  %_20 = alloca [16 x i8], align 8
  %args1 = alloca [128 x i8], align 8
  %args = alloca [64 x i8], align 8
  %_4 = alloca [24 x i8], align 8
  %p = alloca [8 x i8], align 8
  %w = alloca [8 x i8], align 8
  %n = alloca [4 x i8], align 4
; call core::hint::black_box::<i32>
  %_5 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshVgFdEre0pE_3fmt(i32 42) #11
; call core::hint::black_box::<usize>
  %_6 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECshVgFdEre0pE_3fmt(i64 8) #11
; call core::hint::black_box::<usize>
  %_7 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECshVgFdEre0pE_3fmt(i64 3) #11
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i32 %_5, ptr %1, align 8
  store i64 %_6, ptr %_4, align 8
  %2 = getelementptr inbounds i8, ptr %_4, i64 16
  store i64 %_7, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i32, ptr %3, align 8
  store i32 %4, ptr %n, align 4
  %5 = load i64, ptr %_4, align 8
  store i64 %5, ptr %w, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i64, ptr %6, align 8
  store i64 %7, ptr %p, align 8
  store ptr %n, ptr %args, align 8
  %8 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %n, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr %n, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args, i64 24
  store ptr %n, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args, i64 32
  store ptr %n, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %args, i64 40
  store ptr %n, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %args, i64 48
  store ptr %n, ptr %13, align 8
  %14 = getelementptr inbounds i8, ptr %args, i64 56
  store ptr %n, ptr %14, align 8
  %_352 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_20, ptr align 4 %_352) #11
  %15 = getelementptr inbounds i8, ptr %args, i64 8
  %_353 = load ptr, ptr %15, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_21, ptr align 4 %_353) #11
  %16 = getelementptr inbounds i8, ptr %args, i64 16
  %_354 = load ptr, ptr %16, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_22, ptr align 4 %_354) #11
  %17 = getelementptr inbounds i8, ptr %args, i64 24
  %_355 = load ptr, ptr %17, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_23, ptr align 4 %_355) #11
  %18 = getelementptr inbounds i8, ptr %args, i64 32
  %_356 = load ptr, ptr %18, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_24, ptr align 4 %_356) #11
  %19 = getelementptr inbounds i8, ptr %args, i64 40
  %_357 = load ptr, ptr %19, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_25, ptr align 4 %_357) #11
  %20 = getelementptr inbounds i8, ptr %args, i64 48
  %_358 = load ptr, ptr %20, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexlECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8 %_26, ptr align 4 %_358) #11
  %21 = getelementptr inbounds i8, ptr %args, i64 56
  %_359 = load ptr, ptr %21, align 8
; call <core::fmt::rt::Argument>::new_binary::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_27, ptr align 4 %_359) #11
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_20, i64 16, i1 false)
  %23 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %23, ptr align 8 %_21, i64 16, i1 false)
  %24 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %24, ptr align 8 %_22, i64 16, i1 false)
  %25 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %25, ptr align 8 %_23, i64 16, i1 false)
  %26 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %26, ptr align 8 %_24, i64 16, i1 false)
  %27 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %27, ptr align 8 %_25, i64 16, i1 false)
  %28 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 6
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %28, ptr align 8 %_26, i64 16, i1 false)
  %29 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 7
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %29, ptr align 8 %_27, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<86, 8>
  %30 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj56_Kj8_ECshVgFdEre0pE_3fmt(ptr @alloc_058ed9c984ace2f2df2878d2b6a7ab17, ptr align 8 %args1) #11
  %_9.0 = extractvalue { ptr, ptr } %30, 0
  %_9.1 = extractvalue { ptr, ptr } %30, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr @alloc_a06b157fbc4fea4c9656215c4f90058c, ptr %args2, align 8
  %31 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr @alloc_116173a2102397b8b6fd81096c83cfc9, ptr %31, align 8
  %32 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr @alloc_3bff007dbe99da6ff02a2194c6277311, ptr %32, align 8
  %_360 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_37, ptr align 8 %_360) #11
  %33 = getelementptr inbounds i8, ptr %args2, i64 8
  %_361 = load ptr, ptr %33, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_38, ptr align 8 %_361) #11
  %34 = getelementptr inbounds i8, ptr %args2, i64 16
  %_362 = load ptr, ptr %34, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_39, ptr align 8 %_362) #11
  %35 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %35, ptr align 8 %_37, i64 16, i1 false)
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_38, i64 16, i1 false)
  %37 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %37, ptr align 8 %_39, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<35, 3>
  %38 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj23_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_7e4bbc79e2378daf3eeafb7b7df22ee0, ptr align 8 %args3) #11
  %_31.0 = extractvalue { ptr, ptr } %38, 0
  %_31.1 = extractvalue { ptr, ptr } %38, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_31.0, ptr %_31.1)
  store ptr %n, ptr %args4, align 8
  %39 = getelementptr inbounds i8, ptr %args4, i64 8
  store ptr @alloc_8c4e06e927edde26594c713b91192e5a, ptr %39, align 8
  %40 = getelementptr inbounds i8, ptr %args4, i64 16
  store ptr @alloc_f85406d658e94b9c37cd2112f10307ee, ptr %40, align 8
  %41 = getelementptr inbounds i8, ptr %args4, i64 24
  store ptr @alloc_cdde77e819f554b9b7f533765281c183, ptr %41, align 8
  %42 = getelementptr inbounds i8, ptr %args4, i64 32
  store ptr %w, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %args4, i64 40
  store ptr %p, ptr %43, align 8
  %_363 = load ptr, ptr %args4, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_52, ptr align 4 %_363) #11
  %44 = getelementptr inbounds i8, ptr %args4, i64 32
  %_364 = load ptr, ptr %44, align 8
; call <core::fmt::rt::Argument>::from_usize
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_53, ptr align 8 %_364, ptr align 8 @alloc_7a793d85dca71c7dc1dea8251d3c81a6) #11
  %45 = getelementptr inbounds i8, ptr %args4, i64 8
  %_365 = load ptr, ptr %45, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_54, ptr align 8 %_365) #11
  %46 = getelementptr inbounds i8, ptr %args4, i64 40
  %_366 = load ptr, ptr %46, align 8
; call <core::fmt::rt::Argument>::from_usize
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_55, ptr align 8 %_366, ptr align 8 @alloc_7a793d85dca71c7dc1dea8251d3c81a6) #11
  %47 = getelementptr inbounds i8, ptr %args4, i64 24
  %_367 = load ptr, ptr %47, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_56, ptr align 8 %_367) #11
  %48 = getelementptr inbounds i8, ptr %args4, i64 16
  %_368 = load ptr, ptr %48, align 8
; call <core::fmt::rt::Argument>::from_usize
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_57, ptr align 8 %_368, ptr align 8 @alloc_7a793d85dca71c7dc1dea8251d3c81a6) #11
  %49 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %49, ptr align 8 %_52, i64 16, i1 false)
  %50 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %50, ptr align 8 %_53, i64 16, i1 false)
  %51 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %_54, i64 16, i1 false)
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_55, i64 16, i1 false)
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_56, i64 16, i1 false)
  %54 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %54, ptr align 8 %_57, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<41, 6>
  %55 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj29_Kj6_ECshVgFdEre0pE_3fmt(ptr @alloc_33b2945736ef38a27c6e677ffcd45b44, ptr align 8 %args5) #11
  %_43.0 = extractvalue { ptr, ptr } %55, 0
  %_43.1 = extractvalue { ptr, ptr } %55, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_43.0, ptr %_43.1)
; call <core::fmt::rt::Argument>::new_debug::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECs257F0UrNG3U_14rustc_demangle(ptr sret([16 x i8]) align 8 %_65, ptr align 8 @alloc_9f8d7ceb5d76cacbca201a50ff8c4371) #11
  %56 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_65, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<14, 1>
  %57 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_95ee1cd2eaa09486cb2b0fd227d38feb, ptr align 8 %args6) #11
  %_61.0 = extractvalue { ptr, ptr } %57, 0
  %_61.1 = extractvalue { ptr, ptr } %57, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_61.0, ptr %_61.1)
  store ptr @alloc_84452d4c362ef91ce628cf4a12e63db7, ptr %name, align 8, !captures !193
  %58 = getelementptr inbounds i8, ptr %name, i64 8
  store i64 3, ptr %58, align 8
  store i64 7, ptr %width, align 8
  store ptr %name, ptr %args7, align 8
  %59 = getelementptr inbounds i8, ptr %args7, i64 8
  store ptr %width, ptr %59, align 8
  %60 = getelementptr inbounds i8, ptr %args7, i64 16
  store ptr %n, ptr %60, align 8
  %_370 = load ptr, ptr %args7, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_77, ptr align 8 %_370) #11
  %61 = getelementptr inbounds i8, ptr %args7, i64 8
  %_371 = load ptr, ptr %61, align 8
; call <core::fmt::rt::Argument>::from_usize
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_78, ptr align 8 %_371, ptr align 8 @alloc_96f2619f19364aea06eebc9b5a1fb7d7) #11
  %_372 = load ptr, ptr %args7, align 8
; call <core::fmt::rt::Argument>::new_debug::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECs257F0UrNG3U_14rustc_demangle(ptr sret([16 x i8]) align 8 %_79, ptr align 8 %_372) #11
  %62 = getelementptr inbounds i8, ptr %args7, i64 16
  %_373 = load ptr, ptr %62, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexlECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8 %_80, ptr align 4 %_373) #11
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_77, i64 16, i1 false)
  %64 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %64, ptr align 8 %_78, i64 16, i1 false)
  %65 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %65, ptr align 8 %_79, i64 16, i1 false)
  %66 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %66, ptr align 8 %_80, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<34, 4>
  %67 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj22_Kj4_ECshVgFdEre0pE_3fmt(ptr @alloc_9f628f80319a062de0e97a0dc03419f7, ptr align 8 %args8) #11
  %_71.0 = extractvalue { ptr, ptr } %67, 0
  %_71.1 = extractvalue { ptr, ptr } %67, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  store ptr @alloc_b120f3228a2aa0acd63c1931e0ccccd5, ptr %args9, align 8
  %68 = getelementptr inbounds i8, ptr %args9, i64 8
  store ptr @alloc_adbc948e1297c274cac6e15d4baf9312, ptr %68, align 8
  %69 = getelementptr inbounds i8, ptr %args9, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %69, align 8
  %_374 = load ptr, ptr %args9, align 8
; call <core::fmt::rt::Argument>::new_debug::<char>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugcEB7_(ptr sret([16 x i8]) align 8 %_90, ptr align 4 %_374) #11
  %70 = getelementptr inbounds i8, ptr %args9, i64 8
  %_375 = load ptr, ptr %70, align 8
; call <core::fmt::rt::Argument>::new_debug::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECs257F0UrNG3U_14rustc_demangle(ptr sret([16 x i8]) align 8 %_91, ptr align 8 %_375) #11
  %71 = getelementptr inbounds i8, ptr %args9, i64 16
  %_376 = load ptr, ptr %71, align 8
; call <core::fmt::rt::Argument>::new_debug::<()>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuguECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_92, ptr %_376) #11
  %72 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %72, ptr align 8 %_90, i64 16, i1 false)
  %73 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %73, ptr align 8 %_91, i64 16, i1 false)
  %74 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %74, ptr align 8 %_92, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %75 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args10) #11
  %_84.0 = extractvalue { ptr, ptr } %75, 0
  %_84.1 = extractvalue { ptr, ptr } %75, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_84.0, ptr %_84.1)
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<f64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptiondEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_101, ptr align 8 @alloc_938b60fd0bf7f9b98ca251eb559dc6f5) #11
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_102, ptr @alloc_9d4d590161390a2420b41fde992773bb) #11
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_101, i64 16, i1 false)
  %77 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %77, ptr align 8 %_102, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %78 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args11) #11
  %_96.0 = extractvalue { ptr, ptr } %78, 0
  %_96.1 = extractvalue { ptr, ptr } %78, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_96.0, ptr %_96.1)
  %79 = getelementptr inbounds i8, ptr %pt, i64 16
  store i32 -1, ptr %79, align 8
  %80 = getelementptr inbounds i8, ptr %pt, i64 20
  store float 2.500000e+00, ptr %80, align 4
  store ptr @alloc_070ca2e2ae6721b8fbf222c3a28fff78, ptr %pt, align 8
  %81 = getelementptr inbounds i8, ptr %pt, i64 8
  store i64 1, ptr %81, align 8
; call <core::fmt::rt::Argument>::new_debug::<fmt::Point>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt5PointEBX_(ptr sret([16 x i8]) align 8 %_113, ptr align 8 %pt) #11
  %82 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %82, ptr align 8 %_113, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %83 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args12) #11
  %_109.0 = extractvalue { ptr, ptr } %83, 0
  %_109.1 = extractvalue { ptr, ptr } %83, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_109.0, ptr %_109.1)
; call <core::fmt::rt::Argument>::new_debug::<fmt::Point>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt5PointEBX_(ptr sret([16 x i8]) align 8 %_121, ptr align 8 %pt) #11
  %84 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %84, ptr align 8 %_121, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<8, 1>
  %85 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_c3b1946345a8630bc4d2f804c02f8ade, ptr align 8 %args13) #11
  %_117.0 = extractvalue { ptr, ptr } %85, 0
  %_117.1 = extractvalue { ptr, ptr } %85, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_117.0, ptr %_117.1)
; call <&str as core::convert::Into<alloc::string::String>>::into
  call void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_130, ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, i64 1, ptr align 8 @alloc_ad5ee50880169519f12eb2aee1c80306) #11
  %86 = getelementptr inbounds i8, ptr %_129, i64 1
  store i8 1, ptr %86, align 1
  %87 = getelementptr inbounds i8, ptr %_129, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %87, ptr align 8 %_130, i64 24, i1 false)
  store i8 1, ptr %_129, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<fmt::E>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt1EEBX_(ptr sret([16 x i8]) align 8 %_133, ptr align 8 @alloc_f9894cef7d80ce1597e4af1bee2cc81d)
          to label %bb52 unwind label %cleanup

bb156:                                            ; preds = %cleanup
; invoke core::ptr::drop_glue::<fmt::E>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_129) #13
          to label %bb157 unwind label %terminate

cleanup:                                          ; preds = %bb54, %bb53, %bb52, %start
  %88 = landingpad { ptr, i32 }
          cleanup
  %89 = extractvalue { ptr, i32 } %88, 0
  %90 = extractvalue { ptr, i32 } %88, 1
  store ptr %89, ptr %0, align 8
  %91 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %90, ptr %91, align 8
  br label %bb156

bb52:                                             ; preds = %start
; invoke <core::fmt::rt::Argument>::new_debug::<fmt::E>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt1EEBX_(ptr sret([16 x i8]) align 8 %_134, ptr align 8 %_129)
          to label %bb53 unwind label %cleanup

bb53:                                             ; preds = %bb52
  %92 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %92, ptr align 8 %_133, i64 16, i1 false)
  %93 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %93, ptr align 8 %_134, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %94 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14)
          to label %bb54 unwind label %cleanup

bb54:                                             ; preds = %bb53
  %_125.0 = extractvalue { ptr, ptr } %94, 0
  %_125.1 = extractvalue { ptr, ptr } %94, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_125.0, ptr %_125.1)
          to label %bb55 unwind label %cleanup

bb55:                                             ; preds = %bb54
; call core::ptr::drop_glue::<fmt::E>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_129)
; call alloc::boxed::box_new_uninit
  %_1.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshVgFdEre0pE_3fmt(i64 1, i64 2) #11
  %_427 = ptrtoint ptr %_1.i to i64
  %_429 = and i64 %_427, 0
  %_430 = icmp eq i64 %_429, 0
  br i1 %_430, label %bb158, label %panic

bb158:                                            ; preds = %bb55
  %_432 = ptrtoint ptr %_1.i to i64
  %_434 = icmp eq i64 %_432, 0
  %_435 = and i1 %_434, true
  %_436 = xor i1 %_435, true
  br i1 %_436, label %bb159, label %panic43

panic:                                            ; preds = %bb55
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 1, i64 %_427, ptr align 8 @alloc_9c7fb62c24638c4cee5ee34bf542b723) #14
  unreachable

bb159:                                            ; preds = %bb158
  %95 = getelementptr inbounds nuw i8, ptr %_1.i, i64 0
  store i8 1, ptr %95, align 1
  %96 = getelementptr inbounds nuw i8, ptr %_1.i, i64 1
  store i8 2, ptr %96, align 1
; call <[u8]>::into_vec::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh8into_vecNtNtB5_5alloc6GlobalEB5_(ptr sret([24 x i8]) align 8 %_142, ptr %_1.i, i64 2) #11
  %97 = getelementptr inbounds i8, ptr %_141, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %97, ptr align 8 %_142, i64 24, i1 false)
  %98 = getelementptr inbounds i8, ptr %_141, i64 1
  store i8 -3, ptr %98, align 1
  %99 = getelementptr inbounds i8, ptr %98, i64 1
  store i8 1, ptr %99, align 1
  store i8 2, ptr %_141, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<fmt::E>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt1EEBX_(ptr sret([16 x i8]) align 8 %_146, ptr align 8 %_141)
          to label %bb59 unwind label %cleanup44

panic43:                                          ; preds = %bb158
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_9c7fb62c24638c4cee5ee34bf542b723) #14
  unreachable

bb155:                                            ; preds = %cleanup44
; invoke core::ptr::drop_glue::<fmt::E>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_141) #13
          to label %bb157 unwind label %terminate

cleanup44:                                        ; preds = %bb60, %bb59, %bb159
  %100 = landingpad { ptr, i32 }
          cleanup
  %101 = extractvalue { ptr, i32 } %100, 0
  %102 = extractvalue { ptr, i32 } %100, 1
  store ptr %101, ptr %0, align 8
  %103 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %102, ptr %103, align 8
  br label %bb155

bb59:                                             ; preds = %bb159
  %104 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %104, ptr align 8 %_146, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %105 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_c3b1946345a8630bc4d2f804c02f8ade, ptr align 8 %args15)
          to label %bb60 unwind label %cleanup44

bb60:                                             ; preds = %bb59
  %_138.0 = extractvalue { ptr, ptr } %105, 0
  %_138.1 = extractvalue { ptr, ptr } %105, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_138.0, ptr %_138.1)
          to label %bb61 unwind label %cleanup44

bb61:                                             ; preds = %bb60
; call core::ptr::drop_glue::<fmt::E>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_141)
; call <core::fmt::rt::Argument>::new_debug::<(i32, &str, [f64; 2])>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTlReAdj2_EECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_154, ptr align 8 @alloc_b0c6f7e20c8b1e174b89edc6baca02fc) #11
  %106 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %106, ptr align 8 %_154, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<8, 1>
  %107 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_c3b1946345a8630bc4d2f804c02f8ade, ptr align 8 %args16) #11
  %_150.0 = extractvalue { ptr, ptr } %107, 0
  %_150.1 = extractvalue { ptr, ptr } %107, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_150.0, ptr %_150.1)
  store ptr @alloc_0db41ab121065f14f332cc5e3cf612a8, ptr %args17, align 8
  %108 = getelementptr inbounds i8, ptr %args17, i64 8
  store ptr @alloc_33e8ada5b6178afcb200a31f257552b1, ptr %108, align 8
  %109 = getelementptr inbounds i8, ptr %args17, i64 16
  store ptr @alloc_eabeddbc27aba20163f110a6ba7d77e7, ptr %109, align 8
  %110 = getelementptr inbounds i8, ptr %args17, i64 24
  store ptr @alloc_79674baf410e37291a6607f958b7b1fe, ptr %110, align 8
  %_385 = load ptr, ptr %args17, align 8
; call <core::fmt::rt::Argument>::new_display::<fmt::Money>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_165, ptr align 8 %_385) #11
  %111 = getelementptr inbounds i8, ptr %args17, i64 8
  %_386 = load ptr, ptr %111, align 8
; call <core::fmt::rt::Argument>::new_display::<fmt::Money>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_166, ptr align 8 %_386) #11
  %112 = getelementptr inbounds i8, ptr %args17, i64 16
  %_387 = load ptr, ptr %112, align 8
; call <core::fmt::rt::Argument>::new_display::<fmt::Money>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_167, ptr align 8 %_387) #11
  %113 = getelementptr inbounds i8, ptr %args17, i64 24
  %_388 = load ptr, ptr %113, align 8
; call <core::fmt::rt::Argument>::new_display::<fmt::Money>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_168, ptr align 8 %_388) #11
  %114 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %114, ptr align 8 %_165, i64 16, i1 false)
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_166, i64 16, i1 false)
  %116 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %116, ptr align 8 %_167, i64 16, i1 false)
  %117 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %117, ptr align 8 %_168, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<40, 4>
  %118 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj28_Kj4_ECshVgFdEre0pE_3fmt(ptr @alloc_80c3197a743f5124a0a564937a745665, ptr align 8 %args18) #11
  %_158.0 = extractvalue { ptr, ptr } %118, 0
  %_158.1 = extractvalue { ptr, ptr } %118, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_158.0, ptr %_158.1)
  store ptr @alloc_201c3ee118050b09cec852f4540cef71, ptr %args19, align 8
  %119 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr @alloc_201c3ee118050b09cec852f4540cef71, ptr %119, align 8
  %120 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr @alloc_201c3ee118050b09cec852f4540cef71, ptr %120, align 8
  %_389 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<fmt::Hex>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexNtCshVgFdEre0pE_3fmt3HexEB12_(ptr sret([16 x i8]) align 8 %_178, ptr align 4 %_389) #11
  %121 = getelementptr inbounds i8, ptr %args19, i64 8
  %_390 = load ptr, ptr %121, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<fmt::Hex>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexNtCshVgFdEre0pE_3fmt3HexEB12_(ptr sret([16 x i8]) align 8 %_179, ptr align 4 %_390) #11
  %122 = getelementptr inbounds i8, ptr %args19, i64 16
  %_391 = load ptr, ptr %122, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<fmt::Hex>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexNtCshVgFdEre0pE_3fmt3HexEB12_(ptr sret([16 x i8]) align 8 %_180, ptr align 4 %_391) #11
  %123 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %123, ptr align 8 %_178, i64 16, i1 false)
  %124 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %124, ptr align 8 %_179, i64 16, i1 false)
  %125 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %125, ptr align 8 %_180, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<20, 3>
  %126 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_2496decc21825f3f9b238b54f8d5e33f, ptr align 8 %args20) #11
  %_172.0 = extractvalue { ptr, ptr } %126, 0
  %_172.1 = extractvalue { ptr, ptr } %126, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_172.0, ptr %_172.1)
  store ptr @alloc_e0f292073631866f6c61fe5668d1ab0c, ptr %args21, align 8
  %127 = getelementptr inbounds i8, ptr %args21, i64 8
  store ptr @alloc_18e849d5c0b47b9a1071d700260ded41, ptr %127, align 8
  %128 = getelementptr inbounds i8, ptr %args21, i64 16
  store ptr @alloc_cdbdeba67b052fefbde5996b437aa24e, ptr %128, align 8
  %_392 = load ptr, ptr %args21, align 8
; call <core::fmt::rt::Argument>::new_lower_exp::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_190, ptr align 8 %_392) #11
  %129 = getelementptr inbounds i8, ptr %args21, i64 8
  %_393 = load ptr, ptr %129, align 8
; call <core::fmt::rt::Argument>::new_upper_exp::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_191, ptr align 8 %_393) #11
  %130 = getelementptr inbounds i8, ptr %args21, i64 16
  %_394 = load ptr, ptr %130, align 8
; call <core::fmt::rt::Argument>::new_lower_exp::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expmECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_192, ptr align 4 %_394) #11
  %131 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %131, ptr align 8 %_190, i64 16, i1 false)
  %132 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %132, ptr align 8 %_191, i64 16, i1 false)
  %133 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %133, ptr align 8 %_192, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %134 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args22) #11
  %_184.0 = extractvalue { ptr, ptr } %134, 0
  %_184.1 = extractvalue { ptr, ptr } %134, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_184.0, ptr %_184.1)
  store ptr @alloc_f93507f8ba4b5780b14b2c2584609be0, ptr %args23, align 8
  %135 = getelementptr inbounds i8, ptr %args23, i64 8
  store ptr @alloc_91984e5afffc475237697b8bd6a3e206, ptr %135, align 8
  %136 = getelementptr inbounds i8, ptr %args23, i64 16
  store ptr @alloc_ddd207f36435cdb5a6b231356b1990e9, ptr %136, align 8
  %_395 = load ptr, ptr %args23, align 8
; call <core::fmt::rt::Argument>::new_debug::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_202, ptr align 8 %_395) #11
  %137 = getelementptr inbounds i8, ptr %args23, i64 8
  %_396 = load ptr, ptr %137, align 8
; call <core::fmt::rt::Argument>::new_debug::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_203, ptr align 4 %_396) #11
  %138 = getelementptr inbounds i8, ptr %args23, i64 16
  %_397 = load ptr, ptr %138, align 8
; call <core::fmt::rt::Argument>::new_debug::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_204, ptr align 8 %_397) #11
  %139 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %139, ptr align 8 %_202, i64 16, i1 false)
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_203, i64 16, i1 false)
  %141 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %141, ptr align 8 %_204, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %142 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args24) #11
  %_196.0 = extractvalue { ptr, ptr } %142, 0
  %_196.1 = extractvalue { ptr, ptr } %142, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_196.0, ptr %_196.1)
  store ptr @alloc_86fe2e14e8aee3cbc4747be45abbb75c, ptr %args25, align 8
  %143 = getelementptr inbounds i8, ptr %args25, i64 8
  store ptr @alloc_3fd4ac1bd4aabc745420009965a8d1ac, ptr %143, align 8
  %144 = getelementptr inbounds i8, ptr %args25, i64 16
  store ptr @alloc_4e3160e3e5d83eeb2e7a3db504240512, ptr %144, align 8
  %_398 = load ptr, ptr %args25, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_214, ptr align 8 %_398) #11
  %145 = getelementptr inbounds i8, ptr %args25, i64 8
  %_399 = load ptr, ptr %145, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_215, ptr align 4 %_399) #11
  %146 = getelementptr inbounds i8, ptr %args25, i64 16
  %_400 = load ptr, ptr %146, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_216, ptr align 8 %_400) #11
  %147 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %147, ptr align 8 %_214, i64 16, i1 false)
  %148 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %148, ptr align 8 %_215, i64 16, i1 false)
  %149 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %149, ptr align 8 %_216, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %150 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args26) #11
  %_208.0 = extractvalue { ptr, ptr } %150, 0
  %_208.1 = extractvalue { ptr, ptr } %150, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_208.0, ptr %_208.1)
  store ptr @alloc_8821998f047ca62cad40e6bc4e4d87c4, ptr %args27, align 8
  %151 = getelementptr inbounds i8, ptr %args27, i64 8
  store ptr @alloc_5b64c5758b3793302fbedcd0481de01a, ptr %151, align 8
  %152 = getelementptr inbounds i8, ptr %args27, i64 16
  store ptr @alloc_c05f8b186ecd5789d56bb5d9e682c6d7, ptr %152, align 8
  %153 = getelementptr inbounds i8, ptr %args27, i64 24
  store ptr @alloc_2baa0b6208900c4f9b90e2cbbfb2ca47, ptr %153, align 8
  %_401 = load ptr, ptr %args27, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_227, ptr %_401) #11
  %154 = getelementptr inbounds i8, ptr %args27, i64 8
  %_402 = load ptr, ptr %154, align 8
; call <core::fmt::rt::Argument>::new_display::<char>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaycECshGsV4pNJ6ra_6object(ptr sret([16 x i8]) align 8 %_228, ptr align 4 %_402) #11
  %155 = getelementptr inbounds i8, ptr %args27, i64 16
  %_403 = load ptr, ptr %155, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_229, ptr align 8 %_403) #11
  %156 = getelementptr inbounds i8, ptr %args27, i64 24
  %_404 = load ptr, ptr %156, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_230, ptr align 8 %_404) #11
  %157 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args28, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %157, ptr align 8 %_227, i64 16, i1 false)
  %158 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args28, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %158, ptr align 8 %_228, i64 16, i1 false)
  %159 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args28, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %159, ptr align 8 %_229, i64 16, i1 false)
  %160 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args28, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %160, ptr align 8 %_230, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<37, 4>
  %161 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj25_Kj4_ECshVgFdEre0pE_3fmt(ptr @alloc_12541e1a1260b3fd7e4655df6b8014be, ptr align 8 %args28) #11
  %_220.0 = extractvalue { ptr, ptr } %161, 0
  %_220.1 = extractvalue { ptr, ptr } %161, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_220.0, ptr %_220.1)
; call <core::fmt::rt::Argument>::new_debug::<[core::option::Option<i32>; 2]>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAINtNtB7_6option6OptionlEj2_ECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_239, ptr align 4 @alloc_f19792d8e6fca51f99519584a77b3470) #11
; call <core::fmt::rt::Argument>::new_debug::<[[i32; 2]; 2]>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAAlj2_BY_ECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_240, ptr align 4 @alloc_68d244bd4070015bf9253d1ac51d25f8) #11
  %162 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args29, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %162, ptr align 8 %_239, i64 16, i1 false)
  %163 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args29, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %163, ptr align 8 %_240, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %164 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args29) #11
  %_234.0 = extractvalue { ptr, ptr } %164, 0
  %_234.1 = extractvalue { ptr, ptr } %164, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_234.0, ptr %_234.1)
  store ptr @alloc_cdbdeba67b052fefbde5996b437aa24e, ptr %args30, align 8
  %165 = getelementptr inbounds i8, ptr %args30, i64 8
  store ptr @alloc_fc18870ebd3bffa18e161a5a63775070, ptr %165, align 8
  %166 = getelementptr inbounds i8, ptr %args30, i64 16
  store ptr @alloc_a0256699fdc8ea22b569d2c1ec13c81f, ptr %166, align 8
  %_407 = load ptr, ptr %args30, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_250, ptr align 4 %_407) #11
  %167 = getelementptr inbounds i8, ptr %args30, i64 8
  %_408 = load ptr, ptr %167, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_251, ptr align 4 %_408) #11
  %168 = getelementptr inbounds i8, ptr %args30, i64 16
  %_409 = load ptr, ptr %168, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_252, ptr align 8 %_409) #11
  %169 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args31, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %169, ptr align 8 %_250, i64 16, i1 false)
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args31, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_251, i64 16, i1 false)
  %171 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args31, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %171, ptr align 8 %_252, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<30, 3>
  %172 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1e_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_352fcb003cd53a19ca29091d17651ce3, ptr align 8 %args31) #11
  %_244.0 = extractvalue { ptr, ptr } %172, 0
  %_244.1 = extractvalue { ptr, ptr } %172, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_244.0, ptr %_244.1)
  store ptr @alloc_cbaed04ca755d7df81f067609aba73ed, ptr %args32, align 8
  %173 = getelementptr inbounds i8, ptr %args32, i64 8
  store ptr @alloc_4b42cd106c262d3d9a145d6f4764eeaf, ptr %173, align 8
  %174 = getelementptr inbounds i8, ptr %args32, i64 16
  store ptr @alloc_5a1a9e6358d5f90dcb98724ce1d54ed0, ptr %174, align 8
  %_410 = load ptr, ptr %args32, align 8
; call <core::fmt::rt::Argument>::new_lower_exp::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_262, ptr align 8 %_410) #11
  %175 = getelementptr inbounds i8, ptr %args32, i64 8
  %_411 = load ptr, ptr %175, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_263, ptr align 4 %_411) #11
  %176 = getelementptr inbounds i8, ptr %args32, i64 16
  %_412 = load ptr, ptr %176, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_264, ptr align 8 %_412) #11
  %177 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args33, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %177, ptr align 8 %_262, i64 16, i1 false)
  %178 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args33, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %178, ptr align 8 %_263, i64 16, i1 false)
  %179 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args33, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %179, ptr align 8 %_264, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<32, 3>
  %180 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj20_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_5d68c547652bb8e5dddfa04dc983f46a, ptr align 8 %args33) #11
  %_256.0 = extractvalue { ptr, ptr } %180, 0
  %_256.1 = extractvalue { ptr, ptr } %180, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_256.0, ptr %_256.1)
; call <core::fmt::Arguments>::from_str_nonconst
  %181 = call { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCshVgFdEre0pE_3fmt(ptr @alloc_214cd245ef08d32d3c495a75f259c468, i64 4) #11
  %_268.0 = extractvalue { ptr, ptr } %181, 0
  %_268.1 = extractvalue { ptr, ptr } %181, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_268.0, ptr %_268.1)
; call <alloc::string::String>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %s) #11
; invoke <core::fmt::rt::Argument>::new_debug::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECs257F0UrNG3U_14rustc_demangle(ptr sret([16 x i8]) align 8 %_277, ptr align 8 @alloc_0fa510a23a05a548dfd86788ed688330)
          to label %bb115 unwind label %cleanup45

bb154:                                            ; preds = %bb153, %cleanup45
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %s) #13
          to label %bb157 unwind label %terminate

cleanup45:                                        ; preds = %bb2.i50, %bb2.i, %bb150, %bb145, %bb144, %bb143, %bb142, %bb141, %bb140, %bb139, %bb138, %bb137, %bb136, %bb135, %bb134, %bb133, %bb132, %bb131, %bb130, %bb129, %bb128, %bb127, %bb126, %bb125, %bb124, %bb123, %bb122, %bb121, %bb119, %bb118, %bb116, %bb115, %bb61
  %182 = landingpad { ptr, i32 }
          cleanup
  %183 = extractvalue { ptr, i32 } %182, 0
  %184 = extractvalue { ptr, i32 } %182, 1
  store ptr %183, ptr %0, align 8
  %185 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %184, ptr %185, align 8
  br label %bb154

bb115:                                            ; preds = %bb61
  %186 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args34, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %186, ptr align 8 %_277, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<5, 1>
  %187 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj5_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_f1045206bd356f04ecf6c5daa5616281, ptr align 8 %args34)
          to label %bb116 unwind label %cleanup45

bb116:                                            ; preds = %bb115
  %_273.0 = extractvalue { ptr, ptr } %187, 0
  %_273.1 = extractvalue { ptr, ptr } %187, 1
; invoke <alloc::string::String as core::fmt::Write>::write_fmt
  %_271 = invoke zeroext i1 @_RNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtB6_(ptr align 8 %s, ptr %_273.0, ptr %_273.1)
          to label %bb117 unwind label %cleanup45

bb117:                                            ; preds = %bb116
  %188 = zext i1 %_271 to i8
  store i8 %188, ptr %self.i48, align 1
  %189 = load i8, ptr %self.i48, align 1
  %190 = trunc nuw i8 %189 to i1
  %_2.i49 = zext i1 %190 to i64
  br i1 %190, label %bb2.i50, label %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit52

bb2.i50:                                          ; preds = %bb117
; invoke core::result::unwrap_failed
  invoke void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 43, ptr %e.i47, ptr align 8 @vtable.5, ptr align 8 @alloc_ea556a6fc27bebb9c43699dd3a5fa3f3) #15
          to label %.noexc51 unwind label %cleanup45

.noexc51:                                         ; preds = %bb2.i50
  unreachable

_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit52: ; preds = %bb117
  br label %bb118

bb118:                                            ; preds = %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit52
; invoke <core::fmt::Arguments>::from_str
  %191 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_aa8949e1fb3783c4ba3f17396bbaa3bf, i64 2)
          to label %bb119 unwind label %cleanup45

bb119:                                            ; preds = %bb118
  %_283.0 = extractvalue { ptr, ptr } %191, 0
  %_283.1 = extractvalue { ptr, ptr } %191, 1
; invoke <alloc::string::String as core::fmt::Write>::write_fmt
  %_281 = invoke zeroext i1 @_RNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtB6_(ptr align 8 %s, ptr %_283.0, ptr %_283.1)
          to label %bb120 unwind label %cleanup45

bb120:                                            ; preds = %bb119
  %192 = zext i1 %_281 to i8
  store i8 %192, ptr %self.i, align 1
  %193 = load i8, ptr %self.i, align 1
  %194 = trunc nuw i8 %193 to i1
  %_2.i = zext i1 %194 to i64
  br i1 %194, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit

bb2.i:                                            ; preds = %bb120
; invoke core::result::unwrap_failed
  invoke void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 43, ptr %e.i, ptr align 8 @vtable.5, ptr align 8 @alloc_a7aedc039a5bce5f90b5974852c9f0c9) #15
          to label %.noexc unwind label %cleanup45

.noexc:                                           ; preds = %bb2.i
  unreachable

_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit: ; preds = %bb120
  br label %bb121

bb121:                                            ; preds = %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit
; invoke <core::fmt::rt::Argument>::new_display::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_289, ptr align 8 %s)
          to label %bb122 unwind label %cleanup45

bb122:                                            ; preds = %bb121
  %195 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args35, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %195, ptr align 8 %_289, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<2, 1>
  %196 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj2_Kj1_EB8_(ptr @alloc_0c812808379efded5a4fb82d2790b556, ptr align 8 %args35)
          to label %bb123 unwind label %cleanup45

bb123:                                            ; preds = %bb122
  %_285.0 = extractvalue { ptr, ptr } %196, 0
  %_285.1 = extractvalue { ptr, ptr } %196, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_285.0, ptr %_285.1)
          to label %bb124 unwind label %cleanup45

bb124:                                            ; preds = %bb123
; invoke <core::fmt::Arguments>::from_str_nonconst
  %197 = invoke { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCshVgFdEre0pE_3fmt(ptr @alloc_9beb045410d021e66c87fb3fce4c6912, i64 12)
          to label %bb125 unwind label %cleanup45

bb125:                                            ; preds = %bb124
  %_293.0 = extractvalue { ptr, ptr } %197, 0
  %_293.1 = extractvalue { ptr, ptr } %197, 1
; invoke std::io::stdio::_eprint
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio7__eprint(ptr %_293.0, ptr %_293.1)
          to label %bb126 unwind label %cleanup45

bb126:                                            ; preds = %bb125
; invoke <core::fmt::rt::Argument>::new_debug::<i128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugnECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_300, ptr align 16 @alloc_b7cbb96fa2fbc2c33cfdce3b367921a6)
          to label %bb127 unwind label %cleanup45

bb127:                                            ; preds = %bb126
; invoke <core::fmt::rt::Argument>::new_debug::<u128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugoECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_301, ptr align 16 @alloc_d0776666182ad032bd1011cf266e2f3a)
          to label %bb128 unwind label %cleanup45

bb128:                                            ; preds = %bb127
  %198 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args36, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %198, ptr align 8 %_300, i64 16, i1 false)
  %199 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args36, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %199, ptr align 8 %_301, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %200 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args36)
          to label %bb129 unwind label %cleanup45

bb129:                                            ; preds = %bb128
  %_295.0 = extractvalue { ptr, ptr } %200, 0
  %_295.1 = extractvalue { ptr, ptr } %200, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_295.0, ptr %_295.1)
          to label %bb130 unwind label %cleanup45

bb130:                                            ; preds = %bb129
  store ptr @alloc_2aed27a01081c9f91b0f84d085de36d9, ptr %args37, align 8
  %201 = getelementptr inbounds i8, ptr %args37, i64 8
  store ptr @alloc_2aed27a01081c9f91b0f84d085de36d9, ptr %201, align 8
  %202 = getelementptr inbounds i8, ptr %args37, i64 16
  store ptr @alloc_2aed27a01081c9f91b0f84d085de36d9, ptr %202, align 8
  %_417 = load ptr, ptr %args37, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_311, ptr align 4 %_417)
          to label %bb131 unwind label %cleanup45

bb131:                                            ; preds = %bb130
  %203 = getelementptr inbounds i8, ptr %args37, i64 8
  %_418 = load ptr, ptr %203, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_312, ptr align 4 %_418)
          to label %bb132 unwind label %cleanup45

bb132:                                            ; preds = %bb131
  %204 = getelementptr inbounds i8, ptr %args37, i64 16
  %_419 = load ptr, ptr %204, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_313, ptr align 4 %_419)
          to label %bb133 unwind label %cleanup45

bb133:                                            ; preds = %bb132
  %205 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args38, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %205, ptr align 8 %_311, i64 16, i1 false)
  %206 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args38, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %206, ptr align 8 %_312, i64 16, i1 false)
  %207 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args38, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %207, ptr align 8 %_313, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<29, 3>
  %208 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1d_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_c424b10c3bbe424e4bad8e7fe84cacd4, ptr align 8 %args38)
          to label %bb134 unwind label %cleanup45

bb134:                                            ; preds = %bb133
  %_305.0 = extractvalue { ptr, ptr } %208, 0
  %_305.1 = extractvalue { ptr, ptr } %208, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_305.0, ptr %_305.1)
          to label %bb135 unwind label %cleanup45

bb135:                                            ; preds = %bb134
; invoke <core::fmt::rt::Argument>::new_pointer::<*const u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_pointerPhECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_321, ptr align 8 @alloc_53973d2fe29b4adba8bb7390b5678745)
          to label %bb136 unwind label %cleanup45

bb136:                                            ; preds = %bb135
  %209 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args39, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %209, ptr align 8 %_321, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %210 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args39)
          to label %bb137 unwind label %cleanup45

bb137:                                            ; preds = %bb136
  %_317.0 = extractvalue { ptr, ptr } %210, 0
  %_317.1 = extractvalue { ptr, ptr } %210, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_317.0, ptr %_317.1)
          to label %bb138 unwind label %cleanup45

bb138:                                            ; preds = %bb137
; invoke <core::time::Duration>::from_millis
  %211 = invoke { i64, i32 } @_RNvMNtCsl10jNU3mE6R_4core4timeNtB2_8Duration11from_millisCshVgFdEre0pE_3fmt(i64 1500)
          to label %bb139 unwind label %cleanup45

bb139:                                            ; preds = %bb138
  %212 = extractvalue { i64, i32 } %211, 0
  %213 = extractvalue { i64, i32 } %211, 1
  store i64 %212, ptr %_328, align 8
  %214 = getelementptr inbounds i8, ptr %_328, i64 8
  store i32 %213, ptr %214, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::time::Duration>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_4time8DurationECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_330, ptr align 8 %_328)
          to label %bb140 unwind label %cleanup45

bb140:                                            ; preds = %bb139
  %215 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args40, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %215, ptr align 8 %_330, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %216 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args40)
          to label %bb141 unwind label %cleanup45

bb141:                                            ; preds = %bb140
  %_325.0 = extractvalue { ptr, ptr } %216, 0
  %_325.1 = extractvalue { ptr, ptr } %216, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_325.0, ptr %_325.1)
          to label %bb142 unwind label %cleanup45

bb142:                                            ; preds = %bb141
; invoke <core::fmt::rt::Argument>::new_display::<f64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_338, ptr align 8 @alloc_783ee260e8ae01216c1a7e8d97dd7885)
          to label %bb143 unwind label %cleanup45

bb143:                                            ; preds = %bb142
  %217 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args41, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %217, ptr align 8 %_338, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %218 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args41)
          to label %bb144 unwind label %cleanup45

bb144:                                            ; preds = %bb143
  %_334.0 = extractvalue { ptr, ptr } %218, 0
  %_334.1 = extractvalue { ptr, ptr } %218, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_334.0, ptr %_334.1)
          to label %bb145 unwind label %cleanup45

bb145:                                            ; preds = %bb144
; invoke <alloc::string::String as core::convert::From<&str>>::from
  invoke void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_345, ptr @alloc_b03741e4fa93f143426998f2aacbbd7f, i64 2)
          to label %bb146 unwind label %cleanup45

bb146:                                            ; preds = %bb145
; invoke <core::fmt::rt::Argument>::new_debug::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_348, ptr align 8 %_345)
          to label %bb147 unwind label %cleanup46

bb153:                                            ; preds = %cleanup46
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_345) #13
          to label %bb154 unwind label %terminate

cleanup46:                                        ; preds = %bb149, %bb148, %bb147, %bb146
  %219 = landingpad { ptr, i32 }
          cleanup
  %220 = extractvalue { ptr, i32 } %219, 0
  %221 = extractvalue { ptr, i32 } %219, 1
  store ptr %220, ptr %0, align 8
  %222 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %221, ptr %222, align 8
  br label %bb153

bb147:                                            ; preds = %bb146
; invoke <core::fmt::rt::Argument>::new_debug::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugmEB7_(ptr sret([16 x i8]) align 8 %_349, ptr align 4 @alloc_9b2bf7077a3c4b95a732f8a187d9d5ed)
          to label %bb148 unwind label %cleanup46

bb148:                                            ; preds = %bb147
  %223 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args42, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %223, ptr align 8 %_348, i64 16, i1 false)
  %224 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args42, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %224, ptr align 8 %_349, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %225 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args42)
          to label %bb149 unwind label %cleanup46

bb149:                                            ; preds = %bb148
  %_342.0 = extractvalue { ptr, ptr } %225, 0
  %_342.1 = extractvalue { ptr, ptr } %225, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_342.0, ptr %_342.1)
          to label %bb150 unwind label %cleanup46

bb150:                                            ; preds = %bb149
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_345)
          to label %bb151 unwind label %cleanup45

bb151:                                            ; preds = %bb150
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %s)
  ret void

terminate:                                        ; preds = %bb156, %bb155, %bb154, %bb153
  %226 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #16
  unreachable

bb157:                                            ; preds = %bb156, %bb155, %bb154
  %227 = load ptr, ptr %0, align 8
  %228 = getelementptr inbounds i8, ptr %0, i64 8
  %229 = load i32, ptr %228, align 8
  %230 = insertvalue { ptr, i32 } poison, ptr %227, 0
  %231 = insertvalue { ptr, i32 } %230, i32 %229, 1
  resume { ptr, i32 } %231
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !206 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !207 {
start:
  %_1 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newB4_(ptr sret([24 x i8]) align 8 %_1) #11
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_1, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !208 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8 %self) #11
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr %_2.0, i64 %_2.1) #11
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !209 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::time::Duration>::from_millis
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RNvMNtCsl10jNU3mE6R_4core4timeNtB2_8Duration11from_millisCshVgFdEre0pE_3fmt(i64 %millis) unnamed_addr #0 !guid !210 {
start:
  %secs = udiv i64 %millis, 1000
  %_5 = urem i64 %millis, 1000
  %subsec_millis = trunc i64 %_5 to i32
  %_8 = mul i32 %subsec_millis, 1000000
; call <core::num::niche_types::Nanoseconds>::new_unchecked
  %subsec_nanos = call i32 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB5_11Nanoseconds13new_uncheckedCshVgFdEre0pE_3fmt(i32 %_8) #11
  %0 = insertvalue { i64, i32 } poison, i64 %secs, 0
  %1 = insertvalue { i64, i32 } %0, i32 %subsec_nanos, 1
  ret { i64, i32 } %1
}

; <[[i32; 2]]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAlj2_4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !211 {
start:
; call <core::slice::iter::Iter<[i32; 2]>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAlj2_E3newCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #11
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[core::option::Option<i32>]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtB4_6option6OptionlE4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !212 {
start:
; call <core::slice::iter::Iter<core::option::Option<i32>>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterINtNtB9_6option6OptionlEE3newCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #11
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[f64]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCshVgFdEre0pE_3fmt(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !213 {
start:
; call <core::slice::iter::Iter<f64>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterdE3newCshVgFdEre0pE_3fmt(ptr align 8 %self.0, i64 %self.1) #11
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::fmt::rt::Argument>::from_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x, ptr align 8 %0) unnamed_addr #0 !guid !214 {
start:
  %_7 = alloca [16 x i8], align 8
  %_3 = load i64, ptr %x, align 8
  %_2 = icmp ugt i64 %_3, 65535
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_9 = load i64, ptr %x, align 8
  %_8 = trunc i64 %_9 to i16
  %1 = getelementptr inbounds i8, ptr %_7, i64 8
  store i16 %_8, ptr %1, align 8
  store ptr null, ptr %_7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_7, i64 16, i1 false)
  ret void

bb1:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %2 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_bed8969a4b39b5529597d14a2d5628f2, i64 32) #11
  %_6.0 = extractvalue { ptr, ptr } %2, 0
  %_6.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 %0) #15
  unreachable
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCshVgFdEre0pE_3fmt(i64 %self) unnamed_addr #0 !guid !215 {
start:
  ret i64 %self
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !216 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCshVgFdEre0pE_3fmt(i64 %_3) #11
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #11
  ret ptr %_0
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !217 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !218 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCshVgFdEre0pE_3fmt(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !219 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCshVgFdEre0pE_3fmt(i64 %3, i64 %5, i1 zeroext %8) #11
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCshVgFdEre0pE_3fmt(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !220 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #11
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCshVgFdEre0pE_3fmt(ptr align 8 %layout) #11
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #11
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCshVgFdEre0pE_3fmt(i64 %11, i64 %13) #11
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCshVgFdEre0pE_3fmt(i64 %15, i64 %17) #11
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #11
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #11
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #11
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #11
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #11
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<[[i32; 2]; 2]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAAlj2_BW_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !221 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[core::option::Option<i32>; 2]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAINtNtB9_6option6OptionlEj2_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !222 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::option::Option<f64>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptiondEE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !223 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::option::Option<u8>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionhEE8from_refCshVgFdEre0pE_3fmt(ptr %r) unnamed_addr #0 !guid !224 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !225 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<fmt::E>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt1EE8from_refBV_(ptr align 8 %r) unnamed_addr #0 !guid !226 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<fmt::Hex>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt3HexE8from_refBV_(ptr align 4 %r) unnamed_addr #0 !guid !227 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<fmt::Money>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt5MoneyE8from_refBV_(ptr align 8 %r) unnamed_addr #0 !guid !228 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<fmt::Point>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt5PointE8from_refBV_(ptr align 8 %r) unnamed_addr #0 !guid !229 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::time::Duration>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_4time8DurationE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !230 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !231 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<*const u8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullPhE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !232 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[[i32; 2]]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAlj2_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r.0, i64 %r.1) unnamed_addr #0 !guid !233 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[core::option::Option<i32>]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSINtNtB9_6option6OptionlEE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r.0, i64 %r.1) unnamed_addr #0 !guid !234 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[f64]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSdE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r.0, i64 %r.1) unnamed_addr #0 !guid !235 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<(i32, &str, [f64; 2])>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTlReAdj2_EE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !236 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCshVgFdEre0pE_3fmt(ptr %r) unnamed_addr #0 !guid !237 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !238 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !239 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCshVgFdEre0pE_3fmt(ptr align 16 %r) unnamed_addr #0 !guid !240 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<()>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulluE8from_refCshVgFdEre0pE_3fmt(ptr %r) unnamed_addr #0 !guid !241 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !242 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::from_str_nonconst
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCshVgFdEre0pE_3fmt(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !243 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr %s.0, i64 %s.1) #11
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !244 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #11
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr %_7.0, i64 %_7.1) #11
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !245 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshVgFdEre0pE_3fmt(ptr %s.0, i64 %s.1) #11
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<[i32; 2]>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAlj2_E3newCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !246 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[[i32; 2]]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAlj2_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) #11
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[[i32; 2]]>>::cast::<[i32; 2]>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAlj2_E4castBV_ECshVgFdEre0pE_3fmt(ptr %_4.0, i64 %_4.1) #11
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw [2 x i32], ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<core::option::Option<i32>>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterINtNtB9_6option6OptionlEE3newCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !247 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[core::option::Option<i32>]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSINtNtB9_6option6OptionlEE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) #11
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[core::option::Option<i32>]>>::cast::<core::option::Option<i32>>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSINtNtBa_6option6OptionlEE4castBV_ECshVgFdEre0pE_3fmt(ptr %_4.0, i64 %_4.1) #11
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw %"core::option::Option<i32>", ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f64>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterdE3newCshVgFdEre0pE_3fmt(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !248 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[f64]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSdE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %slice.0, i64 %slice.1) #11
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[f64]>>::cast::<f64>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSdE4castdECshVgFdEre0pE_3fmt(ptr %_4.0, i64 %_4.1) #11
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw double, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::num::niche_types::Nanoseconds>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB5_11Nanoseconds13new_uncheckedCshVgFdEre0pE_3fmt(i32 %val) unnamed_addr #0 !guid !249 {
start:
  ret i32 %val
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !250 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshVgFdEre0pE_3fmt(i8 %0) unnamed_addr #0 !guid !251 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshVgFdEre0pE_3fmt(ptr %self) #11
  ret i32 %_0
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !252 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCshVgFdEre0pE_3fmt(ptr align 8 %args) #11
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #11
  ret void
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCshVgFdEre0pE_3fmt(i64 %0, i64 %1) unnamed_addr #0 !guid !253 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #17
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #11
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshVgFdEre0pE_3fmt(ptr align 8 %layout) #11
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #17
  ret ptr %_0
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCshVgFdEre0pE_3fmt(i64 %0, i64 %1) unnamed_addr #0 !guid !254 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #17
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #11
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshVgFdEre0pE_3fmt(ptr align 8 %layout) #11
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #17
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshVgFdEre0pE_3fmt(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !255 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCshVgFdEre0pE_3fmt(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #11
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #18
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #11
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !256 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; <fmt::Money as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXCshVgFdEre0pE_3fmtNtB2_5MoneyNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !257 {
start:
  %0 = alloca [16 x i8], align 8
  %_23 = alloca [16 x i8], align 8
  %_22 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_15 = alloca [8 x i8], align 8
  %_8 = alloca [8 x i8], align 8
  %_4 = alloca [24 x i8], align 8
  %s = alloca [24 x i8], align 8
  %_9 = load i64, ptr %self, align 8
  %_12 = icmp eq i64 %_9, -9223372036854775808
  %_13 = and i1 false, %_12
  br i1 %_13, label %panic, label %bb2

bb2:                                              ; preds = %start
  %1 = sdiv i64 %_9, 100
  store i64 %1, ptr %_8, align 8
  %_16 = load i64, ptr %self, align 8
  %_19 = icmp eq i64 %_16, -9223372036854775808
  %_20 = and i1 false, %_19
  br i1 %_20, label %panic1, label %bb4

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_78648a3da0583c3a93ec45d48e44c913) #15
  unreachable

bb4:                                              ; preds = %bb2
  %2 = srem i64 %_16, 100
  store i64 %2, ptr %_15, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_22, ptr align 8 %_8) #11
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_23, ptr align 8 %_15) #11
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_22, i64 16, i1 false)
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_23, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 2>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj2_EB8_(ptr @alloc_6ddf87a275032c244ec296015b313b7a, ptr align 8 %args) #11
  %_5.0 = extractvalue { ptr, ptr } %5, 0
  %_5.1 = extractvalue { ptr, ptr } %5, 1
; call alloc::fmt::format
  call void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_4, ptr %_5.0, ptr %_5.1) #11
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %s, ptr align 8 %_4, i64 24, i1 false)
; invoke <alloc::string::String as core::ops::deref::Deref>::deref
  %6 = invoke { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %s)
          to label %bb10 unwind label %cleanup

panic1:                                           ; preds = %bb2
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_2a7a4456520952dbf8a616376b1f7793) #15
  unreachable

bb13:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %s) #13
          to label %bb14 unwind label %terminate

cleanup:                                          ; preds = %bb10, %bb4
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb13

bb10:                                             ; preds = %bb4
  %_26.0 = extractvalue { ptr, i64 } %6, 0
  %_26.1 = extractvalue { ptr, i64 } %6, 1
; invoke <core::fmt::Formatter>::pad
  %_0 = invoke zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3pad(ptr align 8 %f, ptr %_26.0, i64 %_26.1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %s)
  ret i1 %_0

terminate:                                        ; preds = %bb13
  %11 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #16
  unreachable

bb14:                                             ; preds = %bb13
  %12 = load ptr, ptr %0, align 8
  %13 = getelementptr inbounds i8, ptr %0, i64 8
  %14 = load i32, ptr %13, align 8
  %15 = insertvalue { ptr, i32 } poison, ptr %12, 0
  %16 = insertvalue { ptr, i32 } %15, i32 %14, 1
  resume { ptr, i32 } %16
}

; <core::slice::iter::Iter<[i32; 2]> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterAlj2_ENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !258 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<core::option::Option<i32>> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterINtNtB8_6option6OptionlEENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !259 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<f64> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterdENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !260 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !261 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <fmt::Point as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs0_CshVgFdEre0pE_3fmtNtB5_5PointNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !262 {
start:
  %_13 = alloca [8 x i8], align 8
  %_6 = getelementptr inbounds i8, ptr %self, i64 16
  %_9 = getelementptr inbounds i8, ptr %self, i64 20
  store ptr %self, ptr %_13, align 8
; call <core::fmt::Formatter>::debug_struct_field3_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field3_finish(ptr align 8 %f, ptr @alloc_bf0ef947d182249ea2203578272460c5, i64 5, ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, i64 1, ptr %_6, ptr align 8 @vtable.6, ptr @alloc_cd51bc84b49b21a3fdb2800731f25c21, i64 1, ptr %_9, ptr align 8 @vtable.7, ptr @alloc_125af81ac88d8b2d4254bab0c6fa4f63, i64 3, ptr %_13, ptr align 8 @vtable.8)
  ret i1 %_0
}

; <(i32, &str, [f64; 2]) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1F_NtCsl10jNU3mE6R_4core3fmtTlReAdj2_ENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !263 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %V = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %0, ptr %V, align 8
  store ptr %self, ptr %U, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 24
  store ptr %1, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_8 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %V, ptr align 8 @vtable.3)
; call <core::fmt::builders::DebugTuple>::field
  %_12 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.9)
; call <core::fmt::builders::DebugTuple>::field
  %_16 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.a)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <(i8, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTabENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #1 !guid !264 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.b)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.c)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCshVgFdEre0pE_3fmt(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !265 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCshVgFdEre0pE_3fmt(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #11
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <&str as core::convert::Into<alloc::string::String>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !266 {
start:
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #11
  ret void
}

; <&[f64; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAdj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !267 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <[f64; 2] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAdj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&[i32; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAlj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !268 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <[i32; 2] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAlj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&core::option::Option<&str> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionReENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !269 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::option::Option<&str> as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionReENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8 %_3, ptr align 8 %f) #11
  ret i1 %_0
}

; <&core::option::Option<i32> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionlENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !270 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::option::Option<i32> as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std(ptr align 4 %_3, ptr align 8 %f) #11
  ret i1 %_0
}

; <&alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !271 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <alloc::string::String as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_3, ptr align 8 %f) #11
  ret i1 %_0
}

; <&[[i32; 2]] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSAlj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !272 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[[i32; 2]] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSAlj2_NtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[core::option::Option<i32>] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSINtNtB8_6option6OptionlENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !273 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[core::option::Option<i32>] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSINtNtB7_6option6OptionlENtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[f64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSdNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !274 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[f64] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSdNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSlNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !275 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[i32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&(i8, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRTabENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !276 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <(i8, bool) as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTabENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&i8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !277 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %_3, ptr align 8 %f) #11
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !278 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %_3, ptr align 8 %f) #11
  ret i1 %_0
}

; <&f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !279 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <f64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <core::slice::iter::Iter<[i32; 2]> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterAlj2_ENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !280 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<[i32; 2]> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAlj2_ENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %ptr, ptr align 8 %_11) #11
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw [2 x i32], ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<core::option::Option<i32>> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterINtNtBa_6option6OptionlEENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !281 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i32>> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %ptr, ptr align 8 %_11) #11
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw %"core::option::Option<i32>", ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !282 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %ptr, ptr align 8 %_11) #11
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw double, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !283 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #11
  ret void
}

; <fmt::E as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_CshVgFdEre0pE_3fmtNtB5_1ENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !284 {
start:
  %__self_11 = alloca [8 x i8], align 8
  %__self_1 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %_3 = zext i8 %0 to i64
  switch i64 %_3, label %bb1 [
    i64 0, label %bb4
    i64 1, label %bb3
    i64 2, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb4:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %1 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_13c56e54a9571211dcad2a135c9eaa2b, i64 4)
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %start
  %__self_0 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_1, align 8
; call <core::fmt::Formatter>::debug_tuple_field2_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field2_finish(ptr align 8 %f, ptr @alloc_8388317ddce58f972b519ce81ee4ed85, i64 3, ptr %__self_0, ptr align 8 @vtable.d, ptr %__self_1, ptr align 8 @vtable.e)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb5

bb2:                                              ; preds = %start
  %__self_02 = getelementptr inbounds i8, ptr %self, i64 8
  %6 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %6, ptr %__self_11, align 8
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr align 8 %f, ptr @alloc_3b31bdf1fe846135477a792935103ed1, i64 3, ptr @alloc_3827bbb606bbdb0f0c926011c14ccc34, i64 1, ptr %__self_02, ptr align 8 @vtable.f, ptr @alloc_ab7766fee1e1b94f8c00ce7ffec41c7e, i64 1, ptr %__self_11, ptr align 8 @vtable.g)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3, %bb4
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[[i32; 2]]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSAlj2_E5indexCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !285 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[core::option::Option<i32>]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSINtNtB9_6option6OptionlEE5indexCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !286 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[f64]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSdE5indexCshVgFdEre0pE_3fmt(ptr align 8 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !287 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i32]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSlE5indexCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !288 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !289 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #11
  ret void
}

; <core::fmt::Error as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsK_NtCsl10jNU3mE6R_4core3fmtNtB5_5ErrorNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !290 {
start:
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_99ac8a81a24cac863217ce4a5cbfabea, i64 5)
  ret i1 %_0
}

; <i8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !291 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <i32 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !292 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i32 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i32 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i32 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::option::Option<f64> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptiondENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !293 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %_3 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load double, ptr %0, align 8
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.2)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <i128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !294 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshVgFdEre0pE_3fmt() unnamed_addr #0 !guid !295 {
start:
  ret i8 0
}

; <u8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !296 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <u128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !297 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <fmt::Hex as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs_CshVgFdEre0pE_3fmtNtB4_3HexNtNtCsl10jNU3mE6R_4core3fmt8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !298 {
start:
; call <u32 as core::fmt::LowerHex>::fmt
  %_0 = call zeroext i1 @_RNvXsu_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  ret i1 %_0
}

; <[[i32; 2]; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAAlj2_Bz_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !299 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[[i32; 2]; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAAlj2_Bz_INtNtNtB7_3ops5index5IndexNtNtBK_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #11
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !193
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[[i32; 2]] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSAlj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[core::option::Option<i32>; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAINtNtB7_6option6OptionlEj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !300 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[core::option::Option<i32>; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAINtNtB7_6option6OptionlEj2_INtNtNtB7_3ops5index5IndexNtNtB13_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #11
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !193
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[core::option::Option<i32>] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSINtNtB8_6option6OptionlENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[f64; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAdj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !301 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[f64; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAdj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #11
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !193
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[f64] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSdNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[i32; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAlj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !302 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[i32; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAlj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #11
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !193
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[i32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSlNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[[i32; 2]; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAAlj2_Bz_INtNtNtB7_3ops5index5IndexNtNtBK_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %0) unnamed_addr #0 !guid !303 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[[i32; 2]]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSAlj2_E5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, i64 2, ptr align 8 %0) #11
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <[core::option::Option<i32>; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAINtNtB7_6option6OptionlEj2_INtNtNtB7_3ops5index5IndexNtNtB13_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %0) unnamed_addr #0 !guid !304 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[core::option::Option<i32>]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSINtNtB9_6option6OptionlEE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, i64 2, ptr align 8 %0) #11
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <[f64; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAdj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %0) unnamed_addr #0 !guid !305 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[f64]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSdE5indexCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 2, ptr align 8 %0) #11
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <[i32; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAlj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %0) unnamed_addr #0 !guid !306 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i32]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSlE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, i64 2, ptr align 8 %0) #11
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::non_null::NonNull<[i32; 2]> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAlj2_ENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !307 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !308 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !309 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !310 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <*const u8 as core::fmt::Pointer>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsl_NtCsl10jNU3mE6R_4core3fmtPhNtB5_7Pointer3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !311 {
start:
  %_0 = alloca [1 x i8], align 1
  %ptr = load ptr, ptr %self, align 8
  %_0.i = ptrtoint ptr %ptr to i64
  br label %bb2

bb2:                                              ; preds = %start
; call core::fmt::pointer_fmt_inner
  %0 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt17pointer_fmt_inner(i64 %_0.i, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb2
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  ret i1 %3

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !312 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %self) #11
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !313 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %self) #11
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <[[i32; 2]] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSAlj2_NtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !314 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[[i32; 2]]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAlj2_4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #11
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&[i32; 2], core::slice::iter::Iter<[i32; 2]>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRAlj2_INtNtNtBa_5slice4iter4IterB14_EECshVgFdEre0pE_3fmt(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[core::option::Option<i32>] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSINtNtB7_6option6OptionlENtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !315 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[core::option::Option<i32>]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtB4_6option6OptionlE4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #11
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&core::option::Option<i32>, core::slice::iter::Iter<core::option::Option<i32>>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRINtNtBa_6option6OptionlEINtNtNtBa_5slice4iter4IterB14_EECshVgFdEre0pE_3fmt(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[f64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSdNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !316 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[f64]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCshVgFdEre0pE_3fmt(ptr align 8 %self.0, i64 %self.1) #11
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&f64, core::slice::iter::Iter<f64>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRdINtNtNtBa_5slice4iter4IterdEECshVgFdEre0pE_3fmt(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !317 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[i32]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsddYV2PBJW9h_3std(ptr align 4 %self.0, i64 %self.1) #11
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECshVgFdEre0pE_3fmt(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <() as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXss_NtCsl10jNU3mE6R_4core3fmtuNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !318 {
start:
; call <core::fmt::Formatter>::pad
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3pad(ptr align 8 %f, ptr @alloc_ae6dc619079e3c3b08144a35532ecff7, i64 2)
  ret i1 %_0
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !319 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCshVgFdEre0pE_3fmt(ptr align 8 %self) #11
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshVgFdEre0pE_3fmt(ptr %_1) unnamed_addr #0 !guid !320 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshVgFdEre0pE_3fmt(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !321 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshVgFdEre0pE_3fmt(ptr align 8 %_1) #11
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<i32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refB9_(ptr align 4) unnamed_addr #0

; <core::ptr::non_null::NonNull<i32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuEBa_(ptr) unnamed_addr #0

; <i32 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsr_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_6Binary3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #3

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::LowerExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8LowerExp3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refB9_(ptr align 4) unnamed_addr #0

; <core::ptr::non_null::NonNull<u32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuEBa_(ptr) unnamed_addr #0

; <u32 as core::fmt::LowerExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsw_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_8LowerExp3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::UpperExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8UpperExp3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <core::option::Option<u8> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionhENtNtB7_3fmt5Debug3fmtCs7CppTae75M1_5alloc(ptr, ptr align 8) unnamed_addr #0

; <core::option::Option<i32> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std(ptr align 4, ptr align 8) unnamed_addr #0

; <core::time::Duration as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core4timeNtB5_8DurationNtNtB7_3fmt5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs2_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_5Debug3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16) unnamed_addr #0

; <core::ptr::non_null::NonNull<u128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #4

; <core::fmt::builders::DebugList>::entry
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #0

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <[u8]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh8into_vecNtNtB5_5alloc6GlobalEB5_(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #0

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEEBG_(ptr align 8) unnamed_addr #1

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::rt::Argument>::new_lower_hex::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexlECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_debug::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECs257F0UrNG3U_14rustc_demangle(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<14, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_debug::<char>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugcEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #5

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #5

; <core::fmt::rt::Argument>::new_display::<char>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaycECshGsV4pNJ6ra_6object(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <alloc::string::String as core::fmt::Write>::write_fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtB6_(ptr align 8, ptr, ptr) unnamed_addr #1

; <core::fmt::Arguments>::new::<2, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj2_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; std::io::stdio::_eprint
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio7__eprint(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_debug::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugmEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #5

; <alloc::vec::Vec<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newB4_(ptr sret([24 x i8]) align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8) unnamed_addr #0

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #6

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #6

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #0

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #4

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #7

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #8

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #9

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #6

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #6

; <core::fmt::Arguments>::new::<13, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj2_EB8_(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::Formatter>::pad
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3pad(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field3_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field3_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <&&str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; <core::option::Option<&str> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionReENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #0

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
declare void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field2_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field2_finish(ptr align 8, ptr, i64, ptr, ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <alloc::vec::Vec<u8> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field2_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <i8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsu_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8LowerHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; core::fmt::pointer_fmt_inner
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt17pointer_fmt_inner(i64, ptr align 8) unnamed_addr #1

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugList>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8) unnamed_addr #1

; <[i32]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsddYV2PBJW9h_3std(ptr align 4, i64) unnamed_addr #0

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #10 !guid !322 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshVgFdEre0pE_3fmt(ptr @_RNvCshVgFdEre0pE_3fmt4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { nonlazybind "target-cpu"="x86-64" }
attributes #11 = { inlinehint }
attributes #12 = { noinline }
attributes #13 = { cold }
attributes #14 = { noinline noreturn nounwind }
attributes #15 = { noinline noreturn }
attributes #16 = { cold noreturn nounwind }
attributes #17 = { nounwind }
attributes #18 = { noreturn }

!llvm.module.flags = !{!126, !127, !128, !129}
!llvm.ident = !{!130}

!0 = !{i64 4826553944420744064}
!1 = !{i64 -5868088760374213520}
!2 = !{i64 -5247999083806311652}
!3 = !{i64 -2157459987852952136}
!4 = !{i64 1482093489364193675}
!5 = !{i64 1623664849433225670}
!6 = !{i64 -1593472230304319314}
!7 = !{i64 -7635163248810649716}
!8 = !{i64 -577073546356888829}
!9 = !{i64 -6844108194042499373}
!10 = !{i64 -516169824412150636}
!11 = !{i64 -1908063299884387600}
!12 = !{i64 757139644034383545}
!13 = !{i64 3722681223349365220}
!14 = !{i64 4083283182001424287}
!15 = !{i64 -4062967328538061970}
!16 = !{i64 -1327391760903788161}
!17 = !{i64 -2322652448786874826}
!18 = !{i64 -4838680829097964254}
!19 = !{i64 8748072831422009710}
!20 = !{i64 -394716845731422163}
!21 = !{i64 5860233702239236606}
!22 = !{i64 -1706283914921929248}
!23 = !{i64 -1919080410807874535}
!24 = !{i64 -5342767181040323658}
!25 = !{i64 2810231716987079085}
!26 = !{i64 -5576911569559703568}
!27 = !{i64 -5084944626957126024}
!28 = !{i64 8432251674807018542}
!29 = !{i64 -5015202342061297618}
!30 = !{i64 -3736185618982898489}
!31 = !{i64 -591374575685052496}
!32 = !{i64 2274743695451314643}
!33 = !{i64 2713003658734069984}
!34 = !{i64 -933426428638480216}
!35 = !{i64 -993002039829721306}
!36 = !{i64 -2253468430328128876}
!37 = !{i64 -4749255079172459068}
!38 = !{i64 3916990760109670961}
!39 = !{i64 2212773127649101446}
!40 = !{i64 5584065934491396975}
!41 = !{i64 -5652344135089000817}
!42 = !{i64 7546446789667000340}
!43 = !{i64 -2403905300768536192}
!44 = !{i64 1459235934954971812}
!45 = !{i64 -6259550584333079343}
!46 = !{i64 -4422371029170761166}
!47 = !{i64 1264033222216718950}
!48 = !{i64 -2316072043815828829}
!49 = !{i64 2809876578690872797}
!50 = !{i64 -2007066530285873498}
!51 = !{i64 2110669748611395879}
!52 = !{i64 7684272467252302654}
!53 = !{i64 -2509343417881901214}
!54 = !{i64 6362243088833346135}
!55 = !{i64 685139831437057870}
!56 = !{i64 -9169540017538518525}
!57 = !{i64 7687126665386690817}
!58 = !{i64 5465731067827784582}
!59 = !{i64 5226550232935421787}
!60 = !{i64 -3573453626406352736}
!61 = !{i64 6236763125154844428}
!62 = !{i64 4878287299760613004}
!63 = !{i64 -9090268440299029750}
!64 = !{i64 5055785646024959096}
!65 = !{i64 -8167673237437823278}
!66 = !{i64 -417323235462969742}
!67 = !{i64 -8831549745758893673}
!68 = !{i64 -4636886171941314550}
!69 = !{i64 3365682401694020541}
!70 = !{i64 -6330986621482673074}
!71 = !{i64 -5477038826078292041}
!72 = !{i64 -5768420342474646396}
!73 = !{i64 -2843092315605587914}
!74 = !{i64 5564031368922769522}
!75 = !{i64 -8322075139909967582}
!76 = !{i64 810783506982441343}
!77 = !{i64 -7271846813879244122}
!78 = !{i64 8264151614003634940}
!79 = !{i64 -2015871537063754090}
!80 = !{i64 2812018196730803312}
!81 = !{i64 70316315501755419}
!82 = !{i64 -7958341364384573189}
!83 = !{i64 -7661187796921093690}
!84 = !{i64 -7432457458805487851}
!85 = !{i64 3469137719956417455}
!86 = !{i64 -2608697416400289564}
!87 = !{i64 -422151868751099621}
!88 = !{i64 -9149531698515560116}
!89 = !{i64 7604957892239391154}
!90 = !{i64 -1496805529200637041}
!91 = !{i64 -2993706336261190945}
!92 = !{i64 -6243981903883764066}
!93 = !{i64 2667922226972356048}
!94 = !{i64 7663320161623032881}
!95 = !{i64 -4724409519477519290}
!96 = !{i64 -7804072751718835000}
!97 = !{i64 8701797371428378983}
!98 = !{i64 9172727812234265901}
!99 = !{i64 1364871080634975753}
!100 = !{i64 1971152453905596512}
!101 = !{i64 -4499957541911900748}
!102 = !{i64 -6741074459445808119}
!103 = !{i64 -2701133806002375051}
!104 = !{i64 2312593604528797818}
!105 = !{i64 5192922204800598223}
!106 = !{i64 -8127230611621693312}
!107 = !{i64 -221485521005250313}
!108 = !{i64 9051896480083306389}
!109 = !{i64 4553364466018817663}
!110 = !{i64 -6615441714317021565}
!111 = !{i64 -4068986400584350032}
!112 = !{i64 -1340010998737269433}
!113 = !{i64 -4239534246509348885}
!114 = !{i64 3792928596688110230}
!115 = !{i64 -5229945751950126371}
!116 = !{i64 -8703159629425390022}
!117 = !{i64 2720229701271388197}
!118 = !{i64 1469644649419597585}
!119 = !{i64 4697973234943270572}
!120 = !{i64 -4779242698007139297}
!121 = !{i64 -1589497205791364753}
!122 = !{i64 -6689813875729583344}
!123 = !{i64 5194227983755596663}
!124 = !{i64 -9137546081407560042}
!125 = !{i64 8396411914061181048}
!126 = !{i32 8, !"PIC Level", i32 2}
!127 = !{i32 7, !"PIE Level", i32 2}
!128 = !{i32 2, !"RtLibUseGOT", i32 1}
!129 = !{i32 7, !"uwtable", i32 2}
!130 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!131 = !{i64 -7730169170113807518}
!132 = !{i64 4801773377623911443}
!133 = !{i64 -3084057772664859311}
!134 = !{i64 4423291852911773492}
!135 = !{i64 4812730341191421490}
!136 = !{i64 -3456547733269109132}
!137 = !{i64 3955936623030078916}
!138 = !{i64 5127539084423874984}
!139 = !{i64 -2173857770303920882}
!140 = !{i64 6640127383132664624}
!141 = !{i64 825628855711899765}
!142 = !{i64 7634682321164322343}
!143 = !{i64 3279195104393158995}
!144 = !{i64 4965092395898331155}
!145 = !{i64 -3394186359278290459}
!146 = !{i64 -7095109920396302965}
!147 = !{i64 -5306170814776717210}
!148 = !{i64 -1812027324443981478}
!149 = !{i64 -4799073400923115407}
!150 = !{i64 -767328904370094174}
!151 = !{i64 -6553038961771511748}
!152 = !{i64 -1148137315368194944}
!153 = !{i64 1595161473091634196}
!154 = !{i64 -4922250615273797892}
!155 = !{i64 3289266059780218518}
!156 = !{i64 3265365179304154272}
!157 = !{i64 -4450288843018741059}
!158 = !{i64 -3364047263468522662}
!159 = !{i64 5096548919705908885}
!160 = !{i64 -8410544145506781689}
!161 = !{i64 -4487492937818276814}
!162 = !{i64 464683584300181625}
!163 = !{i64 -6394578666689644948}
!164 = !{i64 7562691192130722259}
!165 = !{i64 -6966609168285582486}
!166 = !{i64 -4145980064176402162}
!167 = !{i64 -818728121483233930}
!168 = !{i64 7071151080144140216}
!169 = !{i64 1450701695262534483}
!170 = !{i64 -7166319854198847373}
!171 = !{i64 -5264730924811431050}
!172 = !{i64 -3844401939522224847}
!173 = !{i64 8732745674656246252}
!174 = !{i64 -8679020432971772543}
!175 = !{i64 5080376078290121588}
!176 = !{i64 -662973435292884090}
!177 = !{i64 -5985410076870471539}
!178 = !{i64 257852734924454058}
!179 = !{i64 7081073940686832251}
!180 = !{i64 7560259027171119726}
!181 = !{i64 -7960675684290142051}
!182 = !{i64 -2652884967698434809}
!183 = !{i64 -5743906877883001967}
!184 = !{i64 -8951763092455508267}
!185 = !{i64 -1540499576091198570}
!186 = !{i64 -315156859993632687}
!187 = !{i64 -7732669232036068240}
!188 = !{i64 7187913154399702711}
!189 = !{i64 -1186898816145204135}
!190 = !{i64 -3526449587187175492}
!191 = !{i64 221871208117168169}
!192 = !{i64 -3852821826880946470}
!193 = !{!"address", !"read_provenance"}
!194 = !{i64 -6439246804432274092}
!195 = !{i64 6541663144983838573}
!196 = !{i64 7486304605446475021}
!197 = !{i64 -7650426053692254731}
!198 = !{i64 -832564892682934918}
!199 = !{i64 -2409498454174416746}
!200 = !{i64 1322557869699769}
!201 = !{i64 6230184085501283936}
!202 = !{i64 -2376953033220365188}
!203 = !{i64 -1086443278688916248}
!204 = !{i64 -8842606267070792443}
!205 = !{i64 6558566187724958518}
!206 = !{i64 5292330688561933831}
!207 = !{i64 5413477218692182325}
!208 = !{i64 1301894008191696890}
!209 = !{i64 1330863988141907470}
!210 = !{i64 477064652333358627}
!211 = !{i64 -7662074300782288856}
!212 = !{i64 -5867353235550513658}
!213 = !{i64 6236736549055552611}
!214 = !{i64 -7213939522221857594}
!215 = !{i64 -2536915976663147802}
!216 = !{i64 -6375402089602926770}
!217 = !{i64 8246801733840636385}
!218 = !{i64 5246984667878434375}
!219 = !{i64 8314389239982740574}
!220 = !{i64 -6996803978648768123}
!221 = !{i64 6762144589197226401}
!222 = !{i64 -7195719854626341327}
!223 = !{i64 -3400926305133760373}
!224 = !{i64 -7435420864117409728}
!225 = !{i64 1238574712678743116}
!226 = !{i64 8803381976610488250}
!227 = !{i64 2349609271676813917}
!228 = !{i64 -8871134933723337242}
!229 = !{i64 -3334072701639118389}
!230 = !{i64 -1134547415249667632}
!231 = !{i64 -7696571845780090354}
!232 = !{i64 2707781790208459356}
!233 = !{i64 -8338902333534909114}
!234 = !{i64 4986235244782314003}
!235 = !{i64 -7242133735639084285}
!236 = !{i64 -3128898196221752735}
!237 = !{i64 -6555571386061408515}
!238 = !{i64 7975968765170993525}
!239 = !{i64 -6240426729927907219}
!240 = !{i64 1752205899200826348}
!241 = !{i64 -2687037569576501915}
!242 = !{i64 -7009356407558650712}
!243 = !{i64 -3685172069371319810}
!244 = !{i64 371379894756965080}
!245 = !{i64 1364310252765350598}
!246 = !{i64 -8913836709393353965}
!247 = !{i64 990427290099607911}
!248 = !{i64 -5263664073801454965}
!249 = !{i64 5986336924434883173}
!250 = !{i64 2484308150105148561}
!251 = !{i64 797764276369927644}
!252 = !{i64 -8464688875633795535}
!253 = !{i64 191470236979152730}
!254 = !{i64 3926341877941676848}
!255 = !{i64 3645190187786244671}
!256 = !{i64 3170560301256350052}
!257 = !{i64 -7644064545471063616}
!258 = !{i64 -7853615714174881282}
!259 = !{i64 -8337375783872269582}
!260 = !{i64 2722768004807545059}
!261 = !{i64 -4418041461952439668}
!262 = !{i64 5797987867548889619}
!263 = !{i64 695442620630347102}
!264 = !{i64 -8105346992901517440}
!265 = !{i64 5494062067620683019}
!266 = !{i64 -6834709353985492172}
!267 = !{i64 3254192204357885165}
!268 = !{i64 4324828925958322938}
!269 = !{i64 -3224256396494800153}
!270 = !{i64 -5820873047505826506}
!271 = !{i64 -2185936138930546205}
!272 = !{i64 -2692732511740214205}
!273 = !{i64 -7625029099653999965}
!274 = !{i64 -8482012798901484780}
!275 = !{i64 -6455905660702199624}
!276 = !{i64 1066412412765451519}
!277 = !{i64 537313514421811245}
!278 = !{i64 -713585283019284170}
!279 = !{i64 4103375384971173425}
!280 = !{i64 -5627049812867352570}
!281 = !{i64 -4921179134784332863}
!282 = !{i64 3144613751409653026}
!283 = !{i64 2505181270894108841}
!284 = !{i64 -5018378294337499840}
!285 = !{i64 8488294934962476744}
!286 = !{i64 -6635573420272552104}
!287 = !{i64 1924739989191668214}
!288 = !{i64 6349027377615832605}
!289 = !{i64 2509860846348573036}
!290 = !{i64 -2576518871454296016}
!291 = !{i64 -4365886425834899262}
!292 = !{i64 -5744137141146045813}
!293 = !{i64 -7331425361636407905}
!294 = !{i64 -2394632239132369058}
!295 = !{i64 -1781266654528198286}
!296 = !{i64 -3849889344285125321}
!297 = !{i64 -1600695934044983192}
!298 = !{i64 -2151273209879174478}
!299 = !{i64 7028240067064492985}
!300 = !{i64 -7048148330399132107}
!301 = !{i64 -6926030287728340085}
!302 = !{i64 -5053005885609600643}
!303 = !{i64 2249967233579379895}
!304 = !{i64 -7624782965545758321}
!305 = !{i64 294438840701367248}
!306 = !{i64 -8534950642212519539}
!307 = !{i64 8495085923839668865}
!308 = !{i64 -2339793471312789452}
!309 = !{i64 -7523891483424241462}
!310 = !{i64 -8647546223719475220}
!311 = !{i64 7342668281675412474}
!312 = !{i64 -6933176604651149124}
!313 = !{i64 -4043267851280955612}
!314 = !{i64 4586966925732624456}
!315 = !{i64 -5297396064226158042}
!316 = !{i64 -727606346335518771}
!317 = !{i64 -1653864503875113882}
!318 = !{i64 2120004570629443033}
!319 = !{i64 -4269997668479433630}
!320 = !{i64 -6040316333804617375}
!321 = !{i64 2569217573342778815}
!322 = !{i64 -2624081020897602054}
