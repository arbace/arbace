; ModuleID = 'fmt.d0c4af9fcf594538-cgu.0'
source_filename = "fmt.d0c4af9fcf594538-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }
%"core::option::Option<i32>" = type { i32, [1 x i32] }

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAlj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !4
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionlENtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !5
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !6
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !7
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !8
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshVgFdEre0pE_3fmt, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshVgFdEre0pE_3fmt, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshVgFdEre0pE_3fmt }>, align 8, !guid !9
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !10
@alloc_2fc439fdc88563e15d315d43214d38e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\D6\02\00\00\09\00\00\00" }>, align 8, !guid !11
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !12
@alloc_d5d54240cab534dcfdfc9e1f15f834f2 = private unnamed_addr constant [19 x i8] c"alloc/src/slice.rs\00", align 1, !guid !13
@alloc_50f7a04d493c3c635bb162890af45f79 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d5d54240cab534dcfdfc9e1f15f834f2, [16 x i8] c"\12\00\00\00\00\00\00\00\C6\01\00\00$\00\00\00" }>, align 8, !guid !14
@alloc_16d8701a704195662253a9809cf298d1 = private unnamed_addr constant [25 x i8] c"alloc/src/raw_vec/mod.rs\00", align 1, !guid !15
@alloc_c53d1dc14d9dfd00f89649d83c62a8b7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\003\02\00\00X\00\00\00" }>, align 8, !guid !16
@alloc_84e24ad25dfa3f90d9808e22947b437c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\85\03\00\00G\00\00\00" }>, align 8, !guid !17
@alloc_058ed9c984ace2f2df2878d2b6a7ab17 = private unnamed_addr constant [86 x i8] c"\01[\C3 \00\00h\05\00\03] [\C3 \00\00\08\05\00\03] [\C3 \00\00H\05\00\03] [\C3 \00\00(\05\00\03] [\C3 \00\00i\05\00\03] [\C1 \00 `\03] [\C1 \00\80`\03] [\C3 \00\80i\0A\00\02]\0A\00", align 1, !guid !18
@alloc_16cc22b75c9c3452d6258d4ae7173928 = private unnamed_addr constant [3 x i8] c"mid", align 1, !guid !19
@alloc_a06b157fbc4fea4c9656215c4f90058c = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_16cc22b75c9c3452d6258d4ae7173928, [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8, !guid !20
@alloc_c7ca2384edadb766999f3f810e9a1faa = private unnamed_addr constant [1 x i8] c"r", align 1, !guid !21
@alloc_116173a2102397b8b6fd81096c83cfc9 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_c7ca2384edadb766999f3f810e9a1faa, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !22
@alloc_fc67a14388b97431c7788bc1ec3532d5 = private unnamed_addr constant [1 x i8] c"l", align 1, !guid !23
@alloc_3bff007dbe99da6ff02a2194c6277311 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_fc67a14388b97431c7788bc1ec3532d5, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !24
@alloc_7e4bbc79e2378daf3eeafb7b7df22ee0 = private unnamed_addr constant [35 x i8] c"\01[\C3*\00\00H\09\00\03] [\C3-\00\00(\07\00\03] [\C3_\00\00\08\06\00\02]\0A\00", align 1, !guid !25
@alloc_8c4e06e927edde26594c713b91192e5a = private unnamed_addr constant [8 x i8] c"\F1\D4\C8S\FB!\09@", align 8, !guid !26
@alloc_f85406d658e94b9c37cd2112f10307ee = private unnamed_addr constant [8 x i8] c"\02\00\00\00\00\00\00\00", align 8, !guid !27
@alloc_cdde77e819f554b9b7f533765281c183 = private unnamed_addr constant [8 x i8] c"\90\F7\AA\95\09\BF\05@", align 8, !guid !28
@alloc_600bea9355adff585e97c5fff9ed0f73 = private unnamed_addr constant [27 x i8] c"test/rust/synthetic/fmt.rs\00", align 1, !guid !29
@alloc_7a793d85dca71c7dc1dea8251d3c81a6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\15\00\00\00\05\00\00\00" }>, align 8, !guid !30
@alloc_33b2945736ef38a27c6e677ffcd45b44 = private unnamed_addr constant [41 x i8] c"\01[\D3 \00\00h\01\00\03] [\FF \00\008\01\00\03\00\02\00\03] [\ED \00\00p\05\00\04\00\02]\0A\00", align 1, !guid !31
@alloc_1ee9e55db95863be6ebd980ddbf9d982 = private unnamed_addr constant [2 x i8] c"nm", align 1, !guid !32
@alloc_9f8d7ceb5d76cacbca201a50ff8c4371 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_1ee9e55db95863be6ebd980ddbf9d982, [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8, !guid !33
@alloc_95ee1cd2eaa09486cb2b0fd227d38feb = private unnamed_addr constant [14 x i8] c"\09a b a nm \C0\01\0A\00", align 1, !guid !34
@alloc_84452d4c362ef91ce628cf4a12e63db7 = private unnamed_addr constant [3 x i8] c"cap", align 1, !guid !35
@alloc_96f2619f19364aea06eebc9b5a1fb7d7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\18\00\00\00\05\00\00\00" }>, align 8, !guid !36
@alloc_9f628f80319a062de0e97a0dc03419f7 = private unnamed_addr constant [34 x i8] c"\D3 \00\00(\01\00\01|\C8\02\00\01|\C3 \00\80i\06\00\0B|{literal}\0A\00", align 1, !guid !37
@alloc_b120f3228a2aa0acd63c1931e0ccccd5 = private unnamed_addr constant [4 x i8] c"q\00\00\00", align 4, !guid !38
@alloc_3e7031f3d0c6d290661936e0852caa58 = private unnamed_addr constant [2 x i8] c"s\0A", align 1, !guid !39
@alloc_adbc948e1297c274cac6e15d4baf9312 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_3e7031f3d0c6d290661936e0852caa58, [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8, !guid !40
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !41
@alloc_938b60fd0bf7f9b98ca251eb559dc6f5 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\F8?", align 8, !guid !42
@alloc_9d4d590161390a2420b41fde992773bb = private unnamed_addr constant <{ [1 x i8], [1 x i8] }> <{ [1 x i8] zeroinitializer, [1 x i8] undef }>, align 1, !guid !43
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !44
@alloc_070ca2e2ae6721b8fbf222c3a28fff78 = private unnamed_addr constant [1 x i8] c"t", align 1, !guid !45
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !46
@alloc_c3b1946345a8630bc4d2f804c02f8ade = private unnamed_addr constant [8 x i8] c"\C1 \00\80`\01\0A\00", align 1, !guid !47
@alloc_f9894cef7d80ce1597e4af1bee2cc81d = private unnamed_addr constant <{ [1 x i8], [31 x i8] }> <{ [1 x i8] zeroinitializer, [31 x i8] undef }>, align 8, !guid !48
@alloc_37f62a15fae368a2423b3a16c75adcc9 = private unnamed_addr constant [1 x i8] c"x", align 1, !guid !49
@alloc_ad5ee50880169519f12eb2aee1c80306 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\1E\00\00\002\00\00\00" }>, align 8, !guid !50
@alloc_9c7fb62c24638c4cee5ee34bf542b723 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\1F\00\00\00#\00\00\00" }>, align 8, !guid !51
@alloc_babee5271e6e42dc125a96e0272fa27d = private unnamed_addr constant [3 x i8] c"two", align 1, !guid !52
@alloc_b0c6f7e20c8b1e174b89edc6baca02fc = private unnamed_addr constant <{ ptr, [12 x i8], [4 x i8], [16 x i8] }> <{ ptr @alloc_babee5271e6e42dc125a96e0272fa27d, [12 x i8] c"\03\00\00\00\00\00\00\00\01\00\00\00", [4 x i8] undef, [16 x i8] c"\00\00\00\00\00\00\08@\00\00\00\00\00\00\12@" }>, align 8, !guid !53
@alloc_0db41ab121065f14f332cc5e3cf612a8 = private unnamed_addr constant [8 x i8] c"90\00\00\00\00\00\00", align 8, !guid !54
@alloc_33e8ada5b6178afcb200a31f257552b1 = private unnamed_addr constant [8 x i8] c"\05\00\00\00\00\00\00\00", align 8, !guid !55
@alloc_eabeddbc27aba20163f110a6ba7d77e7 = private unnamed_addr constant [8 x i8] c"\9F\86\01\00\00\00\00\00", align 8, !guid !56
@alloc_79674baf410e37291a6607f958b7b1fe = private unnamed_addr constant [8 x i8] c"d\00\00\00\00\00\00\00", align 8, !guid !57
@alloc_80c3197a743f5124a0a564937a745665 = private unnamed_addr constant [40 x i8] c"\01[\C0\03] [\C3 \00\00(\0A\00\03] [\C3 \00\00\08\0A\00\03] [\C3 \00\00H\0A\00\02]\0A\00", align 1, !guid !58
@alloc_201c3ee118050b09cec852f4540cef71 = private unnamed_addr constant [4 x i8] c"\FF\00\00\00", align 4, !guid !59
@alloc_2496decc21825f3f9b238b54f8d5e33f = private unnamed_addr constant [20 x i8] c"\C0\01 \C1 \00\80`\01 \C3 \00\00i\08\00\01\0A\00", align 1, !guid !60
@alloc_e0f292073631866f6c61fe5668d1ab0c = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00J\93@", align 8, !guid !61
@alloc_18e849d5c0b47b9a1071d700260ded41 = private unnamed_addr constant [8 x i8] c"i\1DUM\10u\1F?", align 8, !guid !62
@alloc_cdbdeba67b052fefbde5996b437aa24e = private unnamed_addr constant [4 x i8] c"\05\00\00\00", align 4, !guid !63
@alloc_f93507f8ba4b5780b14b2c2584609be0 = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00\00\F0?", align 8, !guid !64
@alloc_91984e5afffc475237697b8bd6a3e206 = private unnamed_addr constant [4 x i8] c"\9A\99\99>", align 4, !guid !65
@alloc_ddd207f36435cdb5a6b231356b1990e9 = private unnamed_addr constant [8 x i8] c"P\EF\E2\D6\E4\1AKD", align 8, !guid !66
@alloc_86fe2e14e8aee3cbc4747be45abbb75c = private unnamed_addr constant [8 x i8] c"\FF\FF\FF\FF\FF\FF\EF\7F", align 8, !guid !67
@alloc_3fd4ac1bd4aabc745420009965a8d1ac = private unnamed_addr constant [4 x i8] c"\00\00\80\00", align 4, !guid !68
@alloc_4e3160e3e5d83eeb2e7a3db504240512 = private unnamed_addr constant [8 x i8] c"\BB\BD\D7\D9\DF|\DB=", align 8, !guid !69
@alloc_8821998f047ca62cad40e6bc4e4d87c4 = private unnamed_addr constant [1 x i8] c"\01", align 1, !guid !70
@alloc_5b64c5758b3793302fbedcd0481de01a = private unnamed_addr constant [4 x i8] c"c\00\00\00", align 4, !guid !71
@alloc_0ae0accb60b700fe8d2e90793be18e2c = private unnamed_addr constant [2 x i8] c"ab", align 1, !guid !72
@alloc_c05f8b186ecd5789d56bb5d9e682c6d7 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_0ae0accb60b700fe8d2e90793be18e2c, [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8, !guid !73
@alloc_50ab75e5eb17b3d68555764b0a52038b = private unnamed_addr constant [1 x i8] c"z", align 1, !guid !74
@alloc_2baa0b6208900c4f9b90e2cbbfb2ca47 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_50ab75e5eb17b3d68555764b0a52038b, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !75
@alloc_12541e1a1260b3fd7e4655df6b8014be = private unnamed_addr constant [37 x i8] c"\C3 \00\00h\05\00\01|\C3 \00\00\08\05\00\01|\C3 \00\00H\05\00\01|\C3 \00\00(\05\00\01\0A\00", align 1, !guid !76
@alloc_f19792d8e6fca51f99519584a77b3470 = private unnamed_addr constant <{ [12 x i8], [4 x i8] }> <{ [12 x i8] c"\01\00\00\00\01\00\00\00\00\00\00\00", [4 x i8] undef }>, align 4, !guid !77
@alloc_68d244bd4070015bf9253d1ac51d25f8 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\02\00\00\00\03\00\00\00\04\00\00\00", align 4, !guid !78
@alloc_fc18870ebd3bffa18e161a5a63775070 = private unnamed_addr constant [4 x i8] c"\07\00\00\00", align 4, !guid !79
@alloc_a0256699fdc8ea22b569d2c1ec13c81f = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00\00#@", align 8, !guid !80
@alloc_352fcb003cd53a19ca29091d17651ce3 = private unnamed_addr constant [30 x i8] c"\C3 \00\00i\02\00\01:\C3 \00\00i\02\00\01:\C7 \00\00y\06\00\03\00\01\0A\00", align 1, !guid !81
@alloc_cbaed04ca755d7df81f067609aba73ed = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00$\FE@", align 8, !guid !82
@alloc_4b42cd106c262d3d9a145d6f4764eeaf = private unnamed_addr constant [8 x i8] c"\01\00\00\00\01\00\00\00", align 4, !guid !83
@alloc_5a1a9e6358d5f90dcb98724ce1d54ed0 = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00\00\02@", align 8, !guid !84
@alloc_5d68c547652bb8e5dddfa04dc983f46a = private unnamed_addr constant [32 x i8] c"\C7 \00\00x\0A\00\03\00\01|\C3 \00\00\08\0C\00\01|\C7 \00 8\08\00\01\00\01\0A\00", align 1, !guid !85
@alloc_214cd245ef08d32d3c495a75f259c468 = private unnamed_addr constant [4 x i8] c"1 2\0A", align 1, !guid !86
@alloc_0fa510a23a05a548dfd86788ed688330 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8, !guid !87
@alloc_f1045206bd356f04ecf6c5daa5616281 = private unnamed_addr constant [5 x i8] c"\021-\C0\00", align 1, !guid !88
@alloc_ea556a6fc27bebb9c43699dd3a5fa3f3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00-\00\00\00\22\00\00\00" }>, align 8, !guid !89
@alloc_aa8949e1fb3783c4ba3f17396bbaa3bf = private unnamed_addr constant [2 x i8] c"!\0A", align 1, !guid !90
@alloc_a7aedc039a5bce5f90b5974852c9f0c9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00-\00\00\00=\00\00\00" }>, align 8, !guid !91
@alloc_0c812808379efded5a4fb82d2790b556 = private unnamed_addr constant [2 x i8] c"\C0\00", align 1, !guid !92
@alloc_9beb045410d021e66c87fb3fce4c6912 = private unnamed_addr constant [12 x i8] c"to stderr 1\0A", align 1, !guid !93
@alloc_b7cbb96fa2fbc2c33cfdce3b367921a6 = private unnamed_addr constant [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\80", align 16, !guid !94
@alloc_d0776666182ad032bd1011cf266e2f3a = private unnamed_addr constant [16 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF", align 16, !guid !95
@alloc_2aed27a01081c9f91b0f84d085de36d9 = private unnamed_addr constant [4 x i8] c"\F4\FF\FF\FF", align 4, !guid !96
@alloc_c424b10c3bbe424e4bad8e7fe84cacd4 = private unnamed_addr constant [29 x i8] c"\C3 \00\00(\06\00\01|\C3 \00\00\08\06\00\01|\C3 \00\00H\06\00\02|\0A\00", align 1, !guid !97
@alloc_53973d2fe29b4adba8bb7390b5678745 = private unnamed_addr constant [8 x i8] zeroinitializer, align 8, !guid !98
@alloc_783ee260e8ae01216c1a7e8d97dd7885 = private unnamed_addr constant [8 x i8] c"\00\00\00\00\00\00\F0C", align 8, !guid !99
@alloc_b03741e4fa93f143426998f2aacbbd7f = private unnamed_addr constant [2 x i8] c"\C3\A9", align 1, !guid !100
@alloc_9b2bf7077a3c4b95a732f8a187d9d5ed = private unnamed_addr constant [4 x i8] c"\E9\00\00\00", align 4, !guid !101
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !102
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !103
@alloc_00ae4b301f7fab8ac9617c03fcbd7274 = private unnamed_addr constant [43 x i8] c"called `Result::unwrap()` on an `Err` value", align 1, !guid !104
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsK_NtCsl10jNU3mE6R_4core3fmtNtB5_5ErrorNtB5_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !105
@alloc_bed8969a4b39b5529597d14a2d5628f2 = private unnamed_addr constant [32 x i8] c"Formatting argument out of range", align 1, !guid !106
@alloc_988c380202cc7b7a37ca3d8d5930c44f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\AD\00\00\00\1B\00\00\00" }>, align 8, !guid !107
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !108
@alloc_fad0cd83b7d1858a846a172eb260e593 = private unnamed_addr constant [42 x i8] c"is_aligned_to: align is not a power-of-two", align 1, !guid !109
@alloc_3a97cab01964e354cab63e4d72a95bbc = private unnamed_addr constant [26 x i8] c"core/src/ptr/const_ptr.rs\00", align 1, !guid !110
@alloc_7abc4ceda2d1d9be88f00c5dc522bc84 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3a97cab01964e354cab63e4d72a95bbc, [16 x i8] c"\19\00\00\00\00\00\00\00M\05\00\00\0D\00\00\00" }>, align 8, !guid !111
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !112
@alloc_6379aaa2812385052216e7dc8e3279fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00m\01\00\00\1F\00\00\00" }>, align 8, !guid !113
@alloc_9e1ff22d96cae328e0e878f28b86a5f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00]\01\00\00\11\00\00\00" }>, align 8, !guid !114
@alloc_dc3b17f8cb85ad2cd97bd426be5b5da4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00b\01\00\00\1D\00\00\00" }>, align 8, !guid !115
@alloc_4a0c97dbbf49263ee47df53bd3d86fcc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00b\01\00\00+\00\00\00" }>, align 8, !guid !116
@alloc_a699fef46c42b266f9e12652c07a696a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00`\01\00\00\1B\00\00\00" }>, align 8, !guid !117
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !118
@alloc_3d5b7f261101b120d30419294a27cc6f = private unnamed_addr constant [23 x i8] c"core/src/ptr/unique.rs\00", align 1, !guid !119
@alloc_8e8e5d43991787ef9fba0c8fe53b59fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3d5b7f261101b120d30419294a27cc6f, [16 x i8] c"\16\00\00\00\00\00\00\00X\00\00\00$\00\00\00" }>, align 8, !guid !120
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !121
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !122
@alloc_e469ef44bf39c45bcb672a4bc963b9cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\1A\01\00\00\1B\00\00\00" }>, align 8, !guid !123
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !124
@alloc_5bb642ca6df5ad9ba078972a9d3a5201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !125
@alloc_85bcb8feb56634093aba2b8644936af9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\7F\02\00\005\00\00\00" }>, align 8, !guid !126
@alloc_17de00c3327446355700bd7db4b78ded = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\80\02\00\00\1E\00\00\00" }>, align 8, !guid !127
@alloc_b9419d44288097f84422e162822ba96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\81\02\00\00 \00\00\00" }>, align 8, !guid !128
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !129
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !130
@alloc_af3623564924928dd3d563c9d84a8a0e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00s\05\00\00\12\00\00\00" }>, align 8, !guid !131
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !132
@alloc_02ed5979549ad728dcb1e213f787b0ae = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00,\02\00\00\11\00\00\00" }>, align 8, !guid !133
@alloc_9c2bc03755f157121052fe1398e358d1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00%\02\00\00\1A\00\00\00" }>, align 8, !guid !134
@alloc_8b924c2e6c70ef47ed23cadbb79c2da4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\11\02\00\00\1C\00\00\00" }>, align 8, !guid !135
@alloc_91dabd4c1d2514ecf79277c06422ef65 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\07\02\00\00\1C\00\00\00" }>, align 8, !guid !136
@alloc_289c68237f406b28ee6ba245eefcd312 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\03\02\00\00)\00\00\00" }>, align 8, !guid !137
@alloc_33dfd402c6ecbe2e6a32e76edf5f31a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\D8\01\00\00L\00\00\00" }>, align 8, !guid !138
@alloc_099d793709fa470a3d5e7c79c938e035 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\C9\01\00\003\00\00\00" }>, align 8, !guid !139
@alloc_51424262946dd0794fad6132df857999 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\B7\01\00\00\15\00\00\00" }>, align 8, !guid !140
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !141
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !142
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !143
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !144
@alloc_5ea8f0c52284eef1a8a88866fb554c40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\0B\00\00O\00\00\00" }>, align 8, !guid !145
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !146
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !147
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !148
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !149
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !150
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !151
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !152
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !153
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !154
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !155
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !156
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !157
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !158
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !159
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !160
@alloc_db07ae5a9ce650d9b7cc970d048e6f0c = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !161
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !162
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !163
@alloc_dd79dfae92e8fdc23813c4c7a1b7cf72 = private unnamed_addr constant [228 x i8] c"unsafe precondition(s) violated: ptr::write_bytes requires that the destination pointer is aligned and non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !164
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !165
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !166
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !167
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !168
@alloc_78648a3da0583c3a93ec45d48e44c913 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\0B\00\00\00&\00\00\00" }>, align 8, !guid !169
@alloc_2a7a4456520952dbf8a616376b1f7793 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_600bea9355adff585e97c5fff9ed0f73, [16 x i8] c"\1A\00\00\00\00\00\00\00\0B\00\00\004\00\00\00" }>, align 8, !guid !170
@alloc_6ddf87a275032c244ec296015b313b7a = private unnamed_addr constant [13 x i8] c"\01$\C0\01.\C3 \00\00i\02\00\00", align 1, !guid !171
@alloc_bf0ef947d182249ea2203578272460c5 = private unnamed_addr constant [5 x i8] c"Point", align 1, !guid !172
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !173
@alloc_cd51bc84b49b21a3fdb2800731f25c21 = private unnamed_addr constant [1 x i8] c"y", align 1, !guid !174
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @_RNvXs2_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_5Debug3fmt }>, align 8, !guid !175
@alloc_125af81ac88d8b2d4254bab0c6fa4f63 = private unnamed_addr constant [3 x i8] c"tag", align 1, !guid !176
@vtable.9 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionReENtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !177
@vtable.a = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !178
@vtable.b = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAdj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !179
@vtable.c = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !180
@vtable.d = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !181
@alloc_13c56e54a9571211dcad2a135c9eaa2b = private unnamed_addr constant [4 x i8] c"Unit", align 1, !guid !182
@alloc_8388317ddce58f972b519ce81ee4ed85 = private unnamed_addr constant [3 x i8] c"Tup", align 1, !guid !183
@vtable.e = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !184
@vtable.f = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !185
@alloc_3b31bdf1fe846135477a792935103ed1 = private unnamed_addr constant [3 x i8] c"Rec", align 1, !guid !186
@alloc_3827bbb606bbdb0f0c926011c14ccc34 = private unnamed_addr constant [1 x i8] c"a", align 1, !guid !187
@vtable.g = private unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECshVgFdEre0pE_3fmt, [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !188
@alloc_ab7766fee1e1b94f8c00ce7ffec41c7e = private unnamed_addr constant [1 x i8] c"b", align 1, !guid !189
@vtable.h = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRTabENtB6_5Debug3fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !190
@alloc_99ac8a81a24cac863217ce4a5cbfabea = private unnamed_addr constant [5 x i8] c"Error", align 1, !guid !191
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !192
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !193
@vtable.i = private unnamed_addr constant <{ ptr, [16 x i8], ptr, ptr, ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt, [16 x i8] c"\18\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_strCshVgFdEre0pE_3fmt, ptr @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write10write_charCshVgFdEre0pE_3fmt, ptr @_RNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtCshVgFdEre0pE_3fmt }>, align 8, !guid !194
@alloc_0d0353b85363a9d264096e7bdbfe6900 = private unnamed_addr constant [22 x i8] c"core/src/array/mod.rs\00", align 1, !guid !195
@alloc_bb689cb4c05c0bf38d31dd7cd71b8150 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d0353b85363a9d264096e7bdbfe6900, [16 x i8] c"\15\00\00\00\00\00\00\00e\01\00\00\1F\00\00\00" }>, align 8, !guid !196
@alloc_ae6dc619079e3c3b08144a35532ecff7 = private unnamed_addr constant [2 x i8] c"()", align 1, !guid !197

; <[u8]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh8into_vecNtNtB5_5alloc6GlobalECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !203 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[u8]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxShE23into_raw_with_allocatorCshVgFdEre0pE_3fmt(ptr %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<u8>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE17from_raw_parts_inCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[u8]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxShEECshVgFdEre0pE_3fmt(ptr align 8 %self) #20
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable
}

; <[u8]>::to_vec_in::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !204 {
start:
; call <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
  call void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #22
  ret void
}

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECshVgFdEre0pE_3fmt(ptr %0) unnamed_addr #0 !guid !205 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_6, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %7 = load ptr, ptr %_0, align 8
  ret ptr %7

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1, ptr align 8 %default) unnamed_addr #0 personality ptr @rust_eh_personality !guid !206 {
start:
  %_10 = alloca [1 x i8], align 1
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_10, align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_10, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_4 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_4 to i1
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %t.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %9, align 8
  store i8 0, ptr %_9, align 1
; call <<str as alloc::borrow::ToOwned>::to_owned as core::ops::function::FnOnce<(&str,)>>::call_once
  call void @_RNvYNvYeNtNtCs7CppTae75M1_5alloc6borrow7ToOwned8to_ownedINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTReEE9call_onceCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %t.0, i64 %t.1) #22
  br label %bb15

bb2:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call alloc::fmt::format::{closure#0}
  call void @_RNCNvNtCs7CppTae75M1_5alloc3fmt6format0CshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %default) #22
  br label %bb14

bb14:                                             ; preds = %bb2
  br label %bb9

bb9:                                              ; preds = %bb15, %bb14
  %10 = load i8, ptr %_9, align 1
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %bb8, label %bb4

bb15:                                             ; preds = %bb3
  br label %bb9

bb4:                                              ; preds = %bb8, %bb9
  %12 = load i8, ptr %_10, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb10, label %bb5

bb8:                                              ; preds = %bb9
  br label %bb4

bb5:                                              ; preds = %bb10, %bb4
  ret void

bb10:                                             ; preds = %bb4
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable
}

; <core::option::Option<usize>>::ok_or::<alloc::collections::TryReserveErrorKind>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE5ok_orNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, i64 %0, i64 %1, i64 %err.0, i64 %err.1) unnamed_addr #0 !guid !207 {
start:
  %_6 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %7, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store i64 %err.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %err.1, ptr %8, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %9 = load i8, ptr %_6, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError>>::map_err::<alloc::collections::TryReserveError, <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtNtB5_3ptr8non_null7NonNullShENtNtB5_5alloc10AllocErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvMs5_NtB1S_7raw_vecNtB2O_11RawVecInner11finish_grow0ECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1, ptr align 8 %op) unnamed_addr #0 !guid !208 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_3 = select i1 %7, i64 1, i64 0
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}
  %9 = call { i64, i64 } @_RNCNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB7_11RawVecInner11finish_grow0CshVgFdEre0pE_3fmt(ptr align 8 %op) #22
  %_6.0 = extractvalue { i64, i64 } %9, 0
  %_6.1 = extractvalue { i64, i64 } %9, 1
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 %_6.1, ptr %11, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load ptr, ptr %self, align 8
  %12 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %t.0, ptr %13, align 8
  %14 = getelementptr inbounds i8, ptr %13, i64 8
  store i64 %t.1, ptr %14, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %15 = load i8, ptr %_9, align 1
  %16 = trunc nuw i8 %15 to i1
  br i1 %16, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, i64 %0, i64 %1) unnamed_addr #0 !guid !209 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load i64, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = icmp eq i64 %3, 0
  %_3 = select i1 %6, i64 1, i64 0
  %7 = trunc nuw i64 %_3 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call alloc::raw_vec::layout_array::{closure#0}
  %8 = call { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0CshVgFdEre0pE_3fmt() #22
  %_6.0 = extractvalue { i64, i64 } %8, 0
  %_6.1 = extractvalue { i64, i64 } %8, 1
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %_6.1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load i64, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %t.0, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 8
  store i64 %t.1, ptr %13, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %14 = load i8, ptr %_9, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_binary::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !210 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<fmt::Money>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !211 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<fmt::Money>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt5MoneyE8from_refBV_(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<fmt::Money>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt5MoneyE4castuEBW_(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXCshVgFdEre0pE_3fmtNtB2_5MoneyNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !212 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !213 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&str>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullReE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<&str>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullReE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtReNtB6_7Display3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !214 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCshVgFdEre0pE_3fmt(ptr %x) #22
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaycECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !215 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<char>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullcE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<char>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullcE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsk_NtCsl10jNU3mE6R_4core3fmtcNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !216 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !217 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !218 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !219 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_pointer::<*const u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_pointerPhECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !220 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<*const u8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullPhE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<*const u8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullPhE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsl_NtCsl10jNU3mE6R_4core3fmtPhNtB5_7Pointer3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_exp::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !221 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs8_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8LowerExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_exp::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expmECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !222 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<u32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsw_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_8LowerExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<fmt::Hex>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexNtCshVgFdEre0pE_3fmt3HexEB12_(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !223 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<fmt::Hex>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt3HexE8from_refBV_(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<fmt::Hex>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt3HexE4castuEBW_(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_CshVgFdEre0pE_3fmtNtB4_3HexNtNtCsl10jNU3mE6R_4core3fmt8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexlECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !224 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_exp::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !225 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs9_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8UpperExp3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<[[i32; 2]; 2]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAAlj2_BY_ECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !226 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<[[i32; 2]; 2]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAAlj2_BW_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<[[i32; 2]; 2]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAAlj2_BX_E4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAAlj2_Bz_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<[core::option::Option<i32>; 2]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAINtNtB7_6option6OptionlEj2_ECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !227 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<[core::option::Option<i32>; 2]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAINtNtB9_6option6OptionlEj2_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<[core::option::Option<i32>; 2]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAINtNtBa_6option6OptionlEj2_E4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAINtNtB7_6option6OptionlEj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<f64>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptiondEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !228 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<f64>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptiondEE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<core::option::Option<f64>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptiondEE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptiondENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !229 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<u8>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionhEE8from_refCshVgFdEre0pE_3fmt(ptr %x) #22
; call <core::ptr::non_null::NonNull<core::option::Option<u8>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionhEE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionhENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !230 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i32>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<core::option::Option<i32>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionlEE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<fmt::E>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt1EEBX_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !231 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<fmt::E>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt1EE8from_refBV_(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<fmt::E>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt1EE4castuEBW_(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_CshVgFdEre0pE_3fmtNtB5_1ENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<fmt::Point>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt5PointEBX_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !232 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<fmt::Point>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt5PointE8from_refBV_(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<fmt::Point>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt5PointE4castuEBW_(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs0_CshVgFdEre0pE_3fmtNtB5_5PointNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::time::Duration>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_4time8DurationECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !233 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::time::Duration>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_4time8DurationE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<core::time::Duration>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_4time8DurationE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core4timeNtB5_8DurationNtNtB7_3fmt5Debug3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !234 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !235 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&str>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullReE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<&str>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullReE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtReNtB6_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(i32, &str, [f64; 2])>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTlReAdj2_EECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !236 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(i32, &str, [f64; 2])>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTlReAdj2_EE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<(i32, &str, [f64; 2])>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTlReAdj2_EE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1F_NtCsl10jNU3mE6R_4core3fmtTlReAdj2_ENtB6_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugcECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !237 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<char>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullcE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<char>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullcE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsj_NtCsl10jNU3mE6R_4core3fmtcNtB5_5Debug3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !238 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !239 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs2_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_5Debug3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugmECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !240 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<u32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsW_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugnECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !241 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCshVgFdEre0pE_3fmt(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugoECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !242 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refCshVgFdEre0pE_3fmt(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuguECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !243 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<()>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulluE8from_refCshVgFdEre0pE_3fmt(ptr %x) #22
; call <core::ptr::non_null::NonNull<()>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulluE4castuECshVgFdEre0pE_3fmt(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXss_NtCsl10jNU3mE6R_4core3fmtuNtB5_5Debug3fmtCshVgFdEre0pE_3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawShECshVgFdEre0pE_3fmt(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !244 {
start:
; call core::mem::align_of_val_raw::<[u8]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawShECshVgFdEre0pE_3fmt(ptr %val.0, i64 %val.1) #22
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCshVgFdEre0pE_3fmt(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #22
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofhECshVgFdEre0pE_3fmt() unnamed_addr #0 !guid !245 {
start:
  ret i64 1
}

; <core::alloc::layout::Layout>::for_value_raw::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawShECshVgFdEre0pE_3fmt(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !246 {
start:
; call core::mem::size_of_val_raw::<[u8]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawShECshVgFdEre0pE_3fmt(ptr %val.0, i64 %val.1) #22
; call <core::mem::alignment::Alignment>::of_val_raw::<[u8]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawShECshVgFdEre0pE_3fmt(ptr %val.0, i64 %val.1) #22
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCshVgFdEre0pE_3fmt(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #22
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<[u8]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueShE4casthECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !247 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) #22
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !248 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECshVgFdEre0pE_3fmt(ptr %self) #22
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[[i32; 2]; 2]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAAlj2_BX_E4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !249 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[core::option::Option<i32>; 2]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAINtNtBa_6option6OptionlEj2_E4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !250 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<f64>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptiondEE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !251 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<u8>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionhEE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !252 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionlEE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !253 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<fmt::E>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt1EE4castuEBW_(ptr %self) unnamed_addr #0 !guid !254 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<fmt::Hex>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt3HexE4castuEBW_(ptr %self) unnamed_addr #0 !guid !255 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<fmt::Money>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt5MoneyE4castuEBW_(ptr %self) unnamed_addr #0 !guid !256 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<fmt::Point>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCshVgFdEre0pE_3fmt5PointE4castuEBW_(ptr %self) unnamed_addr #0 !guid !257 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::time::Duration>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_4time8DurationE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !258 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !259 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<*const u8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullPhE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !260 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&str>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullReE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !261 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[[i32; 2]]>>::cast::<[i32; 2]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAlj2_E4castBV_ECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !262 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[core::option::Option<i32>]>>::cast::<core::option::Option<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSINtNtBa_6option6OptionlEE4castBV_ECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !263 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[f64]>>::cast::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSdE4castdECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !264 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !265 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[i32]>>::cast::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4castlECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !266 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<(i32, &str, [f64; 2])>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTlReAdj2_EE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !267 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !268 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<char>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullcE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !269 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !270 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !271 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !272 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !273 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !274 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !275 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !276 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<()>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulluE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !277 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !278 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !279 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u8>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !280 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECshVgFdEre0pE_3fmt(ptr %_3) #22
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCshVgFdEre0pE_3fmt(ptr %_2) #22
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<20, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !281 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<29, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1d_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !282 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<30, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1e_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !283 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<32, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj20_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !284 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<34, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj22_Kj4_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !285 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<35, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj23_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !286 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<37, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj25_Kj4_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !287 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<40, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj28_Kj4_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !288 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<41, 6>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj29_Kj6_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !289 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<2, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj2_Kj1_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !290 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !291 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<86, 8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj56_Kj8_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !292 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<5, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj5_Kj1_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !293 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !294 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !295 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !296 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj2_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !297 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<14, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECshVgFdEre0pE_3fmt(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !298 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::builders::DebugList>::entries::<&[i32; 2], core::slice::iter::Iter<[i32; 2]>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRAlj2_INtNtNtBa_5slice4iter4IterB14_EECshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !299 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<[i32; 2]> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterAlj2_ENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %entries.0, ptr %entries.1) #22
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<[i32; 2]> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterAlj2_ENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %iter) #22
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !300
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.0)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&core::option::Option<i32>, core::slice::iter::Iter<core::option::Option<i32>>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRINtNtBa_6option6OptionlEINtNtNtBa_5slice4iter4IterB14_EECshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !301 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<core::option::Option<i32>> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterINtNtB8_6option6OptionlEENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %entries.0, ptr %entries.1) #22
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<core::option::Option<i32>> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterINtNtBa_6option6OptionlEENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %iter) #22
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !300
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.1)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&f64, core::slice::iter::Iter<f64>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRdINtNtNtBa_5slice4iter4IterdEECshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !302 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<f64> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterdENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %entries.0, ptr %entries.1) #22
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %iter) #22
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !300
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.2)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&u8, core::slice::iter::Iter<u8>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRhINtNtNtBa_5slice4iter4IterhEECshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !303 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<u8> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterhENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %entries.0, ptr %entries.1) #22
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
  %2 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %iter) #22
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !300
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.3)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !304 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %entries.0, ptr %entries.1) #22
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %iter) #22
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !300
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.4)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; alloc::raw_vec::new_cap::<u8>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_caphECshVgFdEre0pE_3fmt(i64 %cap) unnamed_addr #1 !guid !305 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCshVgFdEre0pE_3fmt(i64 %cap) #22
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshVgFdEre0pE_3fmt(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !306 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.5, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::is_val_statically_known::<bool>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownbECshVgFdEre0pE_3fmt(i1 zeroext %_arg) unnamed_addr #2 !guid !307 {
start:
  ret i1 false
}

; core::cmp::max::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECshVgFdEre0pE_3fmt(i64 %v1, i64 %v2) unnamed_addr #0 !guid !308 {
start:
; call <usize as core::cmp::Ord>::max
  %_0 = call i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxCshVgFdEre0pE_3fmt(i64 %v1, i64 %v2) #22
  ret i64 %_0
}

; core::mem::size_of_val_raw::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawShECshVgFdEre0pE_3fmt(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !309 {
start:
  %_0 = mul nuw nsw i64 %val.1, 1
  ret i64 %_0
}

; core::mem::align_of_val_raw::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawShECshVgFdEre0pE_3fmt(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !310 {
start:
  %0 = mul nuw nsw i64 %val.1, 1
  ret i64 1
}

; core::ptr::slice_from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECshVgFdEre0pE_3fmt(ptr %data, i64 %len) unnamed_addr #0 !guid !311 {
start:
; call core::ptr::metadata::from_raw_parts::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECshVgFdEre0pE_3fmt(ptr %data, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECshVgFdEre0pE_3fmt(ptr %data, i64 %len) unnamed_addr #0 !guid !312 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECshVgFdEre0pE_3fmt(ptr %data, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECshVgFdEre0pE_3fmt(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !313 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshVgFdEre0pE_3fmt(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECshVgFdEre0pE_3fmt(ptr align 8 %_1) #20
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECshVgFdEre0pE_3fmt(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<[u8]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxShEECshVgFdEre0pE_3fmt(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !314 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[u8]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxShENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshVgFdEre0pE_3fmt(ptr align 8 %_1) #22
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<[u8]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxShENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshVgFdEre0pE_3fmt(ptr align 8 %_1) #20
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb2:                                              ; preds = %bb4
  %3 = load ptr, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8
  %6 = insertvalue { ptr, i32 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i32 } %6, i32 %5, 1
  resume { ptr, i32 } %7
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECshVgFdEre0pE_3fmt(ptr align 8 %_1) unnamed_addr #1 !guid !315 {
start:
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshVgFdEre0pE_3fmt(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<fmt::E>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_1) unnamed_addr #1 !guid !316 {
start:
  %0 = load i8, ptr %_1, align 8
  %_2 = zext i8 %0 to i64
  switch i64 %_2, label %bb3 [
    i64 0, label %bb1
    i64 1, label %bb2
  ]

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECshVgFdEre0pE_3fmt(ptr align 8 %1)
  br label %bb1

bb1:                                              ; preds = %bb3, %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %2 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr align 8 %2)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr align 8 %_1) unnamed_addr #1 !guid !317 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECshVgFdEre0pE_3fmt(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECshVgFdEre0pE_3fmt(i64 %dummy) unnamed_addr #0 !guid !318 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !319
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshVgFdEre0pE_3fmt(i32 %dummy) unnamed_addr #0 !guid !320 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !319
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECshVgFdEre0pE_3fmt() unnamed_addr #0 !guid !321 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !319
  ret void
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshVgFdEre0pE_3fmt(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !322 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshVgFdEre0pE_3fmt(ptr %f) #22
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECshVgFdEre0pE_3fmt() #22
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECshVgFdEre0pE_3fmt(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !323 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECshVgFdEre0pE_3fmt(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !324 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECshVgFdEre0pE_3fmt(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !325 {
start:
  ret i64 %ptr.1
}

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECshVgFdEre0pE_3fmt(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !326 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECshVgFdEre0pE_3fmt(ptr %data, i64 %len) #22
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCshVgFdEre0pE_3fmt(ptr %data, i64 1, i64 1, i64 %len, ptr align 8 %0) #23
  br label %bb5
}

; <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
; Function Attrs: cold nonlazybind uwtable
define internal void @_RINvNvMs2_NtCs7CppTae75M1_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshVgFdEre0pE_3fmt(ptr align 8 %slf, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #4 !guid !327 {
start:
  %_5 = alloca [16 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::grow_amortized
  %0 = call { i64, i64 } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCshVgFdEre0pE_3fmt(ptr align 8 %slf, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1)
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_5, align 8
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load i64, ptr %_5, align 8
  %5 = getelementptr inbounds i8, ptr %_5, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = icmp eq i64 %4, -1
  %_6 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_6 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %err.0 = load i64, ptr %_5, align 8
  %9 = getelementptr inbounds i8, ptr %_5, i64 8
  %err.1 = load i64, ptr %9, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #24
  unreachable

bb3:                                              ; preds = %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !328 {
start:
  %0 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %v = alloca [24 x i8], align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  store i8 0, ptr %_13, align 1
; call <alloc::vec::Vec<u8>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %v, i64 %s.1) #22
  br label %bb1

bb1:                                              ; preds = %start
  %_6 = icmp ugt i64 %s.1, 0
  br i1 %_6, label %bb2, label %bb6

bb6:                                              ; preds = %bb11, %bb1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %v, i64 24, i1 false)
  ret void

bb2:                                              ; preds = %bb1
  br label %bb3

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECshVgFdEre0pE_3fmt(ptr align 8 %v) #20
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4, %bb5, %bb3
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
; invoke <alloc::vec::Vec<u8>>::as_mut_ptr
  %_9 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCshVgFdEre0pE_3fmt(ptr align 8 %v)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke core::ub_checks::check_language_ub
  %_4.i.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
          to label %_4.i.i.noexc unwind label %cleanup

_4.i.i.noexc:                                     ; preds = %bb4
  br i1 %_4.i.i1, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCshVgFdEre0pE_3fmt.exit

bb2.i.i:                                          ; preds = %_4.i.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshVgFdEre0pE_3fmt(ptr %s.0, ptr %_9, i64 1, i64 1, i64 %s.1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #23
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCshVgFdEre0pE_3fmt.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCshVgFdEre0pE_3fmt.exit: ; preds = %_4.i.i.noexc, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_9, ptr align 1 %s.0, i64 %s.1, i1 false)
  br label %bb5

bb5:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCshVgFdEre0pE_3fmt.exit
; invoke <alloc::vec::Vec<u8>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCshVgFdEre0pE_3fmt(ptr align 8 %v, i64 %s.1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb5
  br label %bb6

terminate:                                        ; preds = %bb7
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb10:                                             ; preds = %bb7
  %6 = load i8, ptr %_13, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb9, label %bb8

bb8:                                              ; preds = %bb9, %bb10
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb9:                                              ; preds = %bb10
  br label %bb8
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshVgFdEre0pE_3fmt(ptr align 8 %_1) unnamed_addr #0 !guid !329 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshVgFdEre0pE_3fmt(ptr %_4) #25
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshVgFdEre0pE_3fmt() #22
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshVgFdEre0pE_3fmt(i8 %_2) #22
  ret i32 %_0
}

; <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB7_11RawVecInner11finish_grow0CshVgFdEre0pE_3fmt(ptr align 8 %_1) unnamed_addr #0 !guid !330 {
start:
  %_4.0 = load i64, ptr %_1, align 8
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_4.1 = load i64, ptr %0, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %1 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCshVgFdEre0pE_3fmt(i64 %_4.0, i64 %_4.1, ptr align 8 @alloc_c53d1dc14d9dfd00f89649d83c62a8b7) #22
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; alloc::fmt::format::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvNtCs7CppTae75M1_5alloc3fmt6format0CshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_1) unnamed_addr #0 !guid !331 {
start:
  %_2.0 = load ptr, ptr %_1, align 8
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_2.1 = load ptr, ptr %0, align 8
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCs7CppTae75M1_5alloc3fmt6format12format_inner(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, ptr %_2.1)
  ret void
}

; alloc::raw_vec::layout_array::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0CshVgFdEre0pE_3fmt() unnamed_addr #0 !guid !332 {
start:
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %0 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCshVgFdEre0pE_3fmt(i64 0, i64 undef, ptr align 8 @alloc_84e24ad25dfa3f90d9808e22947b437c) #22
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshVgFdEre0pE_3fmt(ptr %_1) unnamed_addr #0 !guid !333 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshVgFdEre0pE_3fmt(ptr %0) #22
  ret i32 %_0
}

; fmt::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCshVgFdEre0pE_3fmt4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !334 {
start:
  %e.i47 = alloca [0 x i8], align 1
  %self.i48 = alloca [1 x i8], align 1
  %e.i = alloca [0 x i8], align 1
  %self.i = alloca [1 x i8], align 1
  %0 = alloca [16 x i8], align 8
  %_349 = alloca [16 x i8], align 8
  %_348 = alloca [16 x i8], align 8
  %args42 = alloca [32 x i8], align 8
  %_345 = alloca [24 x i8], align 8
  %_338 = alloca [16 x i8], align 8
  %args41 = alloca [16 x i8], align 8
  %_330 = alloca [16 x i8], align 8
  %args40 = alloca [16 x i8], align 8
  %_328 = alloca [16 x i8], align 8
  %_321 = alloca [16 x i8], align 8
  %args39 = alloca [16 x i8], align 8
  %_313 = alloca [16 x i8], align 8
  %_312 = alloca [16 x i8], align 8
  %_311 = alloca [16 x i8], align 8
  %args38 = alloca [48 x i8], align 8
  %args37 = alloca [24 x i8], align 8
  %_301 = alloca [16 x i8], align 8
  %_300 = alloca [16 x i8], align 8
  %args36 = alloca [32 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %args35 = alloca [16 x i8], align 8
  %_277 = alloca [16 x i8], align 8
  %args34 = alloca [16 x i8], align 8
  %s = alloca [24 x i8], align 8
  %_264 = alloca [16 x i8], align 8
  %_263 = alloca [16 x i8], align 8
  %_262 = alloca [16 x i8], align 8
  %args33 = alloca [48 x i8], align 8
  %args32 = alloca [24 x i8], align 8
  %_252 = alloca [16 x i8], align 8
  %_251 = alloca [16 x i8], align 8
  %_250 = alloca [16 x i8], align 8
  %args31 = alloca [48 x i8], align 8
  %args30 = alloca [24 x i8], align 8
  %_240 = alloca [16 x i8], align 8
  %_239 = alloca [16 x i8], align 8
  %args29 = alloca [32 x i8], align 8
  %_230 = alloca [16 x i8], align 8
  %_229 = alloca [16 x i8], align 8
  %_228 = alloca [16 x i8], align 8
  %_227 = alloca [16 x i8], align 8
  %args28 = alloca [64 x i8], align 8
  %args27 = alloca [32 x i8], align 8
  %_216 = alloca [16 x i8], align 8
  %_215 = alloca [16 x i8], align 8
  %_214 = alloca [16 x i8], align 8
  %args26 = alloca [48 x i8], align 8
  %args25 = alloca [24 x i8], align 8
  %_204 = alloca [16 x i8], align 8
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args24 = alloca [48 x i8], align 8
  %args23 = alloca [24 x i8], align 8
  %_192 = alloca [16 x i8], align 8
  %_191 = alloca [16 x i8], align 8
  %_190 = alloca [16 x i8], align 8
  %args22 = alloca [48 x i8], align 8
  %args21 = alloca [24 x i8], align 8
  %_180 = alloca [16 x i8], align 8
  %_179 = alloca [16 x i8], align 8
  %_178 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %args19 = alloca [24 x i8], align 8
  %_168 = alloca [16 x i8], align 8
  %_167 = alloca [16 x i8], align 8
  %_166 = alloca [16 x i8], align 8
  %_165 = alloca [16 x i8], align 8
  %args18 = alloca [64 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_154 = alloca [16 x i8], align 8
  %args16 = alloca [16 x i8], align 8
  %_146 = alloca [16 x i8], align 8
  %args15 = alloca [16 x i8], align 8
  %_142 = alloca [24 x i8], align 8
  %_141 = alloca [32 x i8], align 8
  %_134 = alloca [16 x i8], align 8
  %_133 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_130 = alloca [24 x i8], align 8
  %_129 = alloca [32 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args13 = alloca [16 x i8], align 8
  %_113 = alloca [16 x i8], align 8
  %args12 = alloca [16 x i8], align 8
  %pt = alloca [24 x i8], align 8
  %_102 = alloca [16 x i8], align 8
  %_101 = alloca [16 x i8], align 8
  %args11 = alloca [32 x i8], align 8
  %_92 = alloca [16 x i8], align 8
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args10 = alloca [48 x i8], align 8
  %args9 = alloca [24 x i8], align 8
  %_80 = alloca [16 x i8], align 8
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %_77 = alloca [16 x i8], align 8
  %args8 = alloca [64 x i8], align 8
  %args7 = alloca [24 x i8], align 8
  %width = alloca [8 x i8], align 8
  %name = alloca [16 x i8], align 8
  %_65 = alloca [16 x i8], align 8
  %args6 = alloca [16 x i8], align 8
  %_57 = alloca [16 x i8], align 8
  %_56 = alloca [16 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %_53 = alloca [16 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %args5 = alloca [96 x i8], align 8
  %args4 = alloca [48 x i8], align 8
  %_39 = alloca [16 x i8], align 8
  %_38 = alloca [16 x i8], align 8
  %_37 = alloca [16 x i8], align 8
  %args3 = alloca [48 x i8], align 8
  %args2 = alloca [24 x i8], align 8
  %_27 = alloca [16 x i8], align 8
  %_26 = alloca [16 x i8], align 8
  %_25 = alloca [16 x i8], align 8
  %_24 = alloca [16 x i8], align 8
  %_23 = alloca [16 x i8], align 8
  %_22 = alloca [16 x i8], align 8
  %_21 = alloca [16 x i8], align 8
  %_20 = alloca [16 x i8], align 8
  %args1 = alloca [128 x i8], align 8
  %args = alloca [64 x i8], align 8
  %_4 = alloca [24 x i8], align 8
  %p = alloca [8 x i8], align 8
  %w = alloca [8 x i8], align 8
  %n = alloca [4 x i8], align 4
; call core::hint::black_box::<i32>
  %_5 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshVgFdEre0pE_3fmt(i32 42) #22
; call core::hint::black_box::<usize>
  %_6 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECshVgFdEre0pE_3fmt(i64 8) #22
; call core::hint::black_box::<usize>
  %_7 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECshVgFdEre0pE_3fmt(i64 3) #22
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i32 %_5, ptr %1, align 8
  store i64 %_6, ptr %_4, align 8
  %2 = getelementptr inbounds i8, ptr %_4, i64 16
  store i64 %_7, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i32, ptr %3, align 8
  store i32 %4, ptr %n, align 4
  %5 = load i64, ptr %_4, align 8
  store i64 %5, ptr %w, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i64, ptr %6, align 8
  store i64 %7, ptr %p, align 8
  store ptr %n, ptr %args, align 8
  %8 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %n, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr %n, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args, i64 24
  store ptr %n, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args, i64 32
  store ptr %n, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %args, i64 40
  store ptr %n, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %args, i64 48
  store ptr %n, ptr %13, align 8
  %14 = getelementptr inbounds i8, ptr %args, i64 56
  store ptr %n, ptr %14, align 8
  %_352 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_20, ptr align 4 %_352) #22
  %15 = getelementptr inbounds i8, ptr %args, i64 8
  %_353 = load ptr, ptr %15, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_21, ptr align 4 %_353) #22
  %16 = getelementptr inbounds i8, ptr %args, i64 16
  %_354 = load ptr, ptr %16, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_22, ptr align 4 %_354) #22
  %17 = getelementptr inbounds i8, ptr %args, i64 24
  %_355 = load ptr, ptr %17, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_23, ptr align 4 %_355) #22
  %18 = getelementptr inbounds i8, ptr %args, i64 32
  %_356 = load ptr, ptr %18, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_24, ptr align 4 %_356) #22
  %19 = getelementptr inbounds i8, ptr %args, i64 40
  %_357 = load ptr, ptr %19, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_25, ptr align 4 %_357) #22
  %20 = getelementptr inbounds i8, ptr %args, i64 48
  %_358 = load ptr, ptr %20, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexlECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_26, ptr align 4 %_358) #22
  %21 = getelementptr inbounds i8, ptr %args, i64 56
  %_359 = load ptr, ptr %21, align 8
; call <core::fmt::rt::Argument>::new_binary::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_27, ptr align 4 %_359) #22
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_20, i64 16, i1 false)
  %23 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %23, ptr align 8 %_21, i64 16, i1 false)
  %24 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %24, ptr align 8 %_22, i64 16, i1 false)
  %25 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %25, ptr align 8 %_23, i64 16, i1 false)
  %26 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %26, ptr align 8 %_24, i64 16, i1 false)
  %27 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %27, ptr align 8 %_25, i64 16, i1 false)
  %28 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 6
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %28, ptr align 8 %_26, i64 16, i1 false)
  %29 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 7
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %29, ptr align 8 %_27, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<86, 8>
  %30 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj56_Kj8_ECshVgFdEre0pE_3fmt(ptr @alloc_058ed9c984ace2f2df2878d2b6a7ab17, ptr align 8 %args1) #22
  %_9.0 = extractvalue { ptr, ptr } %30, 0
  %_9.1 = extractvalue { ptr, ptr } %30, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr @alloc_a06b157fbc4fea4c9656215c4f90058c, ptr %args2, align 8
  %31 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr @alloc_116173a2102397b8b6fd81096c83cfc9, ptr %31, align 8
  %32 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr @alloc_3bff007dbe99da6ff02a2194c6277311, ptr %32, align 8
  %_360 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_37, ptr align 8 %_360) #22
  %33 = getelementptr inbounds i8, ptr %args2, i64 8
  %_361 = load ptr, ptr %33, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_38, ptr align 8 %_361) #22
  %34 = getelementptr inbounds i8, ptr %args2, i64 16
  %_362 = load ptr, ptr %34, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_39, ptr align 8 %_362) #22
  %35 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %35, ptr align 8 %_37, i64 16, i1 false)
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_38, i64 16, i1 false)
  %37 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %37, ptr align 8 %_39, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<35, 3>
  %38 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj23_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_7e4bbc79e2378daf3eeafb7b7df22ee0, ptr align 8 %args3) #22
  %_31.0 = extractvalue { ptr, ptr } %38, 0
  %_31.1 = extractvalue { ptr, ptr } %38, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_31.0, ptr %_31.1)
  store ptr %n, ptr %args4, align 8
  %39 = getelementptr inbounds i8, ptr %args4, i64 8
  store ptr @alloc_8c4e06e927edde26594c713b91192e5a, ptr %39, align 8
  %40 = getelementptr inbounds i8, ptr %args4, i64 16
  store ptr @alloc_f85406d658e94b9c37cd2112f10307ee, ptr %40, align 8
  %41 = getelementptr inbounds i8, ptr %args4, i64 24
  store ptr @alloc_cdde77e819f554b9b7f533765281c183, ptr %41, align 8
  %42 = getelementptr inbounds i8, ptr %args4, i64 32
  store ptr %w, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %args4, i64 40
  store ptr %p, ptr %43, align 8
  %_363 = load ptr, ptr %args4, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_52, ptr align 4 %_363) #22
  %44 = getelementptr inbounds i8, ptr %args4, i64 32
  %_364 = load ptr, ptr %44, align 8
; call <core::fmt::rt::Argument>::from_usize
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_53, ptr align 8 %_364, ptr align 8 @alloc_7a793d85dca71c7dc1dea8251d3c81a6) #22
  %45 = getelementptr inbounds i8, ptr %args4, i64 8
  %_365 = load ptr, ptr %45, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_54, ptr align 8 %_365) #22
  %46 = getelementptr inbounds i8, ptr %args4, i64 40
  %_366 = load ptr, ptr %46, align 8
; call <core::fmt::rt::Argument>::from_usize
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_55, ptr align 8 %_366, ptr align 8 @alloc_7a793d85dca71c7dc1dea8251d3c81a6) #22
  %47 = getelementptr inbounds i8, ptr %args4, i64 24
  %_367 = load ptr, ptr %47, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_56, ptr align 8 %_367) #22
  %48 = getelementptr inbounds i8, ptr %args4, i64 16
  %_368 = load ptr, ptr %48, align 8
; call <core::fmt::rt::Argument>::from_usize
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_57, ptr align 8 %_368, ptr align 8 @alloc_7a793d85dca71c7dc1dea8251d3c81a6) #22
  %49 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %49, ptr align 8 %_52, i64 16, i1 false)
  %50 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %50, ptr align 8 %_53, i64 16, i1 false)
  %51 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %_54, i64 16, i1 false)
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_55, i64 16, i1 false)
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_56, i64 16, i1 false)
  %54 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %54, ptr align 8 %_57, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<41, 6>
  %55 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj29_Kj6_ECshVgFdEre0pE_3fmt(ptr @alloc_33b2945736ef38a27c6e677ffcd45b44, ptr align 8 %args5) #22
  %_43.0 = extractvalue { ptr, ptr } %55, 0
  %_43.1 = extractvalue { ptr, ptr } %55, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_43.0, ptr %_43.1)
; call <core::fmt::rt::Argument>::new_debug::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_65, ptr align 8 @alloc_9f8d7ceb5d76cacbca201a50ff8c4371) #22
  %56 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_65, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<14, 1>
  %57 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_95ee1cd2eaa09486cb2b0fd227d38feb, ptr align 8 %args6) #22
  %_61.0 = extractvalue { ptr, ptr } %57, 0
  %_61.1 = extractvalue { ptr, ptr } %57, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_61.0, ptr %_61.1)
  store ptr @alloc_84452d4c362ef91ce628cf4a12e63db7, ptr %name, align 8, !captures !300
  %58 = getelementptr inbounds i8, ptr %name, i64 8
  store i64 3, ptr %58, align 8
  store i64 7, ptr %width, align 8
  store ptr %name, ptr %args7, align 8
  %59 = getelementptr inbounds i8, ptr %args7, i64 8
  store ptr %width, ptr %59, align 8
  %60 = getelementptr inbounds i8, ptr %args7, i64 16
  store ptr %n, ptr %60, align 8
  %_370 = load ptr, ptr %args7, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_77, ptr align 8 %_370) #22
  %61 = getelementptr inbounds i8, ptr %args7, i64 8
  %_371 = load ptr, ptr %61, align 8
; call <core::fmt::rt::Argument>::from_usize
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_78, ptr align 8 %_371, ptr align 8 @alloc_96f2619f19364aea06eebc9b5a1fb7d7) #22
  %_372 = load ptr, ptr %args7, align 8
; call <core::fmt::rt::Argument>::new_debug::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_79, ptr align 8 %_372) #22
  %62 = getelementptr inbounds i8, ptr %args7, i64 16
  %_373 = load ptr, ptr %62, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexlECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_80, ptr align 4 %_373) #22
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_77, i64 16, i1 false)
  %64 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %64, ptr align 8 %_78, i64 16, i1 false)
  %65 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %65, ptr align 8 %_79, i64 16, i1 false)
  %66 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %66, ptr align 8 %_80, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<34, 4>
  %67 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj22_Kj4_ECshVgFdEre0pE_3fmt(ptr @alloc_9f628f80319a062de0e97a0dc03419f7, ptr align 8 %args8) #22
  %_71.0 = extractvalue { ptr, ptr } %67, 0
  %_71.1 = extractvalue { ptr, ptr } %67, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  store ptr @alloc_b120f3228a2aa0acd63c1931e0ccccd5, ptr %args9, align 8
  %68 = getelementptr inbounds i8, ptr %args9, i64 8
  store ptr @alloc_adbc948e1297c274cac6e15d4baf9312, ptr %68, align 8
  %69 = getelementptr inbounds i8, ptr %args9, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %69, align 8
  %_374 = load ptr, ptr %args9, align 8
; call <core::fmt::rt::Argument>::new_debug::<char>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugcECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_90, ptr align 4 %_374) #22
  %70 = getelementptr inbounds i8, ptr %args9, i64 8
  %_375 = load ptr, ptr %70, align 8
; call <core::fmt::rt::Argument>::new_debug::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_91, ptr align 8 %_375) #22
  %71 = getelementptr inbounds i8, ptr %args9, i64 16
  %_376 = load ptr, ptr %71, align 8
; call <core::fmt::rt::Argument>::new_debug::<()>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuguECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_92, ptr %_376) #22
  %72 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %72, ptr align 8 %_90, i64 16, i1 false)
  %73 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %73, ptr align 8 %_91, i64 16, i1 false)
  %74 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %74, ptr align 8 %_92, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %75 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args10) #22
  %_84.0 = extractvalue { ptr, ptr } %75, 0
  %_84.1 = extractvalue { ptr, ptr } %75, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_84.0, ptr %_84.1)
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<f64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptiondEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_101, ptr align 8 @alloc_938b60fd0bf7f9b98ca251eb559dc6f5) #22
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_102, ptr @alloc_9d4d590161390a2420b41fde992773bb) #22
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_101, i64 16, i1 false)
  %77 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %77, ptr align 8 %_102, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %78 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECshVgFdEre0pE_3fmt(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args11) #22
  %_96.0 = extractvalue { ptr, ptr } %78, 0
  %_96.1 = extractvalue { ptr, ptr } %78, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_96.0, ptr %_96.1)
  %79 = getelementptr inbounds i8, ptr %pt, i64 16
  store i32 -1, ptr %79, align 8
  %80 = getelementptr inbounds i8, ptr %pt, i64 20
  store float 2.500000e+00, ptr %80, align 4
  store ptr @alloc_070ca2e2ae6721b8fbf222c3a28fff78, ptr %pt, align 8
  %81 = getelementptr inbounds i8, ptr %pt, i64 8
  store i64 1, ptr %81, align 8
; call <core::fmt::rt::Argument>::new_debug::<fmt::Point>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt5PointEBX_(ptr sret([16 x i8]) align 8 %_113, ptr align 8 %pt) #22
  %82 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %82, ptr align 8 %_113, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %83 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args12) #22
  %_109.0 = extractvalue { ptr, ptr } %83, 0
  %_109.1 = extractvalue { ptr, ptr } %83, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_109.0, ptr %_109.1)
; call <core::fmt::rt::Argument>::new_debug::<fmt::Point>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt5PointEBX_(ptr sret([16 x i8]) align 8 %_121, ptr align 8 %pt) #22
  %84 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %84, ptr align 8 %_121, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<8, 1>
  %85 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_c3b1946345a8630bc4d2f804c02f8ade, ptr align 8 %args13) #22
  %_117.0 = extractvalue { ptr, ptr } %85, 0
  %_117.1 = extractvalue { ptr, ptr } %85, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_117.0, ptr %_117.1)
; call <&str as core::convert::Into<alloc::string::String>>::into
  call void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_130, ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, i64 1, ptr align 8 @alloc_ad5ee50880169519f12eb2aee1c80306) #22
  %86 = getelementptr inbounds i8, ptr %_129, i64 1
  store i8 1, ptr %86, align 1
  %87 = getelementptr inbounds i8, ptr %_129, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %87, ptr align 8 %_130, i64 24, i1 false)
  store i8 1, ptr %_129, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<fmt::E>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt1EEBX_(ptr sret([16 x i8]) align 8 %_133, ptr align 8 @alloc_f9894cef7d80ce1597e4af1bee2cc81d)
          to label %bb52 unwind label %cleanup

bb156:                                            ; preds = %cleanup
; invoke core::ptr::drop_glue::<fmt::E>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_129) #20
          to label %bb157 unwind label %terminate

cleanup:                                          ; preds = %bb54, %bb53, %bb52, %start
  %88 = landingpad { ptr, i32 }
          cleanup
  %89 = extractvalue { ptr, i32 } %88, 0
  %90 = extractvalue { ptr, i32 } %88, 1
  store ptr %89, ptr %0, align 8
  %91 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %90, ptr %91, align 8
  br label %bb156

bb52:                                             ; preds = %start
; invoke <core::fmt::rt::Argument>::new_debug::<fmt::E>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt1EEBX_(ptr sret([16 x i8]) align 8 %_134, ptr align 8 %_129)
          to label %bb53 unwind label %cleanup

bb53:                                             ; preds = %bb52
  %92 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %92, ptr align 8 %_133, i64 16, i1 false)
  %93 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %93, ptr align 8 %_134, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %94 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECshVgFdEre0pE_3fmt(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14)
          to label %bb54 unwind label %cleanup

bb54:                                             ; preds = %bb53
  %_125.0 = extractvalue { ptr, ptr } %94, 0
  %_125.1 = extractvalue { ptr, ptr } %94, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_125.0, ptr %_125.1)
          to label %bb55 unwind label %cleanup

bb55:                                             ; preds = %bb54
; call core::ptr::drop_glue::<fmt::E>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_129)
; call alloc::boxed::box_new_uninit
  %_1.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshVgFdEre0pE_3fmt(i64 1, i64 2) #22
  %_427 = ptrtoint ptr %_1.i to i64
  %_429 = and i64 %_427, 0
  %_430 = icmp eq i64 %_429, 0
  br i1 %_430, label %bb158, label %panic

bb158:                                            ; preds = %bb55
  %_432 = ptrtoint ptr %_1.i to i64
  %_434 = icmp eq i64 %_432, 0
  %_435 = and i1 %_434, true
  %_436 = xor i1 %_435, true
  br i1 %_436, label %bb159, label %panic43

panic:                                            ; preds = %bb55
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 1, i64 %_427, ptr align 8 @alloc_9c7fb62c24638c4cee5ee34bf542b723) #26
  unreachable

bb159:                                            ; preds = %bb158
  %95 = getelementptr inbounds nuw i8, ptr %_1.i, i64 0
  store i8 1, ptr %95, align 1
  %96 = getelementptr inbounds nuw i8, ptr %_1.i, i64 1
  store i8 2, ptr %96, align 1
; call <[u8]>::into_vec::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh8into_vecNtNtB5_5alloc6GlobalECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_142, ptr %_1.i, i64 2) #22
  %97 = getelementptr inbounds i8, ptr %_141, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %97, ptr align 8 %_142, i64 24, i1 false)
  %98 = getelementptr inbounds i8, ptr %_141, i64 1
  store i8 -3, ptr %98, align 1
  %99 = getelementptr inbounds i8, ptr %98, i64 1
  store i8 1, ptr %99, align 1
  store i8 2, ptr %_141, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<fmt::E>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCshVgFdEre0pE_3fmt1EEBX_(ptr sret([16 x i8]) align 8 %_146, ptr align 8 %_141)
          to label %bb59 unwind label %cleanup44

panic43:                                          ; preds = %bb158
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_9c7fb62c24638c4cee5ee34bf542b723) #26
  unreachable

bb155:                                            ; preds = %cleanup44
; invoke core::ptr::drop_glue::<fmt::E>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_141) #20
          to label %bb157 unwind label %terminate

cleanup44:                                        ; preds = %bb60, %bb59, %bb159
  %100 = landingpad { ptr, i32 }
          cleanup
  %101 = extractvalue { ptr, i32 } %100, 0
  %102 = extractvalue { ptr, i32 } %100, 1
  store ptr %101, ptr %0, align 8
  %103 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %102, ptr %103, align 8
  br label %bb155

bb59:                                             ; preds = %bb159
  %104 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %104, ptr align 8 %_146, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %105 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_c3b1946345a8630bc4d2f804c02f8ade, ptr align 8 %args15)
          to label %bb60 unwind label %cleanup44

bb60:                                             ; preds = %bb59
  %_138.0 = extractvalue { ptr, ptr } %105, 0
  %_138.1 = extractvalue { ptr, ptr } %105, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_138.0, ptr %_138.1)
          to label %bb61 unwind label %cleanup44

bb61:                                             ; preds = %bb60
; call core::ptr::drop_glue::<fmt::E>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCshVgFdEre0pE_3fmt1EEBD_(ptr align 8 %_141)
; call <core::fmt::rt::Argument>::new_debug::<(i32, &str, [f64; 2])>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTlReAdj2_EECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_154, ptr align 8 @alloc_b0c6f7e20c8b1e174b89edc6baca02fc) #22
  %106 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %106, ptr align 8 %_154, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<8, 1>
  %107 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_c3b1946345a8630bc4d2f804c02f8ade, ptr align 8 %args16) #22
  %_150.0 = extractvalue { ptr, ptr } %107, 0
  %_150.1 = extractvalue { ptr, ptr } %107, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_150.0, ptr %_150.1)
  store ptr @alloc_0db41ab121065f14f332cc5e3cf612a8, ptr %args17, align 8
  %108 = getelementptr inbounds i8, ptr %args17, i64 8
  store ptr @alloc_33e8ada5b6178afcb200a31f257552b1, ptr %108, align 8
  %109 = getelementptr inbounds i8, ptr %args17, i64 16
  store ptr @alloc_eabeddbc27aba20163f110a6ba7d77e7, ptr %109, align 8
  %110 = getelementptr inbounds i8, ptr %args17, i64 24
  store ptr @alloc_79674baf410e37291a6607f958b7b1fe, ptr %110, align 8
  %_385 = load ptr, ptr %args17, align 8
; call <core::fmt::rt::Argument>::new_display::<fmt::Money>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_165, ptr align 8 %_385) #22
  %111 = getelementptr inbounds i8, ptr %args17, i64 8
  %_386 = load ptr, ptr %111, align 8
; call <core::fmt::rt::Argument>::new_display::<fmt::Money>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_166, ptr align 8 %_386) #22
  %112 = getelementptr inbounds i8, ptr %args17, i64 16
  %_387 = load ptr, ptr %112, align 8
; call <core::fmt::rt::Argument>::new_display::<fmt::Money>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_167, ptr align 8 %_387) #22
  %113 = getelementptr inbounds i8, ptr %args17, i64 24
  %_388 = load ptr, ptr %113, align 8
; call <core::fmt::rt::Argument>::new_display::<fmt::Money>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtCshVgFdEre0pE_3fmt5MoneyEB10_(ptr sret([16 x i8]) align 8 %_168, ptr align 8 %_388) #22
  %114 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %114, ptr align 8 %_165, i64 16, i1 false)
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_166, i64 16, i1 false)
  %116 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %116, ptr align 8 %_167, i64 16, i1 false)
  %117 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %117, ptr align 8 %_168, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<40, 4>
  %118 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj28_Kj4_ECshVgFdEre0pE_3fmt(ptr @alloc_80c3197a743f5124a0a564937a745665, ptr align 8 %args18) #22
  %_158.0 = extractvalue { ptr, ptr } %118, 0
  %_158.1 = extractvalue { ptr, ptr } %118, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_158.0, ptr %_158.1)
  store ptr @alloc_201c3ee118050b09cec852f4540cef71, ptr %args19, align 8
  %119 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr @alloc_201c3ee118050b09cec852f4540cef71, ptr %119, align 8
  %120 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr @alloc_201c3ee118050b09cec852f4540cef71, ptr %120, align 8
  %_389 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<fmt::Hex>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexNtCshVgFdEre0pE_3fmt3HexEB12_(ptr sret([16 x i8]) align 8 %_178, ptr align 4 %_389) #22
  %121 = getelementptr inbounds i8, ptr %args19, i64 8
  %_390 = load ptr, ptr %121, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<fmt::Hex>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexNtCshVgFdEre0pE_3fmt3HexEB12_(ptr sret([16 x i8]) align 8 %_179, ptr align 4 %_390) #22
  %122 = getelementptr inbounds i8, ptr %args19, i64 16
  %_391 = load ptr, ptr %122, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<fmt::Hex>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexNtCshVgFdEre0pE_3fmt3HexEB12_(ptr sret([16 x i8]) align 8 %_180, ptr align 4 %_391) #22
  %123 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %123, ptr align 8 %_178, i64 16, i1 false)
  %124 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %124, ptr align 8 %_179, i64 16, i1 false)
  %125 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %125, ptr align 8 %_180, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<20, 3>
  %126 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_2496decc21825f3f9b238b54f8d5e33f, ptr align 8 %args20) #22
  %_172.0 = extractvalue { ptr, ptr } %126, 0
  %_172.1 = extractvalue { ptr, ptr } %126, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_172.0, ptr %_172.1)
  store ptr @alloc_e0f292073631866f6c61fe5668d1ab0c, ptr %args21, align 8
  %127 = getelementptr inbounds i8, ptr %args21, i64 8
  store ptr @alloc_18e849d5c0b47b9a1071d700260ded41, ptr %127, align 8
  %128 = getelementptr inbounds i8, ptr %args21, i64 16
  store ptr @alloc_cdbdeba67b052fefbde5996b437aa24e, ptr %128, align 8
  %_392 = load ptr, ptr %args21, align 8
; call <core::fmt::rt::Argument>::new_lower_exp::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_190, ptr align 8 %_392) #22
  %129 = getelementptr inbounds i8, ptr %args21, i64 8
  %_393 = load ptr, ptr %129, align 8
; call <core::fmt::rt::Argument>::new_upper_exp::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_191, ptr align 8 %_393) #22
  %130 = getelementptr inbounds i8, ptr %args21, i64 16
  %_394 = load ptr, ptr %130, align 8
; call <core::fmt::rt::Argument>::new_lower_exp::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expmECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_192, ptr align 4 %_394) #22
  %131 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %131, ptr align 8 %_190, i64 16, i1 false)
  %132 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %132, ptr align 8 %_191, i64 16, i1 false)
  %133 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %133, ptr align 8 %_192, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %134 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args22) #22
  %_184.0 = extractvalue { ptr, ptr } %134, 0
  %_184.1 = extractvalue { ptr, ptr } %134, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_184.0, ptr %_184.1)
  store ptr @alloc_f93507f8ba4b5780b14b2c2584609be0, ptr %args23, align 8
  %135 = getelementptr inbounds i8, ptr %args23, i64 8
  store ptr @alloc_91984e5afffc475237697b8bd6a3e206, ptr %135, align 8
  %136 = getelementptr inbounds i8, ptr %args23, i64 16
  store ptr @alloc_ddd207f36435cdb5a6b231356b1990e9, ptr %136, align 8
  %_395 = load ptr, ptr %args23, align 8
; call <core::fmt::rt::Argument>::new_debug::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_202, ptr align 8 %_395) #22
  %137 = getelementptr inbounds i8, ptr %args23, i64 8
  %_396 = load ptr, ptr %137, align 8
; call <core::fmt::rt::Argument>::new_debug::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugfECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_203, ptr align 4 %_396) #22
  %138 = getelementptr inbounds i8, ptr %args23, i64 16
  %_397 = load ptr, ptr %138, align 8
; call <core::fmt::rt::Argument>::new_debug::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_204, ptr align 8 %_397) #22
  %139 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %139, ptr align 8 %_202, i64 16, i1 false)
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_203, i64 16, i1 false)
  %141 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %141, ptr align 8 %_204, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %142 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args24) #22
  %_196.0 = extractvalue { ptr, ptr } %142, 0
  %_196.1 = extractvalue { ptr, ptr } %142, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_196.0, ptr %_196.1)
  store ptr @alloc_86fe2e14e8aee3cbc4747be45abbb75c, ptr %args25, align 8
  %143 = getelementptr inbounds i8, ptr %args25, i64 8
  store ptr @alloc_3fd4ac1bd4aabc745420009965a8d1ac, ptr %143, align 8
  %144 = getelementptr inbounds i8, ptr %args25, i64 16
  store ptr @alloc_4e3160e3e5d83eeb2e7a3db504240512, ptr %144, align 8
  %_398 = load ptr, ptr %args25, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_214, ptr align 8 %_398) #22
  %145 = getelementptr inbounds i8, ptr %args25, i64 8
  %_399 = load ptr, ptr %145, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_215, ptr align 4 %_399) #22
  %146 = getelementptr inbounds i8, ptr %args25, i64 16
  %_400 = load ptr, ptr %146, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_216, ptr align 8 %_400) #22
  %147 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %147, ptr align 8 %_214, i64 16, i1 false)
  %148 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %148, ptr align 8 %_215, i64 16, i1 false)
  %149 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %149, ptr align 8 %_216, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %150 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args26) #22
  %_208.0 = extractvalue { ptr, ptr } %150, 0
  %_208.1 = extractvalue { ptr, ptr } %150, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_208.0, ptr %_208.1)
  store ptr @alloc_8821998f047ca62cad40e6bc4e4d87c4, ptr %args27, align 8
  %151 = getelementptr inbounds i8, ptr %args27, i64 8
  store ptr @alloc_5b64c5758b3793302fbedcd0481de01a, ptr %151, align 8
  %152 = getelementptr inbounds i8, ptr %args27, i64 16
  store ptr @alloc_c05f8b186ecd5789d56bb5d9e682c6d7, ptr %152, align 8
  %153 = getelementptr inbounds i8, ptr %args27, i64 24
  store ptr @alloc_2baa0b6208900c4f9b90e2cbbfb2ca47, ptr %153, align 8
  %_401 = load ptr, ptr %args27, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_227, ptr %_401) #22
  %154 = getelementptr inbounds i8, ptr %args27, i64 8
  %_402 = load ptr, ptr %154, align 8
; call <core::fmt::rt::Argument>::new_display::<char>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaycECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_228, ptr align 4 %_402) #22
  %155 = getelementptr inbounds i8, ptr %args27, i64 16
  %_403 = load ptr, ptr %155, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_229, ptr align 8 %_403) #22
  %156 = getelementptr inbounds i8, ptr %args27, i64 24
  %_404 = load ptr, ptr %156, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_230, ptr align 8 %_404) #22
  %157 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args28, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %157, ptr align 8 %_227, i64 16, i1 false)
  %158 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args28, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %158, ptr align 8 %_228, i64 16, i1 false)
  %159 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args28, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %159, ptr align 8 %_229, i64 16, i1 false)
  %160 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args28, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %160, ptr align 8 %_230, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<37, 4>
  %161 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj25_Kj4_ECshVgFdEre0pE_3fmt(ptr @alloc_12541e1a1260b3fd7e4655df6b8014be, ptr align 8 %args28) #22
  %_220.0 = extractvalue { ptr, ptr } %161, 0
  %_220.1 = extractvalue { ptr, ptr } %161, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_220.0, ptr %_220.1)
; call <core::fmt::rt::Argument>::new_debug::<[core::option::Option<i32>; 2]>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAINtNtB7_6option6OptionlEj2_ECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_239, ptr align 4 @alloc_f19792d8e6fca51f99519584a77b3470) #22
; call <core::fmt::rt::Argument>::new_debug::<[[i32; 2]; 2]>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAAlj2_BY_ECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_240, ptr align 4 @alloc_68d244bd4070015bf9253d1ac51d25f8) #22
  %162 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args29, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %162, ptr align 8 %_239, i64 16, i1 false)
  %163 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args29, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %163, ptr align 8 %_240, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %164 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECshVgFdEre0pE_3fmt(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args29) #22
  %_234.0 = extractvalue { ptr, ptr } %164, 0
  %_234.1 = extractvalue { ptr, ptr } %164, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_234.0, ptr %_234.1)
  store ptr @alloc_cdbdeba67b052fefbde5996b437aa24e, ptr %args30, align 8
  %165 = getelementptr inbounds i8, ptr %args30, i64 8
  store ptr @alloc_fc18870ebd3bffa18e161a5a63775070, ptr %165, align 8
  %166 = getelementptr inbounds i8, ptr %args30, i64 16
  store ptr @alloc_a0256699fdc8ea22b569d2c1ec13c81f, ptr %166, align 8
  %_407 = load ptr, ptr %args30, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_250, ptr align 4 %_407) #22
  %167 = getelementptr inbounds i8, ptr %args30, i64 8
  %_408 = load ptr, ptr %167, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_251, ptr align 4 %_408) #22
  %168 = getelementptr inbounds i8, ptr %args30, i64 16
  %_409 = load ptr, ptr %168, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_252, ptr align 8 %_409) #22
  %169 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args31, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %169, ptr align 8 %_250, i64 16, i1 false)
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args31, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_251, i64 16, i1 false)
  %171 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args31, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %171, ptr align 8 %_252, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<30, 3>
  %172 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1e_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_352fcb003cd53a19ca29091d17651ce3, ptr align 8 %args31) #22
  %_244.0 = extractvalue { ptr, ptr } %172, 0
  %_244.1 = extractvalue { ptr, ptr } %172, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_244.0, ptr %_244.1)
  store ptr @alloc_cbaed04ca755d7df81f067609aba73ed, ptr %args32, align 8
  %173 = getelementptr inbounds i8, ptr %args32, i64 8
  store ptr @alloc_4b42cd106c262d3d9a145d6f4764eeaf, ptr %173, align 8
  %174 = getelementptr inbounds i8, ptr %args32, i64 16
  store ptr @alloc_5a1a9e6358d5f90dcb98724ce1d54ed0, ptr %174, align 8
  %_410 = load ptr, ptr %args32, align 8
; call <core::fmt::rt::Argument>::new_lower_exp::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_expdECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_262, ptr align 8 %_410) #22
  %175 = getelementptr inbounds i8, ptr %args32, i64 8
  %_411 = load ptr, ptr %175, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_263, ptr align 4 %_411) #22
  %176 = getelementptr inbounds i8, ptr %args32, i64 16
  %_412 = load ptr, ptr %176, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_264, ptr align 8 %_412) #22
  %177 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args33, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %177, ptr align 8 %_262, i64 16, i1 false)
  %178 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args33, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %178, ptr align 8 %_263, i64 16, i1 false)
  %179 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args33, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %179, ptr align 8 %_264, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<32, 3>
  %180 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj20_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_5d68c547652bb8e5dddfa04dc983f46a, ptr align 8 %args33) #22
  %_256.0 = extractvalue { ptr, ptr } %180, 0
  %_256.1 = extractvalue { ptr, ptr } %180, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_256.0, ptr %_256.1)
; call <core::fmt::Arguments>::from_str_nonconst
  %181 = call { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCshVgFdEre0pE_3fmt(ptr @alloc_214cd245ef08d32d3c495a75f259c468, i64 4) #22
  %_268.0 = extractvalue { ptr, ptr } %181, 0
  %_268.1 = extractvalue { ptr, ptr } %181, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_268.0, ptr %_268.1)
; call <alloc::string::String>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %s) #22
; invoke <core::fmt::rt::Argument>::new_debug::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_277, ptr align 8 @alloc_0fa510a23a05a548dfd86788ed688330)
          to label %bb115 unwind label %cleanup45

bb154:                                            ; preds = %bb153, %cleanup45
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr align 8 %s) #20
          to label %bb157 unwind label %terminate

cleanup45:                                        ; preds = %bb2.i50, %bb2.i, %bb150, %bb145, %bb144, %bb143, %bb142, %bb141, %bb140, %bb139, %bb138, %bb137, %bb136, %bb135, %bb134, %bb133, %bb132, %bb131, %bb130, %bb129, %bb128, %bb127, %bb126, %bb125, %bb124, %bb123, %bb122, %bb121, %bb119, %bb118, %bb116, %bb115, %bb61
  %182 = landingpad { ptr, i32 }
          cleanup
  %183 = extractvalue { ptr, i32 } %182, 0
  %184 = extractvalue { ptr, i32 } %182, 1
  store ptr %183, ptr %0, align 8
  %185 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %184, ptr %185, align 8
  br label %bb154

bb115:                                            ; preds = %bb61
  %186 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args34, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %186, ptr align 8 %_277, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<5, 1>
  %187 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj5_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_f1045206bd356f04ecf6c5daa5616281, ptr align 8 %args34)
          to label %bb116 unwind label %cleanup45

bb116:                                            ; preds = %bb115
  %_273.0 = extractvalue { ptr, ptr } %187, 0
  %_273.1 = extractvalue { ptr, ptr } %187, 1
; invoke <alloc::string::String as core::fmt::Write>::write_fmt
  %_271 = invoke zeroext i1 @_RNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtCshVgFdEre0pE_3fmt(ptr align 8 %s, ptr %_273.0, ptr %_273.1)
          to label %bb117 unwind label %cleanup45

bb117:                                            ; preds = %bb116
  %188 = zext i1 %_271 to i8
  store i8 %188, ptr %self.i48, align 1
  %189 = load i8, ptr %self.i48, align 1
  %190 = trunc nuw i8 %189 to i1
  %_2.i49 = zext i1 %190 to i64
  br i1 %190, label %bb2.i50, label %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit52

bb2.i50:                                          ; preds = %bb117
; invoke core::result::unwrap_failed
  invoke void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 43, ptr %e.i47, ptr align 8 @vtable.6, ptr align 8 @alloc_ea556a6fc27bebb9c43699dd3a5fa3f3) #27
          to label %.noexc51 unwind label %cleanup45

.noexc51:                                         ; preds = %bb2.i50
  unreachable

_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit52: ; preds = %bb117
  br label %bb118

bb118:                                            ; preds = %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit52
; invoke <core::fmt::Arguments>::from_str
  %191 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_aa8949e1fb3783c4ba3f17396bbaa3bf, i64 2)
          to label %bb119 unwind label %cleanup45

bb119:                                            ; preds = %bb118
  %_283.0 = extractvalue { ptr, ptr } %191, 0
  %_283.1 = extractvalue { ptr, ptr } %191, 1
; invoke <alloc::string::String as core::fmt::Write>::write_fmt
  %_281 = invoke zeroext i1 @_RNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtCshVgFdEre0pE_3fmt(ptr align 8 %s, ptr %_283.0, ptr %_283.1)
          to label %bb120 unwind label %cleanup45

bb120:                                            ; preds = %bb119
  %192 = zext i1 %_281 to i8
  store i8 %192, ptr %self.i, align 1
  %193 = load i8, ptr %self.i, align 1
  %194 = trunc nuw i8 %193 to i1
  %_2.i = zext i1 %194 to i64
  br i1 %194, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit

bb2.i:                                            ; preds = %bb120
; invoke core::result::unwrap_failed
  invoke void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 43, ptr %e.i, ptr align 8 @vtable.6, ptr align 8 @alloc_a7aedc039a5bce5f90b5974852c9f0c9) #27
          to label %.noexc unwind label %cleanup45

.noexc:                                           ; preds = %bb2.i
  unreachable

_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit: ; preds = %bb120
  br label %bb121

bb121:                                            ; preds = %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuNtNtB4_3fmt5ErrorE6unwrapCshVgFdEre0pE_3fmt.exit
; invoke <core::fmt::rt::Argument>::new_display::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_289, ptr align 8 %s)
          to label %bb122 unwind label %cleanup45

bb122:                                            ; preds = %bb121
  %195 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args35, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %195, ptr align 8 %_289, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<2, 1>
  %196 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj2_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_0c812808379efded5a4fb82d2790b556, ptr align 8 %args35)
          to label %bb123 unwind label %cleanup45

bb123:                                            ; preds = %bb122
  %_285.0 = extractvalue { ptr, ptr } %196, 0
  %_285.1 = extractvalue { ptr, ptr } %196, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_285.0, ptr %_285.1)
          to label %bb124 unwind label %cleanup45

bb124:                                            ; preds = %bb123
; invoke <core::fmt::Arguments>::from_str_nonconst
  %197 = invoke { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCshVgFdEre0pE_3fmt(ptr @alloc_9beb045410d021e66c87fb3fce4c6912, i64 12)
          to label %bb125 unwind label %cleanup45

bb125:                                            ; preds = %bb124
  %_293.0 = extractvalue { ptr, ptr } %197, 0
  %_293.1 = extractvalue { ptr, ptr } %197, 1
; invoke std::io::stdio::_eprint
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio7__eprint(ptr %_293.0, ptr %_293.1)
          to label %bb126 unwind label %cleanup45

bb126:                                            ; preds = %bb125
; invoke <core::fmt::rt::Argument>::new_debug::<i128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugnECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_300, ptr align 16 @alloc_b7cbb96fa2fbc2c33cfdce3b367921a6)
          to label %bb127 unwind label %cleanup45

bb127:                                            ; preds = %bb126
; invoke <core::fmt::rt::Argument>::new_debug::<u128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugoECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_301, ptr align 16 @alloc_d0776666182ad032bd1011cf266e2f3a)
          to label %bb128 unwind label %cleanup45

bb128:                                            ; preds = %bb127
  %198 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args36, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %198, ptr align 8 %_300, i64 16, i1 false)
  %199 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args36, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %199, ptr align 8 %_301, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %200 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECshVgFdEre0pE_3fmt(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args36)
          to label %bb129 unwind label %cleanup45

bb129:                                            ; preds = %bb128
  %_295.0 = extractvalue { ptr, ptr } %200, 0
  %_295.1 = extractvalue { ptr, ptr } %200, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_295.0, ptr %_295.1)
          to label %bb130 unwind label %cleanup45

bb130:                                            ; preds = %bb129
  store ptr @alloc_2aed27a01081c9f91b0f84d085de36d9, ptr %args37, align 8
  %201 = getelementptr inbounds i8, ptr %args37, i64 8
  store ptr @alloc_2aed27a01081c9f91b0f84d085de36d9, ptr %201, align 8
  %202 = getelementptr inbounds i8, ptr %args37, i64 16
  store ptr @alloc_2aed27a01081c9f91b0f84d085de36d9, ptr %202, align 8
  %_417 = load ptr, ptr %args37, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_311, ptr align 4 %_417)
          to label %bb131 unwind label %cleanup45

bb131:                                            ; preds = %bb130
  %203 = getelementptr inbounds i8, ptr %args37, i64 8
  %_418 = load ptr, ptr %203, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_312, ptr align 4 %_418)
          to label %bb132 unwind label %cleanup45

bb132:                                            ; preds = %bb131
  %204 = getelementptr inbounds i8, ptr %args37, i64 16
  %_419 = load ptr, ptr %204, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_313, ptr align 4 %_419)
          to label %bb133 unwind label %cleanup45

bb133:                                            ; preds = %bb132
  %205 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args38, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %205, ptr align 8 %_311, i64 16, i1 false)
  %206 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args38, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %206, ptr align 8 %_312, i64 16, i1 false)
  %207 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args38, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %207, ptr align 8 %_313, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<29, 3>
  %208 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj1d_Kj3_ECshVgFdEre0pE_3fmt(ptr @alloc_c424b10c3bbe424e4bad8e7fe84cacd4, ptr align 8 %args38)
          to label %bb134 unwind label %cleanup45

bb134:                                            ; preds = %bb133
  %_305.0 = extractvalue { ptr, ptr } %208, 0
  %_305.1 = extractvalue { ptr, ptr } %208, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_305.0, ptr %_305.1)
          to label %bb135 unwind label %cleanup45

bb135:                                            ; preds = %bb134
; invoke <core::fmt::rt::Argument>::new_pointer::<*const u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_pointerPhECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_321, ptr align 8 @alloc_53973d2fe29b4adba8bb7390b5678745)
          to label %bb136 unwind label %cleanup45

bb136:                                            ; preds = %bb135
  %209 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args39, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %209, ptr align 8 %_321, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %210 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args39)
          to label %bb137 unwind label %cleanup45

bb137:                                            ; preds = %bb136
  %_317.0 = extractvalue { ptr, ptr } %210, 0
  %_317.1 = extractvalue { ptr, ptr } %210, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_317.0, ptr %_317.1)
          to label %bb138 unwind label %cleanup45

bb138:                                            ; preds = %bb137
; invoke <core::time::Duration>::from_millis
  %211 = invoke { i64, i32 } @_RNvMNtCsl10jNU3mE6R_4core4timeNtB2_8Duration11from_millisCshVgFdEre0pE_3fmt(i64 1500)
          to label %bb139 unwind label %cleanup45

bb139:                                            ; preds = %bb138
  %212 = extractvalue { i64, i32 } %211, 0
  %213 = extractvalue { i64, i32 } %211, 1
  store i64 %212, ptr %_328, align 8
  %214 = getelementptr inbounds i8, ptr %_328, i64 8
  store i32 %213, ptr %214, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::time::Duration>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_4time8DurationECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_330, ptr align 8 %_328)
          to label %bb140 unwind label %cleanup45

bb140:                                            ; preds = %bb139
  %215 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args40, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %215, ptr align 8 %_330, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %216 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args40)
          to label %bb141 unwind label %cleanup45

bb141:                                            ; preds = %bb140
  %_325.0 = extractvalue { ptr, ptr } %216, 0
  %_325.1 = extractvalue { ptr, ptr } %216, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_325.0, ptr %_325.1)
          to label %bb142 unwind label %cleanup45

bb142:                                            ; preds = %bb141
; invoke <core::fmt::rt::Argument>::new_display::<f64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_338, ptr align 8 @alloc_783ee260e8ae01216c1a7e8d97dd7885)
          to label %bb143 unwind label %cleanup45

bb143:                                            ; preds = %bb142
  %217 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args41, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %217, ptr align 8 %_338, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %218 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECshVgFdEre0pE_3fmt(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args41)
          to label %bb144 unwind label %cleanup45

bb144:                                            ; preds = %bb143
  %_334.0 = extractvalue { ptr, ptr } %218, 0
  %_334.1 = extractvalue { ptr, ptr } %218, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_334.0, ptr %_334.1)
          to label %bb145 unwind label %cleanup45

bb145:                                            ; preds = %bb144
; invoke <alloc::string::String as core::convert::From<&str>>::from
  invoke void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_345, ptr @alloc_b03741e4fa93f143426998f2aacbbd7f, i64 2)
          to label %bb146 unwind label %cleanup45

bb146:                                            ; preds = %bb145
; invoke <core::fmt::rt::Argument>::new_debug::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_348, ptr align 8 %_345)
          to label %bb147 unwind label %cleanup46

bb153:                                            ; preds = %cleanup46
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr align 8 %_345) #20
          to label %bb154 unwind label %terminate

cleanup46:                                        ; preds = %bb149, %bb148, %bb147, %bb146
  %219 = landingpad { ptr, i32 }
          cleanup
  %220 = extractvalue { ptr, i32 } %219, 0
  %221 = extractvalue { ptr, i32 } %219, 1
  store ptr %220, ptr %0, align 8
  %222 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %221, ptr %222, align 8
  br label %bb153

bb147:                                            ; preds = %bb146
; invoke <core::fmt::rt::Argument>::new_debug::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugmECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_349, ptr align 4 @alloc_9b2bf7077a3c4b95a732f8a187d9d5ed)
          to label %bb148 unwind label %cleanup46

bb148:                                            ; preds = %bb147
  %223 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args42, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %223, ptr align 8 %_348, i64 16, i1 false)
  %224 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args42, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %224, ptr align 8 %_349, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %225 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECshVgFdEre0pE_3fmt(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args42)
          to label %bb149 unwind label %cleanup46

bb149:                                            ; preds = %bb148
  %_342.0 = extractvalue { ptr, ptr } %225, 0
  %_342.1 = extractvalue { ptr, ptr } %225, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_342.0, ptr %_342.1)
          to label %bb150 unwind label %cleanup46

bb150:                                            ; preds = %bb149
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr align 8 %_345)
          to label %bb151 unwind label %cleanup45

bb151:                                            ; preds = %bb150
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr align 8 %s)
  ret void

terminate:                                        ; preds = %bb156, %bb155, %bb154, %bb153
  %226 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb157:                                            ; preds = %bb156, %bb155, %bb154
  %227 = load ptr, ptr %0, align 8
  %228 = getelementptr inbounds i8, ptr %0, i64 8
  %229 = load i32, ptr %228, align 8
  %230 = insertvalue { ptr, i32 } poison, ptr %227, 0
  %231 = insertvalue { ptr, i32 } %230, i32 %229, 1
  resume { ptr, i32 } %231
}

; <alloc::vec::Vec<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !335 {
start:
; call <alloc::raw_vec::RawVec<u8>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVechE3newCshVgFdEre0pE_3fmt()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <[u8]>::to_vec
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !336 {
start:
; call <[u8]>::to_vec_in::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #22
  ret void
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !337 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !338 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  ret i64 %_0
}

; <alloc::string::String>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !339 {
start:
  %_1 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_1) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_1, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCshVgFdEre0pE_3fmt(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !340 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8CshVgFdEre0pE_3fmt(i32 %ch) #22
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %ch_len) #22
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCshVgFdEre0pE_3fmt(i32 %ch, ptr %_0.i) #22
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %_14) #22
  ret void
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !341 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr %_2.0, i64 %_2.1) #22
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !342 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::string::String>::push_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %string.0, i64 %string.1) unnamed_addr #0 !guid !343 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %string.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %string.1, 1
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; call <alloc::vec::Vec<u8>>::extend_from_slice
  call void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %_4.0, i64 %_4.1)
  ret void
}

; <alloc::raw_vec::RawVec<u8>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVechE3newCshVgFdEre0pE_3fmt() unnamed_addr #1 !guid !344 {
start:
; call <alloc::raw_vec::RawVec<u8>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE6new_inCshVgFdEre0pE_3fmt() #22
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !345 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::time::Duration>::from_millis
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RNvMNtCsl10jNU3mE6R_4core4timeNtB2_8Duration11from_millisCshVgFdEre0pE_3fmt(i64 %millis) unnamed_addr #0 !guid !346 {
start:
  %secs = udiv i64 %millis, 1000
  %_5 = urem i64 %millis, 1000
  %subsec_millis = trunc i64 %_5 to i32
  %_8 = mul i32 %subsec_millis, 1000000
; call <core::num::niche_types::Nanoseconds>::new_unchecked
  %subsec_nanos = call i32 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB5_11Nanoseconds13new_uncheckedCshVgFdEre0pE_3fmt(i32 %_8) #22
  %0 = insertvalue { i64, i32 } poison, i64 %secs, 0
  %1 = insertvalue { i64, i32 } %0, i32 %subsec_nanos, 1
  ret { i64, i32 } %1
}

; <[[i32; 2]]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAlj2_4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !347 {
start:
; call <core::slice::iter::Iter<[i32; 2]>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAlj2_E3newCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[core::option::Option<i32>]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtB4_6option6OptionlE4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !348 {
start:
; call <core::slice::iter::Iter<core::option::Option<i32>>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterINtNtB9_6option6OptionlEE3newCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[f64]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCshVgFdEre0pE_3fmt(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !349 {
start:
; call <core::slice::iter::Iter<f64>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterdE3newCshVgFdEre0pE_3fmt(ptr align 8 %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[u8]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !350 {
start:
; call <core::slice::iter::Iter<u8>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[i32]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !351 {
start:
; call <core::slice::iter::Iter<i32>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterlE3newCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::option::Option<&str>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionReE7is_someCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !352 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_2 to i1
  br i1 %5, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb4:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::from_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB2_8Argument10from_usizeCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x, ptr align 8 %0) unnamed_addr #0 !guid !353 {
start:
  %_7 = alloca [16 x i8], align 8
  %_3 = load i64, ptr %x, align 8
  %_2 = icmp ugt i64 %_3, 65535
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_9 = load i64, ptr %x, align 8
  %_8 = trunc i64 %_9 to i16
  %1 = getelementptr inbounds i8, ptr %_7, i64 8
  store i16 %_8, ptr %1, align 8
  store ptr null, ptr %_7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_7, i64 16, i1 false)
  ret void

bb1:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %2 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_bed8969a4b39b5529597d14a2d5628f2, i64 32) #22
  %_6.0 = extractvalue { ptr, ptr } %2, 0
  %_6.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 %0) #27
  unreachable
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[u8]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxShEE3newCshVgFdEre0pE_3fmt(ptr %x.0, i64 %x.1) unnamed_addr #1 !guid !354 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[u8]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxShEE6as_mutCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #1 !guid !355 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[u8]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxShEE6as_refCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #1 !guid !356 {
start:
  ret ptr %self
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCshVgFdEre0pE_3fmt(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !357 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i64 %align, ptr align 8 %0) #23
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCshVgFdEre0pE_3fmt(i64 %self) unnamed_addr #0 !guid !358 {
start:
  ret i64 %self
}

; <core::mem::alignment::Alignment>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCshVgFdEre0pE_3fmt(i64 %align) unnamed_addr #0 !guid !359 {
start:
  %_0 = alloca [8 x i8], align 8
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCshVgFdEre0pE_3fmt(i64 %align, ptr align 8 @alloc_988c380202cc7b7a37ca3d8d5930c44f) #22
  store i64 %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::mem::alignment::Alignment>::as_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCshVgFdEre0pE_3fmt(i64 %self) unnamed_addr #0 !guid !360 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCshVgFdEre0pE_3fmt(i64 %self) #22
; call <core::num::nonzero::NonZero<usize>>::get
  %_0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCshVgFdEre0pE_3fmt(i64 %_2) #22
  ret i64 %_0
}

; <*mut u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCshVgFdEre0pE_3fmt(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !361 {
start:
; call <*const u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCshVgFdEre0pE_3fmt(ptr %self, ptr %origin, ptr align 8 %0) #22
  ret i64 %_0
}

; <*mut u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !362 {
start:
; call <*const u8>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCshVgFdEre0pE_3fmt(ptr %self) #22
  ret i1 %_0
}

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !363 {
start:
; call <*const ()>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCshVgFdEre0pE_3fmt(ptr %self) #22
  ret i1 %_0
}

; <*const u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCshVgFdEre0pE_3fmt(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !364 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 1
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCshVgFdEre0pE_3fmt(ptr %self, ptr %origin, ptr align 8 %0) #23
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #27
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 1, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 1
  ret i64 %_0
}

; <*const u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !365 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCshVgFdEre0pE_3fmt(ptr %self) #22
  ret i1 %_0
}

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCshVgFdEre0pE_3fmt(ptr %self, i64 %align) unnamed_addr #0 !guid !366 {
start:
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i1 = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i1, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_fad0cd83b7d1858a846a172eb260e593, i64 42) #22
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 @alloc_7abc4ceda2d1d9be88f00c5dc522bc84) #27
  unreachable

bb2:                                              ; preds = %start
  %_0.i = ptrtoint ptr %self to i64
  %_8 = sub i64 %align, 1
  %_6 = and i64 %_0.i, %_8
  %_0 = icmp eq i64 %_6, 0
  ret i1 %_0
}

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !367 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCshVgFdEre0pE_3fmt(ptr %self) #22
  ret i1 %_0
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8CshVgFdEre0pE_3fmt(i32 %self) unnamed_addr #0 !guid !368 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CshVgFdEre0pE_3fmt(i32 %self) #22
  ret i64 %_0
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !369 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCshVgFdEre0pE_3fmt(i64 %_3) #22
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCshVgFdEre0pE_3fmt(i64 %_2) #22
  ret ptr %_0
}

; <core::alloc::layout::Layout>::repeat_packed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %n) unnamed_addr #0 !guid !370 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %0, align 8
; call <usize>::checked_mul
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCshVgFdEre0pE_3fmt(i64 %_4, i64 %n) #22
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %size = load i64, ptr %8, align 8
  %_7 = load i64, ptr %self, align 8
; call <core::alloc::layout::Layout>::from_size_alignment
  %9 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCshVgFdEre0pE_3fmt(i64 %size, i64 %_7) #22
  %10 = extractvalue { i64, i64 } %9, 0
  %11 = extractvalue { i64, i64 } %9, 1
  store i64 %10, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %13 = load i64, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { i64, i64 } poison, i64 %13, 0
  %17 = insertvalue { i64, i64 } %16, i64 %15, 1
  ret { i64, i64 } %17

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCshVgFdEre0pE_3fmt(i64 %size, i64 %alignment) unnamed_addr #0 !guid !371 {
start:
  %_0 = alloca [16 x i8], align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 %alignment, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %size, ptr %0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <core::alloc::layout::Layout>::is_size_align_valid
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCshVgFdEre0pE_3fmt(i64 %size, i64 %align) unnamed_addr #0 !guid !372 {
start:
  %_4 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
; call <core::mem::alignment::Alignment>::new
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCshVgFdEre0pE_3fmt(i64 %align) #22
  store i64 %0, ptr %_4, align 8
  %1 = load i64, ptr %_4, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %alignment = load i64, ptr %_4, align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %4 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_align_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCshVgFdEre0pE_3fmt(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !373 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i64 %size, i64 %align, ptr align 8 %0) #23
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %align, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCshVgFdEre0pE_3fmt(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !374 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i64 %size, i64 %alignment, ptr align 8 %0) #23
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !375 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::align
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !376 {
start:
  %_2 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_usize
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCshVgFdEre0pE_3fmt(i64 %_2) #22
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !377 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCshVgFdEre0pE_3fmt(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !378 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCshVgFdEre0pE_3fmt(i64 %3, i64 %5, i1 zeroext %8) #22
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCshVgFdEre0pE_3fmt(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !379 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCshVgFdEre0pE_3fmt(ptr %2, i64 %4, i64 %6) #22
  ret void
}

; <alloc::alloc::Global>::grow_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global17grow_impl_runtimeCshVgFdEre0pE_3fmt(ptr %self, ptr %ptr, i64 %0, i64 %1, i64 %2, i64 %3, i1 zeroext %zeroed) unnamed_addr #0 !guid !380 {
start:
  %_8.i.i = alloca [1 x i8], align 1
  %_30 = alloca [16 x i8], align 8
  %_21 = alloca [8 x i8], align 8
  %old_size = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %new_layout = alloca [16 x i8], align 8
  %old_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %old_layout, align 8
  %4 = getelementptr inbounds i8, ptr %old_layout, i64 8
  store i64 %1, ptr %4, align 8
  store i64 %2, ptr %new_layout, align 8
  %5 = getelementptr inbounds i8, ptr %new_layout, i64 8
  store i64 %3, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %old_layout) #22
  store i64 %6, ptr %old_size, align 8
  %7 = load i64, ptr %old_size, align 8
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %9 = load i64, ptr %new_layout, align 8
  %10 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %11 = load i64, ptr %10, align 8
; call <alloc::alloc::Global>::alloc_impl
  %12 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCshVgFdEre0pE_3fmt(ptr %self, i64 %9, i64 %11, i1 zeroext %zeroed) #22
  %13 = extractvalue { ptr, i64 } %12, 0
  %14 = extractvalue { ptr, i64 } %12, 1
  store ptr %13, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %14, ptr %15, align 8
  br label %bb30

bb2:                                              ; preds = %start
; call <core::alloc::layout::Layout>::align
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCshVgFdEre0pE_3fmt(ptr align 8 %old_layout) #22
; call <core::alloc::layout::Layout>::align
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCshVgFdEre0pE_3fmt(ptr align 8 %new_layout) #22
  %_9 = icmp eq i64 %_10, %_12
  br i1 %_9, label %bb6, label %bb7

bb30:                                             ; preds = %bb17, %bb20, %bb25, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECshVgFdEre0pE_3fmt.exit, %bb3
  %16 = load ptr, ptr %_0, align 8
  %17 = getelementptr inbounds i8, ptr %_0, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  ret { ptr, i64 } %20

bb7:                                              ; preds = %bb2
  %21 = load i64, ptr %new_layout, align 8
  %22 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %23 = load i64, ptr %22, align 8
; call <alloc::alloc::Global>::alloc_impl
  %24 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCshVgFdEre0pE_3fmt(ptr %self, i64 %21, i64 %23, i1 zeroext %zeroed) #22
  %_31.0 = extractvalue { ptr, i64 } %24, 0
  %_31.1 = extractvalue { ptr, i64 } %24, 1
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %25 = call { ptr, i64 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr %_31.0, i64 %_31.1) #22
  %26 = extractvalue { ptr, i64 } %25, 0
  %27 = extractvalue { ptr, i64 } %25, 1
  store ptr %26, ptr %_30, align 8
  %28 = getelementptr inbounds i8, ptr %_30, i64 8
  store i64 %27, ptr %28, align 8
  %29 = load ptr, ptr %_30, align 8
  %30 = getelementptr inbounds i8, ptr %_30, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = ptrtoint ptr %29 to i64
  %33 = icmp eq i64 %32, 0
  %_32 = select i1 %33, i64 1, i64 0
  %34 = trunc nuw i64 %_32 to i1
  br i1 %34, label %bb25, label %bb24

bb6:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %new_size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %new_layout) #22
; call <core::alloc::layout::Layout>::size
  %_18 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %old_layout) #22
  %_17 = icmp uge i64 %new_size, %_18
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_2.i, label %bb2.i2, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i2:                                           ; preds = %bb6
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i1 zeroext %_17, ptr align 8 @alloc_9e1ff22d96cae328e0e878f28b86a5f7) #23
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb6, %bb2.i2
  %35 = load i64, ptr %old_layout, align 8
  %36 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %37 = load i64, ptr %36, align 8
; call alloc::alloc::realloc_nonnull
  %raw_ptr = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc15realloc_nonnullCshVgFdEre0pE_3fmt(ptr %ptr, i64 %35, i64 %37, i64 %new_size) #22
; call <core::ptr::non_null::NonNull<u8>>::new
  %_23 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCshVgFdEre0pE_3fmt(ptr %raw_ptr) #22
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_22 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECshVgFdEre0pE_3fmt(ptr %_23) #22
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %38 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr %_22) #22
  store ptr %38, ptr %_21, align 8
  %39 = load ptr, ptr %_21, align 8
  %40 = ptrtoint ptr %39 to i64
  %41 = icmp eq i64 %40, 0
  %_24 = select i1 %41, i64 1, i64 0
  %42 = trunc nuw i64 %_24 to i1
  br i1 %42, label %bb17, label %bb16

bb25:                                             ; preds = %bb7
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %43 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCshVgFdEre0pE_3fmt(ptr align 8 @alloc_6379aaa2812385052216e7dc8e3279fb) #22
  %44 = extractvalue { ptr, i64 } %43, 0
  %45 = extractvalue { ptr, i64 } %43, 1
  store ptr %44, ptr %_0, align 8
  %46 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %45, ptr %46, align 8
  br label %bb30

bb24:                                             ; preds = %bb7
  %new_ptr.0 = load ptr, ptr %_30, align 8
  %47 = getelementptr inbounds i8, ptr %_30, i64 8
  %new_ptr.1 = load i64, ptr %47, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_37 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCshVgFdEre0pE_3fmt(ptr %new_ptr.0, i64 %new_ptr.1) #22
  %48 = load i64, ptr %old_size, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECshVgFdEre0pE_3fmt.exit

bb2.i:                                            ; preds = %bb24
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshVgFdEre0pE_3fmt(ptr %ptr, ptr %_37, i64 1, i64 1, i64 %48, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #23
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECshVgFdEre0pE_3fmt.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECshVgFdEre0pE_3fmt.exit: ; preds = %bb24, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_37, ptr align 1 %ptr, i64 %48, i1 false)
  %49 = load i64, ptr %old_layout, align 8
  %50 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %51 = load i64, ptr %50, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCshVgFdEre0pE_3fmt(ptr %self, ptr %ptr, i64 %49, i64 %51) #22
  store ptr %new_ptr.0, ptr %_0, align 8
  %52 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %new_ptr.1, ptr %52, align 8
  br label %bb30

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %53 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCshVgFdEre0pE_3fmt(ptr align 8 @alloc_a699fef46c42b266f9e12652c07a696a) #22
  %54 = extractvalue { ptr, i64 } %53, 0
  %55 = extractvalue { ptr, i64 } %53, 1
  store ptr %54, ptr %_0, align 8
  %56 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %55, ptr %56, align 8
  br label %bb30

bb16:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %ptr1 = load ptr, ptr %_21, align 8
  br i1 %zeroed, label %bb18, label %bb20

bb20:                                             ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCshVgFdEre0pE_3fmt.exit, %bb16
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %57 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCshVgFdEre0pE_3fmt(ptr %ptr1, i64 %new_size) #22
  %_29.0 = extractvalue { ptr, i64 } %57, 0
  %_29.1 = extractvalue { ptr, i64 } %57, 1
  store ptr %_29.0, ptr %_0, align 8
  %58 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29.1, ptr %58, align 8
  br label %bb30

bb18:                                             ; preds = %bb16
  %59 = load i64, ptr %old_size, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %raw_ptr, i64 %59
  %60 = load i64, ptr %old_size, align 8
  %_28 = sub i64 %new_size, %60
; call core::ub_checks::check_language_ub
  %_4.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_4.i.i, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCshVgFdEre0pE_3fmt.exit

bb2.i.i:                                          ; preds = %bb18
  %61 = icmp eq i64 %_28, 0
  %62 = zext i1 %61 to i8
  store i8 %62, ptr %_8.i.i, align 1
  %63 = load i8, ptr %_8.i.i, align 1
  %64 = trunc nuw i8 %63 to i1
; call core::ptr::write_bytes::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr11write_bytes18precondition_checkCshVgFdEre0pE_3fmt(ptr %_0.i, i64 1, i1 zeroext %64, ptr align 8 @alloc_2fc439fdc88563e15d315d43214d38e0) #23
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCshVgFdEre0pE_3fmt.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCshVgFdEre0pE_3fmt.exit: ; preds = %bb18, %bb2.i.i
  call void @llvm.memset.p0.i64(ptr align 1 %_0.i, i8 0, i64 %_28, i1 false)
  br label %bb20

bb15:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCshVgFdEre0pE_3fmt(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !381 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCshVgFdEre0pE_3fmt(ptr %_6, i64 0) #22
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCshVgFdEre0pE_3fmt(i64 %11, i64 %13) #22
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCshVgFdEre0pE_3fmt(i64 %15, i64 %17) #22
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCshVgFdEre0pE_3fmt(ptr %_12) #22
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECshVgFdEre0pE_3fmt(ptr %_11) #22
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr %_10) #22
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCshVgFdEre0pE_3fmt(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #22
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCshVgFdEre0pE_3fmt(ptr %ptr, i64 %size) #22
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCshVgFdEre0pE_3fmt(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !382 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCshVgFdEre0pE_3fmt(ptr %ptr, i64 %3, i64 %5) #22
  br label %bb3
}

; <alloc::alloc::Global>::grow_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global9grow_implCshVgFdEre0pE_3fmt(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !383 {
start:
  %_6 = alloca [56 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %_6, i64 32
  store ptr %self, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_6, i64 40
  store ptr %ptr, ptr %1, align 8
  store i64 %old_layout.0, ptr %_6, align 8
  %2 = getelementptr inbounds i8, ptr %_6, i64 8
  store i64 %old_layout.1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_6, i64 16
  store i64 %new_layout.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %new_layout.1, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_6, i64 48
  %6 = zext i1 %zeroed to i8
  store i8 %6, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %_6, i64 32
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds i8, ptr %_6, i64 40
  %10 = load ptr, ptr %9, align 8
  %11 = load i64, ptr %_6, align 8
  %12 = getelementptr inbounds i8, ptr %_6, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = getelementptr inbounds i8, ptr %_6, i64 16
  %15 = load i64, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = getelementptr inbounds i8, ptr %_6, i64 48
  %19 = load i8, ptr %18, align 8
  %20 = trunc nuw i8 %19 to i1
; call <alloc::alloc::Global>::grow_impl_runtime
  %21 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global17grow_impl_runtimeCshVgFdEre0pE_3fmt(ptr %8, ptr %10, i64 %11, i64 %13, i64 %15, i64 %17, i1 zeroext %20) #22
  %_0.0 = extractvalue { ptr, i64 } %21, 0
  %_0.1 = extractvalue { ptr, i64 } %21, 1
  %22 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %_0.1, 1
  ret { ptr, i64 } %23
}

; <alloc::raw_vec::RawVec<u8>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE17from_raw_parts_inCshVgFdEre0pE_3fmt(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !384 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<u8>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_caphECshVgFdEre0pE_3fmt(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inCshVgFdEre0pE_3fmt(ptr %ptr, i64 %capacity2) #22
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<u8>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !385 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u8>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u8>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE6new_inCshVgFdEre0pE_3fmt() unnamed_addr #0 personality ptr @rust_eh_personality !guid !386 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<u8>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofhECshVgFdEre0pE_3fmt() #22
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCshVgFdEre0pE_3fmt(i64 %_4) #22
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<u8>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE7reserveCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #0 !guid !387 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %len, i64 %additional, i64 1, i64 1) #22
  ret void
}

; <alloc::raw_vec::RawVec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !388 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 1) #22
  ret i64 %_0
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCshVgFdEre0pE_3fmt(i32 %self) unnamed_addr #0 !guid !389 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCshVgFdEre0pE_3fmt(i32 %self) #22
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCshVgFdEre0pE_3fmt(i32 %self) unnamed_addr #0 !guid !390 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCshVgFdEre0pE_3fmt(i64 %addr) unnamed_addr #0 !guid !391 {
start:
  %_0 = inttoptr i64 %addr to ptr
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::extend_from_slice
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #1 !guid !392 {
start:
; call <[u8]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCshVgFdEre0pE_3fmt(ptr %other.0, i64 %other.1) #22
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
; call <alloc::vec::Vec<u8> as alloc::vec::spec_extend::SpecExtend<&u8, core::slice::iter::Iter<u8>>>::spec_extend
  call void @_RNvXs2_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB7_3VechEINtB5_10SpecExtendRhINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhEE11spec_extendCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %_3.0, ptr %_3.1)
  ret void
}

; <core::ptr::unique::Unique<[u8]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueShE6as_ptrCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !393 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::unique::Unique<u8>>::from_non_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCshVgFdEre0pE_3fmt(ptr %pointer) unnamed_addr #0 !guid !394 {
start:
  ret ptr %pointer
}

; <core::ptr::unique::Unique<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13new_uncheckedCshVgFdEre0pE_3fmt(ptr %ptr) unnamed_addr #0 !guid !395 {
start:
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_2 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCshVgFdEre0pE_3fmt(ptr %ptr, ptr align 8 @alloc_8e8e5d43991787ef9fba0c8fe53b59fb) #22
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !396 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[[i32; 2]; 2]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAAlj2_BW_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !397 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[core::option::Option<i32>; 2]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAINtNtB9_6option6OptionlEj2_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !398 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::option::Option<f64>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptiondEE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !399 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::option::Option<u8>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionhEE8from_refCshVgFdEre0pE_3fmt(ptr %r) unnamed_addr #0 !guid !400 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !401 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<fmt::E>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt1EE8from_refBV_(ptr align 8 %r) unnamed_addr #0 !guid !402 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<fmt::Hex>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt3HexE8from_refBV_(ptr align 4 %r) unnamed_addr #0 !guid !403 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<fmt::Money>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt5MoneyE8from_refBV_(ptr align 8 %r) unnamed_addr #0 !guid !404 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<fmt::Point>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCshVgFdEre0pE_3fmt5PointE8from_refBV_(ptr align 8 %r) unnamed_addr #0 !guid !405 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::time::Duration>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_4time8DurationE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !406 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !407 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<*const u8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullPhE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !408 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&str>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullReE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !409 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[[i32; 2]]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAlj2_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r.0, i64 %r.1) unnamed_addr #0 !guid !410 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[core::option::Option<i32>]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSINtNtB9_6option6OptionlEE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r.0, i64 %r.1) unnamed_addr #0 !guid !411 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[f64]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSdE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r.0, i64 %r.1) unnamed_addr #0 !guid !412 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCshVgFdEre0pE_3fmt(ptr %ptr.0, i64 %ptr.1, ptr align 8 %0) unnamed_addr #0 !guid !413 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %ptr.1, 1
  ret { ptr, i64 } %2

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCshVgFdEre0pE_3fmt(ptr %ptr.0, ptr align 8 %0) #23
  br label %bb3
}

; <core::ptr::non_null::NonNull<[u8]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCshVgFdEre0pE_3fmt(ptr %r.0, i64 %r.1) unnamed_addr #0 !guid !414 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[i32]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSlE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r.0, i64 %r.1) unnamed_addr #0 !guid !415 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<(i32, &str, [f64; 2])>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTlReAdj2_EE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !416 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCshVgFdEre0pE_3fmt(ptr %r) unnamed_addr #0 !guid !417 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<char>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullcE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !418 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !419 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !420 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCshVgFdEre0pE_3fmt(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !421 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCshVgFdEre0pE_3fmt(ptr %ptr, ptr align 8 %0) #23
  br label %bb3
}

; <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCshVgFdEre0pE_3fmt(ptr %self, ptr %subtracted) unnamed_addr #0 !guid !422 {
start:
; call <*mut u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCshVgFdEre0pE_3fmt(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #22
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCshVgFdEre0pE_3fmt(ptr %ptr) unnamed_addr #0 !guid !423 {
start:
  %_0 = alloca [8 x i8], align 8
; call <*mut u8>::is_null
  %_2 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCshVgFdEre0pE_3fmt(ptr %ptr) #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCshVgFdEre0pE_3fmt(ptr %ptr, ptr align 8 @alloc_e469ef44bf39c45bcb672a4bc963b9cb) #22
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <core::ptr::non_null::NonNull<i32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !424 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %r) unnamed_addr #0 !guid !425 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCshVgFdEre0pE_3fmt(ptr align 16 %r) unnamed_addr #0 !guid !426 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refCshVgFdEre0pE_3fmt(ptr align 16 %r) unnamed_addr #0 !guid !427 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<()>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulluE8from_refCshVgFdEre0pE_3fmt(ptr %r) unnamed_addr #0 !guid !428 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %r) unnamed_addr #0 !guid !429 {
start:
  ret ptr %r
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCshVgFdEre0pE_3fmt(i64 %val) unnamed_addr #0 !guid !430 {
start:
  ret i64 %val
}

; <core::num::niche_types::UsizeNoHighBit>::as_inner
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCshVgFdEre0pE_3fmt(i64 %self) unnamed_addr #0 !guid !431 {
start:
  ret i64 %self
}

; <alloc::raw_vec::RawVecInner>::needs_to_grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #0 !guid !432 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %elem_layout) #22
; call <alloc::raw_vec::RawVecInner>::capacity
  %_6 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %_7) #22
  %_0.i = sub i64 %_6, %len
  %_0 = icmp ugt i64 %additional, %_0.i
  ret i1 %_0
}

; <alloc::raw_vec::RawVecInner>::current_memory
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %0, i64 %1) unnamed_addr #0 !guid !433 {
start:
  %_17 = alloca [24 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %elem_layout) #22
  %_3 = icmp eq i64 %_4, 0
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_7 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCshVgFdEre0pE_3fmt(i64 %_8) #22
  %_6 = icmp eq i64 %_7, 0
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb2, %start
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %3, align 8
  br label %bb12

bb5:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %elem_layout) #22
  %_13 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_12 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCshVgFdEre0pE_3fmt(i64 %_13) #22
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

bb2.i:                                            ; preds = %bb5
; call <usize>::unchecked_mul::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCshVgFdEre0pE_3fmt(i64 %_10, i64 %_12, ptr align 8 @alloc_85bcb8feb56634093aba2b8644936af9) #23
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit: ; preds = %bb5, %bb2.i
  %_0.i = mul nuw i64 %_10, %_12
; call <core::alloc::layout::Layout>::align
  %_15 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCshVgFdEre0pE_3fmt(ptr align 8 %elem_layout) #22
; call <core::alloc::layout::Layout>::from_size_align_unchecked
  %4 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCshVgFdEre0pE_3fmt(i64 %_0.i, i64 %_15, ptr align 8 @alloc_17de00c3327446355700bd7db4b78ded) #22
  %layout.0 = extractvalue { i64, i64 } %4, 0
  %layout.1 = extractvalue { i64, i64 } %4, 1
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_19 = load ptr, ptr %5, align 8
; call <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
  %_18 = call ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCshVgFdEre0pE_3fmt(ptr %_19, ptr align 8 @alloc_b9419d44288097f84422e162822ba96e) #22
  store ptr %_18, ptr %_17, align 8
  %6 = getelementptr inbounds i8, ptr %_17, i64 8
  store i64 %layout.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %layout.1, ptr %7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_17, i64 24, i1 false)
  br label %bb12

bb12:                                             ; preds = %bb4, %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit
  ret void
}

; <alloc::raw_vec::RawVecInner>::set_ptr_and_cap
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15set_ptr_and_capCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %ptr.0, i64 %ptr.1, i64 %cap) unnamed_addr #0 !guid !434 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_5 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECshVgFdEre0pE_3fmt(ptr %ptr.0, i64 %ptr.1) #22
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_4 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCshVgFdEre0pE_3fmt(ptr %_5) #22
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_4, ptr %0, align 8
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_6 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCshVgFdEre0pE_3fmt(i64 %cap) #22
  store i64 %_6, ptr %self, align 8
  ret void
}

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inCshVgFdEre0pE_3fmt(ptr %ptr, i64 %cap) unnamed_addr #0 personality ptr @rust_eh_personality !guid !435 {
start:
; call <core::ptr::unique::Unique<u8>>::new_unchecked
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13new_uncheckedCshVgFdEre0pE_3fmt(ptr %ptr) #22
  br label %bb1

bb1:                                              ; preds = %start
  %0 = insertvalue { i64, ptr } poison, i64 %cap, 0
  %1 = insertvalue { i64, ptr } %0, ptr %_4, 1
  ret { i64, ptr } %1

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCshVgFdEre0pE_3fmt(i64 %align) unnamed_addr #0 personality ptr @rust_eh_personality !guid !436 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCshVgFdEre0pE_3fmt(i64 %align) #22
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_4 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCshVgFdEre0pE_3fmt(i64 %_5) #22
  br label %bb2

bb2:                                              ; preds = %bb1
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %ptr = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCshVgFdEre0pE_3fmt(ptr %_4) #22
  br label %bb3

bb3:                                              ; preds = %bb2
  %0 = insertvalue { i64, ptr } { i64 0, ptr poison }, ptr %ptr, 1
  ret { i64, ptr } %0

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 !guid !437 {
start:
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_5 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) #22
  br i1 %_5, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
  call void @_RINvNvMs2_NtCs7CppTae75M1_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1)
  br label %bb3
}

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %elem_size) unnamed_addr #0 !guid !438 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 %elem_size, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCshVgFdEre0pE_3fmt(i64 %_4) #22
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::fmt::Arguments>::from_str_nonconst
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCshVgFdEre0pE_3fmt(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !439 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr %s.0, i64 %s.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCshVgFdEre0pE_3fmt(ptr %self, i64 %len) unnamed_addr #0 !guid !440 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
  %0 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCshVgFdEre0pE_3fmt(ptr %self, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #1 !guid !441 {
start:
  %_3 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #22
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %ptr = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %layout.0 = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %layout.1 = load i64, ptr %5, align 8
  %_9 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCshVgFdEre0pE_3fmt(ptr %_9, ptr %ptr, i64 %layout.0, i64 %layout.1) #22
  br label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCshVgFdEre0pE_3fmt(i64 %capacity) unnamed_addr #0 !guid !442 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCshVgFdEre0pE_3fmt(i64 %capacity, i64 1, i64 1) #22
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::as_statically_known_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments23as_statically_known_strCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !443 {
start:
  %s = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::fmt::Arguments>::as_str
  %0 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %s, align 8
  %3 = getelementptr inbounds i8, ptr %s, i64 8
  store i64 %2, ptr %3, align 8
; call <core::option::Option<&str>>::is_some
  %_4 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionReE7is_someCshVgFdEre0pE_3fmt(ptr align 8 %s) #22
  %_3 = call i1 @llvm.is.constant.i1(i1 %_4)
  br i1 %_3, label %bb4, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb4:                                              ; preds = %start
  %4 = load ptr, ptr %s, align 8
  %5 = getelementptr inbounds i8, ptr %s, i64 8
  %6 = load i64, ptr %5, align 8
  store ptr %4, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %6, ptr %7, align 8
  br label %bb6

bb6:                                              ; preds = %bb4, %bb5
  %8 = load ptr, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  %10 = load i64, ptr %9, align 8
  %11 = insertvalue { ptr, i64 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %10, 1
  ret { ptr, i64 } %12
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !444 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECshVgFdEre0pE_3fmt(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #22
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr %_7.0, i64 %_7.1) #22
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !445 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshVgFdEre0pE_3fmt(ptr %s.0, i64 %s.1) #22
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !446 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
  %_2 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) #22
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !447 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_0 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) #22
  ret ptr %_0
}

; <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCshVgFdEre0pE_3fmt(ptr %data, i64 %len) unnamed_addr #0 !guid !448 {
start:
; call <*mut u8>::cast_slice
  %0 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCshVgFdEre0pE_3fmt(ptr %data, i64 %len) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCshVgFdEre0pE_3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 @alloc_af3623564924928dd3d563c9d84a8a0e) #22
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::slice::iter::Iter<[i32; 2]>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAlj2_E3newCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !449 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[[i32; 2]]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAlj2_E8from_refCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) #22
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[[i32; 2]]>>::cast::<[i32; 2]>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAlj2_E4castBV_ECshVgFdEre0pE_3fmt(ptr %_4.0, i64 %_4.1) #22
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw [2 x i32], ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<core::option::Option<i32>>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterINtNtB9_6option6OptionlEE3newCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !450 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[core::option::Option<i32>]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSINtNtB9_6option6OptionlEE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) #22
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[core::option::Option<i32>]>>::cast::<core::option::Option<i32>>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSINtNtBa_6option6OptionlEE4castBV_ECshVgFdEre0pE_3fmt(ptr %_4.0, i64 %_4.1) #22
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw %"core::option::Option<i32>", ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f64>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterdE3newCshVgFdEre0pE_3fmt(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !451 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[f64]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSdE8from_refCshVgFdEre0pE_3fmt(ptr align 8 %slice.0, i64 %slice.1) #22
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[f64]>>::cast::<f64>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSdE4castdECshVgFdEre0pE_3fmt(ptr %_4.0, i64 %_4.1) #22
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw double, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCshVgFdEre0pE_3fmt(ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !452 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[u8]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCshVgFdEre0pE_3fmt(ptr %slice.0, i64 %slice.1) #22
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECshVgFdEre0pE_3fmt(ptr %_4.0, i64 %_4.1) #22
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i8, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE8as_sliceCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !453 {
start:
  %_5.i = alloca [8 x i8], align 8
  %_4.i = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_9.i = load ptr, ptr %0, align 8
  %_10.i = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCshVgFdEre0pE_3fmt(ptr %_9.i, ptr %_10.i) #22
  store i64 %1, ptr %_5.i, align 8
  %2 = load i64, ptr %_5.i, align 8
; call core::slice::raw::from_raw_parts::<u8>
  %3 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECshVgFdEre0pE_3fmt(ptr %_4.i, i64 %2, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #22
  %_0.0.i = extractvalue { ptr, i64 } %3, 0
  %_0.1.i = extractvalue { ptr, i64 } %3, 1
  %_0.0 = extractvalue { ptr, i64 } %3, 0
  %_0.1 = extractvalue { ptr, i64 } %3, 1
  %4 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_0.1, 1
  ret { ptr, i64 } %5
}

; <core::slice::iter::Iter<i32>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterlE3newCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !454 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[i32]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSlE8from_refCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1) #22
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[i32]>>::cast::<i32>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4castlECshVgFdEre0pE_3fmt(ptr %_4.0, i64 %_4.1) #22
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i32, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::finish_grow
; Function Attrs: cold nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner11finish_growCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %cap, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #4 !guid !455 {
start:
  %old_layout = alloca [16 x i8], align 8
  %_11 = alloca [24 x i8], align 8
  %memory = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %new_layout = alloca [16 x i8], align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_6, i64 %cap, i64 %elem_layout.0, i64 %elem_layout.1) #22
; call <core::result::Result<core::alloc::layout::Layout, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtB7_5alloc6layout6LayoutNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %_6) #22
  %_7 = load i64, ptr %_5, align 8
  %0 = trunc nuw i64 %_7 to i1
  br i1 %0, label %bb5, label %bb4

bb5:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_5, i64 8
  %residual.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %residual.1 = load i64, ptr %2, align 8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, i64 %residual.0, i64 %residual.1, ptr align 8 @alloc_9c2bc03755f157121052fe1398e358d1) #22
  br label %bb13

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  %val.0 = load i64, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  %val.1 = load i64, ptr %4, align 8
  store i64 %val.0, ptr %new_layout, align 8
  %5 = getelementptr inbounds i8, ptr %new_layout, i64 8
  store i64 %val.1, ptr %5, align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_11, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #22
  %6 = getelementptr inbounds i8, ptr %_11, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = icmp eq i64 %7, 0
  %_12 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_12 to i1
  br i1 %9, label %bb7, label %bb11

bb7:                                              ; preds = %bb4
  %ptr = load ptr, ptr %_11, align 8
  %10 = getelementptr inbounds i8, ptr %_11, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = getelementptr inbounds i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  store i64 %11, ptr %old_layout, align 8
  %14 = getelementptr inbounds i8, ptr %old_layout, i64 8
  store i64 %13, ptr %14, align 8
; call <core::alloc::layout::Layout>::align
  %_17 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCshVgFdEre0pE_3fmt(ptr align 8 %old_layout) #22
; call <core::alloc::layout::Layout>::align
  %_19 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCshVgFdEre0pE_3fmt(ptr align 8 %new_layout) #22
  %_16 = icmp eq i64 %_17, %_19
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb7
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i1 zeroext %_16, ptr align 8 @alloc_02ed5979549ad728dcb1e213f787b0ae) #23
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb7, %bb2.i
  %_21 = getelementptr inbounds i8, ptr %self, i64 16
  %15 = load i64, ptr %old_layout, align 8
  %16 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = load i64, ptr %new_layout, align 8
  %19 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %20 = load i64, ptr %19, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::grow
  %21 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator4growCshVgFdEre0pE_3fmt(ptr %_21, ptr %ptr, i64 %15, i64 %17, i64 %18, i64 %20) #22
  %22 = extractvalue { ptr, i64 } %21, 0
  %23 = extractvalue { ptr, i64 } %21, 1
  store ptr %22, ptr %memory, align 8
  %24 = getelementptr inbounds i8, ptr %memory, i64 8
  store i64 %23, ptr %24, align 8
  br label %bb12

bb11:                                             ; preds = %bb4
  %_22 = getelementptr inbounds i8, ptr %self, i64 16
  %25 = load i64, ptr %new_layout, align 8
  %26 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %27 = load i64, ptr %26, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %28 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCshVgFdEre0pE_3fmt(ptr %_22, i64 %25, i64 %27) #22
  %29 = extractvalue { ptr, i64 } %28, 0
  %30 = extractvalue { ptr, i64 } %28, 1
  store ptr %29, ptr %memory, align 8
  %31 = getelementptr inbounds i8, ptr %memory, i64 8
  store i64 %30, ptr %31, align 8
  br label %bb12

bb12:                                             ; preds = %bb11, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_23.0 = load ptr, ptr %memory, align 8
  %32 = getelementptr inbounds i8, ptr %memory, i64 8
  %_23.1 = load i64, ptr %32, align 8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError>>::map_err::<alloc::collections::TryReserveError, <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtNtB5_3ptr8non_null7NonNullShENtNtB5_5alloc10AllocErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvMs5_NtB1S_7raw_vecNtB2O_11RawVecInner11finish_grow0ECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %_23.0, i64 %_23.1, ptr align 8 %new_layout) #22
  br label %bb13

bb13:                                             ; preds = %bb5, %bb12
  ret void

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::grow_amortized
; Function Attrs: nonlazybind uwtable
define internal { i64, i64 } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #1 !guid !456 {
start:
  %_26 = alloca [24 x i8], align 8
  %_25 = alloca [24 x i8], align 8
  %_11 = alloca [16 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %elem_layout) #22
  %_5 = icmp eq i64 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; call <usize>::checked_add
  %3 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCshVgFdEre0pE_3fmt(i64 %len, i64 %additional) #22
  %_12.0 = extractvalue { i64, i64 } %3, 0
  %_12.1 = extractvalue { i64, i64 } %3, 1
; call <core::option::Option<usize>>::ok_or::<alloc::collections::TryReserveErrorKind>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE5ok_orNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_11, i64 %_12.0, i64 %_12.1, i64 0, i64 undef) #22
; call <core::result::Result<usize, alloc::collections::TryReserveErrorKind> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultjNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_10, ptr align 8 %_11) #22
  %4 = load i64, ptr %_10, align 8
  %5 = icmp eq i64 %4, -1
  %_14 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_14 to i1
  br i1 %6, label %bb10, label %bb9

bb2:                                              ; preds = %start
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCshVgFdEre0pE_3fmt(i64 0, i64 undef, ptr align 8 @alloc_289c68237f406b28ee6ba245eefcd312) #22
  %_8.0 = extractvalue { i64, i64 } %7, 0
  %_8.1 = extractvalue { i64, i64 } %7, 1
  store i64 %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8.1, ptr %8, align 8
  br label %bb21

bb10:                                             ; preds = %bb4
  %residual.02 = load i64, ptr %_10, align 8
  %9 = getelementptr inbounds i8, ptr %_10, i64 8
  %residual.13 = load i64, ptr %9, align 8
; call <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveErrorKind>>>::from_residual
  %10 = call { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtBN_19TryReserveErrorKindEE13from_residualCshVgFdEre0pE_3fmt(i64 %residual.02, i64 %residual.13, ptr align 8 @alloc_91dabd4c1d2514ecf79277c06422ef65) #22
  %11 = extractvalue { i64, i64 } %10, 0
  %12 = extractvalue { i64, i64 } %10, 1
  store i64 %11, ptr %_0, align 8
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %12, ptr %13, align 8
  br label %bb21

bb9:                                              ; preds = %bb4
  %14 = getelementptr inbounds i8, ptr %_10, i64 8
  %required_cap = load i64, ptr %14, align 8
  %_20 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_19 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCshVgFdEre0pE_3fmt(i64 %_20) #22
  %_18 = mul i64 %_19, 2
; call core::cmp::max::<usize>
  %cap = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECshVgFdEre0pE_3fmt(i64 %_18, i64 %required_cap) #22
; call <core::alloc::layout::Layout>::size
  %_23 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %elem_layout) #22
; call alloc::raw_vec::min_non_zero_cap
  %_22 = call i64 @_RNvNtCs7CppTae75M1_5alloc7raw_vec16min_non_zero_cap(i64 %_23)
; call core::cmp::max::<usize>
  %cap1 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECshVgFdEre0pE_3fmt(i64 %_22, i64 %cap) #22
  %15 = load i64, ptr %elem_layout, align 8
  %16 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %17 = load i64, ptr %16, align 8
; call <alloc::raw_vec::RawVecInner>::finish_grow
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner11finish_growCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_26, ptr align 8 %self, i64 %cap1, i64 %15, i64 %17)
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_25, ptr align 8 %_26) #22
  %_28 = load i64, ptr %_25, align 8
  %18 = trunc nuw i64 %_28 to i1
  br i1 %18, label %bb19, label %bb18

bb19:                                             ; preds = %bb9
  %19 = getelementptr inbounds i8, ptr %_25, i64 8
  %residual.0 = load i64, ptr %19, align 8
  %20 = getelementptr inbounds i8, ptr %19, i64 8
  %residual.1 = load i64, ptr %20, align 8
; call <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
  %21 = call { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCshVgFdEre0pE_3fmt(i64 %residual.0, i64 %residual.1, ptr align 8 @alloc_8b924c2e6c70ef47ed23cadbb79c2da4) #22
  %22 = extractvalue { i64, i64 } %21, 0
  %23 = extractvalue { i64, i64 } %21, 1
  store i64 %22, ptr %_0, align 8
  %24 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %23, ptr %24, align 8
  br label %bb21

bb18:                                             ; preds = %bb9
  %25 = getelementptr inbounds i8, ptr %_25, i64 8
  %ptr.0 = load ptr, ptr %25, align 8
  %26 = getelementptr inbounds i8, ptr %25, i64 8
  %ptr.1 = load i64, ptr %26, align 8
; call <alloc::raw_vec::RawVecInner>::set_ptr_and_cap
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15set_ptr_and_capCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %ptr.0, i64 %ptr.1, i64 %cap1) #22
  store i64 -1, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb2, %bb10, %bb19, %bb18
  %27 = load i64, ptr %_0, align 8
  %28 = getelementptr inbounds i8, ptr %_0, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { i64, i64 } poison, i64 %27, 0
  %31 = insertvalue { i64, i64 } %30, i64 %29, 1
  ret { i64, i64 } %31

bb8:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::try_allocate_in
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, i64 %capacity, i1 zeroext %init, i64 %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !457 {
start:
  %_32 = alloca [1 x i8], align 1
  %_31 = alloca [1 x i8], align 1
  %result = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %layout = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  %alloc = alloca [0 x i8], align 1
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_31, align 1
  store i8 0, ptr %_32, align 1
  store i8 1, ptr %_31, align 1
  %3 = load i64, ptr %elem_layout, align 8
  %4 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_6, i64 %capacity, i64 %3, i64 %5) #22
  br label %bb1

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %_6, align 8
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCshVgFdEre0pE_3fmt(i64 0, i64 undef, ptr align 8 @alloc_099d793709fa470a3d5e7c79c938e035) #22
  %_9.0 = extractvalue { i64, i64 } %7, 0
  %_9.1 = extractvalue { i64, i64 } %7, 1
  br label %bb5

bb4:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %_6, i64 8
  %layout.0 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %layout.1 = load i64, ptr %9, align 8
  store i64 %layout.0, ptr %layout, align 8
  %10 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %layout.1, ptr %10, align 8
; call <core::alloc::layout::Layout>::size
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
  br label %bb6

bb6:                                              ; preds = %bb4
  %_11 = icmp eq i64 %_12, 0
  br i1 %_11, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  %_19 = zext i1 %init to i64
  %11 = trunc nuw i64 %_19 to i1
  br i1 %11, label %bb11, label %bb12

bb7:                                              ; preds = %bb6
  store i8 0, ptr %_31, align 1
  store i8 1, ptr %_32, align 1
; call <core::alloc::layout::Layout>::alignment
  %_16 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshVgFdEre0pE_3fmt(ptr align 8 %elem_layout) #22
  br label %bb8

bb11:                                             ; preds = %bb10
  %12 = load i64, ptr %layout, align 8
  %13 = getelementptr inbounds i8, ptr %layout, i64 8
  %14 = load i64, ptr %13, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
  %15 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCshVgFdEre0pE_3fmt(ptr %alloc, i64 %12, i64 %14) #22
  %16 = extractvalue { ptr, i64 } %15, 0
  %17 = extractvalue { ptr, i64 } %15, 1
  store ptr %16, ptr %result, align 8
  %18 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb28

bb12:                                             ; preds = %bb10
  %19 = load i64, ptr %layout, align 8
  %20 = getelementptr inbounds i8, ptr %layout, i64 8
  %21 = load i64, ptr %20, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %22 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCshVgFdEre0pE_3fmt(ptr %alloc, i64 %19, i64 %21) #22
  %23 = extractvalue { ptr, i64 } %22, 0
  %24 = extractvalue { ptr, i64 } %22, 1
  store ptr %23, ptr %result, align 8
  %25 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %24, ptr %25, align 8
  br label %bb29

bb29:                                             ; preds = %bb12
  br label %bb13

bb13:                                             ; preds = %bb28, %bb29
  %26 = load ptr, ptr %result, align 8
  %27 = getelementptr inbounds i8, ptr %result, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = ptrtoint ptr %26 to i64
  %30 = icmp eq i64 %29, 0
  %_22 = select i1 %30, i64 1, i64 0
  %31 = trunc nuw i64 %_22 to i1
  br i1 %31, label %bb14, label %bb15

bb28:                                             ; preds = %bb11
  br label %bb13

bb14:                                             ; preds = %bb13
  %_25.0 = load i64, ptr %layout, align 8
  %32 = getelementptr inbounds i8, ptr %layout, i64 8
  %_25.1 = load i64, ptr %32, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %33 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCshVgFdEre0pE_3fmt(i64 %_25.0, i64 %_25.1, ptr align 8 @alloc_33dfd402c6ecbe2e6a32e76edf5f31a5) #22
  %_24.0 = extractvalue { i64, i64 } %33, 0
  %_24.1 = extractvalue { i64, i64 } %33, 1
  br label %bb16

bb15:                                             ; preds = %bb13
  %ptr.0 = load ptr, ptr %result, align 8
  %34 = getelementptr inbounds i8, ptr %result, i64 8
  %ptr.1 = load i64, ptr %34, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_28 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECshVgFdEre0pE_3fmt(ptr %ptr.0, i64 %ptr.1) #22
  br label %bb17

bb17:                                             ; preds = %bb15
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_27 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCshVgFdEre0pE_3fmt(ptr %_28) #22
  br label %bb18

bb18:                                             ; preds = %bb17
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_29 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCshVgFdEre0pE_3fmt(i64 %capacity) #22
  br label %bb19

bb19:                                             ; preds = %bb18
  store i8 0, ptr %_31, align 1
  %35 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29, ptr %35, align 8
  %36 = getelementptr inbounds i8, ptr %35, i64 8
  store ptr %_27, ptr %36, align 8
  store i64 0, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb23, %bb20, %bb19
  ret void

bb16:                                             ; preds = %bb14
  %37 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_24.0, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %37, i64 8
  store i64 %_24.1, ptr %38, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb20:                                             ; preds = %bb5, %bb9, %bb16
  %39 = load i8, ptr %_31, align 1
  %40 = trunc nuw i8 %39 to i1
  br i1 %40, label %bb23, label %bb21

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_32, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %41 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCshVgFdEre0pE_3fmt(i64 %_16) #22
  %_14.0 = extractvalue { i64, ptr } %41, 0
  %_14.1 = extractvalue { i64, ptr } %41, 1
  br label %bb9

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_32, align 1
  %42 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_14.0, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %42, i64 8
  store ptr %_14.1, ptr %43, align 8
  store i64 0, ptr %_0, align 8
  br label %bb20

bb5:                                              ; preds = %bb3
  %44 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_9.0, ptr %44, align 8
  %45 = getelementptr inbounds i8, ptr %44, i64 8
  store i64 %_9.1, ptr %45, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb23:                                             ; preds = %bb20
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable

bb25:                                             ; No predecessors!
  unreachable

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCshVgFdEre0pE_3fmt(i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !458 {
start:
  %this = alloca [16 x i8], align 8
  %_4 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::try_allocate_in
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_4, i64 %capacity, i1 zeroext false, i64 %elem_layout.0, i64 %elem_layout.1)
  %_6 = load i64, ptr %_4, align 8
  %0 = trunc nuw i64 %_6 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  %err.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %err.1 = load i64, ptr %2, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #24
  unreachable

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load ptr, ptr %5, align 8
  store i64 %4, ptr %this, align 8
  %7 = getelementptr inbounds i8, ptr %this, i64 8
  store ptr %6, ptr %7, align 8
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_10 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCshVgFdEre0pE_3fmt(ptr align 8 %this, i64 0, i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) #22
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = xor i1 %_10, true
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb5
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i1 zeroext %_9, ptr align 8 @alloc_51424262946dd0794fad6132df857999) #23
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb5, %bb2.i
  br label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_0.0 = load i64, ptr %this, align 8
  %8 = getelementptr inbounds i8, ptr %this, i64 8
  %_0.1 = load ptr, ptr %8, align 8
  %9 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %10 = insertvalue { i64, ptr } %9, ptr %_0.1, 1
  ret { i64, ptr } %10

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <core::num::niche_types::Nanoseconds>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB5_11Nanoseconds13new_uncheckedCshVgFdEre0pE_3fmt(i32 %val) unnamed_addr #0 !guid !459 {
start:
  ret i32 %val
}

; <alloc::boxed::Box<[u8]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxShE23into_raw_with_allocatorCshVgFdEre0pE_3fmt(ptr %b.0, i64 %b.1) unnamed_addr #0 !guid !460 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[u8]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxShEE3newCshVgFdEre0pE_3fmt(ptr %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[u8]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxShEE6as_mutCshVgFdEre0pE_3fmt(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[u8]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxShEE6as_refCshVgFdEre0pE_3fmt(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshVgFdEre0pE_3fmt(ptr %self) unnamed_addr #0 !guid !461 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCshVgFdEre0pE_3fmt(i64 %self, i64 %rhs) unnamed_addr #0 !guid !462 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5.0 = add i64 %self, %rhs
  %_5.1 = icmp ult i64 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCshVgFdEre0pE_3fmt(i64 %self, i64 %rhs) unnamed_addr #0 !guid !463 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCshVgFdEre0pE_3fmt(i64 %self, i64 %other) unnamed_addr #0 !guid !464 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCshVgFdEre0pE_3fmt(i32 %_0.i) #22
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <alloc::vec::Vec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !465 {
start:
; call <alloc::raw_vec::RawVec<u8>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCshVgFdEre0pE_3fmt(i64 %capacity) #22
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshVgFdEre0pE_3fmt(i8 %0) unnamed_addr #0 !guid !466 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshVgFdEre0pE_3fmt(ptr %self) #22
  ret i32 %_0
}

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !467 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::append_elements
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE15append_elementsCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !468 {
start:
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECshVgFdEre0pE_3fmt(ptr %other.0, i64 %other.1) #22
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %_0.i)
; call <alloc::vec::Vec<u8>>::append_elements_unreserved
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE26append_elements_unreservedCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %other.0, i64 %other.1) #22
  ret void
}

; <alloc::vec::Vec<u8>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE17from_raw_parts_inCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !469 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCshVgFdEre0pE_3fmt(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #23
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<u8>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE17from_raw_parts_inCshVgFdEre0pE_3fmt(ptr %ptr, i64 %capacity) #22
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u8>>::append_elements_unreserved
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE26append_elements_unreservedCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !470 {
start:
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECshVgFdEre0pE_3fmt(ptr %other.0, i64 %other.1) #22
; call <alloc::vec::Vec<u8>>::len
  %len = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %_6 = icmp ugt i64 %_0.i1, 0
  br i1 %_6, label %bb3, label %bb6

bb6:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECshVgFdEre0pE_3fmt.exit, %start
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i64, ptr %1, align 8
  %3 = add i64 %2, %_0.i1
  store i64 %3, ptr %0, align 8
  ret void

bb3:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() #22
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECshVgFdEre0pE_3fmt.exit

bb2.i:                                            ; preds = %bb3
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshVgFdEre0pE_3fmt(ptr %other.0, ptr %_0.i, i64 1, i64 1, i64 %_0.i1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #23
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECshVgFdEre0pE_3fmt.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECshVgFdEre0pE_3fmt.exit: ; preds = %bb3, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i, ptr align 1 %other.0, i64 %_0.i1, i1 false)
  br label %bb6
}

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !471 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 9223372036854775807
  ret i64 %len
}

; <alloc::vec::Vec<u8>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE6as_ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !472 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  ret ptr %_2
}

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %additional) unnamed_addr #1 !guid !473 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<u8>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE7reserveCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %_5, i64 %additional) #22
  ret void
}

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !474 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCshVgFdEre0pE_3fmt(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #23
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !475 {
start:
; call <alloc::vec::Vec<u8>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE6as_ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !476 {
start:
; call <alloc::raw_vec::RawVec<u8>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  ret i64 %_0
}

; <*mut u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCshVgFdEre0pE_3fmt(ptr %self, i64 %len) unnamed_addr #0 !guid !477 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECshVgFdEre0pE_3fmt(ptr %self, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCshVgFdEre0pE_3fmt(i64 %self) unnamed_addr #0 !guid !478 {
start:
  ret i64 %self
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !479 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCshVgFdEre0pE_3fmt(ptr align 8 %args) #22
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #22
  ret void
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCshVgFdEre0pE_3fmt(i64 %0, i64 %1) unnamed_addr #0 !guid !480 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #28
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #28
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCshVgFdEre0pE_3fmt(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !481 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #28
  ret void
}

; alloc::alloc::realloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc15realloc_nonnullCshVgFdEre0pE_3fmt(ptr %ptr, i64 %0, i64 %1, i64 %new_size) unnamed_addr #0 !guid !482 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
; call __rustc::__rust_realloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc14___rust_realloc(ptr %ptr, i64 %_4, i64 %_6, i64 %new_size) #28
  ret ptr %_0
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCshVgFdEre0pE_3fmt(i64 %0, i64 %1) unnamed_addr #0 !guid !483 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #28
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #28
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshVgFdEre0pE_3fmt(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !484 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCshVgFdEre0pE_3fmt(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #22
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #24
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCshVgFdEre0pE_3fmt(ptr %ptr.0, i64 %ptr.1) #22
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; alloc::raw_vec::layout_array
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, i64 %cap, i64 %0, i64 %1) unnamed_addr #0 !guid !485 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::repeat_packed
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCshVgFdEre0pE_3fmt(ptr align 8 %elem_layout, i64 %cap) #22
  %_3.0 = extractvalue { i64, i64 } %3, 0
  %_3.1 = extractvalue { i64, i64 } %3, 1
; call <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, i64 %_3.0, i64 %_3.1) #22
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCshVgFdEre0pE_3fmt() unnamed_addr #5 !guid !486 {
start:
  ret void
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCshVgFdEre0pE_3fmt(ptr %ptr, i64 %align) unnamed_addr #0 !guid !487 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCshVgFdEre0pE_3fmt(ptr %ptr, i64 %align) #22
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshVgFdEre0pE_3fmt() unnamed_addr #0 !guid !488 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCshVgFdEre0pE_3fmt() #22
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCshVgFdEre0pE_3fmt(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !489 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCshVgFdEre0pE_3fmt(ptr %3, ptr %5, i64 %7, i64 %9) #22
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCshVgFdEre0pE_3fmt(i64 %size, i64 %len) unnamed_addr #0 !guid !490 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #27
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshVgFdEre0pE_3fmt(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !491 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCshVgFdEre0pE_3fmt(ptr %ptr, i64 %align) #22
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCshVgFdEre0pE_3fmt(ptr %ptr) #22
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !492 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCshVgFdEre0pE_3fmt(i32 %code, ptr %dst) unnamed_addr #0 !guid !493 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CshVgFdEre0pE_3fmt(i32 %code) #22
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CshVgFdEre0pE_3fmt(i32 %code) unnamed_addr #0 !guid !494 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i64 %align, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !495 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCshVgFdEre0pE_3fmt(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !496 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCshVgFdEre0pE_3fmt(ptr %ptr) unnamed_addr #0 !guid !497 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !498 {
start:
; invoke <core::alloc::layout::Layout>::is_size_align_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCshVgFdEre0pE_3fmt(i64 %size, i64 %align)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_1be5ea12ba708d9a11b6e93a7d387a75, i64 281)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !499 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCshVgFdEre0pE_3fmt(ptr %ptr, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !500 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCshVgFdEre0pE_3fmt(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <usize>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCshVgFdEre0pE_3fmt(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !501 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCshVgFdEre0pE_3fmt(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !502 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCshVgFdEre0pE_3fmt(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !503 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; core::ptr::write_bytes::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr11write_bytes18precondition_checkCshVgFdEre0pE_3fmt(ptr %addr, i64 %align, i1 zeroext %zero_size, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !504 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_4 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshVgFdEre0pE_3fmt(ptr %addr, i64 %align, i1 zeroext %zero_size)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_dd79dfae92e8fdc23813c4c7a1b7cf72, i64 228)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_6.0 = extractvalue { ptr, ptr } %2, 0
  %_6.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshVgFdEre0pE_3fmt(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !505 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshVgFdEre0pE_3fmt(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshVgFdEre0pE_3fmt(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCshVgFdEre0pE_3fmt(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCshVgFdEre0pE_3fmt(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !506 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCshVgFdEre0pE_3fmt(ptr %ptr, i64 %align) unnamed_addr #0 !guid !507 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCshVgFdEre0pE_3fmt(ptr %ptr, i64 %align) #22
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCshVgFdEre0pE_3fmt() unnamed_addr #0 !guid !508 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCshVgFdEre0pE_3fmt(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !509 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCshVgFdEre0pE_3fmt(i64 %size, i64 %count) #22
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCshVgFdEre0pE_3fmt(i64 %_0.i2, i64 %_0.i) #22
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #26
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCshVgFdEre0pE_3fmt(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !510 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshVgFdEre0pE_3fmt(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshVgFdEre0pE_3fmt(ptr @alloc_a28e8c8fd5088943a8b5d44af697ff83, i64 279)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCshVgFdEre0pE_3fmt(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <fmt::Money as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXCshVgFdEre0pE_3fmtNtB2_5MoneyNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !511 {
start:
  %0 = alloca [16 x i8], align 8
  %_23 = alloca [16 x i8], align 8
  %_22 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_15 = alloca [8 x i8], align 8
  %_8 = alloca [8 x i8], align 8
  %_4 = alloca [24 x i8], align 8
  %s = alloca [24 x i8], align 8
  %_9 = load i64, ptr %self, align 8
  %_12 = icmp eq i64 %_9, -9223372036854775808
  %_13 = and i1 false, %_12
  br i1 %_13, label %panic, label %bb2

bb2:                                              ; preds = %start
  %1 = sdiv i64 %_9, 100
  store i64 %1, ptr %_8, align 8
  %_16 = load i64, ptr %self, align 8
  %_19 = icmp eq i64 %_16, -9223372036854775808
  %_20 = and i1 false, %_19
  br i1 %_20, label %panic1, label %bb4

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_78648a3da0583c3a93ec45d48e44c913) #27
  unreachable

bb4:                                              ; preds = %bb2
  %2 = srem i64 %_16, 100
  store i64 %2, ptr %_15, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_22, ptr align 8 %_8) #22
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_23, ptr align 8 %_15) #22
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_22, i64 16, i1 false)
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_23, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 2>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj2_ECshVgFdEre0pE_3fmt(ptr @alloc_6ddf87a275032c244ec296015b313b7a, ptr align 8 %args) #22
  %_5.0 = extractvalue { ptr, ptr } %5, 0
  %_5.1 = extractvalue { ptr, ptr } %5, 1
; call alloc::fmt::format
  call void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_4, ptr %_5.0, ptr %_5.1) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %s, ptr align 8 %_4, i64 24, i1 false)
; invoke <alloc::string::String as core::ops::deref::Deref>::deref
  %6 = invoke { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %s)
          to label %bb10 unwind label %cleanup

panic1:                                           ; preds = %bb2
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_2a7a4456520952dbf8a616376b1f7793) #27
  unreachable

bb13:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr align 8 %s) #20
          to label %bb14 unwind label %terminate

cleanup:                                          ; preds = %bb10, %bb4
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb13

bb10:                                             ; preds = %bb4
  %_26.0 = extractvalue { ptr, i64 } %6, 0
  %_26.1 = extractvalue { ptr, i64 } %6, 1
; invoke <core::fmt::Formatter>::pad
  %_0 = invoke zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3pad(ptr align 8 %f, ptr %_26.0, i64 %_26.1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECshVgFdEre0pE_3fmt(ptr align 8 %s)
  ret i1 %_0

terminate:                                        ; preds = %bb13
  %11 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb14:                                             ; preds = %bb13
  %12 = load ptr, ptr %0, align 8
  %13 = getelementptr inbounds i8, ptr %0, i64 8
  %14 = load i32, ptr %13, align 8
  %15 = insertvalue { ptr, i32 } poison, ptr %12, 0
  %16 = insertvalue { ptr, i32 } %15, i32 %14, 1
  resume { ptr, i32 } %16
}

; <core::slice::iter::Iter<[i32; 2]> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterAlj2_ENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !512 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<core::option::Option<i32>> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterINtNtB8_6option6OptionlEENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !513 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<f64> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterdENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !514 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<u8> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterhENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !515 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCshVgFdEre0pE_3fmt(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !516 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <fmt::Point as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs0_CshVgFdEre0pE_3fmtNtB5_5PointNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !517 {
start:
  %_13 = alloca [8 x i8], align 8
  %_6 = getelementptr inbounds i8, ptr %self, i64 16
  %_9 = getelementptr inbounds i8, ptr %self, i64 20
  store ptr %self, ptr %_13, align 8
; call <core::fmt::Formatter>::debug_struct_field3_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field3_finish(ptr align 8 %f, ptr @alloc_bf0ef947d182249ea2203578272460c5, i64 5, ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, i64 1, ptr %_6, ptr align 8 @vtable.7, ptr @alloc_cd51bc84b49b21a3fdb2800731f25c21, i64 1, ptr %_9, ptr align 8 @vtable.8, ptr @alloc_125af81ac88d8b2d4254bab0c6fa4f63, i64 3, ptr %_13, ptr align 8 @vtable.9)
  ret i1 %_0
}

; <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCshVgFdEre0pE_3fmt(i64 %kind.0, i64 %kind.1) unnamed_addr #0 !guid !518 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %kind.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %kind.1, 1
  ret { i64, i64 } %1
}

; <(i32, &str, [f64; 2]) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1F_NtCsl10jNU3mE6R_4core3fmtTlReAdj2_ENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !519 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %V = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %0, ptr %V, align 8
  store ptr %self, ptr %U, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 24
  store ptr %1, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_8 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %V, ptr align 8 @vtable.4)
; call <core::fmt::builders::DebugTuple>::field
  %_12 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.a)
; call <core::fmt::builders::DebugTuple>::field
  %_16 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.b)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <(i8, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTabENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #1 !guid !520 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.c)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.d)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCshVgFdEre0pE_3fmt(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !521 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCshVgFdEre0pE_3fmt(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #22
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCshVgFdEre0pE_3fmt(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !522 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCshVgFdEre0pE_3fmt(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext true) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator4growCshVgFdEre0pE_3fmt(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1) unnamed_addr #0 !guid !523 {
start:
; call <alloc::alloc::Global>::grow_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global9grow_implCshVgFdEre0pE_3fmt(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1, i1 zeroext false) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCshVgFdEre0pE_3fmt(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !524 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCshVgFdEre0pE_3fmt(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #1 !guid !525 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 1, i64 1)
  ret void
}

; <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %0) unnamed_addr #0 !guid !526 {
start:
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_0 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCshVgFdEre0pE_3fmt(ptr %self) #22
  ret ptr %_0
}

; <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCshVgFdEre0pE_3fmt(i64 %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !527 {
start:
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCshVgFdEre0pE_3fmt(i64 %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <&str as core::convert::Into<alloc::string::String>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !528 {
start:
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #22
  ret void
}

; <&[f64; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAdj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !529 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <[f64; 2] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAdj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&[i32; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAlj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !530 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <[i32; 2] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAlj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&core::option::Option<&str> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionReENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !531 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::option::Option<&str> as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionReENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&core::option::Option<i32> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionlENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !532 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::option::Option<i32> as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !533 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <alloc::string::String as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&&str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !534 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <&str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtReNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&[[i32; 2]] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSAlj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !535 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[[i32; 2]] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSAlj2_NtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[core::option::Option<i32>] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSINtNtB8_6option6OptionlENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !536 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[core::option::Option<i32>] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSINtNtB7_6option6OptionlENtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[f64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSdNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !537 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[f64] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSdNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSlNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !538 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[i32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&(i8, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRTabENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !539 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <(i8, bool) as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTabENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&i8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !540 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !541 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !542 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <f64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtReNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !543 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !544 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !545 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i32 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtReNtB6_7Display3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !546 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <core::slice::iter::Iter<[i32; 2]> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterAlj2_ENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !547 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<[i32; 2]> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAlj2_ENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %ptr, ptr align 8 %_11) #22
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw [2 x i32], ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<core::option::Option<i32>> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterINtNtBa_6option6OptionlEENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !548 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i32>> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %ptr, ptr align 8 %_11) #22
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw %"core::option::Option<i32>", ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !549 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %ptr, ptr align 8 %_11) #22
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw double, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !550 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %ptr, ptr align 8 %_11) #22
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw i8, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !551 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<i32> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %ptr, ptr align 8 %_11) #22
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw i32, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !552 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #22
  ret void
}

; <alloc::vec::Vec<u8> as alloc::vec::spec_extend::SpecExtend<&u8, core::slice::iter::Iter<u8>>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs2_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB7_3VechEINtB5_10SpecExtendRhINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhEE11spec_extendCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #1 !guid !553 {
start:
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %2 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %2, align 8
; call <core::slice::iter::Iter<u8>>::as_slice
  %3 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE8as_sliceCshVgFdEre0pE_3fmt(ptr align 8 %iterator) #22
  %slice.0 = extractvalue { ptr, i64 } %3, 0
  %slice.1 = extractvalue { ptr, i64 } %3, 1
; call <alloc::vec::Vec<u8>>::append_elements
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE15append_elementsCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %slice.0, i64 %slice.1) #22
  ret void
}

; <fmt::E as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_CshVgFdEre0pE_3fmtNtB5_1ENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !554 {
start:
  %__self_11 = alloca [8 x i8], align 8
  %__self_1 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %_3 = zext i8 %0 to i64
  switch i64 %_3, label %bb1 [
    i64 0, label %bb4
    i64 1, label %bb3
    i64 2, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb4:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %1 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_13c56e54a9571211dcad2a135c9eaa2b, i64 4)
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %start
  %__self_0 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_1, align 8
; call <core::fmt::Formatter>::debug_tuple_field2_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field2_finish(ptr align 8 %f, ptr @alloc_8388317ddce58f972b519ce81ee4ed85, i64 3, ptr %__self_0, ptr align 8 @vtable.e, ptr %__self_1, ptr align 8 @vtable.f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb5

bb2:                                              ; preds = %start
  %__self_02 = getelementptr inbounds i8, ptr %self, i64 8
  %6 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %6, ptr %__self_11, align 8
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr align 8 %f, ptr @alloc_3b31bdf1fe846135477a792935103ed1, i64 3, ptr @alloc_3827bbb606bbdb0f0c926011c14ccc34, i64 1, ptr %__self_02, ptr align 8 @vtable.g, ptr @alloc_ab7766fee1e1b94f8c00ce7ffec41c7e, i64 1, ptr %__self_11, ptr align 8 @vtable.h)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3, %bb4
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10
}

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !555 {
start:
; call <[u8]>::to_vec
  call void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #22
  ret void
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[[i32; 2]]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSAlj2_E5indexCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !556 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[core::option::Option<i32>]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSINtNtB9_6option6OptionlEE5indexCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !557 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[f64]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSdE5indexCshVgFdEre0pE_3fmt(ptr align 8 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !558 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i32]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSlE5indexCshVgFdEre0pE_3fmt(ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !559 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<u8> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !560 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::boxed::Box<[u8]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxShENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !561 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[u8]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueShE6as_ptrCshVgFdEre0pE_3fmt(ptr %ptr.0, i64 %ptr.1) #22
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[u8]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawShECshVgFdEre0pE_3fmt(ptr %_5.0, i64 %_5.1) #22
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshVgFdEre0pE_3fmt(ptr align 8 %layout) #22
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[u8]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueShE4casthECshVgFdEre0pE_3fmt(ptr %ptr.0, i64 %ptr.1) #22
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCshVgFdEre0pE_3fmt(ptr %_12) #22
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCshVgFdEre0pE_3fmt(ptr %_10, ptr %_11, i64 %6, i64 %8) #22
  br label %bb7
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !562 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #22
  ret void
}

; <core::fmt::Error as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsK_NtCsl10jNU3mE6R_4core3fmtNtB5_5ErrorNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !563 {
start:
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_99ac8a81a24cac863217ce4a5cbfabea, i64 5)
  ret i1 %_0
}

; <i8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !564 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <i32 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !565 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i32 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i32 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i32 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::option::Option<&str> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionReENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !566 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq i64 %3, 0
  %_3 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.a)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %8 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %10 = load i8, ptr %_0, align 1
  %11 = trunc nuw i8 %10 to i1
  ret i1 %11

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<f64> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptiondENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !567 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %_3 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load double, ptr %0, align 8
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.2)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u8> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionhENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !568 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.3)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %8 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %10 = load i8, ptr %_0, align 1
  %11 = trunc nuw i8 %10 to i1
  ret i1 %11

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<i32> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !569 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i32, ptr %self, align 4
  %1 = getelementptr inbounds i8, ptr %self, i64 4
  %2 = load i32, ptr %1, align 4
  %_3 = zext i32 %0 to i64
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  store ptr %4, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.4)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <i128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !570 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshVgFdEre0pE_3fmt() unnamed_addr #0 !guid !571 {
start:
  ret i8 0
}

; <u8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !572 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <u32 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsW_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !573 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u32 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsu_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u32 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt(ptr align 4 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u32 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsw_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8UpperHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <u128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !574 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <alloc::string::String as core::fmt::Write>::write_char
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write10write_charCshVgFdEre0pE_3fmt(ptr align 8 %self, i32 %c) unnamed_addr #0 !guid !575 {
start:
; call <alloc::string::String>::push
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCshVgFdEre0pE_3fmt(ptr align 8 %self, i32 %c) #22
  ret i1 false
}

; <alloc::string::String as core::fmt::Write>::write_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_strCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !576 {
start:
; call <alloc::string::String>::push_str
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %s.0, i64 %s.1) #22
  ret i1 false
}

; <fmt::Hex as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs_CshVgFdEre0pE_3fmtNtB4_3HexNtNtCsl10jNU3mE6R_4core3fmt8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !577 {
start:
; call <u32 as core::fmt::LowerHex>::fmt
  %_0 = call zeroext i1 @_RNvXsu_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  ret i1 %_0
}

; <&mut alloc::string::String as core::fmt::Write::write_fmt::SpecWriteFmt>::spec_write_fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs_NvNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtQNtNtCs7CppTae75M1_5alloc6string6StringNtB4_12SpecWriteFmt14spec_write_fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #0 !guid !578 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_statically_known_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments23as_statically_known_strCshVgFdEre0pE_3fmt(ptr align 8 %args) #22
  %4 = extractvalue { ptr, i64 } %3, 0
  %5 = extractvalue { ptr, i64 } %3, 1
  store ptr %4, ptr %_3, align 8
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %5, ptr %6, align 8
  %7 = load ptr, ptr %_3, align 8
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = ptrtoint ptr %7 to i64
  %11 = icmp eq i64 %10, 0
  %_5 = select i1 %11, i64 0, i64 1
  %12 = trunc nuw i64 %_5 to i1
  br i1 %12, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %s.0 = load ptr, ptr %_3, align 8
  %13 = getelementptr inbounds i8, ptr %_3, i64 8
  %s.1 = load i64, ptr %13, align 8
; call <alloc::string::String as core::fmt::Write>::write_str
  %14 = call zeroext i1 @_RNvXsZ_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_strCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %s.0, i64 %s.1) #22
  %15 = zext i1 %14 to i8
  store i8 %15, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %16 = load ptr, ptr %args, align 8
  %17 = getelementptr inbounds i8, ptr %args, i64 8
  %18 = load ptr, ptr %17, align 8
; call core::fmt::write
  %19 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt5write(ptr %self, ptr align 8 @vtable.i, ptr %16, ptr %18)
  %20 = zext i1 %19 to i8
  store i8 %20, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %21 = load i8, ptr %_0, align 1
  %22 = trunc nuw i8 %21 to i1
  ret i1 %22

bb5:                                              ; No predecessors!
  unreachable
}

; <[[i32; 2]; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAAlj2_Bz_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !579 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[[i32; 2]; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAAlj2_Bz_INtNtNtB7_3ops5index5IndexNtNtBK_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #22
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !300
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[[i32; 2]] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSAlj2_NtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[core::option::Option<i32>; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAINtNtB7_6option6OptionlEj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !580 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[core::option::Option<i32>; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAINtNtB7_6option6OptionlEj2_INtNtNtB7_3ops5index5IndexNtNtB13_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #22
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !300
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[core::option::Option<i32>] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSINtNtB8_6option6OptionlENtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[f64; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAdj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !581 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[f64; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAdj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #22
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !300
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[f64] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSdNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[i32; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAlj2_NtNtB7_3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !582 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[i32; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAlj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #22
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !300
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[i32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSlNtB6_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCshVgFdEre0pE_3fmt(ptr %pointer) unnamed_addr #0 !guid !583 {
start:
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCshVgFdEre0pE_3fmt(ptr %pointer) #22
  ret ptr %_0
}

; <[[i32; 2]; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAAlj2_Bz_INtNtNtB7_3ops5index5IndexNtNtBK_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %0) unnamed_addr #0 !guid !584 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[[i32; 2]]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSAlj2_E5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, i64 2, ptr align 8 %0) #22
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <[core::option::Option<i32>; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAINtNtB7_6option6OptionlEj2_INtNtNtB7_3ops5index5IndexNtNtB13_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %0) unnamed_addr #0 !guid !585 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[core::option::Option<i32>]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSINtNtB9_6option6OptionlEE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, i64 2, ptr align 8 %0) #22
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <[f64; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAdj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %0) unnamed_addr #0 !guid !586 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[f64]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSdE5indexCshVgFdEre0pE_3fmt(ptr align 8 %self, i64 2, ptr align 8 %0) #22
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <[i32; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAlj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, ptr align 8 %0) unnamed_addr #0 !guid !587 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i32]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSlE5indexCshVgFdEre0pE_3fmt(ptr align 4 %self, i64 2, ptr align 8 %0) #22
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::non_null::NonNull<[i32; 2]> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAlj2_ENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !588 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !589 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !590 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !591 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<i32> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllENtNtB9_3cmp9PartialEq2eqCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !592 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !593 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCshVgFdEre0pE_3fmt(ptr %unique) unnamed_addr #0 !guid !594 {
start:
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCshVgFdEre0pE_3fmt(ptr %unique) #22
  ret ptr %_0
}

; <*const u8 as core::fmt::Pointer>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsl_NtCsl10jNU3mE6R_4core3fmtPhNtB5_7Pointer3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !595 {
start:
  %_0 = alloca [1 x i8], align 1
  %ptr = load ptr, ptr %self, align 8
  %_0.i = ptrtoint ptr %ptr to i64
  br label %bb2

bb2:                                              ; preds = %start
; call core::fmt::pointer_fmt_inner
  %0 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt17pointer_fmt_inner(i64 %_0.i, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb2
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  ret i1 %3

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #1 !guid !596 {
start:
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCshVgFdEre0pE_3fmt(ptr %_3, i64 %_4) #22
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr %0, i64 %1) unnamed_addr #0 !guid !597 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_2 = select i1 %7, i64 1, i64 0
  %8 = trunc nuw i64 %_2 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %v.1 = load i64, ptr %9, align 8
  store ptr %v.0, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.1, ptr %10, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !598 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = trunc nuw i64 %_2 to i1
  br i1 %0, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %e.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %e.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %e.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v.0 = load ptr, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %v.1 = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %v.0, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 8
  store i64 %v.1, ptr %8, align 8
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr %0) unnamed_addr #0 !guid !599 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtB7_5alloc6layout6LayoutNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !600 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = trunc nuw i64 %_2 to i1
  br i1 %0, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %e.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %e.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %e.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v.0 = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %v.1 = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.0, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 8
  store i64 %v.1, ptr %8, align 8
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<usize, alloc::collections::TryReserveErrorKind> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultjNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindENtNtNtB7_3ops9try_trait3Try6branchCshVgFdEre0pE_3fmt(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !601 {
start:
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load i64, ptr %3, align 8
  store i64 %e.0, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.1, ptr %4, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %6, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !602 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCshVgFdEre0pE_3fmt(ptr align 8 %0) unnamed_addr #0 !guid !603 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { ptr, i64 } { ptr null, i64 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !604 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  %1 = insertvalue { i64, i64 } poison, i64 %residual.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %residual.1, 1
  %_4.0 = extractvalue { i64, i64 } %2, 0
  %_4.1 = extractvalue { i64, i64 } %2, 1
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %_4.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCshVgFdEre0pE_3fmt(i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !605 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  %1 = insertvalue { i64, i64 } poison, i64 %residual.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %residual.1, 1
  %_4.0 = extractvalue { i64, i64 } %2, 0
  %_4.1 = extractvalue { i64, i64 } %2, 1
  %3 = insertvalue { i64, i64 } poison, i64 %_4.0, 0
  %4 = insertvalue { i64, i64 } %3, i64 %_4.1, 1
  ret { i64, i64 } %4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveErrorKind>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtBN_19TryReserveErrorKindEE13from_residualCshVgFdEre0pE_3fmt(i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !606 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCshVgFdEre0pE_3fmt(i64 %residual.0, i64 %residual.1) #22
  %_4.0 = extractvalue { i64, i64 } %1, 0
  %_4.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_4.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_4.1, 1
  ret { i64, i64 } %3

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u8> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !607 {
start:
; call <alloc::vec::Vec<u8> as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[u8] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtShNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !608 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <[[i32; 2]] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSAlj2_NtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !609 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[[i32; 2]]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAlj2_4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #22
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&[i32; 2], core::slice::iter::Iter<[i32; 2]>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRAlj2_INtNtNtBa_5slice4iter4IterB14_EECshVgFdEre0pE_3fmt(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[core::option::Option<i32>] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSINtNtB7_6option6OptionlENtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !610 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[core::option::Option<i32>]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtB4_6option6OptionlE4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #22
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&core::option::Option<i32>, core::slice::iter::Iter<core::option::Option<i32>>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRINtNtBa_6option6OptionlEINtNtNtBa_5slice4iter4IterB14_EECshVgFdEre0pE_3fmt(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[f64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSdNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 8 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !611 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[f64]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCshVgFdEre0pE_3fmt(ptr align 8 %self.0, i64 %self.1) #22
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&f64, core::slice::iter::Iter<f64>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRdINtNtNtBa_5slice4iter4IterdEECshVgFdEre0pE_3fmt(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[u8] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtShNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !612 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[u8]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCshVgFdEre0pE_3fmt(ptr %self.0, i64 %self.1) #22
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&u8, core::slice::iter::Iter<u8>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRhINtNtNtBa_5slice4iter4IterhEECshVgFdEre0pE_3fmt(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !613 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[i32]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCshVgFdEre0pE_3fmt(ptr align 4 %self.0, i64 %self.1) #22
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECshVgFdEre0pE_3fmt(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <() as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXss_NtCsl10jNU3mE6R_4core3fmtuNtB5_5Debug3fmtCshVgFdEre0pE_3fmt(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !614 {
start:
; call <core::fmt::Formatter>::pad
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3pad(ptr align 8 %f, ptr @alloc_ae6dc619079e3c3b08144a35532ecff7, i64 2)
  ret i1 %_0
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshVgFdEre0pE_3fmt(ptr align 8 %self) unnamed_addr #0 !guid !615 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCshVgFdEre0pE_3fmt(ptr align 8 %self) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshVgFdEre0pE_3fmt(ptr %_1) unnamed_addr #0 !guid !616 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshVgFdEre0pE_3fmt(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !617 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshVgFdEre0pE_3fmt(ptr align 8 %_1) #22
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::fmt::Write>::write_fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %args.0, ptr %args.1) unnamed_addr #1 !guid !618 {
start:
; call <&mut alloc::string::String as core::fmt::Write::write_fmt::SpecWriteFmt>::spec_write_fmt
  %_0 = call zeroext i1 @_RNvXs_NvNtNtCsl10jNU3mE6R_4core3fmt5Write9write_fmtQNtNtCs7CppTae75M1_5alloc6string6StringNtB4_12SpecWriteFmt14spec_write_fmtCshVgFdEre0pE_3fmt(ptr align 8 %self, ptr %args.0, ptr %args.1) #22
  ret i1 %_0
}

; <<str as alloc::borrow::ToOwned>::to_owned as core::ops::function::FnOnce<(&str,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNvYeNtNtCs7CppTae75M1_5alloc6borrow7ToOwned8to_ownedINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTReEE9call_onceCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1) unnamed_addr #0 !guid !619 {
start:
  %_2 = alloca [16 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %1, ptr %2, align 8
  %3 = load ptr, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load i64, ptr %4, align 8
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCshVgFdEre0pE_3fmt(ptr sret([24 x i8]) align 8 %_0, ptr %3, i64 %5) #22
  ret void
}

; <usize as core::cmp::Ord>::max
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxCshVgFdEre0pE_3fmt(i64 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !620 {
start:
  %_7 = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %other = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store i64 %0, ptr %self, align 8
  store i64 %1, ptr %other, align 8
  store i8 0, ptr %_7, align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_7, align 1
  store i8 1, ptr %_6, align 1
  %_3.i = load i64, ptr %other, align 8
  %_4.i = load i64, ptr %self, align 8
  %_0.i = icmp ult i64 %_3.i, %_4.i
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  %2 = load i64, ptr %other, align 8
  store i64 %2, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %3 = load i64, ptr %self, align 8
  store i64 %3, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %4 = load i8, ptr %_6, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb9, label %bb5

bb5:                                              ; preds = %bb9, %bb4
  %6 = load i8, ptr %_7, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb10, label %bb6

bb9:                                              ; preds = %bb4
  br label %bb5

bb6:                                              ; preds = %bb10, %bb5
  %8 = load i64, ptr %_0, align 8
  ret i64 %8

bb10:                                             ; preds = %bb5
  br label %bb6

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <i32 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsr_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_6Binary3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #8

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <char as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsk_NtCsl10jNU3mE6R_4core3fmtcNtB5_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::LowerExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8LowerExp3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::LowerExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsw_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_8LowerExp3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::UpperExp>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_8UpperExp3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <core::time::Duration as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core4timeNtB5_8DurationNtNtB7_3fmt5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <char as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsj_NtCsl10jNU3mE6R_4core3fmtcNtB5_5Debug3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs2_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_5Debug3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugList>::entry
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #9

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64, i64) unnamed_addr #10

; alloc::fmt::format::format_inner
; Function Attrs: nonlazybind uwtable
declare void @_RNvNvNtCs7CppTae75M1_5alloc3fmt6format12format_inner(ptr sret([24 x i8]) align 8, ptr, ptr) unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #7

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #7

; std::io::stdio::_eprint
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio7__eprint(ptr, ptr) unnamed_addr #1

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #11

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #11

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #11

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i1(i1) #12

; alloc::raw_vec::min_non_zero_cap
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCs7CppTae75M1_5alloc7raw_vec16min_non_zero_cap(i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #13

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #13

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #2

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #14

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #15

; __rustc::__rust_realloc
; Function Attrs: nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc14___rust_realloc(ptr allocptr, i64, i64 allocalign, i64) unnamed_addr #16

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #17

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #10

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #11

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #18

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #18

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #11

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #11

; <core::fmt::Formatter>::pad
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3pad(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field3_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field3_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; <str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field2_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field2_finish(ptr align 8, ptr, i64, ptr, ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field2_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <i8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsw_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8UpperHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsu_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8LowerHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; core::fmt::write
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt5write(ptr, ptr align 8, ptr, ptr) unnamed_addr #1

; core::fmt::pointer_fmt_inner
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt17pointer_fmt_inner(i64, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugList>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #19 !guid !621 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshVgFdEre0pE_3fmt(ptr @_RNvCshVgFdEre0pE_3fmt4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #9 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #10 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #13 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #14 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { nonlazybind "target-cpu"="x86-64" }
attributes #20 = { cold }
attributes #21 = { cold noreturn nounwind }
attributes #22 = { inlinehint }
attributes #23 = { inlinehint nounwind }
attributes #24 = { noreturn }
attributes #25 = { noinline }
attributes #26 = { noinline noreturn nounwind }
attributes #27 = { noinline noreturn }
attributes #28 = { nounwind }

!llvm.module.flags = !{!198, !199, !200, !201}
!llvm.ident = !{!202}

!0 = !{i64 -8132620317805864350}
!1 = !{i64 5612689302236571829}
!2 = !{i64 -448218242360863312}
!3 = !{i64 1211126980810247125}
!4 = !{i64 4826553944420744064}
!5 = !{i64 -5868088760374213520}
!6 = !{i64 -5247999083806311652}
!7 = !{i64 -2157459987852952136}
!8 = !{i64 1482093489364193675}
!9 = !{i64 -1496805529200637041}
!10 = !{i64 -6784189510335130561}
!11 = !{i64 5586168542495477394}
!12 = !{i64 5008111268216844312}
!13 = !{i64 -3781576357302386890}
!14 = !{i64 -122906141938165412}
!15 = !{i64 -281118051809187356}
!16 = !{i64 -115902566878938752}
!17 = !{i64 -7787282016608996338}
!18 = !{i64 1623664849433225670}
!19 = !{i64 -1593472230304319314}
!20 = !{i64 -7635163248810649716}
!21 = !{i64 -577073546356888829}
!22 = !{i64 -6844108194042499373}
!23 = !{i64 -516169824412150636}
!24 = !{i64 -1908063299884387600}
!25 = !{i64 757139644034383545}
!26 = !{i64 3722681223349365220}
!27 = !{i64 4083283182001424287}
!28 = !{i64 -4062967328538061970}
!29 = !{i64 -1327391760903788161}
!30 = !{i64 -2322652448786874826}
!31 = !{i64 -4838680829097964254}
!32 = !{i64 8748072831422009710}
!33 = !{i64 -394716845731422163}
!34 = !{i64 5860233702239236606}
!35 = !{i64 -1706283914921929248}
!36 = !{i64 -1919080410807874535}
!37 = !{i64 -5342767181040323658}
!38 = !{i64 2810231716987079085}
!39 = !{i64 -5576911569559703568}
!40 = !{i64 -5084944626957126024}
!41 = !{i64 8432251674807018542}
!42 = !{i64 -5015202342061297618}
!43 = !{i64 -3736185618982898489}
!44 = !{i64 -591374575685052496}
!45 = !{i64 2274743695451314643}
!46 = !{i64 2713003658734069984}
!47 = !{i64 -933426428638480216}
!48 = !{i64 -993002039829721306}
!49 = !{i64 -2253468430328128876}
!50 = !{i64 -4749255079172459068}
!51 = !{i64 3916990760109670961}
!52 = !{i64 2212773127649101446}
!53 = !{i64 5584065934491396975}
!54 = !{i64 -5652344135089000817}
!55 = !{i64 7546446789667000340}
!56 = !{i64 -2403905300768536192}
!57 = !{i64 1459235934954971812}
!58 = !{i64 -6259550584333079343}
!59 = !{i64 -4422371029170761166}
!60 = !{i64 1264033222216718950}
!61 = !{i64 -2316072043815828829}
!62 = !{i64 2809876578690872797}
!63 = !{i64 -2007066530285873498}
!64 = !{i64 2110669748611395879}
!65 = !{i64 7684272467252302654}
!66 = !{i64 -2509343417881901214}
!67 = !{i64 6362243088833346135}
!68 = !{i64 685139831437057870}
!69 = !{i64 -9169540017538518525}
!70 = !{i64 7687126665386690817}
!71 = !{i64 5465731067827784582}
!72 = !{i64 5226550232935421787}
!73 = !{i64 -3573453626406352736}
!74 = !{i64 6236763125154844428}
!75 = !{i64 4878287299760613004}
!76 = !{i64 -9090268440299029750}
!77 = !{i64 5055785646024959096}
!78 = !{i64 -8167673237437823278}
!79 = !{i64 -417323235462969742}
!80 = !{i64 -8831549745758893673}
!81 = !{i64 -4636886171941314550}
!82 = !{i64 3365682401694020541}
!83 = !{i64 -6330986621482673074}
!84 = !{i64 -5477038826078292041}
!85 = !{i64 -5768420342474646396}
!86 = !{i64 -2843092315605587914}
!87 = !{i64 5564031368922769522}
!88 = !{i64 -8322075139909967582}
!89 = !{i64 810783506982441343}
!90 = !{i64 -7271846813879244122}
!91 = !{i64 8264151614003634940}
!92 = !{i64 -2015871537063754090}
!93 = !{i64 2812018196730803312}
!94 = !{i64 70316315501755419}
!95 = !{i64 -7958341364384573189}
!96 = !{i64 -7661187796921093690}
!97 = !{i64 -7432457458805487851}
!98 = !{i64 3469137719956417455}
!99 = !{i64 -2608697416400289564}
!100 = !{i64 -422151868751099621}
!101 = !{i64 -9149531698515560116}
!102 = !{i64 -5079148446866426435}
!103 = !{i64 5913944871299075343}
!104 = !{i64 7604957892239391154}
!105 = !{i64 -6741074459445808119}
!106 = !{i64 -2993706336261190945}
!107 = !{i64 -3210086871458441380}
!108 = !{i64 -3976188213370413033}
!109 = !{i64 3736328497362664552}
!110 = !{i64 5920817750577243297}
!111 = !{i64 -8030510410817891372}
!112 = !{i64 -6243981903883764066}
!113 = !{i64 6590980234544584683}
!114 = !{i64 -5221630850859162300}
!115 = !{i64 3700408122684201562}
!116 = !{i64 6826691935431628243}
!117 = !{i64 -5675815145291631865}
!118 = !{i64 2667922226972356048}
!119 = !{i64 394402033564973154}
!120 = !{i64 -5828631274631940601}
!121 = !{i64 -5253303783860664680}
!122 = !{i64 6181089605632763610}
!123 = !{i64 4566702337967795113}
!124 = !{i64 -7804072751718835000}
!125 = !{i64 2994814609246353400}
!126 = !{i64 8722634205977993332}
!127 = !{i64 -7766929622428920343}
!128 = !{i64 4293265385928204414}
!129 = !{i64 7663320161623032881}
!130 = !{i64 -4724409519477519290}
!131 = !{i64 -5423629775491000123}
!132 = !{i64 8701797371428378983}
!133 = !{i64 194126092971558625}
!134 = !{i64 -1146593729610437839}
!135 = !{i64 1083528964381385314}
!136 = !{i64 -1081479177762096566}
!137 = !{i64 405555657937212620}
!138 = !{i64 7841654141538599893}
!139 = !{i64 3482361621223917051}
!140 = !{i64 -7288314053053331465}
!141 = !{i64 8305390359325833814}
!142 = !{i64 8044233877345608484}
!143 = !{i64 3874452188968871356}
!144 = !{i64 2278687786873017166}
!145 = !{i64 2901716498662962347}
!146 = !{i64 7443084446511275234}
!147 = !{i64 5175973781436788028}
!148 = !{i64 -260505252601741549}
!149 = !{i64 -862314056744376636}
!150 = !{i64 -3600420154308279288}
!151 = !{i64 3702050006414583535}
!152 = !{i64 259156230244817539}
!153 = !{i64 6321450066464963473}
!154 = !{i64 4998191751488505578}
!155 = !{i64 -7058177170692411702}
!156 = !{i64 -129205547691680448}
!157 = !{i64 -6867857202363626339}
!158 = !{i64 -138800154976628334}
!159 = !{i64 -7070281070893640237}
!160 = !{i64 -8580140845455700555}
!161 = !{i64 -2179915077731768675}
!162 = !{i64 -6455529994324281876}
!163 = !{i64 2666436217763450749}
!164 = !{i64 4663704484393199073}
!165 = !{i64 -2917467405056069975}
!166 = !{i64 1635729342696332968}
!167 = !{i64 8581899157657193450}
!168 = !{i64 8239744062121445689}
!169 = !{i64 9172727812234265901}
!170 = !{i64 1364871080634975753}
!171 = !{i64 1971152453905596512}
!172 = !{i64 -4499957541911900748}
!173 = !{i64 2312593604528797818}
!174 = !{i64 -2701133806002375051}
!175 = !{i64 -8127230611621693312}
!176 = !{i64 5192922204800598223}
!177 = !{i64 -221485521005250313}
!178 = !{i64 9051896480083306389}
!179 = !{i64 4553364466018817663}
!180 = !{i64 -6615441714317021565}
!181 = !{i64 -4239534246509348885}
!182 = !{i64 -4068986400584350032}
!183 = !{i64 -1340010998737269433}
!184 = !{i64 3792928596688110230}
!185 = !{i64 2720229701271388197}
!186 = !{i64 -5229945751950126371}
!187 = !{i64 -8703159629425390022}
!188 = !{i64 4697973234943270572}
!189 = !{i64 1469644649419597585}
!190 = !{i64 -7297544254932145003}
!191 = !{i64 -4779242698007139297}
!192 = !{i64 -1589497205791364753}
!193 = !{i64 -6689813875729583344}
!194 = !{i64 -5164482134470652076}
!195 = !{i64 5194227983755596663}
!196 = !{i64 -9137546081407560042}
!197 = !{i64 8396411914061181048}
!198 = !{i32 8, !"PIC Level", i32 2}
!199 = !{i32 7, !"PIE Level", i32 2}
!200 = !{i32 2, !"RtLibUseGOT", i32 1}
!201 = !{i32 7, !"uwtable", i32 2}
!202 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!203 = !{i64 -3867494453637628944}
!204 = !{i64 -136418552192666661}
!205 = !{i64 -6578500115618072987}
!206 = !{i64 -8974062386252053572}
!207 = !{i64 -6741796794014705129}
!208 = !{i64 -5507548896524922685}
!209 = !{i64 -6265929485577308242}
!210 = !{i64 -7730169170113807518}
!211 = !{i64 4801773377623911443}
!212 = !{i64 -3084057772664859311}
!213 = !{i64 -8015320313816513344}
!214 = !{i64 4423291852911773492}
!215 = !{i64 -6274649038805816597}
!216 = !{i64 4812730341191421490}
!217 = !{i64 -3456547733269109132}
!218 = !{i64 -7434763763902217093}
!219 = !{i64 3955936623030078916}
!220 = !{i64 5127539084423874984}
!221 = !{i64 -2173857770303920882}
!222 = !{i64 6640127383132664624}
!223 = !{i64 825628855711899765}
!224 = !{i64 -3659384197398975127}
!225 = !{i64 7634682321164322343}
!226 = !{i64 3279195104393158995}
!227 = !{i64 4965092395898331155}
!228 = !{i64 -3394186359278290459}
!229 = !{i64 -7095109920396302965}
!230 = !{i64 -5306170814776717210}
!231 = !{i64 -1812027324443981478}
!232 = !{i64 -4799073400923115407}
!233 = !{i64 -767328904370094174}
!234 = !{i64 -6553038961771511748}
!235 = !{i64 862815605236722143}
!236 = !{i64 -1148137315368194944}
!237 = !{i64 1126471347521018434}
!238 = !{i64 1595161473091634196}
!239 = !{i64 -4922250615273797892}
!240 = !{i64 -2380995945722650402}
!241 = !{i64 3289266059780218518}
!242 = !{i64 3265365179304154272}
!243 = !{i64 -4450288843018741059}
!244 = !{i64 -4456587328059746109}
!245 = !{i64 -5845578776202198783}
!246 = !{i64 8259390624231181985}
!247 = !{i64 -98280573211069965}
!248 = !{i64 -617674543553841949}
!249 = !{i64 -3364047263468522662}
!250 = !{i64 5096548919705908885}
!251 = !{i64 -8410544145506781689}
!252 = !{i64 -4487492937818276814}
!253 = !{i64 464683584300181625}
!254 = !{i64 -6394578666689644948}
!255 = !{i64 7562691192130722259}
!256 = !{i64 -6966609168285582486}
!257 = !{i64 -4145980064176402162}
!258 = !{i64 -818728121483233930}
!259 = !{i64 7071151080144140216}
!260 = !{i64 1450701695262534483}
!261 = !{i64 2532376289704292345}
!262 = !{i64 -7166319854198847373}
!263 = !{i64 -5264730924811431050}
!264 = !{i64 -3844401939522224847}
!265 = !{i64 996538063986325717}
!266 = !{i64 -6949216266568495313}
!267 = !{i64 8732745674656246252}
!268 = !{i64 -8679020432971772543}
!269 = !{i64 -4828095599239218563}
!270 = !{i64 5080376078290121588}
!271 = !{i64 -662973435292884090}
!272 = !{i64 -6259129252355595605}
!273 = !{i64 -5518630071992584408}
!274 = !{i64 2084487444590880098}
!275 = !{i64 -5985410076870471539}
!276 = !{i64 622716146307609350}
!277 = !{i64 257852734924454058}
!278 = !{i64 7081073940686832251}
!279 = !{i64 441101486297210887}
!280 = !{i64 -3504291117403919570}
!281 = !{i64 7560259027171119726}
!282 = !{i64 -7960675684290142051}
!283 = !{i64 -2652884967698434809}
!284 = !{i64 -5743906877883001967}
!285 = !{i64 -8951763092455508267}
!286 = !{i64 -1540499576091198570}
!287 = !{i64 -315156859993632687}
!288 = !{i64 -7732669232036068240}
!289 = !{i64 7187913154399702711}
!290 = !{i64 577526224401925675}
!291 = !{i64 3865924414016758903}
!292 = !{i64 -1186898816145204135}
!293 = !{i64 -3526449587187175492}
!294 = !{i64 -8598887001099902720}
!295 = !{i64 -3420468300831683474}
!296 = !{i64 221871208117168169}
!297 = !{i64 2139135911528034598}
!298 = !{i64 7833011007580698600}
!299 = !{i64 -3852821826880946470}
!300 = !{!"address", !"read_provenance"}
!301 = !{i64 -6439246804432274092}
!302 = !{i64 6541663144983838573}
!303 = !{i64 3713414741173651319}
!304 = !{i64 7486304605446475021}
!305 = !{i64 -7040707650528460791}
!306 = !{i64 -7650426053692254731}
!307 = !{i64 -2123857678502398049}
!308 = !{i64 5873994450454891656}
!309 = !{i64 -5838233508577908346}
!310 = !{i64 -1796575533798572753}
!311 = !{i64 -1639313436501643770}
!312 = !{i64 6976914835822494844}
!313 = !{i64 6998115071906978452}
!314 = !{i64 -9187691924088539936}
!315 = !{i64 -1712790700121451718}
!316 = !{i64 -832564892682934918}
!317 = !{i64 4261832876403444445}
!318 = !{i64 -2409498454174416746}
!319 = !{i64 1322557869699769}
!320 = !{i64 6230184085501283936}
!321 = !{i64 -293147354941460220}
!322 = !{i64 -2376953033220365188}
!323 = !{i64 -530672601421345539}
!324 = !{i64 5077019415189536183}
!325 = !{i64 7907996608821285020}
!326 = !{i64 367479253653765862}
!327 = !{i64 3135131798534966009}
!328 = !{i64 -8573640615877710900}
!329 = !{i64 -1086443278688916248}
!330 = !{i64 -6434967798119884455}
!331 = !{i64 274628121043130486}
!332 = !{i64 5731925161109559373}
!333 = !{i64 -8842606267070792443}
!334 = !{i64 6558566187724958518}
!335 = !{i64 -3883346937061146079}
!336 = !{i64 -1782832558665964899}
!337 = !{i64 5292330688561933831}
!338 = !{i64 1701350442875598092}
!339 = !{i64 5413477218692182325}
!340 = !{i64 1399547116709605326}
!341 = !{i64 1301894008191696890}
!342 = !{i64 -1724025131803656888}
!343 = !{i64 -818722165786121514}
!344 = !{i64 -4321880062849790650}
!345 = !{i64 1330863988141907470}
!346 = !{i64 477064652333358627}
!347 = !{i64 -7662074300782288856}
!348 = !{i64 -5867353235550513658}
!349 = !{i64 6236736549055552611}
!350 = !{i64 5278387498635613202}
!351 = !{i64 -9037011443617815845}
!352 = !{i64 -4279579510392561671}
!353 = !{i64 -7213939522221857594}
!354 = !{i64 -166496684056417484}
!355 = !{i64 -2230993148816162393}
!356 = !{i64 2475092956417799797}
!357 = !{i64 -3932518907961903044}
!358 = !{i64 -2536915976663147802}
!359 = !{i64 -4421946593336579708}
!360 = !{i64 -8249930491378784473}
!361 = !{i64 7478229485813689382}
!362 = !{i64 -7041332064082161842}
!363 = !{i64 -1105174694679776714}
!364 = !{i64 1510524152123537975}
!365 = !{i64 6885564760487196060}
!366 = !{i64 -4408988274118039003}
!367 = !{i64 4749902482400682388}
!368 = !{i64 -6407246724117243688}
!369 = !{i64 -6375402089602926770}
!370 = !{i64 2026683238910474693}
!371 = !{i64 7558167615732134008}
!372 = !{i64 -3226958269673235559}
!373 = !{i64 -5108860901380853574}
!374 = !{i64 4469459735232262339}
!375 = !{i64 8246801733840636385}
!376 = !{i64 6706431284506942933}
!377 = !{i64 5246984667878434375}
!378 = !{i64 8314389239982740574}
!379 = !{i64 -750405123660278989}
!380 = !{i64 4591775385473599926}
!381 = !{i64 -6996803978648768123}
!382 = !{i64 2965887601557481951}
!383 = !{i64 -4147879354884934463}
!384 = !{i64 -6954005352903098307}
!385 = !{i64 -2572970411735610185}
!386 = !{i64 -3782106384585675083}
!387 = !{i64 5965954686604036741}
!388 = !{i64 -8612814158710632949}
!389 = !{i64 2132567018099757742}
!390 = !{i64 -3255199549055522559}
!391 = !{i64 4770243294541407327}
!392 = !{i64 6800887829436166495}
!393 = !{i64 -3110735230975630277}
!394 = !{i64 8685486924111596560}
!395 = !{i64 879828367404514402}
!396 = !{i64 -2176968637016945080}
!397 = !{i64 6762144589197226401}
!398 = !{i64 -7195719854626341327}
!399 = !{i64 -3400926305133760373}
!400 = !{i64 -7435420864117409728}
!401 = !{i64 1238574712678743116}
!402 = !{i64 8803381976610488250}
!403 = !{i64 2349609271676813917}
!404 = !{i64 -8871134933723337242}
!405 = !{i64 -3334072701639118389}
!406 = !{i64 -1134547415249667632}
!407 = !{i64 -7696571845780090354}
!408 = !{i64 2707781790208459356}
!409 = !{i64 -5425132305665720071}
!410 = !{i64 -8338902333534909114}
!411 = !{i64 4986235244782314003}
!412 = !{i64 -7242133735639084285}
!413 = !{i64 1603219210912235225}
!414 = !{i64 1702565854033158263}
!415 = !{i64 767722196505600300}
!416 = !{i64 -3128898196221752735}
!417 = !{i64 -6555571386061408515}
!418 = !{i64 -8787082550952193929}
!419 = !{i64 7975968765170993525}
!420 = !{i64 -6240426729927907219}
!421 = !{i64 5619827140219738282}
!422 = !{i64 -7693398968135527442}
!423 = !{i64 -965955333340717449}
!424 = !{i64 1649607862764618457}
!425 = !{i64 -3112662265325076947}
!426 = !{i64 1752205899200826348}
!427 = !{i64 8883682320526420257}
!428 = !{i64 -2687037569576501915}
!429 = !{i64 -7009356407558650712}
!430 = !{i64 4005157908472937999}
!431 = !{i64 2572669990814322732}
!432 = !{i64 -3552185860839527298}
!433 = !{i64 -5041085703454851131}
!434 = !{i64 5960841661953486047}
!435 = !{i64 -5203037423515663566}
!436 = !{i64 7391566156259735165}
!437 = !{i64 -62726558119208679}
!438 = !{i64 -7377931037338590998}
!439 = !{i64 -3685172069371319810}
!440 = !{i64 -9027269512649337132}
!441 = !{i64 -8228637186868256159}
!442 = !{i64 3850074771448025460}
!443 = !{i64 5200803842634247944}
!444 = !{i64 371379894756965080}
!445 = !{i64 1364310252765350598}
!446 = !{i64 8478227855293666595}
!447 = !{i64 -4673782747335894807}
!448 = !{i64 8574706875328960133}
!449 = !{i64 -8913836709393353965}
!450 = !{i64 990427290099607911}
!451 = !{i64 -5263664073801454965}
!452 = !{i64 -4131467620778196692}
!453 = !{i64 -8257121081842737601}
!454 = !{i64 541539895221940820}
!455 = !{i64 -2847394657205104402}
!456 = !{i64 4862267509913598673}
!457 = !{i64 4725586282375599274}
!458 = !{i64 3870474434459109911}
!459 = !{i64 5986336924434883173}
!460 = !{i64 4477764240186727690}
!461 = !{i64 2484308150105148561}
!462 = !{i64 -3050206039252880904}
!463 = !{i64 194494849069431984}
!464 = !{i64 4896373843678679730}
!465 = !{i64 5504037120275318611}
!466 = !{i64 797764276369927644}
!467 = !{i64 -4287033000586386625}
!468 = !{i64 3943886462663708321}
!469 = !{i64 3770854525391235169}
!470 = !{i64 3490715217795202234}
!471 = !{i64 -3723761645303102449}
!472 = !{i64 -5210563313405413655}
!473 = !{i64 5565544709054696124}
!474 = !{i64 -5877184960182764462}
!475 = !{i64 -368033063725123615}
!476 = !{i64 -2728093462917043806}
!477 = !{i64 -8223290817447982942}
!478 = !{i64 5543456854003255339}
!479 = !{i64 -8464688875633795535}
!480 = !{i64 191470236979152730}
!481 = !{i64 -3210574878743046322}
!482 = !{i64 -6198053412181408961}
!483 = !{i64 3926341877941676848}
!484 = !{i64 3645190187786244671}
!485 = !{i64 -133848971323704318}
!486 = !{i64 3943733253502207666}
!487 = !{i64 6824397668053962364}
!488 = !{i64 171057521641243521}
!489 = !{i64 -9064820005296444172}
!490 = !{i64 -2382404713642264008}
!491 = !{i64 -4510477655604204408}
!492 = !{i64 3170560301256350052}
!493 = !{i64 -6697583126095477952}
!494 = !{i64 7007253523226118056}
!495 = !{i64 1293552083541799905}
!496 = !{i64 -4688711738515196756}
!497 = !{i64 -1396822567271163860}
!498 = !{i64 7770136940300514869}
!499 = !{i64 6419285443167383704}
!500 = !{i64 -1432914630952416900}
!501 = !{i64 -7905822608749167824}
!502 = !{i64 551246756510975312}
!503 = !{i64 -1858285946553633484}
!504 = !{i64 833484573719800943}
!505 = !{i64 8895933665556567114}
!506 = !{i64 5541782390985514654}
!507 = !{i64 -5610917605868341759}
!508 = !{i64 3906584200814670182}
!509 = !{i64 3467336555512975062}
!510 = !{i64 6019501320896110028}
!511 = !{i64 -7644064545471063616}
!512 = !{i64 -7853615714174881282}
!513 = !{i64 -8337375783872269582}
!514 = !{i64 2722768004807545059}
!515 = !{i64 -3667062602094021293}
!516 = !{i64 -4418041461952439668}
!517 = !{i64 5797987867548889619}
!518 = !{i64 2886495029518175907}
!519 = !{i64 695442620630347102}
!520 = !{i64 -8105346992901517440}
!521 = !{i64 -6982595510491451560}
!522 = !{i64 -8045936944828479002}
!523 = !{i64 678073243194024007}
!524 = !{i64 5494062067620683019}
!525 = !{i64 4351038181588498853}
!526 = !{i64 2387538639354354899}
!527 = !{i64 -6251563856406441222}
!528 = !{i64 -6834709353985492172}
!529 = !{i64 3254192204357885165}
!530 = !{i64 4324828925958322938}
!531 = !{i64 -3224256396494800153}
!532 = !{i64 -5820873047505826506}
!533 = !{i64 -2185936138930546205}
!534 = !{i64 -5892110521947742408}
!535 = !{i64 -2692732511740214205}
!536 = !{i64 -7625029099653999965}
!537 = !{i64 -8482012798901484780}
!538 = !{i64 -6455905660702199624}
!539 = !{i64 1066412412765451519}
!540 = !{i64 537313514421811245}
!541 = !{i64 -713585283019284170}
!542 = !{i64 4103375384971173425}
!543 = !{i64 -3983443083955287854}
!544 = !{i64 -3513452704345443821}
!545 = !{i64 2143988854799620687}
!546 = !{i64 -2918668415557827010}
!547 = !{i64 -5627049812867352570}
!548 = !{i64 -4921179134784332863}
!549 = !{i64 3144613751409653026}
!550 = !{i64 8245416395830072926}
!551 = !{i64 -6360290205647692364}
!552 = !{i64 2505181270894108841}
!553 = !{i64 -9038581252047575997}
!554 = !{i64 -5018378294337499840}
!555 = !{i64 3930612517837761984}
!556 = !{i64 8488294934962476744}
!557 = !{i64 -6635573420272552104}
!558 = !{i64 1924739989191668214}
!559 = !{i64 6349027377615832605}
!560 = !{i64 -7057994391020654272}
!561 = !{i64 4782237030730296255}
!562 = !{i64 2509860846348573036}
!563 = !{i64 -2576518871454296016}
!564 = !{i64 -4365886425834899262}
!565 = !{i64 -5744137141146045813}
!566 = !{i64 -5331739760354644683}
!567 = !{i64 -7331425361636407905}
!568 = !{i64 -5940547247704914047}
!569 = !{i64 7150799294802872180}
!570 = !{i64 -2394632239132369058}
!571 = !{i64 -1781266654528198286}
!572 = !{i64 -3849889344285125321}
!573 = !{i64 1545092686915998722}
!574 = !{i64 -1600695934044983192}
!575 = !{i64 -896214853880101922}
!576 = !{i64 -815824912661880287}
!577 = !{i64 -2151273209879174478}
!578 = !{i64 8029206391456013369}
!579 = !{i64 7028240067064492985}
!580 = !{i64 -7048148330399132107}
!581 = !{i64 -6926030287728340085}
!582 = !{i64 -5053005885609600643}
!583 = !{i64 -7724348084303283696}
!584 = !{i64 2249967233579379895}
!585 = !{i64 -7624782965545758321}
!586 = !{i64 294438840701367248}
!587 = !{i64 -8534950642212519539}
!588 = !{i64 8495085923839668865}
!589 = !{i64 -2339793471312789452}
!590 = !{i64 -7523891483424241462}
!591 = !{i64 2374363996991392405}
!592 = !{i64 6949979636648299672}
!593 = !{i64 -8647546223719475220}
!594 = !{i64 2258231961910658251}
!595 = !{i64 7342668281675412474}
!596 = !{i64 2819334879432990036}
!597 = !{i64 4352130335238014345}
!598 = !{i64 4015201218342541258}
!599 = !{i64 -4603790576569659844}
!600 = !{i64 -48269681101254538}
!601 = !{i64 2520288451513786308}
!602 = !{i64 -6933176604651149124}
!603 = !{i64 4609701180760505149}
!604 = !{i64 -964469238650609864}
!605 = !{i64 93903684842287986}
!606 = !{i64 923411367251612007}
!607 = !{i64 6999874401967083241}
!608 = !{i64 -4043267851280955612}
!609 = !{i64 4586966925732624456}
!610 = !{i64 -5297396064226158042}
!611 = !{i64 -727606346335518771}
!612 = !{i64 -2213060608022574690}
!613 = !{i64 -1653864503875113882}
!614 = !{i64 2120004570629443033}
!615 = !{i64 -4269997668479433630}
!616 = !{i64 -6040316333804617375}
!617 = !{i64 2569217573342778815}
!618 = !{i64 5865040130561925977}
!619 = !{i64 -869661410753111738}
!620 = !{i64 -4105280640361882137}
!621 = !{i64 -2624081020897602054}
