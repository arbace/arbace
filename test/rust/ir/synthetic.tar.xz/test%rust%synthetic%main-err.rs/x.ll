; ModuleID = 'main_err.c169d55efd53bca8-cgu.0'
source_filename = "main_err.c169d55efd53bca8-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@anon.ac5c35161c5d8bf686373dccbfb0872a.0 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 5770194870310030701 to ptr), ptr inttoptr (i64 9083022900921122937 to ptr) }>, align 8, !guid !4
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBN_5error5ErrorEL_EEE0INtNtNtBN_3ops8function6FnOnceuE9call_once6vtableCsgBxaKiRzQCG_8main_err, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBI_5error5ErrorEL_EEE0CsgBxaKiRzQCG_8main_err, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBI_5error5ErrorEL_EEE0CsgBxaKiRzQCG_8main_err }>, align 8, !guid !5
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !6
@alloc_6ac7cec0a18e60d101239f56a7eda11e = private unnamed_addr constant [12 x i8] c"not reached\0A", align 1, !guid !7
@alloc_67f66615159ee0b714a92405c8a98ca2 = private unnamed_addr constant [32 x i8] c"test/rust/synthetic/main-err.rs\00", align 1, !guid !8
@alloc_8f3685dfb161361f0a4bf6d2a0a22f82 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f66615159ee0b714a92405c8a98ca2, [16 x i8] c"\1F\00\00\00\00\00\00\00\0A\00\00\00\14\00\00\00" }>, align 8, !guid !9
@alloc_73e00bbe92b269bd917c0bd60b1bd34e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f66615159ee0b714a92405c8a98ca2, [16 x i8] c"\1F\00\00\00\00\00\00\00\09\00\00\00\14\00\00\00" }>, align 8, !guid !10
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !11
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !12
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !13
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !14
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !15
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !16
@alloc_51962fe56062ee42f21b1a5d2870e81d = private unnamed_addr constant [11 x i8] c"\08failure \C0\00", align 1, !guid !17
@alloc_61562ee3f6625a42fbf3ac54f2988902 = private unnamed_addr constant [7 x i8] c"Failure", align 1, !guid !18
@alloc_905976595ed1b08e57e2b44a2acadea4 = private unnamed_addr constant [4 x i8] c"code", align 1, !guid !19
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_ }>, align 8, !guid !20
@alloc_26978532d6004174455ea2130c477035 = private unnamed_addr constant [12 x i8] c"\07Error: \C0\01\0A\00", align 1, !guid !21
@alloc_a80d1d84362286d7db52d66e0bf14839 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXCsgBxaKiRzQCG_8main_errNtB2_7FailureNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt }>, align 8, !guid !22
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXs0_CsgBxaKiRzQCG_8main_errNtB5_7FailureNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_, ptr @_RNvXCsgBxaKiRzQCG_8main_errNtB2_7FailureNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt, ptr @alloc_a80d1d84362286d7db52d66e0bf14839, ptr @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error6sourceB4_, ptr @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error7type_idB4_, ptr @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error11descriptionB4_, ptr @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error5causeB4_, ptr @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error7provideB4_ }>, align 8, !guid !23
@alloc_04d7ce44d7c86a9a02b346ab945bf155 = private unnamed_addr constant [40 x i8] c"description() is deprecated; use Display", align 1, !guid !24

; <core::fmt::rt::Argument>::new_debug::<alloc::boxed::Box<dyn core::error::Error>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EECsgBxaKiRzQCG_8main_err(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !30 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB9_5error5ErrorEL_EE8from_refCsgBxaKiRzQCG_8main_err(ptr align 8 %x) #15
; call <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBa_5error5ErrorEL_EE4castuECsgBxaKiRzQCG_8main_err(ptr %_4) #15
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsn_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtBM_3fmt5Debug3fmtCsgBxaKiRzQCG_8main_err, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<dyn core::error::Error>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_5error5ErrorEL_ECsgBxaKiRzQCG_8main_err(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !31 {
start:
; call core::mem::align_of_val_raw::<dyn core::error::Error>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_5error5ErrorEL_ECsgBxaKiRzQCG_8main_err(ptr %val.0, ptr align 8 %val.1) #15
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsgBxaKiRzQCG_8main_err(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #15
  ret i64 %_0
}

; <core::alloc::layout::Layout>::for_value_raw::<dyn core::error::Error>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_5error5ErrorEL_ECsgBxaKiRzQCG_8main_err(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !32 {
start:
; call core::mem::size_of_val_raw::<dyn core::error::Error>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_5error5ErrorEL_ECsgBxaKiRzQCG_8main_err(ptr %val.0, ptr align 8 %val.1) #15
; call <core::mem::alignment::Alignment>::of_val_raw::<dyn core::error::Error>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_5error5ErrorEL_ECsgBxaKiRzQCG_8main_err(ptr %val.0, ptr align 8 %val.1) #15
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsgBxaKiRzQCG_8main_err(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #15
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<dyn core::error::Error>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_5error5ErrorEL_E4casthECsgBxaKiRzQCG_8main_err(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !33 {
start:
; call <core::ptr::non_null::NonNull<dyn core::error::Error>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_5error5ErrorEL_E4casthECsgBxaKiRzQCG_8main_err(ptr %self.0, ptr align 8 %self.1) #15
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<dyn core::error::Error>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_5error5ErrorEL_E4casthECsgBxaKiRzQCG_8main_err(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !34 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBa_5error5ErrorEL_EE4castuECsgBxaKiRzQCG_8main_err(ptr %self) unnamed_addr #0 !guid !35 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<12, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjc_Kj1_ECsgBxaKiRzQCG_8main_err(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !36 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::any::TypeId>::of::<main_err::Failure>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtCsgBxaKiRzQCG_8main_err7FailureEBM_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !37 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.ac5c35161c5d8bf686373dccbfb0872a.0, i64 16, i1 false)
  ret void
}

; std::rt::lang_start::<core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBG_5error5ErrorEL_EEECsgBxaKiRzQCG_8main_err(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !38 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::mem::size_of_val_raw::<dyn core::error::Error>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_5error5ErrorEL_ECsgBxaKiRzQCG_8main_err(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !39 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %_0 = load i64, ptr %0, align 8, !invariant.load !40
  %1 = getelementptr inbounds i8, ptr %val.1, i64 16
  %2 = load i64, ptr %1, align 8, !invariant.load !40
  ret i64 %_0
}

; core::mem::align_of_val_raw::<dyn core::error::Error>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_5error5ErrorEL_ECsgBxaKiRzQCG_8main_err(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !41 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %1 = load i64, ptr %0, align 8, !invariant.load !40
  %2 = getelementptr inbounds i8, ptr %val.1, i64 16
  %_0 = load i64, ptr %2, align 8, !invariant.load !40
  ret i64 %_0
}

; core::ptr::drop_glue::<dyn core::error::Error>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueDNtNtB4_5error5ErrorEL_ECsgBxaKiRzQCG_8main_err(ptr %_1.0, ptr align 8 %_1.1) unnamed_addr #1 !guid !42 {
start:
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 0
  %1 = load ptr, ptr %0, align 8, !invariant.load !40
  %2 = icmp ne ptr %1, null
  br i1 %2, label %is_not_null, label %bb1

is_not_null:                                      ; preds = %start
  call void %1(ptr %_1.0) #15
  br label %bb1

bb1:                                              ; preds = %is_not_null, %start
  ret void
}

; core::ptr::drop_glue::<core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorEL_EEECsgBxaKiRzQCG_8main_err(ptr align 8 %_1) unnamed_addr #1 !guid !43 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %2 = load ptr, ptr %1, align 8
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = icmp eq i64 %_2, 0
  br i1 %5, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorEL_EECsgBxaKiRzQCG_8main_err(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorEL_EECsgBxaKiRzQCG_8main_err(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !44 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6.1, i64 0
  %3 = load ptr, ptr %2, align 8, !invariant.load !40
  %4 = icmp ne ptr %3, null
  br i1 %4, label %is_not_null, label %bb3

is_not_null:                                      ; preds = %start
  invoke void %3(ptr %_6.0)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %is_not_null, %start
; call <alloc::boxed::Box<dyn core::error::Error> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtNtBM_3ops4drop4Drop4dropCsgBxaKiRzQCG_8main_err(ptr align 8 %_1) #15
  ret void

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<dyn core::error::Error> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtNtBM_3ops4drop4Drop4dropCsgBxaKiRzQCG_8main_err(ptr align 8 %_1) #16
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %is_not_null
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb2:                                              ; preds = %bb4
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECsgBxaKiRzQCG_8main_err(i8 %dummy) unnamed_addr #0 !guid !45 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !46
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn() -> core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>, core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>
; Function Attrs: noinline nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB1e_5error5ErrorEL_EEB19_ECsgBxaKiRzQCG_8main_err(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !47 {
start:
  %0 = alloca [16 x i8], align 8
  %result = alloca [16 x i8], align 8
; call <fn() -> core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>> as core::ops::function::FnOnce<()>>::call_once
  %1 = call { ptr, ptr } @_RNvYFEINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB9_5error5ErrorEL_EEINtNtNtB9_3ops8function6FnOnceuE9call_onceCsgBxaKiRzQCG_8main_err(ptr %f) #15
  %2 = extractvalue { ptr, ptr } %1, 0
  %3 = extractvalue { ptr, ptr } %1, 1
  store ptr %2, ptr %result, align 8
  %4 = getelementptr inbounds i8, ptr %result, i64 8
  store ptr %3, ptr %4, align 8
; invoke core::hint::black_box::<()>
  invoke void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std()
          to label %bb2 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorEL_EEECsgBxaKiRzQCG_8main_err(ptr align 8 %result) #16
          to label %bb4 unwind label %terminate

cleanup:                                          ; preds = %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb3

bb2:                                              ; preds = %start
  %_0.0 = load ptr, ptr %result, align 8
  %9 = getelementptr inbounds i8, ptr %result, i64 8
  %_0.1 = load ptr, ptr %9, align 8
  %10 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, ptr } %10, ptr %_0.1, 1
  ret { ptr, ptr } %11

terminate:                                        ; preds = %bb3
  %12 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb4:                                              ; preds = %bb3
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr inbounds i8, ptr %0, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17
}

; std::rt::lang_start::<core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBI_5error5ErrorEL_EEE0CsgBxaKiRzQCG_8main_err(ptr align 8 %_1) unnamed_addr #0 !guid !48 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn() -> core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>, core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>
  %0 = call { ptr, ptr } @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB1e_5error5ErrorEL_EEB19_ECsgBxaKiRzQCG_8main_err(ptr %_4) #18
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
; call <core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>> as std::process::Termination>::report
  %_2 = call i8 @_RNvXsY_NtCsddYV2PBJW9h_3std7processINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBC_5error5ErrorEL_EENtB5_11Termination6reportCsgBxaKiRzQCG_8main_err(ptr %_3.0, ptr %_3.1)
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsgBxaKiRzQCG_8main_err(i8 %_2) #15
  ret i32 %_0
}

; <std::rt::lang_start<core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBN_5error5ErrorEL_EEE0INtNtNtBN_3ops8function6FnOnceuE9call_once6vtableCsgBxaKiRzQCG_8main_err(ptr %_1) unnamed_addr #0 !guid !49 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBL_5error5ErrorEL_EEE0INtNtNtBL_3ops8function6FnOnceuE9call_onceCsgBxaKiRzQCG_8main_err(ptr %0) #15
  ret i32 %_0
}

; main_err::run
; Function Attrs: nonlazybind uwtable
define internal { i1, i8 } @_RNvCsgBxaKiRzQCG_8main_err3run(i8 %n) unnamed_addr #1 !guid !50 {
start:
  %_0 = alloca [2 x i8], align 1
  %_2 = icmp ugt i8 %n, 3
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %n, ptr %0, align 1
  store i8 0, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %n, ptr %1, align 1
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  %5 = load i8, ptr %4, align 1
  %6 = insertvalue { i1, i8 } poison, i1 %3, 0
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1
  ret { i1, i8 } %7
}

; main_err::main
; Function Attrs: nonlazybind uwtable
define hidden { ptr, ptr } @_RNvCsgBxaKiRzQCG_8main_err4main() unnamed_addr #1 !guid !51 {
start:
  %_28 = alloca [16 x i8], align 8
  %args1 = alloca [16 x i8], align 8
  %_21 = alloca [2 x i8], align 1
  %_20 = alloca [1 x i8], align 1
  %_13 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_6 = alloca [2 x i8], align 1
  %_5 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
; call core::hint::black_box::<u8>
  %_8 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECsgBxaKiRzQCG_8main_err(i8 2) #15
; call main_err::run
  %0 = call { i1, i8 } @_RNvCsgBxaKiRzQCG_8main_err3run(i8 %_8)
  %_7.0 = extractvalue { i1, i8 } %0, 0
  %_7.1 = extractvalue { i1, i8 } %0, 1
; call <core::result::Result<u8, main_err::Failure> as core::ops::try_trait::Try>::branch
  %1 = call { i1, i8 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthNtCsgBxaKiRzQCG_8main_err7FailureENtNtNtB7_3ops9try_trait3Try6branchBN_(i1 zeroext %_7.0, i8 %_7.1) #15
  %2 = extractvalue { i1, i8 } %1, 0
  %3 = extractvalue { i1, i8 } %1, 1
  %4 = zext i1 %2 to i8
  store i8 %4, ptr %_6, align 1
  %5 = getelementptr inbounds i8, ptr %_6, i64 1
  store i8 %3, ptr %5, align 1
  %6 = load i8, ptr %_6, align 1
  %7 = trunc nuw i8 %6 to i1
  %8 = getelementptr inbounds i8, ptr %_6, i64 1
  %9 = load i8, ptr %8, align 1
  %_9 = zext i1 %7 to i64
  %10 = trunc nuw i64 %_9 to i1
  br i1 %10, label %bb6, label %bb5

bb6:                                              ; preds = %start
  %11 = getelementptr inbounds i8, ptr %_6, i64 1
  %residual3 = load i8, ptr %11, align 1
; call <core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, main_err::Failure>>>::from_residual
  %12 = call { ptr, ptr } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtCsgBxaKiRzQCG_8main_err7FailureEE13from_residualB2S_(i8 %residual3, ptr align 8 @alloc_73e00bbe92b269bd917c0bd60b1bd34e) #15
  %13 = extractvalue { ptr, ptr } %12, 0
  %14 = extractvalue { ptr, ptr } %12, 1
  store ptr %13, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %14, ptr %15, align 8
  br label %bb20

bb5:                                              ; preds = %start
  %16 = getelementptr inbounds i8, ptr %_6, i64 1
  %val = load i8, ptr %16, align 1
  store i8 %val, ptr %_5, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_13, ptr %_5) #15
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_13, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %18 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args) #15
  %_2.0 = extractvalue { ptr, ptr } %18, 0
  %_2.1 = extractvalue { ptr, ptr } %18, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<u8>
  %_23 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECsgBxaKiRzQCG_8main_err(i8 9) #15
; call main_err::run
  %19 = call { i1, i8 } @_RNvCsgBxaKiRzQCG_8main_err3run(i8 %_23)
  %_22.0 = extractvalue { i1, i8 } %19, 0
  %_22.1 = extractvalue { i1, i8 } %19, 1
; call <core::result::Result<u8, main_err::Failure> as core::ops::try_trait::Try>::branch
  %20 = call { i1, i8 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthNtCsgBxaKiRzQCG_8main_err7FailureENtNtNtB7_3ops9try_trait3Try6branchBN_(i1 zeroext %_22.0, i8 %_22.1) #15
  %21 = extractvalue { i1, i8 } %20, 0
  %22 = extractvalue { i1, i8 } %20, 1
  %23 = zext i1 %21 to i8
  store i8 %23, ptr %_21, align 1
  %24 = getelementptr inbounds i8, ptr %_21, i64 1
  store i8 %22, ptr %24, align 1
  %25 = load i8, ptr %_21, align 1
  %26 = trunc nuw i8 %25 to i1
  %27 = getelementptr inbounds i8, ptr %_21, i64 1
  %28 = load i8, ptr %27, align 1
  %_24 = zext i1 %26 to i64
  %29 = trunc nuw i64 %_24 to i1
  br i1 %29, label %bb14, label %bb13

bb14:                                             ; preds = %bb5
  %30 = getelementptr inbounds i8, ptr %_21, i64 1
  %residual = load i8, ptr %30, align 1
; call <core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, main_err::Failure>>>::from_residual
  %31 = call { ptr, ptr } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtCsgBxaKiRzQCG_8main_err7FailureEE13from_residualB2S_(i8 %residual, ptr align 8 @alloc_8f3685dfb161361f0a4bf6d2a0a22f82) #15
  %32 = extractvalue { ptr, ptr } %31, 0
  %33 = extractvalue { ptr, ptr } %31, 1
  store ptr %32, ptr %_0, align 8
  %34 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %33, ptr %34, align 8
  br label %bb20

bb13:                                             ; preds = %bb5
  %35 = getelementptr inbounds i8, ptr %_21, i64 1
  %val2 = load i8, ptr %35, align 1
  store i8 %val2, ptr %_20, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_28, ptr %_20) #15
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_28, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %37 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args1) #15
  %_17.0 = extractvalue { ptr, ptr } %37, 0
  %_17.1 = extractvalue { ptr, ptr } %37, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_17.0, ptr %_17.1)
; call <core::fmt::Arguments>::from_str
  %38 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsgBxaKiRzQCG_8main_err(ptr @alloc_6ac7cec0a18e60d101239f56a7eda11e, i64 12) #15
  %_32.0 = extractvalue { ptr, ptr } %38, 0
  %_32.1 = extractvalue { ptr, ptr } %38, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_32.0, ptr %_32.1)
  store ptr null, ptr %_0, align 8
  br label %bb20

bb20:                                             ; preds = %bb6, %bb14, %bb13
  %39 = load ptr, ptr %_0, align 8
  %40 = getelementptr inbounds i8, ptr %_0, i64 8
  %41 = load ptr, ptr %40, align 8
  %42 = insertvalue { ptr, ptr } poison, ptr %39, 0
  %43 = insertvalue { ptr, ptr } %42, ptr %41, 1
  ret { ptr, ptr } %43

bb4:                                              ; No predecessors!
  unreachable
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsgBxaKiRzQCG_8main_err(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !52 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsgBxaKiRzQCG_8main_err(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !53 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsgBxaKiRzQCG_8main_err() #15
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsgBxaKiRzQCG_8main_err(i64 %align, ptr align 8 %0) #19
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsgBxaKiRzQCG_8main_err(i64 %self) unnamed_addr #0 !guid !54 {
start:
  ret i64 %self
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsgBxaKiRzQCG_8main_err(ptr align 8 %self) unnamed_addr #0 !guid !55 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsgBxaKiRzQCG_8main_err(i64 %_3) #15
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #15
  ret ptr %_0
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsgBxaKiRzQCG_8main_err(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !56 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsgBxaKiRzQCG_8main_err(i64 %size, i64 %alignment, ptr align 8 %0) #19
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsgBxaKiRzQCG_8main_err(ptr align 8 %self) unnamed_addr #0 !guid !57 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsgBxaKiRzQCG_8main_err(ptr align 8 %self) unnamed_addr #0 !guid !58 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsgBxaKiRzQCG_8main_err(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !59 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsgBxaKiRzQCG_8main_err(i64 %3, i64 %5, i1 zeroext %8) #15
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsgBxaKiRzQCG_8main_err(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !60 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsgBxaKiRzQCG_8main_err(ptr %2, i64 %4, i64 %6) #15
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsgBxaKiRzQCG_8main_err(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !61 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #15
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsgBxaKiRzQCG_8main_err(i64 %11, i64 %13) #15
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsgBxaKiRzQCG_8main_err(i64 %15, i64 %17) #15
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #15
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #15
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #15
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #15
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #15
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsgBxaKiRzQCG_8main_err(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !62 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsgBxaKiRzQCG_8main_err(ptr %ptr, i64 %3, i64 %5) #15
  br label %bb3
}

; <core::ptr::unique::Unique<dyn core::error::Error>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_5error5ErrorEL_E6as_ptrCsgBxaKiRzQCG_8main_err(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !63 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::error::Error>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB9_5error5ErrorEL_EE8from_refCsgBxaKiRzQCG_8main_err(ptr align 8 %r) unnamed_addr #0 !guid !64 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::as_statically_known_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments23as_statically_known_strCsgBxaKiRzQCG_8main_err(ptr align 8 %self) unnamed_addr #0 !guid !65 {
start:
  %s = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::fmt::Arguments>::as_str
  %0 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsgBxaKiRzQCG_8main_err(ptr align 8 %self) #15
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %s, align 8
  %3 = getelementptr inbounds i8, ptr %s, i64 8
  store i64 %2, ptr %3, align 8
; call <core::option::Option<&str>>::is_some
  %_4 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionReE7is_someB4_(ptr align 8 %s) #15
  %_3 = call i1 @llvm.is.constant.i1(i1 %_4)
  br i1 %_3, label %bb4, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb4:                                              ; preds = %start
  %4 = load ptr, ptr %s, align 8
  %5 = getelementptr inbounds i8, ptr %s, i64 8
  %6 = load i64, ptr %5, align 8
  store ptr %4, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %6, ptr %7, align 8
  br label %bb6

bb6:                                              ; preds = %bb4, %bb5
  %8 = load ptr, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  %10 = load i64, ptr %9, align 8
  %11 = insertvalue { ptr, i64 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %10, 1
  ret { ptr, i64 } %12
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsgBxaKiRzQCG_8main_err(ptr align 8 %self) unnamed_addr #0 !guid !66 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #15
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsgBxaKiRzQCG_8main_err(ptr %_7.0, i64 %_7.1) #15
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsgBxaKiRzQCG_8main_err(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !67 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsgBxaKiRzQCG_8main_err(ptr %s.0, i64 %s.1) #15
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsgBxaKiRzQCG_8main_err(ptr %self) unnamed_addr #0 !guid !68 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsgBxaKiRzQCG_8main_err(i8 %0) unnamed_addr #0 !guid !69 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsgBxaKiRzQCG_8main_err(ptr %self) #15
  ret i32 %_0
}

; <core::fmt::Formatter>::write_fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_fmtCsgBxaKiRzQCG_8main_err(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #0 !guid !70 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %fmt = alloca [16 x i8], align 8
  store ptr %0, ptr %fmt, align 8
  %2 = getelementptr inbounds i8, ptr %fmt, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_statically_known_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments23as_statically_known_strCsgBxaKiRzQCG_8main_err(ptr align 8 %fmt) #15
  %4 = extractvalue { ptr, i64 } %3, 0
  %5 = extractvalue { ptr, i64 } %3, 1
  store ptr %4, ptr %_3, align 8
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %5, ptr %6, align 8
  %7 = load ptr, ptr %_3, align 8
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = ptrtoint ptr %7 to i64
  %11 = icmp eq i64 %10, 0
  %_5 = select i1 %11, i64 0, i64 1
  %12 = trunc nuw i64 %_5 to i1
  br i1 %12, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %s.0 = load ptr, ptr %_3, align 8
  %13 = getelementptr inbounds i8, ptr %_3, i64 8
  %s.1 = load i64, ptr %13, align 8
  %_7.0 = load ptr, ptr %self, align 8
  %14 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load ptr, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %_7.1, i64 24
  %16 = load ptr, ptr %15, align 8, !invariant.load !40, !nonnull !40
  %17 = call zeroext i1 %16(ptr %_7.0, ptr %s.0, i64 %s.1) #15
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %_8.0 = load ptr, ptr %self, align 8
  %19 = getelementptr inbounds i8, ptr %self, i64 8
  %_8.1 = load ptr, ptr %19, align 8
  %20 = load ptr, ptr %fmt, align 8
  %21 = getelementptr inbounds i8, ptr %fmt, i64 8
  %22 = load ptr, ptr %21, align 8
; call core::fmt::write
  %23 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt5write(ptr %_8.0, ptr align 8 %_8.1, ptr %20, ptr %22)
  %24 = zext i1 %23 to i8
  store i8 %24, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %25 = load i8, ptr %_0, align 1
  %26 = trunc nuw i8 %25 to i1
  ret i1 %26

bb5:                                              ; No predecessors!
  unreachable
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsgBxaKiRzQCG_8main_err(i64 %0, i64 %1) unnamed_addr #0 !guid !71 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #20
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #20
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsgBxaKiRzQCG_8main_err(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !72 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #20
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsgBxaKiRzQCG_8main_err(i64 %0, i64 %1) unnamed_addr #0 !guid !73 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #20
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #20
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsgBxaKiRzQCG_8main_err(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !74 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsgBxaKiRzQCG_8main_err(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #15
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #21
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #15
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsgBxaKiRzQCG_8main_err() unnamed_addr #0 !guid !75 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsgBxaKiRzQCG_8main_err() #15
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsgBxaKiRzQCG_8main_err(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !76 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsgBxaKiRzQCG_8main_err(i64 %align, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !77 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsgBxaKiRzQCG_8main_err(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #22
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsgBxaKiRzQCG_8main_err(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !78 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsgBxaKiRzQCG_8main_err(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #22
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsgBxaKiRzQCG_8main_err() unnamed_addr #0 !guid !79 {
start:
  ret i1 true
}

; <main_err::Failure as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXCsgBxaKiRzQCG_8main_errNtB2_7FailureNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt(ptr %self, ptr align 8 %f) unnamed_addr #1 !guid !80 {
start:
  %_7 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_7, ptr %self) #15
  %0 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %_7, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<11, 1>
  %1 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr @alloc_51962fe56062ee42f21b1a5d2870e81d, ptr align 8 %args) #15
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call <core::fmt::Formatter>::write_fmt
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_fmtCsgBxaKiRzQCG_8main_err(ptr align 8 %f, ptr %_3.0, ptr %_3.1) #15
  ret i1 %_0
}

; <main_err::Failure as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs0_CsgBxaKiRzQCG_8main_errNtB5_7FailureNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !81 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_61562ee3f6625a42fbf3ac54f2988902, i64 7, ptr @alloc_905976595ed1b08e57e2b44a2acadea4, i64 4, ptr %_7, ptr align 8 @vtable.1)
  ret i1 %_0
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsgBxaKiRzQCG_8main_err(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !82 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsgBxaKiRzQCG_8main_err(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #15
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsgBxaKiRzQCG_8main_err(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !83 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsgBxaKiRzQCG_8main_err(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::boxed::Box<dyn core::error::Error> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtNtBM_3ops4drop4Drop4dropCsgBxaKiRzQCG_8main_err(ptr align 8 %self) unnamed_addr #0 !guid !84 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<dyn core::error::Error>>::as_ptr
  %1 = call { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_5error5ErrorEL_E6as_ptrCsgBxaKiRzQCG_8main_err(ptr %ptr.0, ptr align 8 %ptr.1) #15
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<dyn core::error::Error>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_5error5ErrorEL_ECsgBxaKiRzQCG_8main_err(ptr %_5.0, ptr align 8 %_5.1) #15
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsgBxaKiRzQCG_8main_err(ptr align 8 %layout) #15
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<dyn core::error::Error>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_5error5ErrorEL_E4casthECsgBxaKiRzQCG_8main_err(ptr %ptr.0, ptr align 8 %ptr.1) #15
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #15
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsgBxaKiRzQCG_8main_err(ptr %_10, ptr %_11, i64 %6, i64 %8) #15
  br label %bb7
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsgBxaKiRzQCG_8main_err() unnamed_addr #0 !guid !85 {
start:
  ret i8 0
}

; <core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>> as std::process::Termination>::report
; Function Attrs: nonlazybind uwtable
define internal i8 @_RNvXsY_NtCsddYV2PBJW9h_3std7processINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBC_5error5ErrorEL_EENtB5_11Termination6reportCsgBxaKiRzQCG_8main_err(ptr %0, ptr %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !86 {
start:
  %2 = alloca [16 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %err = alloca [16 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  %4 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_2 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_2 to i1
  br i1 %9, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %10 = load ptr, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %12 = load ptr, ptr %11, align 8
  store ptr %10, ptr %err, align 8
  %13 = getelementptr inbounds i8, ptr %err, i64 8
  store ptr %12, ptr %13, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<alloc::boxed::Box<dyn core::error::Error>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EECsgBxaKiRzQCG_8main_err(ptr sret([16 x i8]) align 8 %_10, ptr align 8 %err)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %start
; call <() as std::process::Termination>::report
  %14 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsgBxaKiRzQCG_8main_err() #15
  store i8 %14, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb6, %bb3
  %15 = load i8, ptr %_0, align 1
  ret i8 %15

bb8:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorEL_EECsgBxaKiRzQCG_8main_err(ptr align 8 %err) #16
          to label %bb9 unwind label %terminate

cleanup:                                          ; preds = %bb5, %bb4, %bb2
  %16 = landingpad { ptr, i32 }
          cleanup
  %17 = extractvalue { ptr, i32 } %16, 0
  %18 = extractvalue { ptr, i32 } %16, 1
  store ptr %17, ptr %2, align 8
  %19 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %18, ptr %19, align 8
  br label %bb8

bb4:                                              ; preds = %bb2
  %20 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %_10, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<12, 1>
  %21 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjc_Kj1_ECsgBxaKiRzQCG_8main_err(ptr @alloc_26978532d6004174455ea2130c477035, ptr align 8 %args)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  %_6.0 = extractvalue { ptr, ptr } %21, 0
  %_6.1 = extractvalue { ptr, ptr } %21, 1
; invoke std::io::stdio::attempt_print_to_stderr
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio23attempt_print_to_stderr(ptr %_6.0, ptr %_6.1)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  store i8 1, ptr %_0, align 1
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::error::Error>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_5error5ErrorEL_EECsgBxaKiRzQCG_8main_err(ptr align 8 %err)
  br label %bb7

terminate:                                        ; preds = %bb8
  %22 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb9:                                              ; preds = %bb8
  %23 = load ptr, ptr %2, align 8
  %24 = getelementptr inbounds i8, ptr %2, i64 8
  %25 = load i32, ptr %24, align 8
  %26 = insertvalue { ptr, i32 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i32 } %26, i32 %25, 1
  resume { ptr, i32 } %27

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<dyn core::error::Error> as core::convert::From<main_err::Failure>>::from
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXsd_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_EINtNtBW_7convert4FromNtCsgBxaKiRzQCG_8main_err7FailureE4fromB1S_(i8 %err) unnamed_addr #1 personality ptr @rust_eh_personality !guid !87 {
start:
  %_4.i = alloca [1 x i8], align 1
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; call alloc::boxed::box_new_uninit
  %_3.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsgBxaKiRzQCG_8main_err(i64 1, i64 1) #15
  store i8 0, ptr %_4.i, align 1
  store i8 %err, ptr %_3.i, align 1
  %0 = insertvalue { ptr, ptr } poison, ptr %_3.i, 0
  %1 = insertvalue { ptr, ptr } %0, ptr @vtable.2, 1
  ret { ptr, ptr } %1
}

; <alloc::boxed::Box<dyn core::error::Error> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsn_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_ENtNtBM_3fmt5Debug3fmtCsgBxaKiRzQCG_8main_err(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !88 {
start:
  %_4.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4.1 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4.1, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !40, !nonnull !40
  %_0 = call zeroext i1 %2(ptr %_4.0, ptr align 8 %f) #15
  ret i1 %_0
}

; <core::result::Result<u8, main_err::Failure> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthNtCsgBxaKiRzQCG_8main_err7FailureENtNtNtB7_3ops9try_trait3Try6branchBN_(i1 zeroext %0, i8 %1) unnamed_addr #0 !guid !89 {
start:
  %_0 = alloca [2 x i8], align 1
  %self = alloca [2 x i8], align 1
  %2 = zext i1 %0 to i8
  store i8 %2, ptr %self, align 1
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store i8 %1, ptr %3, align 1
  %4 = load i8, ptr %self, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %self, i64 1
  %7 = load i8, ptr %6, align 1
  %_2 = zext i1 %5 to i64
  %8 = trunc nuw i64 %_2 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %self, i64 1
  %e = load i8, ptr %9, align 1
  %10 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %e, ptr %10, align 1
  store i8 1, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %11 = getelementptr inbounds i8, ptr %self, i64 1
  %v = load i8, ptr %11, align 1
  %12 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %v, ptr %12, align 1
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %13 = load i8, ptr %_0, align 1
  %14 = trunc nuw i8 %13 to i1
  %15 = getelementptr inbounds i8, ptr %_0, i64 1
  %16 = load i8, ptr %15, align 1
  %17 = insertvalue { i1, i8 } poison, i1 %14, 0
  %18 = insertvalue { i1, i8 } %17, i8 %16, 1
  ret { i1, i8 } %18

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, main_err::Failure>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB7_5error5ErrorEL_EEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtCsgBxaKiRzQCG_8main_err7FailureEE13from_residualB2S_(i8 %residual, ptr align 8 %0) unnamed_addr #0 !guid !90 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <alloc::boxed::Box<dyn core::error::Error> as core::convert::From<main_err::Failure>>::from
  %1 = call { ptr, ptr } @_RNvXsd_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB7_3BoxDNtNtCsl10jNU3mE6R_4core5error5ErrorEL_EINtNtBW_7convert4FromNtCsgBxaKiRzQCG_8main_err7FailureE4fromB1S_(i8 %residual)
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_4.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_4.1, 1
  ret { ptr, ptr } %3

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() -> core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>> as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvYFEINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB9_5error5ErrorEL_EEINtNtNtB9_3ops8function6FnOnceuE9call_onceCsgBxaKiRzQCG_8main_err(ptr %_1) unnamed_addr #0 !guid !91 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = call { ptr, ptr } %_1()
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <std::rt::lang_start<core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBL_5error5ErrorEL_EEE0INtNtNtBL_3ops8function6FnOnceuE9call_onceCsgBxaKiRzQCG_8main_err(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !92 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBI_5error5ErrorEL_EEE0CsgBxaKiRzQCG_8main_err(ptr align 8 %_1) #15
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <main_err::Failure as core::error::Error>::description
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error11descriptionB4_(ptr %self) unnamed_addr #1 !guid !93 {
start:
  ret { ptr, i64 } { ptr @alloc_04d7ce44d7c86a9a02b346ab945bf155, i64 40 }
}

; <main_err::Failure as core::error::Error>::cause
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error5causeB4_(ptr %self) unnamed_addr #1 !guid !94 {
start:
; call <main_err::Failure as core::error::Error>::source
  %0 = call { ptr, ptr } @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error6sourceB4_(ptr %self)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <main_err::Failure as core::error::Error>::source
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error6sourceB4_(ptr %self) unnamed_addr #1 !guid !95 {
start:
  ret { ptr, ptr } { ptr null, ptr undef }
}

; <main_err::Failure as core::error::Error>::provide
; Function Attrs: nonlazybind uwtable
define internal void @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error7provideB4_(ptr %self, ptr align 8 %request.0, ptr align 8 %request.1) unnamed_addr #1 !guid !96 {
start:
  ret void
}

; <main_err::Failure as core::error::Error>::type_id
; Function Attrs: nonlazybind uwtable
define internal void @_RNvYNtCsgBxaKiRzQCG_8main_err7FailureNtNtCsl10jNU3mE6R_4core5error5Error7type_idB4_(ptr sret([16 x i8]) align 8 %_0, ptr %self) unnamed_addr #1 !guid !97 {
start:
; call <core::any::TypeId>::of::<main_err::Failure>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtCsgBxaKiRzQCG_8main_err7FailureEBM_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #5

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #6

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #0

; <core::option::Option<&str>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionReE7is_someB4_(ptr align 8) unnamed_addr #0

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i1(i1) #7

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #8

; core::fmt::write
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNtCsl10jNU3mE6R_4core3fmt5write(ptr, ptr align 8, ptr, ptr) unnamed_addr #1

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #5

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #9

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #10

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #11

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #12

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #6

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #13

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; <core::fmt::Arguments>::new::<11, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; std::io::stdio::attempt_print_to_stderr
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio23attempt_print_to_stderr(ptr, ptr) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #14 !guid !98 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<core::result::Result<(), alloc::boxed::Box<dyn core::error::Error>>>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startINtNtCsl10jNU3mE6R_4core6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtBG_5error5ErrorEL_EEECsgBxaKiRzQCG_8main_err(ptr @_RNvCsgBxaKiRzQCG_8main_err4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #8 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { nonlazybind "target-cpu"="x86-64" }
attributes #15 = { inlinehint }
attributes #16 = { cold }
attributes #17 = { cold noreturn nounwind }
attributes #18 = { noinline }
attributes #19 = { inlinehint nounwind }
attributes #20 = { nounwind }
attributes #21 = { noreturn }
attributes #22 = { noinline noreturn nounwind }

!llvm.module.flags = !{!25, !26, !27, !28}
!llvm.ident = !{!29}

!0 = !{i64 1723589102790171024}
!1 = !{i64 1523220262941232655}
!2 = !{i64 6061874761778877497}
!3 = !{i64 3731938368918820605}
!4 = !{i64 7067518944258851291}
!5 = !{i64 -4075143487390715771}
!6 = !{i64 -4427764069718308713}
!7 = !{i64 -8054491360670688216}
!8 = !{i64 1987806049183105537}
!9 = !{i64 -2545476024046721804}
!10 = !{i64 -6686825904222405255}
!11 = !{i64 -6838754793597817301}
!12 = !{i64 1844815930504092041}
!13 = !{i64 5533536237564066162}
!14 = !{i64 5969992506778075772}
!15 = !{i64 -8922156589210656561}
!16 = !{i64 -7679174789706796851}
!17 = !{i64 -7667264264230603596}
!18 = !{i64 -5662477725593858233}
!19 = !{i64 4616447715733488120}
!20 = !{i64 -5664614949279012684}
!21 = !{i64 -8550217321659187439}
!22 = !{i64 -3580219233998926808}
!23 = !{i64 5790128789980947676}
!24 = !{i64 6309043605956974172}
!25 = !{i32 8, !"PIC Level", i32 2}
!26 = !{i32 7, !"PIE Level", i32 2}
!27 = !{i32 2, !"RtLibUseGOT", i32 1}
!28 = !{i32 7, !"uwtable", i32 2}
!29 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!30 = !{i64 4830122227178318983}
!31 = !{i64 -8808242722935141677}
!32 = !{i64 6854382986134926710}
!33 = !{i64 2755222876773326720}
!34 = !{i64 1732799707060953173}
!35 = !{i64 2706659451052680454}
!36 = !{i64 -3818121763124426506}
!37 = !{i64 6150623599836862032}
!38 = !{i64 -523317001036025605}
!39 = !{i64 -7176291103515770631}
!40 = !{}
!41 = !{i64 8650900015005954818}
!42 = !{i64 1062457299358888625}
!43 = !{i64 8074948258017342084}
!44 = !{i64 2983170013251584614}
!45 = !{i64 1549769482920639252}
!46 = !{i64 6564857513464465}
!47 = !{i64 -963946994764394270}
!48 = !{i64 6484070896564471924}
!49 = !{i64 -3390094829852007103}
!50 = !{i64 -8282309825444099002}
!51 = !{i64 9177590619553151846}
!52 = !{i64 -4449948893350716599}
!53 = !{i64 -7239579001250093573}
!54 = !{i64 6953861863962602111}
!55 = !{i64 3291446099038241483}
!56 = !{i64 -8794192880155058211}
!57 = !{i64 8130496097422842674}
!58 = !{i64 -5274073461883429754}
!59 = !{i64 -476016206018602591}
!60 = !{i64 5135845326971184305}
!61 = !{i64 6544647926557737352}
!62 = !{i64 1393880719911725430}
!63 = !{i64 7783261582094480098}
!64 = !{i64 -2416449021959915460}
!65 = !{i64 7063893586922970798}
!66 = !{i64 5381587831594267218}
!67 = !{i64 -8506291668579843718}
!68 = !{i64 7735700014202940790}
!69 = !{i64 3580525739411359540}
!70 = !{i64 -4898738008926936041}
!71 = !{i64 -206140607088277249}
!72 = !{i64 -1440536109381723797}
!73 = !{i64 1915361740957626149}
!74 = !{i64 -1696553178931893347}
!75 = !{i64 -1400507767905184489}
!76 = !{i64 7071668254884238350}
!77 = !{i64 7323609423109501291}
!78 = !{i64 -3182012645664741984}
!79 = !{i64 -7276335893774596554}
!80 = !{i64 1855225586192448949}
!81 = !{i64 -8933040010201405782}
!82 = !{i64 -843418910415706977}
!83 = !{i64 3499563104874388899}
!84 = !{i64 8839308383150194665}
!85 = !{i64 3606624606477409358}
!86 = !{i64 7749514933229358642}
!87 = !{i64 4275837769554919656}
!88 = !{i64 2107927508782958199}
!89 = !{i64 3014959132644950242}
!90 = !{i64 9087109035335490814}
!91 = !{i64 -1929332347752882138}
!92 = !{i64 -3755781120966918776}
!93 = !{i64 3398817392982304784}
!94 = !{i64 -4473501057062079292}
!95 = !{i64 1220023506881259479}
!96 = !{i64 -6509673506499042855}
!97 = !{i64 -9064383321184653791}
!98 = !{i64 -2624081020897602054}
