; ModuleID = 'panic_slice_range.73016da69c373dda-cgu.0'
source_filename = "panic_slice_range.73016da69c373dda-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs9SaFawSsn8c_17panic_slice_range, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs9SaFawSsn8c_17panic_slice_range, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs9SaFawSsn8c_17panic_slice_range }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_a5b38ee777bdd97ba83f5ee8fee54adf = private unnamed_addr constant [41 x i8] c"test/rust/synthetic/panic-slice-range.rs\00", align 1, !guid !2
@alloc_84207ad81ffd74b0d3f37246e8d88e27 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a5b38ee777bdd97ba83f5ee8fee54adf, [16 x i8] c"(\00\00\00\00\00\00\00\06\00\00\00.\00\00\00" }>, align 8, !guid !3
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !4
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !5

; <core::fmt::rt::Argument>::new_debug::<&[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRShECs9SaFawSsn8c_17panic_slice_range(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !11 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&[u8]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRShE8from_refCs9SaFawSsn8c_17panic_slice_range(ptr align 8 %x) #8
; call <core::ptr::non_null::NonNull<&[u8]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRShE4castuECs9SaFawSsn8c_17panic_slice_range(ptr %_4) #8
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRShNtB6_5Debug3fmtCsddYV2PBJW9h_3std, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<&[u8]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRShE4castuECs9SaFawSsn8c_17panic_slice_range(ptr %self) unnamed_addr #0 !guid !12 {
start:
  ret ptr %self
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs9SaFawSsn8c_17panic_slice_range(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !13 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECs9SaFawSsn8c_17panic_slice_range(i64 %dummy) unnamed_addr #0 !guid !14 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !15
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs9SaFawSsn8c_17panic_slice_range(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !16 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs9SaFawSsn8c_17panic_slice_range(ptr %f) #8
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #8
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs9SaFawSsn8c_17panic_slice_range(ptr align 8 %_1) unnamed_addr #0 !guid !17 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs9SaFawSsn8c_17panic_slice_range(ptr %_4) #9
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs9SaFawSsn8c_17panic_slice_range() #8
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs9SaFawSsn8c_17panic_slice_range(i8 %_2) #8
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs9SaFawSsn8c_17panic_slice_range(ptr %_1) unnamed_addr #0 !guid !18 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs9SaFawSsn8c_17panic_slice_range(ptr %0) #8
  ret i32 %_0
}

; panic_slice_range::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs9SaFawSsn8c_17panic_slice_range4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !19 {
start:
  %0 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_8 = alloca [16 x i8], align 8
  %v = alloca [24 x i8], align 8
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs9SaFawSsn8c_17panic_slice_range(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #8
  %_2.0 = extractvalue { ptr, ptr } %1, 0
  %_2.1 = extractvalue { ptr, ptr } %1, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call alloc::vec::from_elem::<u8>
  call void @_RINvNtCs7CppTae75M1_5alloc3vec9from_elemhECsddYV2PBJW9h_3std(ptr sret([24 x i8]) align 8 %v, i8 1, i64 3)
; invoke core::hint::black_box::<usize>
  %_12 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECs9SaFawSsn8c_17panic_slice_range(i64 2)
          to label %bb4 unwind label %cleanup

bb13:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEEBG_(ptr align 8 %v) #10
          to label %bb14 unwind label %terminate

cleanup:                                          ; preds = %bb10, %bb9, %bb8, %bb7, %bb6, %bb5, %bb4, %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb13

bb4:                                              ; preds = %start
; invoke core::hint::black_box::<usize>
  %_13 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECs9SaFawSsn8c_17panic_slice_range(i64 5)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
; invoke <alloc::vec::Vec<u8> as core::ops::index::Index<core::ops::range::Range<usize>>>::index
  %6 = invoke { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VechEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBM_5range5RangejEE5indexCs9SaFawSsn8c_17panic_slice_range(ptr align 8 %v, i64 %_12, i64 %_13, ptr align 8 @alloc_84207ad81ffd74b0d3f37246e8d88e27)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, i64 } %6, 0
  %_9.1 = extractvalue { ptr, i64 } %6, 1
  store ptr %_9.0, ptr %_8, align 8, !captures !20
  %7 = getelementptr inbounds i8, ptr %_8, i64 8
  store i64 %_9.1, ptr %7, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<&[u8]>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRShECs9SaFawSsn8c_17panic_slice_range(ptr sret([16 x i8]) align 8 %_15, ptr align 8 %_8)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
  %8 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %8, ptr align 8 %_15, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %9 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %_5.0 = extractvalue { ptr, ptr } %9, 0
  %_5.1 = extractvalue { ptr, ptr } %9, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_5.0, ptr %_5.1)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs9SaFawSsn8c_17panic_slice_range(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12)
          to label %bb10 unwind label %cleanup

bb10:                                             ; preds = %bb9
  %_19.0 = extractvalue { ptr, ptr } %10, 0
  %_19.1 = extractvalue { ptr, ptr } %10, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_19.0, ptr %_19.1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEEBG_(ptr align 8 %v)
  ret void

terminate:                                        ; preds = %bb13
  %11 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #11
  unreachable

bb14:                                             ; preds = %bb13
  %12 = load ptr, ptr %0, align 8
  %13 = getelementptr inbounds i8, ptr %0, i64 8
  %14 = load i32, ptr %13, align 8
  %15 = insertvalue { ptr, i32 } poison, ptr %12, 0
  %16 = insertvalue { ptr, i32 } %15, i32 %14, 1
  resume { ptr, i32 } %16
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs9SaFawSsn8c_17panic_slice_range(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !21 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::ptr::non_null::NonNull<&[u8]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRShE8from_refCs9SaFawSsn8c_17panic_slice_range(ptr align 8 %r) unnamed_addr #0 !guid !22 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs9SaFawSsn8c_17panic_slice_range(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !23 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs9SaFawSsn8c_17panic_slice_range(ptr %s.0, i64 %s.1) #8
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs9SaFawSsn8c_17panic_slice_range(ptr %self) unnamed_addr #0 !guid !24 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCs9SaFawSsn8c_17panic_slice_range(i64 %self, i64 %rhs) unnamed_addr #0 !guid !25 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs9SaFawSsn8c_17panic_slice_range(i8 %0) unnamed_addr #0 !guid !26 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs9SaFawSsn8c_17panic_slice_range(ptr %self) #8
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs9SaFawSsn8c_17panic_slice_range() unnamed_addr #0 !guid !27 {
start:
  ret i8 0
}

; <alloc::vec::Vec<u8> as core::ops::index::Index<core::ops::range::Range<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VechEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBM_5range5RangejEE5indexCs9SaFawSsn8c_17panic_slice_range(ptr align 8 %self, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !28 {
start:
  %_3.i = alloca [16 x i8], align 8
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<u8> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefB7_(ptr align 8 %self) #8
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize>::checked_sub
  %2 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCs9SaFawSsn8c_17panic_slice_range(i64 %index.1, i64 %index.0) #8
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %_3.i, align 8
  %5 = getelementptr inbounds i8, ptr %_3.i, i64 8
  store i64 %4, ptr %5, align 8
  %_6.i = load i64, ptr %_3.i, align 8
  %6 = getelementptr inbounds i8, ptr %_3.i, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = trunc nuw i64 %_6.i to i1
  br i1 %8, label %bb2.i, label %bb5.i

bb2.i:                                            ; preds = %bb1
  %9 = getelementptr inbounds i8, ptr %_3.i, i64 8
  %new_len.i = load i64, ptr %9, align 8
  %_8.i = icmp ule i64 %index.1, %_3.1
  br i1 %_8.i, label %_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexShE5indexCs9SaFawSsn8c_17panic_slice_range.exit, label %bb5.i

bb5.i:                                            ; preds = %bb2.i, %bb1
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %index.0, i64 %index.1, i64 %_3.1, ptr align 8 %0) #12
  unreachable

_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexShE5indexCs9SaFawSsn8c_17panic_slice_range.exit: ; preds = %bb2.i
  %ptr.i.i = getelementptr inbounds nuw i8, ptr %_3.0, i64 %index.0
  %10 = insertvalue { ptr, i64 } poison, ptr %ptr.i.i, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %new_len.i, 1
  %12 = insertvalue { ptr, i64 } poison, ptr %ptr.i.i, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %new_len.i, 1
  %_0.0.i = extractvalue { ptr, i64 } %13, 0
  %_0.1.i = extractvalue { ptr, i64 } %13, 1
  %_0.0 = extractvalue { ptr, i64 } %13, 0
  %_0.1 = extractvalue { ptr, i64 } %13, 1
  br label %bb2

bb2:                                              ; preds = %_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexShE5indexCs9SaFawSsn8c_17panic_slice_range.exit
  %14 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %_0.1, 1
  ret { ptr, i64 } %15

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs9SaFawSsn8c_17panic_slice_range(ptr %_1) unnamed_addr #0 !guid !29 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs9SaFawSsn8c_17panic_slice_range(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !30 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs9SaFawSsn8c_17panic_slice_range(ptr align 8 %_1) #8
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <&[u8] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRShNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #3

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #4

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; alloc::vec::from_elem::<u8>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCs7CppTae75M1_5alloc3vec9from_elemhECsddYV2PBJW9h_3std(ptr sret([24 x i8]) align 8, i8, i64) unnamed_addr #1

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEEBG_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #5

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64, i64, i64, ptr align 8) unnamed_addr #6

; <alloc::vec::Vec<u8> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefB7_(ptr align 8) unnamed_addr #0

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #7 !guid !31 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs9SaFawSsn8c_17panic_slice_range(ptr @_RNvCs9SaFawSsn8c_17panic_slice_range4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nonlazybind "target-cpu"="x86-64" }
attributes #8 = { inlinehint }
attributes #9 = { noinline }
attributes #10 = { cold }
attributes #11 = { cold noreturn nounwind }
attributes #12 = { noinline noreturn }

!llvm.module.flags = !{!6, !7, !8, !9}
!llvm.ident = !{!10}

!0 = !{i64 -1491095746457276536}
!1 = !{i64 -2240041981506565997}
!2 = !{i64 -6376643363769474123}
!3 = !{i64 -6192033215462490622}
!4 = !{i64 -8340098570253519191}
!5 = !{i64 -5911164298192225031}
!6 = !{i32 8, !"PIC Level", i32 2}
!7 = !{i32 7, !"PIE Level", i32 2}
!8 = !{i32 2, !"RtLibUseGOT", i32 1}
!9 = !{i32 7, !"uwtable", i32 2}
!10 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!11 = !{i64 -8621133551010274722}
!12 = !{i64 3257480428165981359}
!13 = !{i64 5229293933236483582}
!14 = !{i64 -1388570348841089914}
!15 = !{i64 1312885603346925}
!16 = !{i64 -149547269710520584}
!17 = !{i64 -2232463546612164453}
!18 = !{i64 -4457011189731813694}
!19 = !{i64 6128822682907939549}
!20 = !{!"address", !"read_provenance"}
!21 = !{i64 3618587334779035325}
!22 = !{i64 6150995540016651191}
!23 = !{i64 -1885821845331608471}
!24 = !{i64 1942921879024869693}
!25 = !{i64 -1291151124933399333}
!26 = !{i64 2350866004457542560}
!27 = !{i64 -2795559862199307078}
!28 = !{i64 496087294156552820}
!29 = !{i64 -7303541189588579835}
!30 = !{i64 3182338182695004292}
!31 = !{i64 -2624081020897602054}
