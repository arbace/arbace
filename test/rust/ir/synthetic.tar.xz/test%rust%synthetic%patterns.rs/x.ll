; ModuleID = 'patterns.8e266fd026c51d7e-cgu.0'
source_filename = "patterns.8e266fd026c51d7e-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%Shape = type { i8, [15 x i8] }
%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }
%"core::mem::maybe_uninit::MaybeUninit<&[i32]>" = type { [2 x i64] }

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !4
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsccF2givDBH6_8patterns, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsccF2givDBH6_8patterns, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsccF2givDBH6_8patterns }>, align 8, !guid !5
@alloc_e90bd9a80b7f188aa76a1bfb741a5999 = private unnamed_addr constant [34 x i8] c"core/src/array/iter/iter_inner.rs\00", align 1, !guid !6
@alloc_ac893681874450253b62899ecf8cf06a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\00 \00\00\00" }>, align 8, !guid !7
@alloc_b0b7c7361940ea6a8360c2bdef76bb12 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\003\00\00\00" }>, align 8, !guid !8
@alloc_139401184e972f55d7c52277555ebf28 = private unnamed_addr constant [32 x i8] c"test/rust/synthetic/patterns.rs\00", align 1, !guid !9
@alloc_a45afb4a24ba0a5e194bc1d8435a9889 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\19\00\00\00\1E\00\00\00" }>, align 8, !guid !10
@alloc_b08f953d6f66747da394290bbf63f3b6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\19\00\00\00\1D\00\00\00" }>, align 8, !guid !11
@alloc_6d3e25798981daeb9a264231f1e928fa = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\1A\00\00\00!\00\00\00" }>, align 8, !guid !12
@alloc_5f317668025e10a890a3eea4a8bef6ff = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00'\00\00\00\12\00\00\00" }>, align 8, !guid !13
@alloc_66e0d902dc5512250b9d4edb026cbbeb = private unnamed_addr constant [4 x i8] c"\01\00\00\00", align 4, !guid !14
@alloc_5598ad317332f65891d44d57bbdb4a57 = private unnamed_addr constant [12 x i8] c"\01\00\00\00\02\00\00\00\01\00\00\00", align 4, !guid !15
@alloc_03fa889ebefc3fd61240d008cccbcd8d = private unnamed_addr constant [12 x i8] c"\01\00\00\00\02\00\00\00\03\00\00\00", align 4, !guid !16
@alloc_df7fb09215c742e668e6254030a2bddf = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00(\00\00\00\12\00\00\00" }>, align 8, !guid !17
@alloc_b1e693e8528fb8140f163b7e7dd5f4c0 = private unnamed_addr constant [5 x i8] c"a = 5", align 1, !guid !18
@alloc_89c92c491e006e6ef9402d0dec0fc54d = private unnamed_addr constant [3 x i8] c"b=x", align 1, !guid !19
@alloc_18f2f0d3d4f38df552db2352111ec81f = private unnamed_addr constant [1 x i8] c"c", align 1, !guid !20
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !21
@alloc_37f62a15fae368a2423b3a16c75adcc9 = private unnamed_addr constant [1 x i8] c"x", align 1, !guid !22
@alloc_6a96e47ef75dbf6fc4eb5423ba7bb768 = private unnamed_addr constant [16 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !23
@alloc_144b8bda8b7d019167909d944f76599d = private unnamed_addr constant [14 x i8] c"\09in range \C0\01\0A\00", align 1, !guid !24
@alloc_b8a9faf0f44a085c631f2755716883c9 = private unnamed_addr constant [5 x i8] c"none\0A", align 1, !guid !25
@alloc_0e8a8a0ff4ea56ec3d4541bf7e74cfec = private unnamed_addr constant [11 x i8] c"inner none\0A", align 1, !guid !26
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !27
@alloc_c1fa64f4e819a506b7859bc956f830ca = private unnamed_addr constant [1 x i8] c"e", align 1, !guid !28
@alloc_31a9e8f7a570396788f7b2482a3a97e4 = private unnamed_addr constant [3 x i8] c"ok\0A", align 1, !guid !29
@alloc_c0c0bd6959bacd2127c8d4fc3870a66f = private unnamed_addr constant [9 x i8] c"\04err \C0\01\0A\00", align 1, !guid !30
@alloc_3dbdd06bebcf2fb86aed3e2f16680d42 = private unnamed_addr constant [8 x i8] c"guarded\0A", align 1, !guid !31
@alloc_acd822e6332f053907a9b112a94122d3 = private unnamed_addr constant [5 x i8] c"boxed", align 1, !guid !32
@alloc_50ab75e5eb17b3d68555764b0a52038b = private unnamed_addr constant [1 x i8] c"z", align 1, !guid !33
@alloc_69ea765c2672a934a5b64287f175d158 = private unnamed_addr constant [4 x i8] c"else", align 1, !guid !34
@alloc_78d5c01af63be55c3511bacffb1a7824 = private unnamed_addr constant [5 x i8] c"digit", align 1, !guid !35
@alloc_f424f6e87101d147a136ec9aa11fa034 = private unnamed_addr constant [4 x i8] c"pow2", align 1, !guid !36
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !37
@alloc_427cf7da6bbe57bf2fdbddfa3078c1f8 = private unnamed_addr constant [4 x i8] c"zero", align 1, !guid !38
@alloc_87862e78b478b6bd0b4ea1c7b6258769 = private unnamed_addr constant [5 x i8] c"small", align 1, !guid !39
@alloc_735ff844006bb5c32021c0456ffecbea = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\0A\00\00\00\0E\00\00\00" }>, align 8, !guid !40
@alloc_7ec976a351c849ad2fc3958edc69f6f6 = private unnamed_addr constant [3 x i8] c"big", align 1, !guid !41
@alloc_f5f4cccb72aa20d03a19e99c91cbe0b2 = private unnamed_addr constant [7 x i8] c"odd-mid", align 1, !guid !42
@alloc_fbf52d5fed6793d3e790c9ce6627a01c = private unnamed_addr constant [4 x i8] c"even", align 1, !guid !43
@alloc_7aa1a11e7908cb59b04764917ce720b4 = private unnamed_addr constant [3 x i8] c"neg", align 1, !guid !44
@alloc_29912b6d8be215f231ca050c1de43b0b = private unnamed_addr constant [17 x i8] c"\06first \C0\06 rest \C0\00", align 1, !guid !45
@alloc_8f41006de9107663c983a7194b89e648 = private unnamed_addr constant [13 x i8] c"\0Asame ends \C0\00", align 1, !guid !46
@alloc_33854f2712a70d661249338f09901dcb = private unnamed_addr constant [7 x i8] c"\04one \C0\00", align 1, !guid !47
@alloc_c597b50e4e89f734c8b5ae53c406eb3f = private unnamed_addr constant [5 x i8] c"empty", align 1, !guid !48
@alloc_0cc6dc99297ba9fc0efa6643cc60563b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\11\00\00\00\17\00\00\00" }>, align 8, !guid !49
@alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b = private unnamed_addr constant [28 x i8] c"core/src/ops/index_range.rs\00", align 1, !guid !50
@alloc_de9a5d9a80d554992107c1ea3afec081 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b, [16 x i8] c"\1B\00\00\00\00\00\00\00?\00\00\00%\00\00\00" }>, align 8, !guid !51
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !52
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !53
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !54
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !55
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !56
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !57
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !58
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !59
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !60
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !61
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !62
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !63
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !64
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !65
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !66
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !67
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !68
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !69
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !70
@alloc_97d92cbf2a68a6ac45a1b13da79836e4 = private unnamed_addr constant [214 x i8] c"unsafe precondition(s) violated: slice::get_unchecked requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !71
@alloc_5a8fdd84b3281310cbf6b74bb6bf0065 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !72
@alloc_61b2665611c43956f6751fc9541d260a = private unnamed_addr constant [6 x i8] c"Circle", align 1, !guid !73
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !74
@alloc_6319043cda67dca378296c9d6ea4e61a = private unnamed_addr constant [4 x i8] c"Rect", align 1, !guid !75
@alloc_91e924fd2a69c8524f72852661c5910c = private unnamed_addr constant [1 x i8] c"w", align 1, !guid !76
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @_RNvXsW_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !77
@alloc_d22b16ed1fc9d86532371a89eda619b7 = private unnamed_addr constant [1 x i8] c"h", align 1, !guid !78
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRmNtB6_5Debug3fmtCsa0i9X4ULBdE_6memchr }>, align 8, !guid !79
@alloc_b786fa3e298d0013cbd9d16f11d06f34 = private unnamed_addr constant [3 x i8] c"Tri", align 1, !guid !80
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !81
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_ }>, align 8, !guid !82
@alloc_59ba7b9f7211443cd55a366616eef46a = private unnamed_addr constant [5 x i8] c"Empty", align 1, !guid !83
@alloc_c7037efb906203803aa3ca07167c9120 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\13\00\00\00\17\00\00\00" }>, align 8, !guid !84
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !85
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !86
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !87
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRTRelENtB6_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !88

; <[patterns::Shape]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCsccF2givDBH6_8patterns5Shape8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !94 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[patterns::Shape]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeE23into_raw_with_allocatorBK_(ptr align 8 %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<patterns::Shape>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[patterns::Shape]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEEB1d_(ptr align 8 %self) #16
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable
}

; <str>::parse::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parselECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !95 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <i32 as core::str::traits::FromStr>::from_str
  %1 = call i64 @_RNvXso_NtCsl10jNU3mE6R_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) #18
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitRSlE13get_uncheckedjECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !96 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitRSlEE13get_uncheckedCsccF2givDBH6_8patterns(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #18
  ret ptr %_3
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitRSlE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !97 {
start:
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitRSlEE17get_unchecked_mutCsccF2givDBH6_8patterns(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #18
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxE13get_uncheckedjECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !98 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitxEE13get_uncheckedCsccF2givDBH6_8patterns(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #18
  ret ptr %_3
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !99 {
start:
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitxEE17get_unchecked_mutCsccF2givDBH6_8patterns(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #18
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <core::option::Option<usize>>::map::<&[i32], <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapRSlNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBZ_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECsccF2givDBH6_8patterns(i64 %0, i64 %1, ptr align 8 %f.0, i64 %f.1) unnamed_addr #0 !guid !100 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next::{closure#0}
  %7 = call { ptr, i64 } @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitRSlEE4next0CsccF2givDBH6_8patterns(ptr align 8 %f.0, i64 %f.1, i64 %x) #18
  %_5.0 = extractvalue { ptr, i64 } %7, 0
  %_5.1 = extractvalue { ptr, i64 } %7, 1
  store ptr %_5.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %8, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %9 = load i8, ptr %_8, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<usize>>::map::<i64, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapxNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBX_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxEE4next0ECsccF2givDBH6_8patterns(i64 %0, i64 %1, ptr align 8 %f.0, i64 %f.1) unnamed_addr #0 !guid !101 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next::{closure#0}
  %_5 = call i64 @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitxEE4next0CsccF2givDBH6_8patterns(ptr align 8 %f.0, i64 %f.1, i64 %x) #18
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %7, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_8, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %10 = load i64, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  %12 = load i64, ptr %11, align 8
  %13 = insertvalue { i64, i64 } poison, i64 %10, 0
  %14 = insertvalue { i64, i64 } %13, i64 %12, 1
  ret { i64, i64 } %14

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !102 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #18
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECsccF2givDBH6_8patterns(ptr %_4) #18
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCsccF2givDBH6_8patterns, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<&i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !103 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRlE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #18
; call <core::ptr::non_null::NonNull<&i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRlE4castuECsccF2givDBH6_8patterns(ptr %_4) #18
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRlNtB6_7Display3fmtCsccF2givDBH6_8patterns, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !104 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i16>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsccF2givDBH6_8patterns(ptr align 2 %x) #18
; call <core::ptr::non_null::NonNull<i16>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsccF2givDBH6_8patterns(ptr %_4) #18
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !105 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #18
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECsccF2givDBH6_8patterns(ptr %_4) #18
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<(&str, i32)>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionTRelEEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !106 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<(&str, i32)>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionTRelEEE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #18
; call <core::ptr::non_null::NonNull<core::option::Option<(&str, i32)>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionTRelEEE4castuECsccF2givDBH6_8patterns(ptr %_4) #18
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTRelEENtNtB7_3fmt5Debug3fmtCsccF2givDBH6_8patterns, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<&patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRNtCsccF2givDBH6_8patterns5ShapeEBY_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !107 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&patterns::Shape>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtCsccF2givDBH6_8patterns5ShapeE8from_refBW_(ptr align 8 %x) #18
; call <core::ptr::non_null::NonNull<&patterns::Shape>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtCsccF2givDBH6_8patterns5ShapeE4castuEBX_(ptr %_4) #18
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtCsccF2givDBH6_8patterns5ShapeNtB6_5Debug3fmtBy_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<&[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !108 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&[i32]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSlE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #18
; call <core::ptr::non_null::NonNull<&[i32]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSlE4castuECsccF2givDBH6_8patterns(ptr %_4) #18
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSlNtB6_5Debug3fmtCsccF2givDBH6_8patterns, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<[patterns::Shape]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEB18_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !109 {
start:
; call core::mem::align_of_val_raw::<[patterns::Shape]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEBM_(ptr %val.0, i64 %val.1) #18
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsccF2givDBH6_8patterns(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #18
  ret i64 %_0
}

; <core::alloc::layout::Layout>::for_value_raw::<[patterns::Shape]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCsccF2givDBH6_8patterns5ShapeEB17_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !110 {
start:
; call core::mem::size_of_val_raw::<[patterns::Shape]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEBL_(ptr %val.0, i64 %val.1) #18
; call <core::mem::alignment::Alignment>::of_val_raw::<[patterns::Shape]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEB18_(ptr %val.0, i64 %val.1) #18
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsccF2givDBH6_8patterns(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #18
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<[patterns::Shape]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCsccF2givDBH6_8patterns5ShapeE4casthEBU_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !111 {
start:
; call <core::ptr::non_null::NonNull<[patterns::Shape]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE4casthEBX_(ptr %self.0, i64 %self.1) #18
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCsccF2givDBH6_8patterns5ShapeEB10_(ptr %self) unnamed_addr #0 !guid !112 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<patterns::Shape>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCsccF2givDBH6_8patterns5ShapeEB13_(ptr %self) #18
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<core::option::Option<(&str, i32)>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionTRelEEE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !113 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !114 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&patterns::Shape>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtCsccF2givDBH6_8patterns5ShapeE4castuEBX_(ptr %self) unnamed_addr #0 !guid !115 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&[i32]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSlE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !116 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&i32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRlE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !117 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[patterns::Shape]>>::cast::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE4castBV_EBX_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !118 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[patterns::Shape]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE4casthEBX_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !119 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<u8>>::cast::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCsccF2givDBH6_8patterns5ShapeEB13_(ptr %self) unnamed_addr #0 !guid !120 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i16>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !121 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !122 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCsccF2givDBH6_8patterns5ShapeEBY_(ptr align 8 %self) unnamed_addr #0 !guid !123 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<patterns::Shape>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCsccF2givDBH6_8patterns5ShapeEB13_(ptr align 8 %self) #18
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCsccF2givDBH6_8patterns5ShapeEB13_(ptr align 8 %self) unnamed_addr #0 !guid !124 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<patterns::Shape>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCsccF2givDBH6_8patterns5ShapeEB10_(ptr %_3) #18
; call <core::ptr::unique::Unique<patterns::Shape>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCsccF2givDBH6_8patterns5ShapeE15as_non_null_ptrBS_(ptr %_2) #18
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<16, 5>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !125 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<9, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj9_Kj1_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !126 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !127 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !128 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECsccF2givDBH6_8patterns(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !129 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr %entries.0, ptr %entries.1) #18
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 8 %iter) #18
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !130
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.0)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; alloc::raw_vec::new_cap::<patterns::Shape>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCsccF2givDBH6_8patterns5ShapeEBG_(i64 %cap) unnamed_addr #1 !guid !131 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsccF2givDBH6_8patterns(i64 %cap) #18
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsccF2givDBH6_8patterns(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !132 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.1, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::mem::needs_drop::<&[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropRSlECsccF2givDBH6_8patterns() unnamed_addr #0 !guid !133 {
start:
  ret i1 false
}

; core::mem::needs_drop::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropxECsccF2givDBH6_8patterns() unnamed_addr #0 !guid !134 {
start:
  ret i1 false
}

; core::mem::size_of_val_raw::<[patterns::Shape]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEBL_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !135 {
start:
  %_0 = mul nuw nsw i64 %val.1, 16
  ret i64 %_0
}

; core::mem::align_of_val_raw::<[patterns::Shape]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEBM_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !136 {
start:
  %0 = mul nuw nsw i64 %val.1, 16
  ret i64 8
}

; core::ptr::slice_from_raw_parts_mut::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCsccF2givDBH6_8patterns5ShapeEBT_(ptr %data, i64 %len) unnamed_addr #0 !guid !137 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[patterns::Shape], patterns::Shape>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCsccF2givDBH6_8patterns5ShapeBX_EBZ_(ptr %data, i64 %len) #18
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<alloc::vec::Vec<patterns::Shape>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsccF2givDBH6_8patterns5ShapeEEB1a_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !138 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<patterns::Shape> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<patterns::Shape>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsccF2givDBH6_8patterns5ShapeEEB1h_(ptr align 8 %_1) #16
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<patterns::Shape>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsccF2givDBH6_8patterns5ShapeEEB1h_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<[patterns::Shape]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEEB1d_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !139 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[patterns::Shape]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #18
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<[patterns::Shape]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #16
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb2:                                              ; preds = %bb4
  %3 = load ptr, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8
  %6 = insertvalue { ptr, i32 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i32 } %6, i32 %5, 1
  resume { ptr, i32 } %7
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<patterns::Shape>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsccF2givDBH6_8patterns5ShapeEEB1h_(ptr align 8 %_1) unnamed_addr #1 !guid !140 {
start:
; call <alloc::raw_vec::RawVec<patterns::Shape> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<&[i32], 4>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterRSlKj4_EECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !141 {
start:
; call <core::array::iter::IntoIter<&[i32], 4> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterRSlKj4_ENtNtNtB9_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1) #18
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<i64, 7>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterxKj7_EECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !142 {
start:
; call <core::array::iter::IntoIter<i64, 7> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterxKj7_ENtNtNtB9_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1) #18
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitRSlEj4_EECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !143 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEj4_ENtNtNtBb_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1) #18
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitxEj7_EECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !144 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEj7_ENtNtNtBb_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1) #18
  ret void
}

; core::hint::black_box::<core::option::Option<core::option::Option<u8>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i8, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionIBD_hEEECsccF2givDBH6_8patterns(i8 %dummy.0, i8 %dummy.1) unnamed_addr #0 !guid !145 {
start:
  %_0 = alloca [2 x i8], align 1
  store i8 %dummy.0, ptr %_0, align 1
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %dummy.1, ptr %0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  %1 = load i8, ptr %_0, align 1
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  %3 = load i8, ptr %2, align 1
  %4 = insertvalue { i8, i8 } poison, i8 %1, 0
  %5 = insertvalue { i8, i8 } %4, i8 %3, 1
  ret { i8, i8 } %5
}

; core::hint::black_box::<core::option::Option<alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %dummy) unnamed_addr #0 !guid !147 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %dummy, i64 24, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  ret void
}

; core::hint::black_box::<core::option::Option<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECsccF2givDBH6_8patterns(i1 zeroext %dummy.0, i8 %dummy.1) unnamed_addr #0 !guid !148 {
start:
  %_0 = alloca [2 x i8], align 1
  %0 = zext i1 %dummy.0 to i8
  store i8 %0, ptr %_0, align 1
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %dummy.1, ptr %1, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  %5 = load i8, ptr %4, align 1
  %6 = insertvalue { i1, i8 } poison, i1 %3, 0
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1
  ret { i1, i8 } %7
}

; core::hint::black_box::<core::result::Result<u8, &str>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6result6ResulthReEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %dummy) unnamed_addr #0 !guid !149 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %dummy, i64 16, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  ret void
}

; core::hint::black_box::<&patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxRNtCsccF2givDBH6_8patterns5ShapeEBF_(ptr align 8 %dummy) unnamed_addr #0 !guid !150 {
start:
  %_0 = alloca [8 x i8], align 8
  store ptr %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; core::hint::black_box::<&[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxRSlECsccF2givDBH6_8patterns(ptr align 4 %dummy.0, i64 %dummy.1) unnamed_addr #0 !guid !151 {
start:
  %_0 = alloca [16 x i8], align 8
  store ptr %dummy.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %dummy.1, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  %1 = load ptr, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { ptr, i64 } poison, ptr %1, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %3, 1
  ret { ptr, i64 } %5
}

; core::hint::black_box::<(u8, (i16, &str), [i32; 3])>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxThTsReEAlj3_EECsccF2givDBH6_8patterns(ptr sret([40 x i8]) align 8 %_0, ptr align 8 %dummy) unnamed_addr #0 !guid !152 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %dummy, i64 40, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  ret void
}

; core::hint::black_box::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECsccF2givDBH6_8patterns(i1 zeroext %dummy) unnamed_addr #0 !guid !153 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = zext i1 %dummy to i8
  store i8 %0, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  %1 = load i8, ptr %_0, align 1
  %2 = trunc nuw i8 %1 to i1
  ret i1 %2
}

; core::hint::black_box::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxcECsccF2givDBH6_8patterns(i32 %dummy) unnamed_addr #0 !guid !154 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsccF2givDBH6_8patterns(i32 %dummy) unnamed_addr #0 !guid !155 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECsccF2givDBH6_8patterns(i64 %dummy) unnamed_addr #0 !guid !156 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !146
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsccF2givDBH6_8patterns(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !157 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsccF2givDBH6_8patterns(ptr %f) #18
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #18
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts_mut::<[patterns::Shape], patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCsccF2givDBH6_8patterns5ShapeBX_EBZ_(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !158 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitRSlEECsccF2givDBH6_8patterns(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !159 {
start:
  ret i64 %ptr.1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<i64>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitxEECsccF2givDBH6_8patterns(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !160 {
start:
  ret i64 %ptr.1
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #0 !guid !161 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsccF2givDBH6_8patterns(ptr %_4) #19
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsccF2givDBH6_8patterns() #18
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsccF2givDBH6_8patterns(i8 %_2) #18
  ret i32 %_0
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitRSlEE4next0CsccF2givDBH6_8patterns(ptr align 8 %_1.0, i64 %_1.1, i64 %idx) unnamed_addr #0 !guid !162 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::get_unchecked::<usize>
  %_3 = call align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitRSlE13get_uncheckedjECsccF2givDBH6_8patterns(ptr align 8 %_1.0, i64 %_1.1, i64 %idx, ptr align 8 @alloc_ac893681874450253b62899ecf8cf06a) #18
  %_0.0.i.i.i = load ptr, ptr %_3, align 8
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %_0.1.i.i.i = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1.i.i.i, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1.i.i.i, 1
  %5 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_0.1.i.i.i, 1
  %_0.0 = extractvalue { ptr, i64 } %6, 0
  %_0.1 = extractvalue { ptr, i64 } %6, 1
  %7 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %_0.1, 1
  ret { ptr, i64 } %8
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitxEE4next0CsccF2givDBH6_8patterns(ptr align 8 %_1.0, i64 %_1.1, i64 %idx) unnamed_addr #0 !guid !163 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<i64>]>::get_unchecked::<usize>
  %_3 = call align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxE13get_uncheckedjECsccF2givDBH6_8patterns(ptr align 8 %_1.0, i64 %_1.1, i64 %idx, ptr align 8 @alloc_ac893681874450253b62899ecf8cf06a) #18
  %_0.i.i.i = load i64, ptr %_3, align 8
  ret i64 %_0.i.i.i
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsccF2givDBH6_8patterns(ptr %_1) unnamed_addr #0 !guid !164 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsccF2givDBH6_8patterns(ptr %0) #18
  ret i32 %_0
}

; patterns::area
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCsccF2givDBH6_8patterns4area(ptr align 8 %s) unnamed_addr #1 !guid !165 {
start:
  %c = alloca [8 x i8], align 8
  %b = alloca [8 x i8], align 8
  %a = alloca [8 x i8], align 8
  %_0 = alloca [4 x i8], align 4
  %0 = load i8, ptr %s, align 8
  %_2 = zext i8 %0 to i64
  switch i64 %_2, label %bb1 [
    i64 0, label %bb5
    i64 1, label %bb4
    i64 2, label %bb3
    i64 3, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb5:                                              ; preds = %start
  %r = getelementptr inbounds i8, ptr %s, i64 8
; call <f64 as core::ops::arith::Mul<&f64>>::mul
  %_5 = call double @_RNvXs2Z_NtNtCsl10jNU3mE6R_4core3ops5arithdINtB6_3MulRdE3mulCsccF2givDBH6_8patterns(double 3.140000e+00, ptr align 8 %r, ptr align 8 @alloc_a45afb4a24ba0a5e194bc1d8435a9889) #18
; call <f64 as core::ops::arith::Mul<&f64>>::mul
  %_4 = call double @_RNvXs2Z_NtNtCsl10jNU3mE6R_4core3ops5arithdINtB6_3MulRdE3mulCsccF2givDBH6_8patterns(double %_5, ptr align 8 %r, ptr align 8 @alloc_b08f953d6f66747da394290bbf63f3b6) #18
  %1 = call i32 @llvm.fptoui.sat.i32.f64(double %_4)
  store i32 %1, ptr %_0, align 4
  br label %bb13

bb4:                                              ; preds = %start
  %w = getelementptr inbounds i8, ptr %s, i64 4
  %h = getelementptr inbounds i8, ptr %s, i64 8
; call <&u32 as core::ops::arith::Mul>::mul
  %2 = call i32 @_RNvXs2t_NtNtCsl10jNU3mE6R_4core3ops5arithRmNtB6_3Mul3mulCsccF2givDBH6_8patterns(ptr align 4 %w, ptr align 4 %h, ptr align 8 @alloc_6d3e25798981daeb9a264231f1e928fa) #18
  store i32 %2, ptr %_0, align 4
  br label %bb13

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %s, i64 1
  store ptr %3, ptr %a, align 8
  %4 = getelementptr inbounds i8, ptr %s, i64 2
  store ptr %4, ptr %b, align 8
  %5 = getelementptr inbounds i8, ptr %s, i64 3
  store ptr %5, ptr %c, align 8
; call <&u8 as core::cmp::PartialEq>::eq
  %_14 = call zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRhNtB7_9PartialEq2eqCsddYV2PBJW9h_3std(ptr align 8 %a, ptr align 8 %b) #18
  br i1 %_14, label %bb9, label %bb12

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb13

bb13:                                             ; preds = %bb2, %bb11, %bb12, %bb4, %bb5
  %6 = load i32, ptr %_0, align 4
  ret i32 %6

bb12:                                             ; preds = %bb9, %bb3
  %a1 = getelementptr inbounds i8, ptr %s, i64 1
  %_17 = load i8, ptr %a1, align 1
  %7 = zext i8 %_17 to i32
  store i32 %7, ptr %_0, align 4
  br label %bb13

bb9:                                              ; preds = %bb3
; call <&u8 as core::cmp::PartialEq>::eq
  %_15 = call zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRhNtB7_9PartialEq2eqCsddYV2PBJW9h_3std(ptr align 8 %b, ptr align 8 %c) #18
  br i1 %_15, label %bb11, label %bb12

bb11:                                             ; preds = %bb9
  store i32 1, ptr %_0, align 4
  br label %bb13
}

; patterns::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsccF2givDBH6_8patterns4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !166 {
start:
  %0 = alloca [16 x i8], align 8
  %_206 = alloca [16 x i8], align 8
  %args17 = alloca [16 x i8], align 8
  %y = alloca [16 x i8], align 8
  %x16 = alloca [4 x i8], align 4
  %_191 = alloca [16 x i8], align 8
  %args15 = alloca [16 x i8], align 8
  %_189 = alloca [8 x i8], align 8
  %_182 = alloca [24 x i8], align 8
  %_181 = alloca [24 x i8], align 8
  %_180 = alloca [24 x i8], align 8
  %_176 = alloca [16 x i8], align 8
  %args14 = alloca [16 x i8], align 8
  %_170 = alloca [4 x i8], align 4
  %_162 = alloca [16 x i8], align 8
  %args13 = alloca [16 x i8], align 8
  %e12 = alloca [16 x i8], align 8
  %_147 = alloca [16 x i8], align 8
  %r = alloca [16 x i8], align 8
  %_139 = alloca [16 x i8], align 8
  %args11 = alloca [16 x i8], align 8
  %x = alloca [1 x i8], align 1
  %opt = alloca [2 x i8], align 1
  %_125 = alloca [16 x i8], align 8
  %args10 = alloca [16 x i8], align 8
  %n9 = alloca [1 x i8], align 1
  %msg = alloca [2 x i8], align 1
  %_111 = alloca [16 x i8], align 8
  %_110 = alloca [16 x i8], align 8
  %_109 = alloca [16 x i8], align 8
  %_108 = alloca [16 x i8], align 8
  %_107 = alloca [16 x i8], align 8
  %args8 = alloca [80 x i8], align 8
  %args7 = alloca [40 x i8], align 8
  %e = alloca [4 x i8], align 4
  %d = alloca [4 x i8], align 4
  %c = alloca [16 x i8], align 8
  %b = alloca [2 x i8], align 2
  %a = alloca [1 x i8], align 1
  %_92 = alloca [12 x i8], align 4
  %_91 = alloca [24 x i8], align 8
  %_90 = alloca [40 x i8], align 8
  %t = alloca [40 x i8], align 8
  %_86 = alloca [16 x i8], align 8
  %_85 = alloca [16 x i8], align 8
  %_84 = alloca [16 x i8], align 8
  %args6 = alloca [48 x i8], align 8
  %_81 = alloca [24 x i8], align 8
  %_78 = alloca [24 x i8], align 8
  %_75 = alloca [24 x i8], align 8
  %args5 = alloca [24 x i8], align 8
  %_68 = alloca [16 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_64 = alloca [4 x i8], align 4
  %s = alloca [8 x i8], align 8
  %_55 = alloca [8 x i8], align 8
  %iter3 = alloca [16 x i8], align 8
  %_51 = alloca [16 x i8], align 8
  %_50 = alloca [16 x i8], align 8
  %_49 = alloca [16 x i8], align 8
  %_48 = alloca [16 x i8], align 8
  %_47 = alloca [16 x i8], align 8
  %shapes = alloca [24 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args2 = alloca [16 x i8], align 8
  %_39 = alloca [24 x i8], align 8
  %_31 = alloca [16 x i8], align 8
  %iter1 = alloca [80 x i8], align 8
  %_21 = alloca [64 x i8], align 8
  %_20 = alloca [80 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_13 = alloca [16 x i8], align 8
  %n = alloca [8 x i8], align 8
  %_4 = alloca [16 x i8], align 8
  %iter = alloca [72 x i8], align 8
  %_2 = alloca [56 x i8], align 8
  %_1 = alloca [72 x i8], align 8
  %1 = getelementptr inbounds nuw i64, ptr %_2, i64 0
  store i64 -5, ptr %1, align 8
  %2 = getelementptr inbounds nuw i64, ptr %_2, i64 1
  store i64 0, ptr %2, align 8
  %3 = getelementptr inbounds nuw i64, ptr %_2, i64 2
  store i64 2, ptr %3, align 8
  %4 = getelementptr inbounds nuw i64, ptr %_2, i64 3
  store i64 4, ptr %4, align 8
  %5 = getelementptr inbounds nuw i64, ptr %_2, i64 4
  store i64 7, ptr %5, align 8
  %6 = getelementptr inbounds nuw i64, ptr %_2, i64 5
  store i64 50, ptr %6, align 8
  %7 = getelementptr inbounds nuw i64, ptr %_2, i64 6
  store i64 1000, ptr %7, align 8
; call <[i64; 7] as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAxj7_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_1, ptr align 8 %_2) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter, ptr align 8 %_1, i64 72, i1 false)
  br label %bb2

bb2:                                              ; preds = %bb124, %start
; invoke <core::array::iter::IntoIter<i64, 7> as core::iter::traits::iterator::Iterator>::next
  %8 = invoke { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterxKj7_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %iter)
          to label %bb3 unwind label %cleanup

bb120:                                            ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<i64, 7>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterxKj7_EECsccF2givDBH6_8patterns(ptr align 8 %iter) #16
          to label %bb121 unwind label %terminate

cleanup:                                          ; preds = %bb11, %bb10, %bb9, %bb8, %bb7, %bb5, %bb2
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb120

bb3:                                              ; preds = %bb2
  %13 = extractvalue { i64, i64 } %8, 0
  %14 = extractvalue { i64, i64 } %8, 1
  store i64 %13, ptr %_4, align 8
  %15 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %14, ptr %15, align 8
  %_6 = load i64, ptr %_4, align 8
  %16 = getelementptr inbounds i8, ptr %_4, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = trunc nuw i64 %_6 to i1
  br i1 %18, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %19 = getelementptr inbounds i8, ptr %_4, i64 8
  %20 = load i64, ptr %19, align 8
  store i64 %20, ptr %n, align 8
  %21 = load i64, ptr %n, align 8
; invoke core::hint::black_box::<i64>
  %_14 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECsccF2givDBH6_8patterns(i64 %21)
          to label %bb7 unwind label %cleanup

bb6:                                              ; preds = %bb3
; call core::ptr::drop_glue::<core::array::iter::IntoIter<i64, 7>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterxKj7_EECsccF2givDBH6_8patterns(ptr align 8 %iter)
; call <[i32; 0] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %22 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAlj0_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCsccF2givDBH6_8patterns(ptr align 4 inttoptr (i64 4 to ptr), ptr align 8 @alloc_5f317668025e10a890a3eea4a8bef6ff) #18
  %_22.0 = extractvalue { ptr, i64 } %22, 0
  %_22.1 = extractvalue { ptr, i64 } %22, 1
  %23 = getelementptr inbounds nuw { ptr, i64 }, ptr %_21, i64 0
  store ptr %_22.0, ptr %23, align 8
  %24 = getelementptr inbounds i8, ptr %23, i64 8
  store i64 %_22.1, ptr %24, align 8
  %25 = getelementptr inbounds nuw { ptr, i64 }, ptr %_21, i64 1
  store ptr @alloc_66e0d902dc5512250b9d4edb026cbbeb, ptr %25, align 8
  %26 = getelementptr inbounds i8, ptr %25, i64 8
  store i64 1, ptr %26, align 8
  %27 = getelementptr inbounds nuw { ptr, i64 }, ptr %_21, i64 2
  store ptr @alloc_5598ad317332f65891d44d57bbdb4a57, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 3, ptr %28, align 8
  %29 = getelementptr inbounds nuw { ptr, i64 }, ptr %_21, i64 3
  store ptr @alloc_03fa889ebefc3fd61240d008cccbcd8d, ptr %29, align 8
  %30 = getelementptr inbounds i8, ptr %29, i64 8
  store i64 3, ptr %30, align 8
; call <[&[i32]; 4] as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARSlj4_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_20, ptr align 8 %_21) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter1, ptr align 8 %_20, i64 80, i1 false)
  br label %bb15

bb15:                                             ; preds = %bb23, %bb6
; invoke <core::array::iter::IntoIter<&[i32], 4> as core::iter::traits::iterator::Iterator>::next
  %31 = invoke { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterRSlKj4_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %iter1)
          to label %bb16 unwind label %cleanup18

bb119:                                            ; preds = %bb118, %cleanup18
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<&[i32], 4>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterRSlKj4_EECsccF2givDBH6_8patterns(ptr align 8 %iter1) #16
          to label %bb121 unwind label %terminate

cleanup18:                                        ; preds = %bb23, %bb19, %bb17, %bb15
  %32 = landingpad { ptr, i32 }
          cleanup
  %33 = extractvalue { ptr, i32 } %32, 0
  %34 = extractvalue { ptr, i32 } %32, 1
  store ptr %33, ptr %0, align 8
  %35 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %34, ptr %35, align 8
  br label %bb119

bb16:                                             ; preds = %bb15
  %36 = extractvalue { ptr, i64 } %31, 0
  %37 = extractvalue { ptr, i64 } %31, 1
  store ptr %36, ptr %_31, align 8
  %38 = getelementptr inbounds i8, ptr %_31, i64 8
  store i64 %37, ptr %38, align 8
  %39 = load ptr, ptr %_31, align 8
  %40 = getelementptr inbounds i8, ptr %_31, i64 8
  %41 = load i64, ptr %40, align 8
  %42 = ptrtoint ptr %39 to i64
  %43 = icmp eq i64 %42, 0
  %_33 = select i1 %43, i64 0, i64 1
  %44 = trunc nuw i64 %_33 to i1
  br i1 %44, label %bb17, label %bb18

bb17:                                             ; preds = %bb16
  %v.0 = load ptr, ptr %_31, align 8
  %45 = getelementptr inbounds i8, ptr %_31, i64 8
  %v.1 = load i64, ptr %45, align 8
; invoke core::hint::black_box::<&[i32]>
  %46 = invoke { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxRSlECsccF2givDBH6_8patterns(ptr align 4 %v.0, i64 %v.1)
          to label %bb19 unwind label %cleanup18

bb18:                                             ; preds = %bb16
; call core::ptr::drop_glue::<core::array::iter::IntoIter<&[i32], 4>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterRSlKj4_EECsccF2givDBH6_8patterns(ptr align 8 %iter1)
; call alloc::boxed::box_new_uninit
  %_1.i = call align 8 ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsccF2givDBH6_8patterns(i64 8, i64 80) #18
  %47 = getelementptr inbounds i8, ptr %_47, i64 8
  store double 2.000000e+00, ptr %47, align 8
  store i8 0, ptr %_47, align 8
  %48 = getelementptr inbounds i8, ptr %_48, i64 4
  store i32 3, ptr %48, align 4
  %49 = getelementptr inbounds i8, ptr %_48, i64 8
  store i32 4, ptr %49, align 8
  store i8 1, ptr %_48, align 8
  %50 = getelementptr inbounds i8, ptr %_49, i64 1
  store i8 2, ptr %50, align 1
  %51 = getelementptr inbounds i8, ptr %_49, i64 2
  store i8 2, ptr %51, align 2
  %52 = getelementptr inbounds i8, ptr %_49, i64 3
  store i8 2, ptr %52, align 1
  store i8 2, ptr %_49, align 8
  %53 = getelementptr inbounds i8, ptr %_50, i64 1
  store i8 5, ptr %53, align 1
  %54 = getelementptr inbounds i8, ptr %_50, i64 2
  store i8 6, ptr %54, align 2
  %55 = getelementptr inbounds i8, ptr %_50, i64 3
  store i8 7, ptr %55, align 1
  store i8 2, ptr %_50, align 8
  store i8 3, ptr %_51, align 8
  %_230 = ptrtoint ptr %_1.i to i64
  %_232 = and i64 %_230, 7
  %_233 = icmp eq i64 %_232, 0
  br i1 %_233, label %bb122, label %panic

bb122:                                            ; preds = %bb18
  %_235 = ptrtoint ptr %_1.i to i64
  %_237 = icmp eq i64 %_235, 0
  %_238 = and i1 %_237, true
  %_239 = xor i1 %_238, true
  br i1 %_239, label %bb123, label %panic19

panic:                                            ; preds = %bb18
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_230, ptr align 8 @alloc_df7fb09215c742e668e6254030a2bddf) #20
  unreachable

bb123:                                            ; preds = %bb122
  %56 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_47, i64 16, i1 false)
  %57 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_48, i64 16, i1 false)
  %58 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %58, ptr align 8 %_49, i64 16, i1 false)
  %59 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %59, ptr align 8 %_50, i64 16, i1 false)
  %60 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %60, ptr align 8 %_51, i64 16, i1 false)
; call <[patterns::Shape]>::into_vec::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCsccF2givDBH6_8patterns5Shape8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %shapes, ptr align 8 %_1.i, i64 5) #18
; invoke <&alloc::vec::Vec<patterns::Shape> as core::iter::traits::collect::IntoIterator>::into_iter
  %61 = invoke { ptr, ptr } @_RNvXsh_NtCs7CppTae75M1_5alloc3vecRINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12IntoIterator9into_iterBI_(ptr align 8 %shapes)
          to label %bb27 unwind label %cleanup20

panic19:                                          ; preds = %bb122
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_df7fb09215c742e668e6254030a2bddf) #20
  unreachable

bb117:                                            ; preds = %bb116, %cleanup20
; invoke core::ptr::drop_glue::<alloc::vec::Vec<patterns::Shape>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsccF2givDBH6_8patterns5ShapeEEB1a_(ptr align 8 %shapes) #16
          to label %bb121 unwind label %terminate

cleanup20:                                        ; preds = %bb36, %bb35, %bb34, %bb33, %bb32, %bb30, %bb113, %bb94, %bb93, %bb92, %bb91, %bb90, %bb82, %bb78, %bb73, %bb81, %bb80, %bb75, %bb71, %bb79, %bb77, %bb72, %bb69, %bb66, %bb65, %bb64, %bb67, %bb63, %bb68, %bb62, %bb59, %bb58, %bb57, %bb55, %bb52, %bb51, %bb50, %bb49, %bb48, %bb47, %bb46, %bb45, %bb44, %bb43, %bb42, %bb41, %bb40, %bb39, %bb38, %bb37, %bb31, %bb28, %bb123
  %62 = landingpad { ptr, i32 }
          cleanup
  %63 = extractvalue { ptr, i32 } %62, 0
  %64 = extractvalue { ptr, i32 } %62, 1
  store ptr %63, ptr %0, align 8
  %65 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %64, ptr %65, align 8
  br label %bb117

bb27:                                             ; preds = %bb123
  %_52.0 = extractvalue { ptr, ptr } %61, 0
  %_52.1 = extractvalue { ptr, ptr } %61, 1
  store ptr %_52.0, ptr %iter3, align 8
  %66 = getelementptr inbounds i8, ptr %iter3, i64 8
  store ptr %_52.1, ptr %66, align 8
  br label %bb28

bb28:                                             ; preds = %bb125, %bb27
; invoke <core::slice::iter::Iter<patterns::Shape> as core::iter::traits::iterator::Iterator>::next
  %67 = invoke align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterNtCsccF2givDBH6_8patterns5ShapeENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBR_(ptr align 8 %iter3)
          to label %bb29 unwind label %cleanup20

bb29:                                             ; preds = %bb28
  store ptr %67, ptr %_55, align 8
  %68 = load ptr, ptr %_55, align 8
  %69 = ptrtoint ptr %68 to i64
  %70 = icmp eq i64 %69, 0
  %_57 = select i1 %70, i64 0, i64 1
  %71 = trunc nuw i64 %_57 to i1
  br i1 %71, label %bb30, label %bb31

bb30:                                             ; preds = %bb29
  %72 = load ptr, ptr %_55, align 8
  store ptr %72, ptr %s, align 8, !captures !130
  %73 = load ptr, ptr %s, align 8
; invoke core::hint::black_box::<&patterns::Shape>
  %_65 = invoke align 8 ptr @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxRNtCsccF2givDBH6_8patterns5ShapeEBF_(ptr align 8 %73)
          to label %bb32 unwind label %cleanup20

bb31:                                             ; preds = %bb29
; invoke patterns::parse_kv
  invoke void @_RNvCsccF2givDBH6_8patterns8parse_kv(ptr sret([24 x i8]) align 8 %_75, ptr @alloc_b1e693e8528fb8140f163b7e7dd5f4c0, i64 5)
          to label %bb37 unwind label %cleanup20

bb37:                                             ; preds = %bb31
; invoke patterns::parse_kv
  invoke void @_RNvCsccF2givDBH6_8patterns8parse_kv(ptr sret([24 x i8]) align 8 %_78, ptr @alloc_89c92c491e006e6ef9402d0dec0fc54d, i64 3)
          to label %bb38 unwind label %cleanup20

bb38:                                             ; preds = %bb37
; invoke patterns::parse_kv
  invoke void @_RNvCsccF2givDBH6_8patterns8parse_kv(ptr sret([24 x i8]) align 8 %_81, ptr @alloc_18f2f0d3d4f38df552db2352111ec81f, i64 1)
          to label %bb39 unwind label %cleanup20

bb39:                                             ; preds = %bb38
  store ptr %_75, ptr %args5, align 8
  %74 = getelementptr inbounds i8, ptr %args5, i64 8
  store ptr %_78, ptr %74, align 8
  %75 = getelementptr inbounds i8, ptr %args5, i64 16
  store ptr %_81, ptr %75, align 8
  %_214 = load ptr, ptr %args5, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<(&str, i32)>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionTRelEEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_84, ptr align 8 %_214)
          to label %bb40 unwind label %cleanup20

bb40:                                             ; preds = %bb39
  %76 = getelementptr inbounds i8, ptr %args5, i64 8
  %_215 = load ptr, ptr %76, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<(&str, i32)>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionTRelEEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_85, ptr align 8 %_215)
          to label %bb41 unwind label %cleanup20

bb41:                                             ; preds = %bb40
  %77 = getelementptr inbounds i8, ptr %args5, i64 16
  %_216 = load ptr, ptr %77, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<(&str, i32)>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionTRelEEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_86, ptr align 8 %_216)
          to label %bb42 unwind label %cleanup20

bb42:                                             ; preds = %bb41
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_84, i64 16, i1 false)
  %79 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %79, ptr align 8 %_85, i64 16, i1 false)
  %80 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %80, ptr align 8 %_86, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 3>
  %81 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsccF2givDBH6_8patterns(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args6)
          to label %bb43 unwind label %cleanup20

bb43:                                             ; preds = %bb42
  %_72.0 = extractvalue { ptr, ptr } %81, 0
  %_72.1 = extractvalue { ptr, ptr } %81, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_72.0, ptr %_72.1)
          to label %bb44 unwind label %cleanup20

bb44:                                             ; preds = %bb43
  store i16 2, ptr %_91, align 8
  %82 = getelementptr inbounds i8, ptr %_91, i64 8
  store ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, ptr %82, align 8
  %83 = getelementptr inbounds i8, ptr %82, i64 8
  store i64 1, ptr %83, align 8
  %84 = getelementptr inbounds nuw i32, ptr %_92, i64 0
  store i32 3, ptr %84, align 4
  %85 = getelementptr inbounds nuw i32, ptr %_92, i64 1
  store i32 4, ptr %85, align 4
  %86 = getelementptr inbounds nuw i32, ptr %_92, i64 2
  store i32 5, ptr %86, align 4
  %87 = getelementptr inbounds i8, ptr %_90, i64 24
  store i8 1, ptr %87, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_90, ptr align 8 %_91, i64 24, i1 false)
  %88 = getelementptr inbounds i8, ptr %_90, i64 28
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %88, ptr align 4 %_92, i64 12, i1 false)
; invoke core::hint::black_box::<(u8, (i16, &str), [i32; 3])>
  invoke void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxThTsReEAlj3_EECsccF2givDBH6_8patterns(ptr sret([40 x i8]) align 8 %t, ptr align 8 %_90)
          to label %bb45 unwind label %cleanup20

bb45:                                             ; preds = %bb44
  %89 = getelementptr inbounds i8, ptr %t, i64 24
  %90 = load i8, ptr %89, align 8
  store i8 %90, ptr %a, align 1
  %91 = load i16, ptr %t, align 8
  store i16 %91, ptr %b, align 2
  %92 = getelementptr inbounds i8, ptr %t, i64 8
  %93 = load ptr, ptr %92, align 8
  %94 = getelementptr inbounds i8, ptr %92, i64 8
  %95 = load i64, ptr %94, align 8
  store ptr %93, ptr %c, align 8, !captures !130
  %96 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %95, ptr %96, align 8
  %97 = getelementptr inbounds i8, ptr %t, i64 28
  %98 = getelementptr inbounds nuw i32, ptr %97, i64 0
  %99 = load i32, ptr %98, align 4
  store i32 %99, ptr %d, align 4
  %100 = getelementptr inbounds i8, ptr %t, i64 28
  %101 = getelementptr inbounds nuw i32, ptr %100, i64 2
  %102 = load i32, ptr %101, align 4
  store i32 %102, ptr %e, align 4
  store ptr %a, ptr %args7, align 8
  %103 = getelementptr inbounds i8, ptr %args7, i64 8
  store ptr %b, ptr %103, align 8
  %104 = getelementptr inbounds i8, ptr %args7, i64 16
  store ptr %c, ptr %104, align 8
  %105 = getelementptr inbounds i8, ptr %args7, i64 24
  store ptr %d, ptr %105, align 8
  %106 = getelementptr inbounds i8, ptr %args7, i64 32
  store ptr %e, ptr %106, align 8
  %_217 = load ptr, ptr %args7, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_107, ptr %_217)
          to label %bb46 unwind label %cleanup20

bb46:                                             ; preds = %bb45
  %107 = getelementptr inbounds i8, ptr %args7, i64 8
  %_218 = load ptr, ptr %107, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i16>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_108, ptr align 2 %_218)
          to label %bb47 unwind label %cleanup20

bb47:                                             ; preds = %bb46
  %108 = getelementptr inbounds i8, ptr %args7, i64 16
  %_219 = load ptr, ptr %108, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_109, ptr align 8 %_219)
          to label %bb48 unwind label %cleanup20

bb48:                                             ; preds = %bb47
  %109 = getelementptr inbounds i8, ptr %args7, i64 24
  %_220 = load ptr, ptr %109, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_110, ptr align 4 %_220)
          to label %bb49 unwind label %cleanup20

bb49:                                             ; preds = %bb48
  %110 = getelementptr inbounds i8, ptr %args7, i64 32
  %_221 = load ptr, ptr %110, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_111, ptr align 4 %_221)
          to label %bb50 unwind label %cleanup20

bb50:                                             ; preds = %bb49
  %111 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %111, ptr align 8 %_107, i64 16, i1 false)
  %112 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %112, ptr align 8 %_108, i64 16, i1 false)
  %113 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %113, ptr align 8 %_109, i64 16, i1 false)
  %114 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %114, ptr align 8 %_110, i64 16, i1 false)
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_111, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<16, 5>
  %116 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECsccF2givDBH6_8patterns(ptr @alloc_6a96e47ef75dbf6fc4eb5423ba7bb768, ptr align 8 %args8)
          to label %bb51 unwind label %cleanup20

bb51:                                             ; preds = %bb50
  %_99.0 = extractvalue { ptr, ptr } %116, 0
  %_99.1 = extractvalue { ptr, ptr } %116, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_99.0, ptr %_99.1)
          to label %bb52 unwind label %cleanup20

bb52:                                             ; preds = %bb51
; invoke core::hint::black_box::<core::option::Option<u8>>
  %117 = invoke { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECsccF2givDBH6_8patterns(i1 zeroext true, i8 42)
          to label %bb53 unwind label %cleanup20

bb53:                                             ; preds = %bb52
  %118 = extractvalue { i1, i8 } %117, 0
  %119 = extractvalue { i1, i8 } %117, 1
  %120 = zext i1 %118 to i8
  store i8 %120, ptr %msg, align 1
  %121 = getelementptr inbounds i8, ptr %msg, i64 1
  store i8 %119, ptr %121, align 1
  %122 = load i8, ptr %msg, align 1
  %123 = trunc nuw i8 %122 to i1
  %124 = getelementptr inbounds i8, ptr %msg, i64 1
  %125 = load i8, ptr %124, align 1
  %_118 = zext i1 %123 to i64
  %126 = trunc nuw i64 %_118 to i1
  br i1 %126, label %bb54, label %bb59

bb54:                                             ; preds = %bb53
  %127 = getelementptr inbounds i8, ptr %msg, i64 1
  %128 = load i8, ptr %127, align 1
  %_116 = icmp ule i8 40, %128
  br i1 %_116, label %bb56, label %bb59

bb59:                                             ; preds = %bb126, %bb56, %bb54, %bb53
; invoke core::hint::black_box::<core::option::Option<core::option::Option<u8>>>
  %129 = invoke { i8, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionIBD_hEEECsccF2givDBH6_8patterns(i8 0, i8 undef)
          to label %bb60 unwind label %cleanup20

bb56:                                             ; preds = %bb54
  %130 = getelementptr inbounds i8, ptr %msg, i64 1
  %131 = load i8, ptr %130, align 1
  %_117 = icmp ule i8 %131, 50
  br i1 %_117, label %bb55, label %bb59

bb55:                                             ; preds = %bb56
  %132 = getelementptr inbounds i8, ptr %msg, i64 1
  %133 = load i8, ptr %132, align 1
  store i8 %133, ptr %n9, align 1
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_125, ptr %n9)
          to label %bb57 unwind label %cleanup20

bb57:                                             ; preds = %bb55
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_125, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<14, 1>
  %135 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_144b8bda8b7d019167909d944f76599d, ptr align 8 %args10)
          to label %bb58 unwind label %cleanup20

bb58:                                             ; preds = %bb57
  %_121.0 = extractvalue { ptr, ptr } %135, 0
  %_121.1 = extractvalue { ptr, ptr } %135, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_121.0, ptr %_121.1)
          to label %bb126 unwind label %cleanup20

bb126:                                            ; preds = %bb58
  br label %bb59

bb60:                                             ; preds = %bb59
  %136 = extractvalue { i8, i8 } %129, 0
  %137 = extractvalue { i8, i8 } %129, 1
  store i8 %136, ptr %opt, align 1
  %138 = getelementptr inbounds i8, ptr %opt, i64 1
  store i8 %137, ptr %138, align 1
  %139 = load i8, ptr %opt, align 1
  %140 = getelementptr inbounds i8, ptr %opt, i64 1
  %141 = load i8, ptr %140, align 1
  %142 = icmp eq i8 %139, 2
  %_132 = select i1 %142, i64 0, i64 1
  %143 = trunc nuw i64 %_132 to i1
  br i1 %143, label %bb61, label %bb62

bb61:                                             ; preds = %bb60
  %144 = load i8, ptr %opt, align 1
  %145 = trunc nuw i8 %144 to i1
  %146 = getelementptr inbounds i8, ptr %opt, i64 1
  %147 = load i8, ptr %146, align 1
  %_131 = zext i1 %145 to i64
  %148 = trunc nuw i64 %_131 to i1
  br i1 %148, label %bb64, label %bb63

bb62:                                             ; preds = %bb60
; invoke <core::fmt::Arguments>::from_str
  %149 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_b8a9faf0f44a085c631f2755716883c9, i64 5)
          to label %bb68 unwind label %cleanup20

bb68:                                             ; preds = %bb62
  %_145.0 = extractvalue { ptr, ptr } %149, 0
  %_145.1 = extractvalue { ptr, ptr } %149, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_145.0, ptr %_145.1)
          to label %bb129 unwind label %cleanup20

bb129:                                            ; preds = %bb68
  br label %bb69

bb69:                                             ; preds = %bb127, %bb128, %bb129
  store ptr @alloc_c1fa64f4e819a506b7859bc956f830ca, ptr %_147, align 8
  %150 = getelementptr inbounds i8, ptr %_147, i64 8
  store i64 1, ptr %150, align 8
; invoke core::hint::black_box::<core::result::Result<u8, &str>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6result6ResulthReEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %r, ptr align 8 %_147)
          to label %bb70 unwind label %cleanup20

bb64:                                             ; preds = %bb61
  %151 = getelementptr inbounds i8, ptr %opt, i64 1
  %152 = load i8, ptr %151, align 1
  store i8 %152, ptr %x, align 1
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_139, ptr %x)
          to label %bb65 unwind label %cleanup20

bb63:                                             ; preds = %bb61
; invoke <core::fmt::Arguments>::from_str
  %153 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_0e8a8a0ff4ea56ec3d4541bf7e74cfec, i64 11)
          to label %bb67 unwind label %cleanup20

bb67:                                             ; preds = %bb63
  %_143.0 = extractvalue { ptr, ptr } %153, 0
  %_143.1 = extractvalue { ptr, ptr } %153, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_143.0, ptr %_143.1)
          to label %bb128 unwind label %cleanup20

bb128:                                            ; preds = %bb67
  br label %bb69

bb65:                                             ; preds = %bb64
  %154 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %154, ptr align 8 %_139, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %155 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args11)
          to label %bb66 unwind label %cleanup20

bb66:                                             ; preds = %bb65
  %_135.0 = extractvalue { ptr, ptr } %155, 0
  %_135.1 = extractvalue { ptr, ptr } %155, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_135.0, ptr %_135.1)
          to label %bb127 unwind label %cleanup20

bb127:                                            ; preds = %bb66
  br label %bb69

bb70:                                             ; preds = %bb69
  %156 = load ptr, ptr %r, align 8
  %157 = ptrtoint ptr %156 to i64
  %158 = icmp eq i64 %157, 0
  %_149 = select i1 %158, i64 0, i64 1
  %159 = trunc nuw i64 %_149 to i1
  br i1 %159, label %bb71, label %bb72

bb71:                                             ; preds = %bb70
; invoke core::hint::black_box::<bool>
  %_150 = invoke zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECsccF2givDBH6_8patterns(i1 zeroext false)
          to label %bb74 unwind label %cleanup20

bb72:                                             ; preds = %bb70
; invoke core::hint::black_box::<bool>
  %_151 = invoke zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECsccF2givDBH6_8patterns(i1 zeroext false)
          to label %bb76 unwind label %cleanup20

bb76:                                             ; preds = %bb72
  br i1 %_151, label %bb73, label %bb77

bb77:                                             ; preds = %bb76
; invoke <core::fmt::Arguments>::from_str
  %160 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_31a9e8f7a570396788f7b2482a3a97e4, i64 3)
          to label %bb79 unwind label %cleanup20

bb73:                                             ; preds = %bb74, %bb76
; invoke <core::fmt::Arguments>::from_str
  %161 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_3dbdd06bebcf2fb86aed3e2f16680d42, i64 8)
          to label %bb78 unwind label %cleanup20

bb79:                                             ; preds = %bb77
  %_155.0 = extractvalue { ptr, ptr } %160, 0
  %_155.1 = extractvalue { ptr, ptr } %160, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_155.0, ptr %_155.1)
          to label %bb131 unwind label %cleanup20

bb131:                                            ; preds = %bb79
  br label %bb82

bb82:                                             ; preds = %bb130, %bb132, %bb131
; invoke core::hint::black_box::<char>
  %ch = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxcECsccF2givDBH6_8patterns(i32 107)
          to label %bb83 unwind label %cleanup20

bb74:                                             ; preds = %bb71
  br i1 %_150, label %bb73, label %bb75

bb75:                                             ; preds = %bb74
  %162 = load ptr, ptr %r, align 8
  %163 = getelementptr inbounds i8, ptr %r, i64 8
  %164 = load i64, ptr %163, align 8
  store ptr %162, ptr %e12, align 8, !captures !130
  %165 = getelementptr inbounds i8, ptr %e12, i64 8
  store i64 %164, ptr %165, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_162, ptr align 8 %e12)
          to label %bb80 unwind label %cleanup20

bb80:                                             ; preds = %bb75
  %166 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %166, ptr align 8 %_162, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<9, 1>
  %167 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj9_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_c0c0bd6959bacd2127c8d4fc3870a66f, ptr align 8 %args13)
          to label %bb81 unwind label %cleanup20

bb81:                                             ; preds = %bb80
  %_158.0 = extractvalue { ptr, ptr } %167, 0
  %_158.1 = extractvalue { ptr, ptr } %167, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_158.0, ptr %_158.1)
          to label %bb132 unwind label %cleanup20

bb132:                                            ; preds = %bb81
  br label %bb82

bb78:                                             ; preds = %bb73
  %_153.0 = extractvalue { ptr, ptr } %161, 0
  %_153.1 = extractvalue { ptr, ptr } %161, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
          to label %bb130 unwind label %cleanup20

bb130:                                            ; preds = %bb78
  br label %bb82

bb83:                                             ; preds = %bb82
  %_173 = icmp ule i32 97, %ch
  br i1 %_173, label %bb89, label %bb86

bb86:                                             ; preds = %bb89, %bb83
  %_171 = icmp ule i32 107, %ch
  br i1 %_171, label %bb88, label %bb84

bb89:                                             ; preds = %bb83
  %_174 = icmp ule i32 %ch, 106
  br i1 %_174, label %bb85, label %bb86

bb85:                                             ; preds = %bb89
  store i32 1, ptr %_170, align 4
  br label %bb90

bb84:                                             ; preds = %bb88, %bb86
  store i32 3, ptr %_170, align 4
  br label %bb90

bb88:                                             ; preds = %bb86
  %_172 = icmp ule i32 %ch, 122
  br i1 %_172, label %bb87, label %bb84

bb87:                                             ; preds = %bb88
  store i32 2, ptr %_170, align 4
  br label %bb90

bb90:                                             ; preds = %bb85, %bb87, %bb84
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_176, ptr align 4 %_170)
          to label %bb91 unwind label %cleanup20

bb91:                                             ; preds = %bb90
  %168 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %168, ptr align 8 %_176, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %169 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args14)
          to label %bb92 unwind label %cleanup20

bb92:                                             ; preds = %bb91
  %_167.0 = extractvalue { ptr, ptr } %169, 0
  %_167.1 = extractvalue { ptr, ptr } %169, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
          to label %bb93 unwind label %cleanup20

bb93:                                             ; preds = %bb92
; invoke <alloc::string::String as core::convert::From<&str>>::from
  invoke void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_182, ptr @alloc_acd822e6332f053907a9b112a94122d3, i64 5)
          to label %bb94 unwind label %cleanup20

bb94:                                             ; preds = %bb93
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_181, ptr align 8 %_182, i64 24, i1 false)
; invoke core::hint::black_box::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_180, ptr align 8 %_181)
          to label %bb95 unwind label %cleanup20

bb95:                                             ; preds = %bb94
  %170 = load i64, ptr %_180, align 8
  %171 = icmp eq i64 %170, -1
  %_183 = select i1 %171, i64 0, i64 1
  %172 = trunc nuw i64 %_183 to i1
  br i1 %172, label %bb96, label %bb100

bb96:                                             ; preds = %bb95
; invoke <alloc::string::String>::len
  %173 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsccF2givDBH6_8patterns(ptr align 8 %_180)
          to label %bb97 unwind label %cleanup21

bb100:                                            ; preds = %bb133, %bb95
; invoke core::hint::black_box::<u32>
  %174 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsccF2givDBH6_8patterns(i32 5)
          to label %bb101 unwind label %cleanup21

bb116:                                            ; preds = %cleanup21
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %_180) #16
          to label %bb117 unwind label %terminate

cleanup21:                                        ; preds = %bb112, %bb111, %bb110, %bb100, %bb99, %bb98, %bb97, %bb96
  %175 = landingpad { ptr, i32 }
          cleanup
  %176 = extractvalue { ptr, i32 } %175, 0
  %177 = extractvalue { ptr, i32 } %175, 1
  store ptr %176, ptr %0, align 8
  %178 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %177, ptr %178, align 8
  br label %bb116

bb97:                                             ; preds = %bb96
  store i64 %173, ptr %_189, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_191, ptr align 8 %_189)
          to label %bb98 unwind label %cleanup21

bb98:                                             ; preds = %bb97
  %179 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %179, ptr align 8 %_191, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %180 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args15)
          to label %bb99 unwind label %cleanup21

bb99:                                             ; preds = %bb98
  %_186.0 = extractvalue { ptr, ptr } %180, 0
  %_186.1 = extractvalue { ptr, ptr } %180, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_186.0, ptr %_186.1)
          to label %bb133 unwind label %cleanup21

bb133:                                            ; preds = %bb99
  br label %bb100

bb101:                                            ; preds = %bb100
  store i32 %174, ptr %x16, align 4
  %181 = load i32, ptr %x16, align 4
  %182 = icmp eq i32 %181, 0
  br i1 %182, label %bb106, label %bb105

bb106:                                            ; preds = %bb101
  store ptr @alloc_50ab75e5eb17b3d68555764b0a52038b, ptr %y, align 8, !captures !130
  %183 = getelementptr inbounds i8, ptr %y, i64 8
  store i64 1, ptr %183, align 8
  br label %bb110

bb105:                                            ; preds = %bb101
  %_200 = load i32, ptr %x16, align 4
  %_0.i.i = call i32 @llvm.ctpop.i32(i32 %_200)
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb107

bb110:                                            ; preds = %bb108, %bb103, %bb102, %bb106
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_206, ptr align 8 %y)
          to label %bb111 unwind label %cleanup21

bb107:                                            ; preds = %bb105
  br i1 %_0.i, label %bb108, label %bb109

bb109:                                            ; preds = %bb107
  %184 = load i32, ptr %x16, align 4
  %_196 = icmp ule i32 1, %184
  br i1 %_196, label %bb104, label %bb102

bb108:                                            ; preds = %bb107
  store ptr @alloc_f424f6e87101d147a136ec9aa11fa034, ptr %y, align 8, !captures !130
  %185 = getelementptr inbounds i8, ptr %y, i64 8
  store i64 4, ptr %185, align 8
  br label %bb110

bb102:                                            ; preds = %bb104, %bb109
  store ptr @alloc_69ea765c2672a934a5b64287f175d158, ptr %y, align 8, !captures !130
  %186 = getelementptr inbounds i8, ptr %y, i64 8
  store i64 4, ptr %186, align 8
  br label %bb110

bb104:                                            ; preds = %bb109
  %187 = load i32, ptr %x16, align 4
  %_197 = icmp ule i32 %187, 9
  br i1 %_197, label %bb103, label %bb102

bb103:                                            ; preds = %bb104
  store ptr @alloc_78d5c01af63be55c3511bacffb1a7824, ptr %y, align 8, !captures !130
  %188 = getelementptr inbounds i8, ptr %y, i64 8
  store i64 5, ptr %188, align 8
  br label %bb110

bb111:                                            ; preds = %bb110
  %189 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %189, ptr align 8 %_206, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %190 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args17)
          to label %bb112 unwind label %cleanup21

bb112:                                            ; preds = %bb111
  %_202.0 = extractvalue { ptr, ptr } %190, 0
  %_202.1 = extractvalue { ptr, ptr } %190, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_202.0, ptr %_202.1)
          to label %bb113 unwind label %cleanup21

bb113:                                            ; preds = %bb112
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %_180)
          to label %bb114 unwind label %cleanup20

bb114:                                            ; preds = %bb113
; call core::ptr::drop_glue::<alloc::vec::Vec<patterns::Shape>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsccF2givDBH6_8patterns5ShapeEEB1a_(ptr align 8 %shapes)
  ret void

terminate:                                        ; preds = %bb120, %bb119, %bb118, %bb117, %bb116
  %191 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb32:                                             ; preds = %bb30
; invoke patterns::area
  %192 = invoke i32 @_RNvCsccF2givDBH6_8patterns4area(ptr align 8 %_65)
          to label %bb33 unwind label %cleanup20

bb33:                                             ; preds = %bb32
  store i32 %192, ptr %_64, align 4
; invoke <core::fmt::rt::Argument>::new_debug::<&patterns::Shape>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRNtCsccF2givDBH6_8patterns5ShapeEBY_(ptr sret([16 x i8]) align 8 %_67, ptr align 8 %s)
          to label %bb34 unwind label %cleanup20

bb34:                                             ; preds = %bb33
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_68, ptr align 4 %_64)
          to label %bb35 unwind label %cleanup20

bb35:                                             ; preds = %bb34
  %193 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %193, ptr align 8 %_67, i64 16, i1 false)
  %194 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %194, ptr align 8 %_68, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %195 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4)
          to label %bb36 unwind label %cleanup20

bb36:                                             ; preds = %bb35
  %_60.0 = extractvalue { ptr, ptr } %195, 0
  %_60.1 = extractvalue { ptr, ptr } %195, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_60.0, ptr %_60.1)
          to label %bb125 unwind label %cleanup20

bb125:                                            ; preds = %bb36
  br label %bb28

bb121:                                            ; preds = %bb120, %bb119, %bb117
  %196 = load ptr, ptr %0, align 8
  %197 = getelementptr inbounds i8, ptr %0, i64 8
  %198 = load i32, ptr %197, align 8
  %199 = insertvalue { ptr, i32 } poison, ptr %196, 0
  %200 = insertvalue { ptr, i32 } %199, i32 %198, 1
  resume { ptr, i32 } %200

bb19:                                             ; preds = %bb17
  %_40.0 = extractvalue { ptr, i64 } %46, 0
  %_40.1 = extractvalue { ptr, i64 } %46, 1
; invoke patterns::slice_pat
  invoke void @_RNvCsccF2givDBH6_8patterns9slice_pat(ptr sret([24 x i8]) align 8 %_39, ptr align 4 %_40.0, i64 %_40.1)
          to label %bb20 unwind label %cleanup18

bb20:                                             ; preds = %bb19
; invoke <core::fmt::rt::Argument>::new_display::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_42, ptr align 8 %_39)
          to label %bb21 unwind label %cleanup22

bb118:                                            ; preds = %cleanup22
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_39) #16
          to label %bb119 unwind label %terminate

cleanup22:                                        ; preds = %bb22, %bb21, %bb20
  %201 = landingpad { ptr, i32 }
          cleanup
  %202 = extractvalue { ptr, i32 } %201, 0
  %203 = extractvalue { ptr, i32 } %201, 1
  store ptr %202, ptr %0, align 8
  %204 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %203, ptr %204, align 8
  br label %bb118

bb21:                                             ; preds = %bb20
  %205 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %205, ptr align 8 %_42, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %206 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args2)
          to label %bb22 unwind label %cleanup22

bb22:                                             ; preds = %bb21
  %_36.0 = extractvalue { ptr, ptr } %206, 0
  %_36.1 = extractvalue { ptr, ptr } %206, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_36.0, ptr %_36.1)
          to label %bb23 unwind label %cleanup22

bb23:                                             ; preds = %bb22
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_39)
          to label %bb15 unwind label %cleanup18

bb7:                                              ; preds = %bb5
; invoke patterns::classify
  %207 = invoke { ptr, i64 } @_RNvCsccF2givDBH6_8patterns8classify(i64 %_14)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %208 = extractvalue { ptr, i64 } %207, 0
  %209 = extractvalue { ptr, i64 } %207, 1
  store ptr %208, ptr %_13, align 8
  %210 = getelementptr inbounds i8, ptr %_13, i64 8
  store i64 %209, ptr %210, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_16, ptr align 8 %n)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_17, ptr align 8 %_13)
          to label %bb10 unwind label %cleanup

bb10:                                             ; preds = %bb9
  %211 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %211, ptr align 8 %_16, i64 16, i1 false)
  %212 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %212, ptr align 8 %_17, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %213 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
  %_9.0 = extractvalue { ptr, ptr } %213, 0
  %_9.1 = extractvalue { ptr, ptr } %213, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
          to label %bb124 unwind label %cleanup

bb124:                                            ; preds = %bb11
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable
}

; patterns::classify
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvCsccF2givDBH6_8patterns8classify(i64 %0) unnamed_addr #1 !guid !167 {
start:
  %_0 = alloca [16 x i8], align 8
  %n = alloca [8 x i8], align 8
  store i64 %0, ptr %n, align 8
  %1 = load i64, ptr %n, align 8
  %_2 = icmp sle i64 -9223372036854775808, %1
  br i1 %_2, label %bb4, label %bb3

bb3:                                              ; preds = %bb4, %start
  %2 = load i64, ptr %n, align 8
  switch i64 %2, label %bb1 [
    i64 0, label %bb9
    i64 1, label %bb8
    i64 2, label %bb8
    i64 3, label %bb8
  ]

bb4:                                              ; preds = %start
  %3 = load i64, ptr %n, align 8
  %_3 = icmp sle i64 %3, -1
  br i1 %_3, label %bb2, label %bb3

bb2:                                              ; preds = %bb4
  store ptr @alloc_7aa1a11e7908cb59b04764917ce720b4, ptr %_0, align 8, !captures !130
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 3, ptr %4, align 8
  br label %bb14

bb1:                                              ; preds = %bb3
  %_9 = load i64, ptr %n, align 8
  %_12 = icmp eq i64 %_9, -9223372036854775808
  %_13 = and i1 false, %_12
  br i1 %_13, label %panic, label %bb11

bb9:                                              ; preds = %bb3
  store ptr @alloc_427cf7da6bbe57bf2fdbddfa3078c1f8, ptr %_0, align 8, !captures !130
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 4, ptr %5, align 8
  br label %bb14

bb8:                                              ; preds = %bb3, %bb3, %bb3
  store ptr @alloc_87862e78b478b6bd0b4ea1c7b6258769, ptr %_0, align 8, !captures !130
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 5, ptr %6, align 8
  br label %bb14

bb14:                                             ; preds = %bb2, %bb12, %bb6, %bb5, %bb8, %bb9
  %7 = load ptr, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  ret { ptr, i64 } %11

bb11:                                             ; preds = %bb1
  %_8 = srem i64 %_9, 2
  %_7 = icmp eq i64 %_8, 0
  br i1 %_7, label %bb12, label %bb13

panic:                                            ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_735ff844006bb5c32021c0456ffecbea) #21
  unreachable

bb13:                                             ; preds = %bb11
  %12 = load i64, ptr %n, align 8
  %_4 = icmp sle i64 4, %12
  br i1 %_4, label %bb7, label %bb5

bb12:                                             ; preds = %bb11
  store ptr @alloc_fbf52d5fed6793d3e790c9ce6627a01c, ptr %_0, align 8, !captures !130
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 4, ptr %13, align 8
  br label %bb14

bb5:                                              ; preds = %bb7, %bb13
  store ptr @alloc_7ec976a351c849ad2fc3958edc69f6f6, ptr %_0, align 8, !captures !130
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 3, ptr %14, align 8
  br label %bb14

bb7:                                              ; preds = %bb13
  %15 = load i64, ptr %n, align 8
  %_5 = icmp sle i64 %15, 99
  br i1 %_5, label %bb6, label %bb5

bb6:                                              ; preds = %bb7
  store ptr @alloc_f5f4cccb72aa20d03a19e99c91cbe0b2, ptr %_0, align 8, !captures !130
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 7, ptr %16, align 8
  br label %bb14
}

; patterns::parse_kv
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCsccF2givDBH6_8patterns8parse_kv(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !168 {
start:
  %0 = alloca [8 x i8], align 8
  %_10 = alloca [24 x i8], align 8
  %_7 = alloca [8 x i8], align 4
  %_4 = alloca [32 x i8], align 8
; call <str>::split_once::<char>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre10split_oncecECsddYV2PBJW9h_3std(ptr sret([32 x i8]) align 8 %_4, ptr %s.0, i64 %s.1, i32 61) #18
  %1 = load ptr, ptr %_4, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_5 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_5 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %k.0 = load ptr, ptr %_4, align 8
  %5 = getelementptr inbounds i8, ptr %_4, i64 8
  %k.1 = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %v.0 = load ptr, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  %v.1 = load i64, ptr %7, align 8
; call <str>::trim
  %8 = call { ptr, i64 } @_RNvMNtCsl10jNU3mE6R_4core3stre4trimCsccF2givDBH6_8patterns(ptr %v.0, i64 %v.1) #18
  %_8.0 = extractvalue { ptr, i64 } %8, 0
  %_8.1 = extractvalue { ptr, i64 } %8, 1
; call <str>::parse::<i32>
  %9 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parselECsccF2givDBH6_8patterns(ptr %_8.0, i64 %_8.1) #18
  store i64 %9, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_7, ptr align 8 %0, i64 8, i1 false)
  %10 = load i8, ptr %_7, align 4
  %11 = trunc nuw i8 %10 to i1
  %_9 = zext i1 %11 to i64
  %12 = trunc nuw i64 %_9 to i1
  br i1 %12, label %bb7, label %bb6

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb9

bb7:                                              ; preds = %bb2
  store ptr null, ptr %_0, align 8
  br label %bb9

bb6:                                              ; preds = %bb2
  %13 = getelementptr inbounds i8, ptr %_7, i64 4
  %n = load i32, ptr %13, align 4
; call <str>::trim
  %14 = call { ptr, i64 } @_RNvMNtCsl10jNU3mE6R_4core3stre4trimCsccF2givDBH6_8patterns(ptr %k.0, i64 %k.1) #18
  %_11.0 = extractvalue { ptr, i64 } %14, 0
  %_11.1 = extractvalue { ptr, i64 } %14, 1
  store ptr %_11.0, ptr %_10, align 8
  %15 = getelementptr inbounds i8, ptr %_10, i64 8
  store i64 %_11.1, ptr %15, align 8
  %16 = getelementptr inbounds i8, ptr %_10, i64 16
  store i32 %n, ptr %16, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_10, i64 24, i1 false)
  br label %bb9

bb9:                                              ; preds = %bb3, %bb7, %bb6
  ret void

bb10:                                             ; No predecessors!
  unreachable
}

; patterns::slice_pat
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCsccF2givDBH6_8patterns9slice_pat(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %v.0, i64 %v.1) unnamed_addr #1 !guid !169 {
start:
  %_42 = alloca [16 x i8], align 8
  %_41 = alloca [16 x i8], align 8
  %args3 = alloca [32 x i8], align 8
  %_35 = alloca [24 x i8], align 8
  %rest = alloca [16 x i8], align 8
  %first2 = alloca [8 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %args1 = alloca [16 x i8], align 8
  %_25 = alloca [24 x i8], align 8
  %last = alloca [8 x i8], align 8
  %first = alloca [8 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %x = alloca [8 x i8], align 8
  %_9 = icmp eq i64 %v.1, 0
  br i1 %_9, label %bb8, label %bb2

bb2:                                              ; preds = %start
  %_5 = icmp eq i64 %v.1, 1
  br i1 %_5, label %bb7, label %bb4

bb8:                                              ; preds = %start
; call <&str as core::convert::Into<alloc::string::String>>::into
  call void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr @alloc_c597b50e4e89f734c8b5ae53c406eb3f, i64 5, ptr align 8 @alloc_0cc6dc99297ba9fc0efa6643cc60563b) #18
  br label %bb21

bb4:                                              ; preds = %bb2
  %_3 = icmp uge i64 %v.1, 2
  br i1 %_3, label %bb6, label %bb3

bb7:                                              ; preds = %bb2
  %0 = getelementptr inbounds nuw i32, ptr %v.0, i64 0
  store ptr %0, ptr %x, align 8
; call <core::fmt::rt::Argument>::new_display::<&i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_17, ptr align 8 %x) #18
  %1 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 1>
  %2 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_33854f2712a70d661249338f09901dcb, ptr align 8 %args) #18
  %_13.0 = extractvalue { ptr, ptr } %2, 0
  %_13.1 = extractvalue { ptr, ptr } %2, 1
; call alloc::fmt::format
  call void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_12, ptr %_13.0, ptr %_13.1) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_12, i64 24, i1 false)
  br label %bb21

bb3:                                              ; preds = %bb6, %bb4
  %_7 = icmp uge i64 %v.1, 1
  br i1 %_7, label %bb5, label %bb1

bb6:                                              ; preds = %bb4
  %3 = getelementptr inbounds nuw i32, ptr %v.0, i64 0
  store ptr %3, ptr %first, align 8
  %4 = sub i64 %v.1, 1
  %5 = getelementptr inbounds nuw i32, ptr %v.0, i64 %4
  store ptr %5, ptr %last, align 8
; call <&i32 as core::cmp::PartialEq>::eq
  %_24 = call zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRlNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %first, ptr align 8 %last) #18
  br i1 %_24, label %bb13, label %bb3

bb13:                                             ; preds = %bb6
; call <core::fmt::rt::Argument>::new_display::<&i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_30, ptr align 8 %first) #18
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_30, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 1>
  %7 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_8f41006de9107663c983a7194b89e648, ptr align 8 %args1) #18
  %_26.0 = extractvalue { ptr, ptr } %7, 0
  %_26.1 = extractvalue { ptr, ptr } %7, 1
; call alloc::fmt::format
  call void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_25, ptr %_26.0, ptr %_26.1) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_25, i64 24, i1 false)
  br label %bb21

bb1:                                              ; preds = %bb3
  unreachable

bb5:                                              ; preds = %bb3
  %8 = getelementptr inbounds nuw i32, ptr %v.0, i64 0
  store ptr %8, ptr %first2, align 8
  %9 = getelementptr inbounds nuw i32, ptr %v.0, i64 1
  %10 = sub i64 %v.1, 1
  store ptr %9, ptr %rest, align 8
  %11 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %10, ptr %11, align 8
; call <core::fmt::rt::Argument>::new_display::<&i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_41, ptr align 8 %first2) #18
; call <core::fmt::rt::Argument>::new_debug::<&[i32]>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_42, ptr align 8 %rest) #18
  %12 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %12, ptr align 8 %_41, i64 16, i1 false)
  %13 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %_42, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 2>
  %14 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj2_EB8_(ptr @alloc_29912b6d8be215f231ca050c1de43b0b, ptr align 8 %args3) #18
  %_36.0 = extractvalue { ptr, ptr } %14, 0
  %_36.1 = extractvalue { ptr, ptr } %14, 1
; call alloc::fmt::format
  call void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_35, ptr %_36.0, ptr %_36.1) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_35, i64 24, i1 false)
  br label %bb21

bb21:                                             ; preds = %bb8, %bb7, %bb13, %bb5
  ret void
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !170 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !171 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #18
  ret i64 %_0
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !172 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8 %self) #18
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr %_2.0, i64 %_2.1) #18
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !173 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <str>::trim
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCsl10jNU3mE6R_4core3stre4trimCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !174 {
start:
; call <str>::trim_matches::<<char>::is_whitespace>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre12trim_matchesNvMNtNtB5_4char7methodsc13is_whitespaceECsddYV2PBJW9h_3std(ptr %self.0, i64 %self.1)
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitRSlE8is_emptyCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !175 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitxE8is_emptyCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !176 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[patterns::Shape]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCsccF2givDBH6_8patterns5Shape4iterBw_(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !177 {
start:
; call <core::slice::iter::Iter<patterns::Shape>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterNtCsccF2givDBH6_8patterns5ShapeE3newBQ_(ptr align 8 %self.0, i64 %self.1) #18
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE3newB1G_(ptr align 8 %x.0, i64 %x.1) unnamed_addr #1 !guid !178 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE6as_mutB1G_(ptr align 8 %self) unnamed_addr #1 !guid !179 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE6as_refB1G_(ptr align 8 %self) unnamed_addr #1 !guid !180 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE3newCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !181 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 80, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #1 !guid !182 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE3newCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !183 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 72, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #1 !guid !184 {
start:
  ret ptr %self
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsccF2givDBH6_8patterns(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !185 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #18
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %align, ptr align 8 %0) #22
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsccF2givDBH6_8patterns(i64 %self) unnamed_addr #0 !guid !186 {
start:
  ret i64 %self
}

; <core::ops::index_range::IndexRange>::next_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !187 {
start:
  %value = load i64, ptr %self, align 8
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #18
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCsccF2givDBH6_8patterns(i64 %value, i64 1, ptr align 8 @alloc_de9a5d9a80d554992107c1ea3afec081) #22
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i64 %value, 1
  store i64 %_0.i, ptr %self, align 8
  ret i64 %value
}

; <core::ops::index_range::IndexRange>::end
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !188 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !189 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_2 = load i64, ptr %0, align 8
  %_3 = load i64, ptr %self, align 8
  %_0 = sub nuw i64 %_2, %_3
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::start
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !190 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::zero_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCsccF2givDBH6_8patterns(i64 %end) unnamed_addr #0 !guid !191 {
start:
  %0 = insertvalue { i64, i64 } { i64 0, i64 poison }, i64 %end, 1
  ret { i64, i64 } %0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %self, i32 %radix) unnamed_addr #0 !guid !192 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #18
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #21
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !193 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsccF2givDBH6_8patterns(i64 %_3) #18
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #18
  ret ptr %_0
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsccF2givDBH6_8patterns(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !194 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %size, i64 %alignment, ptr align 8 %0) #22
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !195 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !196 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::array::iter::IntoIter<&[i32], 4>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterRSlKj4_E10unsize_mutCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !197 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 4, 1
  ret { ptr, i64 } %1
}

; <core::array::iter::IntoIter<i64, 7>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterxKj7_E10unsize_mutCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !198 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 7, 1
  ret { ptr, i64 } %1
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsccF2givDBH6_8patterns(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !199 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsccF2givDBH6_8patterns(i64 %3, i64 %5, i1 zeroext %8) #18
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsccF2givDBH6_8patterns(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !200 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsccF2givDBH6_8patterns(ptr %2, i64 %4, i64 %6) #18
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsccF2givDBH6_8patterns(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !201 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #18
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsccF2givDBH6_8patterns(i64 %11, i64 %13) #18
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsccF2givDBH6_8patterns(i64 %15, i64 %17) #18
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #18
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #18
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #18
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #18
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #18
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsccF2givDBH6_8patterns(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !202 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsccF2givDBH6_8patterns(ptr %ptr, i64 %3, i64 %5) #18
  br label %bb3
}

; <alloc::raw_vec::RawVec<patterns::Shape>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !203 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<patterns::Shape>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCsccF2givDBH6_8patterns5ShapeEBG_(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr %ptr, i64 %capacity2) #18
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<patterns::Shape>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE3ptrBO_(ptr align 8 %self) unnamed_addr #0 !guid !204 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<patterns::Shape>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCsccF2givDBH6_8patterns5ShapeEBY_(ptr align 8 %self) #18
  ret ptr %_0
}

; <i32>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCsccF2givDBH6_8patterns(i32 %self, i32 %rhs) unnamed_addr #0 !guid !205 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsccF2givDBH6_8patterns(i32 %self, i32 %rhs) unnamed_addr #0 !guid !206 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_subCsccF2givDBH6_8patterns(i32 %self, i32 %rhs) unnamed_addr #0 !guid !207 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <core::ptr::unique::Unique<patterns::Shape>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCsccF2givDBH6_8patterns5ShapeE15as_non_null_ptrBS_(ptr %self) unnamed_addr #0 !guid !208 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<[patterns::Shape]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCsccF2givDBH6_8patterns5ShapeE6as_ptrBT_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !209 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::non_null::NonNull<core::option::Option<(&str, i32)>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionTRelEEE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !210 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !211 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&patterns::Shape>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtCsccF2givDBH6_8patterns5ShapeE8from_refBW_(ptr align 8 %r) unnamed_addr #0 !guid !212 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&[i32]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSlE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !213 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&i32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRlE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !214 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[patterns::Shape]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE8from_refBW_(ptr align 8 %r.0, i64 %r.1) unnamed_addr #0 !guid !215 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<i16>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsccF2givDBH6_8patterns(ptr align 2 %r) unnamed_addr #0 !guid !216 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !217 {
start:
  ret ptr %r
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsccF2givDBH6_8patterns(i64 %val) unnamed_addr #0 !guid !218 {
start:
  ret i64 %val
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEj4_E13new_uncheckedCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 8 %data) unnamed_addr #0 !guid !219 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %data, i64 64, i1 false)
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEj7_E13new_uncheckedCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 8 %data) unnamed_addr #0 !guid !220 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %data, i64 56, i1 false)
  ret void
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !221 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #18
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr %_7.0, i64 %_7.1) #18
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !222 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsccF2givDBH6_8patterns(ptr %s.0, i64 %s.1) #18
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<patterns::Shape>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterNtCsccF2givDBH6_8patterns5ShapeE3newBQ_(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !223 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[patterns::Shape]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE8from_refBW_(ptr align 8 %slice.0, i64 %slice.1) #18
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[patterns::Shape]>>::cast::<patterns::Shape>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE4castBV_EBX_(ptr %_4.0, i64 %_4.1) #18
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw %Shape, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<[patterns::Shape]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeE23into_raw_with_allocatorBK_(ptr align 8 %b.0, i64 %b.1) unnamed_addr #0 !guid !224 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE3newB1G_(ptr align 8 %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE6as_mutB1G_(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE6as_refB1G_(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEE4nextCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !225 {
start:
; call <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self.0) #18
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_5.0 = getelementptr inbounds i8, ptr %self.0, i64 16
; call <core::option::Option<usize>>::map::<&[i32], <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next::{closure#0}>
  %1 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapRSlNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBZ_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECsccF2givDBH6_8patterns(i64 %_2.0, i64 %_2.1, ptr align 8 %_5.0, i64 %self.1) #18
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEE4nextCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !226 {
start:
; call <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self.0) #18
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_5.0 = getelementptr inbounds i8, ptr %self.0, i64 16
; call <core::option::Option<usize>>::map::<i64, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next::{closure#0}>
  %1 = call { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapxNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBX_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxEE4next0ECsccF2givDBH6_8patterns(i64 %_2.0, i64 %_2.1, ptr align 8 %_5.0, i64 %self.1) #18
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !227 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsccF2givDBH6_8patterns(i8 %0) unnamed_addr #0 !guid !228 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsccF2givDBH6_8patterns(ptr %self) #18
  ret i32 %_0
}

; <alloc::vec::Vec<patterns::Shape>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE10as_mut_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !229 {
start:
; call <alloc::raw_vec::RawVec<patterns::Shape>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE3ptrBO_(ptr align 8 %self) #18
  ret ptr %_0
}

; <alloc::vec::Vec<patterns::Shape>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !230 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCsccF2givDBH6_8patterns(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #22
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<patterns::Shape>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) #18
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<patterns::Shape>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE6as_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !231 {
start:
; call <alloc::raw_vec::RawVec<patterns::Shape>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE3ptrBO_(ptr align 8 %self) #18
  ret ptr %_2
}

; <alloc::vec::Vec<patterns::Shape>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE8as_sliceBG_(ptr align 8 %self) unnamed_addr #0 !guid !232 {
start:
; call <alloc::vec::Vec<patterns::Shape>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE6as_ptrBG_(ptr align 8 %self) #18
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitRSlEj4_EE4dropCsccF2givDBH6_8patterns(ptr align 8 %slot) unnamed_addr #0 !guid !233 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitRSlEj4_EECsccF2givDBH6_8patterns(ptr align 8 %_3)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitxEj7_EE4dropCsccF2givDBH6_8patterns(ptr align 8 %slot) unnamed_addr #0 !guid !234 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitxEj7_EECsccF2givDBH6_8patterns(ptr align 8 %_3)
  ret void
}

; <*mut patterns::Shape>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCsccF2givDBH6_8patterns5Shape10cast_sliceBG_(ptr %self, i64 %len) unnamed_addr #0 !guid !235 {
start:
; call core::ptr::slice_from_raw_parts_mut::<patterns::Shape>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCsccF2givDBH6_8patterns5ShapeEBT_(ptr %self, i64 %len) #18
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <i32>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl14from_str_radixCsccF2givDBH6_8patterns(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !236 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
  %1 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %2, 0
  %_3.1 = extractvalue { ptr, i64 } %2, 1
; call <i32>::from_ascii_bytes_radix_impl
  %3 = call i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl27from_ascii_bytes_radix_implCsccF2givDBH6_8patterns(ptr %_3.0, i64 %_3.1, i32 %radix) #18
  store i64 %3, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %4 = load i64, ptr %_0, align 4
  ret i64 %4
}

; <i32>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl27from_ascii_bytes_radix_implCsccF2givDBH6_8patterns(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !237 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [8 x i8], align 4
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [8 x i8], align 4
  %_74 = alloca [8 x i8], align 4
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [8 x i8], align 4
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [4 x i8], align 4
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #21
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #18
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i64, ptr %_0, align 4
  ret i64 %4

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %5 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  store i64 %src.1, ptr %6, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %7 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %8 = load i8, ptr %7, align 1
  switch i8 %8, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %9 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %rest.1, ptr %10, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %11 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %12 = sub i64 %src.1, 1
  store ptr %11, ptr %rest, align 8
  %13 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %12, ptr %13, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %14 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %14 to i1
  %15 = getelementptr inbounds i8, ptr %_12, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = getelementptr inbounds i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  store ptr %16, ptr %digits, align 8, !captures !130
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %18, ptr %19, align 8
  store i32 0, ptr %result, align 4
  %_24.0 = load ptr, ptr %digits, align 8
  %20 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %20, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit

bb1.i:                                            ; preds = %bb15
  %21 = icmp ule i64 %_24.1, 7
  %22 = zext i1 %21 to i8
  store i8 %22, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit: ; preds = %bb2.i, %bb1.i
  %23 = load i8, ptr %_0.i, align 1
  %24 = trunc nuw i8 %23 to i1
  br i1 %24, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %25 = load ptr, ptr %rest, align 8
  %26 = getelementptr inbounds i8, ptr %rest, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %25, ptr %28, align 8
  %29 = getelementptr inbounds i8, ptr %28, i64 8
  store i64 %27, ptr %29, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %30 = load ptr, ptr %digits, align 8
  %31 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %31, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %32 = load ptr, ptr %digits, align 8
  %33 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %33, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i32, ptr %result, align 4
  %34 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_105, ptr %34, align 4
  store i8 0, ptr %_0, align 4
  br label %bb53

bb42:                                             ; preds = %bb41
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %37 = load i64, ptr %36, align 8
  %c = getelementptr inbounds nuw i8, ptr %35, i64 0
  %38 = load ptr, ptr %digits, align 8
  %39 = getelementptr inbounds i8, ptr %digits, i64 8
  %40 = load i64, ptr %39, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %38, i64 1
  %rest.13 = sub i64 %40, 1
  %_85 = load i32, ptr %result, align 4
; call <i32>::checked_mul
  %41 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsccF2givDBH6_8patterns(i32 %_85, i32 %radix) #18
  %42 = extractvalue { i32, i32 } %41, 0
  %43 = extractvalue { i32, i32 } %41, 1
  store i32 %42, ptr %mul1, align 4
  %44 = getelementptr inbounds i8, ptr %mul1, i64 4
  store i32 %43, ptr %44, align 4
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %45 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %_89, i32 %radix) #18
  %46 = extractvalue { i32, i32 } %45, 0
  %47 = extractvalue { i32, i32 } %45, 1
  store i32 %46, ptr %_88, align 4
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %47, ptr %48, align 4
  %49 = load i32, ptr %_88, align 4
  %50 = getelementptr inbounds i8, ptr %_88, i64 4
  %51 = load i32, ptr %50, align 4
  %_91 = zext i32 %49 to i64
  %52 = trunc nuw i64 %_91 to i1
  br i1 %52, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %53, align 4
  %54 = load i32, ptr %mul1, align 4
  %55 = getelementptr inbounds i8, ptr %mul1, i64 4
  %56 = load i32, ptr %55, align 4
  %_95 = zext i32 %54 to i64
  %57 = trunc nuw i64 %_95 to i1
  br i1 %57, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %58 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %58, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb48:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %mul1, i64 4
  %value4 = load i32, ptr %59, align 4
  store i32 %value4, ptr %result, align 4
  %_100 = load i32, ptr %result, align 4
; call <i32>::checked_sub
  %60 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_subCsccF2givDBH6_8patterns(i32 %_100, i32 %value) #18
  %61 = extractvalue { i32, i32 } %60, 0
  %62 = extractvalue { i32, i32 } %60, 1
  store i32 %61, ptr %_99, align 4
  %63 = getelementptr inbounds i8, ptr %_99, i64 4
  store i32 %62, ptr %63, align 4
  %64 = load i32, ptr %_99, align 4
  %65 = getelementptr inbounds i8, ptr %_99, i64 4
  %66 = load i32, ptr %65, align 4
  %_101 = zext i32 %64 to i64
  %67 = trunc nuw i64 %_101 to i1
  br i1 %67, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %68 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %68, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb51:                                             ; preds = %bb48
  %69 = getelementptr inbounds i8, ptr %_99, i64 4
  %value5 = load i32, ptr %69, align 4
  store i32 %value5, ptr %result, align 4
  store ptr %rest.02, ptr %digits, align 8, !captures !130
  %70 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %70, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %71 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %71, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb31:                                             ; preds = %bb30
  %72 = load ptr, ptr %digits, align 8
  %73 = getelementptr inbounds i8, ptr %digits, i64 8
  %74 = load i64, ptr %73, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %72, i64 0
  %75 = load ptr, ptr %digits, align 8
  %76 = getelementptr inbounds i8, ptr %digits, i64 8
  %77 = load i64, ptr %76, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %75, i64 1
  %rest.18 = sub i64 %77, 1
  %_60 = load i32, ptr %result, align 4
; call <i32>::checked_mul
  %78 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsccF2givDBH6_8patterns(i32 %_60, i32 %radix) #18
  %79 = extractvalue { i32, i32 } %78, 0
  %80 = extractvalue { i32, i32 } %78, 1
  store i32 %79, ptr %mul, align 4
  %81 = getelementptr inbounds i8, ptr %mul, i64 4
  store i32 %80, ptr %81, align 4
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %82 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %_64, i32 %radix) #18
  %83 = extractvalue { i32, i32 } %82, 0
  %84 = extractvalue { i32, i32 } %82, 1
  store i32 %83, ptr %_63, align 4
  %85 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %84, ptr %85, align 4
  %86 = load i32, ptr %_63, align 4
  %87 = getelementptr inbounds i8, ptr %_63, i64 4
  %88 = load i32, ptr %87, align 4
  %_66 = zext i32 %86 to i64
  %89 = trunc nuw i64 %_66 to i1
  br i1 %89, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %90 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %90, align 4
  %91 = load i32, ptr %mul, align 4
  %92 = getelementptr inbounds i8, ptr %mul, i64 4
  %93 = load i32, ptr %92, align 4
  %_70 = zext i32 %91 to i64
  %94 = trunc nuw i64 %_70 to i1
  br i1 %94, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %95 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %95, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb37:                                             ; preds = %bb35
  %96 = getelementptr inbounds i8, ptr %mul, i64 4
  %value10 = load i32, ptr %96, align 4
  store i32 %value10, ptr %result, align 4
  %_75 = load i32, ptr %result, align 4
; call <i32>::checked_add
  %97 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCsccF2givDBH6_8patterns(i32 %_75, i32 %value9) #18
  %98 = extractvalue { i32, i32 } %97, 0
  %99 = extractvalue { i32, i32 } %97, 1
  store i32 %98, ptr %_74, align 4
  %100 = getelementptr inbounds i8, ptr %_74, i64 4
  store i32 %99, ptr %100, align 4
  %101 = load i32, ptr %_74, align 4
  %102 = getelementptr inbounds i8, ptr %_74, i64 4
  %103 = load i32, ptr %102, align 4
  %_76 = zext i32 %101 to i64
  %104 = trunc nuw i64 %_76 to i1
  br i1 %104, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %105 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %105, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb40:                                             ; preds = %bb37
  %106 = getelementptr inbounds i8, ptr %_74, i64 4
  %value11 = load i32, ptr %106, align 4
  store i32 %value11, ptr %result, align 4
  store ptr %rest.07, ptr %digits, align 8, !captures !130
  %107 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %107, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %108 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %108, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %109 = load ptr, ptr %digits, align 8
  %110 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %110, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %111 = load ptr, ptr %digits, align 8
  %112 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %112, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %113 = load ptr, ptr %digits, align 8
  %114 = getelementptr inbounds i8, ptr %digits, i64 8
  %115 = load i64, ptr %114, align 8
  %c12 = getelementptr inbounds nuw i8, ptr %113, i64 0
  %116 = load ptr, ptr %digits, align 8
  %117 = getelementptr inbounds i8, ptr %digits, i64 8
  %118 = load i64, ptr %117, align 8
  %rest.013 = getelementptr inbounds nuw i8, ptr %116, i64 1
  %rest.114 = sub i64 %118, 1
  %_44 = load i32, ptr %result, align 4
  %119 = mul i32 %_44, %radix
  store i32 %119, ptr %result, align 4
  %_48 = load i8, ptr %c12, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %120 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %_47, i32 %radix) #18
  %121 = extractvalue { i32, i32 } %120, 0
  %122 = extractvalue { i32, i32 } %120, 1
  store i32 %121, ptr %_46, align 4
  %123 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %122, ptr %123, align 4
  %124 = load i32, ptr %_46, align 4
  %125 = getelementptr inbounds i8, ptr %_46, i64 4
  %126 = load i32, ptr %125, align 4
  %_49 = zext i32 %124 to i64
  %127 = trunc nuw i64 %_49 to i1
  br i1 %127, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %128 = getelementptr inbounds i8, ptr %_46, i64 4
  %x = load i32, ptr %128, align 4
  %_53 = load i32, ptr %result, align 4
  %129 = sub i32 %_53, %x
  store i32 %129, ptr %result, align 4
  store ptr %rest.013, ptr %digits, align 8, !captures !130
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.114, ptr %130, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %131 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %131, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb19:                                             ; preds = %bb18
  %132 = load ptr, ptr %digits, align 8
  %133 = getelementptr inbounds i8, ptr %digits, i64 8
  %134 = load i64, ptr %133, align 8
  %c15 = getelementptr inbounds nuw i8, ptr %132, i64 0
  %135 = load ptr, ptr %digits, align 8
  %136 = getelementptr inbounds i8, ptr %digits, i64 8
  %137 = load i64, ptr %136, align 8
  %rest.016 = getelementptr inbounds nuw i8, ptr %135, i64 1
  %rest.117 = sub i64 %137, 1
  %_29 = load i32, ptr %result, align 4
  %138 = mul i32 %_29, %radix
  store i32 %138, ptr %result, align 4
  %_33 = load i8, ptr %c15, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %139 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %_32, i32 %radix) #18
  %140 = extractvalue { i32, i32 } %139, 0
  %141 = extractvalue { i32, i32 } %139, 1
  store i32 %140, ptr %_31, align 4
  %142 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %141, ptr %142, align 4
  %143 = load i32, ptr %_31, align 4
  %144 = getelementptr inbounds i8, ptr %_31, i64 4
  %145 = load i32, ptr %144, align 4
  %_34 = zext i32 %143 to i64
  %146 = trunc nuw i64 %_34 to i1
  br i1 %146, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %147 = getelementptr inbounds i8, ptr %_31, i64 4
  %x18 = load i32, ptr %147, align 4
  %_38 = load i32, ptr %result, align 4
  %148 = add i32 %_38, %x18
  store i32 %148, ptr %result, align 4
  store ptr %rest.016, ptr %digits, align 8, !captures !130
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.117, ptr %149, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %150 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %150, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !238 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsccF2givDBH6_8patterns(ptr align 8 %args) #18
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #18
  ret void
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsccF2givDBH6_8patterns(i64 %0, i64 %1) unnamed_addr #0 !guid !239 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #23
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #23
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsccF2givDBH6_8patterns(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !240 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #23
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsccF2givDBH6_8patterns(i64 %0, i64 %1) unnamed_addr #0 !guid !241 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #23
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #23
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsccF2givDBH6_8patterns(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !242 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsccF2givDBH6_8patterns(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #18
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #24
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #18
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsccF2givDBH6_8patterns() unnamed_addr #3 !guid !243 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() unnamed_addr #0 !guid !244 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsccF2givDBH6_8patterns() #18
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !245 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %align, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !246 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #20
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !247 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #20
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCsccF2givDBH6_8patterns(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !248 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #20
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCsccF2givDBH6_8patterns(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !249 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #20
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsccF2givDBH6_8patterns() unnamed_addr #0 !guid !250 {
start:
  ret i1 true
}

; <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %this, i64 %len, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !251 {
start:
  %_3 = icmp ult i64 %this, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_97d92cbf2a68a6ac45a1b13da79836e4, i64 214)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #20
  unreachable
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCsccF2givDBH6_8patterns(i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !252 {
start:
  %_3 = icmp ule i64 %end, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_5a8fdd84b3281310cbf6b74bb6bf0065, i64 218)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #20
  unreachable
}

; <patterns::Shape as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXCsccF2givDBH6_8patternsNtB2_5ShapeNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB2_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !253 {
start:
  %__self_2 = alloca [8 x i8], align 8
  %__self_1 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %_3 = zext i8 %0 to i64
  switch i64 %_3, label %bb1 [
    i64 0, label %bb5
    i64 1, label %bb4
    i64 2, label %bb3
    i64 3, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb5:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %2 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_61b2665611c43956f6751fc9541d260a, i64 6, ptr %__self_0, ptr align 8 @vtable.2)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb6

bb4:                                              ; preds = %start
  %__self_01 = getelementptr inbounds i8, ptr %self, i64 4
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %4, ptr %__self_1, align 8
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr align 8 %f, ptr @alloc_6319043cda67dca378296c9d6ea4e61a, i64 4, ptr @alloc_91e924fd2a69c8524f72852661c5910c, i64 1, ptr %__self_01, ptr align 8 @vtable.3, ptr @alloc_d22b16ed1fc9d86532371a89eda619b7, i64 1, ptr %__self_1, ptr align 8 @vtable.4)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb6

bb3:                                              ; preds = %start
  %__self_02 = getelementptr inbounds i8, ptr %self, i64 1
  %__self_13 = getelementptr inbounds i8, ptr %self, i64 2
  %7 = getelementptr inbounds i8, ptr %self, i64 3
  store ptr %7, ptr %__self_2, align 8
; call <core::fmt::Formatter>::debug_tuple_field3_finish
  %8 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field3_finish(ptr align 8 %f, ptr @alloc_b786fa3e298d0013cbd9d16f11d06f34, i64 3, ptr %__self_02, ptr align 8 @vtable.5, ptr %__self_13, ptr align 8 @vtable.5, ptr %__self_2, ptr align 8 @vtable.6)
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %_0, align 1
  br label %bb6

bb2:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %10 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_59ba7b9f7211443cd55a366616eef46a, i64 5)
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %_0, align 1
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3, %bb4, %bb5
  %12 = load i8, ptr %_0, align 1
  %13 = trunc nuw i8 %12 to i1
  ret i1 %13
}

; <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !254 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitRSlENtB2_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !255 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitRSlE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1, ptr align 8 @alloc_c7037efb906203803aa3ca07167c9120) #18
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitRSlE8is_emptyCsccF2givDBH6_8patterns(ptr align 8 %_3.0, i64 %_3.1) #18
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitRSlE16assume_init_dropCsccF2givDBH6_8patterns.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitRSlE16assume_init_dropCsccF2givDBH6_8patterns.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitRSlE16assume_init_dropCsccF2givDBH6_8patterns.exit: ; preds = %start, %bb2.i
  ret void
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitxENtB2_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !256 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<i64>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1, ptr align 8 @alloc_c7037efb906203803aa3ca07167c9120) #18
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<i64>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitxE8is_emptyCsccF2givDBH6_8patterns(ptr align 8 %_3.0, i64 %_3.1) #18
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitxE16assume_init_dropCsccF2givDBH6_8patterns.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitxE16assume_init_dropCsccF2givDBH6_8patterns.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitxE16assume_init_dropCsccF2givDBH6_8patterns.exit: ; preds = %start, %bb2.i
  ret void
}

; <[&[i32]; 4] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARSlj4_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !257 {
start:
  %0 = alloca [80 x i8], align 8
  %_2.i = alloca [80 x i8], align 8
  %1 = alloca [80 x i8], align 8
  %2 = alloca [64 x i8], align 8
  %_5 = alloca [80 x i8], align 8
  %inner = alloca [80 x i8], align 8
  %data = alloca [64 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %self, i64 64, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCsccF2givDBH6_8patterns(i64 4) #18
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %data, i64 64, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEj4_E13new_uncheckedCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 8 %2) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 80, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 80, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE3newCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 80, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 80, i1 false)
  ret void
}

; <[i64; 7] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAxj7_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !258 {
start:
  %0 = alloca [72 x i8], align 8
  %_2.i = alloca [72 x i8], align 8
  %1 = alloca [72 x i8], align 8
  %2 = alloca [56 x i8], align 8
  %_5 = alloca [72 x i8], align 8
  %inner = alloca [72 x i8], align 8
  %data = alloca [56 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %self, i64 56, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCsccF2givDBH6_8patterns(i64 7) #18
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %data, i64 56, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEj7_E13new_uncheckedCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 8 %2) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 72, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 72, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE3newCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 72, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 72, i1 false)
  ret void
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitRSlEE13get_uncheckedCsccF2givDBH6_8patterns(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !259 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #18
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitRSlEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #18
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<&[i32]>", ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitRSlEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #18
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %self, i64 %_0.i1, ptr align 8 %0) #22
  br label %bb4
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitxEE13get_uncheckedCsccF2givDBH6_8patterns(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !260 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #18
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<i64>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitxEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #18
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw i64, ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<i64>]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitxEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #18
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %self, i64 %_0.i1, ptr align 8 %0) #22
  br label %bb4
}

; <(&str, i32) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTRelENtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !261 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.7)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.0)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsccF2givDBH6_8patterns(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !262 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsccF2givDBH6_8patterns(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #18
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsccF2givDBH6_8patterns(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !263 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsccF2givDBH6_8patterns(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #18
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<patterns::Shape> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %self) unnamed_addr #1 !guid !264 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 8, i64 16)
  ret void
}

; <&str as core::convert::Into<alloc::string::String>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !265 {
start:
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #18
  ret void
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitRSlEE17get_unchecked_mutCsccF2givDBH6_8patterns(i64 %0, i64 %1, ptr %slice.0, i64 %slice.1, ptr align 8 %2) unnamed_addr #0 !guid !266 {
start:
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ops::index_range::IndexRange>::end
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCsccF2givDBH6_8patterns(ptr align 8 %self) #18
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitRSlEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #18
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCsccF2givDBH6_8patterns(i64 %_5, i64 %_0.i, ptr align 8 %2) #22
  br label %bb4

bb4:                                              ; preds = %bb1
; call <core::ops::index_range::IndexRange>::start
  %_8 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCsccF2givDBH6_8patterns(ptr align 8 %self) #18
; call <core::ops::index_range::IndexRange>::len
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  %ptr.i = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<&[i32]>", ptr %slice.0, i64 %_8
  %4 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_10, 1
  %_0.0 = extractvalue { ptr, i64 } %5, 0
  %_0.1 = extractvalue { ptr, i64 } %5, 1
  %6 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %_0.1, 1
  ret { ptr, i64 } %7
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitxEE17get_unchecked_mutCsccF2givDBH6_8patterns(i64 %0, i64 %1, ptr %slice.0, i64 %slice.1, ptr align 8 %2) unnamed_addr #0 !guid !267 {
start:
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ops::index_range::IndexRange>::end
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCsccF2givDBH6_8patterns(ptr align 8 %self) #18
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<i64>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitxEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #18
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCsccF2givDBH6_8patterns(i64 %_5, i64 %_0.i, ptr align 8 %2) #22
  br label %bb4

bb4:                                              ; preds = %bb1
; call <core::ops::index_range::IndexRange>::start
  %_8 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCsccF2givDBH6_8patterns(ptr align 8 %self) #18
; call <core::ops::index_range::IndexRange>::len
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  %ptr.i = getelementptr inbounds nuw i64, ptr %slice.0, i64 %_8
  %4 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_10, 1
  %_0.0 = extractvalue { ptr, i64 } %5, 0
  %_0.1 = extractvalue { ptr, i64 } %5, 1
  %6 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %_0.1, 1
  ret { ptr, i64 } %7
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEj4_ENtNtNtBb_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !268 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitRSlEj4_NtB4_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEj7_ENtNtNtBb_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !269 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<i64>; 7] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitxEj7_NtB4_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <&patterns::Shape as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtCsccF2givDBH6_8patterns5ShapeNtB6_5Debug3fmtBy_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !270 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <patterns::Shape as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXCsccF2givDBH6_8patternsNtB2_5ShapeNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB2_(ptr align 8 %_3, ptr align 8 %f) #18
  ret i1 %_0
}

; <&[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSlNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !271 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[i32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&(&str, i32) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRTRelENtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !272 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <(&str, i32) as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTRelENtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !273 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <f64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&i32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRlNtB6_7Display3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !274 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i32 as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <u32 as core::ops::arith::Mul>::mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs25_NtNtCsl10jNU3mE6R_4core3ops5arithmNtB6_3Mul3mulCsccF2givDBH6_8patterns(i32 %self, i32 %other, ptr align 8 %0) unnamed_addr #0 !guid !275 {
start:
  %1 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %other)
  %_3.0 = extractvalue { i32, i1 } %1, 0
  %_3.1 = extractvalue { i32, i1 } %1, 1
  br i1 %_3.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_3.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 %0) #21
  unreachable
}

; <core::slice::iter::Iter<patterns::Shape> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterNtCsccF2givDBH6_8patterns5ShapeENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBR_(ptr align 8 %self) unnamed_addr #0 !guid !276 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<patterns::Shape> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCsccF2givDBH6_8patterns5ShapeENtNtB9_3cmp9PartialEq2eqBV_(ptr align 8 %ptr, ptr align 8 %_11) #18
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw %Shape, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <f64 as core::ops::arith::Mul<&f64>>::mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvXs2Z_NtNtCsl10jNU3mE6R_4core3ops5arithdINtB6_3MulRdE3mulCsccF2givDBH6_8patterns(double %self, ptr align 8 %other, ptr align 8 %0) unnamed_addr #0 !guid !277 {
start:
  %_3 = load double, ptr %other, align 8
; call <f64 as core::ops::arith::Mul>::mul
  %_0 = call double @_RNvXs2g_NtNtCsl10jNU3mE6R_4core3ops5arithdNtB6_3Mul3mulCsccF2givDBH6_8patterns(double %self, double %_3, ptr align 8 %0) #18
  ret double %_0
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !278 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #18
  ret void
}

; <f64 as core::ops::arith::Mul>::mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvXs2g_NtNtCsl10jNU3mE6R_4core3ops5arithdNtB6_3Mul3mulCsccF2givDBH6_8patterns(double %self, double %other, ptr align 8 %0) unnamed_addr #0 !guid !279 {
start:
  %_0 = fmul double %self, %other
  ret double %_0
}

; <&u32 as core::ops::arith::Mul>::mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs2t_NtNtCsl10jNU3mE6R_4core3ops5arithRmNtB6_3Mul3mulCsccF2givDBH6_8patterns(ptr align 4 %self, ptr align 4 %other, ptr align 8 %0) unnamed_addr #0 !guid !280 {
start:
  %_3 = load i32, ptr %self, align 4
  %_4 = load i32, ptr %other, align 4
; call <u32 as core::ops::arith::Mul>::mul
  %_0 = call i32 @_RNvXs25_NtNtCsl10jNU3mE6R_4core3ops5arithmNtB6_3Mul3mulCsccF2givDBH6_8patterns(i32 %_3, i32 %_4, ptr align 8 %0) #18
  ret i32 %_0
}

; <core::array::iter::IntoIter<&[i32], 4> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterRSlKj4_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !281 {
start:
; call <core::array::iter::IntoIter<&[i32], 4>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterRSlKj4_E10unsize_mutCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next
  %1 = call { ptr, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEE4nextCsccF2givDBH6_8patterns(ptr align 8 %_2.0, i64 %_2.1) #18
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::array::iter::IntoIter<i64, 7> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterxKj7_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !282 {
start:
; call <core::array::iter::IntoIter<i64, 7>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterxKj7_E10unsize_mutCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next
  %1 = call { i64, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEE4nextCsccF2givDBH6_8patterns(ptr align 8 %_2.0, i64 %_2.1) #18
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <core::ops::index_range::IndexRange as core::clone::Clone>::clone
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !283 {
start:
  %_2 = load i64, ptr %self, align 8
  %_5 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %_5, align 8
  %0 = insertvalue { i64, i64 } poison, i64 %_2, 0
  %1 = insertvalue { i64, i64 } %0, i64 %_4, 1
  ret { i64, i64 } %1
}

; <core::array::iter::IntoIter<&[i32], 4> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterRSlKj4_ENtNtNtB9_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !284 {
start:
; call core::mem::needs_drop::<&[i32]>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropRSlECsccF2givDBH6_8patterns() #18
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitRSlEj4_EE4dropCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  br label %bb3
}

; <core::array::iter::IntoIter<i64, 7> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterxKj7_ENtNtNtB9_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !285 {
start:
; call core::mem::needs_drop::<i64>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropxECsccF2givDBH6_8patterns() #18
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitxEj7_EE4dropCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  br label %bb3
}

; <&i32 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRlNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !286 {
start:
  %_3 = load ptr, ptr %self, align 8
  %_4 = load ptr, ptr %other, align 8
; call <i32 as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXss_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 4 %_3, ptr align 4 %_4) #18
  ret i1 %_0
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i32]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSlE5indexCsccF2givDBH6_8patterns(ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !287 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<patterns::Shape> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefBH_(ptr align 8 %self) unnamed_addr #0 !guid !288 {
start:
; call <alloc::vec::Vec<patterns::Shape>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE8as_sliceBG_(ptr align 8 %self) #18
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::boxed::Box<[patterns::Shape]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %self) unnamed_addr #0 !guid !289 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[patterns::Shape]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCsccF2givDBH6_8patterns5ShapeE6as_ptrBT_(ptr %ptr.0, i64 %ptr.1) #18
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[patterns::Shape]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCsccF2givDBH6_8patterns5ShapeEB17_(ptr %_5.0, i64 %_5.1) #18
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #18
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[patterns::Shape]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCsccF2givDBH6_8patterns5ShapeE4casthEBU_(ptr %ptr.0, i64 %ptr.1) #18
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #18
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsccF2givDBH6_8patterns(ptr %_10, ptr %_11, i64 %6, i64 %8) #18
  br label %bb7
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !290 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #18
  ret void
}

; <core::option::Option<(&str, i32)> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTRelEENtNtB7_3fmt5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !291 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.8)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsccF2givDBH6_8patterns() unnamed_addr #0 !guid !292 {
start:
  ret i8 0
}

; <u8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCsccF2givDBH6_8patterns(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !293 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <u32 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsW_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !294 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u32 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsu_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u32 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt(ptr align 4 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u32 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsw_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8UpperHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %0) unnamed_addr #0 !guid !295 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
; call <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_3 = call i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenB8_(ptr align 8 %self)
  %_2 = icmp ugt i64 %_3, 0
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  %1 = load ptr, ptr %self, align 8
; call <core::ops::index_range::IndexRange>::next_unchecked
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCsccF2givDBH6_8patterns(ptr align 8 %1) #18
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitRSlEj4_NtB4_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !296 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitRSlENtB2_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self, i64 4, i64 %alive.0, i64 %alive.1)
  ret void
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>; 7] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitxEj7_NtB4_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !297 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<i64>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitxENtB2_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self, i64 7, i64 %alive.0, i64 %alive.1)
  ret void
}

; <[i32; 0] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAlj0_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCsccF2givDBH6_8patterns(ptr align 4 %self, ptr align 8 %0) unnamed_addr #0 !guid !298 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i32]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSlE5indexCsccF2givDBH6_8patterns(ptr align 4 %self, i64 0, ptr align 8 %0) #18
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::non_null::NonNull<patterns::Shape> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCsccF2givDBH6_8patterns5ShapeENtNtB9_3cmp9PartialEq2eqBV_(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !299 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <&alloc::vec::Vec<patterns::Shape> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXsh_NtCs7CppTae75M1_5alloc3vecRINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12IntoIterator9into_iterBI_(ptr align 8 %self) unnamed_addr #1 !guid !300 {
start:
; call <alloc::vec::Vec<patterns::Shape> as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefBH_(ptr align 8 %self) #18
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <[patterns::Shape]>::iter
  %1 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCsccF2givDBH6_8patterns5Shape4iterBw_(ptr align 8 %_2.0, i64 %_2.1) #18
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <i32 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXso_NtCsl10jNU3mE6R_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCsccF2givDBH6_8patterns(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !301 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <i32>::from_str_radix
  %1 = call i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl14from_str_radixCsccF2givDBH6_8patterns(ptr %src.0, i64 %src.1, i32 10) #18
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <alloc::vec::Vec<patterns::Shape> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %self) unnamed_addr #1 !guid !302 {
start:
; call <alloc::vec::Vec<patterns::Shape>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE10as_mut_ptrBG_(ptr align 8 %self) #18
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut patterns::Shape>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCsccF2givDBH6_8patterns5Shape10cast_sliceBG_(ptr %_3, i64 %_4) #18
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !303 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !304 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[i32]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsddYV2PBJW9h_3std(ptr align 4 %self.0, i64 %self.1) #18
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECsccF2givDBH6_8patterns(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <i32 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXss_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 4 %self, ptr align 4 %other) unnamed_addr #0 !guid !305 {
start:
  %_3 = load i32, ptr %self, align 4
  %_4 = load i32, ptr %other, align 4
  %_0 = icmp eq i32 %_3, %_4
  ret i1 %_0
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !306 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCsccF2givDBH6_8patterns(ptr align 8 %self) #18
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsccF2givDBH6_8patterns(ptr %_1) unnamed_addr #0 !guid !307 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsccF2givDBH6_8patterns(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !308 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsccF2givDBH6_8patterns(ptr align 8 %_1) #18
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #5

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #6

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; <i16 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt(ptr align 2, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #0

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugList>::entry
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptoui.sat.i32.f64(double) #8

; <&u8 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRhNtB7_9PartialEq2eqCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #0

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #6

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #6

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<14, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #9

; <str>::split_once::<char>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core3stre10split_oncecECsddYV2PBJW9h_3std(ptr sret([32 x i8]) align 8, ptr, i64, i32) unnamed_addr #0

; <core::fmt::Arguments>::new::<17, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj2_EB8_(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8) unnamed_addr #0

; <str>::trim_matches::<<char>::is_whitespace>
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre12trim_matchesNvMNtNtB5_4char7methodsc13is_whitespaceECsddYV2PBJW9h_3std(ptr, i64) unnamed_addr #1

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #9

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr, i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32) #8

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctpop.i32(i32) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #8

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #9

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #5

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #10

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #11

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #12

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #13

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #6

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #14

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <&u32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRmNtB6_5Debug3fmtCsa0i9X4ULBdE_6memchr(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field2_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field3_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field3_finish(ptr align 8, ptr, i64, ptr, ptr align 8, ptr, ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <&&str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8, i64, i64) unnamed_addr #1

; <f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #8

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #9

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
declare void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsw_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8UpperHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsu_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8LowerHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenB8_(ptr align 8) unnamed_addr #1

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <[i32]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsddYV2PBJW9h_3std(ptr align 4, i64) unnamed_addr #0

; <core::fmt::builders::DebugList>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #15 !guid !309 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsccF2givDBH6_8patterns(ptr @_RNvCsccF2givDBH6_8patterns4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nonlazybind "target-cpu"="x86-64" }
attributes #16 = { cold }
attributes #17 = { cold noreturn nounwind }
attributes #18 = { inlinehint }
attributes #19 = { noinline }
attributes #20 = { noinline noreturn nounwind }
attributes #21 = { noinline noreturn }
attributes #22 = { inlinehint nounwind }
attributes #23 = { nounwind }
attributes #24 = { noreturn }

!llvm.module.flags = !{!89, !90, !91, !92}
!llvm.ident = !{!93}

!0 = !{i64 -6262721094808698782}
!1 = !{i64 -8805340782921766884}
!2 = !{i64 7886568547709235864}
!3 = !{i64 -6468279480826265091}
!4 = !{i64 9121876464136025571}
!5 = !{i64 7484764997931357234}
!6 = !{i64 7218324841008857063}
!7 = !{i64 -3007026107481987120}
!8 = !{i64 -4759762169721182250}
!9 = !{i64 -5834318194254009081}
!10 = !{i64 5687047111564693600}
!11 = !{i64 -1850357279236598014}
!12 = !{i64 -2883555232906572926}
!13 = !{i64 8618231762821683921}
!14 = !{i64 9164628430299145092}
!15 = !{i64 -6235189657350564055}
!16 = !{i64 -6860026304082479283}
!17 = !{i64 1461774753722121380}
!18 = !{i64 -4142083989498122273}
!19 = !{i64 6823554023627849010}
!20 = !{i64 3067291712016742664}
!21 = !{i64 -5145280544080191727}
!22 = !{i64 -5297245250663620825}
!23 = !{i64 -524052083578518475}
!24 = !{i64 -4517533185732334762}
!25 = !{i64 2346571757924430792}
!26 = !{i64 669270671394802784}
!27 = !{i64 -4372065835429744829}
!28 = !{i64 -1931124984160846851}
!29 = !{i64 -3524575504775702736}
!30 = !{i64 -4910044210816707787}
!31 = !{i64 -1033414160314169377}
!32 = !{i64 6864536026677364713}
!33 = !{i64 1395976656840326597}
!34 = !{i64 -5014113401672980513}
!35 = !{i64 3447055648860841439}
!36 = !{i64 3825761093760879348}
!37 = !{i64 -1971214899319848998}
!38 = !{i64 5518873671291265565}
!39 = !{i64 5783654722869837311}
!40 = !{i64 4915996198721720245}
!41 = !{i64 -1886564881822757678}
!42 = !{i64 -3283872301837235114}
!43 = !{i64 -3918412058119253435}
!44 = !{i64 -3441556618249294824}
!45 = !{i64 7378439491885975691}
!46 = !{i64 -1156720602752517019}
!47 = !{i64 6084871210644351702}
!48 = !{i64 6849801671324106594}
!49 = !{i64 -1637246020695066381}
!50 = !{i64 4397304550096120444}
!51 = !{i64 6239885662341721179}
!52 = !{i64 -8445162691930126513}
!53 = !{i64 3644078264335747721}
!54 = !{i64 -2701787645542375599}
!55 = !{i64 -587791641223952262}
!56 = !{i64 9123423973074146943}
!57 = !{i64 -3402418168334483027}
!58 = !{i64 1689678139659910589}
!59 = !{i64 -7689697479048273420}
!60 = !{i64 -851494618668501264}
!61 = !{i64 4105024990168731378}
!62 = !{i64 4768463758853779944}
!63 = !{i64 4031776486699737619}
!64 = !{i64 4887988543255554601}
!65 = !{i64 -8902016372263873622}
!66 = !{i64 3125254706544638577}
!67 = !{i64 8683432399661034078}
!68 = !{i64 8820334159238302197}
!69 = !{i64 -4929868154877893826}
!70 = !{i64 -856188314064534895}
!71 = !{i64 4758801360385396735}
!72 = !{i64 2736870197818956325}
!73 = !{i64 -1209345677044954000}
!74 = !{i64 1360539833336636730}
!75 = !{i64 -1517272583483569137}
!76 = !{i64 5821118664507652752}
!77 = !{i64 8913019890393471954}
!78 = !{i64 -5478335171692999155}
!79 = !{i64 7102150209877842468}
!80 = !{i64 1833623976122821461}
!81 = !{i64 7684491721068038338}
!82 = !{i64 3501869692351211717}
!83 = !{i64 -4782498452249487035}
!84 = !{i64 2585257306000500794}
!85 = !{i64 17398192384493584}
!86 = !{i64 -4620334571948798523}
!87 = !{i64 6693049113306090799}
!88 = !{i64 5363906655344728469}
!89 = !{i32 8, !"PIC Level", i32 2}
!90 = !{i32 7, !"PIE Level", i32 2}
!91 = !{i32 2, !"RtLibUseGOT", i32 1}
!92 = !{i32 7, !"uwtable", i32 2}
!93 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!94 = !{i64 -4594546653911907875}
!95 = !{i64 2638237886012278023}
!96 = !{i64 166910231268857847}
!97 = !{i64 8556505617372559308}
!98 = !{i64 1177104432047718414}
!99 = !{i64 -1023968661086896012}
!100 = !{i64 -7999927730127311670}
!101 = !{i64 -5264537119416304794}
!102 = !{i64 3982935204179999820}
!103 = !{i64 -5111436099712529925}
!104 = !{i64 3728082778730964555}
!105 = !{i64 5989716899691282808}
!106 = !{i64 -8030420040090188254}
!107 = !{i64 8522119255730195765}
!108 = !{i64 -6784712229736257331}
!109 = !{i64 -7171608707227459528}
!110 = !{i64 4119463437460071005}
!111 = !{i64 -5311545336905166542}
!112 = !{i64 8457975960613628788}
!113 = !{i64 -5811004458230701975}
!114 = !{i64 2975360613120249692}
!115 = !{i64 4870028735322986966}
!116 = !{i64 -2424505613273562298}
!117 = !{i64 2135891610690675478}
!118 = !{i64 3051749621975083303}
!119 = !{i64 -7321261562024590255}
!120 = !{i64 8663779063255165483}
!121 = !{i64 -5848713185626718389}
!122 = !{i64 8502472759966130134}
!123 = !{i64 227010135980977870}
!124 = !{i64 4829221037906939004}
!125 = !{i64 3961690979446345760}
!126 = !{i64 -5430755574356546466}
!127 = !{i64 5611322028413295324}
!128 = !{i64 -8635279086123006022}
!129 = !{i64 -3671326907365788709}
!130 = !{!"address", !"read_provenance"}
!131 = !{i64 -8599836695374404404}
!132 = !{i64 697751930151057638}
!133 = !{i64 -5507656927741594401}
!134 = !{i64 8164779747714516283}
!135 = !{i64 5790686688322137977}
!136 = !{i64 7332690832570190278}
!137 = !{i64 -8772089633914541640}
!138 = !{i64 -5822205672221035496}
!139 = !{i64 -6344740819046557790}
!140 = !{i64 3033156797966575108}
!141 = !{i64 -7218413646995262131}
!142 = !{i64 745223340311089398}
!143 = !{i64 -7859447153571747736}
!144 = !{i64 -9063739529518326030}
!145 = !{i64 7469892854345931880}
!146 = !{i64 1322278696825464}
!147 = !{i64 1123449340772644724}
!148 = !{i64 -1641383025132459772}
!149 = !{i64 6058433136200923032}
!150 = !{i64 -4373443819769075151}
!151 = !{i64 4755592832599096135}
!152 = !{i64 903081482288870363}
!153 = !{i64 4825321085010193711}
!154 = !{i64 -150047084092419566}
!155 = !{i64 -6535340622947657506}
!156 = !{i64 -1045622375004078819}
!157 = !{i64 438645251900913163}
!158 = !{i64 -3481190167918770992}
!159 = !{i64 2940996423007821384}
!160 = !{i64 8339803670071889876}
!161 = !{i64 -7375972997017903706}
!162 = !{i64 -1578637296988351842}
!163 = !{i64 -1451496061513472849}
!164 = !{i64 2436857246295079512}
!165 = !{i64 6499101211627227364}
!166 = !{i64 8496420901612192410}
!167 = !{i64 -6490812589505791383}
!168 = !{i64 5632489048402117718}
!169 = !{i64 -271281972124242410}
!170 = !{i64 2573127123679747124}
!171 = !{i64 7691791096147674761}
!172 = !{i64 -3028779714792674049}
!173 = !{i64 112659113094693716}
!174 = !{i64 -6499937879894076903}
!175 = !{i64 -8520680420740453626}
!176 = !{i64 9067663797317558752}
!177 = !{i64 -3329791424552865543}
!178 = !{i64 812764142272801396}
!179 = !{i64 -6976337826498946557}
!180 = !{i64 -5952867721635863732}
!181 = !{i64 2664328296298654914}
!182 = !{i64 -7583787637674386670}
!183 = !{i64 -1995347086088839277}
!184 = !{i64 -2823222266317871167}
!185 = !{i64 -3374635421891702861}
!186 = !{i64 1766833209679083141}
!187 = !{i64 -6411819289309696583}
!188 = !{i64 -8094240188536368037}
!189 = !{i64 2366165623768388698}
!190 = !{i64 1249644992642452961}
!191 = !{i64 1479296803414280478}
!192 = !{i64 -7678306184793771821}
!193 = !{i64 -3723792236046463040}
!194 = !{i64 6985751712804355773}
!195 = !{i64 2634819384210575716}
!196 = !{i64 -7679395093262286852}
!197 = !{i64 6611937786202877724}
!198 = !{i64 -8451234109145573672}
!199 = !{i64 -6387204024897238417}
!200 = !{i64 -4298015708576850516}
!201 = !{i64 2342488190097115467}
!202 = !{i64 -6073890161143951469}
!203 = !{i64 -7414638327406923941}
!204 = !{i64 -3783258380250823431}
!205 = !{i64 7177342550864243240}
!206 = !{i64 3058667875093318706}
!207 = !{i64 -8561894499499242876}
!208 = !{i64 4606771247399202572}
!209 = !{i64 -5704528128924231929}
!210 = !{i64 6714457086150742043}
!211 = !{i64 8087963882813926517}
!212 = !{i64 3277711929247287243}
!213 = !{i64 8806287365291460749}
!214 = !{i64 1371024632436915586}
!215 = !{i64 -797647822691776746}
!216 = !{i64 4955564052391677150}
!217 = !{i64 -5354199542626598227}
!218 = !{i64 3498043544855265899}
!219 = !{i64 2784171469358886125}
!220 = !{i64 6197577052375066269}
!221 = !{i64 5959006680123524645}
!222 = !{i64 -3256597587592278769}
!223 = !{i64 7477654269296920108}
!224 = !{i64 2024887965659262937}
!225 = !{i64 2740869610352420143}
!226 = !{i64 -5059021920225500858}
!227 = !{i64 -2698137605600943397}
!228 = !{i64 6761264708200510124}
!229 = !{i64 2137353190427739065}
!230 = !{i64 5410677080903518754}
!231 = !{i64 7096842742967677649}
!232 = !{i64 -9144620746014138353}
!233 = !{i64 -4702832870943623808}
!234 = !{i64 2855210434777070769}
!235 = !{i64 -1843856757150994800}
!236 = !{i64 3771838729372273303}
!237 = !{i64 -4821663875795067039}
!238 = !{i64 -6298104195146463661}
!239 = !{i64 -5276636945505972320}
!240 = !{i64 4461655996251952118}
!241 = !{i64 1674811998416661696}
!242 = !{i64 -628072689477338703}
!243 = !{i64 7753658280278070588}
!244 = !{i64 376071585922703195}
!245 = !{i64 2161723412954711059}
!246 = !{i64 8503299439617435259}
!247 = !{i64 -2565239886848784379}
!248 = !{i64 1230630953094842521}
!249 = !{i64 -7648155338047642826}
!250 = !{i64 4358262814787908236}
!251 = !{i64 -4457296287134730647}
!252 = !{i64 7217830902133014978}
!253 = !{i64 4446773239237404663}
!254 = !{i64 -1639590627374300344}
!255 = !{i64 -9121170507607175503}
!256 = !{i64 4187332895721996052}
!257 = !{i64 7173578036021576330}
!258 = !{i64 5791408863936251660}
!259 = !{i64 -2117733512901483641}
!260 = !{i64 3860410154314325965}
!261 = !{i64 3115761932703024659}
!262 = !{i64 828129338312106935}
!263 = !{i64 -8860175709281930526}
!264 = !{i64 -6770102001978571967}
!265 = !{i64 5316307183402575863}
!266 = !{i64 -5890334707987355762}
!267 = !{i64 -816340930145558188}
!268 = !{i64 -8137421559264276586}
!269 = !{i64 9109103644979573737}
!270 = !{i64 -4274825171370808123}
!271 = !{i64 3699621395936854869}
!272 = !{i64 -3335697713773359298}
!273 = !{i64 -1005550309496451311}
!274 = !{i64 -1866916809513651602}
!275 = !{i64 8137968807674435575}
!276 = !{i64 1552334527334105083}
!277 = !{i64 -4474272225174637298}
!278 = !{i64 -4828237256340469127}
!279 = !{i64 7369347324105632782}
!280 = !{i64 721826443693816825}
!281 = !{i64 -8444670634481272456}
!282 = !{i64 -8050045182956313053}
!283 = !{i64 1146989771707254977}
!284 = !{i64 1263722040641462041}
!285 = !{i64 -7735827744256720982}
!286 = !{i64 589343708246632518}
!287 = !{i64 4786591396763972674}
!288 = !{i64 -7061635755413374549}
!289 = !{i64 1381660469773756902}
!290 = !{i64 6069815823432387827}
!291 = !{i64 6933049767395661575}
!292 = !{i64 7371190733361385655}
!293 = !{i64 -4672945751568376874}
!294 = !{i64 995255670014008454}
!295 = !{i64 -1563527592753839808}
!296 = !{i64 -5540950590210595468}
!297 = !{i64 -3482952459954012131}
!298 = !{i64 6849304694076836085}
!299 = !{i64 -4658757027231197156}
!300 = !{i64 -1157482443644139767}
!301 = !{i64 3876578513367327106}
!302 = !{i64 -6076326059422529531}
!303 = !{i64 8783263430959052785}
!304 = !{i64 3645030924250523773}
!305 = !{i64 7265513515242548459}
!306 = !{i64 -787395054263972961}
!307 = !{i64 86038845172275448}
!308 = !{i64 5516440238115026048}
!309 = !{i64 -2624081020897602054}
