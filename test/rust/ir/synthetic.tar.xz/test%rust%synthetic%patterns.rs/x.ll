; ModuleID = 'patterns.8e266fd026c51d7e-cgu.0'
source_filename = "patterns.8e266fd026c51d7e-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%Shape = type { i8, [15 x i8] }
%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }
%"core::mem::maybe_uninit::MaybeUninit<&[i32]>" = type { [2 x i64] }

@alloc_fc8af3a837bf7fd024fc38e82315f5eb = private unnamed_addr constant [20 x i8] c"core/src/str/mod.rs\00", align 1, !guid !0
@alloc_0fd8e461c4ab8dd9366dfe0b6f984c82 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_fc8af3a837bf7fd024fc38e82315f5eb, [16 x i8] c"\13\00\00\00\00\00\00\00\C0\02\00\00\16\00\00\00" }>, align 8, !guid !1
@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !2
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !3
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !4
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !5
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !6
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsccF2givDBH6_8patterns, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsccF2givDBH6_8patterns, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsccF2givDBH6_8patterns }>, align 8, !guid !7
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !8
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !9
@alloc_723e2ae408a9572b186db8f845b20161 = private unnamed_addr constant [28 x i8] c"core/src/str/validations.rs\00", align 1, !guid !10
@alloc_4202fd0e53b2664da52f5b453f055200 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\000\00\00\00$\00\00\00" }>, align 8, !guid !11
@alloc_8f9bddbbaa03eec60f2c6205160c2a64 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\007\00\00\00(\00\00\00" }>, align 8, !guid !12
@alloc_87f411d4acc54b1b619e428c06de9910 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\00?\00\00\00,\00\00\00" }>, align 8, !guid !13
@alloc_4a25ca9930abb284a1027ea45af7a631 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\00]\00\00\00)\00\00\00" }>, align 8, !guid !14
@alloc_0d743c13f83ba8690fd970b942745aff = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\00b\00\00\00-\00\00\00" }>, align 8, !guid !15
@alloc_c3e3335a0c490d4e9e40b1812db21613 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_723e2ae408a9572b186db8f845b20161, [16 x i8] c"\1B\00\00\00\00\00\00\00g\00\00\001\00\00\00" }>, align 8, !guid !16
@alloc_d5d54240cab534dcfdfc9e1f15f834f2 = private unnamed_addr constant [19 x i8] c"alloc/src/slice.rs\00", align 1, !guid !17
@alloc_50f7a04d493c3c635bb162890af45f79 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d5d54240cab534dcfdfc9e1f15f834f2, [16 x i8] c"\12\00\00\00\00\00\00\00\C6\01\00\00$\00\00\00" }>, align 8, !guid !18
@alloc_e90bd9a80b7f188aa76a1bfb741a5999 = private unnamed_addr constant [34 x i8] c"core/src/array/iter/iter_inner.rs\00", align 1, !guid !19
@alloc_ac893681874450253b62899ecf8cf06a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\00 \00\00\00" }>, align 8, !guid !20
@alloc_b0b7c7361940ea6a8360c2bdef76bb12 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\003\00\00\00" }>, align 8, !guid !21
@alloc_16d8701a704195662253a9809cf298d1 = private unnamed_addr constant [25 x i8] c"alloc/src/raw_vec/mod.rs\00", align 1, !guid !22
@alloc_84e24ad25dfa3f90d9808e22947b437c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\85\03\00\00G\00\00\00" }>, align 8, !guid !23
@alloc_139401184e972f55d7c52277555ebf28 = private unnamed_addr constant [32 x i8] c"test/rust/synthetic/patterns.rs\00", align 1, !guid !24
@alloc_a45afb4a24ba0a5e194bc1d8435a9889 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\19\00\00\00\1E\00\00\00" }>, align 8, !guid !25
@alloc_b08f953d6f66747da394290bbf63f3b6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\19\00\00\00\1D\00\00\00" }>, align 8, !guid !26
@alloc_6d3e25798981daeb9a264231f1e928fa = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\1A\00\00\00!\00\00\00" }>, align 8, !guid !27
@alloc_5f317668025e10a890a3eea4a8bef6ff = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00'\00\00\00\12\00\00\00" }>, align 8, !guid !28
@alloc_66e0d902dc5512250b9d4edb026cbbeb = private unnamed_addr constant [4 x i8] c"\01\00\00\00", align 4, !guid !29
@alloc_5598ad317332f65891d44d57bbdb4a57 = private unnamed_addr constant [12 x i8] c"\01\00\00\00\02\00\00\00\01\00\00\00", align 4, !guid !30
@alloc_03fa889ebefc3fd61240d008cccbcd8d = private unnamed_addr constant [12 x i8] c"\01\00\00\00\02\00\00\00\03\00\00\00", align 4, !guid !31
@alloc_df7fb09215c742e668e6254030a2bddf = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00(\00\00\00\12\00\00\00" }>, align 8, !guid !32
@alloc_b1e693e8528fb8140f163b7e7dd5f4c0 = private unnamed_addr constant [5 x i8] c"a = 5", align 1, !guid !33
@alloc_89c92c491e006e6ef9402d0dec0fc54d = private unnamed_addr constant [3 x i8] c"b=x", align 1, !guid !34
@alloc_18f2f0d3d4f38df552db2352111ec81f = private unnamed_addr constant [1 x i8] c"c", align 1, !guid !35
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !36
@alloc_37f62a15fae368a2423b3a16c75adcc9 = private unnamed_addr constant [1 x i8] c"x", align 1, !guid !37
@alloc_6a96e47ef75dbf6fc4eb5423ba7bb768 = private unnamed_addr constant [16 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !38
@alloc_144b8bda8b7d019167909d944f76599d = private unnamed_addr constant [14 x i8] c"\09in range \C0\01\0A\00", align 1, !guid !39
@alloc_b8a9faf0f44a085c631f2755716883c9 = private unnamed_addr constant [5 x i8] c"none\0A", align 1, !guid !40
@alloc_0e8a8a0ff4ea56ec3d4541bf7e74cfec = private unnamed_addr constant [11 x i8] c"inner none\0A", align 1, !guid !41
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !42
@alloc_c1fa64f4e819a506b7859bc956f830ca = private unnamed_addr constant [1 x i8] c"e", align 1, !guid !43
@alloc_31a9e8f7a570396788f7b2482a3a97e4 = private unnamed_addr constant [3 x i8] c"ok\0A", align 1, !guid !44
@alloc_c0c0bd6959bacd2127c8d4fc3870a66f = private unnamed_addr constant [9 x i8] c"\04err \C0\01\0A\00", align 1, !guid !45
@alloc_3dbdd06bebcf2fb86aed3e2f16680d42 = private unnamed_addr constant [8 x i8] c"guarded\0A", align 1, !guid !46
@alloc_acd822e6332f053907a9b112a94122d3 = private unnamed_addr constant [5 x i8] c"boxed", align 1, !guid !47
@alloc_50ab75e5eb17b3d68555764b0a52038b = private unnamed_addr constant [1 x i8] c"z", align 1, !guid !48
@alloc_69ea765c2672a934a5b64287f175d158 = private unnamed_addr constant [4 x i8] c"else", align 1, !guid !49
@alloc_78d5c01af63be55c3511bacffb1a7824 = private unnamed_addr constant [5 x i8] c"digit", align 1, !guid !50
@alloc_f424f6e87101d147a136ec9aa11fa034 = private unnamed_addr constant [4 x i8] c"pow2", align 1, !guid !51
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !52
@alloc_427cf7da6bbe57bf2fdbddfa3078c1f8 = private unnamed_addr constant [4 x i8] c"zero", align 1, !guid !53
@alloc_87862e78b478b6bd0b4ea1c7b6258769 = private unnamed_addr constant [5 x i8] c"small", align 1, !guid !54
@alloc_735ff844006bb5c32021c0456ffecbea = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\0A\00\00\00\0E\00\00\00" }>, align 8, !guid !55
@alloc_7ec976a351c849ad2fc3958edc69f6f6 = private unnamed_addr constant [3 x i8] c"big", align 1, !guid !56
@alloc_f5f4cccb72aa20d03a19e99c91cbe0b2 = private unnamed_addr constant [7 x i8] c"odd-mid", align 1, !guid !57
@alloc_fbf52d5fed6793d3e790c9ce6627a01c = private unnamed_addr constant [4 x i8] c"even", align 1, !guid !58
@alloc_7aa1a11e7908cb59b04764917ce720b4 = private unnamed_addr constant [3 x i8] c"neg", align 1, !guid !59
@alloc_29912b6d8be215f231ca050c1de43b0b = private unnamed_addr constant [17 x i8] c"\06first \C0\06 rest \C0\00", align 1, !guid !60
@alloc_8f41006de9107663c983a7194b89e648 = private unnamed_addr constant [13 x i8] c"\0Asame ends \C0\00", align 1, !guid !61
@alloc_33854f2712a70d661249338f09901dcb = private unnamed_addr constant [7 x i8] c"\04one \C0\00", align 1, !guid !62
@alloc_c597b50e4e89f734c8b5ae53c406eb3f = private unnamed_addr constant [5 x i8] c"empty", align 1, !guid !63
@alloc_0cc6dc99297ba9fc0efa6643cc60563b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_139401184e972f55d7c52277555ebf28, [16 x i8] c"\1F\00\00\00\00\00\00\00\11\00\00\00\17\00\00\00" }>, align 8, !guid !64
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXs6_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_15TryFromIntErrorNtNtB9_3fmt5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !65
@alloc_988c380202cc7b7a37ca3d8d5930c44f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\AD\00\00\00\1B\00\00\00" }>, align 8, !guid !66
@alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b = private unnamed_addr constant [28 x i8] c"core/src/ops/index_range.rs\00", align 1, !guid !67
@alloc_de9a5d9a80d554992107c1ea3afec081 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b, [16 x i8] c"\1B\00\00\00\00\00\00\00?\00\00\00%\00\00\00" }>, align 8, !guid !68
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !69
@alloc_fad0cd83b7d1858a846a172eb260e593 = private unnamed_addr constant [42 x i8] c"is_aligned_to: align is not a power-of-two", align 1, !guid !70
@alloc_3a97cab01964e354cab63e4d72a95bbc = private unnamed_addr constant [26 x i8] c"core/src/ptr/const_ptr.rs\00", align 1, !guid !71
@alloc_7abc4ceda2d1d9be88f00c5dc522bc84 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3a97cab01964e354cab63e4d72a95bbc, [16 x i8] c"\19\00\00\00\00\00\00\00M\05\00\00\0D\00\00\00" }>, align 8, !guid !72
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !73
@alloc_9e5c5064a9cc4d3581a4b435ddfc6bf3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\F3\00\00\00\12\00\00\00" }>, align 8, !guid !74
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !75
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !76
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !77
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !78
@alloc_3d5b7f261101b120d30419294a27cc6f = private unnamed_addr constant [23 x i8] c"core/src/ptr/unique.rs\00", align 1, !guid !79
@alloc_8e8e5d43991787ef9fba0c8fe53b59fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3d5b7f261101b120d30419294a27cc6f, [16 x i8] c"\16\00\00\00\00\00\00\00X\00\00\00$\00\00\00" }>, align 8, !guid !80
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !81
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !82
@alloc_e469ef44bf39c45bcb672a4bc963b9cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\1A\01\00\00\1B\00\00\00" }>, align 8, !guid !83
@alloc_91bad026f8df33e69ba6aca06b3a4c87 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\AD\02\00\003\00\00\00" }>, align 8, !guid !84
@alloc_85bcb8feb56634093aba2b8644936af9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\7F\02\00\005\00\00\00" }>, align 8, !guid !85
@alloc_17de00c3327446355700bd7db4b78ded = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\80\02\00\00\1E\00\00\00" }>, align 8, !guid !86
@alloc_b9419d44288097f84422e162822ba96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\81\02\00\00 \00\00\00" }>, align 8, !guid !87
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !88
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !89
@alloc_af3623564924928dd3d563c9d84a8a0e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00s\05\00\00\12\00\00\00" }>, align 8, !guid !90
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !91
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !92
@alloc_33dfd402c6ecbe2e6a32e76edf5f31a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\D8\01\00\00L\00\00\00" }>, align 8, !guid !93
@alloc_099d793709fa470a3d5e7c79c938e035 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\C9\01\00\003\00\00\00" }>, align 8, !guid !94
@alloc_51424262946dd0794fad6132df857999 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\B7\01\00\00\15\00\00\00" }>, align 8, !guid !95
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !96
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !97
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !98
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !99
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !100
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !101
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !102
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !103
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !104
@alloc_6495769d0f8513e66380fb38255e98b4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\E3\09\00\00\0E\00\00\00" }>, align 8, !guid !105
@alloc_f20232e75b703e41d96bb787435a1dbc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\D6\09\00\00\09\00\00\00" }>, align 8, !guid !106
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !107
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !108
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !109
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !110
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !111
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !112
@alloc_6019c65badabd8e24db71db4887951df = private unnamed_addr constant [25 x i8] c"core/src/slice/memchr.rs\00", align 1, !guid !113
@alloc_a7e848337f4da91ced55996cfb643467 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6019c65badabd8e24db71db4887951df, [16 x i8] c"\18\00\00\00\00\00\00\00*\00\00\00\0C\00\00\00" }>, align 8, !guid !114
@alloc_2493455d474f4e2949ee4e1a7e153b01 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6019c65badabd8e24db71db4887951df, [16 x i8] c"\18\00\00\00\00\00\00\00\1F\00\00\00\12\00\00\00" }>, align 8, !guid !115
@_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space14WHITESPACE_MAP = external global [256 x i8]
@alloc_ba130814536b16b6d7cee6d8f200ab35 = private unnamed_addr constant [33 x i8] c"core/src/unicode/unicode_data.rs\00", align 1, !guid !116
@alloc_ee09ed5182ef49c6cba0ade2ac4a17f6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba130814536b16b6d7cee6d8f200ab35, [16 x i8] c" \00\00\00\00\00\00\00\9A\03\00\00\12\00\00\00" }>, align 8, !guid !117
@alloc_8acebf40d2a4360b5049d1b9f3d146ab = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba130814536b16b6d7cee6d8f200ab35, [16 x i8] c" \00\00\00\00\00\00\00\9C\03\00\00\13\00\00\00" }>, align 8, !guid !118
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !119
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !120
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !121
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !122
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !123
@alloc_dbcce5cb8873847766db4f16f930a00e = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: isize::unchecked_neg cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !124
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !125
@alloc_db07ae5a9ce650d9b7cc970d048e6f0c = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !126
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !127
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !128
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !129
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !130
@alloc_75fb06c2453febd814e73f5f2e72ae38 = private unnamed_addr constant [199 x i8] c"unsafe precondition(s) violated: hint::unreachable_unchecked must never be reached\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !131
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !132
@alloc_4dc07e69e5d34e9d1484dfbbef0bb9b1 = private unnamed_addr constant [174 x i8] c"unsafe precondition(s) violated: invalid value for `char`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !133
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !134
@alloc_5c1a2f972552229672fc942406cfc298 = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts_mut requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !135
@alloc_2800f9fd9aa1f3e24fde08ad5f3cf8ec = private unnamed_addr constant [71 x i8] c"\12encode_utf8: need \C0\13 bytes to encode U+\C3 \00\00i\04\00\15 but buffer has just \C0\00", align 1, !guid !136
@alloc_97d92cbf2a68a6ac45a1b13da79836e4 = private unnamed_addr constant [214 x i8] c"unsafe precondition(s) violated: slice::get_unchecked requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !137
@alloc_5a8fdd84b3281310cbf6b74bb6bf0065 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !138
@alloc_91f2a00ff2cd9cdc4bb205a66832e2bb = private unnamed_addr constant [219 x i8] c"unsafe precondition(s) violated: str::get_unchecked requires that the range is within the string slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !139
@alloc_61b2665611c43956f6751fc9541d260a = private unnamed_addr constant [6 x i8] c"Circle", align 1, !guid !140
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !141
@alloc_6319043cda67dca378296c9d6ea4e61a = private unnamed_addr constant [4 x i8] c"Rect", align 1, !guid !142
@alloc_91e924fd2a69c8524f72852661c5910c = private unnamed_addr constant [1 x i8] c"w", align 1, !guid !143
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @_RNvXsW_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !144
@alloc_d22b16ed1fc9d86532371a89eda619b7 = private unnamed_addr constant [1 x i8] c"h", align 1, !guid !145
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRmNtB6_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !146
@alloc_b786fa3e298d0013cbd9d16f11d06f34 = private unnamed_addr constant [3 x i8] c"Tri", align 1, !guid !147
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !148
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !149
@alloc_59ba7b9f7211443cd55a366616eef46a = private unnamed_addr constant [5 x i8] c"Empty", align 1, !guid !150
@alloc_c7037efb906203803aa3ca07167c9120 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\13\00\00\00\17\00\00\00" }>, align 8, !guid !151
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !152
@alloc_611ea47e56fe111765d49cc77e8ab451 = private unnamed_addr constant [32 x i8] c"char len should be less than 255", align 1, !guid !153
@alloc_bf8bcb37ff4aad042e24f7bae2d68019 = private unnamed_addr constant [24 x i8] c"core/src/str/pattern.rs\00", align 1, !guid !154
@alloc_a803cf9d531a7eab08229c1ca6c8eae5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bf8bcb37ff4aad042e24f7bae2d68019, [16 x i8] c"\17\00\00\00\00\00\00\00<\02\00\00\0E\00\00\00" }>, align 8, !guid !155
@alloc_5cb263f26a5d50117adfcc5c7225745e = private unnamed_addr constant [15 x i8] c"TryFromIntError", align 1, !guid !156
@vtable.9 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !157
@alloc_ba36178d1927b1fd4e4d55688fcb3a85 = private unnamed_addr constant [23 x i8] c"core/src/str/traits.rs\00", align 1, !guid !158
@alloc_a36baa902ac5f041bb4eed643ef44185 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba36178d1927b1fd4e4d55688fcb3a85, [16 x i8] c"\16\00\00\00\00\00\00\00\BD\01\00\00 \00\00\00" }>, align 8, !guid !159
@alloc_c2c8a36c827ccad15c06f229359033cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba36178d1927b1fd4e4d55688fcb3a85, [16 x i8] c"\16\00\00\00\00\00\00\00\03\02\00\00$\00\00\00" }>, align 8, !guid !160
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !161
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !162
@vtable.a = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRTRelENtB6_5Debug3fmtCsccF2givDBH6_8patterns }>, align 8, !guid !163
@alloc_9ecc32dce479cfcbfd7bb34b5db75f66 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bf8bcb37ff4aad042e24f7bae2d68019, [16 x i8] c"\17\00\00\00\00\00\00\00\B8\01\00\009\00\00\00" }>, align 8, !guid !164
@alloc_5e625bb2bc28691fcb622b93594e784d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bf8bcb37ff4aad042e24f7bae2d68019, [16 x i8] c"\17\00\00\00\00\00\00\00\CF\01\00\007\00\00\00" }>, align 8, !guid !165
@alloc_00315c78e51d29fe6b3102a4c1ecf6ef = private unnamed_addr constant [12 x i8] c"InvalidDigit", align 1, !guid !166
@alloc_bd3a3f3879e0d5f64554753e977f58d4 = private unnamed_addr constant [11 x i8] c"PosOverflow", align 1, !guid !167
@alloc_0964bb2a4870637395c77a018495bd5c = private unnamed_addr constant [11 x i8] c"NegOverflow", align 1, !guid !168
@alloc_6566120a3a17f930e960a0863fcbd591 = private unnamed_addr constant [4 x i8] c"Zero", align 1, !guid !169
@alloc_6c17bac0c71cba42380f8445f4dcbd16 = private unnamed_addr constant [14 x i8] c"NotAPowerOfTwo", align 1, !guid !170

; <[patterns::Shape]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCsccF2givDBH6_8patterns5Shape8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !176 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[patterns::Shape]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeE23into_raw_with_allocatorBK_(ptr align 8 %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<patterns::Shape>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[patterns::Shape]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEEB1d_(ptr align 8 %self) #20
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable
}

; <[u8]>::to_vec_in::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !177 {
start:
; call <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
  call void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #22
  ret void
}

; <str>::split_once::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre10split_oncecECsccF2givDBH6_8patterns(ptr sret([32 x i8]) align 8 %_0, ptr %self.0, i64 %self.1, i32 %delimiter) unnamed_addr #0 personality ptr @rust_eh_personality !guid !178 {
start:
  %_11 = alloca [32 x i8], align 8
  %_8 = alloca [48 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
; call <char as core::str::pattern::Pattern>::into_searcher
  call void @_RNvXs2_NtNtCsl10jNU3mE6R_4core3str7patterncNtB5_7Pattern13into_searcherCsccF2givDBH6_8patterns(ptr sret([48 x i8]) align 8 %_8, i32 %delimiter, ptr %self.0, i64 %self.1) #22
; call <core::str::pattern::CharSearcher as core::str::pattern::Searcher>::next_match
  call void @_RNvXs_NtNtCsl10jNU3mE6R_4core3str7patternNtB4_12CharSearcherNtB4_8Searcher10next_matchCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_6, ptr align 8 %_8) #22
  br label %bb2

bb2:                                              ; preds = %start
; call <core::option::Option<(usize, usize)> as core::ops::try_trait::Try>::branch
  call void @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTjjEENtNtNtB7_3ops9try_trait3Try6branchCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %_6) #22
  br label %bb3

bb3:                                              ; preds = %bb2
  %_9 = load i64, ptr %_5, align 8
  %0 = trunc nuw i64 %_9 to i1
  br i1 %0, label %bb6, label %bb5

bb6:                                              ; preds = %bb3
; call <core::option::Option<(&str, &str)> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  call void @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTReBL_EEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCsccF2givDBH6_8patterns(ptr sret([32 x i8]) align 8 %_0) #22
  br label %bb7

bb5:                                              ; preds = %bb3
  %1 = getelementptr inbounds i8, ptr %_5, i64 8
  %val.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %val.1 = load i64, ptr %2, align 8
; call <str>::get_unchecked::<core::ops::range::RangeTo<usize>>
  %3 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre13get_uncheckedINtNtNtB5_3ops5range7RangeTojEECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1, i64 %val.0) #22
  %_12.0 = extractvalue { ptr, i64 } %3, 0
  %_12.1 = extractvalue { ptr, i64 } %3, 1
; call <str>::get_unchecked::<core::ops::range::RangeFrom<usize>>
  %4 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre13get_uncheckedINtNtNtB5_3ops5range9RangeFromjEECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1, i64 %val.1) #22
  %_14.0 = extractvalue { ptr, i64 } %4, 0
  %_14.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_12.0, ptr %_11, align 8
  %5 = getelementptr inbounds i8, ptr %_11, i64 8
  store i64 %_12.1, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_11, i64 16
  store ptr %_14.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %_14.1, ptr %7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_11, i64 32, i1 false)
  br label %bb11

bb11:                                             ; preds = %bb7, %bb5
  ret void

bb7:                                              ; preds = %bb6
  br label %bb11

bb4:                                              ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable
}

; <str>::trim_matches::<<char>::is_whitespace>
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre12trim_matchesNvMNtNtB5_4char7methodsc13is_whitespaceECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !179 {
start:
  %_11 = alloca [24 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %matcher = alloca [40 x i8], align 8
  %j = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  store i64 0, ptr %i, align 8
  store i64 0, ptr %j, align 8
; call <<char>::is_whitespace as core::str::pattern::Pattern>::into_searcher
  call void @_RNvXsr_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_7Pattern13into_searcherCsccF2givDBH6_8patterns(ptr sret([40 x i8]) align 8 %matcher, ptr %self.0, i64 %self.1) #22
; call <core::str::pattern::CharPredicateSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next_reject
  call void @_RNvXso_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_21CharPredicateSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher11next_rejectCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_6, ptr align 8 %matcher) #22
  br label %bb2

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %_6, align 8
  %0 = trunc nuw i64 %_8 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %bb2
  %1 = getelementptr inbounds i8, ptr %_6, i64 8
  %a = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6, i64 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  %b = load i64, ptr %3, align 8
  store i64 %a, ptr %i, align 8
  store i64 %b, ptr %j, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
; call <core::str::pattern::CharPredicateSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_reject_back
  call void @_RNvXsp_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_21CharPredicateSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher16next_reject_backCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_11, ptr align 8 %matcher) #22
  br label %bb5

bb5:                                              ; preds = %bb4
  %_13 = load i64, ptr %_11, align 8
  %4 = trunc nuw i64 %_13 to i1
  br i1 %4, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %5 = getelementptr inbounds i8, ptr %_11, i64 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %b1 = load i64, ptr %6, align 8
  store i64 %b1, ptr %j, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5
  %_16 = load i64, ptr %i, align 8
  %_17 = load i64, ptr %j, align 8
; call <str>::get_unchecked::<core::ops::range::Range<usize>>
  %7 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre13get_uncheckedINtNtNtB5_3ops5range5RangejEECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1, i64 %_16, i64 %_17) #22
  %_0.0 = extractvalue { ptr, i64 } %7, 0
  %_0.1 = extractvalue { ptr, i64 } %7, 1
  br label %bb8

bb8:                                              ; preds = %bb7
  %8 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %_0.1, 1
  ret { ptr, i64 } %9

bb12:                                             ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <str>::get_unchecked::<core::ops::range::Range<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre13get_uncheckedINtNtNtB5_3ops5range5RangejEECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1, i64 %i.0, i64 %i.1) unnamed_addr #0 !guid !180 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
  %0 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsccF2givDBH6_8patterns(i64 %i.0, i64 %i.1, ptr %self.0, i64 %self.1, ptr align 8 @alloc_0fd8e461c4ab8dd9366dfe0b6f984c82) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_3.1, 1
  ret { ptr, i64 } %2
}

; <str>::get_unchecked::<core::ops::range::RangeTo<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre13get_uncheckedINtNtNtB5_3ops5range7RangeTojEECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1, i64 %i) unnamed_addr #0 !guid !181 {
start:
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
  %0 = call { ptr, i64 } @_RNvXs8_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range7RangeTojEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsccF2givDBH6_8patterns(i64 %i, ptr %self.0, i64 %self.1) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_3.1, 1
  ret { ptr, i64 } %2
}

; <str>::get_unchecked::<core::ops::range::RangeFrom<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre13get_uncheckedINtNtNtB5_3ops5range9RangeFromjEECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1, i64 %i) unnamed_addr #0 !guid !182 {
start:
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
  %0 = call { ptr, i64 } @_RNvXs9_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsccF2givDBH6_8patterns(i64 %i, ptr %self.0, i64 %self.1) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_3.1, 1
  ret { ptr, i64 } %2
}

; <str>::parse::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parselECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !183 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <i32 as core::str::traits::FromStr>::from_str
  %1 = call i64 @_RNvXso_NtCsl10jNU3mE6R_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) #22
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitRSlE13get_uncheckedjECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !184 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitRSlEE13get_uncheckedCsccF2givDBH6_8patterns(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #22
  ret ptr %_3
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitRSlE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !185 {
start:
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitRSlEE17get_unchecked_mutCsccF2givDBH6_8patterns(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #22
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxE13get_uncheckedjECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !186 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitxEE13get_uncheckedCsccF2givDBH6_8patterns(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #22
  ret ptr %_3
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !187 {
start:
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitxEE17get_unchecked_mutCsccF2givDBH6_8patterns(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #22
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <[u8]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSh13get_uncheckedjECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !188 {
start:
; call <usize as core::slice::index::SliceIndex<[u8]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexShE13get_uncheckedCsccF2givDBH6_8patterns(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #22
  ret ptr %_3
}

; <[u8]>::get::<core::ops::range::Range<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSh3getINtNtNtB5_3ops5range5RangejEECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1, i64 %index.0, i64 %index.1) unnamed_addr #0 !guid !189 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[u8]>>::get
  %0 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexShE3getCsccF2givDBH6_8patterns(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECsccF2givDBH6_8patterns(ptr %0) unnamed_addr #0 !guid !190 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_6, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %7 = load ptr, ptr %_0, align 8
  ret ptr %7

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1, ptr align 8 %default) unnamed_addr #0 personality ptr @rust_eh_personality !guid !191 {
start:
  %_10 = alloca [1 x i8], align 1
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_10, align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_10, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_4 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_4 to i1
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %t.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %9, align 8
  store i8 0, ptr %_9, align 1
; call <<str as alloc::borrow::ToOwned>::to_owned as core::ops::function::FnOnce<(&str,)>>::call_once
  call void @_RNvYNvYeNtNtCs7CppTae75M1_5alloc6borrow7ToOwned8to_ownedINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTReEE9call_onceCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %t.0, i64 %t.1) #22
  br label %bb15

bb2:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call alloc::fmt::format::{closure#0}
  call void @_RNCNvNtCs7CppTae75M1_5alloc3fmt6format0CsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %default) #22
  br label %bb14

bb14:                                             ; preds = %bb2
  br label %bb9

bb9:                                              ; preds = %bb15, %bb14
  %10 = load i8, ptr %_9, align 1
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %bb8, label %bb4

bb15:                                             ; preds = %bb3
  br label %bb9

bb4:                                              ; preds = %bb8, %bb9
  %12 = load i8, ptr %_10, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb10, label %bb5

bb8:                                              ; preds = %bb9
  br label %bb4

bb5:                                              ; preds = %bb10, %bb4
  ret void

bb10:                                             ; preds = %bb4
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable
}

; <core::option::Option<char>>::map::<(usize, char), <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptioncE3mapTjcENCNvXs4_NtNtB5_3str4iterNtB10_11CharIndicesNtNtNtNtB5_4iter6traits12double_ended19DoubleEndedIterator9next_back0ECsccF2givDBH6_8patterns(i32 %0, ptr align 8 %f.0, ptr align 8 %f.1) unnamed_addr #0 !guid !192 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [4 x i8], align 4
  store i32 %0, ptr %self, align 4
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load i32, ptr %self, align 4
  %2 = icmp eq i32 %1, -1
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load i32, ptr %self, align 4
  store i8 0, ptr %_8, align 1
; call <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}
  %4 = call { i64, i32 } @_RNCNvXs4_NtNtCsl10jNU3mE6R_4core3str4iterNtB7_11CharIndicesNtNtNtNtBb_4iter6traits12double_ended19DoubleEndedIterator9next_back0CsccF2givDBH6_8patterns(ptr align 8 %f.0, ptr align 8 %f.1, i32 %x) #22
  %_5.0 = extractvalue { i64, i32 } %4, 0
  %_5.1 = extractvalue { i64, i32 } %4, 1
  store i64 %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_5.1, ptr %5, align 8
  br label %bb7

bb2:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 -1, ptr %6, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %7 = load i8, ptr %_8, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %9 = load i64, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { i64, i32 } poison, i64 %9, 0
  %13 = insertvalue { i64, i32 } %12, i32 %11, 1
  ret { i64, i32 } %13

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<usize>>::map::<&[i32], <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapRSlNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBZ_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECsccF2givDBH6_8patterns(i64 %0, i64 %1, ptr align 8 %f.0, i64 %f.1) unnamed_addr #0 !guid !193 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next::{closure#0}
  %7 = call { ptr, i64 } @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitRSlEE4next0CsccF2givDBH6_8patterns(ptr align 8 %f.0, i64 %f.1, i64 %x) #22
  %_5.0 = extractvalue { ptr, i64 } %7, 0
  %_5.1 = extractvalue { ptr, i64 } %7, 1
  store ptr %_5.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %8, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %9 = load i8, ptr %_8, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<usize>>::map::<i64, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapxNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBX_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxEE4next0ECsccF2givDBH6_8patterns(i64 %0, i64 %1, ptr align 8 %f.0, i64 %f.1) unnamed_addr #0 !guid !194 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next::{closure#0}
  %_5 = call i64 @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitxEE4next0CsccF2givDBH6_8patterns(ptr align 8 %f.0, i64 %f.1, i64 %x) #22
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %7, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_8, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %10 = load i64, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  %12 = load i64, ptr %11, align 8
  %13 = insertvalue { i64, i64 } poison, i64 %10, 0
  %14 = insertvalue { i64, i64 } %13, i64 %12, 1
  ret { i64, i64 } %14

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXNtNtB5_3str4iterNtBU_5CharsNtNtNtNtB5_4iter6traits8iterator8Iterator4next0ECsccF2givDBH6_8patterns(i32 %0, i32 %1) unnamed_addr #0 !guid !195 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %self = alloca [8 x i8], align 4
  store i32 %0, ptr %self, align 4
  %2 = getelementptr inbounds i8, ptr %self, i64 4
  store i32 %1, ptr %2, align 4
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %3 = load i32, ptr %self, align 4
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  %5 = load i32, ptr %4, align 4
  %_3 = zext i32 %3 to i64
  %6 = trunc nuw i64 %_3 to i1
  br i1 %6, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 4
  %x = load i32, ptr %7, align 4
  store i8 0, ptr %_8, align 1
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}
  %_5 = call i32 @_RNCNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB4_5CharsNtNtNtNtB8_4iter6traits8iterator8Iterator4next0CsccF2givDBH6_8patterns(i32 %x) #22
  store i32 %_5, ptr %_0, align 4
  br label %bb7

bb2:                                              ; preds = %start
  store i32 -1, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_8, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %10 = load i32, ptr %_0, align 4
  ret i32 %10

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXs0_NtNtB5_3str4iterNtBX_5CharsNtNtNtNtB5_4iter6traits12double_ended19DoubleEndedIterator9next_back0ECsccF2givDBH6_8patterns(i32 %0, i32 %1) unnamed_addr #0 !guid !196 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %self = alloca [8 x i8], align 4
  store i32 %0, ptr %self, align 4
  %2 = getelementptr inbounds i8, ptr %self, i64 4
  store i32 %1, ptr %2, align 4
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %3 = load i32, ptr %self, align 4
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  %5 = load i32, ptr %4, align 4
  %_3 = zext i32 %3 to i64
  %6 = trunc nuw i64 %_3 to i1
  br i1 %6, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 4
  %x = load i32, ptr %7, align 4
  store i8 0, ptr %_8, align 1
; call <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}
  %_5 = call i32 @_RNCNvXs0_NtNtCsl10jNU3mE6R_4core3str4iterNtB7_5CharsNtNtNtNtBb_4iter6traits12double_ended19DoubleEndedIterator9next_back0CsccF2givDBH6_8patterns(i32 %x) #22
  store i32 %_5, ptr %_0, align 4
  br label %bb7

bb2:                                              ; preds = %start
  store i32 -1, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_8, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %10 = load i32, ptr %_0, align 4
  ret i32 %10

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, i64 %0, i64 %1) unnamed_addr #0 !guid !197 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load i64, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = icmp eq i64 %3, 0
  %_3 = select i1 %6, i64 1, i64 0
  %7 = trunc nuw i64 %_3 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call alloc::raw_vec::layout_array::{closure#0}
  %8 = call { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0CsccF2givDBH6_8patterns() #22
  %_6.0 = extractvalue { i64, i64 } %8, 0
  %_6.1 = extractvalue { i64, i64 } %8, 1
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %_6.1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load i64, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %t.0, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 8
  store i64 %t.1, ptr %13, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %14 = load i8, ptr %_9, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !198 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCsccF2givDBH6_8patterns, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !199 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&str>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullReE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<&str>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullReE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtReNtB6_7Display3fmtCsccF2givDBH6_8patterns, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<&i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !200 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRlE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<&i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRlE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRlNtB6_7Display3fmtCsccF2givDBH6_8patterns, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !201 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refCsccF2givDBH6_8patterns(ptr %x) #22
; call <core::ptr::non_null::NonNull<u8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !202 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<usize>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<usize>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !203 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCsccF2givDBH6_8patterns(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !204 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCsccF2givDBH6_8patterns(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<u32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !205 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i16>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsccF2givDBH6_8patterns(ptr align 2 %x) #22
; call <core::ptr::non_null::NonNull<i16>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !206 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexmECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !207 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCsccF2givDBH6_8patterns(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<u32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsw_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<(&str, i32)>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionTRelEEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !208 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<(&str, i32)>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionTRelEEE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<core::option::Option<(&str, i32)>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionTRelEEE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTRelEENtNtB7_3fmt5Debug3fmtCsccF2givDBH6_8patterns, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<&patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRNtCsccF2givDBH6_8patterns5ShapeEBY_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !209 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&patterns::Shape>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtCsccF2givDBH6_8patterns5ShapeE8from_refBW_(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<&patterns::Shape>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtCsccF2givDBH6_8patterns5ShapeE4castuEBX_(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtCsccF2givDBH6_8patterns5ShapeNtB6_5Debug3fmtBy_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<&[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !210 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&[i32]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSlE8from_refCsccF2givDBH6_8patterns(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<&[i32]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSlE4castuECsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSlNtB6_5Debug3fmtCsccF2givDBH6_8patterns, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<[patterns::Shape]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEB18_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !211 {
start:
; call core::mem::align_of_val_raw::<[patterns::Shape]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEBM_(ptr %val.0, i64 %val.1) #22
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsccF2givDBH6_8patterns(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #22
  ret i64 %_0
}

; <core::alloc::layout::Layout>::for_value_raw::<[patterns::Shape]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCsccF2givDBH6_8patterns5ShapeEB17_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !212 {
start:
; call core::mem::size_of_val_raw::<[patterns::Shape]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEBL_(ptr %val.0, i64 %val.1) #22
; call <core::mem::alignment::Alignment>::of_val_raw::<[patterns::Shape]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEB18_(ptr %val.0, i64 %val.1) #22
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsccF2givDBH6_8patterns(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #22
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<[patterns::Shape]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCsccF2givDBH6_8patterns5ShapeE4casthEBU_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !213 {
start:
; call <core::ptr::non_null::NonNull<[patterns::Shape]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE4casthEBX_(ptr %self.0, i64 %self.1) #22
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCsccF2givDBH6_8patterns5ShapeEB10_(ptr %self) unnamed_addr #0 !guid !214 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<patterns::Shape>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCsccF2givDBH6_8patterns5ShapeEB13_(ptr %self) #22
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !215 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECsccF2givDBH6_8patterns(ptr %self) #22
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<core::option::Option<(&str, i32)>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionTRelEEE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !216 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !217 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&patterns::Shape>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtCsccF2givDBH6_8patterns5ShapeE4castuEBX_(ptr %self) unnamed_addr #0 !guid !218 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&[i32]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSlE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !219 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&str>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullReE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !220 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&i32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRlE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !221 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[patterns::Shape]>>::cast::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE4castBV_EBX_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !222 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[patterns::Shape]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE4casthEBX_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !223 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !224 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[i32]>>::cast::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4castlECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !225 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<u8>>::cast::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCsccF2givDBH6_8patterns5ShapeEB13_(ptr %self) unnamed_addr #0 !guid !226 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !227 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !228 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<usize>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !229 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !230 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !231 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i16>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !232 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !233 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCsccF2givDBH6_8patterns5ShapeEBY_(ptr align 8 %self) unnamed_addr #0 !guid !234 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<patterns::Shape>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCsccF2givDBH6_8patterns5ShapeEB13_(ptr align 8 %self) #22
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::ptr::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !235 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u8>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECsccF2givDBH6_8patterns(ptr align 8 %self) #22
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCsccF2givDBH6_8patterns5ShapeEB13_(ptr align 8 %self) unnamed_addr #0 !guid !236 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<patterns::Shape>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCsccF2givDBH6_8patterns5ShapeEB10_(ptr %_3) #22
; call <core::ptr::unique::Unique<patterns::Shape>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCsccF2givDBH6_8patterns5ShapeE15as_non_null_ptrBS_(ptr %_2) #22
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::non_null::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !237 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECsccF2givDBH6_8patterns(ptr %_3) #22
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCsccF2givDBH6_8patterns(ptr %_2) #22
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<16, 5>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !238 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<17, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj2_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !239 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<71, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj47_Kj3_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !240 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !241 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<7, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj1_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !242 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !243 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<9, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj9_Kj1_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !244 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !245 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !246 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<14, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsccF2givDBH6_8patterns(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !247 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECsccF2givDBH6_8patterns(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !248 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr %entries.0, ptr %entries.1) #22
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %iter) #22
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !249
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.0)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; alloc::raw_vec::new_cap::<patterns::Shape>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCsccF2givDBH6_8patterns5ShapeEBG_(i64 %cap) unnamed_addr #1 !guid !250 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsccF2givDBH6_8patterns(i64 %cap) #22
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsccF2givDBH6_8patterns(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !251 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.1, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::mem::needs_drop::<&[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropRSlECsccF2givDBH6_8patterns() unnamed_addr #0 !guid !252 {
start:
  ret i1 false
}

; core::mem::needs_drop::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropxECsccF2givDBH6_8patterns() unnamed_addr #0 !guid !253 {
start:
  ret i1 false
}

; core::mem::size_of_val_raw::<[patterns::Shape]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEBL_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !254 {
start:
  %_0 = mul nuw nsw i64 %val.1, 16
  ret i64 %_0
}

; core::mem::align_of_val_raw::<[patterns::Shape]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCsccF2givDBH6_8patterns5ShapeEBM_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !255 {
start:
  %0 = mul nuw nsw i64 %val.1, 16
  ret i64 8
}

; core::ptr::slice_from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECsccF2givDBH6_8patterns(ptr %data, i64 %len) unnamed_addr #0 !guid !256 {
start:
; call core::ptr::metadata::from_raw_parts::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECsccF2givDBH6_8patterns(ptr %data, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCsccF2givDBH6_8patterns5ShapeEBT_(ptr %data, i64 %len) unnamed_addr #0 !guid !257 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[patterns::Shape], patterns::Shape>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCsccF2givDBH6_8patterns5ShapeBX_EBZ_(ptr %data, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECsccF2givDBH6_8patterns(ptr %data, i64 %len) unnamed_addr #0 !guid !258 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECsccF2givDBH6_8patterns(ptr %data, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !259 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECsccF2givDBH6_8patterns(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::vec::Vec<patterns::Shape>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsccF2givDBH6_8patterns5ShapeEEB1a_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !260 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<patterns::Shape> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<patterns::Shape>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsccF2givDBH6_8patterns5ShapeEEB1h_(ptr align 8 %_1) #20
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<patterns::Shape>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsccF2givDBH6_8patterns5ShapeEEB1h_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !261 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECsccF2givDBH6_8patterns(ptr align 8 %_1) #20
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECsccF2givDBH6_8patterns(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<[patterns::Shape]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEEB1d_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !262 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[patterns::Shape]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #22
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<[patterns::Shape]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #20
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb2:                                              ; preds = %bb4
  %3 = load ptr, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8
  %6 = insertvalue { ptr, i32 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i32 } %6, i32 %5, 1
  resume { ptr, i32 } %7
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<patterns::Shape>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsccF2givDBH6_8patterns5ShapeEEB1h_(ptr align 8 %_1) unnamed_addr #1 !guid !263 {
start:
; call <alloc::raw_vec::RawVec<patterns::Shape> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !264 {
start:
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<&[i32], 4>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterRSlKj4_EECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !265 {
start:
; call <core::array::iter::IntoIter<&[i32], 4> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterRSlKj4_ENtNtNtB9_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1) #22
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<i64, 7>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterxKj7_EECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !266 {
start:
; call <core::array::iter::IntoIter<i64, 7> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterxKj7_ENtNtNtB9_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1) #22
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitRSlEj4_EECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !267 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEj4_ENtNtNtBb_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1) #22
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitxEj7_EECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !268 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEj7_ENtNtNtBb_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %_1) #22
  ret void
}

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #1 !guid !269 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECsccF2givDBH6_8patterns(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<core::option::Option<core::option::Option<u8>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i8, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionIBD_hEEECsccF2givDBH6_8patterns(i8 %dummy.0, i8 %dummy.1) unnamed_addr #0 !guid !270 {
start:
  %_0 = alloca [2 x i8], align 1
  store i8 %dummy.0, ptr %_0, align 1
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %dummy.1, ptr %0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  %1 = load i8, ptr %_0, align 1
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  %3 = load i8, ptr %2, align 1
  %4 = insertvalue { i8, i8 } poison, i8 %1, 0
  %5 = insertvalue { i8, i8 } %4, i8 %3, 1
  ret { i8, i8 } %5
}

; core::hint::black_box::<core::option::Option<alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %dummy) unnamed_addr #0 !guid !272 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %dummy, i64 24, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  ret void
}

; core::hint::black_box::<core::option::Option<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECsccF2givDBH6_8patterns(i1 zeroext %dummy.0, i8 %dummy.1) unnamed_addr #0 !guid !273 {
start:
  %_0 = alloca [2 x i8], align 1
  %0 = zext i1 %dummy.0 to i8
  store i8 %0, ptr %_0, align 1
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %dummy.1, ptr %1, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  %5 = load i8, ptr %4, align 1
  %6 = insertvalue { i1, i8 } poison, i1 %3, 0
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1
  ret { i1, i8 } %7
}

; core::hint::black_box::<core::result::Result<u8, &str>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6result6ResulthReEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %dummy) unnamed_addr #0 !guid !274 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %dummy, i64 16, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  ret void
}

; core::hint::black_box::<&patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxRNtCsccF2givDBH6_8patterns5ShapeEBF_(ptr align 8 %dummy) unnamed_addr #0 !guid !275 {
start:
  %_0 = alloca [8 x i8], align 8
  store ptr %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; core::hint::black_box::<&[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxRSlECsccF2givDBH6_8patterns(ptr align 4 %dummy.0, i64 %dummy.1) unnamed_addr #0 !guid !276 {
start:
  %_0 = alloca [16 x i8], align 8
  store ptr %dummy.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %dummy.1, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  %1 = load ptr, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { ptr, i64 } poison, ptr %1, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %3, 1
  ret { ptr, i64 } %5
}

; core::hint::black_box::<(u8, (i16, &str), [i32; 3])>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxThTsReEAlj3_EECsccF2givDBH6_8patterns(ptr sret([40 x i8]) align 8 %_0, ptr align 8 %dummy) unnamed_addr #0 !guid !277 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %dummy, i64 40, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  ret void
}

; core::hint::black_box::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECsccF2givDBH6_8patterns(i1 zeroext %dummy) unnamed_addr #0 !guid !278 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = zext i1 %dummy to i8
  store i8 %0, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  %1 = load i8, ptr %_0, align 1
  %2 = trunc nuw i8 %1 to i1
  ret i1 %2
}

; core::hint::black_box::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxcECsccF2givDBH6_8patterns(i32 %dummy) unnamed_addr #0 !guid !279 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsccF2givDBH6_8patterns(i32 %dummy) unnamed_addr #0 !guid !280 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsccF2givDBH6_8patterns() unnamed_addr #0 !guid !281 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !271
  ret void
}

; core::hint::black_box::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECsccF2givDBH6_8patterns(i64 %dummy) unnamed_addr #0 !guid !282 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !271
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsccF2givDBH6_8patterns(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !283 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsccF2givDBH6_8patterns(ptr %f) #22
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsccF2givDBH6_8patterns() #22
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECsccF2givDBH6_8patterns(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !284 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[patterns::Shape], patterns::Shape>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCsccF2givDBH6_8patterns5ShapeBX_EBZ_(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !285 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECsccF2givDBH6_8patterns(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !286 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitRSlEECsccF2givDBH6_8patterns(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !287 {
start:
  ret i64 %ptr.1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<i64>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitxEECsccF2givDBH6_8patterns(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !288 {
start:
  ret i64 %ptr.1
}

; core::ptr::metadata::metadata::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECsccF2givDBH6_8patterns(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !289 {
start:
  ret i64 %ptr.1
}

; core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECsccF2givDBH6_8patterns(ptr align 8 %bytes) unnamed_addr #0 !guid !290 {
start:
  %ch = alloca [4 x i8], align 4
  %_3 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
  %_4 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %bytes) #22
; call <core::option::Option<&u8> as core::ops::try_trait::Try>::branch
  %0 = call ptr @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRhENtNtNtB7_3ops9try_trait3Try6branchCsccF2givDBH6_8patterns(ptr %_4) #22
  store ptr %0, ptr %_3, align 8
  %1 = load ptr, ptr %_3, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_5 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_5 to i1
  br i1 %4, label %bb5, label %bb4

bb5:                                              ; preds = %start
; call <core::option::Option<u32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  %5 = call { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCsccF2givDBH6_8patterns() #22
  %6 = extractvalue { i32, i32 } %5, 0
  %7 = extractvalue { i32, i32 } %5, 1
  store i32 %6, ptr %_0, align 4
  %8 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %7, ptr %8, align 4
  br label %bb21

bb4:                                              ; preds = %start
  %val = load ptr, ptr %_3, align 8
  %x = load i8, ptr %val, align 1
  %_7 = icmp ult i8 %x, -128
  br i1 %_7, label %bb6, label %bb7

bb7:                                              ; preds = %bb4
; call core::str::validations::utf8_first_byte
  %init = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCsccF2givDBH6_8patterns(i8 %x, i32 2) #22
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
  %_12 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %bytes) #22
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_11 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCsccF2givDBH6_8patterns(ptr %_12, ptr align 8 @alloc_4202fd0e53b2664da52f5b453f055200) #22
  %y = load i8, ptr %_11, align 1
; call core::str::validations::utf8_acc_cont_byte
  %9 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCsccF2givDBH6_8patterns(i32 %init, i8 %y) #22
  store i32 %9, ptr %ch, align 4
  %_14 = icmp uge i8 %x, -32
  br i1 %_14, label %bb12, label %bb20

bb6:                                              ; preds = %bb4
  %_8 = zext i8 %x to i32
  %10 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_8, ptr %10, align 4
  store i32 1, ptr %_0, align 4
  br label %bb21

bb20:                                             ; preds = %bb16, %bb12, %bb7
  %_29 = load i32, ptr %ch, align 4
  %11 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_29, ptr %11, align 4
  store i32 1, ptr %_0, align 4
  br label %bb21

bb12:                                             ; preds = %bb7
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
  %_17 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %bytes) #22
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_16 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCsccF2givDBH6_8patterns(ptr %_17, ptr align 8 @alloc_8f9bddbbaa03eec60f2c6205160c2a64) #22
  %z = load i8, ptr %_16, align 1
  %_20 = and i8 %y, 63
  %_19 = zext i8 %_20 to i32
; call core::str::validations::utf8_acc_cont_byte
  %y_z = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCsccF2givDBH6_8patterns(i32 %_19, i8 %z) #22
  %_21 = shl i32 %init, 12
  %12 = or i32 %_21, %y_z
  store i32 %12, ptr %ch, align 4
  %_22 = icmp uge i8 %x, -16
  br i1 %_22, label %bb16, label %bb20

bb16:                                             ; preds = %bb12
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
  %_25 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %bytes) #22
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_24 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCsccF2givDBH6_8patterns(ptr %_25, ptr align 8 @alloc_87f411d4acc54b1b619e428c06de9910) #22
  %w = load i8, ptr %_24, align 1
  %_27 = and i32 %init, 7
  %_26 = shl i32 %_27, 18
; call core::str::validations::utf8_acc_cont_byte
  %_28 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCsccF2givDBH6_8patterns(i32 %y_z, i8 %w) #22
  %13 = or i32 %_26, %_28
  store i32 %13, ptr %ch, align 4
  br label %bb20

bb21:                                             ; preds = %bb5, %bb6, %bb20
  %14 = load i32, ptr %_0, align 4
  %15 = getelementptr inbounds i8, ptr %_0, i64 4
  %16 = load i32, ptr %15, align 4
  %17 = insertvalue { i32, i32 } poison, i32 %14, 0
  %18 = insertvalue { i32, i32 } %17, i32 %16, 1
  ret { i32, i32 } %18

bb3:                                              ; No predecessors!
  unreachable
}

; core::str::validations::next_code_point_reverse::<core::slice::iter::Iter<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECsccF2givDBH6_8patterns(ptr align 8 %bytes) unnamed_addr #0 !guid !291 {
start:
  %ch = alloca [4 x i8], align 4
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_3 = call ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCsccF2givDBH6_8patterns(ptr align 8 %bytes) #22
; call <core::option::Option<&u8> as core::ops::try_trait::Try>::branch
  %0 = call ptr @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRhENtNtNtB7_3ops9try_trait3Try6branchCsccF2givDBH6_8patterns(ptr %_3) #22
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_4 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb5, label %bb4

bb5:                                              ; preds = %start
; call <core::option::Option<u32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  %5 = call { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCsccF2givDBH6_8patterns() #22
  %6 = extractvalue { i32, i32 } %5, 0
  %7 = extractvalue { i32, i32 } %5, 1
  store i32 %6, ptr %_0, align 4
  %8 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %7, ptr %8, align 4
  br label %bb26

bb4:                                              ; preds = %start
  %val = load ptr, ptr %_2, align 8
  %_8 = load i8, ptr %val, align 1
  %_7 = icmp ult i8 %_8, -128
  br i1 %_7, label %bb6, label %bb7

bb7:                                              ; preds = %bb4
  %w = load i8, ptr %val, align 1
; call <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_14 = call ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCsccF2givDBH6_8patterns(ptr align 8 %bytes) #22
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_13 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCsccF2givDBH6_8patterns(ptr %_14, ptr align 8 @alloc_4a25ca9930abb284a1027ea45af7a631) #22
  %z = load i8, ptr %_13, align 1
; call core::str::validations::utf8_first_byte
  %_15 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCsccF2givDBH6_8patterns(i8 %z, i32 2) #22
  store i32 %_15, ptr %ch, align 4
; call core::str::validations::utf8_is_cont_byte
  %_16 = call zeroext i1 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations17utf8_is_cont_byteCsccF2givDBH6_8patterns(i8 %z) #22
  br i1 %_16, label %bb12, label %bb24

bb6:                                              ; preds = %bb4
  %next_byte = load i8, ptr %val, align 1
  %_9 = zext i8 %next_byte to i32
  %9 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_9, ptr %9, align 4
  store i32 1, ptr %_0, align 4
  br label %bb26

bb24:                                             ; preds = %bb22, %bb7
  %_31 = load i32, ptr %ch, align 4
; call core::str::validations::utf8_acc_cont_byte
  %_30 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCsccF2givDBH6_8patterns(i32 %_31, i8 %w) #22
  store i32 %_30, ptr %ch, align 4
  %_32 = load i32, ptr %ch, align 4
  %10 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_32, ptr %10, align 4
  store i32 1, ptr %_0, align 4
  br label %bb26

bb12:                                             ; preds = %bb7
; call <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_19 = call ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCsccF2givDBH6_8patterns(ptr align 8 %bytes) #22
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_18 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCsccF2givDBH6_8patterns(ptr %_19, ptr align 8 @alloc_0d743c13f83ba8690fd970b942745aff) #22
  %y = load i8, ptr %_18, align 1
; call core::str::validations::utf8_first_byte
  %_20 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCsccF2givDBH6_8patterns(i8 %y, i32 3) #22
  store i32 %_20, ptr %ch, align 4
; call core::str::validations::utf8_is_cont_byte
  %_21 = call zeroext i1 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations17utf8_is_cont_byteCsccF2givDBH6_8patterns(i8 %y) #22
  br i1 %_21, label %bb17, label %bb22

bb22:                                             ; preds = %bb17, %bb12
  %_29 = load i32, ptr %ch, align 4
; call core::str::validations::utf8_acc_cont_byte
  %_28 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCsccF2givDBH6_8patterns(i32 %_29, i8 %z) #22
  store i32 %_28, ptr %ch, align 4
  br label %bb24

bb17:                                             ; preds = %bb12
; call <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_24 = call ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCsccF2givDBH6_8patterns(ptr align 8 %bytes) #22
; call <core::option::Option<&u8>>::unwrap_unchecked
  %_23 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCsccF2givDBH6_8patterns(ptr %_24, ptr align 8 @alloc_c3e3335a0c490d4e9e40b1812db21613) #22
  %x = load i8, ptr %_23, align 1
; call core::str::validations::utf8_first_byte
  %_25 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCsccF2givDBH6_8patterns(i8 %x, i32 4) #22
  store i32 %_25, ptr %ch, align 4
  %_27 = load i32, ptr %ch, align 4
; call core::str::validations::utf8_acc_cont_byte
  %_26 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCsccF2givDBH6_8patterns(i32 %_27, i8 %y) #22
  store i32 %_26, ptr %ch, align 4
  br label %bb22

bb26:                                             ; preds = %bb5, %bb6, %bb24
  %11 = load i32, ptr %_0, align 4
  %12 = getelementptr inbounds i8, ptr %_0, i64 4
  %13 = load i32, ptr %12, align 4
  %14 = insertvalue { i32, i32 } poison, i32 %11, 0
  %15 = insertvalue { i32, i32 } %14, i32 %13, 1
  ret { i32, i32 } %15

bb3:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECsccF2givDBH6_8patterns(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !292 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECsccF2givDBH6_8patterns(ptr %data, i64 %len) #22
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCsccF2givDBH6_8patterns(ptr %data, i64 1, i64 1, i64 %len, ptr align 8 %0) #23
  br label %bb5
}

; core::slice::raw::from_raw_parts_mut::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_muthECsccF2givDBH6_8patterns(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !293 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts_mut::<u8>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECsccF2givDBH6_8patterns(ptr %data, i64 %len) #22
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts_mut::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCsccF2givDBH6_8patterns(ptr %data, i64 1, i64 1, i64 %len, ptr align 8 %0) #23
  br label %bb5
}

; <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !294 {
start:
  %0 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %v = alloca [24 x i8], align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  store i8 0, ptr %_13, align 1
; call <alloc::vec::Vec<u8>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %v, i64 %s.1) #22
  br label %bb1

bb1:                                              ; preds = %start
  %_6 = icmp ugt i64 %s.1, 0
  br i1 %_6, label %bb2, label %bb6

bb6:                                              ; preds = %bb11, %bb1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %v, i64 24, i1 false)
  ret void

bb2:                                              ; preds = %bb1
  br label %bb3

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECsccF2givDBH6_8patterns(ptr align 8 %v) #20
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4, %bb5, %bb3
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
; invoke <alloc::vec::Vec<u8>>::as_mut_ptr
  %_9 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCsccF2givDBH6_8patterns(ptr align 8 %v)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke core::ub_checks::check_language_ub
  %_4.i.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
          to label %_4.i.i.noexc unwind label %cleanup

_4.i.i.noexc:                                     ; preds = %bb4
  br i1 %_4.i.i1, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCsccF2givDBH6_8patterns.exit

bb2.i.i:                                          ; preds = %_4.i.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCsccF2givDBH6_8patterns(ptr %s.0, ptr %_9, i64 1, i64 1, i64 %s.1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #23
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCsccF2givDBH6_8patterns.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCsccF2givDBH6_8patterns.exit: ; preds = %_4.i.i.noexc, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_9, ptr align 1 %s.0, i64 %s.1, i1 false)
  br label %bb5

bb5:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCsccF2givDBH6_8patterns.exit
; invoke <alloc::vec::Vec<u8>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCsccF2givDBH6_8patterns(ptr align 8 %v, i64 %s.1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb5
  br label %bb6

terminate:                                        ; preds = %bb7
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb10:                                             ; preds = %bb7
  %6 = load i8, ptr %_13, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb9, label %bb8

bb8:                                              ; preds = %bb9, %bb10
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb9:                                              ; preds = %bb10
  br label %bb8
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsccF2givDBH6_8patterns(ptr align 8 %_1) unnamed_addr #0 !guid !295 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsccF2givDBH6_8patterns(ptr %_4) #24
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsccF2givDBH6_8patterns() #22
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsccF2givDBH6_8patterns(i8 %_2) #22
  ret i32 %_0
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitRSlEE4next0CsccF2givDBH6_8patterns(ptr align 8 %_1.0, i64 %_1.1, i64 %idx) unnamed_addr #0 !guid !296 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::get_unchecked::<usize>
  %_3 = call align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitRSlE13get_uncheckedjECsccF2givDBH6_8patterns(ptr align 8 %_1.0, i64 %_1.1, i64 %idx, ptr align 8 @alloc_ac893681874450253b62899ecf8cf06a) #22
  %_0.0.i.i.i = load ptr, ptr %_3, align 8
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %_0.1.i.i.i = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1.i.i.i, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1.i.i.i, 1
  %5 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_0.1.i.i.i, 1
  %_0.0 = extractvalue { ptr, i64 } %6, 0
  %_0.1 = extractvalue { ptr, i64 } %6, 1
  %7 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %_0.1, 1
  ret { ptr, i64 } %8
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitxEE4next0CsccF2givDBH6_8patterns(ptr align 8 %_1.0, i64 %_1.1, i64 %idx) unnamed_addr #0 !guid !297 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<i64>]>::get_unchecked::<usize>
  %_3 = call align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxE13get_uncheckedjECsccF2givDBH6_8patterns(ptr align 8 %_1.0, i64 %_1.1, i64 %idx, ptr align 8 @alloc_ac893681874450253b62899ecf8cf06a) #22
  %_0.i.i.i = load i64, ptr %_3, align 8
  ret i64 %_0.i.i.i
}

; alloc::fmt::format::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvNtCs7CppTae75M1_5alloc3fmt6format0CsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_1) unnamed_addr #0 !guid !298 {
start:
  %_2.0 = load ptr, ptr %_1, align 8
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_2.1 = load ptr, ptr %0, align 8
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCs7CppTae75M1_5alloc3fmt6format12format_inner(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, ptr %_2.1)
  ret void
}

; alloc::raw_vec::layout_array::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0CsccF2givDBH6_8patterns() unnamed_addr #0 !guid !299 {
start:
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %0 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCsccF2givDBH6_8patterns(i64 0, i64 undef, ptr align 8 @alloc_84e24ad25dfa3f90d9808e22947b437c) #22
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB4_5CharsNtNtNtNtB8_4iter6traits8iterator8Iterator4next0CsccF2givDBH6_8patterns(i32 %ch) unnamed_addr #0 !guid !300 {
start:
; call <char>::from_u32_unchecked
  %_0 = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc18from_u32_uncheckedCsccF2givDBH6_8patterns(i32 %ch) #22
  ret i32 %_0
}

; <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvXs0_NtNtCsl10jNU3mE6R_4core3str4iterNtB7_5CharsNtNtNtNtBb_4iter6traits12double_ended19DoubleEndedIterator9next_back0CsccF2givDBH6_8patterns(i32 %ch) unnamed_addr #0 !guid !301 {
start:
; call <char>::from_u32_unchecked
  %_0 = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc18from_u32_uncheckedCsccF2givDBH6_8patterns(i32 %ch) #22
  ret i32 %_0
}

; <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RNCNvXs4_NtNtCsl10jNU3mE6R_4core3str4iterNtB7_11CharIndicesNtNtNtNtBb_4iter6traits12double_ended19DoubleEndedIterator9next_back0CsccF2givDBH6_8patterns(ptr align 8 %_1.0, ptr align 8 %_1.1, i32 %ch) unnamed_addr #0 !guid !302 {
start:
  %_0.i = alloca [8 x i8], align 8
  %_4 = load i64, ptr %_1.0, align 8
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 8
  %_5.i = load ptr, ptr %0, align 8
  %_6.i = load ptr, ptr %_1.1, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %_5.i, ptr %_6.i) #22
  store i64 %1, ptr %_0.i, align 8
  %2 = load i64, ptr %_0.i, align 8
  %index = add i64 %_4, %2
  %3 = insertvalue { i64, i32 } poison, i64 %index, 0
  %4 = insertvalue { i64, i32 } %3, i32 %ch, 1
  ret { i64, i32 } %4
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsccF2givDBH6_8patterns(ptr %_1) unnamed_addr #0 !guid !303 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsccF2givDBH6_8patterns(ptr %0) #22
  ret i32 %_0
}

; patterns::area
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCsccF2givDBH6_8patterns4area(ptr align 8 %s) unnamed_addr #1 !guid !304 {
start:
  %c = alloca [8 x i8], align 8
  %b = alloca [8 x i8], align 8
  %a = alloca [8 x i8], align 8
  %_0 = alloca [4 x i8], align 4
  %0 = load i8, ptr %s, align 8
  %_2 = zext i8 %0 to i64
  switch i64 %_2, label %bb1 [
    i64 0, label %bb5
    i64 1, label %bb4
    i64 2, label %bb3
    i64 3, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb5:                                              ; preds = %start
  %r = getelementptr inbounds i8, ptr %s, i64 8
; call <f64 as core::ops::arith::Mul<&f64>>::mul
  %_5 = call double @_RNvXs2Z_NtNtCsl10jNU3mE6R_4core3ops5arithdINtB6_3MulRdE3mulCsccF2givDBH6_8patterns(double 3.140000e+00, ptr align 8 %r, ptr align 8 @alloc_a45afb4a24ba0a5e194bc1d8435a9889) #22
; call <f64 as core::ops::arith::Mul<&f64>>::mul
  %_4 = call double @_RNvXs2Z_NtNtCsl10jNU3mE6R_4core3ops5arithdINtB6_3MulRdE3mulCsccF2givDBH6_8patterns(double %_5, ptr align 8 %r, ptr align 8 @alloc_b08f953d6f66747da394290bbf63f3b6) #22
  %1 = call i32 @llvm.fptoui.sat.i32.f64(double %_4)
  store i32 %1, ptr %_0, align 4
  br label %bb13

bb4:                                              ; preds = %start
  %w = getelementptr inbounds i8, ptr %s, i64 4
  %h = getelementptr inbounds i8, ptr %s, i64 8
; call <&u32 as core::ops::arith::Mul>::mul
  %2 = call i32 @_RNvXs2t_NtNtCsl10jNU3mE6R_4core3ops5arithRmNtB6_3Mul3mulCsccF2givDBH6_8patterns(ptr align 4 %w, ptr align 4 %h, ptr align 8 @alloc_6d3e25798981daeb9a264231f1e928fa) #22
  store i32 %2, ptr %_0, align 4
  br label %bb13

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %s, i64 1
  store ptr %3, ptr %a, align 8
  %4 = getelementptr inbounds i8, ptr %s, i64 2
  store ptr %4, ptr %b, align 8
  %5 = getelementptr inbounds i8, ptr %s, i64 3
  store ptr %5, ptr %c, align 8
; call <&u8 as core::cmp::PartialEq>::eq
  %_14 = call zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRhNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %a, ptr align 8 %b) #22
  br i1 %_14, label %bb9, label %bb12

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb13

bb13:                                             ; preds = %bb2, %bb11, %bb12, %bb4, %bb5
  %6 = load i32, ptr %_0, align 4
  ret i32 %6

bb12:                                             ; preds = %bb9, %bb3
  %a1 = getelementptr inbounds i8, ptr %s, i64 1
  %_17 = load i8, ptr %a1, align 1
  %7 = zext i8 %_17 to i32
  store i32 %7, ptr %_0, align 4
  br label %bb13

bb9:                                              ; preds = %bb3
; call <&u8 as core::cmp::PartialEq>::eq
  %_15 = call zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRhNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %b, ptr align 8 %c) #22
  br i1 %_15, label %bb11, label %bb12

bb11:                                             ; preds = %bb9
  store i32 1, ptr %_0, align 4
  br label %bb13
}

; patterns::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsccF2givDBH6_8patterns4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !305 {
start:
  %0 = alloca [16 x i8], align 8
  %_206 = alloca [16 x i8], align 8
  %args17 = alloca [16 x i8], align 8
  %y = alloca [16 x i8], align 8
  %x16 = alloca [4 x i8], align 4
  %_191 = alloca [16 x i8], align 8
  %args15 = alloca [16 x i8], align 8
  %_189 = alloca [8 x i8], align 8
  %_182 = alloca [24 x i8], align 8
  %_181 = alloca [24 x i8], align 8
  %_180 = alloca [24 x i8], align 8
  %_176 = alloca [16 x i8], align 8
  %args14 = alloca [16 x i8], align 8
  %_170 = alloca [4 x i8], align 4
  %_162 = alloca [16 x i8], align 8
  %args13 = alloca [16 x i8], align 8
  %e12 = alloca [16 x i8], align 8
  %_147 = alloca [16 x i8], align 8
  %r = alloca [16 x i8], align 8
  %_139 = alloca [16 x i8], align 8
  %args11 = alloca [16 x i8], align 8
  %x = alloca [1 x i8], align 1
  %opt = alloca [2 x i8], align 1
  %_125 = alloca [16 x i8], align 8
  %args10 = alloca [16 x i8], align 8
  %n9 = alloca [1 x i8], align 1
  %msg = alloca [2 x i8], align 1
  %_111 = alloca [16 x i8], align 8
  %_110 = alloca [16 x i8], align 8
  %_109 = alloca [16 x i8], align 8
  %_108 = alloca [16 x i8], align 8
  %_107 = alloca [16 x i8], align 8
  %args8 = alloca [80 x i8], align 8
  %args7 = alloca [40 x i8], align 8
  %e = alloca [4 x i8], align 4
  %d = alloca [4 x i8], align 4
  %c = alloca [16 x i8], align 8
  %b = alloca [2 x i8], align 2
  %a = alloca [1 x i8], align 1
  %_92 = alloca [12 x i8], align 4
  %_91 = alloca [24 x i8], align 8
  %_90 = alloca [40 x i8], align 8
  %t = alloca [40 x i8], align 8
  %_86 = alloca [16 x i8], align 8
  %_85 = alloca [16 x i8], align 8
  %_84 = alloca [16 x i8], align 8
  %args6 = alloca [48 x i8], align 8
  %_81 = alloca [24 x i8], align 8
  %_78 = alloca [24 x i8], align 8
  %_75 = alloca [24 x i8], align 8
  %args5 = alloca [24 x i8], align 8
  %_68 = alloca [16 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_64 = alloca [4 x i8], align 4
  %s = alloca [8 x i8], align 8
  %_55 = alloca [8 x i8], align 8
  %iter3 = alloca [16 x i8], align 8
  %_51 = alloca [16 x i8], align 8
  %_50 = alloca [16 x i8], align 8
  %_49 = alloca [16 x i8], align 8
  %_48 = alloca [16 x i8], align 8
  %_47 = alloca [16 x i8], align 8
  %shapes = alloca [24 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args2 = alloca [16 x i8], align 8
  %_39 = alloca [24 x i8], align 8
  %_31 = alloca [16 x i8], align 8
  %iter1 = alloca [80 x i8], align 8
  %_21 = alloca [64 x i8], align 8
  %_20 = alloca [80 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_13 = alloca [16 x i8], align 8
  %n = alloca [8 x i8], align 8
  %_4 = alloca [16 x i8], align 8
  %iter = alloca [72 x i8], align 8
  %_2 = alloca [56 x i8], align 8
  %_1 = alloca [72 x i8], align 8
  %1 = getelementptr inbounds nuw i64, ptr %_2, i64 0
  store i64 -5, ptr %1, align 8
  %2 = getelementptr inbounds nuw i64, ptr %_2, i64 1
  store i64 0, ptr %2, align 8
  %3 = getelementptr inbounds nuw i64, ptr %_2, i64 2
  store i64 2, ptr %3, align 8
  %4 = getelementptr inbounds nuw i64, ptr %_2, i64 3
  store i64 4, ptr %4, align 8
  %5 = getelementptr inbounds nuw i64, ptr %_2, i64 4
  store i64 7, ptr %5, align 8
  %6 = getelementptr inbounds nuw i64, ptr %_2, i64 5
  store i64 50, ptr %6, align 8
  %7 = getelementptr inbounds nuw i64, ptr %_2, i64 6
  store i64 1000, ptr %7, align 8
; call <[i64; 7] as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAxj7_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_1, ptr align 8 %_2) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter, ptr align 8 %_1, i64 72, i1 false)
  br label %bb2

bb2:                                              ; preds = %bb124, %start
; invoke <core::array::iter::IntoIter<i64, 7> as core::iter::traits::iterator::Iterator>::next
  %8 = invoke { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterxKj7_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %iter)
          to label %bb3 unwind label %cleanup

bb120:                                            ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<i64, 7>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterxKj7_EECsccF2givDBH6_8patterns(ptr align 8 %iter) #20
          to label %bb121 unwind label %terminate

cleanup:                                          ; preds = %bb11, %bb10, %bb9, %bb8, %bb7, %bb5, %bb2
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb120

bb3:                                              ; preds = %bb2
  %13 = extractvalue { i64, i64 } %8, 0
  %14 = extractvalue { i64, i64 } %8, 1
  store i64 %13, ptr %_4, align 8
  %15 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %14, ptr %15, align 8
  %_6 = load i64, ptr %_4, align 8
  %16 = getelementptr inbounds i8, ptr %_4, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = trunc nuw i64 %_6 to i1
  br i1 %18, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %19 = getelementptr inbounds i8, ptr %_4, i64 8
  %20 = load i64, ptr %19, align 8
  store i64 %20, ptr %n, align 8
  %21 = load i64, ptr %n, align 8
; invoke core::hint::black_box::<i64>
  %_14 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECsccF2givDBH6_8patterns(i64 %21)
          to label %bb7 unwind label %cleanup

bb6:                                              ; preds = %bb3
; call core::ptr::drop_glue::<core::array::iter::IntoIter<i64, 7>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterxKj7_EECsccF2givDBH6_8patterns(ptr align 8 %iter)
; call <[i32; 0] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %22 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAlj0_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCsccF2givDBH6_8patterns(ptr align 4 inttoptr (i64 4 to ptr), ptr align 8 @alloc_5f317668025e10a890a3eea4a8bef6ff) #22
  %_22.0 = extractvalue { ptr, i64 } %22, 0
  %_22.1 = extractvalue { ptr, i64 } %22, 1
  %23 = getelementptr inbounds nuw { ptr, i64 }, ptr %_21, i64 0
  store ptr %_22.0, ptr %23, align 8
  %24 = getelementptr inbounds i8, ptr %23, i64 8
  store i64 %_22.1, ptr %24, align 8
  %25 = getelementptr inbounds nuw { ptr, i64 }, ptr %_21, i64 1
  store ptr @alloc_66e0d902dc5512250b9d4edb026cbbeb, ptr %25, align 8
  %26 = getelementptr inbounds i8, ptr %25, i64 8
  store i64 1, ptr %26, align 8
  %27 = getelementptr inbounds nuw { ptr, i64 }, ptr %_21, i64 2
  store ptr @alloc_5598ad317332f65891d44d57bbdb4a57, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 3, ptr %28, align 8
  %29 = getelementptr inbounds nuw { ptr, i64 }, ptr %_21, i64 3
  store ptr @alloc_03fa889ebefc3fd61240d008cccbcd8d, ptr %29, align 8
  %30 = getelementptr inbounds i8, ptr %29, i64 8
  store i64 3, ptr %30, align 8
; call <[&[i32]; 4] as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARSlj4_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_20, ptr align 8 %_21) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter1, ptr align 8 %_20, i64 80, i1 false)
  br label %bb15

bb15:                                             ; preds = %bb23, %bb6
; invoke <core::array::iter::IntoIter<&[i32], 4> as core::iter::traits::iterator::Iterator>::next
  %31 = invoke { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterRSlKj4_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %iter1)
          to label %bb16 unwind label %cleanup18

bb119:                                            ; preds = %bb118, %cleanup18
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<&[i32], 4>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterRSlKj4_EECsccF2givDBH6_8patterns(ptr align 8 %iter1) #20
          to label %bb121 unwind label %terminate

cleanup18:                                        ; preds = %bb23, %bb19, %bb17, %bb15
  %32 = landingpad { ptr, i32 }
          cleanup
  %33 = extractvalue { ptr, i32 } %32, 0
  %34 = extractvalue { ptr, i32 } %32, 1
  store ptr %33, ptr %0, align 8
  %35 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %34, ptr %35, align 8
  br label %bb119

bb16:                                             ; preds = %bb15
  %36 = extractvalue { ptr, i64 } %31, 0
  %37 = extractvalue { ptr, i64 } %31, 1
  store ptr %36, ptr %_31, align 8
  %38 = getelementptr inbounds i8, ptr %_31, i64 8
  store i64 %37, ptr %38, align 8
  %39 = load ptr, ptr %_31, align 8
  %40 = getelementptr inbounds i8, ptr %_31, i64 8
  %41 = load i64, ptr %40, align 8
  %42 = ptrtoint ptr %39 to i64
  %43 = icmp eq i64 %42, 0
  %_33 = select i1 %43, i64 0, i64 1
  %44 = trunc nuw i64 %_33 to i1
  br i1 %44, label %bb17, label %bb18

bb17:                                             ; preds = %bb16
  %v.0 = load ptr, ptr %_31, align 8
  %45 = getelementptr inbounds i8, ptr %_31, i64 8
  %v.1 = load i64, ptr %45, align 8
; invoke core::hint::black_box::<&[i32]>
  %46 = invoke { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxRSlECsccF2givDBH6_8patterns(ptr align 4 %v.0, i64 %v.1)
          to label %bb19 unwind label %cleanup18

bb18:                                             ; preds = %bb16
; call core::ptr::drop_glue::<core::array::iter::IntoIter<&[i32], 4>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterRSlKj4_EECsccF2givDBH6_8patterns(ptr align 8 %iter1)
; call alloc::boxed::box_new_uninit
  %_1.i = call align 8 ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsccF2givDBH6_8patterns(i64 8, i64 80) #22
  %47 = getelementptr inbounds i8, ptr %_47, i64 8
  store double 2.000000e+00, ptr %47, align 8
  store i8 0, ptr %_47, align 8
  %48 = getelementptr inbounds i8, ptr %_48, i64 4
  store i32 3, ptr %48, align 4
  %49 = getelementptr inbounds i8, ptr %_48, i64 8
  store i32 4, ptr %49, align 8
  store i8 1, ptr %_48, align 8
  %50 = getelementptr inbounds i8, ptr %_49, i64 1
  store i8 2, ptr %50, align 1
  %51 = getelementptr inbounds i8, ptr %_49, i64 2
  store i8 2, ptr %51, align 2
  %52 = getelementptr inbounds i8, ptr %_49, i64 3
  store i8 2, ptr %52, align 1
  store i8 2, ptr %_49, align 8
  %53 = getelementptr inbounds i8, ptr %_50, i64 1
  store i8 5, ptr %53, align 1
  %54 = getelementptr inbounds i8, ptr %_50, i64 2
  store i8 6, ptr %54, align 2
  %55 = getelementptr inbounds i8, ptr %_50, i64 3
  store i8 7, ptr %55, align 1
  store i8 2, ptr %_50, align 8
  store i8 3, ptr %_51, align 8
  %_230 = ptrtoint ptr %_1.i to i64
  %_232 = and i64 %_230, 7
  %_233 = icmp eq i64 %_232, 0
  br i1 %_233, label %bb122, label %panic

bb122:                                            ; preds = %bb18
  %_235 = ptrtoint ptr %_1.i to i64
  %_237 = icmp eq i64 %_235, 0
  %_238 = and i1 %_237, true
  %_239 = xor i1 %_238, true
  br i1 %_239, label %bb123, label %panic19

panic:                                            ; preds = %bb18
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_230, ptr align 8 @alloc_df7fb09215c742e668e6254030a2bddf) #25
  unreachable

bb123:                                            ; preds = %bb122
  %56 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_47, i64 16, i1 false)
  %57 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_48, i64 16, i1 false)
  %58 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %58, ptr align 8 %_49, i64 16, i1 false)
  %59 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %59, ptr align 8 %_50, i64 16, i1 false)
  %60 = getelementptr inbounds nuw %Shape, ptr %_1.i, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %60, ptr align 8 %_51, i64 16, i1 false)
; call <[patterns::Shape]>::into_vec::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCsccF2givDBH6_8patterns5Shape8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %shapes, ptr align 8 %_1.i, i64 5) #22
; invoke <&alloc::vec::Vec<patterns::Shape> as core::iter::traits::collect::IntoIterator>::into_iter
  %61 = invoke { ptr, ptr } @_RNvXsh_NtCs7CppTae75M1_5alloc3vecRINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12IntoIterator9into_iterBI_(ptr align 8 %shapes)
          to label %bb27 unwind label %cleanup20

panic19:                                          ; preds = %bb122
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_df7fb09215c742e668e6254030a2bddf) #25
  unreachable

bb117:                                            ; preds = %bb116, %cleanup20
; invoke core::ptr::drop_glue::<alloc::vec::Vec<patterns::Shape>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsccF2givDBH6_8patterns5ShapeEEB1a_(ptr align 8 %shapes) #20
          to label %bb121 unwind label %terminate

cleanup20:                                        ; preds = %bb36, %bb35, %bb34, %bb33, %bb32, %bb30, %bb113, %bb94, %bb93, %bb92, %bb91, %bb90, %bb82, %bb78, %bb73, %bb81, %bb80, %bb75, %bb71, %bb79, %bb77, %bb72, %bb69, %bb66, %bb65, %bb64, %bb67, %bb63, %bb68, %bb62, %bb59, %bb58, %bb57, %bb55, %bb52, %bb51, %bb50, %bb49, %bb48, %bb47, %bb46, %bb45, %bb44, %bb43, %bb42, %bb41, %bb40, %bb39, %bb38, %bb37, %bb31, %bb28, %bb123
  %62 = landingpad { ptr, i32 }
          cleanup
  %63 = extractvalue { ptr, i32 } %62, 0
  %64 = extractvalue { ptr, i32 } %62, 1
  store ptr %63, ptr %0, align 8
  %65 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %64, ptr %65, align 8
  br label %bb117

bb27:                                             ; preds = %bb123
  %_52.0 = extractvalue { ptr, ptr } %61, 0
  %_52.1 = extractvalue { ptr, ptr } %61, 1
  store ptr %_52.0, ptr %iter3, align 8
  %66 = getelementptr inbounds i8, ptr %iter3, i64 8
  store ptr %_52.1, ptr %66, align 8
  br label %bb28

bb28:                                             ; preds = %bb125, %bb27
; invoke <core::slice::iter::Iter<patterns::Shape> as core::iter::traits::iterator::Iterator>::next
  %67 = invoke align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterNtCsccF2givDBH6_8patterns5ShapeENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBR_(ptr align 8 %iter3)
          to label %bb29 unwind label %cleanup20

bb29:                                             ; preds = %bb28
  store ptr %67, ptr %_55, align 8
  %68 = load ptr, ptr %_55, align 8
  %69 = ptrtoint ptr %68 to i64
  %70 = icmp eq i64 %69, 0
  %_57 = select i1 %70, i64 0, i64 1
  %71 = trunc nuw i64 %_57 to i1
  br i1 %71, label %bb30, label %bb31

bb30:                                             ; preds = %bb29
  %72 = load ptr, ptr %_55, align 8
  store ptr %72, ptr %s, align 8, !captures !249
  %73 = load ptr, ptr %s, align 8
; invoke core::hint::black_box::<&patterns::Shape>
  %_65 = invoke align 8 ptr @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxRNtCsccF2givDBH6_8patterns5ShapeEBF_(ptr align 8 %73)
          to label %bb32 unwind label %cleanup20

bb31:                                             ; preds = %bb29
; invoke patterns::parse_kv
  invoke void @_RNvCsccF2givDBH6_8patterns8parse_kv(ptr sret([24 x i8]) align 8 %_75, ptr @alloc_b1e693e8528fb8140f163b7e7dd5f4c0, i64 5)
          to label %bb37 unwind label %cleanup20

bb37:                                             ; preds = %bb31
; invoke patterns::parse_kv
  invoke void @_RNvCsccF2givDBH6_8patterns8parse_kv(ptr sret([24 x i8]) align 8 %_78, ptr @alloc_89c92c491e006e6ef9402d0dec0fc54d, i64 3)
          to label %bb38 unwind label %cleanup20

bb38:                                             ; preds = %bb37
; invoke patterns::parse_kv
  invoke void @_RNvCsccF2givDBH6_8patterns8parse_kv(ptr sret([24 x i8]) align 8 %_81, ptr @alloc_18f2f0d3d4f38df552db2352111ec81f, i64 1)
          to label %bb39 unwind label %cleanup20

bb39:                                             ; preds = %bb38
  store ptr %_75, ptr %args5, align 8
  %74 = getelementptr inbounds i8, ptr %args5, i64 8
  store ptr %_78, ptr %74, align 8
  %75 = getelementptr inbounds i8, ptr %args5, i64 16
  store ptr %_81, ptr %75, align 8
  %_214 = load ptr, ptr %args5, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<(&str, i32)>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionTRelEEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_84, ptr align 8 %_214)
          to label %bb40 unwind label %cleanup20

bb40:                                             ; preds = %bb39
  %76 = getelementptr inbounds i8, ptr %args5, i64 8
  %_215 = load ptr, ptr %76, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<(&str, i32)>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionTRelEEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_85, ptr align 8 %_215)
          to label %bb41 unwind label %cleanup20

bb41:                                             ; preds = %bb40
  %77 = getelementptr inbounds i8, ptr %args5, i64 16
  %_216 = load ptr, ptr %77, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<(&str, i32)>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionTRelEEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_86, ptr align 8 %_216)
          to label %bb42 unwind label %cleanup20

bb42:                                             ; preds = %bb41
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_84, i64 16, i1 false)
  %79 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %79, ptr align 8 %_85, i64 16, i1 false)
  %80 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %80, ptr align 8 %_86, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 3>
  %81 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsccF2givDBH6_8patterns(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args6)
          to label %bb43 unwind label %cleanup20

bb43:                                             ; preds = %bb42
  %_72.0 = extractvalue { ptr, ptr } %81, 0
  %_72.1 = extractvalue { ptr, ptr } %81, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_72.0, ptr %_72.1)
          to label %bb44 unwind label %cleanup20

bb44:                                             ; preds = %bb43
  store i16 2, ptr %_91, align 8
  %82 = getelementptr inbounds i8, ptr %_91, i64 8
  store ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, ptr %82, align 8
  %83 = getelementptr inbounds i8, ptr %82, i64 8
  store i64 1, ptr %83, align 8
  %84 = getelementptr inbounds nuw i32, ptr %_92, i64 0
  store i32 3, ptr %84, align 4
  %85 = getelementptr inbounds nuw i32, ptr %_92, i64 1
  store i32 4, ptr %85, align 4
  %86 = getelementptr inbounds nuw i32, ptr %_92, i64 2
  store i32 5, ptr %86, align 4
  %87 = getelementptr inbounds i8, ptr %_90, i64 24
  store i8 1, ptr %87, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_90, ptr align 8 %_91, i64 24, i1 false)
  %88 = getelementptr inbounds i8, ptr %_90, i64 28
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %88, ptr align 4 %_92, i64 12, i1 false)
; invoke core::hint::black_box::<(u8, (i16, &str), [i32; 3])>
  invoke void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxThTsReEAlj3_EECsccF2givDBH6_8patterns(ptr sret([40 x i8]) align 8 %t, ptr align 8 %_90)
          to label %bb45 unwind label %cleanup20

bb45:                                             ; preds = %bb44
  %89 = getelementptr inbounds i8, ptr %t, i64 24
  %90 = load i8, ptr %89, align 8
  store i8 %90, ptr %a, align 1
  %91 = load i16, ptr %t, align 8
  store i16 %91, ptr %b, align 2
  %92 = getelementptr inbounds i8, ptr %t, i64 8
  %93 = load ptr, ptr %92, align 8
  %94 = getelementptr inbounds i8, ptr %92, i64 8
  %95 = load i64, ptr %94, align 8
  store ptr %93, ptr %c, align 8, !captures !249
  %96 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %95, ptr %96, align 8
  %97 = getelementptr inbounds i8, ptr %t, i64 28
  %98 = getelementptr inbounds nuw i32, ptr %97, i64 0
  %99 = load i32, ptr %98, align 4
  store i32 %99, ptr %d, align 4
  %100 = getelementptr inbounds i8, ptr %t, i64 28
  %101 = getelementptr inbounds nuw i32, ptr %100, i64 2
  %102 = load i32, ptr %101, align 4
  store i32 %102, ptr %e, align 4
  store ptr %a, ptr %args7, align 8
  %103 = getelementptr inbounds i8, ptr %args7, i64 8
  store ptr %b, ptr %103, align 8
  %104 = getelementptr inbounds i8, ptr %args7, i64 16
  store ptr %c, ptr %104, align 8
  %105 = getelementptr inbounds i8, ptr %args7, i64 24
  store ptr %d, ptr %105, align 8
  %106 = getelementptr inbounds i8, ptr %args7, i64 32
  store ptr %e, ptr %106, align 8
  %_217 = load ptr, ptr %args7, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_107, ptr %_217)
          to label %bb46 unwind label %cleanup20

bb46:                                             ; preds = %bb45
  %107 = getelementptr inbounds i8, ptr %args7, i64 8
  %_218 = load ptr, ptr %107, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i16>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_108, ptr align 2 %_218)
          to label %bb47 unwind label %cleanup20

bb47:                                             ; preds = %bb46
  %108 = getelementptr inbounds i8, ptr %args7, i64 16
  %_219 = load ptr, ptr %108, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_109, ptr align 8 %_219)
          to label %bb48 unwind label %cleanup20

bb48:                                             ; preds = %bb47
  %109 = getelementptr inbounds i8, ptr %args7, i64 24
  %_220 = load ptr, ptr %109, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_110, ptr align 4 %_220)
          to label %bb49 unwind label %cleanup20

bb49:                                             ; preds = %bb48
  %110 = getelementptr inbounds i8, ptr %args7, i64 32
  %_221 = load ptr, ptr %110, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_111, ptr align 4 %_221)
          to label %bb50 unwind label %cleanup20

bb50:                                             ; preds = %bb49
  %111 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %111, ptr align 8 %_107, i64 16, i1 false)
  %112 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %112, ptr align 8 %_108, i64 16, i1 false)
  %113 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %113, ptr align 8 %_109, i64 16, i1 false)
  %114 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %114, ptr align 8 %_110, i64 16, i1 false)
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_111, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<16, 5>
  %116 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECsccF2givDBH6_8patterns(ptr @alloc_6a96e47ef75dbf6fc4eb5423ba7bb768, ptr align 8 %args8)
          to label %bb51 unwind label %cleanup20

bb51:                                             ; preds = %bb50
  %_99.0 = extractvalue { ptr, ptr } %116, 0
  %_99.1 = extractvalue { ptr, ptr } %116, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_99.0, ptr %_99.1)
          to label %bb52 unwind label %cleanup20

bb52:                                             ; preds = %bb51
; invoke core::hint::black_box::<core::option::Option<u8>>
  %117 = invoke { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECsccF2givDBH6_8patterns(i1 zeroext true, i8 42)
          to label %bb53 unwind label %cleanup20

bb53:                                             ; preds = %bb52
  %118 = extractvalue { i1, i8 } %117, 0
  %119 = extractvalue { i1, i8 } %117, 1
  %120 = zext i1 %118 to i8
  store i8 %120, ptr %msg, align 1
  %121 = getelementptr inbounds i8, ptr %msg, i64 1
  store i8 %119, ptr %121, align 1
  %122 = load i8, ptr %msg, align 1
  %123 = trunc nuw i8 %122 to i1
  %124 = getelementptr inbounds i8, ptr %msg, i64 1
  %125 = load i8, ptr %124, align 1
  %_118 = zext i1 %123 to i64
  %126 = trunc nuw i64 %_118 to i1
  br i1 %126, label %bb54, label %bb59

bb54:                                             ; preds = %bb53
  %127 = getelementptr inbounds i8, ptr %msg, i64 1
  %128 = load i8, ptr %127, align 1
  %_116 = icmp ule i8 40, %128
  br i1 %_116, label %bb56, label %bb59

bb59:                                             ; preds = %bb126, %bb56, %bb54, %bb53
; invoke core::hint::black_box::<core::option::Option<core::option::Option<u8>>>
  %129 = invoke { i8, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionIBD_hEEECsccF2givDBH6_8patterns(i8 0, i8 undef)
          to label %bb60 unwind label %cleanup20

bb56:                                             ; preds = %bb54
  %130 = getelementptr inbounds i8, ptr %msg, i64 1
  %131 = load i8, ptr %130, align 1
  %_117 = icmp ule i8 %131, 50
  br i1 %_117, label %bb55, label %bb59

bb55:                                             ; preds = %bb56
  %132 = getelementptr inbounds i8, ptr %msg, i64 1
  %133 = load i8, ptr %132, align 1
  store i8 %133, ptr %n9, align 1
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_125, ptr %n9)
          to label %bb57 unwind label %cleanup20

bb57:                                             ; preds = %bb55
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_125, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<14, 1>
  %135 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_144b8bda8b7d019167909d944f76599d, ptr align 8 %args10)
          to label %bb58 unwind label %cleanup20

bb58:                                             ; preds = %bb57
  %_121.0 = extractvalue { ptr, ptr } %135, 0
  %_121.1 = extractvalue { ptr, ptr } %135, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_121.0, ptr %_121.1)
          to label %bb126 unwind label %cleanup20

bb126:                                            ; preds = %bb58
  br label %bb59

bb60:                                             ; preds = %bb59
  %136 = extractvalue { i8, i8 } %129, 0
  %137 = extractvalue { i8, i8 } %129, 1
  store i8 %136, ptr %opt, align 1
  %138 = getelementptr inbounds i8, ptr %opt, i64 1
  store i8 %137, ptr %138, align 1
  %139 = load i8, ptr %opt, align 1
  %140 = getelementptr inbounds i8, ptr %opt, i64 1
  %141 = load i8, ptr %140, align 1
  %142 = icmp eq i8 %139, 2
  %_132 = select i1 %142, i64 0, i64 1
  %143 = trunc nuw i64 %_132 to i1
  br i1 %143, label %bb61, label %bb62

bb61:                                             ; preds = %bb60
  %144 = load i8, ptr %opt, align 1
  %145 = trunc nuw i8 %144 to i1
  %146 = getelementptr inbounds i8, ptr %opt, i64 1
  %147 = load i8, ptr %146, align 1
  %_131 = zext i1 %145 to i64
  %148 = trunc nuw i64 %_131 to i1
  br i1 %148, label %bb64, label %bb63

bb62:                                             ; preds = %bb60
; invoke <core::fmt::Arguments>::from_str
  %149 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_b8a9faf0f44a085c631f2755716883c9, i64 5)
          to label %bb68 unwind label %cleanup20

bb68:                                             ; preds = %bb62
  %_145.0 = extractvalue { ptr, ptr } %149, 0
  %_145.1 = extractvalue { ptr, ptr } %149, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_145.0, ptr %_145.1)
          to label %bb129 unwind label %cleanup20

bb129:                                            ; preds = %bb68
  br label %bb69

bb69:                                             ; preds = %bb127, %bb128, %bb129
  store ptr @alloc_c1fa64f4e819a506b7859bc956f830ca, ptr %_147, align 8
  %150 = getelementptr inbounds i8, ptr %_147, i64 8
  store i64 1, ptr %150, align 8
; invoke core::hint::black_box::<core::result::Result<u8, &str>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6result6ResulthReEECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %r, ptr align 8 %_147)
          to label %bb70 unwind label %cleanup20

bb64:                                             ; preds = %bb61
  %151 = getelementptr inbounds i8, ptr %opt, i64 1
  %152 = load i8, ptr %151, align 1
  store i8 %152, ptr %x, align 1
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_139, ptr %x)
          to label %bb65 unwind label %cleanup20

bb63:                                             ; preds = %bb61
; invoke <core::fmt::Arguments>::from_str
  %153 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_0e8a8a0ff4ea56ec3d4541bf7e74cfec, i64 11)
          to label %bb67 unwind label %cleanup20

bb67:                                             ; preds = %bb63
  %_143.0 = extractvalue { ptr, ptr } %153, 0
  %_143.1 = extractvalue { ptr, ptr } %153, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_143.0, ptr %_143.1)
          to label %bb128 unwind label %cleanup20

bb128:                                            ; preds = %bb67
  br label %bb69

bb65:                                             ; preds = %bb64
  %154 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %154, ptr align 8 %_139, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %155 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args11)
          to label %bb66 unwind label %cleanup20

bb66:                                             ; preds = %bb65
  %_135.0 = extractvalue { ptr, ptr } %155, 0
  %_135.1 = extractvalue { ptr, ptr } %155, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_135.0, ptr %_135.1)
          to label %bb127 unwind label %cleanup20

bb127:                                            ; preds = %bb66
  br label %bb69

bb70:                                             ; preds = %bb69
  %156 = load ptr, ptr %r, align 8
  %157 = ptrtoint ptr %156 to i64
  %158 = icmp eq i64 %157, 0
  %_149 = select i1 %158, i64 0, i64 1
  %159 = trunc nuw i64 %_149 to i1
  br i1 %159, label %bb71, label %bb72

bb71:                                             ; preds = %bb70
; invoke core::hint::black_box::<bool>
  %_150 = invoke zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECsccF2givDBH6_8patterns(i1 zeroext false)
          to label %bb74 unwind label %cleanup20

bb72:                                             ; preds = %bb70
; invoke core::hint::black_box::<bool>
  %_151 = invoke zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECsccF2givDBH6_8patterns(i1 zeroext false)
          to label %bb76 unwind label %cleanup20

bb76:                                             ; preds = %bb72
  br i1 %_151, label %bb73, label %bb77

bb77:                                             ; preds = %bb76
; invoke <core::fmt::Arguments>::from_str
  %160 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_31a9e8f7a570396788f7b2482a3a97e4, i64 3)
          to label %bb79 unwind label %cleanup20

bb73:                                             ; preds = %bb74, %bb76
; invoke <core::fmt::Arguments>::from_str
  %161 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_3dbdd06bebcf2fb86aed3e2f16680d42, i64 8)
          to label %bb78 unwind label %cleanup20

bb79:                                             ; preds = %bb77
  %_155.0 = extractvalue { ptr, ptr } %160, 0
  %_155.1 = extractvalue { ptr, ptr } %160, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_155.0, ptr %_155.1)
          to label %bb131 unwind label %cleanup20

bb131:                                            ; preds = %bb79
  br label %bb82

bb82:                                             ; preds = %bb130, %bb132, %bb131
; invoke core::hint::black_box::<char>
  %ch = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxcECsccF2givDBH6_8patterns(i32 107)
          to label %bb83 unwind label %cleanup20

bb74:                                             ; preds = %bb71
  br i1 %_150, label %bb73, label %bb75

bb75:                                             ; preds = %bb74
  %162 = load ptr, ptr %r, align 8
  %163 = getelementptr inbounds i8, ptr %r, i64 8
  %164 = load i64, ptr %163, align 8
  store ptr %162, ptr %e12, align 8, !captures !249
  %165 = getelementptr inbounds i8, ptr %e12, i64 8
  store i64 %164, ptr %165, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_162, ptr align 8 %e12)
          to label %bb80 unwind label %cleanup20

bb80:                                             ; preds = %bb75
  %166 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %166, ptr align 8 %_162, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<9, 1>
  %167 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj9_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_c0c0bd6959bacd2127c8d4fc3870a66f, ptr align 8 %args13)
          to label %bb81 unwind label %cleanup20

bb81:                                             ; preds = %bb80
  %_158.0 = extractvalue { ptr, ptr } %167, 0
  %_158.1 = extractvalue { ptr, ptr } %167, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_158.0, ptr %_158.1)
          to label %bb132 unwind label %cleanup20

bb132:                                            ; preds = %bb81
  br label %bb82

bb78:                                             ; preds = %bb73
  %_153.0 = extractvalue { ptr, ptr } %161, 0
  %_153.1 = extractvalue { ptr, ptr } %161, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
          to label %bb130 unwind label %cleanup20

bb130:                                            ; preds = %bb78
  br label %bb82

bb83:                                             ; preds = %bb82
  %_173 = icmp ule i32 97, %ch
  br i1 %_173, label %bb89, label %bb86

bb86:                                             ; preds = %bb89, %bb83
  %_171 = icmp ule i32 107, %ch
  br i1 %_171, label %bb88, label %bb84

bb89:                                             ; preds = %bb83
  %_174 = icmp ule i32 %ch, 106
  br i1 %_174, label %bb85, label %bb86

bb85:                                             ; preds = %bb89
  store i32 1, ptr %_170, align 4
  br label %bb90

bb84:                                             ; preds = %bb88, %bb86
  store i32 3, ptr %_170, align 4
  br label %bb90

bb88:                                             ; preds = %bb86
  %_172 = icmp ule i32 %ch, 122
  br i1 %_172, label %bb87, label %bb84

bb87:                                             ; preds = %bb88
  store i32 2, ptr %_170, align 4
  br label %bb90

bb90:                                             ; preds = %bb85, %bb87, %bb84
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_176, ptr align 4 %_170)
          to label %bb91 unwind label %cleanup20

bb91:                                             ; preds = %bb90
  %168 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %168, ptr align 8 %_176, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %169 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args14)
          to label %bb92 unwind label %cleanup20

bb92:                                             ; preds = %bb91
  %_167.0 = extractvalue { ptr, ptr } %169, 0
  %_167.1 = extractvalue { ptr, ptr } %169, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
          to label %bb93 unwind label %cleanup20

bb93:                                             ; preds = %bb92
; invoke <alloc::string::String as core::convert::From<&str>>::from
  invoke void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_182, ptr @alloc_acd822e6332f053907a9b112a94122d3, i64 5)
          to label %bb94 unwind label %cleanup20

bb94:                                             ; preds = %bb93
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_181, ptr align 8 %_182, i64 24, i1 false)
; invoke core::hint::black_box::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_180, ptr align 8 %_181)
          to label %bb95 unwind label %cleanup20

bb95:                                             ; preds = %bb94
  %170 = load i64, ptr %_180, align 8
  %171 = icmp eq i64 %170, -1
  %_183 = select i1 %171, i64 0, i64 1
  %172 = trunc nuw i64 %_183 to i1
  br i1 %172, label %bb96, label %bb100

bb96:                                             ; preds = %bb95
; invoke <alloc::string::String>::len
  %173 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsccF2givDBH6_8patterns(ptr align 8 %_180)
          to label %bb97 unwind label %cleanup21

bb100:                                            ; preds = %bb133, %bb95
; invoke core::hint::black_box::<u32>
  %174 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsccF2givDBH6_8patterns(i32 5)
          to label %bb101 unwind label %cleanup21

bb116:                                            ; preds = %cleanup21
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECsccF2givDBH6_8patterns(ptr align 8 %_180) #20
          to label %bb117 unwind label %terminate

cleanup21:                                        ; preds = %bb112, %bb111, %bb110, %bb100, %bb99, %bb98, %bb97, %bb96
  %175 = landingpad { ptr, i32 }
          cleanup
  %176 = extractvalue { ptr, i32 } %175, 0
  %177 = extractvalue { ptr, i32 } %175, 1
  store ptr %176, ptr %0, align 8
  %178 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %177, ptr %178, align 8
  br label %bb116

bb97:                                             ; preds = %bb96
  store i64 %173, ptr %_189, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_191, ptr align 8 %_189)
          to label %bb98 unwind label %cleanup21

bb98:                                             ; preds = %bb97
  %179 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %179, ptr align 8 %_191, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %180 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args15)
          to label %bb99 unwind label %cleanup21

bb99:                                             ; preds = %bb98
  %_186.0 = extractvalue { ptr, ptr } %180, 0
  %_186.1 = extractvalue { ptr, ptr } %180, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_186.0, ptr %_186.1)
          to label %bb133 unwind label %cleanup21

bb133:                                            ; preds = %bb99
  br label %bb100

bb101:                                            ; preds = %bb100
  store i32 %174, ptr %x16, align 4
  %181 = load i32, ptr %x16, align 4
  %182 = icmp eq i32 %181, 0
  br i1 %182, label %bb106, label %bb105

bb106:                                            ; preds = %bb101
  store ptr @alloc_50ab75e5eb17b3d68555764b0a52038b, ptr %y, align 8, !captures !249
  %183 = getelementptr inbounds i8, ptr %y, i64 8
  store i64 1, ptr %183, align 8
  br label %bb110

bb105:                                            ; preds = %bb101
  %_200 = load i32, ptr %x16, align 4
  %_0.i.i = call i32 @llvm.ctpop.i32(i32 %_200)
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb107

bb110:                                            ; preds = %bb108, %bb103, %bb102, %bb106
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_206, ptr align 8 %y)
          to label %bb111 unwind label %cleanup21

bb107:                                            ; preds = %bb105
  br i1 %_0.i, label %bb108, label %bb109

bb109:                                            ; preds = %bb107
  %184 = load i32, ptr %x16, align 4
  %_196 = icmp ule i32 1, %184
  br i1 %_196, label %bb104, label %bb102

bb108:                                            ; preds = %bb107
  store ptr @alloc_f424f6e87101d147a136ec9aa11fa034, ptr %y, align 8, !captures !249
  %185 = getelementptr inbounds i8, ptr %y, i64 8
  store i64 4, ptr %185, align 8
  br label %bb110

bb102:                                            ; preds = %bb104, %bb109
  store ptr @alloc_69ea765c2672a934a5b64287f175d158, ptr %y, align 8, !captures !249
  %186 = getelementptr inbounds i8, ptr %y, i64 8
  store i64 4, ptr %186, align 8
  br label %bb110

bb104:                                            ; preds = %bb109
  %187 = load i32, ptr %x16, align 4
  %_197 = icmp ule i32 %187, 9
  br i1 %_197, label %bb103, label %bb102

bb103:                                            ; preds = %bb104
  store ptr @alloc_78d5c01af63be55c3511bacffb1a7824, ptr %y, align 8, !captures !249
  %188 = getelementptr inbounds i8, ptr %y, i64 8
  store i64 5, ptr %188, align 8
  br label %bb110

bb111:                                            ; preds = %bb110
  %189 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %189, ptr align 8 %_206, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %190 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args17)
          to label %bb112 unwind label %cleanup21

bb112:                                            ; preds = %bb111
  %_202.0 = extractvalue { ptr, ptr } %190, 0
  %_202.1 = extractvalue { ptr, ptr } %190, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_202.0, ptr %_202.1)
          to label %bb113 unwind label %cleanup21

bb113:                                            ; preds = %bb112
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECsccF2givDBH6_8patterns(ptr align 8 %_180)
          to label %bb114 unwind label %cleanup20

bb114:                                            ; preds = %bb113
; call core::ptr::drop_glue::<alloc::vec::Vec<patterns::Shape>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsccF2givDBH6_8patterns5ShapeEEB1a_(ptr align 8 %shapes)
  ret void

terminate:                                        ; preds = %bb120, %bb119, %bb118, %bb117, %bb116
  %191 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #21
  unreachable

bb32:                                             ; preds = %bb30
; invoke patterns::area
  %192 = invoke i32 @_RNvCsccF2givDBH6_8patterns4area(ptr align 8 %_65)
          to label %bb33 unwind label %cleanup20

bb33:                                             ; preds = %bb32
  store i32 %192, ptr %_64, align 4
; invoke <core::fmt::rt::Argument>::new_debug::<&patterns::Shape>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRNtCsccF2givDBH6_8patterns5ShapeEBY_(ptr sret([16 x i8]) align 8 %_67, ptr align 8 %s)
          to label %bb34 unwind label %cleanup20

bb34:                                             ; preds = %bb33
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_68, ptr align 4 %_64)
          to label %bb35 unwind label %cleanup20

bb35:                                             ; preds = %bb34
  %193 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %193, ptr align 8 %_67, i64 16, i1 false)
  %194 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %194, ptr align 8 %_68, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %195 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsccF2givDBH6_8patterns(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4)
          to label %bb36 unwind label %cleanup20

bb36:                                             ; preds = %bb35
  %_60.0 = extractvalue { ptr, ptr } %195, 0
  %_60.1 = extractvalue { ptr, ptr } %195, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_60.0, ptr %_60.1)
          to label %bb125 unwind label %cleanup20

bb125:                                            ; preds = %bb36
  br label %bb28

bb121:                                            ; preds = %bb120, %bb119, %bb117
  %196 = load ptr, ptr %0, align 8
  %197 = getelementptr inbounds i8, ptr %0, i64 8
  %198 = load i32, ptr %197, align 8
  %199 = insertvalue { ptr, i32 } poison, ptr %196, 0
  %200 = insertvalue { ptr, i32 } %199, i32 %198, 1
  resume { ptr, i32 } %200

bb19:                                             ; preds = %bb17
  %_40.0 = extractvalue { ptr, i64 } %46, 0
  %_40.1 = extractvalue { ptr, i64 } %46, 1
; invoke patterns::slice_pat
  invoke void @_RNvCsccF2givDBH6_8patterns9slice_pat(ptr sret([24 x i8]) align 8 %_39, ptr align 4 %_40.0, i64 %_40.1)
          to label %bb20 unwind label %cleanup18

bb20:                                             ; preds = %bb19
; invoke <core::fmt::rt::Argument>::new_display::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_42, ptr align 8 %_39)
          to label %bb21 unwind label %cleanup22

bb118:                                            ; preds = %cleanup22
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECsccF2givDBH6_8patterns(ptr align 8 %_39) #20
          to label %bb119 unwind label %terminate

cleanup22:                                        ; preds = %bb22, %bb21, %bb20
  %201 = landingpad { ptr, i32 }
          cleanup
  %202 = extractvalue { ptr, i32 } %201, 0
  %203 = extractvalue { ptr, i32 } %201, 1
  store ptr %202, ptr %0, align 8
  %204 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %203, ptr %204, align 8
  br label %bb118

bb21:                                             ; preds = %bb20
  %205 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %205, ptr align 8 %_42, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %206 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args2)
          to label %bb22 unwind label %cleanup22

bb22:                                             ; preds = %bb21
  %_36.0 = extractvalue { ptr, ptr } %206, 0
  %_36.1 = extractvalue { ptr, ptr } %206, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_36.0, ptr %_36.1)
          to label %bb23 unwind label %cleanup22

bb23:                                             ; preds = %bb22
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECsccF2givDBH6_8patterns(ptr align 8 %_39)
          to label %bb15 unwind label %cleanup18

bb7:                                              ; preds = %bb5
; invoke patterns::classify
  %207 = invoke { ptr, i64 } @_RNvCsccF2givDBH6_8patterns8classify(i64 %_14)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %208 = extractvalue { ptr, i64 } %207, 0
  %209 = extractvalue { ptr, i64 } %207, 1
  store ptr %208, ptr %_13, align 8
  %210 = getelementptr inbounds i8, ptr %_13, i64 8
  store i64 %209, ptr %210, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_16, ptr align 8 %n)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_17, ptr align 8 %_13)
          to label %bb10 unwind label %cleanup

bb10:                                             ; preds = %bb9
  %211 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %211, ptr align 8 %_16, i64 16, i1 false)
  %212 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %212, ptr align 8 %_17, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %213 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsccF2givDBH6_8patterns(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
  %_9.0 = extractvalue { ptr, ptr } %213, 0
  %_9.1 = extractvalue { ptr, ptr } %213, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
          to label %bb124 unwind label %cleanup

bb124:                                            ; preds = %bb11
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable
}

; patterns::classify
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvCsccF2givDBH6_8patterns8classify(i64 %0) unnamed_addr #1 !guid !306 {
start:
  %_0 = alloca [16 x i8], align 8
  %n = alloca [8 x i8], align 8
  store i64 %0, ptr %n, align 8
  %1 = load i64, ptr %n, align 8
  %_2 = icmp sle i64 -9223372036854775808, %1
  br i1 %_2, label %bb4, label %bb3

bb3:                                              ; preds = %bb4, %start
  %2 = load i64, ptr %n, align 8
  switch i64 %2, label %bb1 [
    i64 0, label %bb9
    i64 1, label %bb8
    i64 2, label %bb8
    i64 3, label %bb8
  ]

bb4:                                              ; preds = %start
  %3 = load i64, ptr %n, align 8
  %_3 = icmp sle i64 %3, -1
  br i1 %_3, label %bb2, label %bb3

bb2:                                              ; preds = %bb4
  store ptr @alloc_7aa1a11e7908cb59b04764917ce720b4, ptr %_0, align 8, !captures !249
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 3, ptr %4, align 8
  br label %bb14

bb1:                                              ; preds = %bb3
  %_9 = load i64, ptr %n, align 8
  %_12 = icmp eq i64 %_9, -9223372036854775808
  %_13 = and i1 false, %_12
  br i1 %_13, label %panic, label %bb11

bb9:                                              ; preds = %bb3
  store ptr @alloc_427cf7da6bbe57bf2fdbddfa3078c1f8, ptr %_0, align 8, !captures !249
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 4, ptr %5, align 8
  br label %bb14

bb8:                                              ; preds = %bb3, %bb3, %bb3
  store ptr @alloc_87862e78b478b6bd0b4ea1c7b6258769, ptr %_0, align 8, !captures !249
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 5, ptr %6, align 8
  br label %bb14

bb14:                                             ; preds = %bb2, %bb12, %bb6, %bb5, %bb8, %bb9
  %7 = load ptr, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  ret { ptr, i64 } %11

bb11:                                             ; preds = %bb1
  %_8 = srem i64 %_9, 2
  %_7 = icmp eq i64 %_8, 0
  br i1 %_7, label %bb12, label %bb13

panic:                                            ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_735ff844006bb5c32021c0456ffecbea) #26
  unreachable

bb13:                                             ; preds = %bb11
  %12 = load i64, ptr %n, align 8
  %_4 = icmp sle i64 4, %12
  br i1 %_4, label %bb7, label %bb5

bb12:                                             ; preds = %bb11
  store ptr @alloc_fbf52d5fed6793d3e790c9ce6627a01c, ptr %_0, align 8, !captures !249
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 4, ptr %13, align 8
  br label %bb14

bb5:                                              ; preds = %bb7, %bb13
  store ptr @alloc_7ec976a351c849ad2fc3958edc69f6f6, ptr %_0, align 8, !captures !249
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 3, ptr %14, align 8
  br label %bb14

bb7:                                              ; preds = %bb13
  %15 = load i64, ptr %n, align 8
  %_5 = icmp sle i64 %15, 99
  br i1 %_5, label %bb6, label %bb5

bb6:                                              ; preds = %bb7
  store ptr @alloc_f5f4cccb72aa20d03a19e99c91cbe0b2, ptr %_0, align 8, !captures !249
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 7, ptr %16, align 8
  br label %bb14
}

; patterns::parse_kv
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCsccF2givDBH6_8patterns8parse_kv(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !307 {
start:
  %0 = alloca [8 x i8], align 8
  %_10 = alloca [24 x i8], align 8
  %_7 = alloca [8 x i8], align 4
  %_4 = alloca [32 x i8], align 8
; call <str>::split_once::<char>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre10split_oncecECsccF2givDBH6_8patterns(ptr sret([32 x i8]) align 8 %_4, ptr %s.0, i64 %s.1, i32 61) #22
  %1 = load ptr, ptr %_4, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_5 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_5 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %k.0 = load ptr, ptr %_4, align 8
  %5 = getelementptr inbounds i8, ptr %_4, i64 8
  %k.1 = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %v.0 = load ptr, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  %v.1 = load i64, ptr %7, align 8
; call <str>::trim
  %8 = call { ptr, i64 } @_RNvMNtCsl10jNU3mE6R_4core3stre4trimCsccF2givDBH6_8patterns(ptr %v.0, i64 %v.1) #22
  %_8.0 = extractvalue { ptr, i64 } %8, 0
  %_8.1 = extractvalue { ptr, i64 } %8, 1
; call <str>::parse::<i32>
  %9 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parselECsccF2givDBH6_8patterns(ptr %_8.0, i64 %_8.1) #22
  store i64 %9, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_7, ptr align 8 %0, i64 8, i1 false)
  %10 = load i8, ptr %_7, align 4
  %11 = trunc nuw i8 %10 to i1
  %_9 = zext i1 %11 to i64
  %12 = trunc nuw i64 %_9 to i1
  br i1 %12, label %bb7, label %bb6

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb9

bb7:                                              ; preds = %bb2
  store ptr null, ptr %_0, align 8
  br label %bb9

bb6:                                              ; preds = %bb2
  %13 = getelementptr inbounds i8, ptr %_7, i64 4
  %n = load i32, ptr %13, align 4
; call <str>::trim
  %14 = call { ptr, i64 } @_RNvMNtCsl10jNU3mE6R_4core3stre4trimCsccF2givDBH6_8patterns(ptr %k.0, i64 %k.1) #22
  %_11.0 = extractvalue { ptr, i64 } %14, 0
  %_11.1 = extractvalue { ptr, i64 } %14, 1
  store ptr %_11.0, ptr %_10, align 8
  %15 = getelementptr inbounds i8, ptr %_10, i64 8
  store i64 %_11.1, ptr %15, align 8
  %16 = getelementptr inbounds i8, ptr %_10, i64 16
  store i32 %n, ptr %16, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_10, i64 24, i1 false)
  br label %bb9

bb9:                                              ; preds = %bb3, %bb7, %bb6
  ret void

bb10:                                             ; No predecessors!
  unreachable
}

; patterns::slice_pat
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCsccF2givDBH6_8patterns9slice_pat(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %v.0, i64 %v.1) unnamed_addr #1 !guid !308 {
start:
  %_42 = alloca [16 x i8], align 8
  %_41 = alloca [16 x i8], align 8
  %args3 = alloca [32 x i8], align 8
  %_35 = alloca [24 x i8], align 8
  %rest = alloca [16 x i8], align 8
  %first2 = alloca [8 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %args1 = alloca [16 x i8], align 8
  %_25 = alloca [24 x i8], align 8
  %last = alloca [8 x i8], align 8
  %first = alloca [8 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %x = alloca [8 x i8], align 8
  %_9 = icmp eq i64 %v.1, 0
  br i1 %_9, label %bb8, label %bb2

bb2:                                              ; preds = %start
  %_5 = icmp eq i64 %v.1, 1
  br i1 %_5, label %bb7, label %bb4

bb8:                                              ; preds = %start
; call <&str as core::convert::Into<alloc::string::String>>::into
  call void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr @alloc_c597b50e4e89f734c8b5ae53c406eb3f, i64 5, ptr align 8 @alloc_0cc6dc99297ba9fc0efa6643cc60563b) #22
  br label %bb21

bb4:                                              ; preds = %bb2
  %_3 = icmp uge i64 %v.1, 2
  br i1 %_3, label %bb6, label %bb3

bb7:                                              ; preds = %bb2
  %0 = getelementptr inbounds nuw i32, ptr %v.0, i64 0
  store ptr %0, ptr %x, align 8
; call <core::fmt::rt::Argument>::new_display::<&i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_17, ptr align 8 %x) #22
  %1 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 1>
  %2 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_33854f2712a70d661249338f09901dcb, ptr align 8 %args) #22
  %_13.0 = extractvalue { ptr, ptr } %2, 0
  %_13.1 = extractvalue { ptr, ptr } %2, 1
; call alloc::fmt::format
  call void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_12, ptr %_13.0, ptr %_13.1) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_12, i64 24, i1 false)
  br label %bb21

bb3:                                              ; preds = %bb6, %bb4
  %_7 = icmp uge i64 %v.1, 1
  br i1 %_7, label %bb5, label %bb1

bb6:                                              ; preds = %bb4
  %3 = getelementptr inbounds nuw i32, ptr %v.0, i64 0
  store ptr %3, ptr %first, align 8
  %4 = sub i64 %v.1, 1
  %5 = getelementptr inbounds nuw i32, ptr %v.0, i64 %4
  store ptr %5, ptr %last, align 8
; call <&i32 as core::cmp::PartialEq>::eq
  %_24 = call zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRlNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %first, ptr align 8 %last) #22
  br i1 %_24, label %bb13, label %bb3

bb13:                                             ; preds = %bb6
; call <core::fmt::rt::Argument>::new_display::<&i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_30, ptr align 8 %first) #22
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_30, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 1>
  %7 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECsccF2givDBH6_8patterns(ptr @alloc_8f41006de9107663c983a7194b89e648, ptr align 8 %args1) #22
  %_26.0 = extractvalue { ptr, ptr } %7, 0
  %_26.1 = extractvalue { ptr, ptr } %7, 1
; call alloc::fmt::format
  call void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_25, ptr %_26.0, ptr %_26.1) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_25, i64 24, i1 false)
  br label %bb21

bb1:                                              ; preds = %bb3
  unreachable

bb5:                                              ; preds = %bb3
  %8 = getelementptr inbounds nuw i32, ptr %v.0, i64 0
  store ptr %8, ptr %first2, align 8
  %9 = getelementptr inbounds nuw i32, ptr %v.0, i64 1
  %10 = sub i64 %v.1, 1
  store ptr %9, ptr %rest, align 8
  %11 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %10, ptr %11, align 8
; call <core::fmt::rt::Argument>::new_display::<&i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_41, ptr align 8 %first2) #22
; call <core::fmt::rt::Argument>::new_debug::<&[i32]>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSlECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_42, ptr align 8 %rest) #22
  %12 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %12, ptr align 8 %_41, i64 16, i1 false)
  %13 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %_42, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 2>
  %14 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj2_ECsccF2givDBH6_8patterns(ptr @alloc_29912b6d8be215f231ca050c1de43b0b, ptr align 8 %args3) #22
  %_36.0 = extractvalue { ptr, ptr } %14, 0
  %_36.1 = extractvalue { ptr, ptr } %14, 1
; call alloc::fmt::format
  call void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_35, ptr %_36.0, ptr %_36.1) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_35, i64 24, i1 false)
  br label %bb21

bb21:                                             ; preds = %bb8, %bb7, %bb13, %bb5
  ret void
}

; <[u8]>::to_vec
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !309 {
start:
; call <[u8]>::to_vec_in::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #22
  ret void
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !310 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !311 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  ret i64 %_0
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !312 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr %_2.0, i64 %_2.1) #22
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <str>::char_indices
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core3stre12char_indicesCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !313 {
start:
; call <str>::chars
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core3stre5charsCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) #22
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %1, align 8
  store ptr %_2.0, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_2.1, ptr %2, align 8
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !314 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <str>::trim
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCsl10jNU3mE6R_4core3stre4trimCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !315 {
start:
; call <str>::trim_matches::<<char>::is_whitespace>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core3stre12trim_matchesNvMNtNtB5_4char7methodsc13is_whitespaceECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1)
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <str>::chars
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core3stre5charsCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !316 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8]>::iter
  %2 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCsccF2givDBH6_8patterns(ptr %_3.0, i64 %_3.1) #22
  %_2.0 = extractvalue { ptr, ptr } %2, 0
  %_2.1 = extractvalue { ptr, ptr } %2, 1
  %3 = insertvalue { ptr, ptr } poison, ptr %_2.0, 0
  %4 = insertvalue { ptr, ptr } %3, ptr %_2.1, 1
  ret { ptr, ptr } %4
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitRSlE8is_emptyCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !317 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitxE8is_emptyCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !318 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[patterns::Shape]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCsccF2givDBH6_8patterns5Shape4iterBw_(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !319 {
start:
; call <core::slice::iter::Iter<patterns::Shape>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterNtCsccF2givDBH6_8patterns5ShapeE3newBQ_(ptr align 8 %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[u8]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !320 {
start:
; call <core::slice::iter::Iter<u8>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !321 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[i32]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsccF2givDBH6_8patterns(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !322 {
start:
; call <core::slice::iter::Iter<i32>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterlE3newCsccF2givDBH6_8patterns(ptr align 4 %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::option::Option<&u8>>::unwrap_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE16unwrap_uncheckedCsccF2givDBH6_8patterns(ptr %0, ptr align 8 %1) unnamed_addr #0 !guid !323 {
start:
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = load ptr, ptr %self, align 8
  %3 = ptrtoint ptr %2 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_2 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %val = load ptr, ptr %self, align 8
  ret ptr %val

bb2:                                              ; preds = %start
; call core::hint::unreachable_unchecked
  call void @_RNvNtCsl10jNU3mE6R_4core4hint21unreachable_uncheckedCsccF2givDBH6_8patterns(ptr align 8 %1) #27
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<char, core::char::convert::CharTryFromError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultcNtNtNtB4_4char7convert16CharTryFromErrorE5is_okCsccF2givDBH6_8patterns(ptr align 4 %self) unnamed_addr #0 !guid !324 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i32, ptr %self, align 4
  %1 = icmp eq i32 %0, -1
  %_2 = select i1 %1, i64 1, i64 0
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, core::num::error::TryFromIntError>>::expect
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtNtB4_3num5error15TryFromIntErrorE6expectCsccF2givDBH6_8patterns(i1 zeroext %0, i8 %1, ptr %msg.0, i64 %msg.1, ptr align 8 %2) unnamed_addr #0 personality ptr @rust_eh_personality !guid !325 {
start:
  %e = alloca [1 x i8], align 1
  %self = alloca [2 x i8], align 1
  %3 = zext i1 %0 to i8
  store i8 %3, ptr %self, align 1
  %4 = getelementptr inbounds i8, ptr %self, i64 1
  store i8 %1, ptr %4, align 1
  %5 = load i8, ptr %self, align 1
  %6 = trunc nuw i8 %5 to i1
  %7 = getelementptr inbounds i8, ptr %self, i64 1
  %8 = load i8, ptr %7, align 1
  %_3 = zext i1 %6 to i64
  %9 = trunc nuw i64 %_3 to i1
  br i1 %9, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %10 = getelementptr inbounds i8, ptr %self, i64 1
  %11 = load i8, ptr %10, align 1
  store i8 %11, ptr %e, align 1
; call core::result::unwrap_failed
  call void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr %msg.0, i64 %msg.1, ptr %e, ptr align 8 @vtable.2, ptr align 8 %2) #26
  unreachable

bb3:                                              ; preds = %start
  %12 = getelementptr inbounds i8, ptr %self, i64 1
  %t = load i8, ptr %12, align 1
  ret i8 %t

bb1:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE3newB1G_(ptr align 8 %x.0, i64 %x.1) unnamed_addr #1 !guid !326 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE6as_mutB1G_(ptr align 8 %self) unnamed_addr #1 !guid !327 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE6as_refB1G_(ptr align 8 %self) unnamed_addr #1 !guid !328 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE3newCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !329 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 80, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #1 !guid !330 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE3newCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !331 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 72, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #1 !guid !332 {
start:
  ret ptr %self
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsccF2givDBH6_8patterns(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !333 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %align, ptr align 8 %0) #23
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsccF2givDBH6_8patterns(i64 %self) unnamed_addr #0 !guid !334 {
start:
  ret i64 %self
}

; <core::mem::alignment::Alignment>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCsccF2givDBH6_8patterns(i64 %align) unnamed_addr #0 !guid !335 {
start:
  %_0 = alloca [8 x i8], align 8
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsccF2givDBH6_8patterns(i64 %align, ptr align 8 @alloc_988c380202cc7b7a37ca3d8d5930c44f) #22
  store i64 %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::mem::alignment::Alignment>::as_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCsccF2givDBH6_8patterns(i64 %self) unnamed_addr #0 !guid !336 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsccF2givDBH6_8patterns(i64 %self) #22
; call <core::num::nonzero::NonZero<usize>>::get
  %_0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCsccF2givDBH6_8patterns(i64 %_2) #22
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::next_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !337 {
start:
  %value = load i64, ptr %self, align 8
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCsccF2givDBH6_8patterns(i64 %value, i64 1, ptr align 8 @alloc_de9a5d9a80d554992107c1ea3afec081) #23
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i64 %value, 1
  store i64 %_0.i, ptr %self, align 8
  ret i64 %value
}

; <core::ops::index_range::IndexRange>::end
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !338 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !339 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_2 = load i64, ptr %0, align 8
  %_3 = load i64, ptr %self, align 8
  %_0 = sub nuw i64 %_2, %_3
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::start
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !340 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::zero_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCsccF2givDBH6_8patterns(i64 %end) unnamed_addr #0 !guid !341 {
start:
  %0 = insertvalue { i64, i64 } { i64 0, i64 poison }, i64 %end, 1
  ret { i64, i64 } %0
}

; <*mut u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !342 {
start:
; call <*const u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %self, ptr %origin, ptr align 8 %0) #22
  ret i64 %_0
}

; <*mut u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !343 {
start:
; call <*const u8>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCsccF2givDBH6_8patterns(ptr %self) #22
  ret i1 %_0
}

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !344 {
start:
; call <*const ()>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCsccF2givDBH6_8patterns(ptr %self) #22
  ret i1 %_0
}

; <*const u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !345 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 1
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCsccF2givDBH6_8patterns(ptr %self, ptr %origin, ptr align 8 %0) #23
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #26
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 1, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 1
  ret i64 %_0
}

; <*const u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !346 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCsccF2givDBH6_8patterns(ptr %self) #22
  ret i1 %_0
}

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCsccF2givDBH6_8patterns(ptr %self, i64 %align) unnamed_addr #0 !guid !347 {
start:
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i1 = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i1, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_fad0cd83b7d1858a846a172eb260e593, i64 42) #22
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 @alloc_7abc4ceda2d1d9be88f00c5dc522bc84) #26
  unreachable

bb2:                                              ; preds = %start
  %_0.i = ptrtoint ptr %self to i64
  %_8 = sub i64 %align, 1
  %_6 = and i64 %_0.i, %_8
  %_0 = icmp eq i64 %_6, 0
  ret i1 %_0
}

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !348 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCsccF2givDBH6_8patterns(ptr %self) #22
  ret i1 %_0
}

; <char>::encode_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc11encode_utf8CsccF2givDBH6_8patterns(i32 %self, ptr %dst.0, i64 %dst.1) unnamed_addr #0 !guid !349 {
start:
; call core::char::methods::encode_utf8_raw
  %0 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core4char7methods15encode_utf8_rawCsccF2givDBH6_8patterns(i32 %self, ptr %dst.0, i64 %dst.1) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked_mut
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts23from_utf8_unchecked_mutCsccF2givDBH6_8patterns(ptr %_3.0, i64 %_3.1) #22
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <char>::is_whitespace
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc13is_whitespaceCsccF2givDBH6_8patterns(i32 %self) unnamed_addr #0 !guid !350 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = icmp eq i32 %self, 32
  br i1 %0, label %bb7, label %bb2

bb7:                                              ; preds = %bb3, %start
  store i8 1, ptr %_0, align 1
  br label %bb8

bb2:                                              ; preds = %start
  %_2 = icmp ule i32 9, %self
  br i1 %_2, label %bb3, label %bb1

bb1:                                              ; preds = %bb3, %bb2
  %_4 = icmp ule i32 0, %self
  br i1 %_4, label %bb6, label %bb4

bb3:                                              ; preds = %bb2
  %_3 = icmp ule i32 %self, 13
  br i1 %_3, label %bb7, label %bb1

bb4:                                              ; preds = %bb6, %bb1
; call core::unicode::unicode_data::white_space::lookup
  %1 = call zeroext i1 @_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space6lookupCsccF2givDBH6_8patterns(i32 %self) #22
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_0, align 1
  br label %bb8

bb6:                                              ; preds = %bb1
  %_5 = icmp ule i32 %self, 132
  br i1 %_5, label %bb5, label %bb4

bb5:                                              ; preds = %bb6
  store i8 0, ptr %_0, align 1
  br label %bb8

bb8:                                              ; preds = %bb7, %bb5, %bb4
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4
}

; <char>::from_u32_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc18from_u32_uncheckedCsccF2givDBH6_8patterns(i32 %i) unnamed_addr #0 !guid !351 {
start:
; call core::char::convert::from_u32_unchecked
  %_0 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert18from_u32_uncheckedCsccF2givDBH6_8patterns(i32 %i, ptr align 8 @alloc_9e5c5064a9cc4d3581a4b435ddfc6bf3) #22
  ret i32 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %self, i32 %radix) unnamed_addr #0 !guid !352 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #22
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #26
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !353 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsccF2givDBH6_8patterns(i64 %_3) #22
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCsccF2givDBH6_8patterns(i64 %_2) #22
  ret ptr %_0
}

; <core::alloc::layout::Layout>::repeat_packed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %n) unnamed_addr #0 !guid !354 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %0, align 8
; call <usize>::checked_mul
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCsccF2givDBH6_8patterns(i64 %_4, i64 %n) #22
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %size = load i64, ptr %8, align 8
  %_7 = load i64, ptr %self, align 8
; call <core::alloc::layout::Layout>::from_size_alignment
  %9 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCsccF2givDBH6_8patterns(i64 %size, i64 %_7) #22
  %10 = extractvalue { i64, i64 } %9, 0
  %11 = extractvalue { i64, i64 } %9, 1
  store i64 %10, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %13 = load i64, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { i64, i64 } poison, i64 %13, 0
  %17 = insertvalue { i64, i64 } %16, i64 %15, 1
  ret { i64, i64 } %17

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCsccF2givDBH6_8patterns(i64 %size, i64 %alignment) unnamed_addr #0 !guid !355 {
start:
  %_0 = alloca [16 x i8], align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 %alignment, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %size, ptr %0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <core::alloc::layout::Layout>::is_size_align_valid
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCsccF2givDBH6_8patterns(i64 %size, i64 %align) unnamed_addr #0 !guid !356 {
start:
  %_4 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
; call <core::mem::alignment::Alignment>::new
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCsccF2givDBH6_8patterns(i64 %align) #22
  store i64 %0, ptr %_4, align 8
  %1 = load i64, ptr %_4, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %alignment = load i64, ptr %_4, align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %4 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_align_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCsccF2givDBH6_8patterns(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !357 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %size, i64 %align, ptr align 8 %0) #23
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %align, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsccF2givDBH6_8patterns(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !358 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %size, i64 %alignment, ptr align 8 %0) #23
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !359 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::align
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !360 {
start:
  %_2 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_usize
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCsccF2givDBH6_8patterns(i64 %_2) #22
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !361 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::array::iter::IntoIter<&[i32], 4>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterRSlKj4_E10unsize_mutCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !362 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 4, 1
  ret { ptr, i64 } %1
}

; <core::array::iter::IntoIter<i64, 7>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterxKj7_E10unsize_mutCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !363 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 7, 1
  ret { ptr, i64 } %1
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsccF2givDBH6_8patterns(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !364 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsccF2givDBH6_8patterns(i64 %3, i64 %5, i1 zeroext %8) #22
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsccF2givDBH6_8patterns(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !365 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsccF2givDBH6_8patterns(ptr %2, i64 %4, i64 %6) #22
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsccF2givDBH6_8patterns(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !366 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCsccF2givDBH6_8patterns(ptr %_6, i64 0) #22
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsccF2givDBH6_8patterns(i64 %11, i64 %13) #22
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsccF2givDBH6_8patterns(i64 %15, i64 %17) #22
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCsccF2givDBH6_8patterns(ptr %_12) #22
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECsccF2givDBH6_8patterns(ptr %_11) #22
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCsccF2givDBH6_8patterns(ptr %_10) #22
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCsccF2givDBH6_8patterns(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #22
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCsccF2givDBH6_8patterns(ptr %ptr, i64 %size) #22
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsccF2givDBH6_8patterns(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !367 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsccF2givDBH6_8patterns(ptr %ptr, i64 %3, i64 %5) #22
  br label %bb3
}

; <alloc::raw_vec::RawVec<patterns::Shape>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !368 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<patterns::Shape>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCsccF2givDBH6_8patterns5ShapeEBG_(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inCsccF2givDBH6_8patterns(ptr %ptr, i64 %capacity2) #22
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<patterns::Shape>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE3ptrBO_(ptr align 8 %self) unnamed_addr #0 !guid !369 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<patterns::Shape>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCsccF2givDBH6_8patterns5ShapeEBY_(ptr align 8 %self) #22
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u8>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !370 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u8>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECsccF2givDBH6_8patterns(ptr align 8 %self) #22
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !371 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCsccF2givDBH6_8patterns(ptr align 8 %self, i64 1) #22
  ret i64 %_0
}

; <i32>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCsccF2givDBH6_8patterns(i32 %self, i32 %rhs) unnamed_addr #0 !guid !372 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsccF2givDBH6_8patterns(i32 %self, i32 %rhs) unnamed_addr #0 !guid !373 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_subCsccF2givDBH6_8patterns(i32 %self, i32 %rhs) unnamed_addr #0 !guid !374 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsccF2givDBH6_8patterns(i32 %self) unnamed_addr #0 !guid !375 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsccF2givDBH6_8patterns(i32 %self) #22
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsccF2givDBH6_8patterns(i32 %self) unnamed_addr #0 !guid !376 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCsccF2givDBH6_8patterns(i64 %addr) unnamed_addr #0 !guid !377 {
start:
  %_0 = inttoptr i64 %addr to ptr
  ret ptr %_0
}

; <core::ptr::unique::Unique<patterns::Shape>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCsccF2givDBH6_8patterns5ShapeE15as_non_null_ptrBS_(ptr %self) unnamed_addr #0 !guid !378 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<[patterns::Shape]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCsccF2givDBH6_8patterns5ShapeE6as_ptrBT_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !379 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::unique::Unique<u8>>::from_non_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCsccF2givDBH6_8patterns(ptr %pointer) unnamed_addr #0 !guid !380 {
start:
  ret ptr %pointer
}

; <core::ptr::unique::Unique<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13new_uncheckedCsccF2givDBH6_8patterns(ptr %ptr) unnamed_addr #0 !guid !381 {
start:
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_2 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCsccF2givDBH6_8patterns(ptr %ptr, ptr align 8 @alloc_8e8e5d43991787ef9fba0c8fe53b59fb) #22
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !382 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<(&str, i32)>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionTRelEEE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !383 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !384 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&patterns::Shape>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtCsccF2givDBH6_8patterns5ShapeE8from_refBW_(ptr align 8 %r) unnamed_addr #0 !guid !385 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&[i32]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSlE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !386 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&str>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullReE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !387 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&i32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRlE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !388 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[patterns::Shape]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE8from_refBW_(ptr align 8 %r.0, i64 %r.1) unnamed_addr #0 !guid !389 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCsccF2givDBH6_8patterns(ptr %ptr.0, i64 %ptr.1, ptr align 8 %0) unnamed_addr #0 !guid !390 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %ptr.1, 1
  ret { ptr, i64 } %2

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCsccF2givDBH6_8patterns(ptr %ptr.0, ptr align 8 %0) #23
  br label %bb3
}

; <core::ptr::non_null::NonNull<[u8]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCsccF2givDBH6_8patterns(ptr %r.0, i64 %r.1) unnamed_addr #0 !guid !391 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[i32]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSlE8from_refCsccF2givDBH6_8patterns(ptr align 4 %r.0, i64 %r.1) unnamed_addr #0 !guid !392 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCsccF2givDBH6_8patterns(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !393 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCsccF2givDBH6_8patterns(ptr %ptr, ptr align 8 %0) #23
  br label %bb3
}

; <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %self, ptr %subtracted) unnamed_addr #0 !guid !394 {
start:
; call <*mut u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #22
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCsccF2givDBH6_8patterns(ptr %ptr) unnamed_addr #0 !guid !395 {
start:
  %_0 = alloca [8 x i8], align 8
; call <*mut u8>::is_null
  %_2 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCsccF2givDBH6_8patterns(ptr %ptr) #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCsccF2givDBH6_8patterns(ptr %ptr, ptr align 8 @alloc_e469ef44bf39c45bcb672a4bc963b9cb) #22
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <core::ptr::non_null::NonNull<u8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refCsccF2givDBH6_8patterns(ptr %r) unnamed_addr #0 !guid !396 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<usize>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !397 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCsccF2givDBH6_8patterns(ptr align 4 %r) unnamed_addr #0 !guid !398 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCsccF2givDBH6_8patterns(ptr align 4 %r) unnamed_addr #0 !guid !399 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i16>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsccF2givDBH6_8patterns(ptr align 2 %r) unnamed_addr #0 !guid !400 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCsccF2givDBH6_8patterns(ptr align 8 %r) unnamed_addr #0 !guid !401 {
start:
  ret ptr %r
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsccF2givDBH6_8patterns(i64 %val) unnamed_addr #0 !guid !402 {
start:
  ret i64 %val
}

; <core::num::niche_types::UsizeNoHighBit>::as_inner
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCsccF2givDBH6_8patterns(i64 %self) unnamed_addr #0 !guid !403 {
start:
  ret i64 %self
}

; <core::slice::iter::Iter<u8>>::next_back_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs2H_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhE19next_back_uncheckedCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !404 {
start:
  %_0.i.i = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %_3 = alloca [8 x i8], align 8
  %_10.i = getelementptr inbounds i8, ptr %self, i64 8
  %_12.i = load ptr, ptr %_10.i, align 8
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_2.i, label %bb2.i, label %_RNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg.exit

bb2.i:                                            ; preds = %start
; call <isize>::unchecked_neg::precondition_check
  call void @_RNvNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg18precondition_checkCsccF2givDBH6_8patterns(i64 1, ptr align 8 @alloc_91bad026f8df33e69ba6aca06b3a4c87) #23
  br label %_RNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg.exit

_RNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg.exit: ; preds = %start, %bb2.i
  %_3.i1.i = getelementptr inbounds i8, ptr %_12.i, i64 -1
  store ptr %_3.i1.i, ptr %_0.i.i, align 8
  %0 = load ptr, ptr %_0.i.i, align 8
  store ptr %0, ptr %_10.i, align 8
  %1 = load ptr, ptr %_10.i, align 8
  store ptr %1, ptr %_0.i, align 8
  %2 = load ptr, ptr %_0.i, align 8
  store ptr %2, ptr %_3, align 8
  %_4.i = load ptr, ptr %_3, align 8
  ret ptr %_4.i
}

; <alloc::raw_vec::RawVecInner>::needs_to_grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #0 !guid !405 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %elem_layout) #22
; call <alloc::raw_vec::RawVecInner>::capacity
  %_6 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %_7) #22
  %_0.i = sub i64 %_6, %len
  %_0 = icmp ugt i64 %additional, %_0.i
  ret i1 %_0
}

; <alloc::raw_vec::RawVecInner>::current_memory
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %0, i64 %1) unnamed_addr #0 !guid !406 {
start:
  %_17 = alloca [24 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %elem_layout) #22
  %_3 = icmp eq i64 %_4, 0
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_7 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCsccF2givDBH6_8patterns(i64 %_8) #22
  %_6 = icmp eq i64 %_7, 0
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb2, %start
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %3, align 8
  br label %bb12

bb5:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %elem_layout) #22
  %_13 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_12 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCsccF2givDBH6_8patterns(i64 %_13) #22
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

bb2.i:                                            ; preds = %bb5
; call <usize>::unchecked_mul::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCsccF2givDBH6_8patterns(i64 %_10, i64 %_12, ptr align 8 @alloc_85bcb8feb56634093aba2b8644936af9) #23
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit: ; preds = %bb5, %bb2.i
  %_0.i = mul nuw i64 %_10, %_12
; call <core::alloc::layout::Layout>::align
  %_15 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCsccF2givDBH6_8patterns(ptr align 8 %elem_layout) #22
; call <core::alloc::layout::Layout>::from_size_align_unchecked
  %4 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCsccF2givDBH6_8patterns(i64 %_0.i, i64 %_15, ptr align 8 @alloc_17de00c3327446355700bd7db4b78ded) #22
  %layout.0 = extractvalue { i64, i64 } %4, 0
  %layout.1 = extractvalue { i64, i64 } %4, 1
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_19 = load ptr, ptr %5, align 8
; call <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
  %_18 = call ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCsccF2givDBH6_8patterns(ptr %_19, ptr align 8 @alloc_b9419d44288097f84422e162822ba96e) #22
  store ptr %_18, ptr %_17, align 8
  %6 = getelementptr inbounds i8, ptr %_17, i64 8
  store i64 %layout.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %layout.1, ptr %7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_17, i64 24, i1 false)
  br label %bb12

bb12:                                             ; preds = %bb4, %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit
  ret void
}

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inCsccF2givDBH6_8patterns(ptr %ptr, i64 %cap) unnamed_addr #0 personality ptr @rust_eh_personality !guid !407 {
start:
; call <core::ptr::unique::Unique<u8>>::new_unchecked
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13new_uncheckedCsccF2givDBH6_8patterns(ptr %ptr) #22
  br label %bb1

bb1:                                              ; preds = %start
  %0 = insertvalue { i64, ptr } poison, i64 %cap, 0
  %1 = insertvalue { i64, ptr } %0, ptr %_4, 1
  ret { i64, ptr } %1

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCsccF2givDBH6_8patterns(i64 %align) unnamed_addr #0 personality ptr @rust_eh_personality !guid !408 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsccF2givDBH6_8patterns(i64 %align) #22
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_4 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCsccF2givDBH6_8patterns(i64 %_5) #22
  br label %bb2

bb2:                                              ; preds = %bb1
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %ptr = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCsccF2givDBH6_8patterns(ptr %_4) #22
  br label %bb3

bb3:                                              ; preds = %bb2
  %0 = insertvalue { i64, ptr } { i64 0, ptr poison }, ptr %ptr, 1
  ret { i64, ptr } %0

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %elem_size) unnamed_addr #0 !guid !409 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 %elem_size, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCsccF2givDBH6_8patterns(i64 %_4) #22
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCsccF2givDBH6_8patterns(ptr %self, i64 %len) unnamed_addr #0 !guid !410 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
  %0 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCsccF2givDBH6_8patterns(ptr %self, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEj4_E13new_uncheckedCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 8 %data) unnamed_addr #0 !guid !411 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %data, i64 64, i1 false)
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEj7_E13new_uncheckedCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 8 %data) unnamed_addr #0 !guid !412 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %data, i64 56, i1 false)
  ret void
}

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #1 !guid !413 {
start:
  %_3 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #22
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %ptr = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %layout.0 = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %layout.1 = load i64, ptr %5, align 8
  %_9 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsccF2givDBH6_8patterns(ptr %_9, ptr %ptr, i64 %layout.0, i64 %layout.1) #22
  br label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <isize>::overflowing_neg
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i1 } @_RNvMs3_NtCsl10jNU3mE6R_4core3numi15overflowing_negCsccF2givDBH6_8patterns(i64 %self) unnamed_addr #0 !guid !414 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp eq i64 %self, -9223372036854775808
  br i1 %_3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_4 = sub i64 0, %self
  store i64 %_4, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 0, ptr %2, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 27670116110564327424, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i8, ptr %4, align 8
  %6 = trunc nuw i8 %5 to i1
  %7 = insertvalue { i64, i1 } poison, i64 %3, 0
  %8 = insertvalue { i64, i1 } %7, i1 %6, 1
  ret { i64, i1 } %8
}

; <alloc::raw_vec::RawVec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCsccF2givDBH6_8patterns(i64 %capacity) unnamed_addr #0 !guid !415 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsccF2givDBH6_8patterns(i64 %capacity, i64 1, i64 1) #22
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !416 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECsccF2givDBH6_8patterns(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #22
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr %_7.0, i64 %_7.1) #22
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !417 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsccF2givDBH6_8patterns(ptr %s.0, i64 %s.1) #22
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !418 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
  %_2 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) #22
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !419 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_0 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1) #22
  ret ptr %_0
}

; <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCsccF2givDBH6_8patterns(ptr %data, i64 %len) unnamed_addr #0 !guid !420 {
start:
; call <*mut u8>::cast_slice
  %0 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCsccF2givDBH6_8patterns(ptr %data, i64 %len) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCsccF2givDBH6_8patterns(ptr %_3.0, i64 %_3.1, ptr align 8 @alloc_af3623564924928dd3d563c9d84a8a0e) #22
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::slice::iter::Iter<patterns::Shape>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterNtCsccF2givDBH6_8patterns5ShapeE3newBQ_(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !421 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[patterns::Shape]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE8from_refBW_(ptr align 8 %slice.0, i64 %slice.1) #22
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[patterns::Shape]>>::cast::<patterns::Shape>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsccF2givDBH6_8patterns5ShapeE4castBV_EBX_(ptr %_4.0, i64 %_4.1) #22
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw %Shape, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !422 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[u8]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECsccF2givDBH6_8patterns(ptr %_4.0, i64 %_4.1) #22
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i8, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<i32>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterlE3newCsccF2givDBH6_8patterns(ptr align 4 %slice.0, i64 %slice.1) unnamed_addr #0 !guid !423 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[i32]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSlE8from_refCsccF2givDBH6_8patterns(ptr align 4 %slice.0, i64 %slice.1) #22
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[i32]>>::cast::<i32>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4castlECsccF2givDBH6_8patterns(ptr %_4.0, i64 %_4.1) #22
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i32, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::try_allocate_in
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, i64 %capacity, i1 zeroext %init, i64 %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !424 {
start:
  %_32 = alloca [1 x i8], align 1
  %_31 = alloca [1 x i8], align 1
  %result = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %layout = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  %alloc = alloca [0 x i8], align 1
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_31, align 1
  store i8 0, ptr %_32, align 1
  store i8 1, ptr %_31, align 1
  %3 = load i64, ptr %elem_layout, align 8
  %4 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_6, i64 %capacity, i64 %3, i64 %5) #22
  br label %bb1

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %_6, align 8
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCsccF2givDBH6_8patterns(i64 0, i64 undef, ptr align 8 @alloc_099d793709fa470a3d5e7c79c938e035) #22
  %_9.0 = extractvalue { i64, i64 } %7, 0
  %_9.1 = extractvalue { i64, i64 } %7, 1
  br label %bb5

bb4:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %_6, i64 8
  %layout.0 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %layout.1 = load i64, ptr %9, align 8
  store i64 %layout.0, ptr %layout, align 8
  %10 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %layout.1, ptr %10, align 8
; call <core::alloc::layout::Layout>::size
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
  br label %bb6

bb6:                                              ; preds = %bb4
  %_11 = icmp eq i64 %_12, 0
  br i1 %_11, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  %_19 = zext i1 %init to i64
  %11 = trunc nuw i64 %_19 to i1
  br i1 %11, label %bb11, label %bb12

bb7:                                              ; preds = %bb6
  store i8 0, ptr %_31, align 1
  store i8 1, ptr %_32, align 1
; call <core::alloc::layout::Layout>::alignment
  %_16 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsccF2givDBH6_8patterns(ptr align 8 %elem_layout) #22
  br label %bb8

bb11:                                             ; preds = %bb10
  %12 = load i64, ptr %layout, align 8
  %13 = getelementptr inbounds i8, ptr %layout, i64 8
  %14 = load i64, ptr %13, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
  %15 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCsccF2givDBH6_8patterns(ptr %alloc, i64 %12, i64 %14) #22
  %16 = extractvalue { ptr, i64 } %15, 0
  %17 = extractvalue { ptr, i64 } %15, 1
  store ptr %16, ptr %result, align 8
  %18 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb28

bb12:                                             ; preds = %bb10
  %19 = load i64, ptr %layout, align 8
  %20 = getelementptr inbounds i8, ptr %layout, i64 8
  %21 = load i64, ptr %20, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %22 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsccF2givDBH6_8patterns(ptr %alloc, i64 %19, i64 %21) #22
  %23 = extractvalue { ptr, i64 } %22, 0
  %24 = extractvalue { ptr, i64 } %22, 1
  store ptr %23, ptr %result, align 8
  %25 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %24, ptr %25, align 8
  br label %bb29

bb29:                                             ; preds = %bb12
  br label %bb13

bb13:                                             ; preds = %bb28, %bb29
  %26 = load ptr, ptr %result, align 8
  %27 = getelementptr inbounds i8, ptr %result, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = ptrtoint ptr %26 to i64
  %30 = icmp eq i64 %29, 0
  %_22 = select i1 %30, i64 1, i64 0
  %31 = trunc nuw i64 %_22 to i1
  br i1 %31, label %bb14, label %bb15

bb28:                                             ; preds = %bb11
  br label %bb13

bb14:                                             ; preds = %bb13
  %_25.0 = load i64, ptr %layout, align 8
  %32 = getelementptr inbounds i8, ptr %layout, i64 8
  %_25.1 = load i64, ptr %32, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %33 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCsccF2givDBH6_8patterns(i64 %_25.0, i64 %_25.1, ptr align 8 @alloc_33dfd402c6ecbe2e6a32e76edf5f31a5) #22
  %_24.0 = extractvalue { i64, i64 } %33, 0
  %_24.1 = extractvalue { i64, i64 } %33, 1
  br label %bb16

bb15:                                             ; preds = %bb13
  %ptr.0 = load ptr, ptr %result, align 8
  %34 = getelementptr inbounds i8, ptr %result, i64 8
  %ptr.1 = load i64, ptr %34, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_28 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECsccF2givDBH6_8patterns(ptr %ptr.0, i64 %ptr.1) #22
  br label %bb17

bb17:                                             ; preds = %bb15
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_27 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCsccF2givDBH6_8patterns(ptr %_28) #22
  br label %bb18

bb18:                                             ; preds = %bb17
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_29 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsccF2givDBH6_8patterns(i64 %capacity) #22
  br label %bb19

bb19:                                             ; preds = %bb18
  store i8 0, ptr %_31, align 1
  %35 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29, ptr %35, align 8
  %36 = getelementptr inbounds i8, ptr %35, i64 8
  store ptr %_27, ptr %36, align 8
  store i64 0, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb23, %bb20, %bb19
  ret void

bb16:                                             ; preds = %bb14
  %37 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_24.0, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %37, i64 8
  store i64 %_24.1, ptr %38, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb20:                                             ; preds = %bb5, %bb9, %bb16
  %39 = load i8, ptr %_31, align 1
  %40 = trunc nuw i8 %39 to i1
  br i1 %40, label %bb23, label %bb21

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_32, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %41 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCsccF2givDBH6_8patterns(i64 %_16) #22
  %_14.0 = extractvalue { i64, ptr } %41, 0
  %_14.1 = extractvalue { i64, ptr } %41, 1
  br label %bb9

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_32, align 1
  %42 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_14.0, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %42, i64 8
  store ptr %_14.1, ptr %43, align 8
  store i64 0, ptr %_0, align 8
  br label %bb20

bb5:                                              ; preds = %bb3
  %44 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_9.0, ptr %44, align 8
  %45 = getelementptr inbounds i8, ptr %44, i64 8
  store i64 %_9.1, ptr %45, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb23:                                             ; preds = %bb20
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable

bb25:                                             ; No predecessors!
  unreachable

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsccF2givDBH6_8patterns(i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !425 {
start:
  %this = alloca [16 x i8], align 8
  %_4 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::try_allocate_in
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_4, i64 %capacity, i1 zeroext false, i64 %elem_layout.0, i64 %elem_layout.1)
  %_6 = load i64, ptr %_4, align 8
  %0 = trunc nuw i64 %_6 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  %err.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %err.1 = load i64, ptr %2, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #28
  unreachable

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load ptr, ptr %5, align 8
  store i64 %4, ptr %this, align 8
  %7 = getelementptr inbounds i8, ptr %this, i64 8
  store ptr %6, ptr %7, align 8
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_10 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCsccF2givDBH6_8patterns(ptr align 8 %this, i64 0, i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) #22
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = xor i1 %_10, true
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb5
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsccF2givDBH6_8patterns(i1 zeroext %_9, ptr align 8 @alloc_51424262946dd0794fad6132df857999) #23
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb5, %bb2.i
  br label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_0.0 = load i64, ptr %this, align 8
  %8 = getelementptr inbounds i8, ptr %this, i64 8
  %_0.1 = load ptr, ptr %8, align 8
  %9 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %10 = insertvalue { i64, ptr } %9, ptr %_0.1, 1
  ret { i64, ptr } %10

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<[patterns::Shape]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeE23into_raw_with_allocatorBK_(ptr align 8 %b.0, i64 %b.1) unnamed_addr #0 !guid !426 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE3newB1G_(ptr align 8 %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE6as_mutB1G_(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[patterns::Shape]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsccF2givDBH6_8patterns5ShapeEE6as_refB1G_(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEE4nextCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !427 {
start:
; call <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self.0) #22
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_5.0 = getelementptr inbounds i8, ptr %self.0, i64 16
; call <core::option::Option<usize>>::map::<&[i32], <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next::{closure#0}>
  %1 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapRSlNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBZ_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECsccF2givDBH6_8patterns(i64 %_2.0, i64 %_2.1, ptr align 8 %_5.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEE4nextCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !428 {
start:
; call <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self.0) #22
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_5.0 = getelementptr inbounds i8, ptr %self.0, i64 16
; call <core::option::Option<usize>>::map::<i64, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next::{closure#0}>
  %1 = call { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapxNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBX_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxEE4next0ECsccF2givDBH6_8patterns(i64 %_2.0, i64 %_2.1, ptr align 8 %_5.0, i64 %self.1) #22
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsccF2givDBH6_8patterns(ptr %self) unnamed_addr #0 !guid !429 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCsccF2givDBH6_8patterns(i64 %self, i64 %rhs) unnamed_addr #0 !guid !430 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCsccF2givDBH6_8patterns(i64 %self, i64 %rhs) unnamed_addr #0 !guid !431 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCsccF2givDBH6_8patterns(i64 %self, i64 %other) unnamed_addr #0 !guid !432 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsccF2givDBH6_8patterns(i32 %_0.i) #22
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <alloc::vec::Vec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !433 {
start:
; call <alloc::raw_vec::RawVec<u8>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCsccF2givDBH6_8patterns(i64 %capacity) #22
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsccF2givDBH6_8patterns(i8 %0) unnamed_addr #0 !guid !434 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsccF2givDBH6_8patterns(ptr %self) #22
  ret i32 %_0
}

; <alloc::vec::Vec<patterns::Shape>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE10as_mut_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !435 {
start:
; call <alloc::raw_vec::RawVec<patterns::Shape>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE3ptrBO_(ptr align 8 %self) #22
  ret ptr %_0
}

; <alloc::vec::Vec<patterns::Shape>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !436 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCsccF2givDBH6_8patterns(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #23
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<patterns::Shape>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) #22
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<patterns::Shape>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE6as_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !437 {
start:
; call <alloc::raw_vec::RawVec<patterns::Shape>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeE3ptrBO_(ptr align 8 %self) #22
  ret ptr %_2
}

; <alloc::vec::Vec<patterns::Shape>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE8as_sliceBG_(ptr align 8 %self) unnamed_addr #0 !guid !438 {
start:
; call <alloc::vec::Vec<patterns::Shape>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE6as_ptrBG_(ptr align 8 %self) #22
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !439 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !440 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 9223372036854775807
  ret i64 %len
}

; <alloc::vec::Vec<u8>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE6as_ptrCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !441 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  ret ptr %_2
}

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !442 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCsccF2givDBH6_8patterns(ptr align 8 %self) #22
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCsccF2givDBH6_8patterns(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #23
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !443 {
start:
; call <alloc::vec::Vec<u8>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE6as_ptrCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !444 {
start:
; call <alloc::raw_vec::RawVec<u8>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  ret i64 %_0
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitRSlEj4_EE4dropCsccF2givDBH6_8patterns(ptr align 8 %slot) unnamed_addr #0 !guid !445 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitRSlEj4_EECsccF2givDBH6_8patterns(ptr align 8 %_3)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitxEj7_EE4dropCsccF2givDBH6_8patterns(ptr align 8 %slot) unnamed_addr #0 !guid !446 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE6as_mutCsccF2givDBH6_8patterns(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitxEj7_EECsccF2givDBH6_8patterns(ptr align 8 %_3)
  ret void
}

; <*mut patterns::Shape>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCsccF2givDBH6_8patterns5Shape10cast_sliceBG_(ptr %self, i64 %len) unnamed_addr #0 !guid !447 {
start:
; call core::ptr::slice_from_raw_parts_mut::<patterns::Shape>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCsccF2givDBH6_8patterns5ShapeEBT_(ptr %self, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCsccF2givDBH6_8patterns(ptr %self, i64 %len) unnamed_addr #0 !guid !448 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECsccF2givDBH6_8patterns(ptr %self, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*const u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh10cast_sliceCsccF2givDBH6_8patterns(ptr %self, i64 %len) unnamed_addr #0 !guid !449 {
start:
; call core::ptr::slice_from_raw_parts::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECsccF2givDBH6_8patterns(ptr %self, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCsccF2givDBH6_8patterns(i64 %self) unnamed_addr #0 !guid !450 {
start:
  ret i64 %self
}

; <i32>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl14from_str_radixCsccF2givDBH6_8patterns(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !451 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
  %1 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %2, 0
  %_3.1 = extractvalue { ptr, i64 } %2, 1
; call <i32>::from_ascii_bytes_radix_impl
  %3 = call i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl27from_ascii_bytes_radix_implCsccF2givDBH6_8patterns(ptr %_3.0, i64 %_3.1, i32 %radix) #22
  store i64 %3, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %4 = load i64, ptr %_0, align 4
  ret i64 %4
}

; <i32>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl27from_ascii_bytes_radix_implCsccF2givDBH6_8patterns(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !452 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [8 x i8], align 4
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [8 x i8], align 4
  %_74 = alloca [8 x i8], align 4
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [8 x i8], align 4
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [4 x i8], align 4
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #26
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCsccF2givDBH6_8patterns(ptr %src.0, i64 %src.1) #22
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i64, ptr %_0, align 4
  ret i64 %4

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %5 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  store i64 %src.1, ptr %6, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %7 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %8 = load i8, ptr %7, align 1
  switch i8 %8, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %9 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %rest.1, ptr %10, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %11 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %12 = sub i64 %src.1, 1
  store ptr %11, ptr %rest, align 8
  %13 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %12, ptr %13, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %14 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %14 to i1
  %15 = getelementptr inbounds i8, ptr %_12, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = getelementptr inbounds i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  store ptr %16, ptr %digits, align 8, !captures !249
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %18, ptr %19, align 8
  store i32 0, ptr %result, align 4
  %_24.0 = load ptr, ptr %digits, align 8
  %20 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %20, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit

bb1.i:                                            ; preds = %bb15
  %21 = icmp ule i64 %_24.1, 7
  %22 = zext i1 %21 to i8
  store i8 %22, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit: ; preds = %bb2.i, %bb1.i
  %23 = load i8, ptr %_0.i, align 1
  %24 = trunc nuw i8 %23 to i1
  br i1 %24, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %25 = load ptr, ptr %rest, align 8
  %26 = getelementptr inbounds i8, ptr %rest, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %25, ptr %28, align 8
  %29 = getelementptr inbounds i8, ptr %28, i64 8
  store i64 %27, ptr %29, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsccF2givDBH6_8patterns.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %30 = load ptr, ptr %digits, align 8
  %31 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %31, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %32 = load ptr, ptr %digits, align 8
  %33 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %33, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i32, ptr %result, align 4
  %34 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_105, ptr %34, align 4
  store i8 0, ptr %_0, align 4
  br label %bb53

bb42:                                             ; preds = %bb41
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %37 = load i64, ptr %36, align 8
  %c = getelementptr inbounds nuw i8, ptr %35, i64 0
  %38 = load ptr, ptr %digits, align 8
  %39 = getelementptr inbounds i8, ptr %digits, i64 8
  %40 = load i64, ptr %39, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %38, i64 1
  %rest.13 = sub i64 %40, 1
  %_85 = load i32, ptr %result, align 4
; call <i32>::checked_mul
  %41 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsccF2givDBH6_8patterns(i32 %_85, i32 %radix) #22
  %42 = extractvalue { i32, i32 } %41, 0
  %43 = extractvalue { i32, i32 } %41, 1
  store i32 %42, ptr %mul1, align 4
  %44 = getelementptr inbounds i8, ptr %mul1, i64 4
  store i32 %43, ptr %44, align 4
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %45 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %_89, i32 %radix) #22
  %46 = extractvalue { i32, i32 } %45, 0
  %47 = extractvalue { i32, i32 } %45, 1
  store i32 %46, ptr %_88, align 4
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %47, ptr %48, align 4
  %49 = load i32, ptr %_88, align 4
  %50 = getelementptr inbounds i8, ptr %_88, i64 4
  %51 = load i32, ptr %50, align 4
  %_91 = zext i32 %49 to i64
  %52 = trunc nuw i64 %_91 to i1
  br i1 %52, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %53, align 4
  %54 = load i32, ptr %mul1, align 4
  %55 = getelementptr inbounds i8, ptr %mul1, i64 4
  %56 = load i32, ptr %55, align 4
  %_95 = zext i32 %54 to i64
  %57 = trunc nuw i64 %_95 to i1
  br i1 %57, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %58 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %58, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb48:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %mul1, i64 4
  %value4 = load i32, ptr %59, align 4
  store i32 %value4, ptr %result, align 4
  %_100 = load i32, ptr %result, align 4
; call <i32>::checked_sub
  %60 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_subCsccF2givDBH6_8patterns(i32 %_100, i32 %value) #22
  %61 = extractvalue { i32, i32 } %60, 0
  %62 = extractvalue { i32, i32 } %60, 1
  store i32 %61, ptr %_99, align 4
  %63 = getelementptr inbounds i8, ptr %_99, i64 4
  store i32 %62, ptr %63, align 4
  %64 = load i32, ptr %_99, align 4
  %65 = getelementptr inbounds i8, ptr %_99, i64 4
  %66 = load i32, ptr %65, align 4
  %_101 = zext i32 %64 to i64
  %67 = trunc nuw i64 %_101 to i1
  br i1 %67, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %68 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %68, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb51:                                             ; preds = %bb48
  %69 = getelementptr inbounds i8, ptr %_99, i64 4
  %value5 = load i32, ptr %69, align 4
  store i32 %value5, ptr %result, align 4
  store ptr %rest.02, ptr %digits, align 8, !captures !249
  %70 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %70, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %71 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %71, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb31:                                             ; preds = %bb30
  %72 = load ptr, ptr %digits, align 8
  %73 = getelementptr inbounds i8, ptr %digits, i64 8
  %74 = load i64, ptr %73, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %72, i64 0
  %75 = load ptr, ptr %digits, align 8
  %76 = getelementptr inbounds i8, ptr %digits, i64 8
  %77 = load i64, ptr %76, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %75, i64 1
  %rest.18 = sub i64 %77, 1
  %_60 = load i32, ptr %result, align 4
; call <i32>::checked_mul
  %78 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsccF2givDBH6_8patterns(i32 %_60, i32 %radix) #22
  %79 = extractvalue { i32, i32 } %78, 0
  %80 = extractvalue { i32, i32 } %78, 1
  store i32 %79, ptr %mul, align 4
  %81 = getelementptr inbounds i8, ptr %mul, i64 4
  store i32 %80, ptr %81, align 4
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %82 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %_64, i32 %radix) #22
  %83 = extractvalue { i32, i32 } %82, 0
  %84 = extractvalue { i32, i32 } %82, 1
  store i32 %83, ptr %_63, align 4
  %85 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %84, ptr %85, align 4
  %86 = load i32, ptr %_63, align 4
  %87 = getelementptr inbounds i8, ptr %_63, i64 4
  %88 = load i32, ptr %87, align 4
  %_66 = zext i32 %86 to i64
  %89 = trunc nuw i64 %_66 to i1
  br i1 %89, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %90 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %90, align 4
  %91 = load i32, ptr %mul, align 4
  %92 = getelementptr inbounds i8, ptr %mul, i64 4
  %93 = load i32, ptr %92, align 4
  %_70 = zext i32 %91 to i64
  %94 = trunc nuw i64 %_70 to i1
  br i1 %94, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %95 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %95, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb37:                                             ; preds = %bb35
  %96 = getelementptr inbounds i8, ptr %mul, i64 4
  %value10 = load i32, ptr %96, align 4
  store i32 %value10, ptr %result, align 4
  %_75 = load i32, ptr %result, align 4
; call <i32>::checked_add
  %97 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCsccF2givDBH6_8patterns(i32 %_75, i32 %value9) #22
  %98 = extractvalue { i32, i32 } %97, 0
  %99 = extractvalue { i32, i32 } %97, 1
  store i32 %98, ptr %_74, align 4
  %100 = getelementptr inbounds i8, ptr %_74, i64 4
  store i32 %99, ptr %100, align 4
  %101 = load i32, ptr %_74, align 4
  %102 = getelementptr inbounds i8, ptr %_74, i64 4
  %103 = load i32, ptr %102, align 4
  %_76 = zext i32 %101 to i64
  %104 = trunc nuw i64 %_76 to i1
  br i1 %104, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %105 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %105, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb40:                                             ; preds = %bb37
  %106 = getelementptr inbounds i8, ptr %_74, i64 4
  %value11 = load i32, ptr %106, align 4
  store i32 %value11, ptr %result, align 4
  store ptr %rest.07, ptr %digits, align 8, !captures !249
  %107 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %107, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %108 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %108, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %109 = load ptr, ptr %digits, align 8
  %110 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %110, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %111 = load ptr, ptr %digits, align 8
  %112 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %112, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %113 = load ptr, ptr %digits, align 8
  %114 = getelementptr inbounds i8, ptr %digits, i64 8
  %115 = load i64, ptr %114, align 8
  %c12 = getelementptr inbounds nuw i8, ptr %113, i64 0
  %116 = load ptr, ptr %digits, align 8
  %117 = getelementptr inbounds i8, ptr %digits, i64 8
  %118 = load i64, ptr %117, align 8
  %rest.013 = getelementptr inbounds nuw i8, ptr %116, i64 1
  %rest.114 = sub i64 %118, 1
  %_44 = load i32, ptr %result, align 4
  %119 = mul i32 %_44, %radix
  store i32 %119, ptr %result, align 4
  %_48 = load i8, ptr %c12, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %120 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %_47, i32 %radix) #22
  %121 = extractvalue { i32, i32 } %120, 0
  %122 = extractvalue { i32, i32 } %120, 1
  store i32 %121, ptr %_46, align 4
  %123 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %122, ptr %123, align 4
  %124 = load i32, ptr %_46, align 4
  %125 = getelementptr inbounds i8, ptr %_46, i64 4
  %126 = load i32, ptr %125, align 4
  %_49 = zext i32 %124 to i64
  %127 = trunc nuw i64 %_49 to i1
  br i1 %127, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %128 = getelementptr inbounds i8, ptr %_46, i64 4
  %x = load i32, ptr %128, align 4
  %_53 = load i32, ptr %result, align 4
  %129 = sub i32 %_53, %x
  store i32 %129, ptr %result, align 4
  store ptr %rest.013, ptr %digits, align 8, !captures !249
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.114, ptr %130, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %131 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %131, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb19:                                             ; preds = %bb18
  %132 = load ptr, ptr %digits, align 8
  %133 = getelementptr inbounds i8, ptr %digits, i64 8
  %134 = load i64, ptr %133, align 8
  %c15 = getelementptr inbounds nuw i8, ptr %132, i64 0
  %135 = load ptr, ptr %digits, align 8
  %136 = getelementptr inbounds i8, ptr %digits, i64 8
  %137 = load i64, ptr %136, align 8
  %rest.016 = getelementptr inbounds nuw i8, ptr %135, i64 1
  %rest.117 = sub i64 %137, 1
  %_29 = load i32, ptr %result, align 4
  %138 = mul i32 %_29, %radix
  store i32 %138, ptr %result, align 4
  %_33 = load i8, ptr %c15, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %139 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsccF2givDBH6_8patterns(i32 %_32, i32 %radix) #22
  %140 = extractvalue { i32, i32 } %139, 0
  %141 = extractvalue { i32, i32 } %139, 1
  store i32 %140, ptr %_31, align 4
  %142 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %141, ptr %142, align 4
  %143 = load i32, ptr %_31, align 4
  %144 = getelementptr inbounds i8, ptr %_31, i64 4
  %145 = load i32, ptr %144, align 4
  %_34 = zext i32 %143 to i64
  %146 = trunc nuw i64 %_34 to i1
  br i1 %146, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %147 = getelementptr inbounds i8, ptr %_31, i64 4
  %x18 = load i32, ptr %147, align 4
  %_38 = load i32, ptr %result, align 4
  %148 = add i32 %_38, %x18
  store i32 %148, ptr %result, align 4
  store ptr %rest.016, ptr %digits, align 8, !captures !249
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.117, ptr %149, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %150 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %150, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !453 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsccF2givDBH6_8patterns(ptr align 8 %args) #22
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #22
  ret void
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsccF2givDBH6_8patterns(i64 %0, i64 %1) unnamed_addr #0 !guid !454 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsccF2givDBH6_8patterns(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !455 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #29
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsccF2givDBH6_8patterns(i64 %0, i64 %1) unnamed_addr #0 !guid !456 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsccF2givDBH6_8patterns(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !457 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsccF2givDBH6_8patterns(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #22
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #28
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCsccF2givDBH6_8patterns(ptr %ptr.0, i64 %ptr.1) #22
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; alloc::raw_vec::layout_array
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, i64 %cap, i64 %0, i64 %1) unnamed_addr #0 !guid !458 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::repeat_packed
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCsccF2givDBH6_8patterns(ptr align 8 %elem_layout, i64 %cap) #22
  %_3.0 = extractvalue { i64, i64 } %3, 0
  %_3.1 = extractvalue { i64, i64 } %3, 1
; call <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, i64 %_3.0, i64 %_3.1) #22
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsccF2givDBH6_8patterns() unnamed_addr #3 !guid !459 {
start:
  ret void
}

; core::hint::unreachable_unchecked
; Function Attrs: inlinehint noreturn nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core4hint21unreachable_uncheckedCsccF2givDBH6_8patterns(ptr align 8 %0) unnamed_addr #4 !guid !460 {
start:
; call core::ub_checks::check_language_ub
  %_1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  unreachable

bb2:                                              ; preds = %start
; call core::hint::unreachable_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint21unreachable_unchecked18precondition_checkCsccF2givDBH6_8patterns(ptr align 8 %0) #23
  br label %bb3
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCsccF2givDBH6_8patterns(ptr %ptr, i64 %align) unnamed_addr #0 !guid !461 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCsccF2givDBH6_8patterns(ptr %ptr, i64 %align) #22
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() unnamed_addr #0 !guid !462 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsccF2givDBH6_8patterns() #22
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCsccF2givDBH6_8patterns(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !463 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCsccF2givDBH6_8patterns(ptr %3, ptr %5, i64 %7, i64 %9) #22
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCsccF2givDBH6_8patterns(i64 %size, i64 %len) unnamed_addr #0 !guid !464 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #26
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsccF2givDBH6_8patterns(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !465 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCsccF2givDBH6_8patterns(ptr %ptr, i64 %align) #22
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCsccF2givDBH6_8patterns(ptr %ptr) #22
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::str::validations::utf8_first_byte
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations15utf8_first_byteCsccF2givDBH6_8patterns(i8 %byte, i32 %width) unnamed_addr #0 !guid !466 {
start:
  %0 = and i32 %width, 7
  %1 = trunc i32 %0 to i8
  %_4 = lshr i8 127, %1
  %_3 = and i8 %byte, %_4
  %_0 = zext i8 %_3 to i32
  ret i32 %_0
}

; core::str::validations::utf8_is_cont_byte
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations17utf8_is_cont_byteCsccF2givDBH6_8patterns(i8 %byte) unnamed_addr #0 !guid !467 {
start:
  %_0 = icmp slt i8 %byte, -64
  ret i1 %_0
}

; core::str::validations::utf8_acc_cont_byte
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core3str11validations18utf8_acc_cont_byteCsccF2givDBH6_8patterns(i32 %ch, i8 %byte) unnamed_addr #0 !guid !468 {
start:
  %_3 = shl i32 %ch, 6
  %_5 = and i8 %byte, 63
  %_4 = zext i8 %_5 to i32
  %_0 = or i32 %_3, %_4
  ret i32 %_0
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !469 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::str::converts::from_utf8_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts23from_utf8_unchecked_mutCsccF2givDBH6_8patterns(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !470 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::char::convert::char_try_from_u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert17char_try_from_u32CsccF2givDBH6_8patterns(i32 %i) unnamed_addr #0 !guid !471 {
start:
  %_0 = alloca [4 x i8], align 4
  %_4 = xor i32 %i, 55296
  %_0.i = sub i32 %_4, 2048
  %_2 = icmp uge i32 %_0.i, 1112064
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %i, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  store i32 -1, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::char::convert::from_u32_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert18from_u32_uncheckedCsccF2givDBH6_8patterns(i32 %i, ptr align 8 %0) unnamed_addr #0 !guid !472 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i32 %i

bb2:                                              ; preds = %start
; call core::char::convert::from_u32_unchecked::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core4char7convert18from_u32_unchecked18precondition_checkCsccF2givDBH6_8patterns(i32 %i, ptr align 8 %0) #23
  br label %bb3
}

; core::char::methods::encode_utf8_raw
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core4char7methods15encode_utf8_rawCsccF2givDBH6_8patterns(i32 %code, ptr %dst.0, i64 %dst.1) unnamed_addr #0 !guid !473 {
start:
  %_4.i = alloca [24 x i8], align 8
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CsccF2givDBH6_8patterns(i32 %code) #22
  %_4 = icmp ult i64 %dst.1, %len
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCsccF2givDBH6_8patterns(i32 %code, ptr %dst.0) #22
; call core::slice::raw::from_raw_parts_mut::<u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_muthECsccF2givDBH6_8patterns(ptr %dst.0, i64 %len, ptr align 8 @alloc_6495769d0f8513e66380fb38255e98b4) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_4.i, i64 8
  store i32 %code, ptr %3, align 8
  store i64 %len, ptr %_4.i, align 8
  %4 = getelementptr inbounds i8, ptr %_4.i, i64 16
  store i64 %dst.1, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_4.i, i64 8
  %6 = load i32, ptr %5, align 8
  %7 = load i64, ptr %_4.i, align 8
  %8 = getelementptr inbounds i8, ptr %_4.i, i64 16
  %9 = load i64, ptr %8, align 8
; call core::char::methods::encode_utf8_raw::do_panic::runtime
  call void @_RNvNvNvNtNtCsl10jNU3mE6R_4core4char7methods15encode_utf8_raw8do_panic7runtimeCsccF2givDBH6_8patterns(i32 %6, i64 %7, i64 %9, ptr align 8 @alloc_f20232e75b703e41d96bb787435a1dbc) #27
  unreachable

_RNvNvNtNtCsl10jNU3mE6R_4core4char7methods15encode_utf8_raw8do_panic.exit: ; No predecessors!
  unreachable
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCsccF2givDBH6_8patterns(i32 %code, ptr %dst) unnamed_addr #0 !guid !474 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CsccF2givDBH6_8patterns(i32 %code) #22
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CsccF2givDBH6_8patterns(i32 %code) unnamed_addr #0 !guid !475 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::slice::memchr::memchr_naive
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvNtNtCsl10jNU3mE6R_4core5slice6memchr12memchr_naiveCsccF2givDBH6_8patterns(i8 %x, ptr %text.0, i64 %text.1) unnamed_addr #0 !guid !476 {
start:
  %i = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  store i64 0, ptr %i, align 8
  br label %bb1

bb1:                                              ; preds = %bb5, %start
  %_5 = load i64, ptr %i, align 8
  %_4 = icmp ult i64 %_5, %text.1
  br i1 %_4, label %bb2, label %bb6

bb6:                                              ; preds = %bb1
  store i64 0, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_9 = load i64, ptr %i, align 8
  %_11 = icmp ult i64 %_9, %text.1
  br i1 %_11, label %bb3, label %panic

bb7:                                              ; preds = %bb4, %bb6
  %0 = load i64, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = insertvalue { i64, i64 } poison, i64 %0, 0
  %4 = insertvalue { i64, i64 } %3, i64 %2, 1
  ret { i64, i64 } %4

bb3:                                              ; preds = %bb2
  %5 = getelementptr inbounds nuw i8, ptr %text.0, i64 %_9
  %_8 = load i8, ptr %5, align 1
  %_7 = icmp eq i8 %_8, %x
  br i1 %_7, label %bb4, label %bb5

panic:                                            ; preds = %bb2
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 %text.1, ptr align 8 @alloc_a7e848337f4da91ced55996cfb643467) #26
  unreachable

bb5:                                              ; preds = %bb3
  %6 = load i64, ptr %i, align 8
  %7 = add i64 %6, 1
  store i64 %7, ptr %i, align 8
  br label %bb1

bb4:                                              ; preds = %bb3
  %_12 = load i64, ptr %i, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_12, ptr %8, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7
}

; core::slice::memchr::memchr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvNtNtCsl10jNU3mE6R_4core5slice6memchr6memchrCsccF2givDBH6_8patterns(i8 %x, ptr %text.0, i64 %text.1) unnamed_addr #0 !guid !477 {
start:
  %result = alloca [16 x i8], align 8
  %_4 = icmp ult i64 %text.1, 16
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call core::slice::memchr::memchr_aligned
  %0 = call { i64, i64 } @_RNvNtNtCsl10jNU3mE6R_4core5slice6memchr14memchr_aligned(i8 %x, ptr %text.0, i64 %text.1)
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %result, align 8
  %3 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %2, ptr %3, align 8
  br label %bb3

bb1:                                              ; preds = %start
; call core::slice::memchr::memchr_naive
  %4 = call { i64, i64 } @_RNvNtNtCsl10jNU3mE6R_4core5slice6memchr12memchr_naiveCsccF2givDBH6_8patterns(i8 %x, ptr %text.0, i64 %text.1) #22
  %5 = extractvalue { i64, i64 } %4, 0
  %6 = extractvalue { i64, i64 } %4, 1
  store i64 %5, ptr %result, align 8
  %7 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %6, ptr %7, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %_7 = load i64, ptr %result, align 8
  %8 = getelementptr inbounds i8, ptr %result, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = trunc nuw i64 %_7 to i1
  br i1 %10, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  %11 = getelementptr inbounds i8, ptr %result, i64 8
  %index = load i64, ptr %11, align 8
  %_10 = icmp ult i64 %index, %text.1
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsccF2givDBH6_8patterns(i1 zeroext %_10, ptr align 8 @alloc_2493455d474f4e2949ee4e1a7e153b01) #23
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb4, %bb2.i
  br label %bb5

bb5:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit, %bb3
  %_0.0 = load i64, ptr %result, align 8
  %12 = getelementptr inbounds i8, ptr %result, i64 8
  %_0.1 = load i64, ptr %12, align 8
  %13 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %14 = insertvalue { i64, i64 } %13, i64 %_0.1, 1
  ret { i64, i64 } %14

bb6:                                              ; No predecessors!
  unreachable
}

; core::unicode::unicode_data::white_space::lookup
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space6lookupCsccF2givDBH6_8patterns(i32 %c) unnamed_addr #0 !guid !478 {
start:
  %_0 = alloca [1 x i8], align 1
  %_2 = lshr i32 %c, 8
  switch i32 %_2, label %bb1 [
    i32 0, label %bb5
    i32 22, label %bb4
    i32 32, label %bb3
    i32 48, label %bb2
  ]

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb8

bb5:                                              ; preds = %start
  %_8 = zext i32 %c to i64
  %_7 = and i64 %_8, 255
  %_9 = icmp ult i64 %_7, 256
  br i1 %_9, label %bb6, label %panic

bb4:                                              ; preds = %start
  %0 = icmp eq i32 %c, 5760
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb8

bb3:                                              ; preds = %start
  %_15 = zext i32 %c to i64
  %_14 = and i64 %_15, 255
  %_16 = icmp ult i64 %_14, 256
  br i1 %_16, label %bb7, label %panic1

bb2:                                              ; preds = %start
  %2 = icmp eq i32 %c, 12288
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb8

bb6:                                              ; preds = %bb5
  %4 = getelementptr inbounds nuw i8, ptr @_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space14WHITESPACE_MAP, i64 %_7
  %_5 = load i8, ptr %4, align 1
  %_4 = and i8 %_5, 1
  %5 = icmp ne i8 %_4, 0
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb8

panic:                                            ; preds = %bb5
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_7, i64 256, ptr align 8 @alloc_ee09ed5182ef49c6cba0ade2ac4a17f6) #26
  unreachable

bb8:                                              ; preds = %bb1, %bb2, %bb7, %bb4, %bb6
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  ret i1 %8

bb7:                                              ; preds = %bb3
  %9 = getelementptr inbounds nuw i8, ptr @_RNvNtNtNtCsl10jNU3mE6R_4core7unicode12unicode_data11white_space14WHITESPACE_MAP, i64 %_14
  %_12 = load i8, ptr %9, align 1
  %_11 = and i8 %_12, 2
  %10 = icmp ne i8 %_11, 0
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %_0, align 1
  br label %bb8

panic1:                                           ; preds = %bb3
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_14, i64 256, ptr align 8 @alloc_8acebf40d2a4360b5049d1b9f3d146ab) #26
  unreachable
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %align, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !479 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCsccF2givDBH6_8patterns(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !480 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCsccF2givDBH6_8patterns(ptr %ptr) unnamed_addr #0 !guid !481 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !482 {
start:
; invoke <core::alloc::layout::Layout>::is_size_align_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCsccF2givDBH6_8patterns(i64 %size, i64 %align)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_1be5ea12ba708d9a11b6e93a7d387a75, i64 281)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !483 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCsccF2givDBH6_8patterns(ptr %ptr, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !484 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCsccF2givDBH6_8patterns(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <isize>::unchecked_neg::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs3_NtCsl10jNU3mE6R_4core3numi13unchecked_neg18precondition_checkCsccF2givDBH6_8patterns(i64 %lhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !485 {
start:
; invoke <isize>::overflowing_neg
  %1 = invoke { i64, i1 } @_RNvMs3_NtCsl10jNU3mE6R_4core3numi15overflowing_negCsccF2givDBH6_8patterns(i64 %lhs)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  %_3.0 = extractvalue { i64, i1 } %1, 0
  %_3.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_3.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_dbcce5cb8873847766db4f16f930a00e, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %3, 0
  %_5.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCsccF2givDBH6_8patterns(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !486 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <usize>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCsccF2givDBH6_8patterns(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !487 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCsccF2givDBH6_8patterns(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !488 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCsccF2givDBH6_8patterns(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !489 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCsccF2givDBH6_8patterns(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !490 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsccF2givDBH6_8patterns(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsccF2givDBH6_8patterns(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCsccF2givDBH6_8patterns(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsccF2givDBH6_8patterns(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !491 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::hint::unreachable_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint21unreachable_unchecked18precondition_checkCsccF2givDBH6_8patterns(ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !492 {
start:
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_75fb06c2453febd814e73f5f2e72ae38, i64 199)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  %_2.0 = extractvalue { ptr, ptr } %1, 0
  %_2.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_2.0, ptr %_2.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCsccF2givDBH6_8patterns(ptr %ptr, i64 %align) unnamed_addr #0 !guid !493 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCsccF2givDBH6_8patterns(ptr %ptr, i64 %align) #22
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsccF2givDBH6_8patterns() unnamed_addr #0 !guid !494 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCsccF2givDBH6_8patterns(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !495 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCsccF2givDBH6_8patterns(i64 %size, i64 %count) #22
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCsccF2givDBH6_8patterns(i64 %_0.i2, i64 %_0.i) #22
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #25
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::char::convert::from_u32_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core4char7convert18from_u32_unchecked18precondition_checkCsccF2givDBH6_8patterns(i32 %i, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !496 {
start:
  %_4 = alloca [4 x i8], align 4
; invoke core::char::convert::char_try_from_u32
  %1 = invoke i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert17char_try_from_u32CsccF2givDBH6_8patterns(i32 %i)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb4, %bb1, %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  store i32 %1, ptr %_4, align 4
; invoke <core::result::Result<char, core::char::convert::CharTryFromError>>::is_ok
  %_2 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultcNtNtNtB4_4char7convert16CharTryFromErrorE5is_okCsccF2givDBH6_8patterns(ptr align 4 %_4)
          to label %bb2 unwind label %terminate

bb2:                                              ; preds = %bb1
  br i1 %_2, label %bb3, label %bb4

bb4:                                              ; preds = %bb2
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_4dc07e69e5d34e9d1484dfbbef0bb9b1, i64 174)
          to label %bb5 unwind label %terminate

bb3:                                              ; preds = %bb2
  ret void

bb5:                                              ; preds = %bb4
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::slice::raw::from_raw_parts::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCsccF2givDBH6_8patterns(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !497 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsccF2givDBH6_8patterns(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_a28e8c8fd5088943a8b5d44af697ff83, i64 279)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCsccF2givDBH6_8patterns(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::slice::raw::from_raw_parts_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCsccF2givDBH6_8patterns(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !498 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsccF2givDBH6_8patterns(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_5c1a2f972552229672fc942406cfc298, i64 283)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCsccF2givDBH6_8patterns(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::char::methods::encode_utf8_raw::do_panic::runtime
; Function Attrs: inlinehint noreturn nonlazybind uwtable
define internal void @_RNvNvNvNtNtCsl10jNU3mE6R_4core4char7methods15encode_utf8_raw8do_panic7runtimeCsccF2givDBH6_8patterns(i32 %0, i64 %1, i64 %2, ptr align 8 %3) unnamed_addr #4 !guid !499 {
start:
  %_13 = alloca [16 x i8], align 8
  %_12 = alloca [16 x i8], align 8
  %_11 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %dst_len = alloca [8 x i8], align 8
  %len = alloca [8 x i8], align 8
  %code = alloca [4 x i8], align 4
  store i32 %0, ptr %code, align 4
  store i64 %1, ptr %len, align 8
  store i64 %2, ptr %dst_len, align 8
  store ptr %len, ptr %args, align 8
  %4 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %code, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr %dst_len, ptr %5, align 8
  %_16 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_11, ptr align 8 %_16) #22
  %6 = getelementptr inbounds i8, ptr %args, i64 8
  %_17 = load ptr, ptr %6, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexmECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_12, ptr align 4 %_17) #22
  %7 = getelementptr inbounds i8, ptr %args, i64 16
  %_18 = load ptr, ptr %7, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECsccF2givDBH6_8patterns(ptr sret([16 x i8]) align 8 %_13, ptr align 8 %_18) #22
  %8 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %8, ptr align 8 %_11, i64 16, i1 false)
  %9 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %_12, i64 16, i1 false)
  %10 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %10, ptr align 8 %_13, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<71, 3>
  %11 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj47_Kj3_ECsccF2givDBH6_8patterns(ptr @alloc_2800f9fd9aa1f3e24fde08ad5f3cf8ec, ptr align 8 %args1) #22
  %_5.0 = extractvalue { ptr, ptr } %11, 0
  %_5.1 = extractvalue { ptr, ptr } %11, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 %3) #26
  unreachable
}

; <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %this, i64 %len, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !500 {
start:
  %_3 = icmp ult i64 %this, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_97d92cbf2a68a6ac45a1b13da79836e4, i64 214)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCsccF2givDBH6_8patterns(i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !501 {
start:
  %_3 = icmp ule i64 %end, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_5a8fdd84b3281310cbf6b74bb6bf0065, i64 218)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %start1, i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !502 {
start:
  %_4 = icmp uge i64 %end, %start1
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsccF2givDBH6_8patterns(ptr @alloc_91f2a00ff2cd9cdc4bb205a66832e2bb, i64 219)
          to label %bb4 unwind label %terminate

bb1:                                              ; preds = %start
  %_5 = icmp ule i64 %end, %len
  br i1 %_5, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  ret void

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #21
  unreachable

bb4:                                              ; preds = %bb3
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_7.0, ptr %_7.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <patterns::Shape as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXCsccF2givDBH6_8patternsNtB2_5ShapeNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB2_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !503 {
start:
  %__self_2 = alloca [8 x i8], align 8
  %__self_1 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %_3 = zext i8 %0 to i64
  switch i64 %_3, label %bb1 [
    i64 0, label %bb5
    i64 1, label %bb4
    i64 2, label %bb3
    i64 3, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb5:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %2 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_61b2665611c43956f6751fc9541d260a, i64 6, ptr %__self_0, ptr align 8 @vtable.3)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb6

bb4:                                              ; preds = %start
  %__self_01 = getelementptr inbounds i8, ptr %self, i64 4
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %4, ptr %__self_1, align 8
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr align 8 %f, ptr @alloc_6319043cda67dca378296c9d6ea4e61a, i64 4, ptr @alloc_91e924fd2a69c8524f72852661c5910c, i64 1, ptr %__self_01, ptr align 8 @vtable.4, ptr @alloc_d22b16ed1fc9d86532371a89eda619b7, i64 1, ptr %__self_1, ptr align 8 @vtable.5)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb6

bb3:                                              ; preds = %start
  %__self_02 = getelementptr inbounds i8, ptr %self, i64 1
  %__self_13 = getelementptr inbounds i8, ptr %self, i64 2
  %7 = getelementptr inbounds i8, ptr %self, i64 3
  store ptr %7, ptr %__self_2, align 8
; call <core::fmt::Formatter>::debug_tuple_field3_finish
  %8 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field3_finish(ptr align 8 %f, ptr @alloc_b786fa3e298d0013cbd9d16f11d06f34, i64 3, ptr %__self_02, ptr align 8 @vtable.6, ptr %__self_13, ptr align 8 @vtable.6, ptr %__self_2, ptr align 8 @vtable.7)
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %_0, align 1
  br label %bb6

bb2:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %10 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_59ba7b9f7211443cd55a366616eef46a, i64 5)
  %11 = zext i1 %10 to i8
  store i8 %11, ptr %_0, align 1
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3, %bb4, %bb5
  %12 = load i8, ptr %_0, align 1
  %13 = trunc nuw i8 %12 to i1
  ret i1 %13
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !504 {
start:
; call core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>
  %0 = call { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEECsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_2.0 = extractvalue { i32, i32 } %0, 0
  %_2.1 = extractvalue { i32, i32 } %0, 1
; call <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}>
  %_0 = call i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXNtNtB5_3str4iterNtBU_5CharsNtNtNtNtB5_4iter6traits8iterator8Iterator4next0ECsccF2givDBH6_8patterns(i32 %_2.0, i32 %_2.1) #22
  ret i32 %_0
}

; <[u8] as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core5slice3cmpShNtNtB6_3cmp9PartialEq2eqCsccF2givDBH6_8patterns(ptr %self.0, i64 %self.1, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !505 {
start:
  %_0 = alloca [1 x i8], align 1
  %_4 = icmp eq i64 %self.1, %other.1
  br i1 %_4, label %bb1, label %bb4

bb4:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb5

bb1:                                              ; preds = %start
; call <u8 as core::slice::cmp::SlicePartialEq<u8>>::equal_same_length
  %0 = call zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core5slice3cmphINtB5_14SlicePartialEqhE17equal_same_lengthCsccF2givDBH6_8patterns(ptr %self.0, ptr %other.0, i64 %self.1) #22
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb4
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  ret i1 %3
}

; <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: nonlazybind uwtable
define internal i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #1 !guid !506 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_0 = call i64 @_RNvXs1_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtNtNtB9_4iter6traits10exact_size17ExactSizeIterator3lenCsccF2givDBH6_8patterns(ptr align 8 %_3) #22
  ret i64 %_0
}

; <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !507 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitRSlENtB2_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !508 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitRSlE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1, ptr align 8 @alloc_c7037efb906203803aa3ca07167c9120) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitRSlE8is_emptyCsccF2givDBH6_8patterns(ptr align 8 %_3.0, i64 %_3.1) #22
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitRSlE16assume_init_dropCsccF2givDBH6_8patterns.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitRSlE16assume_init_dropCsccF2givDBH6_8patterns.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitRSlE16assume_init_dropCsccF2givDBH6_8patterns.exit: ; preds = %start, %bb2.i
  ret void
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitxENtB2_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !509 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<i64>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitxE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECsccF2givDBH6_8patterns(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1, ptr align 8 @alloc_c7037efb906203803aa3ca07167c9120) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<i64>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitxE8is_emptyCsccF2givDBH6_8patterns(ptr align 8 %_3.0, i64 %_3.1) #22
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitxE16assume_init_dropCsccF2givDBH6_8patterns.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitxE16assume_init_dropCsccF2givDBH6_8patterns.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitxE16assume_init_dropCsccF2givDBH6_8patterns.exit: ; preds = %start, %bb2.i
  ret void
}

; <u8 as core::convert::TryFrom<usize>>::try_from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXNtNtNtCsl10jNU3mE6R_4core7convert3num18ptr_try_from_implshINtB6_7TryFromjE8try_fromCsccF2givDBH6_8patterns(i64 %u) unnamed_addr #0 !guid !510 {
start:
  %_0 = alloca [2 x i8], align 1
  %_2 = icmp ugt i64 %u, 255
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = trunc i64 %u to i8
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_6, ptr %0, align 1
  store i8 0, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %1, align 1
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  %5 = load i8, ptr %4, align 1
  %6 = insertvalue { i1, i8 } poison, i1 %3, 0
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1
  ret { i1, i8 } %7
}

; <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCsccF2givDBH6_8patterns(i64 %kind.0, i64 %kind.1) unnamed_addr #0 !guid !511 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %kind.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %kind.1, 1
  ret { i64, i64 } %1
}

; <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_5CharsNtNtNtNtB9_4iter6traits12double_ended19DoubleEndedIterator9next_backCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !512 {
start:
; call core::str::validations::next_code_point_reverse::<core::slice::iter::Iter<u8>>
  %0 = call { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations23next_code_point_reverseINtNtNtB6_5slice4iter4IterhEECsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_2.0 = extractvalue { i32, i32 } %0, 0
  %_2.1 = extractvalue { i32, i32 } %0, 1
; call <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}>
  %_0 = call i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXs0_NtNtB5_3str4iterNtBX_5CharsNtNtNtNtB5_4iter6traits12double_ended19DoubleEndedIterator9next_back0ECsccF2givDBH6_8patterns(i32 %_2.0, i32 %_2.1) #22
  ret i32 %_0
}

; <[&[i32]; 4] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARSlj4_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !513 {
start:
  %0 = alloca [80 x i8], align 8
  %_2.i = alloca [80 x i8], align 8
  %1 = alloca [80 x i8], align 8
  %2 = alloca [64 x i8], align 8
  %_5 = alloca [80 x i8], align 8
  %inner = alloca [80 x i8], align 8
  %data = alloca [64 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %self, i64 64, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCsccF2givDBH6_8patterns(i64 4) #22
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %data, i64 64, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEj4_E13new_uncheckedCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 8 %2) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 80, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 80, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitRSlEj4_EE3newCsccF2givDBH6_8patterns(ptr sret([80 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 80, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 80, i1 false)
  ret void
}

; <[i64; 7] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAxj7_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !514 {
start:
  %0 = alloca [72 x i8], align 8
  %_2.i = alloca [72 x i8], align 8
  %1 = alloca [72 x i8], align 8
  %2 = alloca [56 x i8], align 8
  %_5 = alloca [72 x i8], align 8
  %inner = alloca [72 x i8], align 8
  %data = alloca [56 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %self, i64 56, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCsccF2givDBH6_8patterns(i64 7) #22
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %data, i64 56, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEj7_E13new_uncheckedCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 8 %2) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 72, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 72, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitxEj7_EE3newCsccF2givDBH6_8patterns(ptr sret([72 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 72, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 72, i1 false)
  ret void
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitRSlEE13get_uncheckedCsccF2givDBH6_8patterns(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !515 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitRSlEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<&[i32]>", ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitRSlEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %self, i64 %_0.i1, ptr align 8 %0) #23
  br label %bb4
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitxEE13get_uncheckedCsccF2givDBH6_8patterns(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !516 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<i64>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitxEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw i64, ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<i64>]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitxEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %self, i64 %_0.i1, ptr align 8 %0) #23
  br label %bb4
}

; <usize as core::slice::index::SliceIndex<[u8]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexShE13get_uncheckedCsccF2givDBH6_8patterns(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !517 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsccF2givDBH6_8patterns() #22
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %self, i64 %_0.i1, ptr align 8 %0) #23
  br label %bb4
}

; <(&str, i32) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTRelENtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !518 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.8)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.0)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsccF2givDBH6_8patterns(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !519 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsccF2givDBH6_8patterns(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #22
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCsccF2givDBH6_8patterns(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !520 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsccF2givDBH6_8patterns(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext true) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsccF2givDBH6_8patterns(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !521 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsccF2givDBH6_8patterns(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<patterns::Shape> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %self) unnamed_addr #1 !guid !522 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCsccF2givDBH6_8patterns(ptr align 8 %self, i64 8, i64 16)
  ret void
}

; <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #1 !guid !523 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCsccF2givDBH6_8patterns(ptr align 8 %self, i64 1, i64 1)
  ret void
}

; <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCsccF2givDBH6_8patterns(ptr %self, ptr align 8 %0) unnamed_addr #0 !guid !524 {
start:
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_0 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCsccF2givDBH6_8patterns(ptr %self) #22
  ret ptr %_0
}

; <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCsccF2givDBH6_8patterns(i64 %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !525 {
start:
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCsccF2givDBH6_8patterns(i64 %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <&str as core::convert::Into<alloc::string::String>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCsl10jNU3mE6R_4core7convertReINtB5_4IntoNtNtCs7CppTae75M1_5alloc6string6StringE4intoCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !526 {
start:
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #22
  ret void
}

; <core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs1_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtNtNtB9_4iter6traits10exact_size17ExactSizeIterator3lenCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !527 {
start:
; call <core::ops::index_range::IndexRange>::len
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  ret i64 %_0
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitRSlEE17get_unchecked_mutCsccF2givDBH6_8patterns(i64 %0, i64 %1, ptr %slice.0, i64 %slice.1, ptr align 8 %2) unnamed_addr #0 !guid !528 {
start:
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ops::index_range::IndexRange>::end
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCsccF2givDBH6_8patterns(ptr align 8 %self) #22
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitRSlEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCsccF2givDBH6_8patterns(i64 %_5, i64 %_0.i, ptr align 8 %2) #23
  br label %bb4

bb4:                                              ; preds = %bb1
; call <core::ops::index_range::IndexRange>::start
  %_8 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCsccF2givDBH6_8patterns(ptr align 8 %self) #22
; call <core::ops::index_range::IndexRange>::len
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %ptr.i = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<&[i32]>", ptr %slice.0, i64 %_8
  %4 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_10, 1
  %_0.0 = extractvalue { ptr, i64 } %5, 0
  %_0.1 = extractvalue { ptr, i64 } %5, 1
  %6 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %_0.1, 1
  ret { ptr, i64 } %7
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitxEE17get_unchecked_mutCsccF2givDBH6_8patterns(i64 %0, i64 %1, ptr %slice.0, i64 %slice.1, ptr align 8 %2) unnamed_addr #0 !guid !529 {
start:
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ops::index_range::IndexRange>::end
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCsccF2givDBH6_8patterns(ptr align 8 %self) #22
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<i64>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitxEECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCsccF2givDBH6_8patterns(i64 %_5, i64 %_0.i, ptr align 8 %2) #23
  br label %bb4

bb4:                                              ; preds = %bb1
; call <core::ops::index_range::IndexRange>::start
  %_8 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCsccF2givDBH6_8patterns(ptr align 8 %self) #22
; call <core::ops::index_range::IndexRange>::len
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %ptr.i = getelementptr inbounds nuw i64, ptr %slice.0, i64 %_8
  %4 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_10, 1
  %_0.0 = extractvalue { ptr, i64 } %5, 0
  %_0.1 = extractvalue { ptr, i64 } %5, 1
  %6 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %_0.1, 1
  ret { ptr, i64 } %7
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEj4_ENtNtNtBb_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !530 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitRSlEj4_NtB4_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEj7_ENtNtNtBb_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !531 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<i64>; 7] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitxEj7_NtB4_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <&patterns::Shape as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtCsccF2givDBH6_8patterns5ShapeNtB6_5Debug3fmtBy_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !532 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <patterns::Shape as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXCsccF2givDBH6_8patternsNtB2_5ShapeNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB2_(ptr align 8 %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !533 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCsccF2givDBH6_8patterns(ptr %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&&str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !534 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <&str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtReNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSlNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !535 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[i32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&(&str, i32) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRTRelENtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !536 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <(&str, i32) as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTRelENtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !537 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <f64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtReNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !538 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !539 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCsccF2givDBH6_8patterns(ptr %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !540 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i32 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 4 %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&u32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRmNtB6_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !541 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u32 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsW_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 4 %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtReNtB6_7Display3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !542 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&i32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRlNtB6_7Display3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !543 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i32 as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <u32 as core::ops::arith::Mul>::mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs25_NtNtCsl10jNU3mE6R_4core3ops5arithmNtB6_3Mul3mulCsccF2givDBH6_8patterns(i32 %self, i32 %other, ptr align 8 %0) unnamed_addr #0 !guid !544 {
start:
  %1 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %other)
  %_3.0 = extractvalue { i32, i1 } %1, 0
  %_3.1 = extractvalue { i32, i1 } %1, 1
  br i1 %_3.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_3.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 %0) #26
  unreachable
}

; <core::slice::iter::Iter<patterns::Shape> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterNtCsccF2givDBH6_8patterns5ShapeENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBR_(ptr align 8 %self) unnamed_addr #0 !guid !545 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<patterns::Shape> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCsccF2givDBH6_8patterns5ShapeENtNtB9_3cmp9PartialEq2eqBV_(ptr align 8 %ptr, ptr align 8 %_11) #22
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw %Shape, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !546 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %ptr, ptr align 8 %_11) #22
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw i8, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !547 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<i32> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllENtNtB9_3cmp9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %ptr, ptr align 8 %_11) #22
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw i32, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8> as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs2K_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits12double_ended19DoubleEndedIterator9next_backCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !548 {
start:
  %end = alloca [8 x i8], align 8
  %_2 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  br label %bb3

bb3:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_6 = load ptr, ptr %0, align 8
  store ptr %_6, ptr %end, align 8
; call <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
  %1 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %end) #22
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_2, align 1
  br label %bb4

bb4:                                              ; preds = %bb3
  %3 = load i8, ptr %_2, align 1
  %4 = trunc nuw i8 %3 to i1
  br i1 %4, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
; call <core::slice::iter::Iter<u8>>::next_back_unchecked
  %_9 = call ptr @_RNvMs2H_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterhE19next_back_uncheckedCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  store ptr %_9, ptr %_0, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store ptr null, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb5, %bb6
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <f64 as core::ops::arith::Mul<&f64>>::mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvXs2Z_NtNtCsl10jNU3mE6R_4core3ops5arithdINtB6_3MulRdE3mulCsccF2givDBH6_8patterns(double %self, ptr align 8 %other, ptr align 8 %0) unnamed_addr #0 !guid !549 {
start:
  %_3 = load double, ptr %other, align 8
; call <f64 as core::ops::arith::Mul>::mul
  %_0 = call double @_RNvXs2g_NtNtCsl10jNU3mE6R_4core3ops5arithdNtB6_3Mul3mulCsccF2givDBH6_8patterns(double %self, double %_3, ptr align 8 %0) #22
  ret double %_0
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !550 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #22
  ret void
}

; <char as core::str::pattern::Pattern>::into_searcher
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtNtCsl10jNU3mE6R_4core3str7patterncNtB5_7Pattern13into_searcherCsccF2givDBH6_8patterns(ptr sret([48 x i8]) align 8 %_0, i32 %self, ptr %haystack.0, i64 %haystack.1) unnamed_addr #0 !guid !551 {
start:
  %_13 = alloca [4 x i8], align 1
  %utf8_encoded = alloca [4 x i8], align 1
  call void @llvm.memset.p0.i64(ptr align 1 %utf8_encoded, i8 0, i64 4, i1 false)
; call <char>::encode_utf8
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc11encode_utf8CsccF2givDBH6_8patterns(i32 %self, ptr %utf8_encoded, i64 4) #22
  %_8.0 = extractvalue { ptr, i64 } %0, 0
  %_8.1 = extractvalue { ptr, i64 } %0, 1
; call <str>::len
  %_6 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsccF2givDBH6_8patterns(ptr %_8.0, i64 %_8.1) #22
; call <usize as core::convert::TryInto<u8>>::try_into
  %1 = call { i1, i8 } @_RNvXs4_NtCsl10jNU3mE6R_4core7convertjINtB5_7TryIntohE8try_intoCsccF2givDBH6_8patterns(i64 %_6) #22
  %_5.0 = extractvalue { i1, i8 } %1, 0
  %_5.1 = extractvalue { i1, i8 } %1, 1
; call <core::result::Result<u8, core::num::error::TryFromIntError>>::expect
  %utf8_size = call i8 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtNtB4_3num5error15TryFromIntErrorE6expectCsccF2givDBH6_8patterns(i1 zeroext %_5.0, i8 %_5.1, ptr @alloc_611ea47e56fe111765d49cc77e8ab451, i64 32, ptr align 8 @alloc_a803cf9d531a7eab08229c1ca6c8eae5) #22
; call <str>::len
  %_12 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsccF2givDBH6_8patterns(ptr %haystack.0, i64 %haystack.1) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_13, ptr align 1 %utf8_encoded, i64 4, i1 false)
  store ptr %haystack.0, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %haystack.1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 24
  store i64 %_12, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 36
  store i32 %self, ptr %5, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 40
  store i8 %utf8_size, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 1 %_13, i64 4, i1 false)
  ret void
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[u8]>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexShE3getCsccF2givDBH6_8patterns(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !552 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <usize>::checked_sub
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCsccF2givDBH6_8patterns(i64 %self.1, i64 %self.0) #22
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_3, align 8
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %2, ptr %3, align 8
  %_6 = load i64, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_6 to i1
  br i1 %6, label %bb2, label %bb5

bb2:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_3, i64 8
  %new_len = load i64, ptr %7, align 8
  %_8 = icmp ule i64 %self.1, %slice.1
  br i1 %_8, label %bb3, label %bb5

bb5:                                              ; preds = %bb2, %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb3:                                              ; preds = %bb2
  %ptr.i = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self.0
  %8 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %new_len, 1
  %_12.0 = extractvalue { ptr, i64 } %9, 0
  %_12.1 = extractvalue { ptr, i64 } %9, 1
  store ptr %_12.0, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_12.1, ptr %10, align 8
  br label %bb6

bb6:                                              ; preds = %bb5, %bb3
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb7:                                              ; No predecessors!
  unreachable
}

; <f64 as core::ops::arith::Mul>::mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvXs2g_NtNtCsl10jNU3mE6R_4core3ops5arithdNtB6_3Mul3mulCsccF2givDBH6_8patterns(double %self, double %other, ptr align 8 %0) unnamed_addr #0 !guid !553 {
start:
  %_0 = fmul double %self, %other
  ret double %_0
}

; <&u32 as core::ops::arith::Mul>::mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs2t_NtNtCsl10jNU3mE6R_4core3ops5arithRmNtB6_3Mul3mulCsccF2givDBH6_8patterns(ptr align 4 %self, ptr align 4 %other, ptr align 8 %0) unnamed_addr #0 !guid !554 {
start:
  %_3 = load i32, ptr %self, align 4
  %_4 = load i32, ptr %other, align 4
; call <u32 as core::ops::arith::Mul>::mul
  %_0 = call i32 @_RNvXs25_NtNtCsl10jNU3mE6R_4core3ops5arithmNtB6_3Mul3mulCsccF2givDBH6_8patterns(i32 %_3, i32 %_4, ptr align 8 %0) #22
  ret i32 %_0
}

; <core::str::iter::CharIndices as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !555 {
start:
  %_0.i1 = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %_4 = alloca [4 x i8], align 4
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.i2 = load ptr, ptr %0, align 8
  %_6.i3 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %_5.i2, ptr %_6.i3) #22
  store i64 %1, ptr %_0.i1, align 8
  %2 = load i64, ptr %_0.i1, align 8
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
  %3 = call i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  store i32 %3, ptr %_4, align 4
  %4 = load i32, ptr %_4, align 4
  %5 = icmp eq i32 %4, -1
  %_6 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_6 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %ch = load i32, ptr %_4, align 4
  %7 = getelementptr inbounds i8, ptr %self, i64 16
  %index = load i64, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.i = load ptr, ptr %8, align 8
  %_6.i = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %9 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %_5.i, ptr %_6.i) #22
  store i64 %9, ptr %_0.i, align 8
  %10 = load i64, ptr %_0.i, align 8
  %_11 = sub i64 %2, %10
  %11 = getelementptr inbounds i8, ptr %self, i64 16
  %12 = getelementptr inbounds i8, ptr %self, i64 16
  %13 = load i64, ptr %12, align 8
  %14 = add i64 %13, %_11
  store i64 %14, ptr %11, align 8
  store i64 %index, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %ch, ptr %15, align 8
  br label %bb7

bb5:                                              ; preds = %start
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 -1, ptr %16, align 8
  br label %bb7

bb7:                                              ; preds = %bb4, %bb5
  %17 = load i64, ptr %_0, align 8
  %18 = getelementptr inbounds i8, ptr %_0, i64 8
  %19 = load i32, ptr %18, align 8
  %20 = insertvalue { i64, i32 } poison, i64 %17, 0
  %21 = insertvalue { i64, i32 } %20, i32 %19, 1
  ret { i64, i32 } %21

bb3:                                              ; No predecessors!
  unreachable
}

; <<char>::is_whitespace as core::str::pattern::MultiCharEq>::matches
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_11MultiCharEq7matchesCsccF2givDBH6_8patterns(ptr %self, i32 %c) unnamed_addr #0 !guid !556 {
start:
; call <<char>::is_whitespace as core::ops::function::FnMut<(char,)>>::call_mut
  %_0 = call zeroext i1 @_RNvYNvMNtNtCsl10jNU3mE6R_4core4char7methodsc13is_whitespaceINtNtNtB9_3ops8function5FnMutTcEE8call_mutCsccF2givDBH6_8patterns(ptr %self, i32 %c) #22
  ret i1 %_0
}

; <core::array::iter::IntoIter<&[i32], 4> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterRSlKj4_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !557 {
start:
; call <core::array::iter::IntoIter<&[i32], 4>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterRSlKj4_E10unsize_mutCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>]>>::next
  %1 = call { ptr, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitRSlEE4nextCsccF2givDBH6_8patterns(ptr align 8 %_2.0, i64 %_2.1) #22
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::array::iter::IntoIter<i64, 7> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterxKj7_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !558 {
start:
; call <core::array::iter::IntoIter<i64, 7>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterxKj7_E10unsize_mutCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>]>>::next
  %1 = call { i64, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitxEE4nextCsccF2givDBH6_8patterns(ptr align 8 %_2.0, i64 %_2.1) #22
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <u8 as core::slice::cmp::SlicePartialEq<u8>>::equal_same_length
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core5slice3cmphINtB5_14SlicePartialEqhE17equal_same_lengthCsccF2givDBH6_8patterns(ptr %lhs, ptr %rhs, i64 %len) unnamed_addr #0 !guid !559 {
start:
  %size = mul nuw i64 %len, 1
  %_5 = call i32 @memcmp(ptr %lhs, ptr %rhs, i64 %size)
  %_0 = icmp eq i32 %_5, 0
  ret i1 %_0
}

; <usize as core::convert::TryInto<u8>>::try_into
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXs4_NtCsl10jNU3mE6R_4core7convertjINtB5_7TryIntohE8try_intoCsccF2givDBH6_8patterns(i64 %self) unnamed_addr #0 !guid !560 {
start:
; call <u8 as core::convert::TryFrom<usize>>::try_from
  %0 = call { i1, i8 } @_RNvXNtNtNtCsl10jNU3mE6R_4core7convert3num18ptr_try_from_implshINtB6_7TryFromjE8try_fromCsccF2givDBH6_8patterns(i64 %self) #22
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits12double_ended19DoubleEndedIterator9next_backCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !561 {
start:
; call <core::str::iter::Chars as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %_2 = call i32 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_5CharsNtNtNtNtB9_4iter6traits12double_ended19DoubleEndedIterator9next_backCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_5 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::option::Option<char>>::map::<(usize, char), <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back::{closure#0}>
  %0 = call { i64, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptioncE3mapTjcENCNvXs4_NtNtB5_3str4iterNtB10_11CharIndicesNtNtNtNtB5_4iter6traits12double_ended19DoubleEndedIterator9next_back0ECsccF2givDBH6_8patterns(i32 %_2, ptr align 8 %_5, ptr align 8 %self) #22
  %_0.0 = extractvalue { i64, i32 } %0, 0
  %_0.1 = extractvalue { i64, i32 } %0, 1
  %1 = insertvalue { i64, i32 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i32 } %1, i32 %_0.1, 1
  ret { i64, i32 } %2
}

; <core::ops::index_range::IndexRange as core::clone::Clone>::clone
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !562 {
start:
  %_2 = load i64, ptr %self, align 8
  %_5 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %_5, align 8
  %0 = insertvalue { i64, i64 } poison, i64 %_2, 0
  %1 = insertvalue { i64, i64 } %0, i64 %_4, 1
  ret { i64, i64 } %1
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsccF2givDBH6_8patterns(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !563 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked::precondition_check
  call void @_RNvNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCsccF2givDBH6_8patterns(i64 %self.0, i64 %self.1, i64 %_0.i1, ptr align 8 %0) #23
  br label %bb3

bb3:                                              ; preds = %bb1
  %new_len = sub nuw i64 %self.1, %self.0
  %_0.i = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self.0
; call <*const u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh10cast_sliceCsccF2givDBH6_8patterns(ptr %_0.i, i64 %new_len) #22
  %_12.0 = extractvalue { ptr, i64 } %1, 0
  %_12.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_12.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_12.1, 1
  ret { ptr, i64 } %3
}

; <core::array::iter::IntoIter<&[i32], 4> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterRSlKj4_ENtNtNtB9_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !564 {
start:
; call core::mem::needs_drop::<&[i32]>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropRSlECsccF2givDBH6_8patterns() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitRSlEj4_EE4dropCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  br label %bb3
}

; <core::array::iter::IntoIter<i64, 7> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterxKj7_ENtNtNtB9_3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !565 {
start:
; call core::mem::needs_drop::<i64>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropxECsccF2givDBH6_8patterns() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<i64>; 7]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitxEj7_EE4dropCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  br label %bb3
}

; <core::num::error::TryFromIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_15TryFromIntErrorNtNtB9_3fmt5Debug3fmtCsccF2givDBH6_8patterns(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !566 {
start:
  %_6 = alloca [8 x i8], align 8
  store ptr %self, ptr %_6, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_5cb263f26a5d50117adfcc5c7225745e, i64 15, ptr %_6, ptr align 8 @vtable.9)
  ret i1 %_0
}

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !567 {
start:
; call <[u8]>::to_vec
  call void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #22
  ret void
}

; <&[u8] as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRShNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !568 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
  %_4.0 = load ptr, ptr %other, align 8
  %1 = getelementptr inbounds i8, ptr %other, i64 8
  %_4.1 = load i64, ptr %1, align 8
; call <[u8] as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core5slice3cmpShNtNtB6_3cmp9PartialEq2eqCsccF2givDBH6_8patterns(ptr %_3.0, i64 %_3.1, ptr %_4.0, i64 %_4.1) #22
  ret i1 %_0
}

; <&u8 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRhNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !569 {
start:
  %_3 = load ptr, ptr %self, align 8
  %_4 = load ptr, ptr %other, align 8
; call <u8 as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXsk_NtNtCsl10jNU3mE6R_4core3cmp5implshNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr %_3, ptr %_4) #22
  ret i1 %_0
}

; <&i32 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRlNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !570 {
start:
  %_3 = load ptr, ptr %self, align 8
  %_4 = load ptr, ptr %other, align 8
; call <i32 as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXss_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 4 %_3, ptr align 4 %_4) #22
  ret i1 %_0
}

; <core::str::pattern::MultiCharEqPattern<<char>::is_whitespace> as core::str::pattern::Pattern>::into_searcher
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs7_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_18MultiCharEqPatternNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_7Pattern13into_searcherCsccF2givDBH6_8patterns(ptr sret([40 x i8]) align 8 %_0, ptr %haystack.0, i64 %haystack.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !571 {
start:
  %_4 = alloca [24 x i8], align 8
; call <str>::char_indices
  call void @_RNvMNtCsl10jNU3mE6R_4core3stre12char_indicesCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_4, ptr %haystack.0, i64 %haystack.1) #22
  br label %bb1

bb1:                                              ; preds = %start
  store ptr %haystack.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %haystack.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %_4, i64 24, i1 false)
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i32]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSlE5indexCsccF2givDBH6_8patterns(ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !572 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<patterns::Shape> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefBH_(ptr align 8 %self) unnamed_addr #0 !guid !573 {
start:
; call <alloc::vec::Vec<patterns::Shape>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE8as_sliceBG_(ptr align 8 %self) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::boxed::Box<[patterns::Shape]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %self) unnamed_addr #0 !guid !574 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[patterns::Shape]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCsccF2givDBH6_8patterns5ShapeE6as_ptrBT_(ptr %ptr.0, i64 %ptr.1) #22
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[patterns::Shape]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCsccF2givDBH6_8patterns5ShapeEB17_(ptr %_5.0, i64 %_5.1) #22
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsccF2givDBH6_8patterns(ptr align 8 %layout) #22
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[patterns::Shape]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCsccF2givDBH6_8patterns5ShapeE4casthEBU_(ptr %ptr.0, i64 %ptr.1) #22
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCsccF2givDBH6_8patterns(ptr %_12) #22
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsccF2givDBH6_8patterns(ptr %_10, ptr %_11, i64 %6, i64 %8) #22
  br label %bb7
}

; <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range7RangeTojEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsccF2givDBH6_8patterns(i64 %self, ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !575 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
  %0 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsccF2givDBH6_8patterns(i64 0, i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 @alloc_a36baa902ac5f041bb4eed643ef44185) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher4nextCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !576 {
start:
  %_0.i1 = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %_5 = alloca [16 x i8], align 8
  %s = getelementptr inbounds i8, ptr %self, i64 16
  %0 = getelementptr inbounds i8, ptr %s, i64 8
  %_5.i2 = load ptr, ptr %0, align 8
  %_6.i3 = load ptr, ptr %s, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %_5.i2, ptr %_6.i3) #22
  store i64 %1, ptr %_0.i1, align 8
  %2 = load i64, ptr %_0.i1, align 8
; call <core::str::iter::CharIndices as core::iter::traits::iterator::Iterator>::next
  %3 = call { i64, i32 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %s) #22
  %4 = extractvalue { i64, i32 } %3, 0
  %5 = extractvalue { i64, i32 } %3, 1
  store i64 %4, ptr %_5, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 8
  store i32 %5, ptr %6, align 8
  %7 = load i64, ptr %_5, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = icmp eq i32 %9, -1
  %_6 = select i1 %10, i64 0, i64 1
  %11 = trunc nuw i64 %_6 to i1
  br i1 %11, label %bb3, label %bb8

bb3:                                              ; preds = %start
  %i = load i64, ptr %_5, align 8
  %12 = getelementptr inbounds i8, ptr %_5, i64 8
  %c = load i32, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %s, i64 8
  %_5.i = load ptr, ptr %13, align 8
  %_6.i = load ptr, ptr %s, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %14 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %_5.i, ptr %_6.i) #22
  store i64 %14, ptr %_0.i, align 8
  %15 = load i64, ptr %_0.i, align 8
  %char_len = sub i64 %2, %15
  %_13 = getelementptr inbounds i8, ptr %self, i64 40
; call <<char>::is_whitespace as core::str::pattern::MultiCharEq>::matches
  %_12 = call zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_11MultiCharEq7matchesCsccF2givDBH6_8patterns(ptr %_13, i32 %c) #22
  br i1 %_12, label %bb6, label %bb7

bb8:                                              ; preds = %start
  store i64 2, ptr %_0, align 8
  br label %bb9

bb7:                                              ; preds = %bb3
  %_15 = add i64 %i, %char_len
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %i, ptr %16, align 8
  %17 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %_15, ptr %17, align 8
  store i64 1, ptr %_0, align 8
  br label %bb9

bb6:                                              ; preds = %bb3
  %_14 = add i64 %i, %char_len
  %18 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %i, ptr %18, align 8
  %19 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %_14, ptr %19, align 8
  store i64 0, ptr %_0, align 8
  br label %bb9

bb9:                                              ; preds = %bb8, %bb6, %bb7
  ret void

bb10:                                             ; No predecessors!
  unreachable
}

; <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs9_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range9RangeFromjEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsccF2givDBH6_8patterns(i64 %self, ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !577 {
start:
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECsccF2givDBH6_8patterns(ptr %slice.0, i64 %slice.1) #22
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
  %0 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsccF2givDBH6_8patterns(i64 %self, i64 %_0.i, ptr %slice.0, i64 %slice.1, ptr align 8 @alloc_c2c8a36c827ccad15c06f229359033cb) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs9_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher9next_backCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !578 {
start:
  %_0.i1 = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %_5 = alloca [16 x i8], align 8
  %s = getelementptr inbounds i8, ptr %self, i64 16
  %0 = getelementptr inbounds i8, ptr %s, i64 8
  %_5.i2 = load ptr, ptr %0, align 8
  %_6.i3 = load ptr, ptr %s, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %_5.i2, ptr %_6.i3) #22
  store i64 %1, ptr %_0.i1, align 8
  %2 = load i64, ptr %_0.i1, align 8
; call <core::str::iter::CharIndices as core::iter::traits::double_ended::DoubleEndedIterator>::next_back
  %3 = call { i64, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core3str4iterNtB5_11CharIndicesNtNtNtNtB9_4iter6traits12double_ended19DoubleEndedIterator9next_backCsccF2givDBH6_8patterns(ptr align 8 %s) #22
  %4 = extractvalue { i64, i32 } %3, 0
  %5 = extractvalue { i64, i32 } %3, 1
  store i64 %4, ptr %_5, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 8
  store i32 %5, ptr %6, align 8
  %7 = load i64, ptr %_5, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = icmp eq i32 %9, -1
  %_6 = select i1 %10, i64 0, i64 1
  %11 = trunc nuw i64 %_6 to i1
  br i1 %11, label %bb3, label %bb8

bb3:                                              ; preds = %start
  %i = load i64, ptr %_5, align 8
  %12 = getelementptr inbounds i8, ptr %_5, i64 8
  %c = load i32, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %s, i64 8
  %_5.i = load ptr, ptr %13, align 8
  %_6.i = load ptr, ptr %s, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %14 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCsccF2givDBH6_8patterns(ptr %_5.i, ptr %_6.i) #22
  store i64 %14, ptr %_0.i, align 8
  %15 = load i64, ptr %_0.i, align 8
  %char_len = sub i64 %2, %15
  %_13 = getelementptr inbounds i8, ptr %self, i64 40
; call <<char>::is_whitespace as core::str::pattern::MultiCharEq>::matches
  %_12 = call zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_11MultiCharEq7matchesCsccF2givDBH6_8patterns(ptr %_13, i32 %c) #22
  br i1 %_12, label %bb6, label %bb7

bb8:                                              ; preds = %start
  store i64 2, ptr %_0, align 8
  br label %bb9

bb7:                                              ; preds = %bb3
  %_15 = add i64 %i, %char_len
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %i, ptr %16, align 8
  %17 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %_15, ptr %17, align 8
  store i64 1, ptr %_0, align 8
  br label %bb9

bb6:                                              ; preds = %bb3
  %_14 = add i64 %i, %char_len
  %18 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %i, ptr %18, align 8
  %19 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %_14, ptr %19, align 8
  store i64 0, ptr %_0, align 8
  br label %bb9

bb9:                                              ; preds = %bb8, %bb6, %bb7
  ret void

bb10:                                             ; No predecessors!
  unreachable
}

; <core::option::Option<&[u8]> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRShENtNtNtB7_3ops9try_trait3Try6branchCsccF2givDBH6_8patterns(ptr %0, i64 %1) unnamed_addr #0 !guid !579 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_2 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_2 to i1
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %v.1 = load i64, ptr %9, align 8
  store ptr %v.0, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.1, ptr %10, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&u8> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRhENtNtNtB7_3ops9try_trait3Try6branchCsccF2givDBH6_8patterns(ptr %0) unnamed_addr #0 !guid !580 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<(usize, usize)> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTjjEENtNtNtB7_3ops9try_trait3Try6branchCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !581 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = trunc nuw i64 %_2 to i1
  br i1 %0, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %v.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %v.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %v.1, ptr %4, align 8
  store i64 0, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !582 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #22
  ret void
}

; <core::option::Option<(&str, &str)> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTReBL_EEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCsccF2givDBH6_8patterns(ptr sret([32 x i8]) align 8 %_0) unnamed_addr #0 !guid !583 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<(usize, usize)> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTjjEEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !584 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCsccF2givDBH6_8patterns() unnamed_addr #0 !guid !585 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { i32, i32 } { i32 0, i32 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <i32 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !586 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i32 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i32 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i32 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::option::Option<(&str, i32)> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTRelEENtNtB7_3fmt5Debug3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !587 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.a)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsccF2givDBH6_8patterns() unnamed_addr #0 !guid !588 {
start:
  ret i8 0
}

; <u8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCsccF2givDBH6_8patterns(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !589 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <u32 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsW_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !590 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u32 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsu_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u32 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt(ptr align 4 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u32 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsw_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8UpperHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCsccF2givDBH6_8patterns(ptr align 8 %0) unnamed_addr #0 !guid !591 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
; call <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_3 = call i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenCsccF2givDBH6_8patterns(ptr align 8 %self)
  %_2 = icmp ugt i64 %_3, 0
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  %1 = load ptr, ptr %self, align 8
; call <core::ops::index_range::IndexRange>::next_unchecked
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCsccF2givDBH6_8patterns(ptr align 8 %1) #22
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <core::str::pattern::CharSearcher as core::str::pattern::Searcher>::next_match
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs_NtNtCsl10jNU3mE6R_4core3str7patternNtB4_12CharSearcherNtB4_8Searcher10next_matchCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !592 {
start:
  %_38 = alloca [16 x i8], align 8
  %slice = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_2 = alloca [16 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %bb17, %bb13, %bb11, %start
  %_47.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_47.1 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_47.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_47.1, 1
  %_4.0 = extractvalue { ptr, i64 } %2, 0
  %_4.1 = extractvalue { ptr, i64 } %2, 1
  %3 = getelementptr inbounds i8, ptr %self, i64 16
  %_6 = load i64, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 24
  %_7 = load i64, ptr %4, align 8
; call <[u8]>::get::<core::ops::range::Range<usize>>
  %5 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSh3getINtNtNtB5_3ops5range5RangejEECsccF2givDBH6_8patterns(ptr %_4.0, i64 %_4.1, i64 %_6, i64 %_7) #22
  %_3.0 = extractvalue { ptr, i64 } %5, 0
  %_3.1 = extractvalue { ptr, i64 } %5, 1
; call <core::option::Option<&[u8]> as core::ops::try_trait::Try>::branch
  %6 = call { ptr, i64 } @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRShENtNtNtB7_3ops9try_trait3Try6branchCsccF2givDBH6_8patterns(ptr %_3.0, i64 %_3.1) #22
  %7 = extractvalue { ptr, i64 } %6, 0
  %8 = extractvalue { ptr, i64 } %6, 1
  store ptr %7, ptr %_2, align 8
  %9 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %8, ptr %9, align 8
  %10 = load ptr, ptr %_2, align 8
  %11 = getelementptr inbounds i8, ptr %_2, i64 8
  %12 = load i64, ptr %11, align 8
  %13 = ptrtoint ptr %10 to i64
  %14 = icmp eq i64 %13, 0
  %_8 = select i1 %14, i64 1, i64 0
  %15 = trunc nuw i64 %_8 to i1
  br i1 %15, label %bb7, label %bb6

bb7:                                              ; preds = %bb1
; call <core::option::Option<(usize, usize)> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  call void @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTjjEEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0) #22
  br label %bb23

bb6:                                              ; preds = %bb1
  %bytes.0 = load ptr, ptr %_2, align 8
  %16 = getelementptr inbounds i8, ptr %_2, i64 8
  %bytes.1 = load i64, ptr %16, align 8
  %_13 = getelementptr inbounds i8, ptr %self, i64 32
; call <core::str::pattern::CharSearcher>::utf8_size
  %_15 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3str7patternNtB2_12CharSearcher9utf8_size(ptr align 8 %self)
  %_14 = sub i64 %_15, 1
; call <[u8]>::get_unchecked::<usize>
  %_11 = call ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSh13get_uncheckedjECsccF2givDBH6_8patterns(ptr %_13, i64 4, i64 %_14, ptr align 8 @alloc_9ecc32dce479cfcbfd7bb34b5db75f66) #22
  %last_byte = load i8, ptr %_11, align 1
; call core::slice::memchr::memchr
  %17 = call { i64, i64 } @_RNvNtNtCsl10jNU3mE6R_4core5slice6memchr6memchrCsccF2givDBH6_8patterns(i8 %last_byte, ptr %bytes.0, i64 %bytes.1) #22
  %18 = extractvalue { i64, i64 } %17, 0
  %19 = extractvalue { i64, i64 } %17, 1
  store i64 %18, ptr %_17, align 8
  %20 = getelementptr inbounds i8, ptr %_17, i64 8
  store i64 %19, ptr %20, align 8
  %_18 = load i64, ptr %_17, align 8
  %21 = getelementptr inbounds i8, ptr %_17, i64 8
  %22 = load i64, ptr %21, align 8
  %23 = trunc nuw i64 %_18 to i1
  br i1 %23, label %bb11, label %bb22

bb11:                                             ; preds = %bb6
  %24 = getelementptr inbounds i8, ptr %_17, i64 8
  %index = load i64, ptr %24, align 8
  %_20 = add i64 %index, 1
  %25 = getelementptr inbounds i8, ptr %self, i64 16
  %26 = getelementptr inbounds i8, ptr %self, i64 16
  %27 = load i64, ptr %26, align 8
  %28 = add i64 %27, %_20
  store i64 %28, ptr %25, align 8
  %29 = getelementptr inbounds i8, ptr %self, i64 16
  %_22 = load i64, ptr %29, align 8
; call <core::str::pattern::CharSearcher>::utf8_size
  %_23 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3str7patternNtB2_12CharSearcher9utf8_size(ptr align 8 %self)
  %_21 = icmp uge i64 %_22, %_23
  br i1 %_21, label %bb13, label %bb1

bb22:                                             ; preds = %bb6
  %30 = getelementptr inbounds i8, ptr %self, i64 24
  %_46 = load i64, ptr %30, align 8
  %31 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %_46, ptr %31, align 8
  store i64 0, ptr %_0, align 8
  br label %bb23

bb13:                                             ; preds = %bb11
  %32 = getelementptr inbounds i8, ptr %self, i64 16
  %_26 = load i64, ptr %32, align 8
; call <core::str::pattern::CharSearcher>::utf8_size
  %_27 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3str7patternNtB2_12CharSearcher9utf8_size(ptr align 8 %self)
  %found_char = sub i64 %_26, %_27
  %_48.0 = load ptr, ptr %self, align 8
  %33 = getelementptr inbounds i8, ptr %self, i64 8
  %_48.1 = load i64, ptr %33, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %_48.0, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %_48.1, 1
  %_30.0 = extractvalue { ptr, i64 } %35, 0
  %_30.1 = extractvalue { ptr, i64 } %35, 1
  %36 = getelementptr inbounds i8, ptr %self, i64 16
  %_32 = load i64, ptr %36, align 8
; call <[u8]>::get::<core::ops::range::Range<usize>>
  %37 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSh3getINtNtNtB5_3ops5range5RangejEECsccF2givDBH6_8patterns(ptr %_30.0, i64 %_30.1, i64 %found_char, i64 %_32) #22
  %38 = extractvalue { ptr, i64 } %37, 0
  %39 = extractvalue { ptr, i64 } %37, 1
  store ptr %38, ptr %_29, align 8
  %40 = getelementptr inbounds i8, ptr %_29, i64 8
  store i64 %39, ptr %40, align 8
  %41 = load ptr, ptr %_29, align 8
  %42 = getelementptr inbounds i8, ptr %_29, i64 8
  %43 = load i64, ptr %42, align 8
  %44 = ptrtoint ptr %41 to i64
  %45 = icmp eq i64 %44, 0
  %_33 = select i1 %45, i64 0, i64 1
  %46 = trunc nuw i64 %_33 to i1
  br i1 %46, label %bb17, label %bb1

bb17:                                             ; preds = %bb13
  %47 = load ptr, ptr %_29, align 8
  %48 = getelementptr inbounds i8, ptr %_29, i64 8
  %49 = load i64, ptr %48, align 8
  store ptr %47, ptr %slice, align 8, !captures !249
  %50 = getelementptr inbounds i8, ptr %slice, i64 8
  store i64 %49, ptr %50, align 8
  %_40 = getelementptr inbounds i8, ptr %self, i64 32
; call <core::str::pattern::CharSearcher>::utf8_size
  %_42 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3str7patternNtB2_12CharSearcher9utf8_size(ptr align 8 %self)
; call <[u8; 4] as core::ops::index::Index<core::ops::range::Range<usize>>>::index
  %51 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAhj4_INtNtNtB7_3ops5index5IndexINtNtBG_5range5RangejEE5indexCsccF2givDBH6_8patterns(ptr %_40, i64 0, i64 %_42, ptr align 8 @alloc_5e625bb2bc28691fcb622b93594e784d) #22
  %_39.0 = extractvalue { ptr, i64 } %51, 0
  %_39.1 = extractvalue { ptr, i64 } %51, 1
  store ptr %_39.0, ptr %_38, align 8, !captures !249
  %52 = getelementptr inbounds i8, ptr %_38, i64 8
  store i64 %_39.1, ptr %52, align 8
; call <&[u8] as core::cmp::PartialEq>::eq
  %_35 = call zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRShNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %slice, ptr align 8 %_38) #22
  br i1 %_35, label %bb21, label %bb1

bb21:                                             ; preds = %bb17
  %53 = getelementptr inbounds i8, ptr %self, i64 16
  %_45 = load i64, ptr %53, align 8
  %54 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %found_char, ptr %54, align 8
  %55 = getelementptr inbounds i8, ptr %54, i64 8
  store i64 %_45, ptr %55, align 8
  store i64 1, ptr %_0, align 8
  br label %bb23

bb23:                                             ; preds = %bb7, %bb22, %bb21
  ret void

bb5:                                              ; No predecessors!
  unreachable
}

; <[core::mem::maybe_uninit::MaybeUninit<&[i32]>; 4] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitRSlEj4_NtB4_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !593 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&[i32]>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitRSlENtB2_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self, i64 4, i64 %alive.0, i64 %alive.1)
  ret void
}

; <[core::mem::maybe_uninit::MaybeUninit<i64>; 7] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitxEj7_NtB4_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !594 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<i64>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitxENtB2_11PartialDrop12partial_dropCsccF2givDBH6_8patterns(ptr align 8 %self, i64 7, i64 %alive.0, i64 %alive.1)
  ret void
}

; <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCsccF2givDBH6_8patterns(ptr %pointer) unnamed_addr #0 !guid !595 {
start:
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCsccF2givDBH6_8patterns(ptr %pointer) #22
  ret ptr %_0
}

; <[u8; 4] as core::ops::index::Index<core::ops::range::Range<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAhj4_INtNtNtB7_3ops5index5IndexINtNtBG_5range5RangejEE5indexCsccF2givDBH6_8patterns(ptr %self, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !596 {
start:
  %_3.i = alloca [16 x i8], align 8
; call <usize>::checked_sub
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCsccF2givDBH6_8patterns(i64 %index.1, i64 %index.0) #22
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3.i, align 8
  %4 = getelementptr inbounds i8, ptr %_3.i, i64 8
  store i64 %3, ptr %4, align 8
  %_6.i = load i64, ptr %_3.i, align 8
  %5 = getelementptr inbounds i8, ptr %_3.i, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_6.i to i1
  br i1 %7, label %bb2.i, label %bb5.i

bb2.i:                                            ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3.i, i64 8
  %new_len.i = load i64, ptr %8, align 8
  %_8.i = icmp ule i64 %index.1, 4
  br i1 %_8.i, label %_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexShE5indexCsccF2givDBH6_8patterns.exit, label %bb5.i

bb5.i:                                            ; preds = %bb2.i, %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %index.0, i64 %index.1, i64 4, ptr align 8 %0) #26
  unreachable

_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexShE5indexCsccF2givDBH6_8patterns.exit: ; preds = %bb2.i
  %ptr.i.i = getelementptr inbounds nuw i8, ptr %self, i64 %index.0
  %9 = insertvalue { ptr, i64 } poison, ptr %ptr.i.i, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %new_len.i, 1
  %11 = insertvalue { ptr, i64 } poison, ptr %ptr.i.i, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %new_len.i, 1
  %_0.0.i = extractvalue { ptr, i64 } %12, 0
  %_0.1.i = extractvalue { ptr, i64 } %12, 1
  %_0.0 = extractvalue { ptr, i64 } %12, 0
  %_0.1 = extractvalue { ptr, i64 } %12, 1
  %13 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %14 = insertvalue { ptr, i64 } %13, i64 %_0.1, 1
  ret { ptr, i64 } %14
}

; <[i32; 0] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAlj0_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCsccF2givDBH6_8patterns(ptr align 4 %self, ptr align 8 %0) unnamed_addr #0 !guid !597 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i32]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSlE5indexCsccF2givDBH6_8patterns(ptr align 4 %self, i64 0, ptr align 8 %0) #22
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::non_null::NonNull<patterns::Shape> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCsccF2givDBH6_8patterns5ShapeENtNtB9_3cmp9PartialEq2eqBV_(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !598 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !599 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<i32> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllENtNtB9_3cmp9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !600 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <&alloc::vec::Vec<patterns::Shape> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXsh_NtCs7CppTae75M1_5alloc3vecRINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12IntoIterator9into_iterBI_(ptr align 8 %self) unnamed_addr #1 !guid !601 {
start:
; call <alloc::vec::Vec<patterns::Shape> as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefBH_(ptr align 8 %self) #22
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <[patterns::Shape]>::iter
  %1 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCsccF2givDBH6_8patterns5Shape4iterBw_(ptr align 8 %_2.0, i64 %_2.1) #22
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCsccF2givDBH6_8patterns(ptr %unique) unnamed_addr #0 !guid !602 {
start:
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCsccF2givDBH6_8patterns(ptr %unique) #22
  ret ptr %_0
}

; <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCsccF2givDBH6_8patterns(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !603 {
start:
  %_3 = alloca [16 x i8], align 8
  %0 = load i8, ptr %self, align 1
  %_4 = zext i8 %0 to i64
  switch i64 %_4, label %bb1 [
    i64 0, label %bb7
    i64 1, label %bb6
    i64 2, label %bb5
    i64 3, label %bb4
    i64 4, label %bb3
    i64 5, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb7:                                              ; preds = %start
  store ptr @alloc_59ba7b9f7211443cd55a366616eef46a, ptr %_3, align 8, !captures !249
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %1, align 8
  br label %bb8

bb6:                                              ; preds = %start
  store ptr @alloc_00315c78e51d29fe6b3102a4c1ecf6ef, ptr %_3, align 8, !captures !249
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 12, ptr %2, align 8
  br label %bb8

bb5:                                              ; preds = %start
  store ptr @alloc_bd3a3f3879e0d5f64554753e977f58d4, ptr %_3, align 8, !captures !249
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %3, align 8
  br label %bb8

bb4:                                              ; preds = %start
  store ptr @alloc_0964bb2a4870637395c77a018495bd5c, ptr %_3, align 8, !captures !249
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %4, align 8
  br label %bb8

bb3:                                              ; preds = %start
  store ptr @alloc_6566120a3a17f930e960a0863fcbd591, ptr %_3, align 8, !captures !249
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %5, align 8
  br label %bb8

bb2:                                              ; preds = %start
  store ptr @alloc_6c17bac0c71cba42380f8445f4dcbd16, ptr %_3, align 8, !captures !249
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 14, ptr %6, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb3, %bb4, %bb5, %bb6, %bb7
  %7 = load ptr, ptr %_3, align 8
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = load i64, ptr %8, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %7, i64 %9)
  ret i1 %_0
}

; <u8 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsk_NtNtCsl10jNU3mE6R_4core3cmp5implshNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr %self, ptr %other) unnamed_addr #0 !guid !604 {
start:
  %_3 = load i8, ptr %self, align 1
  %_4 = load i8, ptr %other, align 1
  %_0 = icmp eq i8 %_3, %_4
  ret i1 %_0
}

; <i32 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXso_NtCsl10jNU3mE6R_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCsccF2givDBH6_8patterns(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !605 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <i32>::from_str_radix
  %1 = call i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl14from_str_radixCsccF2givDBH6_8patterns(ptr %src.0, i64 %src.1, i32 10) #22
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <core::str::pattern::CharPredicateSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next_reject
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXso_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_21CharPredicateSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher11next_rejectCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !606 {
start:
; call <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next_reject
  call void @_RNvYINtNtNtCsl10jNU3mE6R_4core3str7pattern19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher11next_rejectCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #22
  ret void
}

; <alloc::vec::Vec<patterns::Shape> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsccF2givDBH6_8patterns5ShapeENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %self) unnamed_addr #1 !guid !607 {
start:
; call <alloc::vec::Vec<patterns::Shape>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsccF2givDBH6_8patterns5ShapeE10as_mut_ptrBG_(ptr align 8 %self) #22
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut patterns::Shape>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCsccF2givDBH6_8patterns5Shape10cast_sliceBG_(ptr %_3, i64 %_4) #22
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #1 !guid !608 {
start:
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCsccF2givDBH6_8patterns(ptr %_3, i64 %_4) #22
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCsccF2givDBH6_8patterns(ptr %0) unnamed_addr #0 !guid !609 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::str::pattern::CharPredicateSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_reject_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_21CharPredicateSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher16next_reject_backCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !610 {
start:
; call <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_reject_back
  call void @_RNvYINtNtNtCsl10jNU3mE6R_4core3str7pattern19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher16next_reject_backCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #22
  ret void
}

; <alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCsccF2givDBH6_8patterns(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !611 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCsccF2givDBH6_8patterns(ptr align 8 %0) unnamed_addr #0 !guid !612 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { ptr, i64 } { ptr null, i64 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCsccF2givDBH6_8patterns(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !613 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[i32]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsccF2givDBH6_8patterns(ptr align 4 %self.0, i64 %self.1) #22
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECsccF2givDBH6_8patterns(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <<char>::is_whitespace as core::str::pattern::Pattern>::into_searcher
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsr_NtNtCsl10jNU3mE6R_4core3str7patternNvMNtNtB9_4char7methodsc13is_whitespaceNtB5_7Pattern13into_searcherCsccF2givDBH6_8patterns(ptr sret([40 x i8]) align 8 %_0, ptr %haystack.0, i64 %haystack.1) unnamed_addr #0 !guid !614 {
start:
  %_3 = alloca [40 x i8], align 8
; call <core::str::pattern::MultiCharEqPattern<<char>::is_whitespace> as core::str::pattern::Pattern>::into_searcher
  call void @_RNvXs7_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_18MultiCharEqPatternNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_7Pattern13into_searcherCsccF2givDBH6_8patterns(ptr sret([40 x i8]) align 8 %_3, ptr %haystack.0, i64 %haystack.1) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_3, i64 40, i1 false)
  ret void
}

; <i32 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXss_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB7_9PartialEq2eqCsccF2givDBH6_8patterns(ptr align 4 %self, ptr align 4 %other) unnamed_addr #0 !guid !615 {
start:
  %_3 = load i32, ptr %self, align 4
  %_4 = load i32, ptr %other, align 4
  %_0 = icmp eq i32 %_3, %_4
  ret i1 %_0
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCsccF2givDBH6_8patterns(ptr align 8 %self) unnamed_addr #0 !guid !616 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCsccF2givDBH6_8patterns(ptr align 8 %self) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsccF2givDBH6_8patterns(ptr %_1) unnamed_addr #0 !guid !617 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_reject_back
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYINtNtNtCsl10jNU3mE6R_4core3str7pattern19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher16next_reject_backCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !618 {
start:
  %_2 = alloca [24 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %bb1, %start
; call <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::ReverseSearcher>::next_back
  call void @_RNvXs9_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_15ReverseSearcher9next_backCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_2, ptr align 8 %self) #22
  %_3 = load i64, ptr %_2, align 8
  switch i64 %_3, label %bb6 [
    i64 1, label %bb4
    i64 2, label %bb3
    i64 0, label %bb1
  ]

bb6:                                              ; preds = %bb1
  unreachable

bb4:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  %a = load i64, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_2, i64 16
  %b = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %a, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %b, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb1
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next_reject
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYINtNtNtCsl10jNU3mE6R_4core3str7pattern19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher11next_rejectCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !619 {
start:
  %_2 = alloca [24 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %bb1, %start
; call <core::str::pattern::MultiCharEqSearcher<<char>::is_whitespace> as core::str::pattern::Searcher>::next
  call void @_RNvXs8_NtNtCsl10jNU3mE6R_4core3str7patternINtB5_19MultiCharEqSearcherNvMNtNtB9_4char7methodsc13is_whitespaceENtB5_8Searcher4nextCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_2, ptr align 8 %self) #22
  %_3 = load i64, ptr %_2, align 8
  switch i64 %_3, label %bb6 [
    i64 1, label %bb4
    i64 2, label %bb3
    i64 0, label %bb1
  ]

bb6:                                              ; preds = %bb1
  unreachable

bb4:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  %a = load i64, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_2, i64 16
  %b = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %a, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %b, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb1
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsccF2givDBH6_8patterns(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !620 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsccF2givDBH6_8patterns(ptr align 8 %_1) #22
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<char>::is_whitespace as core::ops::function::FnMut<(char,)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvYNvMNtNtCsl10jNU3mE6R_4core4char7methodsc13is_whitespaceINtNtNtB9_3ops8function5FnMutTcEE8call_mutCsccF2givDBH6_8patterns(ptr %_1, i32 %0) unnamed_addr #0 !guid !621 {
start:
  %_2 = alloca [4 x i8], align 4
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
; call <char>::is_whitespace
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc13is_whitespaceCsccF2givDBH6_8patterns(i32 %1) #22
  ret i1 %_0
}

; <<str as alloc::borrow::ToOwned>::to_owned as core::ops::function::FnOnce<(&str,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNvYeNtNtCs7CppTae75M1_5alloc6borrow7ToOwned8to_ownedINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTReEE9call_onceCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1) unnamed_addr #0 !guid !622 {
start:
  %_2 = alloca [16 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %1, ptr %2, align 8
  %3 = load ptr, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load i64, ptr %4, align 8
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsccF2givDBH6_8patterns(ptr sret([24 x i8]) align 8 %_0, ptr %3, i64 %5) #22
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #6

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #8

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <usize as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i16 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt(ptr align 2, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsw_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8UpperHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugList>::entry
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; alloc::fmt::format::format_inner
; Function Attrs: nonlazybind uwtable
declare void @_RNvNvNtCs7CppTae75M1_5alloc3fmt6format12format_inner(ptr sret([24 x i8]) align 8, ptr, ptr) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptoui.sat.i32.f64(double) #9

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #7

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #7

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #10

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #10

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #10

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #10

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32) #9

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64, i64) unnamed_addr #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctpop.i32(i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #9

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #10

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #6

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #12

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #13

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #14

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #11

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #10

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #15

; core::slice::memchr::memchr_aligned
; Function Attrs: nonlazybind uwtable
declare { i64, i64 } @_RNvNtNtCsl10jNU3mE6R_4core5slice6memchr14memchr_aligned(i8, ptr, i64) unnamed_addr #1

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #16

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #16

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field2_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field3_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field3_finish(ptr align 8, ptr, i64, ptr, ptr align 8, ptr, ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #10

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #17

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64, i64, i64, ptr align 8) unnamed_addr #10

; Function Attrs: nonlazybind
declare i32 @memcmp(ptr, ptr, i64) #18

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <i32 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsu_NtNtCsl10jNU3mE6R_4core3fmt3nummNtB7_8LowerHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <core::str::pattern::CharSearcher>::utf8_size
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvMNtNtCsl10jNU3mE6R_4core3str7patternNtB2_12CharSearcher9utf8_size(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugList>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #19 !guid !623 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsccF2givDBH6_8patterns(ptr @_RNvCsccF2givDBH6_8patterns4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { inlinehint noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #18 = { nonlazybind }
attributes #19 = { nonlazybind "target-cpu"="x86-64" }
attributes #20 = { cold }
attributes #21 = { cold noreturn nounwind }
attributes #22 = { inlinehint }
attributes #23 = { inlinehint nounwind }
attributes #24 = { noinline }
attributes #25 = { noinline noreturn nounwind }
attributes #26 = { noinline noreturn }
attributes #27 = { inlinehint noreturn }
attributes #28 = { noreturn }
attributes #29 = { nounwind }

!llvm.module.flags = !{!171, !172, !173, !174}
!llvm.ident = !{!175}

!0 = !{i64 5413900492822873644}
!1 = !{i64 -1194006783608091694}
!2 = !{i64 -6262721094808698782}
!3 = !{i64 -8805340782921766884}
!4 = !{i64 7886568547709235864}
!5 = !{i64 -6468279480826265091}
!6 = !{i64 9121876464136025571}
!7 = !{i64 7484764997931357234}
!8 = !{i64 5974893939525915804}
!9 = !{i64 7788206758472091095}
!10 = !{i64 -7122930840218010264}
!11 = !{i64 -4470224346270604118}
!12 = !{i64 7943921168083614317}
!13 = !{i64 -6436449896982494530}
!14 = !{i64 -5204570531771261021}
!15 = !{i64 1564135765322834517}
!16 = !{i64 7490549011668471067}
!17 = !{i64 -4370826456013781970}
!18 = !{i64 -3880375126840751788}
!19 = !{i64 7218324841008857063}
!20 = !{i64 -3007026107481987120}
!21 = !{i64 -4759762169721182250}
!22 = !{i64 947460603012713844}
!23 = !{i64 -8414465777975419255}
!24 = !{i64 -5834318194254009081}
!25 = !{i64 5687047111564693600}
!26 = !{i64 -1850357279236598014}
!27 = !{i64 -2883555232906572926}
!28 = !{i64 8618231762821683921}
!29 = !{i64 9164628430299145092}
!30 = !{i64 -6235189657350564055}
!31 = !{i64 -6860026304082479283}
!32 = !{i64 1461774753722121380}
!33 = !{i64 -4142083989498122273}
!34 = !{i64 6823554023627849010}
!35 = !{i64 3067291712016742664}
!36 = !{i64 -5145280544080191727}
!37 = !{i64 -5297245250663620825}
!38 = !{i64 -524052083578518475}
!39 = !{i64 -4517533185732334762}
!40 = !{i64 2346571757924430792}
!41 = !{i64 669270671394802784}
!42 = !{i64 -4372065835429744829}
!43 = !{i64 -1931124984160846851}
!44 = !{i64 -3524575504775702736}
!45 = !{i64 -4910044210816707787}
!46 = !{i64 -1033414160314169377}
!47 = !{i64 6864536026677364713}
!48 = !{i64 1395976656840326597}
!49 = !{i64 -5014113401672980513}
!50 = !{i64 3447055648860841439}
!51 = !{i64 3825761093760879348}
!52 = !{i64 -1971214899319848998}
!53 = !{i64 5518873671291265565}
!54 = !{i64 5783654722869837311}
!55 = !{i64 4915996198721720245}
!56 = !{i64 -1886564881822757678}
!57 = !{i64 -3283872301837235114}
!58 = !{i64 -3918412058119253435}
!59 = !{i64 -3441556618249294824}
!60 = !{i64 7378439491885975691}
!61 = !{i64 -1156720602752517019}
!62 = !{i64 6084871210644351702}
!63 = !{i64 6849801671324106594}
!64 = !{i64 -1637246020695066381}
!65 = !{i64 1360539833336636730}
!66 = !{i64 -7917392898936978482}
!67 = !{i64 4397304550096120444}
!68 = !{i64 6239885662341721179}
!69 = !{i64 2094301862509906923}
!70 = !{i64 7906539164316537656}
!71 = !{i64 -4051107717396125239}
!72 = !{i64 3758115801502913174}
!73 = !{i64 3644078264335747721}
!74 = !{i64 7668892749989667084}
!75 = !{i64 -8445162691930126513}
!76 = !{i64 -2701787645542375599}
!77 = !{i64 -587791641223952262}
!78 = !{i64 9123423973074146943}
!79 = !{i64 1582905005507049309}
!80 = !{i64 -8143679912024269191}
!81 = !{i64 -4706482421304353051}
!82 = !{i64 5478486784861073993}
!83 = !{i64 7051621321032091926}
!84 = !{i64 4743726299319550971}
!85 = !{i64 1706861074735748145}
!86 = !{i64 8466588392202257510}
!87 = !{i64 -6631094515035268993}
!88 = !{i64 -3402418168334483027}
!89 = !{i64 1689678139659910589}
!90 = !{i64 7772915727537623722}
!91 = !{i64 -7689697479048273420}
!92 = !{i64 -851494618668501264}
!93 = !{i64 -7548587780462258273}
!94 = !{i64 -283323540146141715}
!95 = !{i64 -8142615663355892569}
!96 = !{i64 4105024990168731378}
!97 = !{i64 4768463758853779944}
!98 = !{i64 4031776486699737619}
!99 = !{i64 4887988543255554601}
!100 = !{i64 -1318447383911722414}
!101 = !{i64 -8902016372263873622}
!102 = !{i64 3125254706544638577}
!103 = !{i64 -8107899358637756634}
!104 = !{i64 -2213029633131588954}
!105 = !{i64 -2359353471807091218}
!106 = !{i64 8276669897241319872}
!107 = !{i64 -1194066891449087377}
!108 = !{i64 -6253230839746497342}
!109 = !{i64 2784829550188948021}
!110 = !{i64 4871597806849804379}
!111 = !{i64 -770822626613449036}
!112 = !{i64 -2891901574880253078}
!113 = !{i64 -7853256647244737872}
!114 = !{i64 -4187637431572808709}
!115 = !{i64 -8772930597488013860}
!116 = !{i64 1349166803560929296}
!117 = !{i64 -6082036231765810313}
!118 = !{i64 6554785699930087874}
!119 = !{i64 8683432399661034078}
!120 = !{i64 -1724909020043524217}
!121 = !{i64 -6139782948577205237}
!122 = !{i64 8820334159238302197}
!123 = !{i64 -2039645719471111325}
!124 = !{i64 6060207670227844986}
!125 = !{i64 -4929868154877893826}
!126 = !{i64 4610681404435136462}
!127 = !{i64 -856188314064534895}
!128 = !{i64 -4948199851407617669}
!129 = !{i64 914592812427063352}
!130 = !{i64 4902982399139548323}
!131 = !{i64 -2091725978057384638}
!132 = !{i64 81218818587119968}
!133 = !{i64 -849207296929790636}
!134 = !{i64 -7061523736803357750}
!135 = !{i64 4621347816510201054}
!136 = !{i64 5893371494190104609}
!137 = !{i64 4758801360385396735}
!138 = !{i64 2736870197818956325}
!139 = !{i64 7826815216429305970}
!140 = !{i64 -1209345677044954000}
!141 = !{i64 8913019890393471954}
!142 = !{i64 -1517272583483569137}
!143 = !{i64 5821118664507652752}
!144 = !{i64 7102150209877842468}
!145 = !{i64 -5478335171692999155}
!146 = !{i64 7684491721068038338}
!147 = !{i64 1833623976122821461}
!148 = !{i64 3501869692351211717}
!149 = !{i64 17398192384493584}
!150 = !{i64 -4782498452249487035}
!151 = !{i64 2585257306000500794}
!152 = !{i64 5363906655344728469}
!153 = !{i64 2595124999408185478}
!154 = !{i64 6505776342392609272}
!155 = !{i64 3993796858236898491}
!156 = !{i64 -18431954703562266}
!157 = !{i64 1055462993393058474}
!158 = !{i64 8204058454349177821}
!159 = !{i64 -102715432507060572}
!160 = !{i64 -7331578722618222288}
!161 = !{i64 -4620334571948798523}
!162 = !{i64 6693049113306090799}
!163 = !{i64 3299216931696593693}
!164 = !{i64 8672992777738005568}
!165 = !{i64 6344134339638636863}
!166 = !{i64 2984267842011147499}
!167 = !{i64 3533855699882533444}
!168 = !{i64 -4701142705406197435}
!169 = !{i64 5586375712205529833}
!170 = !{i64 3330441922623548894}
!171 = !{i32 8, !"PIC Level", i32 2}
!172 = !{i32 7, !"PIE Level", i32 2}
!173 = !{i32 2, !"RtLibUseGOT", i32 1}
!174 = !{i32 7, !"uwtable", i32 2}
!175 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!176 = !{i64 -4594546653911907875}
!177 = !{i64 7816272115802784405}
!178 = !{i64 6241213901077712125}
!179 = !{i64 -6166304947927189327}
!180 = !{i64 3688580646373831096}
!181 = !{i64 1498557917916051441}
!182 = !{i64 3829696561769355313}
!183 = !{i64 2638237886012278023}
!184 = !{i64 166910231268857847}
!185 = !{i64 8556505617372559308}
!186 = !{i64 1177104432047718414}
!187 = !{i64 -1023968661086896012}
!188 = !{i64 -9039642701893559502}
!189 = !{i64 2859185543653848662}
!190 = !{i64 -401473859953402249}
!191 = !{i64 5997675271428726928}
!192 = !{i64 1505059039862969147}
!193 = !{i64 -7999927730127311670}
!194 = !{i64 -5264537119416304794}
!195 = !{i64 -6116971000943582765}
!196 = !{i64 -8653919250736323996}
!197 = !{i64 -3875738380410359947}
!198 = !{i64 3982935204179999820}
!199 = !{i64 3278713512910864959}
!200 = !{i64 -5111436099712529925}
!201 = !{i64 1809492269127730829}
!202 = !{i64 -825455501749761289}
!203 = !{i64 -8963013671555212606}
!204 = !{i64 -7861091550966131396}
!205 = !{i64 3728082778730964555}
!206 = !{i64 5989716899691282808}
!207 = !{i64 7238913117348456139}
!208 = !{i64 -8030420040090188254}
!209 = !{i64 8522119255730195765}
!210 = !{i64 -6784712229736257331}
!211 = !{i64 -7171608707227459528}
!212 = !{i64 4119463437460071005}
!213 = !{i64 -5311545336905166542}
!214 = !{i64 8457975960613628788}
!215 = !{i64 8656107753166168393}
!216 = !{i64 -5811004458230701975}
!217 = !{i64 2975360613120249692}
!218 = !{i64 4870028735322986966}
!219 = !{i64 -2424505613273562298}
!220 = !{i64 2303406390270230214}
!221 = !{i64 2135891610690675478}
!222 = !{i64 3051749621975083303}
!223 = !{i64 -7321261562024590255}
!224 = !{i64 3775409259286900096}
!225 = !{i64 1941369966953052319}
!226 = !{i64 8663779063255165483}
!227 = !{i64 -4385999960818470403}
!228 = !{i64 -874247557796178654}
!229 = !{i64 4208893709764369908}
!230 = !{i64 -2401968658543505804}
!231 = !{i64 -1803077080580392130}
!232 = !{i64 -5848713185626718389}
!233 = !{i64 8502472759966130134}
!234 = !{i64 227010135980977870}
!235 = !{i64 -7010963760926834869}
!236 = !{i64 4829221037906939004}
!237 = !{i64 -140396188400189977}
!238 = !{i64 3961690979446345760}
!239 = !{i64 -6785554494542487272}
!240 = !{i64 -4534577442398218624}
!241 = !{i64 -6708206373530900691}
!242 = !{i64 5649415922520953044}
!243 = !{i64 -69294383016093939}
!244 = !{i64 -5430755574356546466}
!245 = !{i64 5611322028413295324}
!246 = !{i64 -8635279086123006022}
!247 = !{i64 -5773566487094649194}
!248 = !{i64 -3671326907365788709}
!249 = !{!"address", !"read_provenance"}
!250 = !{i64 -8599836695374404404}
!251 = !{i64 697751930151057638}
!252 = !{i64 -5507656927741594401}
!253 = !{i64 8164779747714516283}
!254 = !{i64 5790686688322137977}
!255 = !{i64 7332690832570190278}
!256 = !{i64 -424743771448065250}
!257 = !{i64 -8772089633914541640}
!258 = !{i64 -2812366524916064365}
!259 = !{i64 -7972153214365933661}
!260 = !{i64 -5822205672221035496}
!261 = !{i64 562114512052149656}
!262 = !{i64 -6344740819046557790}
!263 = !{i64 3033156797966575108}
!264 = !{i64 -2137330593418060784}
!265 = !{i64 -7218413646995262131}
!266 = !{i64 745223340311089398}
!267 = !{i64 -7859447153571747736}
!268 = !{i64 -9063739529518326030}
!269 = !{i64 -8744811931895533947}
!270 = !{i64 7469892854345931880}
!271 = !{i64 1322278696825464}
!272 = !{i64 1123449340772644724}
!273 = !{i64 -1641383025132459772}
!274 = !{i64 6058433136200923032}
!275 = !{i64 -4373443819769075151}
!276 = !{i64 4755592832599096135}
!277 = !{i64 903081482288870363}
!278 = !{i64 4825321085010193711}
!279 = !{i64 -150047084092419566}
!280 = !{i64 -6535340622947657506}
!281 = !{i64 -7878407188529128519}
!282 = !{i64 -1045622375004078819}
!283 = !{i64 438645251900913163}
!284 = !{i64 4896325097263657521}
!285 = !{i64 -3481190167918770992}
!286 = !{i64 4243632157654511374}
!287 = !{i64 2940996423007821384}
!288 = !{i64 8339803670071889876}
!289 = !{i64 4944436468079407258}
!290 = !{i64 7575741558233867697}
!291 = !{i64 8651078372058610353}
!292 = !{i64 -405245984093177168}
!293 = !{i64 -534271258082050827}
!294 = !{i64 -8314305688802708275}
!295 = !{i64 -7375972997017903706}
!296 = !{i64 -1578637296988351842}
!297 = !{i64 -1451496061513472849}
!298 = !{i64 4513385224344538892}
!299 = !{i64 6242266527576335262}
!300 = !{i64 -7161800845394110527}
!301 = !{i64 6641288361189766920}
!302 = !{i64 3888438951504307212}
!303 = !{i64 2436857246295079512}
!304 = !{i64 6499101211627227364}
!305 = !{i64 8496420901612192410}
!306 = !{i64 -6490812589505791383}
!307 = !{i64 5632489048402117718}
!308 = !{i64 -271281972124242410}
!309 = !{i64 -2868828768339331043}
!310 = !{i64 2573127123679747124}
!311 = !{i64 7691791096147674761}
!312 = !{i64 -3028779714792674049}
!313 = !{i64 6303429852324459527}
!314 = !{i64 112659113094693716}
!315 = !{i64 -6499937879894076903}
!316 = !{i64 -9028007759038109854}
!317 = !{i64 -8520680420740453626}
!318 = !{i64 9067663797317558752}
!319 = !{i64 -3329791424552865543}
!320 = !{i64 3144542790406885307}
!321 = !{i64 651721741470027765}
!322 = !{i64 -3012832127318829860}
!323 = !{i64 -4856478539644921240}
!324 = !{i64 -3150667689500121801}
!325 = !{i64 -1981170971849368110}
!326 = !{i64 812764142272801396}
!327 = !{i64 -6976337826498946557}
!328 = !{i64 -5952867721635863732}
!329 = !{i64 2664328296298654914}
!330 = !{i64 -7583787637674386670}
!331 = !{i64 -1995347086088839277}
!332 = !{i64 -2823222266317871167}
!333 = !{i64 -3374635421891702861}
!334 = !{i64 1766833209679083141}
!335 = !{i64 6101273628294728361}
!336 = !{i64 -2610784822135446433}
!337 = !{i64 -6411819289309696583}
!338 = !{i64 -8094240188536368037}
!339 = !{i64 2366165623768388698}
!340 = !{i64 1249644992642452961}
!341 = !{i64 1479296803414280478}
!342 = !{i64 -6428025445339308395}
!343 = !{i64 -4137760065347526418}
!344 = !{i64 3345511374196884254}
!345 = !{i64 4584493376782936072}
!346 = !{i64 1609082262991229747}
!347 = !{i64 7922101364011771095}
!348 = !{i64 -2670723694305189727}
!349 = !{i64 1530184181270274906}
!350 = !{i64 -5517338572664759117}
!351 = !{i64 -5440382258916258168}
!352 = !{i64 -7678306184793771821}
!353 = !{i64 -3723792236046463040}
!354 = !{i64 -2332515440830849067}
!355 = !{i64 -7251539332046057174}
!356 = !{i64 699270960773090058}
!357 = !{i64 8309096882015876150}
!358 = !{i64 6985751712804355773}
!359 = !{i64 2634819384210575716}
!360 = !{i64 455544457552072158}
!361 = !{i64 -7679395093262286852}
!362 = !{i64 6611937786202877724}
!363 = !{i64 -8451234109145573672}
!364 = !{i64 -6387204024897238417}
!365 = !{i64 -4298015708576850516}
!366 = !{i64 2342488190097115467}
!367 = !{i64 -6073890161143951469}
!368 = !{i64 -7414638327406923941}
!369 = !{i64 -3783258380250823431}
!370 = !{i64 1303385243381486724}
!371 = !{i64 4454863672576467051}
!372 = !{i64 7177342550864243240}
!373 = !{i64 3058667875093318706}
!374 = !{i64 -8561894499499242876}
!375 = !{i64 8225691816601377496}
!376 = !{i64 479308482927826848}
!377 = !{i64 -7387677021173313785}
!378 = !{i64 4606771247399202572}
!379 = !{i64 -5704528128924231929}
!380 = !{i64 5973555695871674241}
!381 = !{i64 6623333748107544900}
!382 = !{i64 15555335031680283}
!383 = !{i64 6714457086150742043}
!384 = !{i64 8087963882813926517}
!385 = !{i64 3277711929247287243}
!386 = !{i64 8806287365291460749}
!387 = !{i64 4379439295565004099}
!388 = !{i64 1371024632436915586}
!389 = !{i64 -797647822691776746}
!390 = !{i64 -3612566185193719482}
!391 = !{i64 -3800182493613884486}
!392 = !{i64 -3953308871309941737}
!393 = !{i64 1030106903644251028}
!394 = !{i64 4677846647179848383}
!395 = !{i64 -2298654995355373418}
!396 = !{i64 -8350917734198445831}
!397 = !{i64 -4574980116362201689}
!398 = !{i64 -8712980433614021674}
!399 = !{i64 -1568304423792686035}
!400 = !{i64 4955564052391677150}
!401 = !{i64 -5354199542626598227}
!402 = !{i64 3498043544855265899}
!403 = !{i64 853970047033112270}
!404 = !{i64 4036901985880615097}
!405 = !{i64 2779041378909429515}
!406 = !{i64 800935068166598686}
!407 = !{i64 3854200255829217355}
!408 = !{i64 2297462413515289322}
!409 = !{i64 7099655256598882996}
!410 = !{i64 3437063594527855094}
!411 = !{i64 2784171469358886125}
!412 = !{i64 6197577052375066269}
!413 = !{i64 -5309849934204785065}
!414 = !{i64 -7086568692968593362}
!415 = !{i64 -2787823282343150}
!416 = !{i64 5959006680123524645}
!417 = !{i64 -3256597587592278769}
!418 = !{i64 -3675326284997384696}
!419 = !{i64 3086833538523674578}
!420 = !{i64 -4022918999801592337}
!421 = !{i64 7477654269296920108}
!422 = !{i64 -1210192097338405451}
!423 = !{i64 -7750347520403277694}
!424 = !{i64 -2860545747744890407}
!425 = !{i64 7430875044250314295}
!426 = !{i64 2024887965659262937}
!427 = !{i64 2740869610352420143}
!428 = !{i64 -5059021920225500858}
!429 = !{i64 -2698137605600943397}
!430 = !{i64 -3300364584936536168}
!431 = !{i64 -6259122989090493708}
!432 = !{i64 3216525809477971378}
!433 = !{i64 7051727849709946567}
!434 = !{i64 6761264708200510124}
!435 = !{i64 2137353190427739065}
!436 = !{i64 5410677080903518754}
!437 = !{i64 7096842742967677649}
!438 = !{i64 -9144620746014138353}
!439 = !{i64 4399924150797478539}
!440 = !{i64 -4323108791320847972}
!441 = !{i64 -4381027893870896484}
!442 = !{i64 6661589535716141589}
!443 = !{i64 -8281403920235675400}
!444 = !{i64 -4420493884681069281}
!445 = !{i64 -4702832870943623808}
!446 = !{i64 2855210434777070769}
!447 = !{i64 -1843856757150994800}
!448 = !{i64 8805108888968846709}
!449 = !{i64 -1072439506747449349}
!450 = !{i64 2560193157698397256}
!451 = !{i64 3771838729372273303}
!452 = !{i64 -4821663875795067039}
!453 = !{i64 -6298104195146463661}
!454 = !{i64 -5276636945505972320}
!455 = !{i64 4461655996251952118}
!456 = !{i64 1674811998416661696}
!457 = !{i64 -628072689477338703}
!458 = !{i64 -1367362458170295357}
!459 = !{i64 7753658280278070588}
!460 = !{i64 -6043760830815378168}
!461 = !{i64 7066512628986718666}
!462 = !{i64 376071585922703195}
!463 = !{i64 -3000430401434887556}
!464 = !{i64 1835662705002565297}
!465 = !{i64 2991591324323861866}
!466 = !{i64 -3782981375274940964}
!467 = !{i64 -381875658253062642}
!468 = !{i64 -7141809598381222060}
!469 = !{i64 2161723412954711059}
!470 = !{i64 -2205744876969863962}
!471 = !{i64 8505380511899318720}
!472 = !{i64 2402557234842458593}
!473 = !{i64 4376264518137360209}
!474 = !{i64 -7457326014664132509}
!475 = !{i64 -918554896156309207}
!476 = !{i64 -3841801493839772089}
!477 = !{i64 -7887657092181159296}
!478 = !{i64 8102064005035888643}
!479 = !{i64 8503299439617435259}
!480 = !{i64 1725295124059827213}
!481 = !{i64 -8150663917195342597}
!482 = !{i64 -5679988836834863905}
!483 = !{i64 -2565239886848784379}
!484 = !{i64 -2379051005279179342}
!485 = !{i64 -4783878107083167194}
!486 = !{i64 1230630953094842521}
!487 = !{i64 -8963679916618713150}
!488 = !{i64 -7648155338047642826}
!489 = !{i64 1514521645579781913}
!490 = !{i64 -7427121118985582365}
!491 = !{i64 -4712940822334213834}
!492 = !{i64 -8309514323681368260}
!493 = !{i64 -2237029340886535441}
!494 = !{i64 4358262814787908236}
!495 = !{i64 8642859224103399380}
!496 = !{i64 9033769919097250801}
!497 = !{i64 8153036603398361236}
!498 = !{i64 -7980344906219793049}
!499 = !{i64 -1421002754062085383}
!500 = !{i64 -4457296287134730647}
!501 = !{i64 7217830902133014978}
!502 = !{i64 -6867846816611839964}
!503 = !{i64 4446773239237404663}
!504 = !{i64 7067808024087418697}
!505 = !{i64 -8467058047113789317}
!506 = !{i64 4506289254046563127}
!507 = !{i64 -1639590627374300344}
!508 = !{i64 -9121170507607175503}
!509 = !{i64 4187332895721996052}
!510 = !{i64 -4166183846892733847}
!511 = !{i64 8302095227148671339}
!512 = !{i64 7844166214459440014}
!513 = !{i64 7173578036021576330}
!514 = !{i64 5791408863936251660}
!515 = !{i64 -2117733512901483641}
!516 = !{i64 3860410154314325965}
!517 = !{i64 -1312502643438218828}
!518 = !{i64 3115761932703024659}
!519 = !{i64 828129338312106935}
!520 = !{i64 -3506287215713347953}
!521 = !{i64 -8860175709281930526}
!522 = !{i64 -6770102001978571967}
!523 = !{i64 -7573408772194845706}
!524 = !{i64 3863343044578294267}
!525 = !{i64 -3983881210407969989}
!526 = !{i64 5316307183402575863}
!527 = !{i64 -2955517497181096639}
!528 = !{i64 -5890334707987355762}
!529 = !{i64 -816340930145558188}
!530 = !{i64 -8137421559264276586}
!531 = !{i64 9109103644979573737}
!532 = !{i64 -4274825171370808123}
!533 = !{i64 8990396652554003878}
!534 = !{i64 -7204382766390908294}
!535 = !{i64 3699621395936854869}
!536 = !{i64 -3335697713773359298}
!537 = !{i64 -1005550309496451311}
!538 = !{i64 7128288459167632983}
!539 = !{i64 -3066716834299901959}
!540 = !{i64 225614560856578445}
!541 = !{i64 -1012822825088774659}
!542 = !{i64 -5621991742955848667}
!543 = !{i64 -1866916809513651602}
!544 = !{i64 8137968807674435575}
!545 = !{i64 1552334527334105083}
!546 = !{i64 -8503756297644261213}
!547 = !{i64 8377166826743863025}
!548 = !{i64 -6271954754560501503}
!549 = !{i64 -4474272225174637298}
!550 = !{i64 -4828237256340469127}
!551 = !{i64 8533707428446278464}
!552 = !{i64 -291480160130727050}
!553 = !{i64 7369347324105632782}
!554 = !{i64 721826443693816825}
!555 = !{i64 -6991068525343341437}
!556 = !{i64 -8192245022690313329}
!557 = !{i64 -8444670634481272456}
!558 = !{i64 -8050045182956313053}
!559 = !{i64 3154641185670435419}
!560 = !{i64 -6991247755485130065}
!561 = !{i64 4212534268892106658}
!562 = !{i64 1146989771707254977}
!563 = !{i64 1572264030142692014}
!564 = !{i64 1263722040641462041}
!565 = !{i64 -7735827744256720982}
!566 = !{i64 -1981979611795067727}
!567 = !{i64 102668510484412051}
!568 = !{i64 -2114125557003269289}
!569 = !{i64 -3264790703640679058}
!570 = !{i64 589343708246632518}
!571 = !{i64 6205270168974897645}
!572 = !{i64 4786591396763972674}
!573 = !{i64 -7061635755413374549}
!574 = !{i64 1381660469773756902}
!575 = !{i64 2368120514979725399}
!576 = !{i64 1388042293808307052}
!577 = !{i64 -3890088202826080456}
!578 = !{i64 -7147113949316603347}
!579 = !{i64 -7384423455420412784}
!580 = !{i64 -3731516115024635929}
!581 = !{i64 -1336505236636950203}
!582 = !{i64 6069815823432387827}
!583 = !{i64 -518939300424457801}
!584 = !{i64 -3604625500273509932}
!585 = !{i64 782625399835865784}
!586 = !{i64 -4534822597841403333}
!587 = !{i64 6933049767395661575}
!588 = !{i64 7371190733361385655}
!589 = !{i64 -4672945751568376874}
!590 = !{i64 995255670014008454}
!591 = !{i64 -1563527592753839808}
!592 = !{i64 -7591833010925842469}
!593 = !{i64 -5540950590210595468}
!594 = !{i64 -3482952459954012131}
!595 = !{i64 6441276622060962215}
!596 = !{i64 -2497555841111326033}
!597 = !{i64 6849304694076836085}
!598 = !{i64 -4658757027231197156}
!599 = !{i64 -1027662441717188585}
!600 = !{i64 -6175297879806950103}
!601 = !{i64 -1157482443644139767}
!602 = !{i64 -1318951706902652798}
!603 = !{i64 564412326702333552}
!604 = !{i64 679131537724314944}
!605 = !{i64 3876578513367327106}
!606 = !{i64 -7489672004730082443}
!607 = !{i64 -6076326059422529531}
!608 = !{i64 5720415145329763155}
!609 = !{i64 1758484543633165355}
!610 = !{i64 1784016916389521352}
!611 = !{i64 8783263430959052785}
!612 = !{i64 -6624172908554205067}
!613 = !{i64 3645030924250523773}
!614 = !{i64 -1477922263800434161}
!615 = !{i64 7265513515242548459}
!616 = !{i64 -787395054263972961}
!617 = !{i64 86038845172275448}
!618 = !{i64 7161425931735797707}
!619 = !{i64 953248674175052841}
!620 = !{i64 5516440238115026048}
!621 = !{i64 8984819869991960898}
!622 = !{i64 6193041966584619988}
!623 = !{i64 -2624081020897602054}
