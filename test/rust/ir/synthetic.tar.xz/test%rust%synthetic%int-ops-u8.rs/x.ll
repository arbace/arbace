; ModuleID = 'int_ops_u8.ab97dbae693642ab-cgu.0'
source_filename = "int_ops_u8.ab97dbae693642ab-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCseJnXURkPMql_10int_ops_u8, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseJnXURkPMql_10int_ops_u8, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseJnXURkPMql_10int_ops_u8 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !3
@alloc_025a5709ba9544310ca8368ed72bebad = private unnamed_addr constant [4 x i8] c"\08\00\00\00", align 4, !guid !4
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !5
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !7
@alloc_bc6b42204dbdbae38b5ca4af01898c89 = private unnamed_addr constant [34 x i8] c"test/rust/synthetic/int-ops-u8.rs\00", align 1, !guid !8
@alloc_a86ee8176aa67afec68ae8e7a0551d2c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bc6b42204dbdbae38b5ca4af01898c89, [16 x i8] c"!\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !9
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !10
@alloc_cb742a493b8e02858af6e3e5d1677431 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bc6b42204dbdbae38b5ca4af01898c89, [16 x i8] c"!\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !11
@alloc_5880d95b5bf4728dcf6885494c76eb52 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bc6b42204dbdbae38b5ca4af01898c89, [16 x i8] c"!\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !12
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !13
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !14
@alloc_2dbd61561d1dc78121cd8e5ee98f8154 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bc6b42204dbdbae38b5ca4af01898c89, [16 x i8] c"!\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !15
@alloc_25be3c2986333bc1d9dc7dc3b19c705f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bc6b42204dbdbae38b5ca4af01898c89, [16 x i8] c"!\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !16
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !17
@alloc_3f8a030187d908ae175dd04a608ffd87 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bc6b42204dbdbae38b5ca4af01898c89, [16 x i8] c"!\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !18
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !19
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !20
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !21
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !22
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !23
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !24
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !25
@alloc_1f1d7c1ec8c9041988f7c79d620acc00 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\02\00\00\05\00\00\00" }>, align 8, !guid !26
@alloc_5aa1d1250638a5285856df0c8e3018a3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00K\07\00\00\01\00\00\00" }>, align 8, !guid !27
@anon.994e02650ca0984a4e232d970c64dac2.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !28
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !29
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !30
@alloc_eff87de2e562ad9bea1d5ede245212a6 = private unnamed_addr constant [183 x i8] c"unsafe precondition(s) violated: u8::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !31
@alloc_57df2bd3515ba57ec27b75aa1042dee2 = private unnamed_addr constant [183 x i8] c"unsafe precondition(s) violated: u8::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !32
@alloc_f61fc5fd845387df941deb3653b9481f = private unnamed_addr constant [183 x i8] c"unsafe precondition(s) violated: u8::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !33
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !34
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_ }>, align 8, !guid !35
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCseJnXURkPMql_10int_ops_u8 }>, align 8, !guid !36
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !37
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !38
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !39
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !40
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !41
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCseJnXURkPMql_10int_ops_u8 }>, align 8, !guid !42

; <str>::parse::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parsehECseJnXURkPMql_10int_ops_u8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !48 {
start:
; call <u8 as core::str::traits::FromStr>::from_str
  %0 = call { i1, i8 } @_RNvXsw_NtCsl10jNU3mE6R_4core3numhNtNtNtB7_3str6traits7FromStr8from_strCseJnXURkPMql_10int_ops_u8(ptr %self.0, i64 %self.1) #17
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <core::fmt::rt::Argument>::new_binary::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryhECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !49 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refB9_(ptr %x) #17
; call <core::ptr::non_null::NonNull<u8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !50 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCseJnXURkPMql_10int_ops_u8(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECseJnXURkPMql_10int_ops_u8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !51 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCseJnXURkPMql_10int_ops_u8(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECseJnXURkPMql_10int_ops_u8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !52 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCseJnXURkPMql_10int_ops_u8(ptr align 4 %x) #17
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECseJnXURkPMql_10int_ops_u8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !53 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<u8>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionhEE8from_refCseJnXURkPMql_10int_ops_u8(ptr %x) #17
; call <core::ptr::non_null::NonNull<core::option::Option<u8>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionhEE4castuECseJnXURkPMql_10int_ops_u8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionhENtNtB7_3fmt5Debug3fmtCs7CppTae75M1_5alloc, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<u8, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResulthNtNtNtB7_3num5error13ParseIntErrorEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !54 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<u8, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResulthNtNtNtB9_3num5error13ParseIntErrorEE8from_refCseJnXURkPMql_10int_ops_u8(ptr %x) #17
; call <core::ptr::non_null::NonNull<core::result::Result<u8, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResulthNtNtNtBa_3num5error13ParseIntErrorEE4castuECseJnXURkPMql_10int_ops_u8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCseJnXURkPMql_10int_ops_u8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(u8, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugThbEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !55 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(u8, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullThbEE8from_refCseJnXURkPMql_10int_ops_u8(ptr %x) #17
; call <core::ptr::non_null::NonNull<(u8, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullThbEE4castuECseJnXURkPMql_10int_ops_u8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtThbENtB6_5Debug3fmtCseJnXURkPMql_10int_ops_u8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !56 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCseJnXURkPMql_10int_ops_u8(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECseJnXURkPMql_10int_ops_u8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCseJnXURkPMql_10int_ops_u8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalhECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !57 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refB9_(ptr %x) #17
; call <core::ptr::non_null::NonNull<u8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsc_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::option::Option<u8>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionhEE4castuECseJnXURkPMql_10int_ops_u8(ptr %self) unnamed_addr #0 !guid !58 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<u8, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResulthNtNtNtBa_3num5error13ParseIntErrorEE4castuECseJnXURkPMql_10int_ops_u8(ptr %self) unnamed_addr #0 !guid !59 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<(u8, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullThbEE4castuECseJnXURkPMql_10int_ops_u8(ptr %self) unnamed_addr #0 !guid !60 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECseJnXURkPMql_10int_ops_u8(ptr %self) unnamed_addr #0 !guid !61 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECseJnXURkPMql_10int_ops_u8(ptr %self) unnamed_addr #0 !guid !62 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECseJnXURkPMql_10int_ops_u8(ptr %self) unnamed_addr #0 !guid !63 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECseJnXURkPMql_10int_ops_u8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !64 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECseJnXURkPMql_10int_ops_u8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !65 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECseJnXURkPMql_10int_ops_u8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !66 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECseJnXURkPMql_10int_ops_u8(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !67 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u8>
; Function Attrs: nounwind nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefthECseJnXURkPMql_10int_ops_u8(i8 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !68 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 1 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i8
  %_0 = call i8 @llvm.fshl.i8(i8 %x, i8 %x, i8 %1)
  ret i8 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u8>
; Function Attrs: nounwind nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righthECseJnXURkPMql_10int_ops_u8(i8 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !69 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 1 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i8
  %_0 = call i8 @llvm.fshr.i8(i8 %x, i8 %x, i8 %1)
  ret i8 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::is_val_statically_known::<u8>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownhECseJnXURkPMql_10int_ops_u8(i8 %_arg) unnamed_addr #2 !guid !70 {
start:
  ret i1 false
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseJnXURkPMql_10int_ops_u8(i8 %dummy) unnamed_addr #0 !guid !71 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !72
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECseJnXURkPMql_10int_ops_u8(i32 %dummy) unnamed_addr #0 !guid !73 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !72
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseJnXURkPMql_10int_ops_u8(i32 %dummy) unnamed_addr #0 !guid !74 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !72
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseJnXURkPMql_10int_ops_u8(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !75 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseJnXURkPMql_10int_ops_u8(ptr %f) #17
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #17
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseJnXURkPMql_10int_ops_u8(ptr align 8 %_1) unnamed_addr #0 !guid !76 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseJnXURkPMql_10int_ops_u8(ptr %_4) #20
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCseJnXURkPMql_10int_ops_u8() #17
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CseJnXURkPMql_10int_ops_u8(i8 %_2) #17
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCseJnXURkPMql_10int_ops_u8(ptr %_1) unnamed_addr #0 !guid !77 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseJnXURkPMql_10int_ops_u8(ptr %0) #17
  ret i32 %_0
}

; int_ops_u8::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCseJnXURkPMql_10int_ops_u84main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !78 {
start:
  %0 = alloca [16 x i8], align 8
  %_288 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_283 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_278 = alloca [24 x i8], align 8
  %_277 = alloca [24 x i8], align 8
  %_273 = alloca [24 x i8], align 8
  %_270 = alloca [8 x i8], align 8
  %_263 = alloca [16 x i8], align 8
  %_262 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_258 = alloca [4 x i8], align 4
  %_256 = alloca [1 x i8], align 1
  %_249 = alloca [16 x i8], align 8
  %_248 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_246 = alloca [4 x i8], align 4
  %_244 = alloca [4 x i8], align 4
  %_237 = alloca [16 x i8], align 8
  %_236 = alloca [16 x i8], align 8
  %_235 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_233 = alloca [8 x i8], align 8
  %_231 = alloca [4 x i8], align 4
  %_227 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_220 = alloca [16 x i8], align 8
  %_219 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_216 = alloca [2 x i8], align 1
  %_214 = alloca [1 x i8], align 1
  %_210 = alloca [2 x i8], align 1
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_200 = alloca [1 x i8], align 1
  %_197 = alloca [1 x i8], align 1
  %_190 = alloca [16 x i8], align 8
  %_189 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_187 = alloca [2 x i8], align 1
  %_184 = alloca [2 x i8], align 1
  %_177 = alloca [16 x i8], align 8
  %_176 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_173 = alloca [1 x i8], align 1
  %_170 = alloca [1 x i8], align 1
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [1 x i8], align 1
  %_156 = alloca [1 x i8], align 1
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [1 x i8], align 1
  %_144 = alloca [1 x i8], align 1
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [1 x i8], align 1
  %_130 = alloca [1 x i8], align 1
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [2 x i8], align 1
  %_98 = alloca [2 x i8], align 1
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [1 x i8], align 1
  %_86 = alloca [1 x i8], align 1
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [1 x i8], align 1
  %_74 = alloca [1 x i8], align 1
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [1 x i8], align 1
  %_62 = alloca [1 x i8], align 1
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [2 x i8], align 1
  %_50 = alloca [2 x i8], align 1
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [2 x i8], align 1
  %_38 = alloca [2 x i8], align 1
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [1 x i8], align 1
  %min = alloca [1 x i8], align 1
; call core::hint::black_box::<u8>
  %_4 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseJnXURkPMql_10int_ops_u8(i8 0) #17
; call core::hint::black_box::<u8>
  %_5 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseJnXURkPMql_10int_ops_u8(i8 -1) #17
  store i8 %_4, ptr %min, align 1
  store i8 %_5, ptr %max, align 1
; call core::hint::black_box::<u8>
  %one = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseJnXURkPMql_10int_ops_u8(i8 1) #17
; call core::hint::black_box::<u8>
  %three = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseJnXURkPMql_10int_ops_u8(i8 3) #17
  store ptr %min, ptr %args, align 8
  %1 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_025a5709ba9544310ca8368ed72bebad, ptr %2, align 8
  %_291 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_15, ptr %_291) #17
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  %_292 = load ptr, ptr %3, align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_16, ptr %_292) #17
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  %_293 = load ptr, ptr %4, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_293) #17
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_15, i64 16, i1 false)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_16, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECseJnXURkPMql_10int_ops_u8(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #17
  %_9.0 = extractvalue { ptr, ptr } %8, 0
  %_9.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %9 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %11, align 8
  %_294 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexhEB7_(ptr sret([16 x i8]) align 8 %_28, ptr %_294) #17
  %12 = getelementptr inbounds i8, ptr %args2, i64 8
  %_295 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_binary::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryhECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_29, ptr %_295) #17
  %13 = getelementptr inbounds i8, ptr %args2, i64 16
  %_296 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_octal::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalhECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_30, ptr %_296) #17
  %14 = getelementptr inbounds i8, ptr %args2, i64 24
  %_297 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexhEB7_(ptr sret([16 x i8]) align 8 %_31, ptr %_297) #17
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_28, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_29, i64 16, i1 false)
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_30, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECseJnXURkPMql_10int_ops_u8(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #17
  %_21.0 = extractvalue { ptr, ptr } %19, 0
  %_21.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %20 = load i8, ptr %max, align 1
; call <u8>::checked_add
  %21 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_addCseJnXURkPMql_10int_ops_u8(i8 %20, i8 %one) #17
  %22 = extractvalue { i1, i8 } %21, 0
  %23 = extractvalue { i1, i8 } %21, 1
  %24 = zext i1 %22 to i8
  store i8 %24, ptr %_38, align 1
  %25 = getelementptr inbounds i8, ptr %_38, i64 1
  store i8 %23, ptr %25, align 1
  %26 = load i8, ptr %min, align 1
; call <u8>::checked_add
  %27 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_addCseJnXURkPMql_10int_ops_u8(i8 %26, i8 %one) #17
  %28 = extractvalue { i1, i8 } %27, 0
  %29 = extractvalue { i1, i8 } %27, 1
  %30 = zext i1 %28 to i8
  store i8 %30, ptr %_40, align 1
  %31 = getelementptr inbounds i8, ptr %_40, i64 1
  store i8 %29, ptr %31, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_42, ptr %_38) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_43, ptr %_40) #17
  %32 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %_42, i64 16, i1 false)
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %34 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #17
  %_35.0 = extractvalue { ptr, ptr } %34, 0
  %_35.1 = extractvalue { ptr, ptr } %34, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %35 = load i8, ptr %max, align 1
  %_5.0.i = add i8 %35, %one
  %_5.1.i = icmp ult i8 %_5.0.i, %35
  %36 = insertvalue { i8, i1 } poison, i8 %_5.0.i, 0
  %37 = insertvalue { i8, i1 } %36, i1 %_5.1.i, 1
  %38 = extractvalue { i8, i1 } %37, 0
  %39 = extractvalue { i8, i1 } %37, 1
  store i8 %38, ptr %_50, align 1
  %40 = getelementptr inbounds i8, ptr %_50, i64 1
  %41 = zext i1 %39 to i8
  store i8 %41, ptr %40, align 1
  %42 = load i8, ptr %min, align 1
  %_5.0.i52 = sub i8 %42, %one
  %_5.1.i53 = icmp ult i8 %42, %one
  %43 = insertvalue { i8, i1 } poison, i8 %_5.0.i52, 0
  %44 = insertvalue { i8, i1 } %43, i1 %_5.1.i53, 1
  %45 = extractvalue { i8, i1 } %44, 0
  %46 = extractvalue { i8, i1 } %44, 1
  store i8 %45, ptr %_52, align 1
  %47 = getelementptr inbounds i8, ptr %_52, i64 1
  %48 = zext i1 %46 to i8
  store i8 %48, ptr %47, align 1
; call <core::fmt::rt::Argument>::new_debug::<(u8, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugThbEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_54, ptr %_50) #17
; call <core::fmt::rt::Argument>::new_debug::<(u8, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugThbEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_55, ptr %_52) #17
  %49 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %49, ptr align 8 %_54, i64 16, i1 false)
  %50 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %50, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %51 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #17
  %_47.0 = extractvalue { ptr, ptr } %51, 0
  %_47.1 = extractvalue { ptr, ptr } %51, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %52 = load i8, ptr %max, align 1
  %_0.i34 = add i8 %52, %one
  store i8 %_0.i34, ptr %_62, align 1
  %53 = load i8, ptr %min, align 1
  %_0.i40 = sub i8 %53, %one
  store i8 %_0.i40, ptr %_64, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_66, ptr %_62) #17
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_67, ptr %_64) #17
  %54 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %54, ptr align 8 %_66, i64 16, i1 false)
  %55 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %55, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %56 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #17
  %_59.0 = extractvalue { ptr, ptr } %56, 0
  %_59.1 = extractvalue { ptr, ptr } %56, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %57 = load i8, ptr %max, align 1
  %_0.i48 = call i8 @llvm.uadd.sat.i8(i8 %57, i8 %three)
  store i8 %_0.i48, ptr %_74, align 1
  %58 = load i8, ptr %min, align 1
  %_0.i49 = call i8 @llvm.usub.sat.i8(i8 %58, i8 %three)
  store i8 %_0.i49, ptr %_76, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_78, ptr %_74) #17
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_79, ptr %_76) #17
  %59 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %59, ptr align 8 %_78, i64 16, i1 false)
  %60 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %60, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %61 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #17
  %_71.0 = extractvalue { ptr, ptr } %61, 0
  %_71.1 = extractvalue { ptr, ptr } %61, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %62 = load i8, ptr %max, align 1
  %_0.i36 = mul i8 %62, %three
  store i8 %_0.i36, ptr %_86, align 1
  %63 = load i8, ptr %max, align 1
  %64 = load i8, ptr %max, align 1
  %_0.i35 = mul i8 %63, %64
  store i8 %_0.i35, ptr %_88, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_90, ptr %_86) #17
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_91, ptr %_88) #17
  %65 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %65, ptr align 8 %_90, i64 16, i1 false)
  %66 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %66, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %67 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #17
  %_83.0 = extractvalue { ptr, ptr } %67, 0
  %_83.1 = extractvalue { ptr, ptr } %67, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %68 = load i8, ptr %max, align 1
; call <u8>::checked_mul
  %69 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCseJnXURkPMql_10int_ops_u8(i8 %68, i8 %three) #17
  %70 = extractvalue { i1, i8 } %69, 0
  %71 = extractvalue { i1, i8 } %69, 1
  %72 = zext i1 %70 to i8
  store i8 %72, ptr %_98, align 1
  %73 = getelementptr inbounds i8, ptr %_98, i64 1
  store i8 %71, ptr %73, align 1
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseJnXURkPMql_10int_ops_u8(i32 5) #17
; call <u8>::checked_pow
  %74 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_powCseJnXURkPMql_10int_ops_u8(i8 %three, i32 %_101) #17
  %75 = extractvalue { i1, i8 } %74, 0
  %76 = extractvalue { i1, i8 } %74, 1
  %77 = zext i1 %75 to i8
  store i8 %77, ptr %_100, align 1
  %78 = getelementptr inbounds i8, ptr %_100, i64 1
  store i8 %76, ptr %78, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_103, ptr %_98) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_104, ptr %_100) #17
  %79 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %79, ptr align 8 %_103, i64 16, i1 false)
  %80 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %80, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %81 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #17
  %_95.0 = extractvalue { ptr, ptr } %81, 0
  %_95.1 = extractvalue { ptr, ptr } %81, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %82 = load i8, ptr %max, align 1
  %83 = call i8 @llvm.ctpop.i8(i8 %82)
  %_0.i = zext i8 %83 to i32
  store i32 %_0.i, ptr %_111, align 4
  %84 = load i8, ptr %max, align 1
  %85 = call i8 @llvm.ctlz.i8(i8 %84, i1 false)
  %_0.i42 = zext i8 %85 to i32
  store i32 %_0.i42, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECseJnXURkPMql_10int_ops_u8(i32 3) #17
  %_119 = icmp ult i32 %_117, 8
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %86 = and i32 %_117, 7
  %87 = trunc i32 %86 to i8
  %_116 = shl i8 %one, %87
  %88 = call i8 @llvm.cttz.i8(i8 %_116, i1 false)
  %_0.i51 = zext i8 %88 to i32
  store i32 %_0.i51, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %89 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %89, align 8
  %90 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %90, align 8
  %_310 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_310) #17
  %91 = getelementptr inbounds i8, ptr %args10, i64 8
  %_311 = load ptr, ptr %91, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_311) #17
  %92 = getelementptr inbounds i8, ptr %args10, i64 16
  %_312 = load ptr, ptr %92, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_312) #17
  %93 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %93, ptr align 8 %_121, i64 16, i1 false)
  %94 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %94, ptr align 8 %_122, i64 16, i1 false)
  %95 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %95, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %96 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECseJnXURkPMql_10int_ops_u8(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #17
  %_108.0 = extractvalue { ptr, ptr } %96, 0
  %_108.1 = extractvalue { ptr, ptr } %96, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseJnXURkPMql_10int_ops_u8(i32 5) #17
  %97 = load i8, ptr %max, align 1
; call core::intrinsics::rotate_left::<u8>
  %_0.i30 = call i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefthECseJnXURkPMql_10int_ops_u8(i8 %97, i32 %_131) #21
  store i8 %_0.i30, ptr %_130, align 1
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseJnXURkPMql_10int_ops_u8(i32 7) #17
  %98 = load i8, ptr %min, align 1
; call core::intrinsics::rotate_right::<u8>
  %_0.i33 = call i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righthECseJnXURkPMql_10int_ops_u8(i8 %98, i32 %_134) #21
  store i8 %_0.i33, ptr %_133, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_136, ptr %_130) #17
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_137, ptr %_133) #17
  %99 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %99, ptr align 8 %_136, i64 16, i1 false)
  %100 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %100, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %101 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #17
  %_127.0 = extractvalue { ptr, ptr } %101, 0
  %_127.1 = extractvalue { ptr, ptr } %101, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %102 = load i8, ptr %max, align 1
  store i8 %102, ptr %_144, align 1
  %103 = load i8, ptr %max, align 1
  %_0.i32 = call i8 @llvm.bitreverse.i8(i8 %103)
  store i8 %_0.i32, ptr %_146, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_148, ptr %_144) #17
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_149, ptr %_146) #17
  %104 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %104, ptr align 8 %_148, i64 16, i1 false)
  %105 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %105, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %106 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #17
  %_141.0 = extractvalue { ptr, ptr } %106, 0
  %_141.1 = extractvalue { ptr, ptr } %106, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseJnXURkPMql_10int_ops_u8(i32 70) #17
  %107 = load i8, ptr %max, align 1
  %_3.i = and i32 %_157, 7
; call core::ub_checks::check_language_ub
  %_3.i43 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_3.i43, label %bb2.i, label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <u8>::unchecked_shl::precondition_check
  call void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl18precondition_checkCseJnXURkPMql_10int_ops_u8(i32 %_3.i, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit

_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %108 = trunc nuw i32 %_3.i to i8
  %_0.i44 = shl i8 %107, %108
  store i8 %_0.i44, ptr %_156, align 1
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseJnXURkPMql_10int_ops_u8(i32 66) #17
  %109 = load i8, ptr %min, align 1
  %_3.i38 = and i32 %_160, 7
; call core::ub_checks::check_language_ub
  %_3.i45 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_3.i45, label %bb2.i47, label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shr.exit

bb2.i47:                                          ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit
; call <u8>::unchecked_shr::precondition_check
  call void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shr18precondition_checkCseJnXURkPMql_10int_ops_u8(i32 %_3.i38, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shr.exit

_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shr.exit: ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit, %bb2.i47
  %110 = trunc nuw i32 %_3.i38 to i8
  %_0.i46 = lshr i8 %109, %110
  store i8 %_0.i46, ptr %_159, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_162, ptr %_156) #17
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_163, ptr %_159) #17
  %111 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %111, ptr align 8 %_162, i64 16, i1 false)
  %112 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %112, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %113 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #17
  %_153.0 = extractvalue { ptr, ptr } %113, 0
  %_153.1 = extractvalue { ptr, ptr } %113, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i8 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_a86ee8176aa67afec68ae8e7a0551d2c) #23
  unreachable

bb85:                                             ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shr.exit
  %114 = load i8, ptr %max, align 1
  %115 = udiv i8 %114, %three
  store i8 %115, ptr %_170, align 1
  %_174 = icmp eq i8 %three, 0
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cb742a493b8e02858af6e3e5d1677431) #23
  unreachable

bb86:                                             ; preds = %bb85
  %116 = load i8, ptr %max, align 1
  %117 = urem i8 %116, %three
  store i8 %117, ptr %_173, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_176, ptr %_170) #17
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_177, ptr %_173) #17
  %118 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %118, ptr align 8 %_176, i64 16, i1 false)
  %119 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %119, ptr align 8 %_177, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %120 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #17
  %_167.0 = extractvalue { ptr, ptr } %120, 0
  %_167.1 = extractvalue { ptr, ptr } %120, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<u8>
  %_185 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseJnXURkPMql_10int_ops_u8(i8 0) #17
  %121 = load i8, ptr %max, align 1
; call <u8>::checked_div
  %122 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_divCseJnXURkPMql_10int_ops_u8(i8 %121, i8 %_185) #17
  %123 = extractvalue { i1, i8 } %122, 0
  %124 = extractvalue { i1, i8 } %122, 1
  %125 = zext i1 %123 to i8
  store i8 %125, ptr %_184, align 1
  %126 = getelementptr inbounds i8, ptr %_184, i64 1
  store i8 %124, ptr %126, align 1
  %127 = load i8, ptr %max, align 1
; call <u8>::checked_rem
  %128 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_remCseJnXURkPMql_10int_ops_u8(i8 %127, i8 %three) #17
  %129 = extractvalue { i1, i8 } %128, 0
  %130 = extractvalue { i1, i8 } %128, 1
  %131 = zext i1 %129 to i8
  store i8 %131, ptr %_187, align 1
  %132 = getelementptr inbounds i8, ptr %_187, i64 1
  store i8 %130, ptr %132, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_189, ptr %_184) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionhEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_190, ptr %_187) #17
  %133 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %133, ptr align 8 %_189, i64 16, i1 false)
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_190, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %135 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #17
  %_181.0 = extractvalue { ptr, ptr } %135, 0
  %_181.1 = extractvalue { ptr, ptr } %135, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_181.0, ptr %_181.1)
; call core::hint::black_box::<u32>
  %_198 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseJnXURkPMql_10int_ops_u8(i32 4) #17
; call <u8>::pow
  %136 = call i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh3powCseJnXURkPMql_10int_ops_u8(i8 %three, i32 %_198) #17
  store i8 %136, ptr %_197, align 1
  %137 = load i8, ptr %max, align 1
  %138 = load i8, ptr %min, align 1
; call <u8>::abs_diff
  %139 = call i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh8abs_diffCseJnXURkPMql_10int_ops_u8(i8 %137, i8 %138) #17
  store i8 %139, ptr %_200, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_202, ptr %_197) #17
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_203, ptr %_200) #17
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_202, i64 16, i1 false)
  %141 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %141, ptr align 8 %_203, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %142 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #17
  %_194.0 = extractvalue { ptr, ptr } %142, 0
  %_194.1 = extractvalue { ptr, ptr } %142, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_194.0, ptr %_194.1)
; call core::hint::black_box::<u32>
  %_212 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseJnXURkPMql_10int_ops_u8(i32 7) #17
; call <u8>::from_str_radix
  %143 = call { i1, i8 } @_RNvMsx_NtCsl10jNU3mE6R_4core3numh14from_str_radixCseJnXURkPMql_10int_ops_u8(ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_212) #17
  %144 = extractvalue { i1, i8 } %143, 0
  %145 = extractvalue { i1, i8 } %143, 1
  %146 = zext i1 %144 to i8
  store i8 %146, ptr %_210, align 1
  %147 = getelementptr inbounds i8, ptr %_210, i64 1
  store i8 %145, ptr %147, align 1
; call <str>::parse::<u8>
  %148 = call { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parsehECseJnXURkPMql_10int_ops_u8(ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #17
  %149 = extractvalue { i1, i8 } %148, 0
  %150 = extractvalue { i1, i8 } %148, 1
  %151 = zext i1 %149 to i8
  store i8 %151, ptr %_216, align 1
  %152 = getelementptr inbounds i8, ptr %_216, i64 1
  store i8 %150, ptr %152, align 1
; call <core::result::Result<u8, core::num::error::ParseIntError>>::is_ok
  %153 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtNtB4_3num5error13ParseIntErrorE5is_okCseJnXURkPMql_10int_ops_u8(ptr %_216) #17
  %154 = zext i1 %153 to i8
  store i8 %154, ptr %_214, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<u8, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResulthNtNtNtB7_3num5error13ParseIntErrorEECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_219, ptr %_210) #17
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_220, ptr %_214) #17
  %155 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %155, ptr align 8 %_219, i64 16, i1 false)
  %156 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %156, ptr align 8 %_220, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %157 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #17
  %_207.0 = extractvalue { ptr, ptr } %157, 0
  %_207.1 = extractvalue { ptr, ptr } %157, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_207.0, ptr %_207.1)
  %158 = load i8, ptr %max, align 1
  %_229 = uitofp i8 %158 to double
  %_228 = call i8 @llvm.fptoui.sat.i8.f64(double %_229)
  %159 = load i8, ptr %max, align 1
  %160 = icmp eq i8 %_228, %159
  %161 = zext i1 %160 to i8
  store i8 %161, ptr %_227, align 1
  %162 = load i8, ptr %max, align 1
  %163 = uitofp i8 %162 to float
  store float %163, ptr %_231, align 4
  %164 = load i8, ptr %min, align 1
  %165 = uitofp i8 %164 to double
  store double %165, ptr %_233, align 8
  store ptr %_227, ptr %args19, align 8
  %166 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_231, ptr %166, align 8
  %167 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_233, ptr %167, align 8
  %_327 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_235, ptr %_327) #17
  %168 = getelementptr inbounds i8, ptr %args19, i64 8
  %_328 = load ptr, ptr %168, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_236, ptr align 4 %_328) #17
  %169 = getelementptr inbounds i8, ptr %args19, i64 16
  %_329 = load ptr, ptr %169, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECseJnXURkPMql_10int_ops_u8(ptr sret([16 x i8]) align 8 %_237, ptr align 8 %_329) #17
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_235, i64 16, i1 false)
  %171 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %171, ptr align 8 %_236, i64 16, i1 false)
  %172 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %172, ptr align 8 %_237, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %173 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECseJnXURkPMql_10int_ops_u8(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #17
  %_224.0 = extractvalue { ptr, ptr } %173, 0
  %_224.1 = extractvalue { ptr, ptr } %173, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_224.0, ptr %_224.1)
  %174 = load i8, ptr %max, align 1
  %_2.i = xor i8 %174, -1
  %175 = call i8 @llvm.ctlz.i8(i8 %_2.i, i1 false)
  %_0.i41 = zext i8 %175 to i32
  store i32 %_0.i41, ptr %_244, align 4
  %176 = load i8, ptr %min, align 1
  %177 = call i8 @llvm.cttz.i8(i8 %176, i1 false)
  %_0.i50 = zext i8 %177 to i32
  store i32 %_0.i50, ptr %_246, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_248, ptr align 4 %_244) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_249, ptr align 4 %_246) #17
  %178 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %178, ptr align 8 %_248, i64 16, i1 false)
  %179 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %179, ptr align 8 %_249, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %180 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #17
  %_241.0 = extractvalue { ptr, ptr } %180, 0
  %_241.1 = extractvalue { ptr, ptr } %180, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_241.0, ptr %_241.1)
  %181 = load i8, ptr %max, align 1
; call <u8>::isqrt
  %182 = call i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5isqrtCseJnXURkPMql_10int_ops_u8(i8 %181) #17
  store i8 %182, ptr %_256, align 1
  %183 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %three, i8 %three)
  %_260.0 = extractvalue { i8, i1 } %183, 0
  %_260.1 = extractvalue { i8, i1 } %183, 1
  br i1 %_260.1, label %panic27, label %bb125

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_5880d95b5bf4728dcf6885494c76eb52) #23
  unreachable

bb125:                                            ; preds = %bb86
; call <u8>::ilog2
  %184 = call i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2CseJnXURkPMql_10int_ops_u8(i8 %_260.0, ptr align 8 @alloc_25be3c2986333bc1d9dc7dc3b19c705f) #17
  store i32 %184, ptr %_258, align 4
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_262, ptr %_256) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_263, ptr align 4 %_258) #17
  %185 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %185, ptr align 8 %_262, i64 16, i1 false)
  %186 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %186, ptr align 8 %_263, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %187 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #17
  %_253.0 = extractvalue { ptr, ptr } %187, 0
  %_253.1 = extractvalue { ptr, ptr } %187, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_253.0, ptr %_253.1)
; call <u8 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringhNtB5_8ToString9to_stringCseJnXURkPMql_10int_ops_u8(ptr sret([24 x i8]) align 8 %_273, ptr %max) #17
; invoke <alloc::string::String>::len
  %_271 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCseJnXURkPMql_10int_ops_u8(ptr align 8 %_273)
          to label %bb132 unwind label %cleanup

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_2dbd61561d1dc78121cd8e5ee98f8154) #23
  unreachable

bb145:                                            ; preds = %bb144, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_273) #24
          to label %bb146 unwind label %terminate

cleanup:                                          ; preds = %bb141, %bb134, %bb133, %bb132, %bb125
  %188 = landingpad { ptr, i32 }
          cleanup
  %189 = extractvalue { ptr, i32 } %188, 0
  %190 = extractvalue { ptr, i32 } %188, 1
  store ptr %189, ptr %0, align 8
  %191 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %190, ptr %191, align 8
  br label %bb145

bb132:                                            ; preds = %bb125
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_283, ptr %min)
          to label %bb133 unwind label %cleanup

bb133:                                            ; preds = %bb132
  %192 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %192, ptr align 8 %_283, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %193 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb134 unwind label %cleanup

bb134:                                            ; preds = %bb133
  %_279.0 = extractvalue { ptr, ptr } %193, 0
  %_279.1 = extractvalue { ptr, ptr } %193, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCseJnXURkPMql_10int_ops_u8(ptr sret([24 x i8]) align 8 %_278, ptr %_279.0, ptr %_279.1)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_277, ptr align 8 %_278, i64 24, i1 false)
  br label %bb136

bb136:                                            ; preds = %bb135
; invoke <alloc::string::String>::len
  %_275 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCseJnXURkPMql_10int_ops_u8(ptr align 8 %_277)
          to label %bb137 unwind label %cleanup28

bb144:                                            ; preds = %cleanup28
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_277) #24
          to label %bb145 unwind label %terminate

cleanup28:                                        ; preds = %bb140, %bb139, %bb138, %panic29, %bb136
  %194 = landingpad { ptr, i32 }
          cleanup
  %195 = extractvalue { ptr, i32 } %194, 0
  %196 = extractvalue { ptr, i32 } %194, 1
  store ptr %195, ptr %0, align 8
  %197 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %196, ptr %197, align 8
  br label %bb144

bb137:                                            ; preds = %bb136
  %_286.0 = add i64 %_271, %_275
  %_286.1 = icmp ult i64 %_286.0, %_271
  br i1 %_286.1, label %panic29, label %bb138

bb138:                                            ; preds = %bb137
  store i64 %_286.0, ptr %_270, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_288, ptr align 8 %_270)
          to label %bb139 unwind label %cleanup28

panic29:                                          ; preds = %bb137
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_3f8a030187d908ae175dd04a608ffd87) #19
          to label %unreachable unwind label %cleanup28

unreachable:                                      ; preds = %panic29
  unreachable

bb139:                                            ; preds = %bb138
  %198 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %198, ptr align 8 %_288, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %199 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb140 unwind label %cleanup28

bb140:                                            ; preds = %bb139
  %_267.0 = extractvalue { ptr, ptr } %199, 0
  %_267.1 = extractvalue { ptr, ptr } %199, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_267.0, ptr %_267.1)
          to label %bb141 unwind label %cleanup28

bb141:                                            ; preds = %bb140
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_277)
          to label %bb142 unwind label %cleanup

bb142:                                            ; preds = %bb141
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_273)
  ret void

terminate:                                        ; preds = %bb145, %bb144
  %200 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable

bb146:                                            ; preds = %bb145
  %201 = load ptr, ptr %0, align 8
  %202 = getelementptr inbounds i8, ptr %0, i64 8
  %203 = load i32, ptr %202, align 8
  %204 = insertvalue { ptr, i32 } poison, ptr %201, 0
  %205 = insertvalue { ptr, i32 } %204, i32 %203, 1
  resume { ptr, i32 } %205
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCseJnXURkPMql_10int_ops_u8(ptr align 8 %self) unnamed_addr #0 !guid !79 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #17
  ret i64 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCseJnXURkPMql_10int_ops_u8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !80 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::result::Result<u8, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtNtB4_3num5error13ParseIntErrorE5is_okCseJnXURkPMql_10int_ops_u8(ptr %self) unnamed_addr #0 !guid !81 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_2 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %5 = load i8, ptr %_0, align 1
  %6 = trunc nuw i8 %5 to i1
  ret i1 %6

bb4:                                              ; No predecessors!
  unreachable
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCseJnXURkPMql_10int_ops_u8(i32 %self, i32 %radix) unnamed_addr #0 !guid !82 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseJnXURkPMql_10int_ops_u8(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #17
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #23
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCseJnXURkPMql_10int_ops_u8(i32 %self) unnamed_addr #0 !guid !83 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCseJnXURkPMql_10int_ops_u8(i32 %self) #17
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCseJnXURkPMql_10int_ops_u8(i32 %self) unnamed_addr #0 !guid !84 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::ptr::non_null::NonNull<core::option::Option<u8>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionhEE8from_refCseJnXURkPMql_10int_ops_u8(ptr %r) unnamed_addr #0 !guid !85 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<u8, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResulthNtNtNtB9_3num5error13ParseIntErrorEE8from_refCseJnXURkPMql_10int_ops_u8(ptr %r) unnamed_addr #0 !guid !86 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<(u8, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullThbEE8from_refCseJnXURkPMql_10int_ops_u8(ptr %r) unnamed_addr #0 !guid !87 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCseJnXURkPMql_10int_ops_u8(ptr %r) unnamed_addr #0 !guid !88 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCseJnXURkPMql_10int_ops_u8(ptr align 8 %r) unnamed_addr #0 !guid !89 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCseJnXURkPMql_10int_ops_u8(ptr align 4 %r) unnamed_addr #0 !guid !90 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCseJnXURkPMql_10int_ops_u8(ptr align 8 %self) unnamed_addr #0 !guid !91 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #17
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCseJnXURkPMql_10int_ops_u8(ptr %_7.0, i64 %_7.1) #17
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseJnXURkPMql_10int_ops_u8(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !92 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCseJnXURkPMql_10int_ops_u8(ptr %s.0, i64 %s.1) #17
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u8>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh10strict_powCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !93 {
start:
  %_3 = alloca [2 x i8], align 1
; call <u8>::checked_pow
  %1 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_powCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %exp) #17
  %2 = extractvalue { i1, i8 } %1, 0
  %3 = extractvalue { i1, i8 } %1, 1
  %4 = zext i1 %2 to i8
  store i8 %4, ptr %_3, align 1
  %5 = getelementptr inbounds i8, ptr %_3, i64 1
  store i8 %3, ptr %5, align 1
  %6 = load i8, ptr %_3, align 1
  %7 = trunc nuw i8 %6 to i1
  %8 = getelementptr inbounds i8, ptr %_3, i64 1
  %9 = load i8, ptr %8, align 1
  %_4 = zext i1 %7 to i64
  %10 = trunc nuw i64 %_4 to i1
  br i1 %10, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %11 = getelementptr inbounds i8, ptr %_3, i64 1
  %a = load i8, ptr %11, align 1
  ret i8 %a

bb4:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <u8>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_addCseJnXURkPMql_10int_ops_u8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !94 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %_5.0 = add i8 %self, %rhs
  %_5.1 = icmp ult i8 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i8 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_6, ptr %2, align 1
  store i8 1, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  %5 = getelementptr inbounds i8, ptr %_0, i64 1
  %6 = load i8, ptr %5, align 1
  %7 = insertvalue { i1, i8 } poison, i1 %4, 0
  %8 = insertvalue { i1, i8 } %7, i8 %6, 1
  ret { i1, i8 } %8
}

; <u8>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_divCseJnXURkPMql_10int_ops_u8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !95 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %_4 = icmp eq i8 %rhs, 0
  br i1 %_4, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_5 = udiv i8 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5, ptr %2, align 1
  store i8 1, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  %5 = getelementptr inbounds i8, ptr %_0, i64 1
  %6 = load i8, ptr %5, align 1
  %7 = insertvalue { i1, i8 } poison, i1 %4, 0
  %8 = insertvalue { i1, i8 } %7, i8 %6, 1
  ret { i1, i8 } %8
}

; <u8>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCseJnXURkPMql_10int_ops_u8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !96 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <u8>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_powCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %0) unnamed_addr #0 !guid !97 {
start:
  %_49 = alloca [2 x i8], align 1
  %_40 = alloca [2 x i8], align 1
  %_30 = alloca [2 x i8], align 1
  %_24 = alloca [2 x i8], align 1
  %_11 = alloca [8 x i8], align 4
  %acc = alloca [1 x i8], align 1
  %base = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i8 %self, ptr %base, align 1
  store i8 1, ptr %acc, align 1
  %_6 = load i8, ptr %base, align 1
  %_5 = call i1 @llvm.is.constant.i8(i8 %_6)
  br i1 %_5, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_16 = load i32, ptr %exp, align 4
  %_15 = icmp eq i32 %_16, 0
  br i1 %_15, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_8 = load i8, ptr %base, align 1
  %1 = call i8 @llvm.ctpop.i8(i8 %_8)
  %_0.i.i = zext i8 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_10 = load i8, ptr %base, align 1
; call <u8>::ilog2
  %k = call i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2CseJnXURkPMql_10int_ops_u8(i8 %_10, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #17
  %_12 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCseJnXURkPMql_10int_ops_u8(i32 %k, i32 %_12) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_11, align 4
  %5 = getelementptr inbounds i8, ptr %_11, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_11, align 4
  %7 = getelementptr inbounds i8, ptr %_11, i64 4
  %8 = load i32, ptr %7, align 4
  %_13 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_13 to i1
  br i1 %9, label %bb9, label %bb8

bb12:                                             ; preds = %bb10
  %_18 = load i32, ptr %exp, align 4
  %_17 = call i1 @llvm.is.constant.i32(i32 %_18)
  br i1 %_17, label %bb14, label %bb26

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %10, align 1
  store i8 1, ptr %_0, align 1
  br label %bb37

bb26:                                             ; preds = %bb36, %bb12
  %_39 = load i32, ptr %exp, align 4
  %_38 = and i32 %_39, 1
  %_37 = icmp eq i32 %_38, 1
  br i1 %_37, label %bb27, label %bb32

bb14:                                             ; preds = %bb24, %bb12
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp ugt i32 %_20, 1
  br i1 %_19, label %bb15, label %bb25

bb32:                                             ; preds = %bb30, %bb26
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_50 = load i8, ptr %base, align 1
  %_51 = load i8, ptr %base, align 1
; call <u8>::checked_mul
  %13 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCseJnXURkPMql_10int_ops_u8(i8 %_50, i8 %_51) #17
  %14 = extractvalue { i1, i8 } %13, 0
  %15 = extractvalue { i1, i8 } %13, 1
  %16 = zext i1 %14 to i8
  store i8 %16, ptr %_49, align 1
  %17 = getelementptr inbounds i8, ptr %_49, i64 1
  store i8 %15, ptr %17, align 1
  %18 = load i8, ptr %_49, align 1
  %19 = trunc nuw i8 %18 to i1
  %20 = getelementptr inbounds i8, ptr %_49, i64 1
  %21 = load i8, ptr %20, align 1
  %_52 = zext i1 %19 to i64
  %22 = trunc nuw i64 %_52 to i1
  br i1 %22, label %bb36, label %bb35

bb27:                                             ; preds = %bb26
  %_41 = load i8, ptr %acc, align 1
  %_42 = load i8, ptr %base, align 1
; call <u8>::checked_mul
  %23 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCseJnXURkPMql_10int_ops_u8(i8 %_41, i8 %_42) #17
  %24 = extractvalue { i1, i8 } %23, 0
  %25 = extractvalue { i1, i8 } %23, 1
  %26 = zext i1 %24 to i8
  store i8 %26, ptr %_40, align 1
  %27 = getelementptr inbounds i8, ptr %_40, i64 1
  store i8 %25, ptr %27, align 1
  %28 = load i8, ptr %_40, align 1
  %29 = trunc nuw i8 %28 to i1
  %30 = getelementptr inbounds i8, ptr %_40, i64 1
  %31 = load i8, ptr %30, align 1
  %_43 = zext i1 %29 to i64
  %32 = trunc nuw i64 %_43 to i1
  br i1 %32, label %bb30, label %bb29

bb30:                                             ; preds = %bb27
  %33 = getelementptr inbounds i8, ptr %_40, i64 1
  %x = load i8, ptr %33, align 1
  store i8 %x, ptr %acc, align 1
  %_46 = load i32, ptr %exp, align 4
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb31, label %bb32

bb29:                                             ; preds = %bb27
  store i8 0, ptr %_0, align 1
  br label %bb37

bb37:                                             ; preds = %bb9, %bb8, %bb11, %bb23, %bb18, %bb25, %bb31, %bb35, %bb29
  %34 = load i8, ptr %_0, align 1
  %35 = trunc nuw i8 %34 to i1
  %36 = getelementptr inbounds i8, ptr %_0, i64 1
  %37 = load i8, ptr %36, align 1
  %38 = insertvalue { i1, i8 } poison, i1 %35, 0
  %39 = insertvalue { i1, i8 } %38, i8 %37, 1
  ret { i1, i8 } %39

bb31:                                             ; preds = %bb30
  %_47 = load i8, ptr %acc, align 1
  %40 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_47, ptr %40, align 1
  store i8 1, ptr %_0, align 1
  br label %bb37

bb36:                                             ; preds = %bb32
  %41 = getelementptr inbounds i8, ptr %_49, i64 1
  %x1 = load i8, ptr %41, align 1
  store i8 %x1, ptr %base, align 1
  br label %bb26

bb35:                                             ; preds = %bb32
  store i8 0, ptr %_0, align 1
  br label %bb37

bb25:                                             ; preds = %bb14
  %_35 = load i8, ptr %acc, align 1
  %_36 = load i8, ptr %base, align 1
; call <u8>::checked_mul
  %42 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCseJnXURkPMql_10int_ops_u8(i8 %_35, i8 %_36) #17
  %43 = extractvalue { i1, i8 } %42, 0
  %44 = extractvalue { i1, i8 } %42, 1
  %45 = zext i1 %43 to i8
  store i8 %45, ptr %_0, align 1
  %46 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %44, ptr %46, align 1
  br label %bb37

bb15:                                             ; preds = %bb14
  %_23 = load i32, ptr %exp, align 4
  %_22 = and i32 %_23, 1
  %_21 = icmp eq i32 %_22, 1
  br i1 %_21, label %bb16, label %bb20

bb20:                                             ; preds = %bb19, %bb15
  %47 = load i32, ptr %exp, align 4
  %48 = udiv i32 %47, 2
  store i32 %48, ptr %exp, align 4
  %_31 = load i8, ptr %base, align 1
  %_32 = load i8, ptr %base, align 1
; call <u8>::checked_mul
  %49 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCseJnXURkPMql_10int_ops_u8(i8 %_31, i8 %_32) #17
  %50 = extractvalue { i1, i8 } %49, 0
  %51 = extractvalue { i1, i8 } %49, 1
  %52 = zext i1 %50 to i8
  store i8 %52, ptr %_30, align 1
  %53 = getelementptr inbounds i8, ptr %_30, i64 1
  store i8 %51, ptr %53, align 1
  %54 = load i8, ptr %_30, align 1
  %55 = trunc nuw i8 %54 to i1
  %56 = getelementptr inbounds i8, ptr %_30, i64 1
  %57 = load i8, ptr %56, align 1
  %_33 = zext i1 %55 to i64
  %58 = trunc nuw i64 %_33 to i1
  br i1 %58, label %bb24, label %bb23

bb16:                                             ; preds = %bb15
  %_25 = load i8, ptr %acc, align 1
  %_26 = load i8, ptr %base, align 1
; call <u8>::checked_mul
  %59 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCseJnXURkPMql_10int_ops_u8(i8 %_25, i8 %_26) #17
  %60 = extractvalue { i1, i8 } %59, 0
  %61 = extractvalue { i1, i8 } %59, 1
  %62 = zext i1 %60 to i8
  store i8 %62, ptr %_24, align 1
  %63 = getelementptr inbounds i8, ptr %_24, i64 1
  store i8 %61, ptr %63, align 1
  %64 = load i8, ptr %_24, align 1
  %65 = trunc nuw i8 %64 to i1
  %66 = getelementptr inbounds i8, ptr %_24, i64 1
  %67 = load i8, ptr %66, align 1
  %_27 = zext i1 %65 to i64
  %68 = trunc nuw i64 %_27 to i1
  br i1 %68, label %bb19, label %bb18

bb19:                                             ; preds = %bb16
  %69 = getelementptr inbounds i8, ptr %_24, i64 1
  %x2 = load i8, ptr %69, align 1
  store i8 %x2, ptr %acc, align 1
  br label %bb20

bb18:                                             ; preds = %bb16
  store i8 0, ptr %_0, align 1
  br label %bb37

bb24:                                             ; preds = %bb20
  %70 = getelementptr inbounds i8, ptr %_30, i64 1
  %x3 = load i8, ptr %70, align 1
  store i8 %x3, ptr %base, align 1
  br label %bb14

bb23:                                             ; preds = %bb20
  store i8 0, ptr %_0, align 1
  br label %bb37

bb9:                                              ; preds = %bb4
  %71 = getelementptr inbounds i8, ptr %_11, i64 4
  %shift = load i32, ptr %71, align 4
; call <u8>::checked_shl
  %72 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_shlCseJnXURkPMql_10int_ops_u8(i8 1, i32 %shift) #17
  %73 = extractvalue { i1, i8 } %72, 0
  %74 = extractvalue { i1, i8 } %72, 1
  %75 = zext i1 %73 to i8
  store i8 %75, ptr %_0, align 1
  %76 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %74, ptr %76, align 1
  br label %bb37

bb8:                                              ; preds = %bb4
  store i8 0, ptr %_0, align 1
  br label %bb37

bb7:                                              ; No predecessors!
  unreachable
}

; <u8>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_remCseJnXURkPMql_10int_ops_u8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !98 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %_4 = icmp eq i8 %rhs, 0
  br i1 %_4, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_5 = urem i8 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5, ptr %2, align 1
  store i8 1, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  %5 = getelementptr inbounds i8, ptr %_0, i64 1
  %6 = load i8, ptr %5, align 1
  %7 = insertvalue { i1, i8 } poison, i1 %4, 0
  %8 = insertvalue { i1, i8 } %7, i8 %6, 1
  ret { i1, i8 } %8
}

; <u8>::checked_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_shlCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %rhs) unnamed_addr #0 !guid !99 {
start:
  %_0 = alloca [2 x i8], align 1
  %_3 = icmp ult i32 %rhs, 8
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u8>::unchecked_shl::precondition_check
  call void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl18precondition_checkCseJnXURkPMql_10int_ops_u8(i32 %rhs, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit

_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = trunc nuw i32 %rhs to i8
  %_0.i = shl i8 %self, %0
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_0.i, ptr %1, align 1
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit, %bb3
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  %5 = load i8, ptr %4, align 1
  %6 = insertvalue { i1, i8 } poison, i1 %3, 0
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1
  ret { i1, i8 } %7
}

; <u8>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_subCseJnXURkPMql_10int_ops_u8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !100 {
start:
  %_0 = alloca [2 x i8], align 1
  %_3 = icmp ult i8 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i8 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_4, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i8, ptr %_0, align 1
  %2 = trunc nuw i8 %1 to i1
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  %4 = load i8, ptr %3, align 1
  %5 = insertvalue { i1, i8 } poison, i1 %2, 0
  %6 = insertvalue { i1, i8 } %5, i8 %4, 1
  ret { i1, i8 } %6
}

; <u8>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh12wrapping_powCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %exp) unnamed_addr #0 !guid !101 {
start:
; call <u8>::overflowing_pow
  %0 = call { i8, i1 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh15overflowing_powCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %exp) #17
  %_3.0 = extractvalue { i8, i1 } %0, 0
  %_3.1 = extractvalue { i8, i1 } %0, 1
  ret i8 %_3.0
}

; <u8>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh13checked_ilog2CseJnXURkPMql_10int_ops_u8(i8 %self) unnamed_addr #0 !guid !102 {
start:
  %_2 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u8>>::new
  %0 = call i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3newB9_(i8 %self) #17
  store i8 %0, ptr %_2, align 1
  %1 = load i8, ptr %_2, align 1
  %2 = icmp eq i8 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i8, ptr %_2, align 1
; call <core::num::nonzero::NonZero<u8>>::ilog2
  %_5 = call i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE5ilog2CseJnXURkPMql_10int_ops_u8(i8 %x) #17
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u8>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unbounded_shlCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %rhs) unnamed_addr #0 !guid !103 {
start:
  %_0 = alloca [1 x i8], align 1
  %_3 = icmp ult i32 %rhs, 8
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u8>::unchecked_shl::precondition_check
  call void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl18precondition_checkCseJnXURkPMql_10int_ops_u8(i32 %rhs, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit

_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = trunc nuw i32 %rhs to i8
  %_0.i = shl i8 %self, %0
  store i8 %_0.i, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl.exit, %bb2
  %1 = load i8, ptr %_0, align 1
  ret i8 %1
}

; <u8>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i8, i1 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh15overflowing_powCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %0) unnamed_addr #0 !guid !104 {
start:
  %_14 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [1 x i8], align 1
  %base = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i8 %self, ptr %base, align 1
  store i8 1, ptr %acc, align 1
  store i8 0, ptr %overflow, align 1
  %_8 = load i8, ptr %base, align 1
  %_7 = call i1 @llvm.is.constant.i8(i8 %_8)
  br i1 %_7, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp eq i32 %_20, 0
  br i1 %_19, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_10 = load i8, ptr %base, align 1
  %1 = call i8 @llvm.ctpop.i8(i8 %_10)
  %_0.i.i = zext i8 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_12 = load i8, ptr %base, align 1
; call <u8>::ilog2
  %k = call i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2CseJnXURkPMql_10int_ops_u8(i8 %_12, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #17
  %_15 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCseJnXURkPMql_10int_ops_u8(i32 %k, i32 %_15) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_14, align 4
  %5 = getelementptr inbounds i8, ptr %_14, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_14, align 4
  %7 = getelementptr inbounds i8, ptr %_14, i64 4
  %8 = load i32, ptr %7, align 4
  %_16 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_16 to i1
  br i1 %9, label %bb7, label %bb8

bb12:                                             ; preds = %bb10
  %_22 = load i32, ptr %exp, align 4
  %_21 = call i1 @llvm.is.constant.i32(i32 %_22)
  br i1 %_21, label %bb14, label %bb23

bb11:                                             ; preds = %bb10
  store i16 1, ptr %_0, align 1
  br label %bb30

bb23:                                             ; preds = %bb27, %bb12
  %_51 = load i32, ptr %exp, align 4
  %_50 = and i32 %_51, 1
  %_49 = icmp eq i32 %_50, 1
  br i1 %_49, label %bb24, label %bb27

bb14:                                             ; preds = %bb18, %bb12
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp ugt i32 %_24, 1
  br i1 %_23, label %bb15, label %bb21

bb27:                                             ; preds = %bb24, %bb23
  %10 = load i32, ptr %exp, align 4
  %11 = udiv i32 %10, 2
  store i32 %11, ptr %exp, align 4
  %_66 = load i8, ptr %base, align 1
  %_67 = load i8, ptr %base, align 1
  %12 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %_66, i8 %_67)
  %_5.0.i5 = extractvalue { i8, i1 } %12, 0
  %_5.1.i6 = extractvalue { i8, i1 } %12, 1
  %_65.0 = extractvalue { i8, i1 } %12, 0
  %_65.1 = extractvalue { i8, i1 } %12, 1
  store i8 %_65.0, ptr %base, align 1
  %13 = zext i1 %_65.1 to i8
  store i8 %13, ptr %tmp_overflow, align 1
  %14 = load i8, ptr %tmp_overflow, align 1
  %_68 = trunc nuw i8 %14 to i1
  %15 = load i8, ptr %overflow, align 1
  %16 = trunc nuw i8 %15 to i1
  %17 = or i1 %16, %_68
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %overflow, align 1
  br label %bb23

bb24:                                             ; preds = %bb23
  %_55 = load i8, ptr %acc, align 1
  %_56 = load i8, ptr %base, align 1
  %19 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %_55, i8 %_56)
  %_5.0.i7 = extractvalue { i8, i1 } %19, 0
  %_5.1.i8 = extractvalue { i8, i1 } %19, 1
  %_54.0 = extractvalue { i8, i1 } %19, 0
  %_54.1 = extractvalue { i8, i1 } %19, 1
  store i8 %_54.0, ptr %acc, align 1
  %20 = zext i1 %_54.1 to i8
  store i8 %20, ptr %tmp_overflow, align 1
  %21 = load i8, ptr %tmp_overflow, align 1
  %_57 = trunc nuw i8 %21 to i1
  %22 = load i8, ptr %overflow, align 1
  %23 = trunc nuw i8 %22 to i1
  %24 = or i1 %23, %_57
  %25 = zext i1 %24 to i8
  store i8 %25, ptr %overflow, align 1
  %_59 = load i32, ptr %exp, align 4
  %_58 = icmp eq i32 %_59, 1
  br i1 %_58, label %bb26, label %bb27

bb26:                                             ; preds = %bb24
  %_60 = load i8, ptr %acc, align 1
  %26 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %26 to i1
  store i8 %_60, ptr %_0, align 1
  %27 = getelementptr inbounds i8, ptr %_0, i64 1
  %28 = zext i1 %_61 to i8
  store i8 %28, ptr %27, align 1
  br label %bb30

bb30:                                             ; preds = %bb8, %bb7, %bb11, %bb21, %bb26
  %29 = load i8, ptr %_0, align 1
  %30 = getelementptr inbounds i8, ptr %_0, i64 1
  %31 = load i8, ptr %30, align 1
  %32 = trunc nuw i8 %31 to i1
  %33 = insertvalue { i8, i1 } poison, i8 %29, 0
  %34 = insertvalue { i8, i1 } %33, i1 %32, 1
  ret { i8, i1 } %34

bb21:                                             ; preds = %bb14
  %_44 = load i8, ptr %acc, align 1
  %_45 = load i8, ptr %base, align 1
  %35 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %_44, i8 %_45)
  %_5.0.i3 = extractvalue { i8, i1 } %35, 0
  %_5.1.i4 = extractvalue { i8, i1 } %35, 1
  %_43.0 = extractvalue { i8, i1 } %35, 0
  %_43.1 = extractvalue { i8, i1 } %35, 1
  store i8 %_43.0, ptr %acc, align 1
  %36 = zext i1 %_43.1 to i8
  store i8 %36, ptr %tmp_overflow, align 1
  %37 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %37 to i1
  %38 = load i8, ptr %overflow, align 1
  %39 = trunc nuw i8 %38 to i1
  %40 = or i1 %39, %_46
  %41 = zext i1 %40 to i8
  store i8 %41, ptr %overflow, align 1
  %_47 = load i8, ptr %acc, align 1
  %42 = load i8, ptr %overflow, align 1
  %_48 = trunc nuw i8 %42 to i1
  store i8 %_47, ptr %_0, align 1
  %43 = getelementptr inbounds i8, ptr %_0, i64 1
  %44 = zext i1 %_48 to i8
  store i8 %44, ptr %43, align 1
  br label %bb30

bb15:                                             ; preds = %bb14
  %_27 = load i32, ptr %exp, align 4
  %_26 = and i32 %_27, 1
  %_25 = icmp eq i32 %_26, 1
  br i1 %_25, label %bb16, label %bb18

bb18:                                             ; preds = %bb16, %bb15
  %45 = load i32, ptr %exp, align 4
  %46 = udiv i32 %45, 2
  store i32 %46, ptr %exp, align 4
  %_38 = load i8, ptr %base, align 1
  %_39 = load i8, ptr %base, align 1
  %47 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %_38, i8 %_39)
  %_5.0.i = extractvalue { i8, i1 } %47, 0
  %_5.1.i = extractvalue { i8, i1 } %47, 1
  %_37.0 = extractvalue { i8, i1 } %47, 0
  %_37.1 = extractvalue { i8, i1 } %47, 1
  store i8 %_37.0, ptr %base, align 1
  %48 = zext i1 %_37.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_40 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_40
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  br label %bb14

bb16:                                             ; preds = %bb15
  %_31 = load i8, ptr %acc, align 1
  %_32 = load i8, ptr %base, align 1
  %54 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %_31, i8 %_32)
  %_5.0.i1 = extractvalue { i8, i1 } %54, 0
  %_5.1.i2 = extractvalue { i8, i1 } %54, 1
  %_30.0 = extractvalue { i8, i1 } %54, 0
  %_30.1 = extractvalue { i8, i1 } %54, 1
  store i8 %_30.0, ptr %acc, align 1
  %55 = zext i1 %_30.1 to i8
  store i8 %55, ptr %tmp_overflow, align 1
  %56 = load i8, ptr %tmp_overflow, align 1
  %_33 = trunc nuw i8 %56 to i1
  %57 = load i8, ptr %overflow, align 1
  %58 = trunc nuw i8 %57 to i1
  %59 = or i1 %58, %_33
  %60 = zext i1 %59 to i8
  store i8 %60, ptr %overflow, align 1
  br label %bb18

bb7:                                              ; preds = %bb4
  %61 = getelementptr inbounds i8, ptr %_14, i64 4
  %shift = load i32, ptr %61, align 4
; call <u8>::unbounded_shl
  %_17 = call i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unbounded_shlCseJnXURkPMql_10int_ops_u8(i8 1, i32 %shift) #17
  %_18 = icmp uge i32 %shift, 8
  store i8 %_17, ptr %_0, align 1
  %62 = getelementptr inbounds i8, ptr %_0, i64 1
  %63 = zext i1 %_18 to i8
  store i8 %63, ptr %62, align 1
  br label %bb30

bb8:                                              ; preds = %bb4
  store i16 256, ptr %_0, align 1
  br label %bb30

bb31:                                             ; No predecessors!
  unreachable
}

; <u8>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh3powCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %exp) unnamed_addr #0 !guid !105 {
start:
  %_0 = alloca [1 x i8], align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <u8>::strict_pow
  %0 = call i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh10strict_powCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %exp, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #17
  store i8 %0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; No predecessors!
; call <u8>::wrapping_pow
  %1 = call i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh12wrapping_powCseJnXURkPMql_10int_ops_u8(i8 %self, i32 %exp) #17
  store i8 %1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_0, align 1
  ret i8 %2
}

; <u8>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2CseJnXURkPMql_10int_ops_u8(i8 %self, ptr align 8 %0) unnamed_addr #0 !guid !106 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u8>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh13checked_ilog2CseJnXURkPMql_10int_ops_u8(i8 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u8>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5isqrtCseJnXURkPMql_10int_ops_u8(i8 %self) unnamed_addr #0 !guid !107 {
start:
; call core::num::imp::int_sqrt::u8
  %result = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CseJnXURkPMql_10int_ops_u8(i8 %self) #17
  %_3 = icmp ule i8 %result, 15
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCseJnXURkPMql_10int_ops_u8(i1 zeroext %_3, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i8 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u8>::unchecked_mul::precondition_check
  call void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul18precondition_checkCseJnXURkPMql_10int_ops_u8(i8 %result, i8 %result, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit

_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i8 %result, %result
  %_8 = icmp ule i8 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCseJnXURkPMql_10int_ops_u8(i1 zeroext %_8, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i8 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCseJnXURkPMql_10int_ops_u8(i1 zeroext %_11, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i8 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i8 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCseJnXURkPMql_10int_ops_u8(i1 zeroext %_6, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <u8>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh8abs_diffCseJnXURkPMql_10int_ops_u8(i8 %self, i8 %other) unnamed_addr #0 !guid !108 {
start:
  %_0 = alloca [1 x i8], align 1
  %_3 = icmp eq i64 1, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i8 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = zext i8 %self to i32
  %_8 = zext i8 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCseJnXURkPMql_10int_ops_u8(i32 %_0.i) #17
  %0 = trunc i32 %_5 to i8
  store i8 %0, ptr %_0, align 1
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i8 %self, %other
  store i8 %1, ptr %_0, align 1
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i8 %other, %self
  store i8 %2, ptr %_0, align 1
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i8, ptr %_0, align 1
  ret i8 %3
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCseJnXURkPMql_10int_ops_u8(i32 %self, i32 %rhs) unnamed_addr #0 !guid !109 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CseJnXURkPMql_10int_ops_u8(ptr %self) unnamed_addr #0 !guid !110 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u8>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE13leading_zerosCseJnXURkPMql_10int_ops_u8(i8 %self) unnamed_addr #0 !guid !111 {
start:
; call <core::num::nonzero::NonZero<u8>>::get
  %_2 = call i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3getB9_(i8 %self) #17
  %0 = call i8 @llvm.ctlz.i8(i8 %_2, i1 true)
  %_0 = zext i8 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u8>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE5ilog2CseJnXURkPMql_10int_ops_u8(i8 %self) unnamed_addr #0 !guid !112 {
start:
; call <core::num::nonzero::NonZero<u8>>::leading_zeros
  %_3 = call i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE13leading_zerosCseJnXURkPMql_10int_ops_u8(i8 %self) #17
  %_0 = sub i32 7, %_3
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CseJnXURkPMql_10int_ops_u8(i8 %0) unnamed_addr #0 !guid !113 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CseJnXURkPMql_10int_ops_u8(ptr %self) #17
  ret i32 %_0
}

; <u8>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsx_NtCsl10jNU3mE6R_4core3numh14from_str_radixCseJnXURkPMql_10int_ops_u8(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !114 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <u8>::from_ascii_bytes_radix_impl
  %2 = call { i1, i8 } @_RNvMsx_NtCsl10jNU3mE6R_4core3numh27from_ascii_bytes_radix_implCseJnXURkPMql_10int_ops_u8(ptr %_3.0, i64 %_3.1, i32 %radix) #17
  %_0.0 = extractvalue { i1, i8 } %2, 0
  %_0.1 = extractvalue { i1, i8 } %2, 1
  %3 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %4 = insertvalue { i1, i8 } %3, i8 %_0.1, 1
  ret { i1, i8 } %4
}

; <u8>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsx_NtCsl10jNU3mE6R_4core3numh27from_ascii_bytes_radix_implCseJnXURkPMql_10int_ops_u8(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !115 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [2 x i8], align 1
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [2 x i8], align 1
  %_74 = alloca [2 x i8], align 1
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [2 x i8], align 1
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [1 x i8], align 1
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [2 x i8], align 1
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_5aa1d1250638a5285856df0c8e3018a3) #23
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #17
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9

bb9:                                              ; preds = %bb11, %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %10 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 %src.1, ptr %11, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %12 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %13 = load i8, ptr %12, align 1
  switch i8 %13, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %14, i64 8
  store i64 %rest.1, ptr %15, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %16 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %17 = sub i64 %src.1, 1
  store ptr %16, ptr %rest, align 8
  %18 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb9

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %19 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %19 to i1
  %20 = getelementptr inbounds i8, ptr %_12, i64 8
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr inbounds i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  store ptr %21, ptr %digits, align 8, !captures !116
  %24 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %23, ptr %24, align 8
  store i8 0, ptr %result, align 1
  %_24.0 = load ptr, ptr %digits, align 8
  %25 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %25, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECseJnXURkPMql_10int_ops_u8.exit

bb1.i:                                            ; preds = %bb15
  %26 = icmp ule i64 %_24.1, 2
  %27 = zext i1 %26 to i8
  store i8 %27, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECseJnXURkPMql_10int_ops_u8.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECseJnXURkPMql_10int_ops_u8.exit: ; preds = %bb2.i, %bb1.i
  %28 = load i8, ptr %_0.i, align 1
  %29 = trunc nuw i8 %28 to i1
  br i1 %29, label %bb17, label %bb29

bb14:                                             ; No predecessors!
  store i8 0, ptr %_12, align 8
  %30 = load ptr, ptr %rest, align 8
  %31 = getelementptr inbounds i8, ptr %rest, i64 8
  %32 = load i64, ptr %31, align 8
  %33 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %30, ptr %33, align 8
  %34 = getelementptr inbounds i8, ptr %33, i64 8
  store i64 %32, ptr %34, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECseJnXURkPMql_10int_ops_u8.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowhECseJnXURkPMql_10int_ops_u8.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %36, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %38, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i8, ptr %result, align 1
  %39 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_105, ptr %39, align 1
  store i8 0, ptr %_0, align 1
  br label %bb53

bb42:                                             ; preds = %bb41
  %40 = load ptr, ptr %digits, align 8
  %41 = getelementptr inbounds i8, ptr %digits, i64 8
  %42 = load i64, ptr %41, align 8
  %c = getelementptr inbounds nuw i8, ptr %40, i64 0
  %43 = load ptr, ptr %digits, align 8
  %44 = getelementptr inbounds i8, ptr %digits, i64 8
  %45 = load i64, ptr %44, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %43, i64 1
  %rest.13 = sub i64 %45, 1
  %_85 = load i8, ptr %result, align 1
  %_86 = trunc i32 %radix to i8
; call <u8>::checked_mul
  %46 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCseJnXURkPMql_10int_ops_u8(i8 %_85, i8 %_86) #17
  %47 = extractvalue { i1, i8 } %46, 0
  %48 = extractvalue { i1, i8 } %46, 1
  %49 = zext i1 %47 to i8
  store i8 %49, ptr %mul1, align 1
  %50 = getelementptr inbounds i8, ptr %mul1, i64 1
  store i8 %48, ptr %50, align 1
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %51 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCseJnXURkPMql_10int_ops_u8(i32 %_89, i32 %radix) #17
  %52 = extractvalue { i32, i32 } %51, 0
  %53 = extractvalue { i32, i32 } %51, 1
  store i32 %52, ptr %_88, align 4
  %54 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %53, ptr %54, align 4
  %55 = load i32, ptr %_88, align 4
  %56 = getelementptr inbounds i8, ptr %_88, i64 4
  %57 = load i32, ptr %56, align 4
  %_91 = zext i32 %55 to i64
  %58 = trunc nuw i64 %_91 to i1
  br i1 %58, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %59 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %59, align 4
  %x = trunc i32 %value to i8
  %60 = load i8, ptr %mul1, align 1
  %61 = trunc nuw i8 %60 to i1
  %62 = getelementptr inbounds i8, ptr %mul1, i64 1
  %63 = load i8, ptr %62, align 1
  %_95 = zext i1 %61 to i64
  %64 = trunc nuw i64 %_95 to i1
  br i1 %64, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %65 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %65, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb48:                                             ; preds = %bb46
  %66 = getelementptr inbounds i8, ptr %mul1, i64 1
  %value4 = load i8, ptr %66, align 1
  store i8 %value4, ptr %result, align 1
  %_100 = load i8, ptr %result, align 1
; call <u8>::checked_sub
  %67 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_subCseJnXURkPMql_10int_ops_u8(i8 %_100, i8 %x) #17
  %68 = extractvalue { i1, i8 } %67, 0
  %69 = extractvalue { i1, i8 } %67, 1
  %70 = zext i1 %68 to i8
  store i8 %70, ptr %_99, align 1
  %71 = getelementptr inbounds i8, ptr %_99, i64 1
  store i8 %69, ptr %71, align 1
  %72 = load i8, ptr %_99, align 1
  %73 = trunc nuw i8 %72 to i1
  %74 = getelementptr inbounds i8, ptr %_99, i64 1
  %75 = load i8, ptr %74, align 1
  %_101 = zext i1 %73 to i64
  %76 = trunc nuw i64 %_101 to i1
  br i1 %76, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %77 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %77, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb51:                                             ; preds = %bb48
  %78 = getelementptr inbounds i8, ptr %_99, i64 1
  %value5 = load i8, ptr %78, align 1
  store i8 %value5, ptr %result, align 1
  store ptr %rest.02, ptr %digits, align 8, !captures !116
  %79 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %79, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %80 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %80, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb31:                                             ; preds = %bb30
  %81 = load ptr, ptr %digits, align 8
  %82 = getelementptr inbounds i8, ptr %digits, i64 8
  %83 = load i64, ptr %82, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %81, i64 0
  %84 = load ptr, ptr %digits, align 8
  %85 = getelementptr inbounds i8, ptr %digits, i64 8
  %86 = load i64, ptr %85, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %84, i64 1
  %rest.18 = sub i64 %86, 1
  %_60 = load i8, ptr %result, align 1
  %_61 = trunc i32 %radix to i8
; call <u8>::checked_mul
  %87 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_mulCseJnXURkPMql_10int_ops_u8(i8 %_60, i8 %_61) #17
  %88 = extractvalue { i1, i8 } %87, 0
  %89 = extractvalue { i1, i8 } %87, 1
  %90 = zext i1 %88 to i8
  store i8 %90, ptr %mul, align 1
  %91 = getelementptr inbounds i8, ptr %mul, i64 1
  store i8 %89, ptr %91, align 1
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %92 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCseJnXURkPMql_10int_ops_u8(i32 %_64, i32 %radix) #17
  %93 = extractvalue { i32, i32 } %92, 0
  %94 = extractvalue { i32, i32 } %92, 1
  store i32 %93, ptr %_63, align 4
  %95 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %94, ptr %95, align 4
  %96 = load i32, ptr %_63, align 4
  %97 = getelementptr inbounds i8, ptr %_63, i64 4
  %98 = load i32, ptr %97, align 4
  %_66 = zext i32 %96 to i64
  %99 = trunc nuw i64 %_66 to i1
  br i1 %99, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %100 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %100, align 4
  %x10 = trunc i32 %value9 to i8
  %101 = load i8, ptr %mul, align 1
  %102 = trunc nuw i8 %101 to i1
  %103 = getelementptr inbounds i8, ptr %mul, i64 1
  %104 = load i8, ptr %103, align 1
  %_70 = zext i1 %102 to i64
  %105 = trunc nuw i64 %_70 to i1
  br i1 %105, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %106 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %106, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb37:                                             ; preds = %bb35
  %107 = getelementptr inbounds i8, ptr %mul, i64 1
  %value11 = load i8, ptr %107, align 1
  store i8 %value11, ptr %result, align 1
  %_75 = load i8, ptr %result, align 1
; call <u8>::checked_add
  %108 = call { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_addCseJnXURkPMql_10int_ops_u8(i8 %_75, i8 %x10) #17
  %109 = extractvalue { i1, i8 } %108, 0
  %110 = extractvalue { i1, i8 } %108, 1
  %111 = zext i1 %109 to i8
  store i8 %111, ptr %_74, align 1
  %112 = getelementptr inbounds i8, ptr %_74, i64 1
  store i8 %110, ptr %112, align 1
  %113 = load i8, ptr %_74, align 1
  %114 = trunc nuw i8 %113 to i1
  %115 = getelementptr inbounds i8, ptr %_74, i64 1
  %116 = load i8, ptr %115, align 1
  %_76 = zext i1 %114 to i64
  %117 = trunc nuw i64 %_76 to i1
  br i1 %117, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %118 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %118, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb40:                                             ; preds = %bb37
  %119 = getelementptr inbounds i8, ptr %_74, i64 1
  %value12 = load i8, ptr %119, align 1
  store i8 %value12, ptr %result, align 1
  store ptr %rest.07, ptr %digits, align 8, !captures !116
  %120 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %120, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %121 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %121, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %122 = load ptr, ptr %digits, align 8
  %123 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %123, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %124 = load ptr, ptr %digits, align 8
  %125 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %125, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %126 = load ptr, ptr %digits, align 8
  %127 = getelementptr inbounds i8, ptr %digits, i64 8
  %128 = load i64, ptr %127, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %126, i64 0
  %129 = load ptr, ptr %digits, align 8
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  %131 = load i64, ptr %130, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %129, i64 1
  %rest.115 = sub i64 %131, 1
  %_44 = load i8, ptr %result, align 1
  %_45 = trunc i32 %radix to i8
  %132 = mul i8 %_44, %_45
  store i8 %132, ptr %result, align 1
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %133 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCseJnXURkPMql_10int_ops_u8(i32 %_47, i32 %radix) #17
  %134 = extractvalue { i32, i32 } %133, 0
  %135 = extractvalue { i32, i32 } %133, 1
  store i32 %134, ptr %_46, align 4
  %136 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %135, ptr %136, align 4
  %137 = load i32, ptr %_46, align 4
  %138 = getelementptr inbounds i8, ptr %_46, i64 4
  %139 = load i32, ptr %138, align 4
  %_49 = zext i32 %137 to i64
  %140 = trunc nuw i64 %_49 to i1
  br i1 %140, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %141 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %141, align 4
  %_53 = load i8, ptr %result, align 1
  %_54 = trunc i32 %x16 to i8
  %142 = sub i8 %_53, %_54
  store i8 %142, ptr %result, align 1
  store ptr %rest.014, ptr %digits, align 8, !captures !116
  %143 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %143, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %144 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %144, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb19:                                             ; preds = %bb18
  %145 = load ptr, ptr %digits, align 8
  %146 = getelementptr inbounds i8, ptr %digits, i64 8
  %147 = load i64, ptr %146, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %145, i64 0
  %148 = load ptr, ptr %digits, align 8
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  %150 = load i64, ptr %149, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %148, i64 1
  %rest.119 = sub i64 %150, 1
  %_29 = load i8, ptr %result, align 1
  %_30 = trunc i32 %radix to i8
  %151 = mul i8 %_29, %_30
  store i8 %151, ptr %result, align 1
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %152 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCseJnXURkPMql_10int_ops_u8(i32 %_32, i32 %radix) #17
  %153 = extractvalue { i32, i32 } %152, 0
  %154 = extractvalue { i32, i32 } %152, 1
  store i32 %153, ptr %_31, align 4
  %155 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %154, ptr %155, align 4
  %156 = load i32, ptr %_31, align 4
  %157 = getelementptr inbounds i8, ptr %_31, i64 4
  %158 = load i32, ptr %157, align 4
  %_34 = zext i32 %156 to i64
  %159 = trunc nuw i64 %_34 to i1
  br i1 %159, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %160 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %160, align 4
  %_38 = load i8, ptr %result, align 1
  %_39 = trunc i32 %x20 to i8
  %161 = add i8 %_38, %_39
  store i8 %161, ptr %result, align 1
  store ptr %rest.018, ptr %digits, align 8, !captures !116
  %162 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %162, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %163 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %163, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCseJnXURkPMql_10int_ops_u8(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !117 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCseJnXURkPMql_10int_ops_u8(ptr align 8 %args) #17
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #17
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCseJnXURkPMql_10int_ops_u8() unnamed_addr #4 !guid !118 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseJnXURkPMql_10int_ops_u8() unnamed_addr #0 !guid !119 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCseJnXURkPMql_10int_ops_u8() #17
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCseJnXURkPMql_10int_ops_u8(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !120 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CseJnXURkPMql_10int_ops_u8(i8 %n) unnamed_addr #0 !guid !121 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.994e02650ca0984a4e232d970c64dac2.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #23
  unreachable
}

; <u8>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul18precondition_checkCseJnXURkPMql_10int_ops_u8(i8 %lhs, i8 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !122 {
start:
  %1 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %lhs, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %1, 0
  %_5.1.i = extractvalue { i8, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i8, i1 } %1, 0
  %_4.1 = extractvalue { i8, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseJnXURkPMql_10int_ops_u8(ptr @alloc_eff87de2e562ad9bea1d5ede245212a6, i64 183)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <u8>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shl18precondition_checkCseJnXURkPMql_10int_ops_u8(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !123 {
start:
  %_2 = icmp ult i32 %rhs, 8
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseJnXURkPMql_10int_ops_u8(ptr @alloc_57df2bd3515ba57ec27b75aa1042dee2, i64 183)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <u8>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_shr18precondition_checkCseJnXURkPMql_10int_ops_u8(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !124 {
start:
  %_2 = icmp ult i32 %rhs, 8
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseJnXURkPMql_10int_ops_u8(ptr @alloc_f61fc5fd845387df941deb3653b9481f, i64 183)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCseJnXURkPMql_10int_ops_u8(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !125 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseJnXURkPMql_10int_ops_u8(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCseJnXURkPMql_10int_ops_u8() unnamed_addr #0 !guid !126 {
start:
  ret i1 true
}

; <(u8, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtThbENtB6_5Debug3fmtCseJnXURkPMql_10int_ops_u8(ptr %self, ptr align 8 %f) unnamed_addr #1 !guid !127 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <u8 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1H_NtCs7CppTae75M1_5alloc6stringhNtB6_12SpecToString14spec_to_stringCseJnXURkPMql_10int_ops_u8(ptr sret([24 x i8]) align 8 %_0, ptr %self) unnamed_addr #0 !guid !128 {
start:
  %buf = alloca [3 x i8], align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 3, i1 false)
  %_5 = load i8, ptr %self, align 1
; call <u8>::_fmt
  %0 = call { ptr, i64 } @_RNvMs0_NtNtNtCsl10jNU3mE6R_4core3fmt3num3imph4__fmt(i8 %_5, ptr %buf, i64 3)
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8 %_0, ptr %_4.0, i64 %_4.1) #17
  ret void
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCseJnXURkPMql_10int_ops_u8(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !129 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCseJnXURkPMql_10int_ops_u8(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCseJnXURkPMql_10int_ops_u8(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !130 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCseJnXURkPMql_10int_ops_u8(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <u8 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringhNtB5_8ToString9to_stringCseJnXURkPMql_10int_ops_u8(ptr sret([24 x i8]) align 8 %_0, ptr %self) unnamed_addr #0 !guid !131 {
start:
; call <u8 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1H_NtCs7CppTae75M1_5alloc6stringhNtB6_12SpecToString14spec_to_stringCseJnXURkPMql_10int_ops_u8(ptr sret([24 x i8]) align 8 %_0, ptr %self) #17
  ret void
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCseJnXURkPMql_10int_ops_u8() unnamed_addr #0 !guid !132 {
start:
  ret i8 0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCseJnXURkPMql_10int_ops_u8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !133 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCseJnXURkPMql_10int_ops_u8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !134 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::result::Result<u8, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCseJnXURkPMql_10int_ops_u8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !135 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %8, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12

bb1:                                              ; No predecessors!
  unreachable
}

; <u8 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXsw_NtCsl10jNU3mE6R_4core3numhNtNtNtB7_3str6traits7FromStr8from_strCseJnXURkPMql_10int_ops_u8(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !136 {
start:
; call <u8>::from_str_radix
  %0 = call { i1, i8 } @_RNvMsx_NtCsl10jNU3mE6R_4core3numh14from_str_radixCseJnXURkPMql_10int_ops_u8(ptr %src.0, i64 %src.1, i32 10) #17
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseJnXURkPMql_10int_ops_u8(ptr %_1) unnamed_addr #0 !guid !137 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseJnXURkPMql_10int_ops_u8(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !138 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseJnXURkPMql_10int_ops_u8(ptr align 8 %_1) #17
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<u8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refB9_(ptr) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuEBa_(ptr) unnamed_addr #0

; <u8 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsa_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_6Binary3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <core::option::Option<u8> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionhENtNtB7_3fmt5Debug3fmtCs7CppTae75M1_5alloc(ptr, ptr align 8) unnamed_addr #0

; <u8 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsc_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Octal3fmt(ptr, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshr.i8(i8, i8, i8) #9

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_lower_hex::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_upper_hex::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptoui.sat.i8.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.umul.with.overflow.i8(i8, i8) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #9

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #10

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i8(i8) #11

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.bitreverse.i8(i8) #9

; <core::num::nonzero::NonZero<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3newB9_(i8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctlz.i8(i8, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.uadd.sat.i8(i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.usub.sat.i8(i8, i8) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #12

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; <core::num::nonzero::NonZero<u8>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3getB9_(i8) unnamed_addr #0

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #13

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #14

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #15

; <u8>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMs0_NtNtNtCsl10jNU3mE6R_4core3fmt3num3imph4__fmt(i8, ptr, i64) unnamed_addr #1

; <str as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #0

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #16 !guid !139 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECseJnXURkPMql_10int_ops_u8(ptr @_RNvCseJnXURkPMql_10int_ops_u84main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #12 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #16 = { nonlazybind "target-cpu"="x86-64" }
attributes #17 = { inlinehint }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noreturn }
attributes #20 = { noinline }
attributes #21 = { nounwind }
attributes #22 = { inlinehint nounwind }
attributes #23 = { noinline noreturn }
attributes #24 = { cold }
attributes #25 = { noinline noreturn nounwind }

!llvm.module.flags = !{!43, !44, !45, !46}
!llvm.ident = !{!47}

!0 = !{i64 8466359288557161432}
!1 = !{i64 2896456124488917214}
!2 = !{i64 8165065637961042123}
!3 = !{i64 5299881109884399194}
!4 = !{i64 -7699071466122863380}
!5 = !{i64 7558765344599455434}
!6 = !{i64 -2214319906118946704}
!7 = !{i64 4179964216819123907}
!8 = !{i64 -7181343009220726007}
!9 = !{i64 -9119685304442188654}
!10 = !{i64 -3557521500243566289}
!11 = !{i64 8700909812355715693}
!12 = !{i64 -6977468453174596749}
!13 = !{i64 4617472616095798878}
!14 = !{i64 214670645678163794}
!15 = !{i64 -7099344033051747433}
!16 = !{i64 6573449967576876828}
!17 = !{i64 -7449350358463245744}
!18 = !{i64 5287730090943825238}
!19 = !{i64 8217510241505600760}
!20 = !{i64 6388268539410098537}
!21 = !{i64 -4390069672766203331}
!22 = !{i64 6852373480193802520}
!23 = !{i64 3337310582179585681}
!24 = !{i64 2815794954330241821}
!25 = !{i64 -531509188519807563}
!26 = !{i64 7943615215268182672}
!27 = !{i64 6482811751217387601}
!28 = !{i64 7473149459684482499}
!29 = !{i64 3979562331630979585}
!30 = !{i64 5601480851504037875}
!31 = !{i64 -722411747054554725}
!32 = !{i64 470476917719605657}
!33 = !{i64 -7181283509276621940}
!34 = !{i64 5094234784715556069}
!35 = !{i64 8506869475496115371}
!36 = !{i64 -4424273550592371283}
!37 = !{i64 7957738606477942353}
!38 = !{i64 -6802703803692259716}
!39 = !{i64 -7854438341332466922}
!40 = !{i64 191529638825775100}
!41 = !{i64 7240920022137554267}
!42 = !{i64 -3607666343666360680}
!43 = !{i32 8, !"PIC Level", i32 2}
!44 = !{i32 7, !"PIE Level", i32 2}
!45 = !{i32 2, !"RtLibUseGOT", i32 1}
!46 = !{i32 7, !"uwtable", i32 2}
!47 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!48 = !{i64 4300804700582476536}
!49 = !{i64 5265253677884651669}
!50 = !{i64 8556123303797182986}
!51 = !{i64 -8223971737749777996}
!52 = !{i64 4258754556936679086}
!53 = !{i64 3036871402716214218}
!54 = !{i64 -8438694793570091022}
!55 = !{i64 8421638903023305000}
!56 = !{i64 -3101413628587345703}
!57 = !{i64 -2727843623788249922}
!58 = !{i64 -734200845814344122}
!59 = !{i64 2545140154434561667}
!60 = !{i64 -8227031267507732556}
!61 = !{i64 2997405961026814167}
!62 = !{i64 4328218361235937918}
!63 = !{i64 -1551379948788213149}
!64 = !{i64 8305555010048413833}
!65 = !{i64 -3248532897654768477}
!66 = !{i64 -1920539443703214689}
!67 = !{i64 8140601837778425267}
!68 = !{i64 -9162598292007100808}
!69 = !{i64 9011382101926914521}
!70 = !{i64 8473626098635500125}
!71 = !{i64 3446810228538156619}
!72 = !{i64 1318408931290867}
!73 = !{i64 -2723024267560296167}
!74 = !{i64 128423798375273798}
!75 = !{i64 1818990742770941778}
!76 = !{i64 -7501328017253239659}
!77 = !{i64 3790034011210269711}
!78 = !{i64 4339286150839513142}
!79 = !{i64 -3067073085569318922}
!80 = !{i64 8280058852696673008}
!81 = !{i64 -7842064314367254583}
!82 = !{i64 -8460521183743086777}
!83 = !{i64 -8919625530994302665}
!84 = !{i64 1444667105851898036}
!85 = !{i64 3565926962966760900}
!86 = !{i64 8138070923691711953}
!87 = !{i64 -613936342490654173}
!88 = !{i64 -5314867083770563801}
!89 = !{i64 1671694945875789144}
!90 = !{i64 -1555859186016846992}
!91 = !{i64 931125716767656229}
!92 = !{i64 66800262611433359}
!93 = !{i64 6761549126410755993}
!94 = !{i64 -7064021251746444893}
!95 = !{i64 1553622141513769860}
!96 = !{i64 7260162032760302870}
!97 = !{i64 -3126735805746175596}
!98 = !{i64 -1018848819145666254}
!99 = !{i64 -1287780267540565018}
!100 = !{i64 1632407276182338162}
!101 = !{i64 5694122721033287492}
!102 = !{i64 519968761998560185}
!103 = !{i64 760467447238656897}
!104 = !{i64 355475996599552785}
!105 = !{i64 -5718123562926199329}
!106 = !{i64 2972205955761210938}
!107 = !{i64 -699777279061027822}
!108 = !{i64 -8783506133387586615}
!109 = !{i64 8082456393537789183}
!110 = !{i64 463771176676449751}
!111 = !{i64 -581693541169176554}
!112 = !{i64 6521231758025240956}
!113 = !{i64 -2866823832457659589}
!114 = !{i64 3588419761488535309}
!115 = !{i64 -1900404226018641420}
!116 = !{!"address", !"read_provenance"}
!117 = !{i64 -559293076511801299}
!118 = !{i64 4841161269541021090}
!119 = !{i64 -3416692077024491688}
!120 = !{i64 5096263596723929214}
!121 = !{i64 8057917081087937539}
!122 = !{i64 6790201671732570632}
!123 = !{i64 7440249824535425132}
!124 = !{i64 165627623116919333}
!125 = !{i64 8269538690521722047}
!126 = !{i64 2961737123901752021}
!127 = !{i64 -5323391712852590876}
!128 = !{i64 -8831517546886135603}
!129 = !{i64 1618283127332506681}
!130 = !{i64 2419460604060193855}
!131 = !{i64 7836574731319309361}
!132 = !{i64 6010729883696052614}
!133 = !{i64 8867585753175336412}
!134 = !{i64 3864562202030758094}
!135 = !{i64 -8637311565785857876}
!136 = !{i64 -8233640832239092823}
!137 = !{i64 -8914418096529903300}
!138 = !{i64 -1473518768288353840}
!139 = !{i64 -2624081020897602054}
