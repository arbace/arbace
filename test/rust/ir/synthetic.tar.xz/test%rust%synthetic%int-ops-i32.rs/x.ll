; ModuleID = 'int_ops_i32.75b3dca032daa5e6-cgu.0'
source_filename = "int_ops_i32.75b3dca032daa5e6-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsa6wK0QGfIeE_11int_ops_i32, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csa6wK0QGfIeE_11int_ops_i32, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csa6wK0QGfIeE_11int_ops_i32 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !3
@alloc_5b66301ade9e29b84d934b21047ee8a3 = private unnamed_addr constant [4 x i8] c" \00\00\00", align 4, !guid !4
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !5
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !7
@alloc_7019727ef41071f2ebc10b47f1127ed8 = private unnamed_addr constant [35 x i8] c"test/rust/synthetic/int-ops-i32.rs\00", align 1, !guid !8
@alloc_8d3346adc094adb684c29777989c3870 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_7019727ef41071f2ebc10b47f1127ed8, [16 x i8] c"\22\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !9
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !10
@alloc_57172b0953aa92f9c03c288dcf70d372 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_7019727ef41071f2ebc10b47f1127ed8, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !11
@alloc_07450170cb785b1c11c90fa6e8c9f8c6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_7019727ef41071f2ebc10b47f1127ed8, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !12
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !13
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !14
@alloc_91e2d8f9efb8e9d23ecdfcecae5c3b26 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_7019727ef41071f2ebc10b47f1127ed8, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\00\1B\00\00\00" }>, align 8, !guid !15
@alloc_e4ce1314da1468d02f58a2cffa3c68e3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_7019727ef41071f2ebc10b47f1127ed8, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !16
@alloc_67568d91f0e90d45aeb7ad0942f2155e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_7019727ef41071f2ebc10b47f1127ed8, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !17
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !18
@alloc_50f965bb574aafc5e48212a6fe739f63 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_7019727ef41071f2ebc10b47f1127ed8, [16 x i8] c"\22\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !19
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !20
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !21
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !22
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !23
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !24
@alloc_321cb53071ed634b0d814fda86198fe8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\AD\01\00\00\05\00\00\00" }>, align 8, !guid !25
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !26
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !27
@alloc_214c36c067ac462f6ec22f6fcbcc1f6d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\0A\05\00\00\05\00\00\00" }>, align 8, !guid !28
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !29
@anon.a284940029756418f450b23cf5472523.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !30
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !31
@alloc_dd07830ff498a5ad3af27fc9310868e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E5\00\00\00\12\00\00\00" }>, align 8, !guid !32
@alloc_73a63def61abd19c5b285b7e5bba6f74 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E6\00\00\00\05\00\00\00" }>, align 8, !guid !33
@alloc_c9c619c258f652778f0098fbdacd3593 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F1\00\00\00\12\00\00\00" }>, align 8, !guid !34
@alloc_debe392282102e1a17f340d9b53f07df = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F2\00\00\00\12\00\00\00" }>, align 8, !guid !35
@alloc_d1e64d3a180065bd6a022925cad00717 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F3\00\00\00\05\00\00\00" }>, align 8, !guid !36
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !37
@alloc_eea3b4108fd45221c9468d112de34f4d = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: i32::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !38
@alloc_51faf7dcdededcddf8ff69cfb939d83f = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: i32::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !39
@alloc_43d9f86d1bad35544b007cb40d6affed = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u32::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !40
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !41
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !42
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32 }>, align 8, !guid !43
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !44
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !45
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !46
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !47
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !48
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32 }>, align 8, !guid !49

; <str>::parse::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parselECsa6wK0QGfIeE_11int_ops_i32(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !55 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <i32 as core::str::traits::FromStr>::from_str
  %1 = call i64 @_RNvXso_NtCsl10jNU3mE6R_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCsa6wK0QGfIeE_11int_ops_i32(ptr %self.0, i64 %self.1) #16
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <core::fmt::rt::Argument>::new_binary::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarylECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !56 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refB9_(ptr align 4 %x) #16
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuEBa_(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !57 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr %x) #16
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !58 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 8 %x) #16
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !59 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %x) #16
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexlECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !60 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refB9_(ptr align 4 %x) #16
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuEBa_(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !61 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i32>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %x) #16
; call <core::ptr::non_null::NonNull<core::option::Option<i32>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionlEE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i32, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultlNtNtNtB7_3num5error13ParseIntErrorEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !62 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i32, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %x) #16
; call <core::ptr::non_null::NonNull<core::result::Result<i32, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlNtNtNtBa_3num5error13ParseIntErrorEE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultlNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(i32, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTlbEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !63 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(i32, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTlbEE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %x) #16
; call <core::ptr::non_null::NonNull<(i32, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTlbEE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTlbENtB6_5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !64 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr %x) #16
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octallECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !65 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refB9_(ptr align 4 %x) #16
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuEBa_(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionlEE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %self) unnamed_addr #0 !guid !66 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlNtNtNtBa_3num5error13ParseIntErrorEE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %self) unnamed_addr #0 !guid !67 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<(i32, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTlbEE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %self) unnamed_addr #0 !guid !68 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %self) unnamed_addr #0 !guid !69 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %self) unnamed_addr #0 !guid !70 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsa6wK0QGfIeE_11int_ops_i32(ptr %self) unnamed_addr #0 !guid !71 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsa6wK0QGfIeE_11int_ops_i32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !72 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsa6wK0QGfIeE_11int_ops_i32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !73 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsa6wK0QGfIeE_11int_ops_i32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !74 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsa6wK0QGfIeE_11int_ops_i32(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !75 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u32>
; Function Attrs: nounwind nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftmECsa6wK0QGfIeE_11int_ops_i32(i32 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !76 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 4 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %_0 = call i32 @llvm.fshl.i32(i32 %x, i32 %x, i32 %_3)
  ret i32 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #18
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u32>
; Function Attrs: nounwind nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightmECsa6wK0QGfIeE_11int_ops_i32(i32 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !77 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 4 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %_0 = call i32 @llvm.fshr.i32(i32 %x, i32 %x, i32 %_3)
  ret i32 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #18
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::is_val_statically_known::<i32>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownlECsa6wK0QGfIeE_11int_ops_i32(i32 %_arg) unnamed_addr #2 !guid !78 {
start:
  ret i1 false
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsa6wK0QGfIeE_11int_ops_i32(i32 %dummy) unnamed_addr #0 !guid !79 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !80
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsa6wK0QGfIeE_11int_ops_i32(i32 %dummy) unnamed_addr #0 !guid !81 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !80
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsa6wK0QGfIeE_11int_ops_i32(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !82 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsa6wK0QGfIeE_11int_ops_i32(ptr %f) #16
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #16
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csa6wK0QGfIeE_11int_ops_i32(ptr align 8 %_1) unnamed_addr #0 !guid !83 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsa6wK0QGfIeE_11int_ops_i32(ptr %_4) #19
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsa6wK0QGfIeE_11int_ops_i32() #16
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csa6wK0QGfIeE_11int_ops_i32(i8 %_2) #16
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsa6wK0QGfIeE_11int_ops_i32(ptr %_1) unnamed_addr #0 !guid !84 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsa6wK0QGfIeE_11int_ops_i32(ptr %0) #16
  ret i32 %_0
}

; int_ops_i32::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsa6wK0QGfIeE_11int_ops_i324main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !85 {
start:
  %0 = alloca [16 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %_294 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_284 = alloca [24 x i8], align 8
  %_283 = alloca [24 x i8], align 8
  %_279 = alloca [24 x i8], align 8
  %_276 = alloca [8 x i8], align 8
  %_269 = alloca [16 x i8], align 8
  %_268 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_264 = alloca [4 x i8], align 4
  %_262 = alloca [4 x i8], align 4
  %_255 = alloca [16 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_252 = alloca [4 x i8], align 4
  %_250 = alloca [4 x i8], align 4
  %_243 = alloca [16 x i8], align 8
  %_242 = alloca [16 x i8], align 8
  %_241 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_239 = alloca [8 x i8], align 8
  %_237 = alloca [4 x i8], align 4
  %_233 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_226 = alloca [16 x i8], align 8
  %_225 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_222 = alloca [8 x i8], align 4
  %_220 = alloca [1 x i8], align 1
  %_216 = alloca [8 x i8], align 4
  %_209 = alloca [16 x i8], align 8
  %_208 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_206 = alloca [4 x i8], align 4
  %_203 = alloca [4 x i8], align 4
  %_196 = alloca [16 x i8], align 8
  %_195 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_193 = alloca [8 x i8], align 4
  %_190 = alloca [8 x i8], align 4
  %_183 = alloca [16 x i8], align 8
  %_182 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_176 = alloca [4 x i8], align 4
  %_170 = alloca [4 x i8], align 4
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [4 x i8], align 4
  %_156 = alloca [4 x i8], align 4
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [4 x i8], align 4
  %_144 = alloca [4 x i8], align 4
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [4 x i8], align 4
  %_130 = alloca [4 x i8], align 4
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [8 x i8], align 4
  %_98 = alloca [8 x i8], align 4
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [4 x i8], align 4
  %_86 = alloca [4 x i8], align 4
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [4 x i8], align 4
  %_74 = alloca [4 x i8], align 4
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [4 x i8], align 4
  %_62 = alloca [4 x i8], align 4
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [8 x i8], align 4
  %_50 = alloca [8 x i8], align 4
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [8 x i8], align 4
  %_38 = alloca [8 x i8], align 4
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [4 x i8], align 4
  %min = alloca [4 x i8], align 4
; call core::hint::black_box::<i32>
  %_4 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsa6wK0QGfIeE_11int_ops_i32(i32 -2147483648) #16
; call core::hint::black_box::<i32>
  %_5 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsa6wK0QGfIeE_11int_ops_i32(i32 2147483647) #16
  store i32 %_4, ptr %min, align 4
  store i32 %_5, ptr %max, align 4
; call core::hint::black_box::<i32>
  %one = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsa6wK0QGfIeE_11int_ops_i32(i32 1) #16
; call core::hint::black_box::<i32>
  %three = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsa6wK0QGfIeE_11int_ops_i32(i32 3) #16
  store ptr %min, ptr %args, align 8
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_5b66301ade9e29b84d934b21047ee8a3, ptr %4, align 8
  %_297 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_15, ptr align 4 %_297) #16
  %5 = getelementptr inbounds i8, ptr %args, i64 8
  %_298 = load ptr, ptr %5, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_16, ptr align 4 %_298) #16
  %6 = getelementptr inbounds i8, ptr %args, i64 16
  %_299 = load ptr, ptr %6, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_299) #16
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_15, i64 16, i1 false)
  %8 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %8, ptr align 8 %_16, i64 16, i1 false)
  %9 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %10 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #16
  %_9.0 = extractvalue { ptr, ptr } %10, 0
  %_9.1 = extractvalue { ptr, ptr } %10, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %13, align 8
  %_300 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexlECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8 %_28, ptr align 4 %_300) #16
  %14 = getelementptr inbounds i8, ptr %args2, i64 8
  %_301 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_binary::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarylECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_29, ptr align 4 %_301) #16
  %15 = getelementptr inbounds i8, ptr %args2, i64 16
  %_302 = load ptr, ptr %15, align 8
; call <core::fmt::rt::Argument>::new_octal::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octallECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_30, ptr align 4 %_302) #16
  %16 = getelementptr inbounds i8, ptr %args2, i64 24
  %_303 = load ptr, ptr %16, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexlECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_31, ptr align 4 %_303) #16
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_28, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_29, i64 16, i1 false)
  %19 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %19, ptr align 8 %_30, i64 16, i1 false)
  %20 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %21 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #16
  %_21.0 = extractvalue { ptr, ptr } %21, 0
  %_21.1 = extractvalue { ptr, ptr } %21, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %22 = load i32, ptr %max, align 4
; call <i32>::checked_add
  %23 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCsa6wK0QGfIeE_11int_ops_i32(i32 %22, i32 %one) #16
  %24 = extractvalue { i32, i32 } %23, 0
  %25 = extractvalue { i32, i32 } %23, 1
  store i32 %24, ptr %_38, align 4
  %26 = getelementptr inbounds i8, ptr %_38, i64 4
  store i32 %25, ptr %26, align 4
  %27 = load i32, ptr %min, align 4
; call <i32>::checked_add
  %28 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCsa6wK0QGfIeE_11int_ops_i32(i32 %27, i32 %one) #16
  %29 = extractvalue { i32, i32 } %28, 0
  %30 = extractvalue { i32, i32 } %28, 1
  store i32 %29, ptr %_40, align 4
  %31 = getelementptr inbounds i8, ptr %_40, i64 4
  store i32 %30, ptr %31, align 4
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_42, ptr align 4 %_38) #16
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_43, ptr align 4 %_40) #16
  %32 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %_42, i64 16, i1 false)
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %34 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #16
  %_35.0 = extractvalue { ptr, ptr } %34, 0
  %_35.1 = extractvalue { ptr, ptr } %34, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %35 = load i32, ptr %max, align 4
  %36 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %35, i32 %one)
  %_5.0.i = extractvalue { i32, i1 } %36, 0
  %_5.1.i = extractvalue { i32, i1 } %36, 1
  %37 = extractvalue { i32, i1 } %36, 0
  %38 = extractvalue { i32, i1 } %36, 1
  store i32 %37, ptr %_50, align 4
  %39 = getelementptr inbounds i8, ptr %_50, i64 4
  %40 = zext i1 %38 to i8
  store i8 %40, ptr %39, align 4
  %41 = load i32, ptr %min, align 4
  %42 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %41, i32 %one)
  %_5.0.i53 = extractvalue { i32, i1 } %42, 0
  %_5.1.i54 = extractvalue { i32, i1 } %42, 1
  %43 = extractvalue { i32, i1 } %42, 0
  %44 = extractvalue { i32, i1 } %42, 1
  store i32 %43, ptr %_52, align 4
  %45 = getelementptr inbounds i8, ptr %_52, i64 4
  %46 = zext i1 %44 to i8
  store i8 %46, ptr %45, align 4
; call <core::fmt::rt::Argument>::new_debug::<(i32, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTlbEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_54, ptr align 4 %_50) #16
; call <core::fmt::rt::Argument>::new_debug::<(i32, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTlbEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_55, ptr align 4 %_52) #16
  %47 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %47, ptr align 8 %_54, i64 16, i1 false)
  %48 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %48, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %49 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #16
  %_47.0 = extractvalue { ptr, ptr } %49, 0
  %_47.1 = extractvalue { ptr, ptr } %49, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %50 = load i32, ptr %max, align 4
  %_0.i35 = add i32 %50, %one
  store i32 %_0.i35, ptr %_62, align 4
  %51 = load i32, ptr %min, align 4
  %_0.i42 = sub i32 %51, %one
  store i32 %_0.i42, ptr %_64, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_66, ptr align 4 %_62) #16
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_67, ptr align 4 %_64) #16
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_66, i64 16, i1 false)
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %54 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #16
  %_59.0 = extractvalue { ptr, ptr } %54, 0
  %_59.1 = extractvalue { ptr, ptr } %54, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %55 = load i32, ptr %max, align 4
  %_0.i49 = call i32 @llvm.sadd.sat.i32(i32 %55, i32 %three)
  store i32 %_0.i49, ptr %_74, align 4
  %56 = load i32, ptr %min, align 4
  %_0.i50 = call i32 @llvm.ssub.sat.i32(i32 %56, i32 %three)
  store i32 %_0.i50, ptr %_76, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_78, ptr align 4 %_74) #16
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_79, ptr align 4 %_76) #16
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_78, i64 16, i1 false)
  %58 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %58, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %59 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #16
  %_71.0 = extractvalue { ptr, ptr } %59, 0
  %_71.1 = extractvalue { ptr, ptr } %59, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %60 = load i32, ptr %max, align 4
  %_0.i37 = mul i32 %60, %three
  store i32 %_0.i37, ptr %_86, align 4
  %61 = load i32, ptr %max, align 4
  %62 = load i32, ptr %max, align 4
  %_0.i36 = mul i32 %61, %62
  store i32 %_0.i36, ptr %_88, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_90, ptr align 4 %_86) #16
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_91, ptr align 4 %_88) #16
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_90, i64 16, i1 false)
  %64 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %64, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %65 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #16
  %_83.0 = extractvalue { ptr, ptr } %65, 0
  %_83.1 = extractvalue { ptr, ptr } %65, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %66 = load i32, ptr %max, align 4
; call <i32>::checked_mul
  %67 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %66, i32 %three) #16
  %68 = extractvalue { i32, i32 } %67, 0
  %69 = extractvalue { i32, i32 } %67, 1
  store i32 %68, ptr %_98, align 4
  %70 = getelementptr inbounds i8, ptr %_98, i64 4
  store i32 %69, ptr %70, align 4
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsa6wK0QGfIeE_11int_ops_i32(i32 5) #16
; call <i32>::checked_pow
  %71 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_powCsa6wK0QGfIeE_11int_ops_i32(i32 %three, i32 %_101) #16
  %72 = extractvalue { i32, i32 } %71, 0
  %73 = extractvalue { i32, i32 } %71, 1
  store i32 %72, ptr %_100, align 4
  %74 = getelementptr inbounds i8, ptr %_100, i64 4
  store i32 %73, ptr %74, align 4
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_103, ptr align 4 %_98) #16
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_104, ptr align 4 %_100) #16
  %75 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %75, ptr align 8 %_103, i64 16, i1 false)
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %77 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #16
  %_95.0 = extractvalue { ptr, ptr } %77, 0
  %_95.1 = extractvalue { ptr, ptr } %77, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %78 = load i32, ptr %max, align 4
  %_0.i55 = call i32 @llvm.ctpop.i32(i32 %78)
  store i32 %_0.i55, ptr %_111, align 4
  %79 = load i32, ptr %max, align 4
  %_0.i61 = call i32 @llvm.ctlz.i32(i32 %79, i1 false)
  store i32 %_0.i61, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsa6wK0QGfIeE_11int_ops_i32(i32 3) #16
  %_119 = icmp ult i32 %_117, 32
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %80 = and i32 %_117, 31
  %_116 = shl i32 %one, %80
  %_0.i62 = call i32 @llvm.cttz.i32(i32 %_116, i1 false)
  store i32 %_0.i62, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %81 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %81, align 8
  %82 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %82, align 8
  %_316 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_316) #16
  %83 = getelementptr inbounds i8, ptr %args10, i64 8
  %_317 = load ptr, ptr %83, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_317) #16
  %84 = getelementptr inbounds i8, ptr %args10, i64 16
  %_318 = load ptr, ptr %84, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_318) #16
  %85 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %85, ptr align 8 %_121, i64 16, i1 false)
  %86 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %86, ptr align 8 %_122, i64 16, i1 false)
  %87 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %87, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %88 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #16
  %_108.0 = extractvalue { ptr, ptr } %88, 0
  %_108.1 = extractvalue { ptr, ptr } %88, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsa6wK0QGfIeE_11int_ops_i32(i32 5) #16
  %89 = load i32, ptr %max, align 4
; call core::intrinsics::rotate_left::<u32>
  %_0.i56 = call i32 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftmECsa6wK0QGfIeE_11int_ops_i32(i32 %89, i32 %_131) #20
  store i32 %_0.i56, ptr %_130, align 4
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsa6wK0QGfIeE_11int_ops_i32(i32 7) #16
  %90 = load i32, ptr %min, align 4
; call core::intrinsics::rotate_right::<u32>
  %_0.i59 = call i32 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightmECsa6wK0QGfIeE_11int_ops_i32(i32 %90, i32 %_134) #20
  store i32 %_0.i59, ptr %_133, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_136, ptr align 4 %_130) #16
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_137, ptr align 4 %_133) #16
  %91 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %91, ptr align 8 %_136, i64 16, i1 false)
  %92 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %92, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %93 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #16
  %_127.0 = extractvalue { ptr, ptr } %93, 0
  %_127.1 = extractvalue { ptr, ptr } %93, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %94 = load i32, ptr %max, align 4
  %_0.i = call i32 @llvm.bswap.i32(i32 %94)
  store i32 %_0.i, ptr %_144, align 4
  %95 = load i32, ptr %max, align 4
  %_0.i58 = call i32 @llvm.bitreverse.i32(i32 %95)
  store i32 %_0.i58, ptr %_146, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_148, ptr align 4 %_144) #16
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_149, ptr align 4 %_146) #16
  %96 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %96, ptr align 8 %_148, i64 16, i1 false)
  %97 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %97, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %98 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #16
  %_141.0 = extractvalue { ptr, ptr } %98, 0
  %_141.1 = extractvalue { ptr, ptr } %98, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsa6wK0QGfIeE_11int_ops_i32(i32 70) #16
  %99 = load i32, ptr %max, align 4
  %_3.i38 = and i32 %_157, 31
; call core::ub_checks::check_language_ub
  %_3.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_3.i44, label %bb2.i, label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <i32>::unchecked_shl::precondition_check
  call void @_RNvNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i32 %_3.i38, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #21
  br label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %_0.i45 = shl i32 %99, %_3.i38
  store i32 %_0.i45, ptr %_156, align 4
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsa6wK0QGfIeE_11int_ops_i32(i32 66) #16
  %100 = load i32, ptr %min, align 4
  %_3.i40 = and i32 %_160, 31
; call core::ub_checks::check_language_ub
  %_3.i46 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_3.i46, label %bb2.i48, label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shr.exit

bb2.i48:                                          ; preds = %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit
; call <i32>::unchecked_shr::precondition_check
  call void @_RNvNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shr18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i32 %_3.i40, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #21
  br label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shr.exit

_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shr.exit: ; preds = %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit, %bb2.i48
  %_0.i47 = ashr i32 %100, %_3.i40
  store i32 %_0.i47, ptr %_159, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_162, ptr align 4 %_156) #16
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_163, ptr align 4 %_159) #16
  %101 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %101, ptr align 8 %_162, i64 16, i1 false)
  %102 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %102, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %103 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #16
  %_153.0 = extractvalue { ptr, ptr } %103, 0
  %_153.1 = extractvalue { ptr, ptr } %103, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i32 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_8d3346adc094adb684c29777989c3870) #22
  unreachable

bb85:                                             ; preds = %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shr.exit
  %_172 = icmp eq i32 %three, -1
  %104 = load i32, ptr %max, align 4
  %_173 = icmp eq i32 %104, -2147483648
  %_174 = and i1 %_172, %_173
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_57172b0953aa92f9c03c288dcf70d372) #22
  unreachable

bb86:                                             ; preds = %bb85
  %105 = load i32, ptr %max, align 4
  %106 = sdiv i32 %105, %three
  store i32 %106, ptr %_170, align 4
  %_177 = icmp eq i32 %three, 0
  br i1 %_177, label %panic27, label %bb87

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_57172b0953aa92f9c03c288dcf70d372) #22
  unreachable

bb87:                                             ; preds = %bb86
  %_178 = icmp eq i32 %three, -1
  %107 = load i32, ptr %max, align 4
  %_179 = icmp eq i32 %107, -2147483648
  %_180 = and i1 %_178, %_179
  br i1 %_180, label %panic28, label %bb88

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_07450170cb785b1c11c90fa6e8c9f8c6) #22
  unreachable

bb88:                                             ; preds = %bb87
  %108 = load i32, ptr %max, align 4
  %109 = srem i32 %108, %three
  store i32 %109, ptr %_176, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_182, ptr align 4 %_170) #16
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_183, ptr align 4 %_176) #16
  %110 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %110, ptr align 8 %_182, i64 16, i1 false)
  %111 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %111, ptr align 8 %_183, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %112 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #16
  %_167.0 = extractvalue { ptr, ptr } %112, 0
  %_167.1 = extractvalue { ptr, ptr } %112, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<i32>
  %_191 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsa6wK0QGfIeE_11int_ops_i32(i32 0) #16
  %113 = load i32, ptr %max, align 4
; call <i32>::checked_div
  %114 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_divCsa6wK0QGfIeE_11int_ops_i32(i32 %113, i32 %_191) #16
  %115 = extractvalue { i32, i32 } %114, 0
  %116 = extractvalue { i32, i32 } %114, 1
  store i32 %115, ptr %_190, align 4
  %117 = getelementptr inbounds i8, ptr %_190, i64 4
  store i32 %116, ptr %117, align 4
  %118 = load i32, ptr %max, align 4
; call <i32>::checked_rem
  %119 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_remCsa6wK0QGfIeE_11int_ops_i32(i32 %118, i32 %three) #16
  %120 = extractvalue { i32, i32 } %119, 0
  %121 = extractvalue { i32, i32 } %119, 1
  store i32 %120, ptr %_193, align 4
  %122 = getelementptr inbounds i8, ptr %_193, i64 4
  store i32 %121, ptr %122, align 4
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_195, ptr align 4 %_190) #16
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i32>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionlEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_196, ptr align 4 %_193) #16
  %123 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %123, ptr align 8 %_195, i64 16, i1 false)
  %124 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %124, ptr align 8 %_196, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %125 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #16
  %_187.0 = extractvalue { ptr, ptr } %125, 0
  %_187.1 = extractvalue { ptr, ptr } %125, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_187.0, ptr %_187.1)
; call core::hint::black_box::<u32>
  %_204 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsa6wK0QGfIeE_11int_ops_i32(i32 4) #16
; call <i32>::pow
  %126 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl3powCsa6wK0QGfIeE_11int_ops_i32(i32 %three, i32 %_204) #16
  store i32 %126, ptr %_203, align 4
  %127 = load i32, ptr %max, align 4
  %128 = load i32, ptr %min, align 4
; call <i32>::abs_diff
  %129 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl8abs_diffCsa6wK0QGfIeE_11int_ops_i32(i32 %127, i32 %128) #16
  store i32 %129, ptr %_206, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_208, ptr align 4 %_203) #16
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_209, ptr align 4 %_206) #16
  %130 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %130, ptr align 8 %_208, i64 16, i1 false)
  %131 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %131, ptr align 8 %_209, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %132 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #16
  %_200.0 = extractvalue { ptr, ptr } %132, 0
  %_200.1 = extractvalue { ptr, ptr } %132, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_200.0, ptr %_200.1)
; call core::hint::black_box::<u32>
  %_218 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsa6wK0QGfIeE_11int_ops_i32(i32 7) #16
; call <i32>::from_str_radix
  %133 = call i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl14from_str_radixCsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_218) #16
  store i64 %133, ptr %2, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_216, ptr align 8 %2, i64 8, i1 false)
; call <str>::parse::<i32>
  %134 = call i64 @_RINvMNtCsl10jNU3mE6R_4core3stre5parselECsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #16
  store i64 %134, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_222, ptr align 8 %1, i64 8, i1 false)
; call <core::result::Result<i32, core::num::error::ParseIntError>>::is_ok
  %135 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlNtNtNtB4_3num5error13ParseIntErrorE5is_okCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %_222) #16
  %136 = zext i1 %135 to i8
  store i8 %136, ptr %_220, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i32, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultlNtNtNtB7_3num5error13ParseIntErrorEECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_225, ptr align 4 %_216) #16
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_226, ptr %_220) #16
  %137 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %137, ptr align 8 %_225, i64 16, i1 false)
  %138 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %138, ptr align 8 %_226, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %139 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #16
  %_213.0 = extractvalue { ptr, ptr } %139, 0
  %_213.1 = extractvalue { ptr, ptr } %139, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_213.0, ptr %_213.1)
  %140 = load i32, ptr %max, align 4
  %_235 = sitofp i32 %140 to double
  %_234 = call i32 @llvm.fptosi.sat.i32.f64(double %_235)
  %141 = load i32, ptr %max, align 4
  %142 = icmp eq i32 %_234, %141
  %143 = zext i1 %142 to i8
  store i8 %143, ptr %_233, align 1
  %144 = load i32, ptr %max, align 4
  %145 = sitofp i32 %144 to float
  store float %145, ptr %_237, align 4
  %146 = load i32, ptr %min, align 4
  %147 = sitofp i32 %146 to double
  store double %147, ptr %_239, align 8
  store ptr %_233, ptr %args19, align 8
  %148 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_237, ptr %148, align 8
  %149 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_239, ptr %149, align 8
  %_333 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_241, ptr %_333) #16
  %150 = getelementptr inbounds i8, ptr %args19, i64 8
  %_334 = load ptr, ptr %150, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_242, ptr align 4 %_334) #16
  %151 = getelementptr inbounds i8, ptr %args19, i64 16
  %_335 = load ptr, ptr %151, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsa6wK0QGfIeE_11int_ops_i32(ptr sret([16 x i8]) align 8 %_243, ptr align 8 %_335) #16
  %152 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %152, ptr align 8 %_241, i64 16, i1 false)
  %153 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %153, ptr align 8 %_242, i64 16, i1 false)
  %154 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %154, ptr align 8 %_243, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %155 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #16
  %_230.0 = extractvalue { ptr, ptr } %155, 0
  %_230.1 = extractvalue { ptr, ptr } %155, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_230.0, ptr %_230.1)
  %156 = load i32, ptr %max, align 4
  %_2.i = xor i32 %156, -1
  %_0.i60 = call i32 @llvm.ctlz.i32(i32 %_2.i, i1 false)
  store i32 %_0.i60, ptr %_250, align 4
  %157 = load i32, ptr %min, align 4
  %_0.i63 = call i32 @llvm.cttz.i32(i32 %157, i1 false)
  store i32 %_0.i63, ptr %_252, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_254, ptr align 4 %_250) #16
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_255, ptr align 4 %_252) #16
  %158 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %158, ptr align 8 %_254, i64 16, i1 false)
  %159 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %159, ptr align 8 %_255, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %160 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #16
  %_247.0 = extractvalue { ptr, ptr } %160, 0
  %_247.1 = extractvalue { ptr, ptr } %160, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_247.0, ptr %_247.1)
  %161 = load i32, ptr %max, align 4
; call <i32>::isqrt
  %162 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl5isqrtCsa6wK0QGfIeE_11int_ops_i32(i32 %161, ptr align 8 @alloc_91e2d8f9efb8e9d23ecdfcecae5c3b26) #16
  store i32 %162, ptr %_262, align 4
  %163 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %three, i32 %three)
  %_266.0 = extractvalue { i32, i1 } %163, 0
  %_266.1 = extractvalue { i32, i1 } %163, 1
  br i1 %_266.1, label %panic29, label %bb127

panic28:                                          ; preds = %bb87
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_07450170cb785b1c11c90fa6e8c9f8c6) #22
  unreachable

bb127:                                            ; preds = %bb88
; call <i32>::ilog2
  %164 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl5ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %_266.0, ptr align 8 @alloc_67568d91f0e90d45aeb7ad0942f2155e) #16
  store i32 %164, ptr %_264, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_268, ptr align 4 %_262) #16
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_269, ptr align 4 %_264) #16
  %165 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %165, ptr align 8 %_268, i64 16, i1 false)
  %166 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %166, ptr align 8 %_269, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %167 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #16
  %_259.0 = extractvalue { ptr, ptr } %167, 0
  %_259.1 = extractvalue { ptr, ptr } %167, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_259.0, ptr %_259.1)
; call <i32 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringlNtB5_8ToString9to_stringCsddYV2PBJW9h_3std(ptr sret([24 x i8]) align 8 %_279, ptr align 4 %max) #16
; invoke <alloc::string::String>::len
  %_277 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsa6wK0QGfIeE_11int_ops_i32(ptr align 8 %_279)
          to label %bb134 unwind label %cleanup

panic29:                                          ; preds = %bb88
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_e4ce1314da1468d02f58a2cffa3c68e3) #22
  unreachable

bb147:                                            ; preds = %bb146, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279) #23
          to label %bb148 unwind label %terminate

cleanup:                                          ; preds = %bb143, %bb136, %bb135, %bb134, %bb127
  %168 = landingpad { ptr, i32 }
          cleanup
  %169 = extractvalue { ptr, i32 } %168, 0
  %170 = extractvalue { ptr, i32 } %168, 1
  store ptr %169, ptr %0, align 8
  %171 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %170, ptr %171, align 8
  br label %bb147

bb134:                                            ; preds = %bb127
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_289, ptr align 4 %min)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  %172 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %172, ptr align 8 %_289, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %173 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb136 unwind label %cleanup

bb136:                                            ; preds = %bb135
  %_285.0 = extractvalue { ptr, ptr } %173, 0
  %_285.1 = extractvalue { ptr, ptr } %173, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsa6wK0QGfIeE_11int_ops_i32(ptr sret([24 x i8]) align 8 %_284, ptr %_285.0, ptr %_285.1)
          to label %bb137 unwind label %cleanup

bb137:                                            ; preds = %bb136
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_283, ptr align 8 %_284, i64 24, i1 false)
  br label %bb138

bb138:                                            ; preds = %bb137
; invoke <alloc::string::String>::len
  %_281 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsa6wK0QGfIeE_11int_ops_i32(ptr align 8 %_283)
          to label %bb139 unwind label %cleanup30

bb146:                                            ; preds = %cleanup30
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283) #23
          to label %bb147 unwind label %terminate

cleanup30:                                        ; preds = %bb142, %bb141, %bb140, %panic31, %bb138
  %174 = landingpad { ptr, i32 }
          cleanup
  %175 = extractvalue { ptr, i32 } %174, 0
  %176 = extractvalue { ptr, i32 } %174, 1
  store ptr %175, ptr %0, align 8
  %177 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %176, ptr %177, align 8
  br label %bb146

bb139:                                            ; preds = %bb138
  %_292.0 = add i64 %_277, %_281
  %_292.1 = icmp ult i64 %_292.0, %_277
  br i1 %_292.1, label %panic31, label %bb140

bb140:                                            ; preds = %bb139
  store i64 %_292.0, ptr %_276, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_294, ptr align 8 %_276)
          to label %bb141 unwind label %cleanup30

panic31:                                          ; preds = %bb139
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_50f965bb574aafc5e48212a6fe739f63) #18
          to label %unreachable unwind label %cleanup30

unreachable:                                      ; preds = %panic31
  unreachable

bb141:                                            ; preds = %bb140
  %178 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %178, ptr align 8 %_294, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %179 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb142 unwind label %cleanup30

bb142:                                            ; preds = %bb141
  %_273.0 = extractvalue { ptr, ptr } %179, 0
  %_273.1 = extractvalue { ptr, ptr } %179, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_273.0, ptr %_273.1)
          to label %bb143 unwind label %cleanup30

bb143:                                            ; preds = %bb142
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283)
          to label %bb144 unwind label %cleanup

bb144:                                            ; preds = %bb143
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279)
  ret void

terminate:                                        ; preds = %bb147, %bb146
  %180 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb148:                                            ; preds = %bb147
  %181 = load ptr, ptr %0, align 8
  %182 = getelementptr inbounds i8, ptr %0, i64 8
  %183 = load i32, ptr %182, align 8
  %184 = insertvalue { ptr, i32 } poison, ptr %181, 0
  %185 = insertvalue { ptr, i32 } %184, i32 %183, 1
  resume { ptr, i32 } %185
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsa6wK0QGfIeE_11int_ops_i32(ptr align 8 %self) unnamed_addr #0 !guid !86 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #16
  ret i64 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsa6wK0QGfIeE_11int_ops_i32(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !87 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<i32>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE7is_noneCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %self) unnamed_addr #0 !guid !88 {
start:
; call <core::option::Option<i32>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE7is_someCsddYV2PBJW9h_3std(ptr align 4 %self) #16
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::result::Result<i32, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlNtNtNtB4_3num5error13ParseIntErrorE5is_okCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %self) unnamed_addr #0 !guid !89 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 4
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %radix) unnamed_addr #0 !guid !90 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #16
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #22
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <i32>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl10strict_powCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !91 {
start:
  %_3 = alloca [8 x i8], align 4
; call <i32>::checked_pow
  %1 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_powCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %exp) #16
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_3, align 4
  %4 = getelementptr inbounds i8, ptr %_3, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_3, align 4
  %6 = getelementptr inbounds i8, ptr %_3, i64 4
  %7 = load i32, ptr %6, align 4
  %_4 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_4 to i1
  br i1 %8, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_3, i64 4
  %x = load i32, ptr %9, align 4
  ret i32 %x

bb3:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #18
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i32>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !92 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_divCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !93 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %_5 = icmp eq i32 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i32 %self, -2147483648
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i32 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = sdiv i32 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_7, ptr %6, align 4
  store i32 1, ptr %_0, align 4
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i32, ptr %_0, align 4
  %8 = getelementptr inbounds i8, ptr %_0, i64 4
  %9 = load i32, ptr %8, align 4
  %10 = insertvalue { i32, i32 } poison, i32 %7, 0
  %11 = insertvalue { i32, i32 } %10, i32 %9, 1
  ret { i32, i32 } %11
}

; <i32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !94 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_powCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %0) unnamed_addr #0 !guid !95 {
start:
  %_57 = alloca [8 x i8], align 4
  %_48 = alloca [8 x i8], align 4
  %_38 = alloca [8 x i8], align 4
  %_32 = alloca [8 x i8], align 4
  %_13 = alloca [8 x i8], align 4
  %acc = alloca [4 x i8], align 4
  %base = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i32 %self, ptr %base, align 4
  store i32 1, ptr %acc, align 4
  %_6 = load i32, ptr %base, align 4
  %_5 = call i1 @llvm.is.constant.i32(i32 %_6)
  br i1 %_5, label %bb2, label %bb16

bb16:                                             ; preds = %bb2, %start
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp eq i32 %_24, 0
  br i1 %_23, label %bb17, label %bb18

bb2:                                              ; preds = %start
  %_9 = load i32, ptr %base, align 4
; call <i32>::unsigned_abs
  %_8 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsa6wK0QGfIeE_11int_ops_i32(i32 %_9) #16
  %_0.i.i = call i32 @llvm.ctpop.i32(i32 %_8)
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb16

bb5:                                              ; preds = %bb2
  %_12 = load i32, ptr %base, align 4
; call <i32>::unsigned_abs
  %_11 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsa6wK0QGfIeE_11int_ops_i32(i32 %_12) #16
; call <u32>::ilog2
  %k = call i32 @_RNvMs6_NtCsl10jNU3mE6R_4core3numm5ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %_11, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #16
  %_14 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %1 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %k, i32 %_14) #16
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_13, align 4
  %4 = getelementptr inbounds i8, ptr %_13, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_13, align 4
  %6 = getelementptr inbounds i8, ptr %_13, i64 4
  %7 = load i32, ptr %6, align 4
  %_15 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_15 to i1
  br i1 %8, label %bb11, label %bb10

bb18:                                             ; preds = %bb16
  %_26 = load i32, ptr %exp, align 4
  %_25 = call i1 @llvm.is.constant.i32(i32 %_26)
  br i1 %_25, label %bb20, label %bb32

bb17:                                             ; preds = %bb16
  %9 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 1, ptr %9, align 4
  store i32 1, ptr %_0, align 4
  br label %bb43

bb32:                                             ; preds = %bb42, %bb18
  %_47 = load i32, ptr %exp, align 4
  %_46 = and i32 %_47, 1
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb33, label %bb38

bb20:                                             ; preds = %bb30, %bb18
  %_28 = load i32, ptr %exp, align 4
  %_27 = icmp ugt i32 %_28, 1
  br i1 %_27, label %bb21, label %bb31

bb38:                                             ; preds = %bb36, %bb32
  %10 = load i32, ptr %exp, align 4
  %11 = udiv i32 %10, 2
  store i32 %11, ptr %exp, align 4
  %_58 = load i32, ptr %base, align 4
  %_59 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %12 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %_58, i32 %_59) #16
  %13 = extractvalue { i32, i32 } %12, 0
  %14 = extractvalue { i32, i32 } %12, 1
  store i32 %13, ptr %_57, align 4
  %15 = getelementptr inbounds i8, ptr %_57, i64 4
  store i32 %14, ptr %15, align 4
  %16 = load i32, ptr %_57, align 4
  %17 = getelementptr inbounds i8, ptr %_57, i64 4
  %18 = load i32, ptr %17, align 4
  %_60 = zext i32 %16 to i64
  %19 = trunc nuw i64 %_60 to i1
  br i1 %19, label %bb42, label %bb41

bb33:                                             ; preds = %bb32
  %_49 = load i32, ptr %acc, align 4
  %_50 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %20 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %_49, i32 %_50) #16
  %21 = extractvalue { i32, i32 } %20, 0
  %22 = extractvalue { i32, i32 } %20, 1
  store i32 %21, ptr %_48, align 4
  %23 = getelementptr inbounds i8, ptr %_48, i64 4
  store i32 %22, ptr %23, align 4
  %24 = load i32, ptr %_48, align 4
  %25 = getelementptr inbounds i8, ptr %_48, i64 4
  %26 = load i32, ptr %25, align 4
  %_51 = zext i32 %24 to i64
  %27 = trunc nuw i64 %_51 to i1
  br i1 %27, label %bb36, label %bb35

bb36:                                             ; preds = %bb33
  %28 = getelementptr inbounds i8, ptr %_48, i64 4
  %x = load i32, ptr %28, align 4
  store i32 %x, ptr %acc, align 4
  %_54 = load i32, ptr %exp, align 4
  %_53 = icmp eq i32 %_54, 1
  br i1 %_53, label %bb37, label %bb38

bb35:                                             ; preds = %bb33
  store i32 0, ptr %_0, align 4
  br label %bb43

bb43:                                             ; preds = %bb14, %bb15, %bb10, %bb17, %bb29, %bb24, %bb31, %bb37, %bb41, %bb35
  %29 = load i32, ptr %_0, align 4
  %30 = getelementptr inbounds i8, ptr %_0, i64 4
  %31 = load i32, ptr %30, align 4
  %32 = insertvalue { i32, i32 } poison, i32 %29, 0
  %33 = insertvalue { i32, i32 } %32, i32 %31, 1
  ret { i32, i32 } %33

bb37:                                             ; preds = %bb36
  %_55 = load i32, ptr %acc, align 4
  %34 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_55, ptr %34, align 4
  store i32 1, ptr %_0, align 4
  br label %bb43

bb42:                                             ; preds = %bb38
  %35 = getelementptr inbounds i8, ptr %_57, i64 4
  %x1 = load i32, ptr %35, align 4
  store i32 %x1, ptr %base, align 4
  br label %bb32

bb41:                                             ; preds = %bb38
  store i32 0, ptr %_0, align 4
  br label %bb43

bb31:                                             ; preds = %bb20
  %_43 = load i32, ptr %acc, align 4
  %_44 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %36 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %_43, i32 %_44) #16
  %37 = extractvalue { i32, i32 } %36, 0
  %38 = extractvalue { i32, i32 } %36, 1
  store i32 %37, ptr %_0, align 4
  %39 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %38, ptr %39, align 4
  br label %bb43

bb21:                                             ; preds = %bb20
  %_31 = load i32, ptr %exp, align 4
  %_30 = and i32 %_31, 1
  %_29 = icmp eq i32 %_30, 1
  br i1 %_29, label %bb22, label %bb26

bb26:                                             ; preds = %bb25, %bb21
  %40 = load i32, ptr %exp, align 4
  %41 = udiv i32 %40, 2
  store i32 %41, ptr %exp, align 4
  %_39 = load i32, ptr %base, align 4
  %_40 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %42 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %_39, i32 %_40) #16
  %43 = extractvalue { i32, i32 } %42, 0
  %44 = extractvalue { i32, i32 } %42, 1
  store i32 %43, ptr %_38, align 4
  %45 = getelementptr inbounds i8, ptr %_38, i64 4
  store i32 %44, ptr %45, align 4
  %46 = load i32, ptr %_38, align 4
  %47 = getelementptr inbounds i8, ptr %_38, i64 4
  %48 = load i32, ptr %47, align 4
  %_41 = zext i32 %46 to i64
  %49 = trunc nuw i64 %_41 to i1
  br i1 %49, label %bb30, label %bb29

bb22:                                             ; preds = %bb21
  %_33 = load i32, ptr %acc, align 4
  %_34 = load i32, ptr %base, align 4
; call <i32>::checked_mul
  %50 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %_33, i32 %_34) #16
  %51 = extractvalue { i32, i32 } %50, 0
  %52 = extractvalue { i32, i32 } %50, 1
  store i32 %51, ptr %_32, align 4
  %53 = getelementptr inbounds i8, ptr %_32, i64 4
  store i32 %52, ptr %53, align 4
  %54 = load i32, ptr %_32, align 4
  %55 = getelementptr inbounds i8, ptr %_32, i64 4
  %56 = load i32, ptr %55, align 4
  %_35 = zext i32 %54 to i64
  %57 = trunc nuw i64 %_35 to i1
  br i1 %57, label %bb25, label %bb24

bb25:                                             ; preds = %bb22
  %58 = getelementptr inbounds i8, ptr %_32, i64 4
  %x2 = load i32, ptr %58, align 4
  store i32 %x2, ptr %acc, align 4
  br label %bb26

bb24:                                             ; preds = %bb22
  store i32 0, ptr %_0, align 4
  br label %bb43

bb30:                                             ; preds = %bb26
  %59 = getelementptr inbounds i8, ptr %_38, i64 4
  %x3 = load i32, ptr %59, align 4
  store i32 %x3, ptr %base, align 4
  br label %bb20

bb29:                                             ; preds = %bb26
  store i32 0, ptr %_0, align 4
  br label %bb43

bb11:                                             ; preds = %bb5
  %60 = getelementptr inbounds i8, ptr %_13, i64 4
  %shift = load i32, ptr %60, align 4
  %_18 = load i32, ptr %base, align 4
  %_17 = icmp slt i32 %_18, 0
  br i1 %_17, label %bb12, label %bb15

bb10:                                             ; preds = %bb5
  store i32 0, ptr %_0, align 4
  br label %bb43

bb15:                                             ; preds = %bb12, %bb11
; call <i32>::shl_exact
  %61 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl9shl_exactCsa6wK0QGfIeE_11int_ops_i32(i32 1, i32 %shift) #16
  %62 = extractvalue { i32, i32 } %61, 0
  %63 = extractvalue { i32, i32 } %61, 1
  store i32 %62, ptr %_0, align 4
  %64 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %63, ptr %64, align 4
  br label %bb43

bb12:                                             ; preds = %bb11
  %_21 = load i32, ptr %exp, align 4
  %_20 = urem i32 %_21, 2
  %_19 = icmp eq i32 %_20, 1
  br i1 %_19, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
; call <i32>::shl_exact
  %65 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl9shl_exactCsa6wK0QGfIeE_11int_ops_i32(i32 -1, i32 %shift) #16
  %66 = extractvalue { i32, i32 } %65, 0
  %67 = extractvalue { i32, i32 } %65, 1
  store i32 %66, ptr %_0, align 4
  %68 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %67, ptr %68, align 4
  br label %bb43

bb9:                                              ; No predecessors!
  unreachable
}

; <i32>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_remCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !96 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %_5 = icmp eq i32 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i32 %self, -2147483648
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i32 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = srem i32 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_7, ptr %6, align 4
  store i32 1, ptr %_0, align 4
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i32, ptr %_0, align 4
  %8 = getelementptr inbounds i8, ptr %_0, i64 4
  %9 = load i32, ptr %8, align 4
  %10 = insertvalue { i32, i32 } poison, i32 %7, 0
  %11 = insertvalue { i32, i32 } %10, i32 %9, 1
  ret { i32, i32 } %11
}

; <i32>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_subCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !97 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsa6wK0QGfIeE_11int_ops_i32(i32 %self) unnamed_addr #0 !guid !98 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsa6wK0QGfIeE_11int_ops_i32(i32 %self) #16
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsa6wK0QGfIeE_11int_ops_i32(i32 %self) unnamed_addr #0 !guid !99 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <i32>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_powCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %exp) unnamed_addr #0 !guid !100 {
start:
; call <i32>::overflowing_pow
  %0 = call { i32, i1 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl15overflowing_powCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %exp) #16
  %_3.0 = extractvalue { i32, i1 } %0, 0
  %_3.1 = extractvalue { i32, i1 } %0, 1
  ret i32 %_3.0
}

; <i32>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl13checked_ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %self) unnamed_addr #0 !guid !101 {
start:
  %_0 = alloca [8 x i8], align 4
  %_2 = icmp sle i32 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_5 = call i32 @llvm.ctlz.i32(i32 %self, i1 true)
  %log = sub i32 31, %_5
  %0 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %log, ptr %0, align 4
  store i32 1, ptr %_0, align 4
  br label %bb4

bb1:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  %1 = load i32, ptr %_0, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  %3 = load i32, ptr %2, align 4
  %4 = insertvalue { i32, i32 } poison, i32 %1, 0
  %5 = insertvalue { i32, i32 } %4, i32 %3, 1
  ret { i32, i32 } %5
}

; <i32>::checked_isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl13checked_isqrtCsa6wK0QGfIeE_11int_ops_i32(i32 %self) unnamed_addr #0 !guid !102 {
start:
  %_0 = alloca [8 x i8], align 4
  %_2 = icmp slt i32 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call <u32>::isqrt
  %_4 = call i32 @_RNvMs6_NtCsl10jNU3mE6R_4core3numm5isqrtCsa6wK0QGfIeE_11int_ops_i32(i32 %self) #16
  %_7 = icmp sle i32 %_4, 46340
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb2
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i1 zeroext %_7, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #21
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb2, %bb2.i
  %0 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_4, ptr %0, align 4
  store i32 1, ptr %_0, align 4
  br label %bb7

bb1:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb1, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %1 = load i32, ptr %_0, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  %3 = load i32, ptr %2, align 4
  %4 = insertvalue { i32, i32 } poison, i32 %1, 0
  %5 = insertvalue { i32, i32 } %4, i32 %3, 1
  ret { i32, i32 } %5
}

; <i32>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unbounded_shlCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !103 {
start:
  %_0 = alloca [4 x i8], align 4
  %_3 = icmp ult i32 %rhs, 32
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_3.i, label %bb2.i, label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <i32>::unchecked_shl::precondition_check
  call void @_RNvNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i32 %rhs, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #21
  br label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %_0.i = shl i32 %self, %rhs
  store i32 %_0.i, ptr %_0, align 4
  br label %bb3

bb3:                                              ; preds = %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit, %bb2
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <i32>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i1 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl15overflowing_powCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %0) unnamed_addr #0 !guid !104 {
start:
  %_30 = alloca [8 x i8], align 4
  %base1 = alloca [4 x i8], align 4
  %_16 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [4 x i8], align 4
  %base = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i32 %self, ptr %base, align 4
  store i32 1, ptr %acc, align 4
  store i8 0, ptr %overflow, align 1
  %_8 = load i32, ptr %base, align 4
  %_7 = call i1 @llvm.is.constant.i32(i32 %_8)
  br i1 %_7, label %bb2, label %bb19

bb19:                                             ; preds = %bb2, %start
  %_33 = load i32, ptr %exp, align 4
  %_32 = icmp eq i32 %_33, 0
  br i1 %_32, label %bb20, label %bb21

bb2:                                              ; preds = %start
  %_11 = load i32, ptr %base, align 4
; call <i32>::unsigned_abs
  %_10 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsa6wK0QGfIeE_11int_ops_i32(i32 %_11) #16
  %_0.i.i = call i32 @llvm.ctpop.i32(i32 %_10)
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb19

bb5:                                              ; preds = %bb2
  %_14 = load i32, ptr %base, align 4
; call <i32>::unsigned_abs
  %_13 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsa6wK0QGfIeE_11int_ops_i32(i32 %_14) #16
; call <u32>::ilog2
  %k = call i32 @_RNvMs6_NtCsl10jNU3mE6R_4core3numm5ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %_13, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #16
  %_17 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %1 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %k, i32 %_17) #16
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_16, align 4
  %4 = getelementptr inbounds i8, ptr %_16, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_16, align 4
  %6 = getelementptr inbounds i8, ptr %_16, i64 4
  %7 = load i32, ptr %6, align 4
  %_18 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_18 to i1
  br i1 %8, label %bb9, label %bb10

bb21:                                             ; preds = %bb19
  %_35 = load i32, ptr %exp, align 4
  %_34 = call i1 @llvm.is.constant.i32(i32 %_35)
  br i1 %_34, label %bb23, label %bb32

bb20:                                             ; preds = %bb19
  store i64 1, ptr %_0, align 4
  br label %bb39

bb32:                                             ; preds = %bb36, %bb21
  %_64 = load i32, ptr %exp, align 4
  %_63 = and i32 %_64, 1
  %_62 = icmp eq i32 %_63, 1
  br i1 %_62, label %bb33, label %bb36

bb23:                                             ; preds = %bb27, %bb21
  %_37 = load i32, ptr %exp, align 4
  %_36 = icmp ugt i32 %_37, 1
  br i1 %_36, label %bb24, label %bb30

bb36:                                             ; preds = %bb33, %bb32
  %9 = load i32, ptr %exp, align 4
  %10 = udiv i32 %9, 2
  store i32 %10, ptr %exp, align 4
  %_79 = load i32, ptr %base, align 4
  %_80 = load i32, ptr %base, align 4
  %11 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_79, i32 %_80)
  %_5.0.i6 = extractvalue { i32, i1 } %11, 0
  %_5.1.i7 = extractvalue { i32, i1 } %11, 1
  %_78.0 = extractvalue { i32, i1 } %11, 0
  %_78.1 = extractvalue { i32, i1 } %11, 1
  store i32 %_78.0, ptr %base, align 4
  %12 = zext i1 %_78.1 to i8
  store i8 %12, ptr %tmp_overflow, align 1
  %13 = load i8, ptr %tmp_overflow, align 1
  %_81 = trunc nuw i8 %13 to i1
  %14 = load i8, ptr %overflow, align 1
  %15 = trunc nuw i8 %14 to i1
  %16 = or i1 %15, %_81
  %17 = zext i1 %16 to i8
  store i8 %17, ptr %overflow, align 1
  br label %bb32

bb33:                                             ; preds = %bb32
  %_68 = load i32, ptr %acc, align 4
  %_69 = load i32, ptr %base, align 4
  %18 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_68, i32 %_69)
  %_5.0.i8 = extractvalue { i32, i1 } %18, 0
  %_5.1.i9 = extractvalue { i32, i1 } %18, 1
  %_67.0 = extractvalue { i32, i1 } %18, 0
  %_67.1 = extractvalue { i32, i1 } %18, 1
  store i32 %_67.0, ptr %acc, align 4
  %19 = zext i1 %_67.1 to i8
  store i8 %19, ptr %tmp_overflow, align 1
  %20 = load i8, ptr %tmp_overflow, align 1
  %_70 = trunc nuw i8 %20 to i1
  %21 = load i8, ptr %overflow, align 1
  %22 = trunc nuw i8 %21 to i1
  %23 = or i1 %22, %_70
  %24 = zext i1 %23 to i8
  store i8 %24, ptr %overflow, align 1
  %_72 = load i32, ptr %exp, align 4
  %_71 = icmp eq i32 %_72, 1
  br i1 %_71, label %bb35, label %bb36

bb35:                                             ; preds = %bb33
  %_73 = load i32, ptr %acc, align 4
  %25 = load i8, ptr %overflow, align 1
  %_74 = trunc nuw i8 %25 to i1
  store i32 %_73, ptr %_0, align 4
  %26 = getelementptr inbounds i8, ptr %_0, i64 4
  %27 = zext i1 %_74 to i8
  store i8 %27, ptr %26, align 4
  br label %bb39

bb39:                                             ; preds = %bb10, %bb15, %bb20, %bb30, %bb35
  %28 = load i32, ptr %_0, align 4
  %29 = getelementptr inbounds i8, ptr %_0, i64 4
  %30 = load i8, ptr %29, align 4
  %31 = trunc nuw i8 %30 to i1
  %32 = insertvalue { i32, i1 } poison, i32 %28, 0
  %33 = insertvalue { i32, i1 } %32, i1 %31, 1
  ret { i32, i1 } %33

bb30:                                             ; preds = %bb23
  %_57 = load i32, ptr %acc, align 4
  %_58 = load i32, ptr %base, align 4
  %34 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_57, i32 %_58)
  %_5.0.i4 = extractvalue { i32, i1 } %34, 0
  %_5.1.i5 = extractvalue { i32, i1 } %34, 1
  %_56.0 = extractvalue { i32, i1 } %34, 0
  %_56.1 = extractvalue { i32, i1 } %34, 1
  store i32 %_56.0, ptr %acc, align 4
  %35 = zext i1 %_56.1 to i8
  store i8 %35, ptr %tmp_overflow, align 1
  %36 = load i8, ptr %tmp_overflow, align 1
  %_59 = trunc nuw i8 %36 to i1
  %37 = load i8, ptr %overflow, align 1
  %38 = trunc nuw i8 %37 to i1
  %39 = or i1 %38, %_59
  %40 = zext i1 %39 to i8
  store i8 %40, ptr %overflow, align 1
  %_60 = load i32, ptr %acc, align 4
  %41 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %41 to i1
  store i32 %_60, ptr %_0, align 4
  %42 = getelementptr inbounds i8, ptr %_0, i64 4
  %43 = zext i1 %_61 to i8
  store i8 %43, ptr %42, align 4
  br label %bb39

bb24:                                             ; preds = %bb23
  %_40 = load i32, ptr %exp, align 4
  %_39 = and i32 %_40, 1
  %_38 = icmp eq i32 %_39, 1
  br i1 %_38, label %bb25, label %bb27

bb27:                                             ; preds = %bb25, %bb24
  %44 = load i32, ptr %exp, align 4
  %45 = udiv i32 %44, 2
  store i32 %45, ptr %exp, align 4
  %_51 = load i32, ptr %base, align 4
  %_52 = load i32, ptr %base, align 4
  %46 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_51, i32 %_52)
  %_5.0.i = extractvalue { i32, i1 } %46, 0
  %_5.1.i = extractvalue { i32, i1 } %46, 1
  %_50.0 = extractvalue { i32, i1 } %46, 0
  %_50.1 = extractvalue { i32, i1 } %46, 1
  store i32 %_50.0, ptr %base, align 4
  %47 = zext i1 %_50.1 to i8
  store i8 %47, ptr %tmp_overflow, align 1
  %48 = load i8, ptr %tmp_overflow, align 1
  %_53 = trunc nuw i8 %48 to i1
  %49 = load i8, ptr %overflow, align 1
  %50 = trunc nuw i8 %49 to i1
  %51 = or i1 %50, %_53
  %52 = zext i1 %51 to i8
  store i8 %52, ptr %overflow, align 1
  br label %bb23

bb25:                                             ; preds = %bb24
  %_44 = load i32, ptr %acc, align 4
  %_45 = load i32, ptr %base, align 4
  %53 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_44, i32 %_45)
  %_5.0.i2 = extractvalue { i32, i1 } %53, 0
  %_5.1.i3 = extractvalue { i32, i1 } %53, 1
  %_43.0 = extractvalue { i32, i1 } %53, 0
  %_43.1 = extractvalue { i32, i1 } %53, 1
  store i32 %_43.0, ptr %acc, align 4
  %54 = zext i1 %_43.1 to i8
  store i8 %54, ptr %tmp_overflow, align 1
  %55 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %55 to i1
  %56 = load i8, ptr %overflow, align 1
  %57 = trunc nuw i8 %56 to i1
  %58 = or i1 %57, %_46
  %59 = zext i1 %58 to i8
  store i8 %59, ptr %overflow, align 1
  br label %bb27

bb9:                                              ; preds = %bb5
  %60 = getelementptr inbounds i8, ptr %_16, i64 4
  %shift = load i32, ptr %60, align 4
  %_21 = load i32, ptr %base, align 4
  %_20 = icmp slt i32 %_21, 0
  br i1 %_20, label %bb11, label %bb14

bb10:                                             ; preds = %bb5
  store i64 4294967296, ptr %_0, align 4
  br label %bb39

bb14:                                             ; preds = %bb11, %bb9
  store i32 1, ptr %base1, align 4
  br label %bb15

bb11:                                             ; preds = %bb9
  %_24 = load i32, ptr %exp, align 4
  %_23 = urem i32 %_24, 2
  %_22 = icmp ne i32 %_23, 0
  br i1 %_22, label %bb13, label %bb14

bb13:                                             ; preds = %bb11
  store i32 -1, ptr %base1, align 4
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_27 = load i32, ptr %base1, align 4
; call <i32>::unbounded_shl
  %_26 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unbounded_shlCsa6wK0QGfIeE_11int_ops_i32(i32 %_27, i32 %shift) #16
  %_31 = load i32, ptr %base1, align 4
; call <i32>::shl_exact
  %61 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl9shl_exactCsa6wK0QGfIeE_11int_ops_i32(i32 %_31, i32 %shift) #16
  %62 = extractvalue { i32, i32 } %61, 0
  %63 = extractvalue { i32, i32 } %61, 1
  store i32 %62, ptr %_30, align 4
  %64 = getelementptr inbounds i8, ptr %_30, i64 4
  store i32 %63, ptr %64, align 4
; call <core::option::Option<i32>>::is_none
  %_28 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE7is_noneCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %_30) #16
  store i32 %_26, ptr %_0, align 4
  %65 = getelementptr inbounds i8, ptr %_0, i64 4
  %66 = zext i1 %_28 to i8
  store i8 %66, ptr %65, align 4
  br label %bb39

bb40:                                             ; No predecessors!
  unreachable
}

; <i32>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl3powCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %exp) unnamed_addr #0 !guid !105 {
start:
  %_0 = alloca [4 x i8], align 4
  br label %bb1

bb1:                                              ; preds = %start
; call <i32>::strict_pow
  %0 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl10strict_powCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %exp, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #16
  store i32 %0, ptr %_0, align 4
  br label %bb3

bb2:                                              ; No predecessors!
; call <i32>::wrapping_pow
  %1 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_powCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %exp) #16
  store i32 %1, ptr %_0, align 4
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i32, ptr %_0, align 4
  ret i32 %2
}

; <i32>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl5ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %self, ptr align 8 %0) unnamed_addr #0 !guid !106 {
start:
  %_2 = alloca [8 x i8], align 4
; call <i32>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl13checked_ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %self) #16
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #18
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i32>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl5isqrtCsa6wK0QGfIeE_11int_ops_i32(i32 %self, ptr align 8 %0) unnamed_addr #0 !guid !107 {
start:
  %_2 = alloca [8 x i8], align 4
; call <i32>::checked_isqrt
  %1 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl13checked_isqrtCsa6wK0QGfIeE_11int_ops_i32(i32 %self) #16
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %sqrt = load i32, ptr %9, align 4
  ret i32 %sqrt

bb3:                                              ; preds = %start
; call core::num::imp::int_sqrt::panic_for_negative_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8 %0) #18
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i32>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl8abs_diffCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %other) unnamed_addr #0 !guid !108 {
start:
  %_0 = alloca [4 x i8], align 4
  %_3 = icmp slt i32 %self, %other
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_0.i1 = sub i32 %self, %other
  store i32 %_0.i1, ptr %_0, align 4
  br label %bb3

bb1:                                              ; preds = %start
  %_0.i = sub i32 %other, %self
  store i32 %_0.i, ptr %_0, align 4
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <i32>::shl_exact
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl9shl_exactCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !109 {
start:
  %_0 = alloca [8 x i8], align 4
  %_0.i4 = call i32 @llvm.ctlz.i32(i32 %self, i1 false)
  %_3 = icmp ult i32 %rhs, %_0.i4
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_2.i = xor i32 %self, -1
  %_0.i = call i32 @llvm.ctlz.i32(i32 %_2.i, i1 false)
  %_5 = icmp ult i32 %rhs, %_0.i
  br i1 %_5, label %bb4, label %bb6

bb4:                                              ; preds = %bb2, %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_3.i, label %bb2.i, label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

bb2.i:                                            ; preds = %bb4
; call <i32>::unchecked_shl::precondition_check
  call void @_RNvNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i32 %rhs, ptr align 8 @alloc_321cb53071ed634b0d814fda86198fe8) #21
  br label %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit

_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit: ; preds = %bb4, %bb2.i
  %_0.i2 = shl i32 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_0.i2, ptr %0, align 4
  store i32 1, ptr %_0, align 4
  br label %bb7

bb6:                                              ; preds = %bb2
  store i32 0, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %_RNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl.exit, %bb6
  %1 = load i32, ptr %_0, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  %3 = load i32, ptr %2, align 4
  %4 = insertvalue { i32, i32 } poison, i32 %1, 0
  %5 = insertvalue { i32, i32 } %4, i32 %3, 1
  ret { i32, i32 } %5
}

; <core::ptr::non_null::NonNull<core::option::Option<i32>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionlEE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %r) unnamed_addr #0 !guid !110 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %r) unnamed_addr #0 !guid !111 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<(i32, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTlbEE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %r) unnamed_addr #0 !guid !112 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr %r) unnamed_addr #0 !guid !113 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 8 %r) unnamed_addr #0 !guid !114 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %r) unnamed_addr #0 !guid !115 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsa6wK0QGfIeE_11int_ops_i32(ptr align 8 %self) unnamed_addr #0 !guid !116 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #16
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsa6wK0QGfIeE_11int_ops_i32(ptr %_7.0, i64 %_7.1) #16
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsa6wK0QGfIeE_11int_ops_i32(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !117 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsa6wK0QGfIeE_11int_ops_i32(ptr %s.0, i64 %s.1) #16
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %self, i32 %rhs) unnamed_addr #0 !guid !118 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u32>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm13checked_ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %self) unnamed_addr #0 !guid !119 {
start:
  %_2 = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u32>>::new
  %0 = call i32 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE3newB9_(i32 %self) #16
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
  %2 = icmp eq i32 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i32, ptr %_2, align 4
; call <core::num::nonzero::NonZero<u32>>::ilog2
  %_5 = call i32 @_RNvMsU_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE5ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %x) #16
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u32>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs6_NtCsl10jNU3mE6R_4core3numm5ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %self, ptr align 8 %0) unnamed_addr #0 !guid !120 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u32>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm13checked_ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %self) #16
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #18
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u32>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs6_NtCsl10jNU3mE6R_4core3numm5isqrtCsa6wK0QGfIeE_11int_ops_i32(i32 %self) unnamed_addr #0 !guid !121 {
start:
; call core::num::imp::int_sqrt::u32
  %result = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32Csa6wK0QGfIeE_11int_ops_i32(i32 %self) #16
  %_3 = icmp ule i32 %result, 65535
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i1 zeroext %_3, ptr align 8 @alloc_214c36c067ac462f6ec22f6fcbcc1f6d) #21
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i32 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_3.i, label %bb2.i, label %_RNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u32>::unchecked_mul::precondition_check
  call void @_RNvNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_mul18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i32 %result, i32 %result, ptr align 8 @alloc_214c36c067ac462f6ec22f6fcbcc1f6d) #21
  br label %_RNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_mul.exit

_RNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i32 %result, %result
  %_8 = icmp ule i32 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i1 zeroext %_8, ptr align 8 @alloc_214c36c067ac462f6ec22f6fcbcc1f6d) #21
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i32 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i1 zeroext %_11, ptr align 8 @alloc_214c36c067ac462f6ec22f6fcbcc1f6d) #21
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i32 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i32 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i1 zeroext %_6, ptr align 8 @alloc_214c36c067ac462f6ec22f6fcbcc1f6d) #21
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csa6wK0QGfIeE_11int_ops_i32(ptr %self) unnamed_addr #0 !guid !122 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csa6wK0QGfIeE_11int_ops_i32(i8 %0) unnamed_addr #0 !guid !123 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csa6wK0QGfIeE_11int_ops_i32(ptr %self) #16
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u32>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsU_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE13leading_zerosCsa6wK0QGfIeE_11int_ops_i32(i32 %self) unnamed_addr #0 !guid !124 {
start:
; call <core::num::nonzero::NonZero<u32>>::get
  %_2 = call i32 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE3getB9_(i32 %self) #16
  %_0 = call i32 @llvm.ctlz.i32(i32 %_2, i1 true)
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u32>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsU_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE5ilog2Csa6wK0QGfIeE_11int_ops_i32(i32 %self) unnamed_addr #0 !guid !125 {
start:
; call <core::num::nonzero::NonZero<u32>>::leading_zeros
  %_3 = call i32 @_RNvMsU_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE13leading_zerosCsa6wK0QGfIeE_11int_ops_i32(i32 %self) #16
  %_0 = sub i32 31, %_3
  ret i32 %_0
}

; <i32>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl14from_str_radixCsa6wK0QGfIeE_11int_ops_i32(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !126 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
  %1 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %2, 0
  %_3.1 = extractvalue { ptr, i64 } %2, 1
; call <i32>::from_ascii_bytes_radix_impl
  %3 = call i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl27from_ascii_bytes_radix_implCsa6wK0QGfIeE_11int_ops_i32(ptr %_3.0, i64 %_3.1, i32 %radix) #16
  store i64 %3, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %4 = load i64, ptr %_0, align 4
  ret i64 %4
}

; <i32>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl27from_ascii_bytes_radix_implCsa6wK0QGfIeE_11int_ops_i32(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !127 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [8 x i8], align 4
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [8 x i8], align 4
  %_74 = alloca [8 x i8], align 4
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [8 x i8], align 4
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [4 x i8], align 4
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #22
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #16
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i64, ptr %_0, align 4
  ret i64 %4

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %5 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  store i64 %src.1, ptr %6, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %7 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %8 = load i8, ptr %7, align 1
  switch i8 %8, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %9 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %rest.1, ptr %10, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %11 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %12 = sub i64 %src.1, 1
  store ptr %11, ptr %rest, align 8
  %13 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %12, ptr %13, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %14 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %14 to i1
  %15 = getelementptr inbounds i8, ptr %_12, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = getelementptr inbounds i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  store ptr %16, ptr %digits, align 8, !captures !128
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %18, ptr %19, align 8
  store i32 0, ptr %result, align 4
  %_24.0 = load ptr, ptr %digits, align 8
  %20 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %20, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsa6wK0QGfIeE_11int_ops_i32.exit

bb1.i:                                            ; preds = %bb15
  %21 = icmp ule i64 %_24.1, 7
  %22 = zext i1 %21 to i8
  store i8 %22, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsa6wK0QGfIeE_11int_ops_i32.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsa6wK0QGfIeE_11int_ops_i32.exit: ; preds = %bb2.i, %bb1.i
  %23 = load i8, ptr %_0.i, align 1
  %24 = trunc nuw i8 %23 to i1
  br i1 %24, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %25 = load ptr, ptr %rest, align 8
  %26 = getelementptr inbounds i8, ptr %rest, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %25, ptr %28, align 8
  %29 = getelementptr inbounds i8, ptr %28, i64 8
  store i64 %27, ptr %29, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsa6wK0QGfIeE_11int_ops_i32.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowlECsa6wK0QGfIeE_11int_ops_i32.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %30 = load ptr, ptr %digits, align 8
  %31 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %31, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %32 = load ptr, ptr %digits, align 8
  %33 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %33, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i32, ptr %result, align 4
  %34 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_105, ptr %34, align 4
  store i8 0, ptr %_0, align 4
  br label %bb53

bb42:                                             ; preds = %bb41
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %37 = load i64, ptr %36, align 8
  %c = getelementptr inbounds nuw i8, ptr %35, i64 0
  %38 = load ptr, ptr %digits, align 8
  %39 = getelementptr inbounds i8, ptr %digits, i64 8
  %40 = load i64, ptr %39, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %38, i64 1
  %rest.13 = sub i64 %40, 1
  %_85 = load i32, ptr %result, align 4
; call <i32>::checked_mul
  %41 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %_85, i32 %radix) #16
  %42 = extractvalue { i32, i32 } %41, 0
  %43 = extractvalue { i32, i32 } %41, 1
  store i32 %42, ptr %mul1, align 4
  %44 = getelementptr inbounds i8, ptr %mul1, i64 4
  store i32 %43, ptr %44, align 4
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %45 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsa6wK0QGfIeE_11int_ops_i32(i32 %_89, i32 %radix) #16
  %46 = extractvalue { i32, i32 } %45, 0
  %47 = extractvalue { i32, i32 } %45, 1
  store i32 %46, ptr %_88, align 4
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %47, ptr %48, align 4
  %49 = load i32, ptr %_88, align 4
  %50 = getelementptr inbounds i8, ptr %_88, i64 4
  %51 = load i32, ptr %50, align 4
  %_91 = zext i32 %49 to i64
  %52 = trunc nuw i64 %_91 to i1
  br i1 %52, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %53, align 4
  %54 = load i32, ptr %mul1, align 4
  %55 = getelementptr inbounds i8, ptr %mul1, i64 4
  %56 = load i32, ptr %55, align 4
  %_95 = zext i32 %54 to i64
  %57 = trunc nuw i64 %_95 to i1
  br i1 %57, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %58 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %58, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb48:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %mul1, i64 4
  %value4 = load i32, ptr %59, align 4
  store i32 %value4, ptr %result, align 4
  %_100 = load i32, ptr %result, align 4
; call <i32>::checked_sub
  %60 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_subCsa6wK0QGfIeE_11int_ops_i32(i32 %_100, i32 %value) #16
  %61 = extractvalue { i32, i32 } %60, 0
  %62 = extractvalue { i32, i32 } %60, 1
  store i32 %61, ptr %_99, align 4
  %63 = getelementptr inbounds i8, ptr %_99, i64 4
  store i32 %62, ptr %63, align 4
  %64 = load i32, ptr %_99, align 4
  %65 = getelementptr inbounds i8, ptr %_99, i64 4
  %66 = load i32, ptr %65, align 4
  %_101 = zext i32 %64 to i64
  %67 = trunc nuw i64 %_101 to i1
  br i1 %67, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %68 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %68, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb51:                                             ; preds = %bb48
  %69 = getelementptr inbounds i8, ptr %_99, i64 4
  %value5 = load i32, ptr %69, align 4
  store i32 %value5, ptr %result, align 4
  store ptr %rest.02, ptr %digits, align 8, !captures !128
  %70 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %70, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %71 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %71, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb31:                                             ; preds = %bb30
  %72 = load ptr, ptr %digits, align 8
  %73 = getelementptr inbounds i8, ptr %digits, i64 8
  %74 = load i64, ptr %73, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %72, i64 0
  %75 = load ptr, ptr %digits, align 8
  %76 = getelementptr inbounds i8, ptr %digits, i64 8
  %77 = load i64, ptr %76, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %75, i64 1
  %rest.18 = sub i64 %77, 1
  %_60 = load i32, ptr %result, align 4
; call <i32>::checked_mul
  %78 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_mulCsa6wK0QGfIeE_11int_ops_i32(i32 %_60, i32 %radix) #16
  %79 = extractvalue { i32, i32 } %78, 0
  %80 = extractvalue { i32, i32 } %78, 1
  store i32 %79, ptr %mul, align 4
  %81 = getelementptr inbounds i8, ptr %mul, i64 4
  store i32 %80, ptr %81, align 4
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %82 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsa6wK0QGfIeE_11int_ops_i32(i32 %_64, i32 %radix) #16
  %83 = extractvalue { i32, i32 } %82, 0
  %84 = extractvalue { i32, i32 } %82, 1
  store i32 %83, ptr %_63, align 4
  %85 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %84, ptr %85, align 4
  %86 = load i32, ptr %_63, align 4
  %87 = getelementptr inbounds i8, ptr %_63, i64 4
  %88 = load i32, ptr %87, align 4
  %_66 = zext i32 %86 to i64
  %89 = trunc nuw i64 %_66 to i1
  br i1 %89, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %90 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %90, align 4
  %91 = load i32, ptr %mul, align 4
  %92 = getelementptr inbounds i8, ptr %mul, i64 4
  %93 = load i32, ptr %92, align 4
  %_70 = zext i32 %91 to i64
  %94 = trunc nuw i64 %_70 to i1
  br i1 %94, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %95 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %95, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb37:                                             ; preds = %bb35
  %96 = getelementptr inbounds i8, ptr %mul, i64 4
  %value10 = load i32, ptr %96, align 4
  store i32 %value10, ptr %result, align 4
  %_75 = load i32, ptr %result, align 4
; call <i32>::checked_add
  %97 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl11checked_addCsa6wK0QGfIeE_11int_ops_i32(i32 %_75, i32 %value9) #16
  %98 = extractvalue { i32, i32 } %97, 0
  %99 = extractvalue { i32, i32 } %97, 1
  store i32 %98, ptr %_74, align 4
  %100 = getelementptr inbounds i8, ptr %_74, i64 4
  store i32 %99, ptr %100, align 4
  %101 = load i32, ptr %_74, align 4
  %102 = getelementptr inbounds i8, ptr %_74, i64 4
  %103 = load i32, ptr %102, align 4
  %_76 = zext i32 %101 to i64
  %104 = trunc nuw i64 %_76 to i1
  br i1 %104, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %105 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %105, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb40:                                             ; preds = %bb37
  %106 = getelementptr inbounds i8, ptr %_74, i64 4
  %value11 = load i32, ptr %106, align 4
  store i32 %value11, ptr %result, align 4
  store ptr %rest.07, ptr %digits, align 8, !captures !128
  %107 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %107, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %108 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %108, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %109 = load ptr, ptr %digits, align 8
  %110 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %110, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %111 = load ptr, ptr %digits, align 8
  %112 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %112, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %113 = load ptr, ptr %digits, align 8
  %114 = getelementptr inbounds i8, ptr %digits, i64 8
  %115 = load i64, ptr %114, align 8
  %c12 = getelementptr inbounds nuw i8, ptr %113, i64 0
  %116 = load ptr, ptr %digits, align 8
  %117 = getelementptr inbounds i8, ptr %digits, i64 8
  %118 = load i64, ptr %117, align 8
  %rest.013 = getelementptr inbounds nuw i8, ptr %116, i64 1
  %rest.114 = sub i64 %118, 1
  %_44 = load i32, ptr %result, align 4
  %119 = mul i32 %_44, %radix
  store i32 %119, ptr %result, align 4
  %_48 = load i8, ptr %c12, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %120 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsa6wK0QGfIeE_11int_ops_i32(i32 %_47, i32 %radix) #16
  %121 = extractvalue { i32, i32 } %120, 0
  %122 = extractvalue { i32, i32 } %120, 1
  store i32 %121, ptr %_46, align 4
  %123 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %122, ptr %123, align 4
  %124 = load i32, ptr %_46, align 4
  %125 = getelementptr inbounds i8, ptr %_46, i64 4
  %126 = load i32, ptr %125, align 4
  %_49 = zext i32 %124 to i64
  %127 = trunc nuw i64 %_49 to i1
  br i1 %127, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %128 = getelementptr inbounds i8, ptr %_46, i64 4
  %x = load i32, ptr %128, align 4
  %_53 = load i32, ptr %result, align 4
  %129 = sub i32 %_53, %x
  store i32 %129, ptr %result, align 4
  store ptr %rest.013, ptr %digits, align 8, !captures !128
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.114, ptr %130, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %131 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %131, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb19:                                             ; preds = %bb18
  %132 = load ptr, ptr %digits, align 8
  %133 = getelementptr inbounds i8, ptr %digits, i64 8
  %134 = load i64, ptr %133, align 8
  %c15 = getelementptr inbounds nuw i8, ptr %132, i64 0
  %135 = load ptr, ptr %digits, align 8
  %136 = getelementptr inbounds i8, ptr %digits, i64 8
  %137 = load i64, ptr %136, align 8
  %rest.016 = getelementptr inbounds nuw i8, ptr %135, i64 1
  %rest.117 = sub i64 %137, 1
  %_29 = load i32, ptr %result, align 4
  %138 = mul i32 %_29, %radix
  store i32 %138, ptr %result, align 4
  %_33 = load i8, ptr %c15, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %139 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsa6wK0QGfIeE_11int_ops_i32(i32 %_32, i32 %radix) #16
  %140 = extractvalue { i32, i32 } %139, 0
  %141 = extractvalue { i32, i32 } %139, 1
  store i32 %140, ptr %_31, align 4
  %142 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %141, ptr %142, align 4
  %143 = load i32, ptr %_31, align 4
  %144 = getelementptr inbounds i8, ptr %_31, i64 4
  %145 = load i32, ptr %144, align 4
  %_34 = zext i32 %143 to i64
  %146 = trunc nuw i64 %_34 to i1
  br i1 %146, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %147 = getelementptr inbounds i8, ptr %_31, i64 4
  %x18 = load i32, ptr %147, align 4
  %_38 = load i32, ptr %result, align 4
  %148 = add i32 %_38, %x18
  store i32 %148, ptr %result, align 4
  store ptr %rest.016, ptr %digits, align 8, !captures !128
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.117, ptr %149, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %150 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %150, align 1
  store i8 1, ptr %_0, align 4
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsa6wK0QGfIeE_11int_ops_i32(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !129 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsa6wK0QGfIeE_11int_ops_i32(ptr align 8 %args) #16
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #16
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsa6wK0QGfIeE_11int_ops_i32() unnamed_addr #4 !guid !130 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() unnamed_addr #0 !guid !131 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsa6wK0QGfIeE_11int_ops_i32(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !132 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::num::imp::int_sqrt::u16_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsa6wK0QGfIeE_11int_ops_i32(i16 %n) unnamed_addr #0 !guid !133 {
start:
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n1 = lshr i16 %n, 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.a284940029756418f450b23cf5472523.0, i64 512, i1 false)
  %_9 = zext i16 %n1 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s2 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s2, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i1 zeroext %_12, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #21
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb1, %bb2.i
  %lo = and i16 %n, 255
  %_16 = zext i8 %r to i16
  %_15 = shl i16 %_16, 4
  %_17 = lshr i16 %lo, 4
  %numerator = or i16 %_15, %_17
  %_19 = zext i8 %s2 to i16
  %denominator = shl i16 %_19, 1
  %_21 = icmp eq i16 %denominator, 0
  br i1 %_21, label %panic3, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #22
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q = udiv i16 %numerator, %denominator
  %_24 = shl i8 %s2, 4
  %_23 = zext i8 %_24 to i16
  %3 = add i16 %_23, %q
  store i16 %3, ptr %s, align 2
  %_28 = load i16, ptr %s, align 2
  %_29 = load i16, ptr %s, align 2
  %4 = call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %_28, i16 %_29)
  %_5.0.i = extractvalue { i16, i1 } %4, 0
  %_5.1.i = extractvalue { i16, i1 } %4, 1
  %_27.0 = extractvalue { i16, i1 } %4, 0
  %_27.1 = extractvalue { i16, i1 } %4, 1
  br i1 %_27.1, label %bb6, label %bb5

panic3:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_73a63def61abd19c5b285b7e5bba6f74) #22
  unreachable

bb5:                                              ; preds = %bb3
  %_30 = icmp ugt i16 %_27.0, %n
  br i1 %_30, label %bb6, label %bb7

bb6:                                              ; preds = %bb5, %bb3
  %5 = load i16, ptr %s, align 2
  %6 = sub i16 %5, 1
  store i16 %6, ptr %s, align 2
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5
  %_0 = load i16, ptr %s, align 2
  ret i16 %_0
}

; core::num::imp::int_sqrt::u32_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsa6wK0QGfIeE_11int_ops_i32(i32 %n) unnamed_addr #0 !guid !134 {
start:
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n2 = lshr i32 %n, 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.a284940029756418f450b23cf5472523.0, i64 512, i1 false)
  %_9 = zext i32 %n2 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s3 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r4 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s3, 0
; call core::ub_checks::check_language_ub
  %_2.i15 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_2.i15, label %bb2.i16, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

bb2.i16:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i1 zeroext %_12, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #21
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17: ; preds = %bb1, %bb2.i16
  %_17 = lshr i32 %n, 16
  %n5 = trunc i32 %_17 to i16
  %lo = and i16 %n5, 255
  %_21 = zext i8 %r4 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s3 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic6, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #22
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic7, label %bb4

panic6:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #22
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s3, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic7:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #22
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsa6wK0QGfIeE_11int_ops_i32() #16
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i1 zeroext %_45, ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #21
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb8, %bb2.i
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %lo8 = and i32 %n, 65535
  %_52 = zext i16 %_48 to i32
  %_51 = shl i32 %_52, 8
  %_53 = lshr i32 %lo8, 8
  %numerator9 = or i32 %_51, %_53
  %_55 = zext i16 %_47 to i32
  %denominator10 = shl i32 %_55, 1
  %_57 = icmp eq i32 %denominator10, 0
  br i1 %_57, label %panic11, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q12 = udiv i32 %numerator9, %denominator10
  %_60 = shl i16 %_47, 8
  %_59 = zext i16 %_60 to i32
  %8 = add i32 %_59, %q12
  store i32 %8, ptr %s1, align 4
  %_64 = load i32, ptr %s1, align 4
  %_65 = load i32, ptr %s1, align 4
  %9 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_64, i32 %_65)
  %_5.0.i13 = extractvalue { i32, i1 } %9, 0
  %_5.1.i14 = extractvalue { i32, i1 } %9, 1
  %_63.0 = extractvalue { i32, i1 } %9, 0
  %_63.1 = extractvalue { i32, i1 } %9, 1
  br i1 %_63.1, label %bb13, label %bb12

panic11:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_d1e64d3a180065bd6a022925cad00717) #22
  unreachable

bb12:                                             ; preds = %bb10
  %_66 = icmp ugt i32 %_63.0, %n
  br i1 %_66, label %bb13, label %bb14

bb13:                                             ; preds = %bb12, %bb10
  %10 = load i32, ptr %s1, align 4
  %11 = sub i32 %10, 1
  store i32 %11, ptr %s1, align 4
  br label %bb14

bb14:                                             ; preds = %bb13, %bb12
  %_0 = load i32, ptr %s1, align 4
  ret i32 %_0
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8Csa6wK0QGfIeE_11int_ops_i32(i8 %n) unnamed_addr #0 !guid !135 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.a284940029756418f450b23cf5472523.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #22
  unreachable
}

; core::num::imp::int_sqrt::u16
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16Csa6wK0QGfIeE_11int_ops_i32(i16 %0) unnamed_addr #0 !guid !136 {
start:
  %_0 = alloca [2 x i8], align 2
  %n = alloca [2 x i8], align 2
  store i16 %0, ptr %n, align 2
  %_3 = load i16, ptr %n, align 2
  %_2 = icmp ule i16 %_3, 255
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i16, ptr %n, align 2
  %1 = call i16 @llvm.ctlz.i16(i16 %_10, i1 false)
  %_0.i = zext i16 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i16, ptr %n, align 2
  %3 = and i32 %normalization_shift, 15
  %4 = trunc i32 %3 to i16
  %5 = shl i16 %2, %4
  store i16 %5, ptr %n, align 2
  %_12 = load i16, ptr %n, align 2
; call core::num::imp::int_sqrt::u16_stages
  %s = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsa6wK0QGfIeE_11int_ops_i32(i16 %_12) #16
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 15
  %7 = trunc i32 %6 to i16
  %8 = lshr i16 %s, %7
  store i16 %8, ptr %_0, align 2
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i16, ptr %n, align 2
  %_6 = trunc i16 %_7 to i8
; call core::num::imp::int_sqrt::u8
  %_5 = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8Csa6wK0QGfIeE_11int_ops_i32(i8 %_6) #16
  %9 = zext i8 %_5 to i16
  store i16 %9, ptr %_0, align 2
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i16, ptr %_0, align 2
  ret i16 %10
}

; core::num::imp::int_sqrt::u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32Csa6wK0QGfIeE_11int_ops_i32(i32 %0) unnamed_addr #0 !guid !137 {
start:
  %_0 = alloca [4 x i8], align 4
  %n = alloca [4 x i8], align 4
  store i32 %0, ptr %n, align 4
  %_3 = load i32, ptr %n, align 4
  %_2 = icmp ule i32 %_3, 65535
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i32, ptr %n, align 4
  %_0.i = call i32 @llvm.ctlz.i32(i32 %_10, i1 false)
  %normalization_shift = and i32 %_0.i, -2
  %1 = load i32, ptr %n, align 4
  %2 = and i32 %normalization_shift, 31
  %3 = shl i32 %1, %2
  store i32 %3, ptr %n, align 4
  %_12 = load i32, ptr %n, align 4
; call core::num::imp::int_sqrt::u32_stages
  %s = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsa6wK0QGfIeE_11int_ops_i32(i32 %_12) #16
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %4 = and i32 %denormalization_shift, 31
  %5 = lshr i32 %s, %4
  store i32 %5, ptr %_0, align 4
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i32, ptr %n, align 4
  %_6 = trunc i32 %_7 to i16
; call core::num::imp::int_sqrt::u16
  %_5 = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16Csa6wK0QGfIeE_11int_ops_i32(i16 %_6) #16
  %6 = zext i16 %_5 to i32
  store i32 %6, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %7 = load i32, ptr %_0, align 4
  ret i32 %7
}

; <i32>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shl18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !138 {
start:
  %_2 = icmp ult i32 %rhs, 32
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_eea3b4108fd45221c9468d112de34f4d, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; <i32>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs0_NtCsl10jNU3mE6R_4core3numl13unchecked_shr18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !139 {
start:
  %_2 = icmp ult i32 %rhs, 32
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_51faf7dcdededcddf8ff69cfb939d83f, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; <u32>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_mul18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i32 %lhs, i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !140 {
start:
  %1 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %lhs, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %1, 0
  %_5.1.i = extractvalue { i32, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i32, i1 } %1, 0
  %_4.1 = extractvalue { i32, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_43d9f86d1bad35544b007cb40d6affed, i64 184)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsa6wK0QGfIeE_11int_ops_i32(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !141 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsa6wK0QGfIeE_11int_ops_i32(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsa6wK0QGfIeE_11int_ops_i32() unnamed_addr #0 !guid !142 {
start:
  ret i1 true
}

; <(i32, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTlbENtB6_5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !143 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 4
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !144 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32(ptr %_3, ptr align 8 %f) #16
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !145 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32(ptr %_3, ptr align 8 %f) #16
  ret i1 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsa6wK0QGfIeE_11int_ops_i32() unnamed_addr #0 !guid !146 {
start:
  ret i8 0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !147 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !148 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <i32 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXso_NtCsl10jNU3mE6R_4core3numlNtNtNtB7_3str6traits7FromStr8from_strCsa6wK0QGfIeE_11int_ops_i32(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !149 {
start:
  %0 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <i32>::from_str_radix
  %1 = call i64 @_RNvMsp_NtCsl10jNU3mE6R_4core3numl14from_str_radixCsa6wK0QGfIeE_11int_ops_i32(ptr %src.0, i64 %src.1, i32 10) #16
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %0, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <core::result::Result<i32, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultlNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsa6wK0QGfIeE_11int_ops_i32(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !150 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 4
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 4
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsa6wK0QGfIeE_11int_ops_i32(ptr %_1) unnamed_addr #0 !guid !151 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsa6wK0QGfIeE_11int_ops_i32(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !152 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csa6wK0QGfIeE_11int_ops_i32(ptr align 8 %_1) #16
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <core::ptr::non_null::NonNull<i32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refB9_(ptr align 4) unnamed_addr #0

; <core::ptr::non_null::NonNull<i32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuEBa_(ptr) unnamed_addr #0

; <i32 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsr_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_6Binary3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <core::option::Option<i32> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionlENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std(ptr align 4, ptr align 8) unnamed_addr #0

; <i32 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXst_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Octal3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshl.i32(i32, i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshr.i32(i32, i32, i32) #9

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_lower_hex::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexlECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptosi.sat.i32.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <i32 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringlNtB5_8ToString9to_stringCsddYV2PBJW9h_3std(ptr sret([24 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; <core::option::Option<i32>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE7is_someCsddYV2PBJW9h_3std(ptr align 4) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #10

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #11

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.sadd.sat.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ssub.sat.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32) #9

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #10

; core::num::imp::int_sqrt::panic_for_negative_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8) unnamed_addr #10

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctlz.i16(i16, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.umul.with.overflow.i16(i16, i16) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctpop.i32(i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bitreverse.i32(i32) #9

; <core::num::nonzero::NonZero<u32>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i32 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE3newB9_(i32) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.cttz.i32(i32, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; <core::num::nonzero::NonZero<u32>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i32 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeromE3getB9_(i32) unnamed_addr #0

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #13

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #14

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #15 !guid !153 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsa6wK0QGfIeE_11int_ops_i32(ptr @_RNvCsa6wK0QGfIeE_11int_ops_i324main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #12 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nonlazybind "target-cpu"="x86-64" }
attributes #16 = { inlinehint }
attributes #17 = { cold noreturn nounwind }
attributes #18 = { noreturn }
attributes #19 = { noinline }
attributes #20 = { nounwind }
attributes #21 = { inlinehint nounwind }
attributes #22 = { noinline noreturn }
attributes #23 = { cold }
attributes #24 = { noinline noreturn nounwind }

!llvm.module.flags = !{!50, !51, !52, !53}
!llvm.ident = !{!54}

!0 = !{i64 -3073635160440227542}
!1 = !{i64 -3271945298400772116}
!2 = !{i64 3777104629545720516}
!3 = !{i64 5279506800985304769}
!4 = !{i64 -3675664483830617346}
!5 = !{i64 -2693192529592142744}
!6 = !{i64 -7996235817080939961}
!7 = !{i64 -8447791659425690335}
!8 = !{i64 3783212222971967704}
!9 = !{i64 -8425032672922634311}
!10 = !{i64 7009987819485490469}
!11 = !{i64 706956806827732872}
!12 = !{i64 3058005536428136572}
!13 = !{i64 -5625404329537752805}
!14 = !{i64 6568660896061367204}
!15 = !{i64 5226218147670942298}
!16 = !{i64 2494137437542496166}
!17 = !{i64 8337570570743820333}
!18 = !{i64 -4483803892271232436}
!19 = !{i64 -5643347699813492382}
!20 = !{i64 -2145737474827648724}
!21 = !{i64 6584424647585278805}
!22 = !{i64 -3195208287023485668}
!23 = !{i64 -7199238199900815322}
!24 = !{i64 -3949050392038189934}
!25 = !{i64 7778201478205920241}
!26 = !{i64 -3859714808090686041}
!27 = !{i64 2827475969889883750}
!28 = !{i64 -2308981125680727935}
!29 = !{i64 379748877234012283}
!30 = !{i64 -2282668064055702300}
!31 = !{i64 3201983224474684316}
!32 = !{i64 4646086790858649965}
!33 = !{i64 -7945424498840118540}
!34 = !{i64 -2161453455496831009}
!35 = !{i64 -1666928910016922308}
!36 = !{i64 -8629574135722216670}
!37 = !{i64 3974843203089313446}
!38 = !{i64 6788478623678398291}
!39 = !{i64 -8488136430611188909}
!40 = !{i64 -619556746825807384}
!41 = !{i64 3277942682677848634}
!42 = !{i64 -5511425934616161149}
!43 = !{i64 8981976411294709540}
!44 = !{i64 -5047161751108934436}
!45 = !{i64 -757488778492744466}
!46 = !{i64 6062197922836268281}
!47 = !{i64 -4505812039510727930}
!48 = !{i64 2891416040889648063}
!49 = !{i64 1861349527156895491}
!50 = !{i32 8, !"PIC Level", i32 2}
!51 = !{i32 7, !"PIE Level", i32 2}
!52 = !{i32 2, !"RtLibUseGOT", i32 1}
!53 = !{i32 7, !"uwtable", i32 2}
!54 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!55 = !{i64 -4158993036998609454}
!56 = !{i64 2783146897852614935}
!57 = !{i64 -3729987709667228476}
!58 = !{i64 5290717778546361362}
!59 = !{i64 -7567393383161048568}
!60 = !{i64 -963528396407175209}
!61 = !{i64 -628823283819096016}
!62 = !{i64 5268837502057698933}
!63 = !{i64 -6709738470319553110}
!64 = !{i64 4254087712286777834}
!65 = !{i64 -5369172315380337049}
!66 = !{i64 -2229155617684013129}
!67 = !{i64 -668972713592026409}
!68 = !{i64 5242707730576048281}
!69 = !{i64 -6088854142086926638}
!70 = !{i64 4182270928044993310}
!71 = !{i64 -678254723927829111}
!72 = !{i64 -8367407583986445613}
!73 = !{i64 -5511270038173736628}
!74 = !{i64 5541802894193787184}
!75 = !{i64 6802047872679251440}
!76 = !{i64 -8707586892405442315}
!77 = !{i64 5645870400180596967}
!78 = !{i64 -1555035191955835332}
!79 = !{i64 7589877885515271882}
!80 = !{i64 1318421816192758}
!81 = !{i64 4762191114785033493}
!82 = !{i64 4864726712944524973}
!83 = !{i64 4909490842485189887}
!84 = !{i64 -3139122589863032836}
!85 = !{i64 5462534796519081133}
!86 = !{i64 -766593560716647552}
!87 = !{i64 8754107663930308809}
!88 = !{i64 2465292833279153486}
!89 = !{i64 -6205567100908211573}
!90 = !{i64 2973712758734003492}
!91 = !{i64 5073664767130498010}
!92 = !{i64 -5646820198019475305}
!93 = !{i64 -2519282845711648118}
!94 = !{i64 -4970525716667617719}
!95 = !{i64 -8802579063011355835}
!96 = !{i64 -7404603323894315331}
!97 = !{i64 -3399368340205888088}
!98 = !{i64 6290168268694353144}
!99 = !{i64 -3978498849952606172}
!100 = !{i64 -5781956777520827621}
!101 = !{i64 3669199394831664986}
!102 = !{i64 -2906625694214225183}
!103 = !{i64 -1296304284322611842}
!104 = !{i64 -7466944144942654761}
!105 = !{i64 876776160875127653}
!106 = !{i64 2168930861696301859}
!107 = !{i64 4295801905535517763}
!108 = !{i64 4428936101726650025}
!109 = !{i64 481455835074888117}
!110 = !{i64 -4712294565337611948}
!111 = !{i64 1074429442772960653}
!112 = !{i64 4607313421617655622}
!113 = !{i64 60918775224377636}
!114 = !{i64 7131172247107214075}
!115 = !{i64 5304492012676587671}
!116 = !{i64 3049350753564932451}
!117 = !{i64 -8999561964269327077}
!118 = !{i64 1106354796762430115}
!119 = !{i64 9072228292729257410}
!120 = !{i64 -7914905027830040604}
!121 = !{i64 -4595095046260684452}
!122 = !{i64 5179294592930174822}
!123 = !{i64 8217531073430220020}
!124 = !{i64 8017884885258722433}
!125 = !{i64 7405136147166240503}
!126 = !{i64 7979115868327578267}
!127 = !{i64 1425492299783591794}
!128 = !{!"address", !"read_provenance"}
!129 = !{i64 8624434338477070722}
!130 = !{i64 9163936832521111002}
!131 = !{i64 -1296013104814051771}
!132 = !{i64 -2717670516300913293}
!133 = !{i64 2093398368050865344}
!134 = !{i64 -8446117573019302529}
!135 = !{i64 -7648769497613644862}
!136 = !{i64 -4486092131318481694}
!137 = !{i64 8064045968804790609}
!138 = !{i64 2238847509194592592}
!139 = !{i64 3064948788850978008}
!140 = !{i64 -5259900728784220898}
!141 = !{i64 -261982392116737741}
!142 = !{i64 -8785526589068729341}
!143 = !{i64 -8237417580657019554}
!144 = !{i64 -6666574387085083785}
!145 = !{i64 -5989014435862811434}
!146 = !{i64 1508129085294269679}
!147 = !{i64 3802794892883529389}
!148 = !{i64 8302373821883476058}
!149 = !{i64 5236788598870585601}
!150 = !{i64 -8664256577429011797}
!151 = !{i64 -5362217492519852855}
!152 = !{i64 -1059854389422386111}
!153 = !{i64 -2624081020897602054}
