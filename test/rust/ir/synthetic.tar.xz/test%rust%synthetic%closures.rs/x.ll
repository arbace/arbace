; ModuleID = 'closures.d133eaff1e72187c-cgu.0'
source_filename = "closures.d133eaff1e72187c-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"alloc::boxed::Box<dyn core::ops::function::Fn() -> usize>" = type { %"core::ptr::unique::Unique<dyn core::ops::function::Fn() -> usize>", %"alloc::alloc::Global" }
%"core::ptr::unique::Unique<dyn core::ops::function::Fn() -> usize>" = type { %"core::ptr::non_null::NonNull<dyn core::ops::function::Fn() -> usize>", %"core::marker::PhantomData<dyn core::ops::function::Fn() -> usize>" }
%"core::ptr::non_null::NonNull<dyn core::ops::function::Fn() -> usize>" = type { { { ptr, ptr } } }
%"core::marker::PhantomData<dyn core::ops::function::Fn() -> usize>" = type {}
%"alloc::alloc::Global" = type {}
%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }
%"core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>" = type { [3 x i64] }

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@alloc_67f63f1edba9c857548f5126ab7ce3c2 = private unnamed_addr constant [36 x i8] c"core/src/slice/sort/stable/merge.rs\00", align 1, !guid !4
@alloc_fdb60fb5b6a688ef522fd0615d36880a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00v\00\00\00%\00\00\00" }>, align 8, !guid !5
@alloc_da4db734c057a1035818039c5f2cff53 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00w\00\00\00&\00\00\00" }>, align 8, !guid !6
@alloc_dbe0429b9a60c3340cdd89d89688dc8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00x\00\00\00\1B\00\00\00" }>, align 8, !guid !7
@alloc_766632cf75d088c2aec994d85ef6a106 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00\7F\00\00\00!\00\00\00" }>, align 8, !guid !8
@alloc_529aa4c4fd2d7c0d041fb141fa6954c5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00\80\00\00\00\22\00\00\00" }>, align 8, !guid !9
@alloc_22aeb683d111f116ce81304814e59560 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00_\00\00\00\1E\00\00\00" }>, align 8, !guid !10
@alloc_5fdc9e59b7004febe916aa193690e482 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00`\00\00\00\1F\00\00\00" }>, align 8, !guid !11
@alloc_90003bfdf1f7042f7a6739b0adf34bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00b\00\00\00\1C\00\00\00" }>, align 8, !guid !12
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRjNtB6_5Debug3fmtB8_ }>, align 8, !guid !13
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !14
@alloc_31365cfefba383c4d2bf6b6a04cc10aa = private unnamed_addr constant [17 x i8] c"capacity overflow", align 1, !guid !15
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !16
@alloc_8d2d54b2e3654c99232db78ca79b95fd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\002\10\00\00\0D\00\00\00" }>, align 8, !guid !17
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshXA3KcOxU02_8closures, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshXA3KcOxU02_8closures, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshXA3KcOxU02_8closures }>, align 8, !guid !18
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !19
@alloc_4267f6d2b1c6fe0d6aaa5e106110e530 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\C6\0A\00\00\0E\00\00\00" }>, align 8, !guid !20
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !21
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !22
@alloc_16babad1faddf07a74f2f1bf3db5920d = private unnamed_addr constant [17 x i8] c"core/src/hint.rs\00", align 1, !guid !23
@alloc_4abf659b91fe7b31ded00e9133a8280f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16babad1faddf07a74f2f1bf3db5920d, [16 x i8] c"\10\00\00\00\00\00\00\00o\03\00\00Q\00\00\00" }>, align 8, !guid !24
@alloc_cb304c8bbb6b9195bc454f414df930e7 = private unnamed_addr constant [34 x i8] c"core/src/slice/sort/shared/mod.rs\00", align 1, !guid !25
@alloc_b1a59a7585543a4a25115f0cbf40f484 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00\22\00\00\00-\00\00\00" }>, align 8, !guid !26
@alloc_4e95ed00d8479deaf9b8943b85759bde = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00\22\00\00\00A\00\00\00" }>, align 8, !guid !27
@alloc_0aa54d60960e578bf5dc3db64f9182b2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00(\00\00\00/\00\00\00" }>, align 8, !guid !28
@alloc_34d92db687bf3e85a75e319cac8072d0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00(\00\00\00I\00\00\00" }>, align 8, !guid !29
@alloc_3a54043bf62a6816be5c3584bd0aab69 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00$\00\00\00.\00\00\00" }>, align 8, !guid !30
@alloc_435a452c7ddb8b633a1045ff18a4d695 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00$\00\00\00H\00\00\00" }>, align 8, !guid !31
@alloc_302a40d1b3e97481190cef1fa0a61594 = private unnamed_addr constant [34 x i8] c"core/src/slice/sort/stable/mod.rs\00", align 1, !guid !32
@alloc_63f80f9ffc23059c68b68d596767dcd4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_302a40d1b3e97481190cef1fa0a61594, [16 x i8] c"!\00\00\00\00\00\00\00p\00\00\00\1A\00\00\00" }>, align 8, !guid !33
@alloc_5d8412d29d22d9db01454032d8b4fb6b = private unnamed_addr constant [36 x i8] c"core/src/slice/sort/shared/pivot.rs\00", align 1, !guid !34
@alloc_99632a891b912b3f72527a56e4385e22 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00C\00\00\00\22\00\00\00" }>, align 8, !guid !35
@alloc_09b6e462f7991c3c89272eedf987595a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00C\00\00\001\00\00\00" }>, align 8, !guid !36
@alloc_ff6d2fff2e86935f8ee7efadcbb4f63c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00D\00\00\00\22\00\00\00" }>, align 8, !guid !37
@alloc_a1fbc84c38974b09c08d1ec7662e37f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00D\00\00\001\00\00\00" }>, align 8, !guid !38
@alloc_7346065d37ade22e9dac3d1740436530 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00E\00\00\00\22\00\00\00" }>, align 8, !guid !39
@alloc_8d141bec50a4ecf1e0d49d05dd5d5a28 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00E\00\00\001\00\00\00" }>, align 8, !guid !40
@alloc_ce80262f7993cac42401bc51ff6be40f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00\1F\00\00\00\18\00\00\00" }>, align 8, !guid !41
@alloc_8fdae93ef9d304733cddf77b9bee7ee5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00 \00\00\00\18\00\00\00" }>, align 8, !guid !42
@alloc_f0b38f15064fc95bc0114a55e7ca2131 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00%\00\00\006\00\00\00" }>, align 8, !guid !43
@alloc_1824be00902e801da9c2923e0e00ce0b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00#\00\00\00-\00\00\00" }>, align 8, !guid !44
@alloc_ab4c6a2d756e35f752701a51dadd262d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00*\00\00\00\09\00\00\00" }>, align 8, !guid !45
@alloc_f23d27f71cf62f918f1bed533c70d704 = private unnamed_addr constant [40 x i8] c"core/src/slice/sort/shared/smallsort.rs\00", align 1, !guid !46
@alloc_dec6cf59bf3c4f4ee712ccf93b06ede2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\E0\02\00\00\13\00\00\00" }>, align 8, !guid !47
@alloc_d37f5665651ea8a963ab5b8e3fc8edc3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\1C\02\00\00\1D\00\00\00" }>, align 8, !guid !48
@alloc_fdc854ce3bacec098be26750747cb188 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00&\02\00\00*\00\00\00" }>, align 8, !guid !49
@alloc_9deddb0feaaab459a2c7bc3556806f0a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\005\02\00\00\19\00\00\00" }>, align 8, !guid !50
@alloc_d25d1aaad97ebd3cd2f74cf98d99708b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00l\02\00\00#\00\00\00" }>, align 8, !guid !51
@alloc_7559890e91a3e111de81bd762d3bd47b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00m\02\00\00#\00\00\00" }>, align 8, !guid !52
@alloc_9b8e086b7f9a13f6b87be36922fe3508 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00m\02\00\004\00\00\00" }>, align 8, !guid !53
@alloc_4d667cad9e6bd5c37f0224e029fdac09 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00n\02\00\00\18\00\00\00" }>, align 8, !guid !54
@alloc_b1a74bf155318ff7697ff97ab6eab62f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00o\02\00\00\18\00\00\00" }>, align 8, !guid !55
@alloc_5b26eaacf3418840255607328a9ebf80 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00p\02\00\00\18\00\00\00" }>, align 8, !guid !56
@alloc_363ed81fe39abdd8a5079e48018053d0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00q\02\00\00\18\00\00\00" }>, align 8, !guid !57
@alloc_417b4ff3eddaf23cb9f5daaf8042e173 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\88\02\00\00*\00\00\00" }>, align 8, !guid !58
@alloc_5aef466167aa735606252f9c0ea6593f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\89\02\00\00*\00\00\00" }>, align 8, !guid !59
@alloc_030cd358d2f5c80597f9fd26abd3c2a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\8A\02\00\00+\00\00\00" }>, align 8, !guid !60
@alloc_7a8e4a95c146a6c2f88953bb46a5cc11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\9A\02\00\00\1D\00\00\00" }>, align 8, !guid !61
@alloc_6b013669700cca0a3c4ffe02b2be411a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\9A\02\00\002\00\00\00" }>, align 8, !guid !62
@alloc_0ab1672cf9b06a39e5138e5643964c99 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\A0\02\00\00\1D\00\00\00" }>, align 8, !guid !63
@alloc_309c25bb111f12fc56d067e96fc10c4d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00$\03\00\00\1D\00\00\00" }>, align 8, !guid !64
@alloc_448a388e6d58225948aba50cc1a6d287 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00'\03\00\00 \00\00\00" }>, align 8, !guid !65
@alloc_0f305da993ffb5dd0c56a60daa72ac11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00(\03\00\00!\00\00\00" }>, align 8, !guid !66
@alloc_5c83ade1182dd85b92ed28e4ff47ff65 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00)\03\00\00\1F\00\00\00" }>, align 8, !guid !67
@alloc_93577c96033441b3a93f04582b1dcd3c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\008\03\00\00\19\00\00\00" }>, align 8, !guid !68
@alloc_73f0e688413d58d51ee7d8bf7ee8fce8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\009\03\00\00\1B\00\00\00" }>, align 8, !guid !69
@alloc_f03f13dd652dcc6c8ef2b56857ba12fd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00O\02\00\00\1C\00\00\00" }>, align 8, !guid !70
@alloc_db2dccc6f36daf34898e5d24ec4427c7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00P\02\00\00\1F\00\00\00" }>, align 8, !guid !71
@alloc_0977e4bfeef367cc9b1ee8484f31ed3e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00W\02\00\00\19\00\00\00" }>, align 8, !guid !72
@alloc_9a8ea5ce0558e5156f6c03bd8315475b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\04\01\00\00-\00\00\00" }>, align 8, !guid !73
@alloc_9f2322a70f1cdf56e7a06ccd06d355bd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\04\01\00\00J\00\00\00" }>, align 8, !guid !74
@alloc_c1f1e1e090df8fced69504921b66da98 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\FF\00\00\00!\00\00\00" }>, align 8, !guid !75
@alloc_1d52a18521d4b096220396e4abdd5c93 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\FF\00\00\00>\00\00\00" }>, align 8, !guid !76
@alloc_5597fc2d1a2380cd4ab5ac1a539e8a22 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F3\00\00\00=\00\00\00" }>, align 8, !guid !77
@alloc_e13dc99a925a6bd4a73408f1fbbddb5f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F5\00\00\00\18\00\00\00" }>, align 8, !guid !78
@alloc_2288ef688a5190ec529d3a4c5860298d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F6\00\00\00\1E\00\00\00" }>, align 8, !guid !79
@alloc_4a7db440c2c67d9cd260b0d40e6000e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F7\00\00\00\1E\00\00\00" }>, align 8, !guid !80
@alloc_dea82b1a5cc143169db7b7d27413b6f6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\1F\01\00\00\0D\00\00\00" }>, align 8, !guid !81
@alloc_581886408b98ee2e542da40823dc7fbc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\0C\01\00\00\1E\00\00\00" }>, align 8, !guid !82
@alloc_4f39daafd3dae09b4a4c732def155bd3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\0D\01\00\00$\00\00\00" }>, align 8, !guid !83
@alloc_bf1a118daf399e69d630cbc17cad5ced = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\11\01\00\00.\00\00\00" }>, align 8, !guid !84
@alloc_40ef727ccfc43dc7481d04a8f29418d4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\11\01\00\00:\00\00\00" }>, align 8, !guid !85
@alloc_400da1c41164a324a087a19b9508009c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\12\01\00\00&\00\00\00" }>, align 8, !guid !86
@alloc_aaec00fa598af579a3c30bdcf4b2d93d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\BD\02\00\00\1F\00\00\00" }>, align 8, !guid !87
@alloc_8746fce18c06124837c134543b80e6a7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\BE\02\00\00\1D\00\00\00" }>, align 8, !guid !88
@alloc_bb2fc3b74a4bb7a8908f20b7bbc281bc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\BF\02\00\00\13\00\00\00" }>, align 8, !guid !89
@alloc_b64624e679dbd4ce1203b98702274009 = private unnamed_addr constant [36 x i8] c"core/src/slice/sort/stable/drift.rs\00", align 1, !guid !90
@alloc_ea3823fa310c0ac95d0d5924e997a992 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\FF\00\00\00\19\00\00\00" }>, align 8, !guid !91
@alloc_0b170457ff613254af1d0cbd2a159dca = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\F2\00\00\00\12\00\00\00" }>, align 8, !guid !92
@alloc_c54bc7e12f54e1b6a5d6ee337e066d20 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\CE\00\00\00$\00\00\00" }>, align 8, !guid !93
@alloc_4b0ce783e358f6d901ee99bada134993 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\D1\00\00\00$\00\00\00" }>, align 8, !guid !94
@alloc_5b26bc7b45e7e23728885c9a7d45b9d3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\0D\01\00\00#\00\00\00" }>, align 8, !guid !95
@alloc_418d50aea1f432fc229dc42e85bc0c4e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00@\00\00\00\22\00\00\00" }>, align 8, !guid !96
@alloc_e6fc37ca432e3141da706e397b9bb790 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00W\00\00\004\00\00\00" }>, align 8, !guid !97
@alloc_93fee4c110c8615e3a44cfd0974e3956 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00g\00\00\00\13\00\00\00" }>, align 8, !guid !98
@alloc_ad9b3ef1565e0278a16153d428d3f2bf = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00h\00\00\00\1D\00\00\00" }>, align 8, !guid !99
@alloc_1a50229706ade81408c400fb610c9b55 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00Z\00\00\00\22\00\00\00" }>, align 8, !guid !100
@alloc_289e523c22daf4b02f0ced64176f9f7d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00]\00\00\00%\00\00\00" }>, align 8, !guid !101
@alloc_0f1d702ef74aa7166083d4a51933e745 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00)\00\00\00\1C\00\00\00" }>, align 8, !guid !102
@alloc_c1de2663403b8d62e29c8e4804352bb5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00*\00\00\00\1C\00\00\00" }>, align 8, !guid !103
@alloc_1b2260870073aafe108a5ee9a05f9377 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\005\00\00\00A\00\00\00" }>, align 8, !guid !104
@alloc_31616bb5bbed1ce5b2e84544eb586cfa = private unnamed_addr constant [40 x i8] c"core/src/slice/sort/stable/quicksort.rs\00", align 1, !guid !105
@alloc_8dae72bdaad9bf2cafde7b2cd598f477 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00r\00\00\00\1C\00\00\00" }>, align 8, !guid !106
@alloc_6b7a24d3e2ffd1fcade669520d81ebba = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\82\00\00\00)\00\00\00" }>, align 8, !guid !107
@alloc_77a953284c34024a97a172b82a9b5128 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\8B\00\00\00#\00\00\00" }>, align 8, !guid !108
@alloc_99697bcb2ea96e2031a95f1524bc6f42 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\AE\00\00\00\1E\00\00\00" }>, align 8, !guid !109
@alloc_27f0c46980e62edb2ad618f3979fb7d8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\AF\00\00\00\18\00\00\00" }>, align 8, !guid !110
@alloc_4b681e459e5d8eeddb2bdf3b83cf18ab = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00-\00\00\009\00\00\00" }>, align 8, !guid !111
@alloc_1c4a9aaa93e622ac2e6c018a51cab7ab = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00-\00\00\00#\00\00\00" }>, align 8, !guid !112
@alloc_2b7dc74fc6b7aa0b08aab5733d36da25 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00<\00\00\00;\00\00\00" }>, align 8, !guid !113
@alloc_06823d4b39e256f98f8c7a33a4ce85ea = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00M\00\00\00\1F\00\00\00" }>, align 8, !guid !114
@alloc_d82d96a4fa703c840ac11f4b07c0ef3c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00G\00\00\00\17\00\00\00" }>, align 8, !guid !115
@alloc_e86c6ef68ba94e4a4bc451173d753cca = private unnamed_addr constant [22 x i8] c"core/src/slice/mod.rs\00", align 1, !guid !116
@alloc_ab5ed840fe8613ddcabc97b74e0b565e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F1\03\00\00\1C\00\00\00" }>, align 8, !guid !117
@alloc_f7fcaa33fdba299ee035b5518e72c889 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F2\03\00\00\1C\00\00\00" }>, align 8, !guid !118
@alloc_1466797b2db3a3ca9645efa4732978a2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F6\03\00\00 \00\00\00" }>, align 8, !guid !119
@alloc_853b9dc5190658ffe6dc67504ed95441 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F6\03\00\00+\00\00\00" }>, align 8, !guid !120
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !121
@alloc_5bb642ca6df5ad9ba078972a9d3a5201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !122
@alloc_9a72dc1c87ddefcce62e4b5ab68e5150 = private unnamed_addr constant [1 x i8] c"\FF", align 1, !guid !123
@alloc_9de8e9d950889b89b57820c769482176 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00%\10\00\00$\00\00\00" }>, align 8, !guid !124
@alloc_673b3b79d500d405af0869a4e4a93e2d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00%\10\00\00\15\00\00\00" }>, align 8, !guid !125
@alloc_45a6f3102fc5b21d50b822c2cd1437cc = private unnamed_addr constant [32 x i8] c"test/rust/synthetic/closures.rs\00", align 1, !guid !126
@alloc_11b7222e38e467be99f52fe6836b7504 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\1C\00\00\00P\00\00\00" }>, align 8, !guid !127
@alloc_49ce66a1f0abad2a7a12818bca93edfa = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\03\00\00\009\00\00\00" }>, align 8, !guid !128
@alloc_883f8141c9a30c7bbd66eeb6fd38f3b2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\04\00\00\00E\00\00\00" }>, align 8, !guid !129
@alloc_19577330274845de4d5d8ab514a8941e = private unnamed_addr constant [6 x i8] c"\01<\C0\01>\00", align 1, !guid !130
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCNCNvCshXA3KcOxU02_8closures4mains2_00INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableBa_, ptr @_RNCNCNvCshXA3KcOxU02_8closures4mains2_00B5_, ptr @_RNCNCNvCshXA3KcOxU02_8closures4mains2_00B5_ }>, align 8, !guid !131
@alloc_7182b4eab97ac9715161e806fa0b46e7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\1F\00\00\00#\00\00\00" }>, align 8, !guid !132
@alloc_eac2b581b65e96d58e47255cf376d3af = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\1F\00\00\00\1A\00\00\00" }>, align 8, !guid !133
@alloc_ad2cb06a096b843358bb7babe59e7320 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\12\00\00\00#\00\00\00" }>, align 8, !guid !134
@alloc_1ee95cd7edfc13d03512a15866876812 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\18\00\00\000\00\00\00" }>, align 8, !guid !135
@alloc_d408193c092dd785417ad926b4403743 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\16\00\00\00\1E\00\00\00" }>, align 8, !guid !136
@alloc_05940ffd410c2695e9f6b6e120c9bc27 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\05\00\00\00P\00\00\00" }>, align 8, !guid !137
@alloc_292f47fe07f654b3daeb53c95309879e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\05\00\00\00\84\00\00\00" }>, align 8, !guid !138
@alloc_823e4ac05cf949d91880645767c98b2e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\05\00\00\00j\00\00\00" }>, align 8, !guid !139
@alloc_e90bd9a80b7f188aa76a1bfb741a5999 = private unnamed_addr constant [34 x i8] c"core/src/array/iter/iter_inner.rs\00", align 1, !guid !140
@alloc_ac893681874450253b62899ecf8cf06a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\00 \00\00\00" }>, align 8, !guid !141
@alloc_b0b7c7361940ea6a8360c2bdef76bb12 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\003\00\00\00" }>, align 8, !guid !142
@alloc_bdb8d18f3ed9bc69be55303901373737 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\0A\00\00\00\19\00\00\00" }>, align 8, !guid !143
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !144
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !145
@alloc_1a2b9f3efbe1a8edd339fa75af2334ed = private unnamed_addr constant [5 x i8] c"hello", align 1, !guid !146
@alloc_13af184f83ea529683dab3456027e412 = private unnamed_addr constant [3 x i8] c"abc", align 1, !guid !147
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !148
@alloc_597f75f969a5bf2c5fb37f6e1a0a26a0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00\19\00\00\00\11\00\00\00" }>, align 8, !guid !149
@alloc_58096495302c69ca26995c4c0084234f = private unnamed_addr constant [5 x i8] c"moved", align 1, !guid !150
@alloc_570d9fe4b5961862179f7942a2cbdd3e = private unnamed_addr constant [3 x i8] c"add", align 1, !guid !151
@alloc_a12a40a498c0d2454ea9e1174a89e908 = private unnamed_addr constant [3 x i8] c"mul", align 1, !guid !152
@alloc_71df11005c9c3a274ea98edca8205c70 = private unnamed_addr constant [3 x i8] c"pow", align 1, !guid !153
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNSNvYNCNvCshXA3KcOxU02_8closures5boxed0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_once6vtableB8_, ptr @_RNCNvCshXA3KcOxU02_8closures5boxed0B3_, ptr @_RNCNvCshXA3KcOxU02_8closures5boxed0B3_ }>, align 8, !guid !154
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNSNvYNCNvCshXA3KcOxU02_8closures5boxeds_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_once6vtableB8_, ptr @_RNCNvCshXA3KcOxU02_8closures5boxeds_0B3_, ptr @_RNCNvCshXA3KcOxU02_8closures5boxeds_0B3_ }>, align 8, !guid !155
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNSNvYNCNvCshXA3KcOxU02_8closures5boxeds0_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_once6vtableB8_, ptr @_RNCNvCshXA3KcOxU02_8closures5boxeds0_0B3_, ptr @_RNCNvCshXA3KcOxU02_8closures5boxeds0_0B3_ }>, align 8, !guid !156
@alloc_d1084648e479974e70c9329824bf76f9 = private unnamed_addr constant [9 x i8] c"mid > len", align 1, !guid !157
@alloc_36e015fa750e45dca62b9d94b6d857e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00J\03\00\00\22\00\00\00" }>, align 8, !guid !158
@alloc_a6541cbd0ddc1cb3d23757a1b3f12432 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\9D\08\00\00 \00\00\00" }>, align 8, !guid !159
@alloc_c0be9056d9e7c9d32564b353e6cdd76b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\DD\03\00\00\15\00\00\00" }>, align 8, !guid !160
@alloc_73d74aabd1e8eaefe4cbe59407c3c85c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\DE\03\00\003\00\00\00" }>, align 8, !guid !161
@alloc_11a111513757e9d53adfd2e1c4df0866 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\DE\03\00\00\15\00\00\00" }>, align 8, !guid !162
@alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b = private unnamed_addr constant [28 x i8] c"core/src/ops/index_range.rs\00", align 1, !guid !163
@alloc_de9a5d9a80d554992107c1ea3afec081 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b, [16 x i8] c"\1B\00\00\00\00\00\00\00?\00\00\00%\00\00\00" }>, align 8, !guid !164
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !165
@alloc_f5abd596fd0c54395cb86286cae95a93 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_302a40d1b3e97481190cef1fa0a61594, [16 x i8] c"!\00\00\00\00\00\00\00\A0\00\00\00\13\00\00\00" }>, align 8, !guid !166
@alloc_2491cc18f41182435b2301519a149a1c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_302a40d1b3e97481190cef1fa0a61594, [16 x i8] c"!\00\00\00\00\00\00\00\A3\00\00\00\12\00\00\00" }>, align 8, !guid !167
@alloc_a96f4d0356403e36c78136287f0c1b2f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\DE\00\00\001\00\00\00" }>, align 8, !guid !168
@alloc_a56b047bd0b34a39f54c81b6689d3e24 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\E3\00\00\00 \00\00\00" }>, align 8, !guid !169
@alloc_35909116da33a5c42c9fe1f80ecea2ce = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\E7\00\00\00#\00\00\00" }>, align 8, !guid !170
@alloc_9738d6b9b3097219ddae8e296f0517dc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\CB\00\00\00X\00\00\00" }>, align 8, !guid !171
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !172
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !173
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !174
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !175
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !176
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !177
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !178
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !179
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !180
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !181
@alloc_9f4cf96e0cfa121f5a07edf0a5a77ed7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\AC\05\00\00\05\00\00\00" }>, align 8, !guid !182
@alloc_9420a1aba537dc94842201b7589e1f0c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0C\04\00\00)\00\00\00" }>, align 8, !guid !183
@alloc_ce6d47b03c47f09012a85da1d9cb0822 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0D\04\00\00\0D\00\00\00" }>, align 8, !guid !184
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !185
@alloc_1cbb975cc83b9471f5f1e14e3976c3b1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\EA\0C\00\00#\00\00\00" }>, align 8, !guid !186
@alloc_027cef065c3c71aa2f31a680ec9e0201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\E9\0C\00\00\0D\00\00\00" }>, align 8, !guid !187
@alloc_a486ca5f44dc72a11bf5950520485aa9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00$\00\00\00Y\00\00\00" }>, align 8, !guid !188
@alloc_65d221b36a247b637ff22be5417994a4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_45a6f3102fc5b21d50b822c2cd1437cc, [16 x i8] c"\1F\00\00\00\00\00\00\00$\00\00\00P\00\00\00" }>, align 8, !guid !189
@alloc_ab1ae74de3e4549d53c3a5a25a7b5349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\FE\05\00\00.\00\00\00" }>, align 8, !guid !190
@alloc_bde50f121dd28b1208f603a6cb579e2e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\FE\05\00\00<\00\00\00" }>, align 8, !guid !191
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !192
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !193
@alloc_945f2c369c171e278c4be97205a79e9b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !194
@alloc_8b70662a33190959512d6213db47913f = private unnamed_addr constant [22 x i8] c"Platform not supported", align 1, !guid !195
@alloc_32204aadf0ef6d74ed8e4766f91eb6a4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\9E\00\00\00\09\00\00\00" }>, align 8, !guid !196
@alloc_6b0b11c9e93314b588b613b55005cf18 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: slice::split_at_mut_unchecked requires the index to be within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !197
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !198
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !199
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !200
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !201
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !202
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !203
@alloc_2875d9f120b8cc0de1c30c014c7b6715 = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::swap_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !204
@alloc_21be34ed5a7b8b5ac8a692be276474da = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\EB\05\00\00\09\00\00\00" }>, align 8, !guid !205
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !206
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !207
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !208
@alloc_5c1a2f972552229672fc942406cfc298 = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts_mut requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !209
@alloc_97d92cbf2a68a6ac45a1b13da79836e4 = private unnamed_addr constant [214 x i8] c"unsafe precondition(s) violated: slice::get_unchecked requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !210
@alloc_5a8fdd84b3281310cbf6b74bb6bf0065 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !211
@alloc_18d73aa062d524e9620b9e3b55bd9eb1 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the range is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !212
@alloc_c7037efb906203803aa3ca07167c9120 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\13\00\00\00\17\00\00\00" }>, align 8, !guid !213
@alloc_f764952b50ffad1fb52cf6916450b6b7 = private unnamed_addr constant [23 x i8] c"core/src/iter/range.rs\00", align 1, !guid !214
@alloc_33c781d4b73231c4b72218e776044e11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f764952b50ffad1fb52cf6916450b6b7, [16 x i8] c"\16\00\00\00\00\00\00\00$\02\00\00\01\00\00\00" }>, align 8, !guid !215
@alloc_cff8939d5dc637bf609a2f92b31c63ab = private unnamed_addr constant [39 x i8] c"alloc/src/vec/spec_from_iter_nested.rs\00", align 1, !guid !216
@alloc_391673418deaa0b14b40e679e64fed1a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cff8939d5dc637bf609a2f92b31c63ab, [16 x i8] c"&\00\00\00\00\00\00\009\00\00\00\12\00\00\00" }>, align 8, !guid !217
@alloc_4a07d64a21980758f07ef2afc3d73d2d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00\92\00\00\00 \00\00\00" }>, align 8, !guid !218

; closures::apply::<closures::main::{closure#10}>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvCshXA3KcOxU02_8closures5applyNCNvB2_4mains8_0EB2_(ptr align 8 %f, ptr align 8 %s) unnamed_addr #0 !guid !224 {
start:
  %0 = alloca [24 x i8], align 8
  %_3 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3, ptr align 8 %s, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %f, i64 24, i1 false)
; call closures::main::{closure#10}
  %_0 = call i64 @_RNCNvCshXA3KcOxU02_8closures4mains8_0B3_(ptr align 8 %0, ptr align 8 %_3) #21
  ret i64 %_0
}

; closures::twice::<closures::main::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvCshXA3KcOxU02_8closures5twiceNCNvB2_4main0EB2_(ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !225 {
start:
  %f = alloca [8 x i8], align 8
  store ptr %0, ptr %f, align 8
; call closures::main::{closure#0}
  call void @_RNCNvCshXA3KcOxU02_8closures4main0B3_(ptr align 8 %f) #21
  br label %bb1

bb1:                                              ; preds = %start
; call closures::main::{closure#0}
  call void @_RNCNvCshXA3KcOxU02_8closures4main0B3_(ptr align 8 %f) #21
  br label %bb2

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; closures::compose::<i32, i32, alloc::string::String, closures::main::{closure#1}, closures::main::{closure#2}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvCshXA3KcOxU02_8closures7composellNtNtCs7CppTae75M1_5alloc6string6StringNCNvB2_4mains_0NCB1d_s0_0EB2_() unnamed_addr #0 !guid !226 {
start:
  ret void
}

; <[i32]>::sort_by::<closures::main::{closure#3}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0EBJ_(ptr align 4 %self.0, i64 %self.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !227 {
start:
  %compare = alloca [0 x i8], align 1
; call alloc::slice::stable_sort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtCs7CppTae75M1_5alloc5slice11stable_sortlNCINvMB2_Sl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB15_(ptr align 4 %self.0, i64 %self.1, ptr %compare) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <[i32]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSl8into_vecNtNtB5_5alloc6GlobalECshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !228 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[i32]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlE23into_raw_with_allocatorCshXA3KcOxU02_8closures(ptr align 4 %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<i32>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE17from_raw_parts_inCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[i32]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEECshXA3KcOxU02_8closures(ptr align 8 %self) #22
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable
}

; <bool>::then_some::<&i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core4boolb9then_someRlECshXA3KcOxU02_8closures(i1 zeroext %self, ptr align 4 %t) unnamed_addr #1 !guid !229 {
start:
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  store i8 0, ptr %_4, align 1
  store i8 1, ptr %_4, align 1
  br i1 %self, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_4, align 1
  store ptr %t, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load i8, ptr %_4, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb3
  %2 = load ptr, ptr %_0, align 8
  ret ptr %2

bb5:                                              ; preds = %bb3
  br label %bb4
}

; <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitTReFddEdEE13get_uncheckedjECshXA3KcOxU02_8closures(ptr align 8 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #1 !guid !230 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitTReFddEdEEE13get_uncheckedCshXA3KcOxU02_8closures(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #21
  ret ptr %_3
}

; <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitTReFddEdEE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECshXA3KcOxU02_8closures(ptr align 8 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #1 !guid !231 {
start:
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitTReFddEdEEE17get_unchecked_mutCshXA3KcOxU02_8closures(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #21
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <[i32]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECshXA3KcOxU02_8closures(ptr align 4 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #1 !guid !232 {
start:
; call <usize as core::slice::index::SliceIndex<[i32]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSlE13get_uncheckedCshXA3KcOxU02_8closures(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #21
  ret ptr %_3
}

; <[i32]>::get_unchecked_mut::<core::ops::range::Range<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSl17get_unchecked_mutINtNtNtB5_3ops5range5RangejEECshXA3KcOxU02_8closures(ptr align 4 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #1 !guid !233 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[i32]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSlE17get_unchecked_mutCshXA3KcOxU02_8closures(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #21
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <core::option::Option<usize>>::map::<(&str, fn(f64, f64) -> f64), <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapTReFddEdENCNvMs8_NtNtNtB5_5array4iter10iter_innerINtB15_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %0, i64 %1, ptr align 8 %f.0, i64 %f.1) unnamed_addr #1 !guid !234 {
start:
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::next::{closure#0}
  call void @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitTReFddEdEEE4next0CshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %f.0, i64 %f.1, i64 %x) #21
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %7 = load i8, ptr %_8, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !235 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCshXA3KcOxU02_8closures(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECshXA3KcOxU02_8closures(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCshXA3KcOxU02_8closures, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !236 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshXA3KcOxU02_8closures(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshXA3KcOxU02_8closures(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<alloc::vec::Vec<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc3vec3VecjEECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !237 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::vec::Vec<usize>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecjEE8from_refCshXA3KcOxU02_8closures(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<alloc::vec::Vec<usize>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecjEE4castuECshXA3KcOxU02_8closures(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshXA3KcOxU02_8closures, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<alloc::vec::Vec<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc3vec3VeclEECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !238 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::vec::Vec<i32>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VeclEE8from_refCshXA3KcOxU02_8closures(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<alloc::vec::Vec<i32>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VeclEE4castuECshXA3KcOxU02_8closures(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshXA3KcOxU02_8closures, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<dyn core::ops::function::Fn<(i32,), Output = i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDINtNtNtB7_3ops8function2FnTlEEp6OutputlEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) unnamed_addr #1 !guid !239 {
start:
; call core::mem::align_of_val_raw::<dyn core::ops::function::Fn<(i32,), Output = i32>>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDINtNtNtB4_3ops8function2FnTlEEp6OutputlEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) #21
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCshXA3KcOxU02_8closures(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #21
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<dyn core::ops::function::Fn<(), Output = usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDINtNtNtB7_3ops8function2FnuEp6OutputjEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) unnamed_addr #1 !guid !240 {
start:
; call core::mem::align_of_val_raw::<dyn core::ops::function::Fn<(), Output = usize>>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDINtNtNtB4_3ops8function2FnuEp6OutputjEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) #21
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCshXA3KcOxU02_8closures(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #21
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSlECshXA3KcOxU02_8closures(ptr %val.0, i64 %val.1) unnamed_addr #1 !guid !241 {
start:
; call core::mem::align_of_val_raw::<[i32]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSlECshXA3KcOxU02_8closures(ptr %val.0, i64 %val.1) #21
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCshXA3KcOxU02_8closures(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #21
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofjECshXA3KcOxU02_8closures() unnamed_addr #1 !guid !242 {
start:
  ret i64 8
}

; <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), i32, core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuituE10wrap_mut_2ulNCINvNvNtNtNtNtB7_4iter6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0EB2o_(ptr align 4 %f) unnamed_addr #1 !guid !243 {
start:
  ret ptr %f
}

; <core::alloc::layout::Layout>::for_value_raw::<dyn core::ops::function::Fn<(i32,), Output = i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDINtNtNtB7_3ops8function2FnTlEEp6OutputlEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) unnamed_addr #1 !guid !244 {
start:
; call core::mem::size_of_val_raw::<dyn core::ops::function::Fn<(i32,), Output = i32>>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDINtNtNtB4_3ops8function2FnTlEEp6OutputlEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) #21
; call <core::mem::alignment::Alignment>::of_val_raw::<dyn core::ops::function::Fn<(i32,), Output = i32>>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDINtNtNtB7_3ops8function2FnTlEEp6OutputlEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) #21
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCshXA3KcOxU02_8closures(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #21
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<dyn core::ops::function::Fn<(), Output = usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDINtNtNtB7_3ops8function2FnuEp6OutputjEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) unnamed_addr #1 !guid !245 {
start:
; call core::mem::size_of_val_raw::<dyn core::ops::function::Fn<(), Output = usize>>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDINtNtNtB4_3ops8function2FnuEp6OutputjEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) #21
; call <core::mem::alignment::Alignment>::of_val_raw::<dyn core::ops::function::Fn<(), Output = usize>>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDINtNtNtB7_3ops8function2FnuEp6OutputjEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) #21
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCshXA3KcOxU02_8closures(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #21
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSlECshXA3KcOxU02_8closures(ptr %val.0, i64 %val.1) unnamed_addr #1 !guid !246 {
start:
; call core::mem::size_of_val_raw::<[i32]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSlECshXA3KcOxU02_8closures(ptr %val.0, i64 %val.1) #21
; call <core::mem::alignment::Alignment>::of_val_raw::<[i32]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSlECshXA3KcOxU02_8closures(ptr %val.0, i64 %val.1) #21
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCshXA3KcOxU02_8closures(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #21
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::slice::sort::stable::merge::MergeState<i32>>::merge_down::<<[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStatelE10merge_downNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB2a_(ptr align 8 %self, ptr %left_end, ptr %right_end, ptr %0, ptr align 8 %is_less) unnamed_addr #0 !guid !247 {
start:
  %_0.i6 = alloca [8 x i8], align 8
  %_0.i4 = alloca [8 x i8], align 8
  %_0.i2 = alloca [8 x i8], align 8
  %src = alloca [8 x i8], align 8
  %out = alloca [8 x i8], align 8
  store ptr %0, ptr %out, align 8
  br label %bb1

bb1:                                              ; preds = %bb12, %start
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_7 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i32, ptr %_7, i64 -1
  store ptr %2, ptr %_0.i6, align 8
  %3 = load ptr, ptr %_0.i6, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_9 = load ptr, ptr %4, align 8
  %5 = getelementptr inbounds i32, ptr %_9, i64 -1
  store ptr %5, ptr %_0.i4, align 8
  %6 = load ptr, ptr %_0.i4, align 8
  %_11 = load ptr, ptr %out, align 8
  %7 = getelementptr inbounds i32, ptr %_11, i64 -1
  store ptr %7, ptr %_0.i2, align 8
  %8 = load ptr, ptr %_0.i2, align 8
  store ptr %8, ptr %out, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %consume_left = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %6, ptr align 4 %3) #21
  br i1 %consume_left, label %bb6, label %bb7

bb7:                                              ; preds = %bb1
  store ptr %6, ptr %src, align 8
  br label %bb8

bb6:                                              ; preds = %bb1
  store ptr %3, ptr %src, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_19 = load ptr, ptr %src, align 8
  %_20 = load ptr, ptr %out, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %bb8
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_19, ptr %_20, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %bb8, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_20, ptr align 4 %_19, i64 4, i1 false)
  %_23 = xor i1 %consume_left, true
  %_22 = zext i1 %_23 to i64
  %_0.i1 = getelementptr inbounds nuw i32, ptr %3, i64 %_22
  %9 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %_0.i1, ptr %9, align 8
  %_25 = zext i1 %consume_left to i64
  %_0.i = getelementptr inbounds nuw i32, ptr %6, i64 %_25
  %10 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_0.i, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 16
  %_28 = load ptr, ptr %11, align 8
  %_26 = icmp eq ptr %_28, %left_end
  br i1 %_26, label %bb13, label %bb12

bb12:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit
  %12 = getelementptr inbounds i8, ptr %self, i64 8
  %_31 = load ptr, ptr %12, align 8
  %_29 = icmp eq ptr %_31, %right_end
  br i1 %_29, label %bb13, label %bb1

bb13:                                             ; preds = %bb12, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit
  ret void
}

; <core::slice::sort::stable::merge::MergeState<i32>>::merge_up::<<[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStatelE8merge_upNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB27_(ptr align 8 %self, ptr %0, ptr %right_end, ptr align 8 %is_less) unnamed_addr #0 !guid !248 {
start:
  %src = alloca [8 x i8], align 8
  %right = alloca [8 x i8], align 8
  store ptr %0, ptr %right, align 8
  %out = getelementptr inbounds i8, ptr %self, i64 16
  br label %bb1

bb1:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit, %start
  %_8 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %_9 = load ptr, ptr %1, align 8
  %_7 = icmp ne ptr %_8, %_9
  br i1 %_7, label %bb2, label %bb12

bb12:                                             ; preds = %bb2, %bb1
  ret void

bb2:                                              ; preds = %bb1
  %_11 = load ptr, ptr %right, align 8
  %_10 = icmp ne ptr %_11, %right_end
  br i1 %_10, label %bb3, label %bb12

bb3:                                              ; preds = %bb2
  %_15 = load ptr, ptr %right, align 8
  %_31 = load ptr, ptr %self, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_13 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_15, ptr align 4 %_31) #21
  %consume_left = xor i1 %_13, true
  br i1 %consume_left, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %2 = load ptr, ptr %right, align 8
  store ptr %2, ptr %src, align 8
  br label %bb7

bb5:                                              ; preds = %bb3
  %_18 = load ptr, ptr %self, align 8
  store ptr %_18, ptr %src, align 8
  br label %bb7

bb7:                                              ; preds = %bb5, %bb6
  %_20 = load ptr, ptr %src, align 8
  %_21 = load ptr, ptr %out, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %bb7
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_20, ptr %_21, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %bb7, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_21, ptr align 4 %_20, i64 4, i1 false)
  %_23 = load ptr, ptr %self, align 8
  %_24 = zext i1 %consume_left to i64
  %_0.i1 = getelementptr inbounds nuw i32, ptr %_23, i64 %_24
  store ptr %_0.i1, ptr %self, align 8
  %_26 = load ptr, ptr %right, align 8
  %_28 = xor i1 %consume_left, true
  %_27 = zext i1 %_28 to i64
  %_0.i2 = getelementptr inbounds nuw i32, ptr %_26, i64 %_27
  store ptr %_0.i2, ptr %right, align 8
  %_30 = load ptr, ptr %out, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_30, i64 1
  store ptr %_0.i, ptr %out, align 8
  br label %bb1
}

; <core::ptr::unique::Unique<dyn core::ops::function::Fn<(i32,), Output = i32>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDINtNtNtBa_3ops8function2FnTlEEp6OutputlEL_E4casthECshXA3KcOxU02_8closures(ptr %self.0, ptr align 8 %self.1) unnamed_addr #1 !guid !249 {
start:
; call <core::ptr::non_null::NonNull<dyn core::ops::function::Fn<(i32,), Output = i32>>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDINtNtNtBa_3ops8function2FnTlEEp6OutputlEL_E4casthECshXA3KcOxU02_8closures(ptr %self.0, ptr align 8 %self.1) #21
  ret ptr %_2
}

; <core::ptr::unique::Unique<dyn core::ops::function::Fn<(), Output = usize>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDINtNtNtBa_3ops8function2FnuEp6OutputjEL_E4casthECshXA3KcOxU02_8closures(ptr %self.0, ptr align 8 %self.1) unnamed_addr #1 !guid !250 {
start:
; call <core::ptr::non_null::NonNull<dyn core::ops::function::Fn<(), Output = usize>>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDINtNtNtBa_3ops8function2FnuEp6OutputjEL_E4casthECshXA3KcOxU02_8closures(ptr %self.0, ptr align 8 %self.1) #21
  ret ptr %_2
}

; <core::ptr::unique::Unique<[i32]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSlE4casthECshXA3KcOxU02_8closures(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !251 {
start:
; call <core::ptr::non_null::NonNull<[i32]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4casthECshXA3KcOxU02_8closures(ptr %self.0, i64 %self.1) #21
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !252 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr %self) #21
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castlECshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !253 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<i32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castlECshXA3KcOxU02_8closures(ptr %self) #21
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<dyn core::ops::function::Fn<(i32,), Output = i32>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDINtNtNtBa_3ops8function2FnTlEEp6OutputlEL_E4casthECshXA3KcOxU02_8closures(ptr %self.0, ptr align 8 %self.1) unnamed_addr #1 !guid !254 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<dyn core::ops::function::Fn<(), Output = usize>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDINtNtNtBa_3ops8function2FnuEp6OutputjEL_E4casthECshXA3KcOxU02_8closures(ptr %self.0, ptr align 8 %self.1) unnamed_addr #1 !guid !255 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<alloc::vec::Vec<usize>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecjEE4castuECshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !256 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::vec::Vec<i32>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VeclEE4castuECshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !257 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !258 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>]>>::cast::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EE4castBV_ECshXA3KcOxU02_8closures(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !259 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[i32]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4casthECshXA3KcOxU02_8closures(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !260 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !261 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !262 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castlECshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !263 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !264 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %self) #21
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::ptr::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrlECshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !265 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<i32>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nulllECshXA3KcOxU02_8closures(ptr align 8 %self) #21
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !266 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr %_3) #21
; call <core::ptr::unique::Unique<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE15as_non_null_ptrCshXA3KcOxU02_8closures(ptr %_2) #21
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::non_null::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nulllECshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !267 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<i32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castlECshXA3KcOxU02_8closures(ptr %_3) #21
; call <core::ptr::unique::Unique<i32>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquelE15as_non_null_ptrCshXA3KcOxU02_8closures(ptr %_2) #21
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshXA3KcOxU02_8closures(ptr %template, ptr align 8 %args) unnamed_addr #1 !guid !268 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::builders::DebugList>::entries::<&usize, core::slice::iter::Iter<usize>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRjINtNtNtBa_5slice4iter4IterjEECshXA3KcOxU02_8closures(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !269 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterjENtB2_12IntoIterator9into_iterCshXA3KcOxU02_8closures(ptr %entries.0, ptr %entries.1) #21
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<usize> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterjENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBa_(ptr align 8 %iter) #21
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !270
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.0)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECshXA3KcOxU02_8closures(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !271 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCshXA3KcOxU02_8closures(ptr %entries.0, ptr %entries.1) #21
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 8 %iter) #21
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !270
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.1)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted::<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE14extend_trustedINtNtNtNtB16_4iter8adapters3map3MapINtNtB14_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EEB3b_(ptr align 8 %self, i64 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !272 {
start:
  %_23 = alloca [1 x i8], align 1
  %_20 = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %high = alloca [16 x i8], align 8
  %iterator = alloca [16 x i8], align 8
  store i64 %0, ptr %iterator, align 8
  %2 = getelementptr inbounds i8, ptr %iterator, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_23, align 1
  store i8 1, ptr %_23, align 1
; call <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtNtNtB9_6traits8iterator8Iterator9size_hintB1s_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %iterator) #21
  br label %bb1

bb1:                                              ; preds = %start
  %low = load i64, ptr %_5, align 8
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
  store i64 %4, ptr %high, align 8
  %7 = getelementptr inbounds i8, ptr %high, i64 8
  store i64 %6, ptr %7, align 8
  %_7 = load i64, ptr %high, align 8
  %8 = getelementptr inbounds i8, ptr %high, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = trunc nuw i64 %_7 to i1
  br i1 %10, label %bb2, label %bb7

bb2:                                              ; preds = %bb1
  %11 = getelementptr inbounds i8, ptr %high, i64 8
  %additional = load i64, ptr %11, align 8
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE7reserveCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %additional)
  br label %bb3

bb7:                                              ; preds = %bb1
; call <core::fmt::Arguments>::from_str
  %12 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_31365cfefba383c4d2bf6b6a04cc10aa, i64 17) #21
  %_22.0 = extractvalue { ptr, ptr } %12, 0
  %_22.1 = extractvalue { ptr, ptr } %12, 1
  br label %bb8

bb3:                                              ; preds = %bb2
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::as_mut_ptr
  %ptr = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  br label %bb4

bb4:                                              ; preds = %bb3
  %_17 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::new
  %13 = call { ptr, i64 } @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop3newCshXA3KcOxU02_8closures(ptr align 8 %_17) #21
  %local_len.0 = extractvalue { ptr, i64 } %13, 0
  %local_len.1 = extractvalue { ptr, i64 } %13, 1
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_23, align 1
  %_19.0 = load i64, ptr %iterator, align 8
  %14 = getelementptr inbounds i8, ptr %iterator, i64 8
  %_19.1 = load i64, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %_20, i64 16
  store ptr %ptr, ptr %15, align 8
  store ptr %local_len.0, ptr %_20, align 8
  %16 = getelementptr inbounds i8, ptr %_20, i64 8
  store i64 %local_len.1, ptr %16, align 8
; call <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>
  call void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2K_3VecINtNtB2M_5boxed3BoxDINtNtBW_8function2FnuEp6OutputjEL_EE14extend_trustedB3_E0EB1n_(i64 %_19.0, i64 %_19.1, ptr align 8 %_20) #21
  br label %bb6

bb6:                                              ; preds = %bb5
  ret void

bb8:                                              ; preds = %bb7
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_22.0, ptr %_22.1, ptr align 8 @alloc_8d2d54b2e3654c99232db78ca79b95fd) #25
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<usize>>::extend_trusted::<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterINtNtB8_5boxed3BoxDINtNtNtB17_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EEB3h_(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !273 {
start:
  %_23 = alloca [1 x i8], align 1
  %_20 = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %high = alloca [16 x i8], align 8
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %2 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_23, align 1
  store i8 1, ptr %_23, align 1
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBb_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtNtNtB9_6traits8iterator8Iterator9size_hintB2G_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %iterator) #21
  br label %bb1

bb1:                                              ; preds = %start
  %low = load i64, ptr %_5, align 8
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
  store i64 %4, ptr %high, align 8
  %7 = getelementptr inbounds i8, ptr %high, i64 8
  store i64 %6, ptr %7, align 8
  %_7 = load i64, ptr %high, align 8
  %8 = getelementptr inbounds i8, ptr %high, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = trunc nuw i64 %_7 to i1
  br i1 %10, label %bb2, label %bb7

bb2:                                              ; preds = %bb1
  %11 = getelementptr inbounds i8, ptr %high, i64 8
  %additional = load i64, ptr %11, align 8
; call <alloc::vec::Vec<usize>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE7reserveCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %additional)
  br label %bb3

bb7:                                              ; preds = %bb1
; call <core::fmt::Arguments>::from_str
  %12 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_31365cfefba383c4d2bf6b6a04cc10aa, i64 17) #21
  %_22.0 = extractvalue { ptr, ptr } %12, 0
  %_22.1 = extractvalue { ptr, ptr } %12, 1
  br label %bb8

bb3:                                              ; preds = %bb2
; call <alloc::vec::Vec<usize>>::as_mut_ptr
  %ptr = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  br label %bb4

bb4:                                              ; preds = %bb3
  %_17 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::new
  %13 = call { ptr, i64 } @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop3newCshXA3KcOxU02_8closures(ptr align 8 %_17) #21
  %local_len.0 = extractvalue { ptr, i64 } %13, 0
  %local_len.1 = extractvalue { ptr, i64 } %13, 1
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_23, align 1
  %_19.0 = load ptr, ptr %iterator, align 8
  %14 = getelementptr inbounds i8, ptr %iterator, i64 8
  %_19.1 = load ptr, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %_20, i64 16
  store ptr %ptr, ptr %15, align 8
  store ptr %local_len.0, ptr %_20, align 8
  %16 = getelementptr inbounds i8, ptr %_20, i64 8
  store i64 %local_len.1, ptr %16, align 8
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>
  call void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvMsk_NtB1m_3vecINtB3Y_3VecjE14extend_trustedB3_E0EB2B_(ptr %_19.0, ptr %_19.1, ptr align 8 %_20) #21
  br label %bb6

bb6:                                              ; preds = %bb5
  ret void

bb8:                                              ; preds = %bb7
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_22.0, ptr %_22.1, ptr align 8 @alloc_8d2d54b2e3654c99232db78ca79b95fd) #25
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; alloc::slice::stable_sort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCs7CppTae75M1_5alloc5slice11stable_sortlNCINvMB2_Sl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB15_(ptr align 4 %v.0, i64 %v.1, ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !274 {
start:
  %_0.i1 = alloca [1 x i8], align 1
  %_0.i = alloca [1 x i8], align 1
  %is_less = alloca [8 x i8], align 8
  store ptr %0, ptr %is_less, align 8
  %_6.i = icmp ult i64 %v.1, 2
  br i1 %_6.i, label %bb1.i3, label %bb2.i2

bb2.i2:                                           ; preds = %start
  store i8 0, ptr %_0.i1, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4

bb1.i3:                                           ; preds = %start
  store i8 1, ptr %_0.i1, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4

_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4: ; preds = %bb2.i2, %bb1.i3
  %1 = load i8, ptr %_0.i1, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0INtNtBX_3vec3VeclEEB1B_.exit, label %bb3.i

bb3.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4
  %_8.i = icmp ule i64 %v.1, 20
  br i1 %_8.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb3.i
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit

bb1.i:                                            ; preds = %bb3.i
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit: ; preds = %bb2.i, %bb1.i
  %3 = load i8, ptr %_0.i, align 1
  %4 = trunc nuw i8 %3 to i1
  br i1 %4, label %bb5.i, label %bb6.i

bb6.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit
; call core::slice::sort::stable::driftsort_main::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}, alloc::vec::Vec<i32>>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable14driftsort_mainlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0INtNtB18_3vec3VeclEEB1M_(ptr align 4 %v.0, i64 %v.1, ptr align 8 %is_less) #26
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0INtNtBX_3vec3VeclEEB1B_.exit

bb5.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit
; call core::slice::sort::shared::smallsort::insertion_sort_shift_left::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB29_(ptr align 4 %v.0, i64 %v.1, i64 1, ptr align 8 %is_less)
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0INtNtBX_3vec3VeclEEB1B_.exit

_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0INtNtBX_3vec3VeclEEB1B_.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4, %bb6.i, %bb5.i
  br label %bb1

bb1:                                              ; preds = %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0INtNtBX_3vec3VeclEEB1B_.exit
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; alloc::raw_vec::new_cap::<i32>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_caplECshXA3KcOxU02_8closures(i64 %cap) unnamed_addr #0 !guid !275 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCshXA3KcOxU02_8closures(i64 %cap) #21
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshXA3KcOxU02_8closures(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !276 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.2, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::select_unpredictable::<core::mem::maybe_uninit::MaybeUninit<*const i32>>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal ptr @_RINvNtCsl10jNU3mE6R_4core10intrinsics20select_unpredictableINtNtNtB4_3mem12maybe_uninit11MaybeUninitPlEECshXA3KcOxU02_8closures(i1 zeroext %b, ptr %true_val, ptr %false_val) unnamed_addr #2 !guid !277 {
start:
  %_0 = alloca [8 x i8], align 8
  br i1 %b, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr %false_val, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store ptr %true_val, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; core::intrinsics::select_unpredictable::<*mut *const i32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal ptr @_RINvNtCsl10jNU3mE6R_4core10intrinsics20select_unpredictableOPlECshXA3KcOxU02_8closures(i1 zeroext %b, ptr %true_val, ptr %false_val) unnamed_addr #2 !guid !278 {
start:
  %_0 = alloca [8 x i8], align 8
  br i1 %b, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr %false_val, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store ptr %true_val, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; core::intrinsics::typed_swap_nonoverlapping::<i32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core10intrinsics25typed_swap_nonoverlappinglECshXA3KcOxU02_8closures(ptr %x, ptr %y) unnamed_addr #2 personality ptr @rust_eh_personality !guid !279 {
start:
; invoke core::ptr::swap_nonoverlapping::<i32>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlappinglECshXA3KcOxU02_8closures(ptr %x, ptr %y, i64 1, ptr align 8 @alloc_4267f6d2b1c6fe0d6aaa5e106110e530)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  ret void
}

; core::mem::needs_drop::<(&str, fn(f64, f64) -> f64)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropTReFddEdEECshXA3KcOxU02_8closures() unnamed_addr #1 !guid !280 {
start:
  ret i1 false
}

; core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECshXA3KcOxU02_8closures(ptr %src) unnamed_addr #1 !guid !281 {
start:
  ret ptr %src
}

; core::mem::size_of_val_raw::<dyn core::ops::function::Fn<(i32,), Output = i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDINtNtNtB4_3ops8function2FnTlEEp6OutputlEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) unnamed_addr #1 !guid !282 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %_0 = load i64, ptr %0, align 8, !invariant.load !283
  %1 = getelementptr inbounds i8, ptr %val.1, i64 16
  %2 = load i64, ptr %1, align 8, !invariant.load !283
  ret i64 %_0
}

; core::mem::size_of_val_raw::<dyn core::ops::function::Fn<(), Output = usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDINtNtNtB4_3ops8function2FnuEp6OutputjEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) unnamed_addr #1 !guid !284 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %_0 = load i64, ptr %0, align 8, !invariant.load !283
  %1 = getelementptr inbounds i8, ptr %val.1, i64 16
  %2 = load i64, ptr %1, align 8, !invariant.load !283
  ret i64 %_0
}

; core::mem::size_of_val_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSlECshXA3KcOxU02_8closures(ptr %val.0, i64 %val.1) unnamed_addr #1 !guid !285 {
start:
  %_0 = mul nuw nsw i64 %val.1, 4
  ret i64 %_0
}

; core::mem::align_of_val_raw::<dyn core::ops::function::Fn<(i32,), Output = i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDINtNtNtB4_3ops8function2FnTlEEp6OutputlEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) unnamed_addr #1 !guid !286 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %1 = load i64, ptr %0, align 8, !invariant.load !283
  %2 = getelementptr inbounds i8, ptr %val.1, i64 16
  %_0 = load i64, ptr %2, align 8, !invariant.load !283
  ret i64 %_0
}

; core::mem::align_of_val_raw::<dyn core::ops::function::Fn<(), Output = usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDINtNtNtB4_3ops8function2FnuEp6OutputjEL_ECshXA3KcOxU02_8closures(ptr %val.0, ptr align 8 %val.1) unnamed_addr #1 !guid !287 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %1 = load i64, ptr %0, align 8, !invariant.load !283
  %2 = getelementptr inbounds i8, ptr %val.1, i64 16
  %_0 = load i64, ptr %2, align 8, !invariant.load !283
  ret i64 %_0
}

; core::mem::align_of_val_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSlECshXA3KcOxU02_8closures(ptr %val.0, i64 %val.1) unnamed_addr #1 !guid !288 {
start:
  %0 = mul nuw nsw i64 %val.1, 4
  ret i64 4
}

; core::mem::swap::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem4swaplECshXA3KcOxU02_8closures(ptr align 4 %x, ptr align 4 %y) unnamed_addr #1 !guid !289 {
start:
  %0 = load i32, ptr %x, align 4
  %1 = load i32, ptr %y, align 4
  store i32 %1, ptr %x, align 4
  store i32 %0, ptr %y, align 4
  ret void
}

; core::mem::forget::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECshXA3KcOxU02_8closures(ptr align 8 %t) unnamed_addr #1 !guid !290 {
start:
  %0 = alloca [24 x i8], align 8
  %_2.i = alloca [24 x i8], align 8
  %1 = alloca [24 x i8], align 8
  %_2 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %t, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 24, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtNtB6_5slice4sort6shared9smallsort10CopyOnDroplEE3newCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_2, ptr align 8 %_2.i, i64 24, i1 false)
  ret void
}

; core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr %t) unnamed_addr #1 !guid !291 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::hint::select_unpredictable::DropOnPanic<*const i32>>>::new
  %_2.i = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNvNtB6_4hint20select_unpredictable11DropOnPanicPlEE3newCshXA3KcOxU02_8closures(ptr %t)
  ret void
}

; core::mem::replace::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core3mem7replacelECshXA3KcOxU02_8closures(ptr align 4 %dest, i32 %src) unnamed_addr #1 !guid !292 {
start:
  %result = load i32, ptr %dest, align 4
  store i32 %src, ptr %dest, align 4
  ret i32 %result
}

; core::ptr::swap_nonoverlapping::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlappinglECshXA3KcOxU02_8closures(ptr %x, ptr %y, i64 %count, ptr align 8 %0) unnamed_addr #1 !guid !293 {
start:
  %_10 = alloca [24 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::swap_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %x, ptr %y, i64 4, i64 4, i64 %count, ptr align 8 %0) #24
  br label %bb4

bb4:                                              ; preds = %bb1
  store ptr %x, ptr %_10, align 8
  %1 = getelementptr inbounds i8, ptr %_10, i64 8
  store ptr %y, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_10, i64 16
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_10, align 8
  %4 = getelementptr inbounds i8, ptr %_10, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_10, i64 16
  %7 = load i64, ptr %6, align 8
; call core::ptr::swap_nonoverlapping::runtime::<i32>
  call void @_RINvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping7runtimelECshXA3KcOxU02_8closures(ptr %3, ptr %5, i64 %7) #21
  ret void
}

; core::ptr::slice_from_raw_parts::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partslECshXA3KcOxU02_8closures(ptr %data, i64 %len) unnamed_addr #1 !guid !294 {
start:
; call core::ptr::metadata::from_raw_parts::<[i32], i32>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsSllECshXA3KcOxU02_8closures(ptr %data, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr %data, i64 %len) unnamed_addr #1 !guid !295 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>], alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB6_3ops8function2FnuEp6OutputjEL_EBX_ECshXA3KcOxU02_8closures(ptr %data, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtNtB4_3mem12maybe_uninit11MaybeUninitlEECshXA3KcOxU02_8closures(ptr %data, i64 %len) unnamed_addr #1 !guid !296 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[core::mem::maybe_uninit::MaybeUninit<i32>], core::mem::maybe_uninit::MaybeUninit<i32>>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEBX_ECshXA3KcOxU02_8closures(ptr %data, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutjECshXA3KcOxU02_8closures(ptr %data, i64 %len) unnamed_addr #1 !guid !297 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[usize], usize>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSjjECshXA3KcOxU02_8closures(ptr %data, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECshXA3KcOxU02_8closures(ptr %data, i64 %len) unnamed_addr #1 !guid !298 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[i32], i32>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSllECshXA3KcOxU02_8closures(ptr %data, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<dyn core::ops::function::Fn<(i32,), Output = i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueDINtNtNtB4_3ops8function2FnTlEEp6OutputlEL_ECshXA3KcOxU02_8closures(ptr %_1.0, ptr align 8 %_1.1) unnamed_addr #0 !guid !299 {
start:
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 0
  %1 = load ptr, ptr %0, align 8, !invariant.load !283
  %2 = icmp ne ptr %1, null
  br i1 %2, label %is_not_null, label %bb1

is_not_null:                                      ; preds = %start
  call void %1(ptr %_1.0) #21
  br label %bb1

bb1:                                              ; preds = %is_not_null, %start
  ret void
}

; core::ptr::drop_glue::<dyn core::ops::function::Fn<(), Output = usize>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueDINtNtNtB4_3ops8function2FnuEp6OutputjEL_ECshXA3KcOxU02_8closures(ptr %_1.0, ptr align 8 %_1.1) unnamed_addr #0 !guid !300 {
start:
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 0
  %1 = load ptr, ptr %0, align 8, !invariant.load !283
  %2 = icmp ne ptr %1, null
  br i1 %2, label %is_not_null, label %bb1

is_not_null:                                      ; preds = %start
  call void %1(ptr %_1.0) #21
  br label %bb1

bb1:                                              ; preds = %is_not_null, %start
  ret void
}

; core::ptr::drop_glue::<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtBG_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !301 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EENtNtB13_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecINtNtBG_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EEECshXA3KcOxU02_8closures(ptr align 8 %_1) #22
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecINtNtBG_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EEECshXA3KcOxU02_8closures(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<usize>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !302 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<usize> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecjEECshXA3KcOxU02_8closures(ptr align 8 %_1) #22
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<usize>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecjEECshXA3KcOxU02_8closures(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !303 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<i32> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeclEECshXA3KcOxU02_8closures(ptr align 8 %_1) #22
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeclEECshXA3KcOxU02_8closures(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::ops::function::Fn<(i32,), Output = i32>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnTlEEp6OutputlEL_EECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !304 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6.1, i64 0
  %3 = load ptr, ptr %2, align 8, !invariant.load !283
  %4 = icmp ne ptr %3, null
  br i1 %4, label %is_not_null, label %bb3

is_not_null:                                      ; preds = %start
  invoke void %3(ptr %_6.0)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %is_not_null, %start
; call <alloc::boxed::Box<dyn core::ops::function::Fn<(i32,), Output = i32>> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnTlEEp6OutputlEL_ENtNtBN_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1) #21
  ret void

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<dyn core::ops::function::Fn<(i32,), Output = i32>> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnTlEEp6OutputlEL_ENtNtBN_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1) #22
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %is_not_null
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb2:                                              ; preds = %bb4
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !305 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6.1, i64 0
  %3 = load ptr, ptr %2, align 8, !invariant.load !283
  %4 = icmp ne ptr %3, null
  br i1 %4, label %is_not_null, label %bb3

is_not_null:                                      ; preds = %start
  invoke void %3(ptr %_6.0)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %is_not_null, %start
; call <alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_ENtNtBN_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1) #21
  ret void

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_ENtNtBN_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1) #22
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %is_not_null
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb2:                                              ; preds = %bb4
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; core::ptr::drop_glue::<alloc::boxed::Box<[i32]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !306 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[i32]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1) #21
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<[i32]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1) #22
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb2:                                              ; preds = %bb4
  %3 = load ptr, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8
  %6 = insertvalue { ptr, i32 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i32 } %6, i32 %5, 1
  resume { ptr, i32 } %7
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecINtNtBG_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 !guid !307 {
start:
; call <alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EENtNtB1a_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<usize>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecjEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 !guid !308 {
start:
; call <alloc::raw_vec::RawVec<usize> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeclEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 !guid !309 {
start:
; call <alloc::raw_vec::RawVec<i32> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<(&str, fn(f64, f64) -> f64), 3>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterTReFddEdEKj3_EECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 !guid !310 {
start:
; call <core::array::iter::IntoIter<(&str, fn(f64, f64) -> f64), 3> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterTReFddEdEKj3_ENtNtNtB9_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1) #21
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitTReFddEdEEj3_EECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 !guid !311 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitTReFddEdEEj3_ENtNtNtBb_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1) #21
  ret void
}

; core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 !guid !312 {
start:
; call <core::slice::sort::shared::smallsort::CopyOnDrop<i32> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsortINtB5_10CopyOnDroplENtNtNtBd_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::slice::sort::stable::merge::MergeState<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6stable5merge10MergeStatelEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 !guid !313 {
start:
; call <core::slice::sort::stable::merge::MergeState<i32> as core::ops::drop::Drop>::drop
  call void @_RNvXs_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB4_10MergeStatelENtNtNtBc_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #0 !guid !314 {
start:
; call <core::hint::select_unpredictable::DropOnPanic<*const i32> as core::ops::drop::Drop>::drop
  call void @_RNvXNvNtCsl10jNU3mE6R_4core4hint20select_unpredictableINtB2_11DropOnPanicPlENtNtNtB6_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtBK_3VecINtNtBM_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EE14extend_trustedINtNtNtNtB4_4iter8adapters3map3MapINtNtB1I_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0EB3y_(ptr align 8 %_1) unnamed_addr #0 !guid !315 {
start:
; call core::ptr::drop_glue::<alloc::vec::set_len_on_drop::SetLenOnDrop>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtNtCs7CppTae75M1_5alloc3vec15set_len_on_drop12SetLenOnDropECsddYV2PBJW9h_3std(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<<alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtBK_3VecjE14extend_trustedINtNtNtNtB4_4iter8adapters3map3MapINtNtNtB4_5slice4iter4IterINtNtBM_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0EB3D_(ptr align 8 %_1) unnamed_addr #0 !guid !316 {
start:
; call core::ptr::drop_glue::<alloc::vec::set_len_on_drop::SetLenOnDrop>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtNtCs7CppTae75M1_5alloc3vec15set_len_on_drop12SetLenOnDropECsddYV2PBJW9h_3std(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::iter::adapters::map::map_fold<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldRINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EjuNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtB1m_3vecINtB4b_3VecjE14extend_trustedINtBG_3MapINtNtNtB4_5slice4iter4IterB1h_EB2y_EE0E0E0EB2C_(ptr align 8 %_1) unnamed_addr #0 !guid !317 {
start:
; call core::ptr::drop_glue::<core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1L_3VecjE14extend_trustedINtNtNtBO_8adapters3map3MapINtNtNtB4_5slice4iter4IterINtNtB1N_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0E0EB4z_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::iter::adapters::map::map_fold<usize, alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, (), closures::main::{closure#4}, core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldjINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EuNCNvCshXA3KcOxU02_8closures4mains2_0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4callB1h_NCINvMsk_NtB1m_3vecINtB4d_3VecB1h_E14extend_trustedINtBG_3MapINtNtB1W_5range5RangejEB2x_EE0E0E0EB2B_(ptr align 8 %_1) unnamed_addr #0 !guid !318 {
start:
; call core::ptr::drop_glue::<core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4callINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_ENCINvMsk_NtB1G_3vecINtB2Z_3VecB1B_E14extend_trustedINtNtNtBO_8adapters3map3MapINtNtB2g_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0E0EB4x_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4callINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_ENCINvMsk_NtB1G_3vecINtB2Z_3VecB1B_E14extend_trustedINtNtNtBO_8adapters3map3MapINtNtB2g_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0E0EB4x_(ptr align 8 %_1) unnamed_addr #0 !guid !319 {
start:
; call core::ptr::drop_glue::<<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtBK_3VecINtNtBM_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EE14extend_trustedINtNtNtNtB4_4iter8adapters3map3MapINtNtB1I_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0EB3y_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1L_3VecjE14extend_trustedINtNtNtBO_8adapters3map3MapINtNtNtB4_5slice4iter4IterINtNtB1N_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0E0EB4z_(ptr align 8 %_1) unnamed_addr #0 !guid !320 {
start:
; call core::ptr::drop_glue::<<alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtBK_3VecjE14extend_trustedINtNtNtNtB4_4iter8adapters3map3MapINtNtNtB4_5slice4iter4IterINtNtBM_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0EB3D_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<closures::main::{closure#10}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCNvCshXA3KcOxU02_8closures4mains8_0EBF_(ptr align 8 %_1) unnamed_addr #0 !guid !321 {
start:
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>]>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %_1.0, i64 %_1.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !322 {
start:
  %0 = alloca [16 x i8], align 8
  %_3 = alloca [8 x i8], align 8
  store i64 0, ptr %_3, align 8
  br label %bb6

bb6:                                              ; preds = %bb5, %start
  %1 = load i64, ptr %_3, align 8
  %_7 = icmp eq i64 %1, %_1.1
  br i1 %_7, label %bb1, label %bb5

bb5:                                              ; preds = %bb6
  %2 = load i64, ptr %_3, align 8
  %_6 = getelementptr inbounds nuw %"alloc::boxed::Box<dyn core::ops::function::Fn() -> usize>", ptr %_1.0, i64 %2
  %3 = load i64, ptr %_3, align 8
  %4 = add i64 %3, 1
  store i64 %4, ptr %_3, align 8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %_6)
          to label %bb6 unwind label %cleanup

bb1:                                              ; preds = %bb6
  ret void

bb4:                                              ; preds = %bb3, %cleanup
  %5 = load i64, ptr %_3, align 8
  %_5 = icmp eq i64 %5, %_1.1
  br i1 %_5, label %bb2, label %bb3

cleanup:                                          ; preds = %bb5
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb4

bb3:                                              ; preds = %bb4
  %10 = load i64, ptr %_3, align 8
  %_4 = getelementptr inbounds nuw %"alloc::boxed::Box<dyn core::ops::function::Fn() -> usize>", ptr %_1.0, i64 %10
  %11 = load i64, ptr %_3, align 8
  %12 = add i64 %11, 1
  store i64 %12, ptr %_3, align 8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %_4) #22
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb4
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr inbounds i8, ptr %0, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

terminate:                                        ; preds = %bb3
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable
}

; core::hint::black_box::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECshXA3KcOxU02_8closures(double %dummy) unnamed_addr #1 !guid !323 {
start:
  %_0 = alloca [8 x i8], align 8
  store double %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !324
  %0 = load double, ptr %_0, align 8
  ret double %0
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECshXA3KcOxU02_8closures(i8 %dummy) unnamed_addr #1 !guid !325 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !324
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshXA3KcOxU02_8closures(i32 %dummy) unnamed_addr #1 !guid !326 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !324
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECshXA3KcOxU02_8closures(i64 %dummy) unnamed_addr #1 !guid !327 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !324
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshXA3KcOxU02_8closures(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !328 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshXA3KcOxU02_8closures(ptr %f) #21
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #21
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[i32], i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsSllECshXA3KcOxU02_8closures(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !329 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>], alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB6_3ops8function2FnuEp6OutputjEL_EBX_ECshXA3KcOxU02_8closures(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !330 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[core::mem::maybe_uninit::MaybeUninit<i32>], core::mem::maybe_uninit::MaybeUninit<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEBX_ECshXA3KcOxU02_8closures(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !331 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[usize], usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSjjECshXA3KcOxU02_8closures(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !332 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[i32], i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSllECshXA3KcOxU02_8closures(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !333 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitTReFddEdEEECshXA3KcOxU02_8closures(ptr %ptr.0, i64 %ptr.1) unnamed_addr #1 !guid !334 {
start:
  ret i64 %ptr.1
}

; core::ptr::metadata::metadata::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSlECshXA3KcOxU02_8closures(ptr %ptr.0, i64 %ptr.1) unnamed_addr #1 !guid !335 {
start:
  ret i64 %ptr.1
}

; core::slice::raw::from_raw_parts::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partslECshXA3KcOxU02_8closures(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #1 !guid !336 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts::<i32>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partslECshXA3KcOxU02_8closures(ptr %data, i64 %len) #21
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCshXA3KcOxU02_8closures(ptr %data, i64 4, i64 4, i64 %len, ptr align 8 %0) #24
  br label %bb5
}

; core::slice::raw::from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEECshXA3KcOxU02_8closures(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #1 !guid !337 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtNtB4_3mem12maybe_uninit11MaybeUninitlEECshXA3KcOxU02_8closures(ptr %data, i64 %len) #21
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts_mut::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCshXA3KcOxU02_8closures(ptr %data, i64 4, i64 4, i64 %len, ptr align 8 %0) #24
  br label %bb5
}

; core::slice::raw::from_raw_parts_mut::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECshXA3KcOxU02_8closures(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #1 !guid !338 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts_mut::<i32>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECshXA3KcOxU02_8closures(ptr %data, i64 %len) #21
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts_mut::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCshXA3KcOxU02_8closures(ptr %data, i64 4, i64 4, i64 %len, ptr align 8 %0) #24
  br label %bb5
}

; core::iter::adapters::map::map_fold::<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_EjuNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvNtNtNtB6_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtBY_3vecINtB3N_3VecjE14extend_trustedINtB2_3MapINtNtNtB8_5slice4iter4IterBT_EB2a_EE0E0EB2e_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %g) unnamed_addr #0 !guid !339 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %g, i64 24, i1 false)
  ret void
}

; core::iter::adapters::map::map_fold::<usize, alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, (), closures::main::{closure#4}, core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldjINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_EuNCNvCshXA3KcOxU02_8closures4mains2_0NCINvNvNtNtNtB6_6traits8iterator8Iterator8for_each4callBT_NCINvMsk_NtBY_3vecINtB3O_3VecBT_E14extend_trustedINtB2_3MapINtNtB1y_5range5RangejEB29_EE0E0EB2d_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %g) unnamed_addr #0 !guid !340 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %g, i64 24, i1 false)
  ret void
}

; core::slice::sort::stable::driftsort_main::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}, alloc::vec::Vec<i32>>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable14driftsort_mainlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0INtNtB18_3vec3VeclEEB1M_(ptr align 4 %v.0, i64 %v.1, ptr align 8 %is_less) unnamed_addr #3 personality ptr @rust_eh_personality !guid !341 {
start:
  %0 = alloca [16 x i8], align 8
  %_30 = alloca [1 x i8], align 1
  %_23 = alloca [24 x i8], align 8
  %scratch = alloca [16 x i8], align 8
  %heap_buf = alloca [24 x i8], align 8
  %stack_buf = alloca [4096 x i8], align 4
  store i8 0, ptr %_30, align 1
  %_5 = icmp eq i64 4, 0
  br i1 %_5, label %panic, label %bb2

bb2:                                              ; preds = %start
  %max_full_alloc = udiv i64 8000000, 4
  %_11 = udiv i64 %v.1, 2
  %_10 = sub i64 %v.1, %_11
; call core::cmp::min::<usize>
  %_13 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %v.1, i64 %max_full_alloc) #21
; call core::cmp::max::<usize>
  %_9 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64 %_10, i64 %_13) #21
; call core::cmp::max::<usize>
  %alloc_len = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64 %_9, i64 48) #21
; call <core::slice::sort::stable::AlignedStorage<i32, 4096>>::new
  call void @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStoragelKj1000_E3newCshXA3KcOxU02_8closures(ptr sret([4096 x i8]) align 4 %stack_buf)
; call <core::slice::sort::stable::AlignedStorage<i32, 4096>>::as_uninit_slice_mut
  %1 = call { ptr, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStoragelKj1000_E19as_uninit_slice_mutCshXA3KcOxU02_8closures(ptr align 4 %stack_buf)
  %stack_scratch.0 = extractvalue { ptr, i64 } %1, 0
  %stack_scratch.1 = extractvalue { ptr, i64 } %1, 1
  %_19 = icmp uge i64 %stack_scratch.1, %alloc_len
  br i1 %_19, label %bb9, label %bb10

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_63f80f9ffc23059c68b68d596767dcd4) #25
  unreachable

bb10:                                             ; preds = %bb2
; invoke <alloc::vec::Vec<i32> as core::slice::sort::stable::BufGuard<i32>>::with_capacity
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VeclEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardlE13with_capacityCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_23, i64 %alloc_len)
          to label %bb11 unwind label %cleanup

bb9:                                              ; preds = %bb2
  store ptr %stack_scratch.0, ptr %scratch, align 8
  %2 = getelementptr inbounds i8, ptr %scratch, i64 8
  store i64 %stack_scratch.1, ptr %2, align 8
  br label %bb13

bb20:                                             ; preds = %cleanup
  %3 = load i8, ptr %_30, align 1
  %4 = trunc nuw i8 %3 to i1
  br i1 %4, label %bb19, label %bb17

cleanup:                                          ; preds = %bb14, %bb11, %bb10
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb20

bb11:                                             ; preds = %bb10
  store i8 1, ptr %_30, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %heap_buf, ptr align 8 %_23, i64 24, i1 false)
; invoke <alloc::vec::Vec<i32> as core::slice::sort::stable::BufGuard<i32>>::as_uninit_slice_mut
  %9 = invoke { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VeclEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardlE19as_uninit_slice_mutCshXA3KcOxU02_8closures(ptr align 8 %heap_buf)
          to label %bb12 unwind label %cleanup

bb12:                                             ; preds = %bb11
  %_22.0 = extractvalue { ptr, i64 } %9, 0
  %_22.1 = extractvalue { ptr, i64 } %9, 1
  store ptr %_22.0, ptr %scratch, align 8
  %10 = getelementptr inbounds i8, ptr %scratch, i64 8
  store i64 %_22.1, ptr %10, align 8
  br label %bb13

bb13:                                             ; preds = %bb9, %bb12
  br label %bb14

bb14:                                             ; preds = %bb13
  %_26 = mul i64 32, 2
  %eager_sort = icmp ule i64 %v.1, %_26
  %_29.0 = load ptr, ptr %scratch, align 8
  %11 = getelementptr inbounds i8, ptr %scratch, i64 8
  %_29.1 = load i64, ptr %11, align 8
; invoke core::slice::sort::stable::drift::sort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  invoke void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift4sortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1J_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %_29.0, i64 %_29.1, i1 zeroext %eager_sort, ptr align 8 %is_less)
          to label %bb15 unwind label %cleanup

bb15:                                             ; preds = %bb14
  %12 = load i8, ptr %_30, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb18, label %bb16

bb16:                                             ; preds = %bb18, %bb15
  store i8 0, ptr %_30, align 1
  ret void

bb18:                                             ; preds = %bb15
; call core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECshXA3KcOxU02_8closures(ptr align 8 %heap_buf)
  br label %bb16

bb17:                                             ; preds = %bb19, %bb20
  %14 = load ptr, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  %16 = load i32, ptr %15, align 8
  %17 = insertvalue { ptr, i32 } poison, ptr %14, 0
  %18 = insertvalue { ptr, i32 } %17, i32 %16, 1
  resume { ptr, i32 } %18

bb19:                                             ; preds = %bb20
; invoke core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECshXA3KcOxU02_8closures(ptr align 8 %heap_buf) #22
          to label %bb17 unwind label %terminate

terminate:                                        ; preds = %bb19
  %19 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable
}

; core::slice::sort::shared::pivot::median3_rec::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_(ptr %0, ptr %1, ptr %2, i64 %n, ptr align 8 %is_less) unnamed_addr #0 !guid !342 {
start:
  %_0.i = alloca [8 x i8], align 8
  %c = alloca [8 x i8], align 8
  %b = alloca [8 x i8], align 8
  %a = alloca [8 x i8], align 8
  store ptr %0, ptr %a, align 8
  store ptr %1, ptr %b, align 8
  store ptr %2, ptr %c, align 8
  %_7 = mul i64 %n, 8
  %_6 = icmp uge i64 %_7, 64
  br i1 %_6, label %bb1, label %bb12

bb12:                                             ; preds = %bb1, %start
  %_34 = load ptr, ptr %a, align 8
  %_35 = load ptr, ptr %b, align 8
  %_36 = load ptr, ptr %c, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %x.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_34, ptr align 4 %_35) #21
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %y.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_34, ptr align 4 %_36) #21
  %_9.i = icmp eq i1 %x.i, %y.i
  br i1 %_9.i, label %bb3.i, label %bb7.i

bb7.i:                                            ; preds = %bb12
  store ptr %_34, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1M_.exit

bb3.i:                                            ; preds = %bb12
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %z.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_35, ptr align 4 %_36) #21
  %_12.i = xor i1 %z.i, %x.i
  br i1 %_12.i, label %bb5.i, label %bb6.i

bb6.i:                                            ; preds = %bb3.i
  store ptr %_35, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1M_.exit

bb5.i:                                            ; preds = %bb3.i
  store ptr %_36, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1M_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1M_.exit: ; preds = %bb7.i, %bb6.i, %bb5.i
  %3 = load ptr, ptr %_0.i, align 8
  ret ptr %3

bb1:                                              ; preds = %start
  %n8 = udiv i64 %n, 8
  %_11 = load ptr, ptr %a, align 8
  %_13 = load ptr, ptr %a, align 8
  %_14 = mul i64 %n8, 4
  %_0.i6 = getelementptr inbounds nuw i32, ptr %_13, i64 %_14
  %_16 = load ptr, ptr %a, align 8
  %_17 = mul i64 %n8, 7
  %_0.i5 = getelementptr inbounds nuw i32, ptr %_16, i64 %_17
; call core::slice::sort::shared::pivot::median3_rec::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  %_10 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_(ptr %_11, ptr %_0.i6, ptr %_0.i5, i64 %n8, ptr align 8 %is_less)
  store ptr %_10, ptr %a, align 8
  %_19 = load ptr, ptr %b, align 8
  %_21 = load ptr, ptr %b, align 8
  %_22 = mul i64 %n8, 4
  %_0.i4 = getelementptr inbounds nuw i32, ptr %_21, i64 %_22
  %_24 = load ptr, ptr %b, align 8
  %_25 = mul i64 %n8, 7
  %_0.i3 = getelementptr inbounds nuw i32, ptr %_24, i64 %_25
; call core::slice::sort::shared::pivot::median3_rec::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  %_18 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_(ptr %_19, ptr %_0.i4, ptr %_0.i3, i64 %n8, ptr align 8 %is_less)
  store ptr %_18, ptr %b, align 8
  %_27 = load ptr, ptr %c, align 8
  %_29 = load ptr, ptr %c, align 8
  %_30 = mul i64 %n8, 4
  %_0.i2 = getelementptr inbounds nuw i32, ptr %_29, i64 %_30
  %_32 = load ptr, ptr %c, align 8
  %_33 = mul i64 %n8, 7
  %_0.i1 = getelementptr inbounds nuw i32, ptr %_32, i64 %_33
; call core::slice::sort::shared::pivot::median3_rec::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  %_26 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_(ptr %_27, ptr %_0.i2, ptr %_0.i1, i64 %n8, ptr align 8 %is_less)
  store ptr %_26, ptr %c, align 8
  br label %bb12
}

; core::slice::sort::shared::pivot::choose_pivot::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot12choose_pivotlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1S_(ptr align 4 %v.0, i64 %v.1, ptr align 8 %is_less) unnamed_addr #1 !guid !343 {
start:
  %_0.i = alloca [8 x i8], align 8
  %index = alloca [8 x i8], align 8
  %_4 = icmp ult i64 %v.1, 8
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %len_div_8 = udiv i64 %v.1, 8
  %_11 = mul i64 %len_div_8, 4
  %_0.i2 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_11
  %_13 = mul i64 %len_div_8, 7
  %_0.i1 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_13
  %_14 = icmp ult i64 %v.1, 64
  br i1 %_14, label %bb7, label %bb9

bb1:                                              ; preds = %start
  call void @llvm.trap()
  unreachable

bb9:                                              ; preds = %bb2
; call core::slice::sort::shared::pivot::median3_rec::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  %_19 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_(ptr %v.0, ptr %_0.i2, ptr %_0.i1, i64 %len_div_8, ptr align 8 %is_less)
; call <*const i32>::offset_from_unsigned
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPl20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %_19, ptr %v.0, ptr align 8 @alloc_f0b38f15064fc95bc0114a55e7ca2131) #21
  store i64 %0, ptr %index, align 8
  br label %bb11

bb7:                                              ; preds = %bb2
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %x.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %v.0, ptr align 4 %_0.i2) #21
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %y.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %v.0, ptr align 4 %_0.i1) #21
  %_9.i = icmp eq i1 %x.i, %y.i
  br i1 %_9.i, label %bb3.i, label %bb7.i

bb7.i:                                            ; preds = %bb7
  store ptr %v.0, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1M_.exit

bb3.i:                                            ; preds = %bb7
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %z.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_0.i2, ptr align 4 %_0.i1) #21
  %_12.i = xor i1 %z.i, %x.i
  br i1 %_12.i, label %bb5.i, label %bb6.i

bb6.i:                                            ; preds = %bb3.i
  store ptr %_0.i2, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1M_.exit

bb5.i:                                            ; preds = %bb3.i
  store ptr %_0.i1, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1M_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1M_.exit: ; preds = %bb7.i, %bb6.i, %bb5.i
  %1 = load ptr, ptr %_0.i, align 8
; call <*const i32>::offset_from_unsigned
  %2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPl20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %1, ptr %v.0, ptr align 8 @alloc_1824be00902e801da9c2923e0e00ce0b) #21
  store i64 %2, ptr %index, align 8
  br label %bb11

bb11:                                             ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1M_.exit, %bb9
  %_22 = load i64, ptr %index, align 8
  %_21 = icmp ult i64 %_22, %v.1
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb11
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCshXA3KcOxU02_8closures(i1 zeroext %_21, ptr align 8 @alloc_ab4c6a2d756e35f752701a51dadd262d) #24
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb11, %bb2.i
  %_0 = load i64, ptr %index, align 8
  ret i64 %_0
}

; core::slice::sort::shared::smallsort::insert_tail::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort11insert_taillNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1V_(ptr %begin, ptr %tail, ptr align 8 %is_less) unnamed_addr #0 personality ptr @rust_eh_personality !guid !344 {
start:
  %_0.i3 = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %0 = alloca [16 x i8], align 8
  %gap_guard = alloca [24 x i8], align 8
  %tmp = alloca [4 x i8], align 4
  %sift = alloca [8 x i8], align 8
  %1 = getelementptr inbounds i32, ptr %tail, i64 -1
  store ptr %1, ptr %_0.i3, align 8
  %2 = load ptr, ptr %_0.i3, align 8
  store ptr %2, ptr %sift, align 8
  %_8 = load ptr, ptr %sift, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_5 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %tail, ptr align 4 %_8) #21
  br i1 %_5, label %bb3, label %bb14

bb14:                                             ; preds = %bb13, %start
  ret void

bb3:                                              ; preds = %start
  %_0.i.i = load i32, ptr %tail, align 4
; call <core::mem::maybe_dangling::MaybeDangling<i32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCsddYV2PBJW9h_3std(i32 %_0.i.i)
  store i32 %_2.i, ptr %tmp, align 4
; call <core::mem::maybe_dangling::MaybeDangling<i32>>::as_ref
  %_0.i7 = call align 4 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE6as_refCshXA3KcOxU02_8closures(ptr align 4 %tmp)
  store ptr %_0.i7, ptr %gap_guard, align 8
  %3 = getelementptr inbounds i8, ptr %gap_guard, i64 8
  store ptr %tail, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %gap_guard, i64 16
  store i64 1, ptr %4, align 8
  br label %bb7

bb7:                                              ; preds = %bb12, %bb3
  %_17 = load ptr, ptr %sift, align 8
  %5 = getelementptr inbounds i8, ptr %gap_guard, i64 8
  %_18 = load ptr, ptr %5, align 8
; invoke core::ub_checks::check_language_ub
  %_4.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
          to label %_4.i.noexc unwind label %cleanup

_4.i.noexc:                                       ; preds = %bb7
  br i1 %_4.i1, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %_4.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_17, ptr %_18, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %_4.i.noexc, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_18, ptr align 4 %_17, i64 4, i1 false)
  br label %bb8

bb15:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECshXA3KcOxU02_8closures(ptr align 8 %gap_guard) #22
          to label %bb16 unwind label %terminate

cleanup:                                          ; preds = %bb10, %bb7, %bb11
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb15

bb8:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit
  %_19 = load ptr, ptr %sift, align 8
  %10 = getelementptr inbounds i8, ptr %gap_guard, i64 8
  store ptr %_19, ptr %10, align 8
  %_21 = load ptr, ptr %sift, align 8
  %_20 = icmp eq ptr %_21, %begin
  br i1 %_20, label %bb13, label %bb9

bb9:                                              ; preds = %bb8
  %_23 = load ptr, ptr %sift, align 8
  %11 = getelementptr inbounds i32, ptr %_23, i64 -1
  store ptr %11, ptr %_0.i, align 8
  %12 = load ptr, ptr %_0.i, align 8
  br label %bb10

bb13:                                             ; preds = %bb12, %bb8
; call core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECshXA3KcOxU02_8closures(ptr align 8 %gap_guard)
  br label %bb14

bb10:                                             ; preds = %bb9
  store ptr %12, ptr %sift, align 8
; invoke <core::mem::maybe_dangling::MaybeDangling<i32>>::as_ref
  %_0.i56 = invoke align 4 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE6as_refCshXA3KcOxU02_8closures(ptr align 4 %tmp)
          to label %_RNvXs0_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB5_12ManuallyDroplENtNtNtB9_3ops5deref5Deref5derefCshXA3KcOxU02_8closures.exit unwind label %cleanup

_RNvXs0_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB5_12ManuallyDroplENtNtNtB9_3ops5deref5Deref5derefCshXA3KcOxU02_8closures.exit: ; preds = %bb10
  br label %bb11

bb11:                                             ; preds = %_RNvXs0_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB5_12ManuallyDroplENtNtNtB9_3ops5deref5Deref5derefCshXA3KcOxU02_8closures.exit
  %_28 = load ptr, ptr %sift, align 8
; invoke <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_24 = invoke zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_0.i56, ptr align 4 %_28)
          to label %bb12 unwind label %cleanup

bb12:                                             ; preds = %bb11
  br i1 %_24, label %bb7, label %bb13

terminate:                                        ; preds = %bb15
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb16:                                             ; preds = %bb15
  %14 = load ptr, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  %16 = load i32, ptr %15, align 8
  %17 = insertvalue { ptr, i32 } poison, ptr %14, 0
  %18 = insertvalue { ptr, i32 } %17, i32 %16, 1
  resume { ptr, i32 } %18
}

; core::slice::sort::shared::smallsort::sort4_stable::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr %v_base, ptr %dst, ptr align 8 %is_less) unnamed_addr #0 personality ptr @rust_eh_personality !guid !345 {
start:
  %0 = alloca [16 x i8], align 8
  %_21.i155 = alloca [1 x i8], align 1
  %_20.i156 = alloca [1 x i8], align 1
  %guard.i157 = alloca [8 x i8], align 8
  %false_val2.i158 = alloca [8 x i8], align 8
  %true_val1.i159 = alloca [8 x i8], align 8
  %1 = alloca [16 x i8], align 8
  %_21.i131 = alloca [1 x i8], align 1
  %_20.i132 = alloca [1 x i8], align 1
  %guard.i133 = alloca [8 x i8], align 8
  %false_val2.i134 = alloca [8 x i8], align 8
  %true_val1.i135 = alloca [8 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %_21.i107 = alloca [1 x i8], align 1
  %_20.i108 = alloca [1 x i8], align 1
  %guard.i109 = alloca [8 x i8], align 8
  %false_val2.i110 = alloca [8 x i8], align 8
  %true_val1.i111 = alloca [8 x i8], align 8
  %3 = alloca [16 x i8], align 8
  %_21.i83 = alloca [1 x i8], align 1
  %_20.i84 = alloca [1 x i8], align 1
  %guard.i85 = alloca [8 x i8], align 8
  %false_val2.i86 = alloca [8 x i8], align 8
  %true_val1.i87 = alloca [8 x i8], align 8
  %4 = alloca [16 x i8], align 8
  %_21.i59 = alloca [1 x i8], align 1
  %_20.i60 = alloca [1 x i8], align 1
  %guard.i61 = alloca [8 x i8], align 8
  %false_val2.i62 = alloca [8 x i8], align 8
  %true_val1.i63 = alloca [8 x i8], align 8
  %5 = alloca [16 x i8], align 8
  %_21.i35 = alloca [1 x i8], align 1
  %_20.i36 = alloca [1 x i8], align 1
  %guard.i37 = alloca [8 x i8], align 8
  %false_val2.i38 = alloca [8 x i8], align 8
  %true_val1.i39 = alloca [8 x i8], align 8
  %6 = alloca [16 x i8], align 8
  %_21.i11 = alloca [1 x i8], align 1
  %_20.i12 = alloca [1 x i8], align 1
  %guard.i13 = alloca [8 x i8], align 8
  %false_val2.i14 = alloca [8 x i8], align 8
  %true_val1.i15 = alloca [8 x i8], align 8
  %7 = alloca [16 x i8], align 8
  %_21.i = alloca [1 x i8], align 1
  %_20.i = alloca [1 x i8], align 1
  %guard.i = alloca [8 x i8], align 8
  %false_val2.i = alloca [8 x i8], align 8
  %true_val1.i = alloca [8 x i8], align 8
  %_0.i188 = getelementptr inbounds nuw i32, ptr %v_base, i64 1
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %c1 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_0.i188, ptr align 4 %v_base) #21
  %_0.i187 = getelementptr inbounds nuw i32, ptr %v_base, i64 3
  %_0.i186 = getelementptr inbounds nuw i32, ptr %v_base, i64 2
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %c2 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_0.i187, ptr align 4 %_0.i186) #21
  %_16 = zext i1 %c1 to i64
  %_0.i185 = getelementptr inbounds nuw i32, ptr %v_base, i64 %_16
  %_19 = xor i1 %c1, true
  %_18 = zext i1 %_19 to i64
  %_0.i184 = getelementptr inbounds nuw i32, ptr %v_base, i64 %_18
  %_22 = zext i1 %c2 to i64
  %_21 = add i64 2, %_22
  %_0.i183 = getelementptr inbounds nuw i32, ptr %v_base, i64 %_21
  %_26 = xor i1 %c2, true
  %_25 = zext i1 %_26 to i64
  %_24 = add i64 2, %_25
  %_0.i182 = getelementptr inbounds nuw i32, ptr %v_base, i64 %_24
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %c3 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_0.i183, ptr align 4 %_0.i185) #21
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %c4 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_0.i182, ptr align 4 %_0.i184) #21
  store i8 0, ptr %_21.i155, align 1
  store i8 0, ptr %_20.i156, align 1
  store i8 1, ptr %_21.i155, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i212 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i183)
  store ptr %_2.i.i212, ptr %true_val1.i159, align 8
  store i8 0, ptr %_21.i155, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i185)
  store ptr %_2.i.i, ptr %false_val2.i158, align 8
  %guard3.i163 = select i1 %c3, ptr %true_val1.i159, ptr %false_val2.i158, !unpredictable !283
  %drop.i164 = select i1 %c3, ptr %false_val2.i158, ptr %true_val1.i159, !unpredictable !283
  store i8 1, ptr %_20.i156, align 1
  store ptr %guard3.i163, ptr %guard.i157, align 8
  br label %bb7.i171

cleanup.i165:                                     ; preds = %bb8.i173, %bb7.i171
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %10, ptr %11, align 8
  %12 = load i8, ptr %_20.i156, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb12.i169, label %bb15.i166

bb7.i171:                                         ; preds = %start
  store i8 0, ptr %_20.i156, align 1
  %_16.i172 = load ptr, ptr %guard.i157, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr %_16.i172)
          to label %bb8.i173 unwind label %cleanup.i165

bb8.i173:                                         ; preds = %bb7.i171
  %_18.i174 = load ptr, ptr %true_val1.i159, align 8
  %_19.i175 = load ptr, ptr %false_val2.i158, align 8
  %_17.i176 = select i1 %c3, ptr %_18.i174, ptr %_19.i175, !unpredictable !283
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i189190 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECshXA3KcOxU02_8closures(ptr %_17.i176) #21
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit unwind label %cleanup.i165

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit: ; preds = %bb8.i173
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit178

bb15.i166:                                        ; preds = %bb12.i169, %cleanup.i165
  %14 = load i8, ptr %_21.i155, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb14.i168, label %bb11.i167

bb12.i169:                                        ; preds = %cleanup.i165
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr align 8 %guard.i157) #22
          to label %bb15.i166 unwind label %terminate.i170

terminate.i170:                                   ; preds = %bb12.i169
  %16 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb11.i167:                                        ; preds = %bb14.i168, %bb15.i166
  %17 = load ptr, ptr %0, align 8
  %18 = getelementptr inbounds i8, ptr %0, i64 8
  %19 = load i32, ptr %18, align 8
  %20 = insertvalue { ptr, i32 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i32 } %20, i32 %19, 1
  resume { ptr, i32 } %21

bb14.i168:                                        ; preds = %bb15.i166
  br label %bb11.i167

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit178: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit
  store i8 0, ptr %_20.i156, align 1
  store i8 0, ptr %_21.i131, align 1
  store i8 0, ptr %_20.i132, align 1
  store i8 1, ptr %_21.i131, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i214 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i184)
  store ptr %_2.i.i214, ptr %true_val1.i135, align 8
  store i8 0, ptr %_21.i131, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i213 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i182)
  store ptr %_2.i.i213, ptr %false_val2.i134, align 8
  %guard3.i139 = select i1 %c4, ptr %true_val1.i135, ptr %false_val2.i134, !unpredictable !283
  %drop.i140 = select i1 %c4, ptr %false_val2.i134, ptr %true_val1.i135, !unpredictable !283
  store i8 1, ptr %_20.i132, align 1
  store ptr %guard3.i139, ptr %guard.i133, align 8
  br label %bb7.i147

cleanup.i141:                                     ; preds = %bb8.i149, %bb7.i147
  %22 = landingpad { ptr, i32 }
          cleanup
  %23 = extractvalue { ptr, i32 } %22, 0
  %24 = extractvalue { ptr, i32 } %22, 1
  store ptr %23, ptr %1, align 8
  %25 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %24, ptr %25, align 8
  %26 = load i8, ptr %_20.i132, align 1
  %27 = trunc nuw i8 %26 to i1
  br i1 %27, label %bb12.i145, label %bb15.i142

bb7.i147:                                         ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit178
  store i8 0, ptr %_20.i132, align 1
  %_16.i148 = load ptr, ptr %guard.i133, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr %_16.i148)
          to label %bb8.i149 unwind label %cleanup.i141

bb8.i149:                                         ; preds = %bb7.i147
  %_18.i150 = load ptr, ptr %true_val1.i135, align 8
  %_19.i151 = load ptr, ptr %false_val2.i134, align 8
  %_17.i152 = select i1 %c4, ptr %_18.i150, ptr %_19.i151, !unpredictable !283
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i191192 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECshXA3KcOxU02_8closures(ptr %_17.i152) #21
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit193 unwind label %cleanup.i141

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit193: ; preds = %bb8.i149
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit154

bb15.i142:                                        ; preds = %bb12.i145, %cleanup.i141
  %28 = load i8, ptr %_21.i131, align 1
  %29 = trunc nuw i8 %28 to i1
  br i1 %29, label %bb14.i144, label %bb11.i143

bb12.i145:                                        ; preds = %cleanup.i141
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr align 8 %guard.i133) #22
          to label %bb15.i142 unwind label %terminate.i146

terminate.i146:                                   ; preds = %bb12.i145
  %30 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb11.i143:                                        ; preds = %bb14.i144, %bb15.i142
  %31 = load ptr, ptr %1, align 8
  %32 = getelementptr inbounds i8, ptr %1, i64 8
  %33 = load i32, ptr %32, align 8
  %34 = insertvalue { ptr, i32 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i32 } %34, i32 %33, 1
  resume { ptr, i32 } %35

bb14.i144:                                        ; preds = %bb15.i142
  br label %bb11.i143

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit154: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit193
  store i8 0, ptr %_20.i132, align 1
  store i8 0, ptr %_21.i107, align 1
  store i8 0, ptr %_20.i108, align 1
  store i8 1, ptr %_21.i107, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i216 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i183)
  store ptr %_2.i.i216, ptr %true_val1.i111, align 8
  store i8 0, ptr %_21.i107, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i215 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i184)
  store ptr %_2.i.i215, ptr %false_val2.i110, align 8
  %guard3.i115 = select i1 %c4, ptr %true_val1.i111, ptr %false_val2.i110, !unpredictable !283
  %drop.i116 = select i1 %c4, ptr %false_val2.i110, ptr %true_val1.i111, !unpredictable !283
  store i8 1, ptr %_20.i108, align 1
  store ptr %guard3.i115, ptr %guard.i109, align 8
  br label %bb7.i123

cleanup.i117:                                     ; preds = %bb8.i125, %bb7.i123
  %36 = landingpad { ptr, i32 }
          cleanup
  %37 = extractvalue { ptr, i32 } %36, 0
  %38 = extractvalue { ptr, i32 } %36, 1
  store ptr %37, ptr %2, align 8
  %39 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %38, ptr %39, align 8
  %40 = load i8, ptr %_20.i108, align 1
  %41 = trunc nuw i8 %40 to i1
  br i1 %41, label %bb12.i121, label %bb15.i118

bb7.i123:                                         ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit154
  store i8 0, ptr %_20.i108, align 1
  %_16.i124 = load ptr, ptr %guard.i109, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr %_16.i124)
          to label %bb8.i125 unwind label %cleanup.i117

bb8.i125:                                         ; preds = %bb7.i123
  %_18.i126 = load ptr, ptr %true_val1.i111, align 8
  %_19.i127 = load ptr, ptr %false_val2.i110, align 8
  %_17.i128 = select i1 %c4, ptr %_18.i126, ptr %_19.i127, !unpredictable !283
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i194195 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECshXA3KcOxU02_8closures(ptr %_17.i128) #21
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit196 unwind label %cleanup.i117

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit196: ; preds = %bb8.i125
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit130

bb15.i118:                                        ; preds = %bb12.i121, %cleanup.i117
  %42 = load i8, ptr %_21.i107, align 1
  %43 = trunc nuw i8 %42 to i1
  br i1 %43, label %bb14.i120, label %bb11.i119

bb12.i121:                                        ; preds = %cleanup.i117
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr align 8 %guard.i109) #22
          to label %bb15.i118 unwind label %terminate.i122

terminate.i122:                                   ; preds = %bb12.i121
  %44 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb11.i119:                                        ; preds = %bb14.i120, %bb15.i118
  %45 = load ptr, ptr %2, align 8
  %46 = getelementptr inbounds i8, ptr %2, i64 8
  %47 = load i32, ptr %46, align 8
  %48 = insertvalue { ptr, i32 } poison, ptr %45, 0
  %49 = insertvalue { ptr, i32 } %48, i32 %47, 1
  resume { ptr, i32 } %49

bb14.i120:                                        ; preds = %bb15.i118
  br label %bb11.i119

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit130: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit196
  store i8 0, ptr %_20.i108, align 1
  store i8 0, ptr %_21.i83, align 1
  store i8 0, ptr %_20.i84, align 1
  store i8 1, ptr %_21.i83, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i218 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i185)
  store ptr %_2.i.i218, ptr %true_val1.i87, align 8
  store i8 0, ptr %_21.i83, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i217 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i194195)
  store ptr %_2.i.i217, ptr %false_val2.i86, align 8
  %guard3.i91 = select i1 %c3, ptr %true_val1.i87, ptr %false_val2.i86, !unpredictable !283
  %drop.i92 = select i1 %c3, ptr %false_val2.i86, ptr %true_val1.i87, !unpredictable !283
  store i8 1, ptr %_20.i84, align 1
  store ptr %guard3.i91, ptr %guard.i85, align 8
  br label %bb7.i99

cleanup.i93:                                      ; preds = %bb8.i101, %bb7.i99
  %50 = landingpad { ptr, i32 }
          cleanup
  %51 = extractvalue { ptr, i32 } %50, 0
  %52 = extractvalue { ptr, i32 } %50, 1
  store ptr %51, ptr %3, align 8
  %53 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %52, ptr %53, align 8
  %54 = load i8, ptr %_20.i84, align 1
  %55 = trunc nuw i8 %54 to i1
  br i1 %55, label %bb12.i97, label %bb15.i94

bb7.i99:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit130
  store i8 0, ptr %_20.i84, align 1
  %_16.i100 = load ptr, ptr %guard.i85, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr %_16.i100)
          to label %bb8.i101 unwind label %cleanup.i93

bb8.i101:                                         ; preds = %bb7.i99
  %_18.i102 = load ptr, ptr %true_val1.i87, align 8
  %_19.i103 = load ptr, ptr %false_val2.i86, align 8
  %_17.i104 = select i1 %c3, ptr %_18.i102, ptr %_19.i103, !unpredictable !283
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i197198 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECshXA3KcOxU02_8closures(ptr %_17.i104) #21
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit199 unwind label %cleanup.i93

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit199: ; preds = %bb8.i101
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit106

bb15.i94:                                         ; preds = %bb12.i97, %cleanup.i93
  %56 = load i8, ptr %_21.i83, align 1
  %57 = trunc nuw i8 %56 to i1
  br i1 %57, label %bb14.i96, label %bb11.i95

bb12.i97:                                         ; preds = %cleanup.i93
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr align 8 %guard.i85) #22
          to label %bb15.i94 unwind label %terminate.i98

terminate.i98:                                    ; preds = %bb12.i97
  %58 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb11.i95:                                         ; preds = %bb14.i96, %bb15.i94
  %59 = load ptr, ptr %3, align 8
  %60 = getelementptr inbounds i8, ptr %3, i64 8
  %61 = load i32, ptr %60, align 8
  %62 = insertvalue { ptr, i32 } poison, ptr %59, 0
  %63 = insertvalue { ptr, i32 } %62, i32 %61, 1
  resume { ptr, i32 } %63

bb14.i96:                                         ; preds = %bb15.i94
  br label %bb11.i95

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit106: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit199
  store i8 0, ptr %_20.i84, align 1
  store i8 0, ptr %_21.i59, align 1
  store i8 0, ptr %_20.i60, align 1
  store i8 1, ptr %_21.i59, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i220 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i184)
  store ptr %_2.i.i220, ptr %true_val1.i63, align 8
  store i8 0, ptr %_21.i59, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i219 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i183)
  store ptr %_2.i.i219, ptr %false_val2.i62, align 8
  %guard3.i67 = select i1 %c3, ptr %true_val1.i63, ptr %false_val2.i62, !unpredictable !283
  %drop.i68 = select i1 %c3, ptr %false_val2.i62, ptr %true_val1.i63, !unpredictable !283
  store i8 1, ptr %_20.i60, align 1
  store ptr %guard3.i67, ptr %guard.i61, align 8
  br label %bb7.i75

cleanup.i69:                                      ; preds = %bb8.i77, %bb7.i75
  %64 = landingpad { ptr, i32 }
          cleanup
  %65 = extractvalue { ptr, i32 } %64, 0
  %66 = extractvalue { ptr, i32 } %64, 1
  store ptr %65, ptr %4, align 8
  %67 = getelementptr inbounds i8, ptr %4, i64 8
  store i32 %66, ptr %67, align 8
  %68 = load i8, ptr %_20.i60, align 1
  %69 = trunc nuw i8 %68 to i1
  br i1 %69, label %bb12.i73, label %bb15.i70

bb7.i75:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit106
  store i8 0, ptr %_20.i60, align 1
  %_16.i76 = load ptr, ptr %guard.i61, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr %_16.i76)
          to label %bb8.i77 unwind label %cleanup.i69

bb8.i77:                                          ; preds = %bb7.i75
  %_18.i78 = load ptr, ptr %true_val1.i63, align 8
  %_19.i79 = load ptr, ptr %false_val2.i62, align 8
  %_17.i80 = select i1 %c3, ptr %_18.i78, ptr %_19.i79, !unpredictable !283
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i200201 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECshXA3KcOxU02_8closures(ptr %_17.i80) #21
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit202 unwind label %cleanup.i69

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit202: ; preds = %bb8.i77
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit82

bb15.i70:                                         ; preds = %bb12.i73, %cleanup.i69
  %70 = load i8, ptr %_21.i59, align 1
  %71 = trunc nuw i8 %70 to i1
  br i1 %71, label %bb14.i72, label %bb11.i71

bb12.i73:                                         ; preds = %cleanup.i69
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr align 8 %guard.i61) #22
          to label %bb15.i70 unwind label %terminate.i74

terminate.i74:                                    ; preds = %bb12.i73
  %72 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb11.i71:                                         ; preds = %bb14.i72, %bb15.i70
  %73 = load ptr, ptr %4, align 8
  %74 = getelementptr inbounds i8, ptr %4, i64 8
  %75 = load i32, ptr %74, align 8
  %76 = insertvalue { ptr, i32 } poison, ptr %73, 0
  %77 = insertvalue { ptr, i32 } %76, i32 %75, 1
  resume { ptr, i32 } %77

bb14.i72:                                         ; preds = %bb15.i70
  br label %bb11.i71

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit82: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit202
  store i8 0, ptr %_20.i60, align 1
  store i8 0, ptr %_21.i35, align 1
  store i8 0, ptr %_20.i36, align 1
  store i8 1, ptr %_21.i35, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i222 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i182)
  store ptr %_2.i.i222, ptr %true_val1.i39, align 8
  store i8 0, ptr %_21.i35, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i221 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i200201)
  store ptr %_2.i.i221, ptr %false_val2.i38, align 8
  %guard3.i43 = select i1 %c4, ptr %true_val1.i39, ptr %false_val2.i38, !unpredictable !283
  %drop.i44 = select i1 %c4, ptr %false_val2.i38, ptr %true_val1.i39, !unpredictable !283
  store i8 1, ptr %_20.i36, align 1
  store ptr %guard3.i43, ptr %guard.i37, align 8
  br label %bb7.i51

cleanup.i45:                                      ; preds = %bb8.i53, %bb7.i51
  %78 = landingpad { ptr, i32 }
          cleanup
  %79 = extractvalue { ptr, i32 } %78, 0
  %80 = extractvalue { ptr, i32 } %78, 1
  store ptr %79, ptr %5, align 8
  %81 = getelementptr inbounds i8, ptr %5, i64 8
  store i32 %80, ptr %81, align 8
  %82 = load i8, ptr %_20.i36, align 1
  %83 = trunc nuw i8 %82 to i1
  br i1 %83, label %bb12.i49, label %bb15.i46

bb7.i51:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit82
  store i8 0, ptr %_20.i36, align 1
  %_16.i52 = load ptr, ptr %guard.i37, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr %_16.i52)
          to label %bb8.i53 unwind label %cleanup.i45

bb8.i53:                                          ; preds = %bb7.i51
  %_18.i54 = load ptr, ptr %true_val1.i39, align 8
  %_19.i55 = load ptr, ptr %false_val2.i38, align 8
  %_17.i56 = select i1 %c4, ptr %_18.i54, ptr %_19.i55, !unpredictable !283
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i203204 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECshXA3KcOxU02_8closures(ptr %_17.i56) #21
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit205 unwind label %cleanup.i45

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit205: ; preds = %bb8.i53
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit58

bb15.i46:                                         ; preds = %bb12.i49, %cleanup.i45
  %84 = load i8, ptr %_21.i35, align 1
  %85 = trunc nuw i8 %84 to i1
  br i1 %85, label %bb14.i48, label %bb11.i47

bb12.i49:                                         ; preds = %cleanup.i45
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr align 8 %guard.i37) #22
          to label %bb15.i46 unwind label %terminate.i50

terminate.i50:                                    ; preds = %bb12.i49
  %86 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb11.i47:                                         ; preds = %bb14.i48, %bb15.i46
  %87 = load ptr, ptr %5, align 8
  %88 = getelementptr inbounds i8, ptr %5, i64 8
  %89 = load i32, ptr %88, align 8
  %90 = insertvalue { ptr, i32 } poison, ptr %87, 0
  %91 = insertvalue { ptr, i32 } %90, i32 %89, 1
  resume { ptr, i32 } %91

bb14.i48:                                         ; preds = %bb15.i46
  br label %bb11.i47

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit58: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit205
  store i8 0, ptr %_20.i36, align 1
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %c5 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_0.i203204, ptr align 4 %_0.i197198) #21
  store i8 0, ptr %_21.i11, align 1
  store i8 0, ptr %_20.i12, align 1
  store i8 1, ptr %_21.i11, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i224 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i203204)
  store ptr %_2.i.i224, ptr %true_val1.i15, align 8
  store i8 0, ptr %_21.i11, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i223 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i197198)
  store ptr %_2.i.i223, ptr %false_val2.i14, align 8
  %guard3.i19 = select i1 %c5, ptr %true_val1.i15, ptr %false_val2.i14, !unpredictable !283
  %drop.i20 = select i1 %c5, ptr %false_val2.i14, ptr %true_val1.i15, !unpredictable !283
  store i8 1, ptr %_20.i12, align 1
  store ptr %guard3.i19, ptr %guard.i13, align 8
  br label %bb7.i27

cleanup.i21:                                      ; preds = %bb8.i29, %bb7.i27
  %92 = landingpad { ptr, i32 }
          cleanup
  %93 = extractvalue { ptr, i32 } %92, 0
  %94 = extractvalue { ptr, i32 } %92, 1
  store ptr %93, ptr %6, align 8
  %95 = getelementptr inbounds i8, ptr %6, i64 8
  store i32 %94, ptr %95, align 8
  %96 = load i8, ptr %_20.i12, align 1
  %97 = trunc nuw i8 %96 to i1
  br i1 %97, label %bb12.i25, label %bb15.i22

bb7.i27:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit58
  store i8 0, ptr %_20.i12, align 1
  %_16.i28 = load ptr, ptr %guard.i13, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr %_16.i28)
          to label %bb8.i29 unwind label %cleanup.i21

bb8.i29:                                          ; preds = %bb7.i27
  %_18.i30 = load ptr, ptr %true_val1.i15, align 8
  %_19.i31 = load ptr, ptr %false_val2.i14, align 8
  %_17.i32 = select i1 %c5, ptr %_18.i30, ptr %_19.i31, !unpredictable !283
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i206207 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECshXA3KcOxU02_8closures(ptr %_17.i32) #21
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit208 unwind label %cleanup.i21

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit208: ; preds = %bb8.i29
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit34

bb15.i22:                                         ; preds = %bb12.i25, %cleanup.i21
  %98 = load i8, ptr %_21.i11, align 1
  %99 = trunc nuw i8 %98 to i1
  br i1 %99, label %bb14.i24, label %bb11.i23

bb12.i25:                                         ; preds = %cleanup.i21
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr align 8 %guard.i13) #22
          to label %bb15.i22 unwind label %terminate.i26

terminate.i26:                                    ; preds = %bb12.i25
  %100 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb11.i23:                                         ; preds = %bb14.i24, %bb15.i22
  %101 = load ptr, ptr %6, align 8
  %102 = getelementptr inbounds i8, ptr %6, i64 8
  %103 = load i32, ptr %102, align 8
  %104 = insertvalue { ptr, i32 } poison, ptr %101, 0
  %105 = insertvalue { ptr, i32 } %104, i32 %103, 1
  resume { ptr, i32 } %105

bb14.i24:                                         ; preds = %bb15.i22
  br label %bb11.i23

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit34: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit208
  store i8 0, ptr %_20.i12, align 1
  store i8 0, ptr %_21.i, align 1
  store i8 0, ptr %_20.i, align 1
  store i8 1, ptr %_21.i, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i226 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i197198)
  store ptr %_2.i.i226, ptr %true_val1.i, align 8
  store i8 0, ptr %_21.i, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i225 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %_0.i203204)
  store ptr %_2.i.i225, ptr %false_val2.i, align 8
  %guard3.i = select i1 %c5, ptr %true_val1.i, ptr %false_val2.i, !unpredictable !283
  %drop.i = select i1 %c5, ptr %false_val2.i, ptr %true_val1.i, !unpredictable !283
  store i8 1, ptr %_20.i, align 1
  store ptr %guard3.i, ptr %guard.i, align 8
  br label %bb7.i

cleanup.i:                                        ; preds = %bb8.i, %bb7.i
  %106 = landingpad { ptr, i32 }
          cleanup
  %107 = extractvalue { ptr, i32 } %106, 0
  %108 = extractvalue { ptr, i32 } %106, 1
  store ptr %107, ptr %7, align 8
  %109 = getelementptr inbounds i8, ptr %7, i64 8
  store i32 %108, ptr %109, align 8
  %110 = load i8, ptr %_20.i, align 1
  %111 = trunc nuw i8 %110 to i1
  br i1 %111, label %bb12.i, label %bb15.i

bb7.i:                                            ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit34
  store i8 0, ptr %_20.i, align 1
  %_16.i = load ptr, ptr %guard.i, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr %_16.i)
          to label %bb8.i unwind label %cleanup.i

bb8.i:                                            ; preds = %bb7.i
  %_18.i = load ptr, ptr %true_val1.i, align 8
  %_19.i = load ptr, ptr %false_val2.i, align 8
  %_17.i = select i1 %c5, ptr %_18.i, ptr %_19.i, !unpredictable !283
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i209210 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECshXA3KcOxU02_8closures(ptr %_17.i) #21
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit211 unwind label %cleanup.i

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit211: ; preds = %bb8.i
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit

bb15.i:                                           ; preds = %bb12.i, %cleanup.i
  %112 = load i8, ptr %_21.i, align 1
  %113 = trunc nuw i8 %112 to i1
  br i1 %113, label %bb14.i, label %bb11.i

bb12.i:                                           ; preds = %cleanup.i
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECshXA3KcOxU02_8closures(ptr align 8 %guard.i) #22
          to label %bb15.i unwind label %terminate.i

terminate.i:                                      ; preds = %bb12.i
  %114 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb11.i:                                           ; preds = %bb14.i, %bb15.i
  %115 = load ptr, ptr %7, align 8
  %116 = getelementptr inbounds i8, ptr %7, i64 8
  %117 = load i32, ptr %116, align 8
  %118 = insertvalue { ptr, i32 } poison, ptr %115, 0
  %119 = insertvalue { ptr, i32 } %118, i32 %117, 1
  resume { ptr, i32 } %119

bb14.i:                                           ; preds = %bb15.i
  br label %bb11.i

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCshXA3KcOxU02_8closures.exit211
  store i8 0, ptr %_20.i, align 1
; call core::ub_checks::check_language_ub
  %_4.i7 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i7, label %bb2.i8, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit9

bb2.i8:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i189190, ptr %dst, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit9

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit9: ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECshXA3KcOxU02_8closures.exit, %bb2.i8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %dst, ptr align 4 %_0.i189190, i64 4, i1 false)
  %_0.i181 = getelementptr inbounds nuw i32, ptr %dst, i64 1
; call core::ub_checks::check_language_ub
  %_4.i4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i4, label %bb2.i5, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit6

bb2.i5:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit9
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i206207, ptr %_0.i181, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit6

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit6: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit9, %bb2.i5
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i181, ptr align 4 %_0.i206207, i64 4, i1 false)
  %_0.i180 = getelementptr inbounds nuw i32, ptr %dst, i64 2
; call core::ub_checks::check_language_ub
  %_4.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i1, label %bb2.i2, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit3

bb2.i2:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit6
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i209210, ptr %_0.i180, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit3

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit3: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit6, %bb2.i2
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i180, ptr align 4 %_0.i209210, i64 4, i1 false)
  %_0.i179 = getelementptr inbounds nuw i32, ptr %dst, i64 3
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit3
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i191192, ptr %_0.i179, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit3, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i179, ptr align 4 %_0.i191192, i64 4, i1 false)
  ret void
}

; core::slice::sort::shared::smallsort::sort8_stable::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort8_stablelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr %v_base, ptr %dst, ptr %scratch_base, ptr align 8 %is_less) unnamed_addr #0 !guid !346 {
start:
; call core::slice::sort::shared::smallsort::sort4_stable::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr %v_base, ptr %scratch_base, ptr align 8 %is_less)
  %_0.i1 = getelementptr inbounds nuw i32, ptr %v_base, i64 4
  %_0.i = getelementptr inbounds nuw i32, ptr %scratch_base, i64 4
; call core::slice::sort::shared::smallsort::sort4_stable::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr %_0.i1, ptr %_0.i, ptr align 8 %is_less)
; call core::slice::raw::from_raw_parts::<i32>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partslECshXA3KcOxU02_8closures(ptr %scratch_base, i64 8, ptr align 8 @alloc_0ab1672cf9b06a39e5138e5643964c99) #21
  %_12.0 = extractvalue { ptr, i64 } %0, 0
  %_12.1 = extractvalue { ptr, i64 } %0, 1
; call core::slice::sort::shared::smallsort::bidirectional_merge::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort19bidirectional_mergelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB23_(ptr align 4 %_12.0, i64 %_12.1, ptr %dst, ptr align 8 %is_less)
  ret void
}

; core::slice::sort::shared::smallsort::bidirectional_merge::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort19bidirectional_mergelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB23_(ptr align 4 %v.0, i64 %v.1, ptr %dst, ptr align 8 %is_less) unnamed_addr #0 !guid !347 {
start:
  %_0.i30 = alloca [8 x i8], align 8
  %src.i3 = alloca [8 x i8], align 8
  %dst.i4 = alloca [8 x i8], align 8
  %right_src.i5 = alloca [8 x i8], align 8
  %left_src.i6 = alloca [8 x i8], align 8
  %src.i = alloca [8 x i8], align 8
  %dst.i = alloca [8 x i8], align 8
  %right_src.i = alloca [8 x i8], align 8
  %left_src.i = alloca [8 x i8], align 8
  %last_src = alloca [8 x i8], align 8
  %_35 = alloca [24 x i8], align 8
  %_28 = alloca [24 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %dst_rev = alloca [8 x i8], align 8
  %right_rev = alloca [8 x i8], align 8
  %left_rev = alloca [8 x i8], align 8
  %dst1 = alloca [8 x i8], align 8
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  %len_div_2 = udiv i64 %v.1, 2
  %_8 = icmp ne i64 %len_div_2, 0
  store ptr %v.0, ptr %left, align 8
  %_0.i48 = getelementptr inbounds nuw i32, ptr %v.0, i64 %len_div_2
  store ptr %_0.i48, ptr %right, align 8
  store ptr %dst, ptr %dst1, align 8
  %_13 = sub i64 %len_div_2, 1
  %_0.i47 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_13
  store ptr %_0.i47, ptr %left_rev, align 8
  %_15 = sub i64 %v.1, 1
  %_0.i46 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_15
  store ptr %_0.i46, ptr %right_rev, align 8
  %_17 = load ptr, ptr %dst1, align 8
  %_18 = sub i64 %v.1, 1
  %_0.i29 = getelementptr inbounds nuw i32, ptr %_17, i64 %_18
  store ptr %_0.i29, ptr %dst_rev, align 8
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %len_div_2) #21
  %_19.0 = extractvalue { i64, i64 } %0, 0
  %_19.1 = extractvalue { i64, i64 } %0, 1
  store i64 %_19.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_19.1, ptr %1, align 8
  br label %bb8

bb8:                                              ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1U_.exit, %start
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %2 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #21
  %_22.0 = extractvalue { i64, i64 } %2, 0
  %_22.1 = extractvalue { i64, i64 } %2, 1
  %3 = trunc nuw i64 %_22.0 to i1
  br i1 %3, label %bb11, label %bb12

bb11:                                             ; preds = %bb8
  %_29 = load ptr, ptr %left, align 8
  %_30 = load ptr, ptr %right, align 8
  %_31 = load ptr, ptr %dst1, align 8
  store ptr %_29, ptr %left_src.i6, align 8
  store ptr %_30, ptr %right_src.i5, align 8
  store ptr %_31, ptr %dst.i4, align 8
  %_8.i7 = load ptr, ptr %right_src.i5, align 8
  %_9.i8 = load ptr, ptr %left_src.i6, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_6.i9 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_8.i7, ptr align 4 %_9.i8) #21
  %is_l.i10 = xor i1 %_6.i9, true
  br i1 %is_l.i10, label %bb2.i28, label %bb3.i11

bb3.i11:                                          ; preds = %bb11
  %4 = load ptr, ptr %right_src.i5, align 8
  store ptr %4, ptr %src.i3, align 8
  br label %bb4.i12

bb2.i28:                                          ; preds = %bb11
  %5 = load ptr, ptr %left_src.i6, align 8
  store ptr %5, ptr %src.i3, align 8
  br label %bb4.i12

bb4.i12:                                          ; preds = %bb2.i28, %bb3.i11
  %_12.i13 = load ptr, ptr %src.i3, align 8
  %_13.i14 = load ptr, ptr %dst.i4, align 8
; call core::ub_checks::check_language_ub
  %_4.i.i15 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i.i15, label %bb2.i.i27, label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_.exit

bb2.i.i27:                                        ; preds = %bb4.i12
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_12.i13, ptr %_13.i14, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_.exit: ; preds = %bb4.i12, %bb2.i.i27
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_13.i14, ptr align 4 %_12.i13, i64 4, i1 false)
  %_15.i16 = load ptr, ptr %right_src.i5, align 8
  %_16.i18 = zext i1 %_6.i9 to i64
  %_0.i43 = getelementptr inbounds nuw i32, ptr %_15.i16, i64 %_16.i18
  store ptr %_0.i43, ptr %right_src.i5, align 8
  %_19.i20 = load ptr, ptr %left_src.i6, align 8
  %_20.i = zext i1 %is_l.i10 to i64
  %_0.i42 = getelementptr inbounds nuw i32, ptr %_19.i20, i64 %_20.i
  store ptr %_0.i42, ptr %left_src.i6, align 8
  %_22.i22 = load ptr, ptr %dst.i4, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_22.i22, i64 1
  store ptr %_0.i, ptr %dst.i4, align 8
  %_23.i24 = load ptr, ptr %left_src.i6, align 8
  %_24.i25 = load ptr, ptr %right_src.i5, align 8
  %_25.i26 = load ptr, ptr %dst.i4, align 8
  store ptr %_23.i24, ptr %_28, align 8
  %6 = getelementptr inbounds i8, ptr %_28, i64 8
  store ptr %_24.i25, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_28, i64 16
  store ptr %_25.i26, ptr %7, align 8
  %_25 = load ptr, ptr %_28, align 8
  %8 = getelementptr inbounds i8, ptr %_28, i64 8
  %_26 = load ptr, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %_28, i64 16
  %_27 = load ptr, ptr %9, align 8
  store ptr %_25, ptr %left, align 8
  store ptr %_26, ptr %right, align 8
  store ptr %_27, ptr %dst1, align 8
  %_36 = load ptr, ptr %left_rev, align 8
  %_37 = load ptr, ptr %right_rev, align 8
  %_38 = load ptr, ptr %dst_rev, align 8
  store ptr %_36, ptr %left_src.i, align 8
  store ptr %_37, ptr %right_src.i, align 8
  store ptr %_38, ptr %dst.i, align 8
  %_8.i = load ptr, ptr %right_src.i, align 8
  %_9.i = load ptr, ptr %left_src.i, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_6.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_8.i, ptr align 4 %_9.i) #21
  %is_l.i = xor i1 %_6.i, true
  br i1 %is_l.i, label %bb2.i2, label %bb3.i

bb3.i:                                            ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_.exit
  %10 = load ptr, ptr %left_src.i, align 8
  store ptr %10, ptr %src.i, align 8
  br label %bb4.i

bb2.i2:                                           ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1R_.exit
  %11 = load ptr, ptr %right_src.i, align 8
  store ptr %11, ptr %src.i, align 8
  br label %bb4.i

bb4.i:                                            ; preds = %bb2.i2, %bb3.i
  %_12.i = load ptr, ptr %src.i, align 8
  %_13.i = load ptr, ptr %dst.i, align 8
; call core::ub_checks::check_language_ub
  %_4.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i.i, label %bb2.i.i, label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1U_.exit

bb2.i.i:                                          ; preds = %bb4.i
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_12.i, ptr %_13.i, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1U_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1U_.exit: ; preds = %bb4.i, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_13.i, ptr align 4 %_12.i, i64 4, i1 false)
  %_15.i = load ptr, ptr %right_src.i, align 8
  %_16.i = zext i1 %is_l.i to i64
  %_0.i52 = sub i64 0, %_16.i
  %_0.i38 = getelementptr i32, ptr %_15.i, i64 %_0.i52
  store ptr %_0.i38, ptr %right_src.i, align 8
  %_18.i = load ptr, ptr %left_src.i, align 8
  %_19.i = zext i1 %_6.i to i64
  %_0.i51 = sub i64 0, %_19.i
  %_0.i39 = getelementptr i32, ptr %_18.i, i64 %_0.i51
  store ptr %_0.i39, ptr %left_src.i, align 8
  %_22.i = load ptr, ptr %dst.i, align 8
  %12 = getelementptr inbounds i32, ptr %_22.i, i64 -1
  store ptr %12, ptr %_0.i30, align 8
  %13 = load ptr, ptr %_0.i30, align 8
  store ptr %13, ptr %dst.i, align 8
  %_23.i = load ptr, ptr %left_src.i, align 8
  %_24.i = load ptr, ptr %right_src.i, align 8
  %_25.i = load ptr, ptr %dst.i, align 8
  store ptr %_23.i, ptr %_35, align 8
  %14 = getelementptr inbounds i8, ptr %_35, i64 8
  store ptr %_24.i, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %_35, i64 16
  store ptr %_25.i, ptr %15, align 8
  %_32 = load ptr, ptr %_35, align 8
  %16 = getelementptr inbounds i8, ptr %_35, i64 8
  %_33 = load ptr, ptr %16, align 8
  %17 = getelementptr inbounds i8, ptr %_35, i64 16
  %_34 = load ptr, ptr %17, align 8
  store ptr %_32, ptr %left_rev, align 8
  store ptr %_33, ptr %right_rev, align 8
  store ptr %_34, ptr %dst_rev, align 8
  br label %bb8

bb12:                                             ; preds = %bb8
  %_40 = load ptr, ptr %left_rev, align 8
  %_0.i40 = getelementptr i32, ptr %_40, i64 1
  %_42 = load ptr, ptr %right_rev, align 8
  %_0.i41 = getelementptr i32, ptr %_42, i64 1
; call <usize>::is_multiple_of
  %_43 = call zeroext i1 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj14is_multiple_ofCshXA3KcOxU02_8closures(i64 %v.1, i64 2) #21
  br i1 %_43, label %bb25, label %bb18

bb18:                                             ; preds = %bb12
  %_45 = load ptr, ptr %left, align 8
  %left_nonempty = icmp ult ptr %_45, %_0.i40
  br i1 %left_nonempty, label %bb19, label %bb20

bb25:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit, %bb12
  %_58 = load ptr, ptr %left, align 8
  %_57 = icmp ne ptr %_58, %_0.i40
  br i1 %_57, label %bb27, label %bb26

bb20:                                             ; preds = %bb18
  %18 = load ptr, ptr %right, align 8
  store ptr %18, ptr %last_src, align 8
  br label %bb21

bb19:                                             ; preds = %bb18
  %19 = load ptr, ptr %left, align 8
  store ptr %19, ptr %last_src, align 8
  br label %bb21

bb21:                                             ; preds = %bb19, %bb20
  %_48 = load ptr, ptr %last_src, align 8
  %_49 = load ptr, ptr %dst1, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %bb21
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_48, ptr %_49, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %bb21, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_49, ptr align 4 %_48, i64 4, i1 false)
  %_51 = load ptr, ptr %left, align 8
  %_52 = zext i1 %left_nonempty to i64
  %_0.i45 = getelementptr inbounds nuw i32, ptr %_51, i64 %_52
  store ptr %_0.i45, ptr %left, align 8
  %_54 = load ptr, ptr %right, align 8
  %_56 = xor i1 %left_nonempty, true
  %_55 = zext i1 %_56 to i64
  %_0.i44 = getelementptr inbounds nuw i32, ptr %_54, i64 %_55
  store ptr %_0.i44, ptr %right, align 8
  br label %bb25

bb26:                                             ; preds = %bb25
  %_60 = load ptr, ptr %right, align 8
  %_59 = icmp ne ptr %_60, %_0.i41
  br i1 %_59, label %bb27, label %bb28

bb27:                                             ; preds = %bb26, %bb25
; call core::slice::sort::shared::smallsort::panic_on_ord_violation
  call void @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort22panic_on_ord_violation() #25
  unreachable

bb28:                                             ; preds = %bb26
  ret void

bb10:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::shared::smallsort::insertion_sort_shift_left::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB29_(ptr align 4 %v.0, i64 %v.1, i64 %offset, ptr align 8 %is_less) unnamed_addr #0 !guid !348 {
start:
  %tail = alloca [8 x i8], align 8
  %_6 = icmp eq i64 %offset, 0
  br i1 %_6, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_7 = icmp ugt i64 %offset, %v.1
  br i1 %_7, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
  call void @llvm.trap()
  unreachable

bb3:                                              ; preds = %bb1
  %_0.i2 = getelementptr inbounds nuw i32, ptr %v.0, i64 %v.1
  %_0.i1 = getelementptr inbounds nuw i32, ptr %v.0, i64 %offset
  store ptr %_0.i1, ptr %tail, align 8
  br label %bb6

bb6:                                              ; preds = %bb7, %bb3
  %_13 = load ptr, ptr %tail, align 8
  %_12 = icmp ne ptr %_13, %_0.i2
  br i1 %_12, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  ret void

bb7:                                              ; preds = %bb6
  %_15 = load ptr, ptr %tail, align 8
; call core::slice::sort::shared::smallsort::insert_tail::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort11insert_taillNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1V_(ptr %v.0, ptr %_15, ptr align 8 %is_less)
  %_17 = load ptr, ptr %tail, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_17, i64 1
  store ptr %_0.i, ptr %tail, align 8
  br label %bb6
}

; core::slice::sort::shared::smallsort::small_sort_general_with_scratch::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB2f_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, ptr align 8 %is_less) unnamed_addr #0 personality ptr @rust_eh_personality !guid !349 {
start:
  %0 = alloca [16 x i8], align 8
  %_74 = alloca [1 x i8], align 1
  %_73 = alloca [24 x i8], align 8
  %drop_guard = alloca [24 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %iter1 = alloca [16 x i8], align 8
  %desired_len = alloca [8 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %iter = alloca [32 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_39 = alloca [32 x i8], align 8
  %presorted_len = alloca [8 x i8], align 8
  store i8 0, ptr %_74, align 1
  %_6 = icmp ult i64 %v.1, 2
  br i1 %_6, label %bb50, label %bb1

bb1:                                              ; preds = %start
  %_10 = add i64 %v.1, 16
  %_7 = icmp ult i64 %scratch.1, %_10
  br i1 %_7, label %bb2, label %bb3

bb50:                                             ; preds = %bb49, %start
  ret void

bb3:                                              ; preds = %bb1
  %len_div_2 = udiv i64 %v.1, 2
  br label %bb7

bb2:                                              ; preds = %bb1
  call void @llvm.trap()
  unreachable

bb7:                                              ; preds = %bb3
  %_18 = icmp uge i64 %v.1, 16
  br i1 %_18, label %bb8, label %bb15

bb15:                                             ; preds = %bb7
  %_26 = icmp uge i64 %v.1, 8
  br i1 %_26, label %bb16, label %bb21

bb8:                                              ; preds = %bb7
  %_0.i16 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %v.1
; call core::slice::sort::shared::smallsort::sort8_stable::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort8_stablelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr %v.0, ptr %scratch.0, ptr %_0.i16, ptr align 8 %is_less)
  %_0.i15 = getelementptr inbounds nuw i32, ptr %v.0, i64 %len_div_2
  %_0.i14 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %len_div_2
  %_25 = add i64 %v.1, 8
  %_0.i13 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %_25
; call core::slice::sort::shared::smallsort::sort8_stable::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort8_stablelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr %_0.i15, ptr %_0.i14, ptr %_0.i13, ptr align 8 %is_less)
  store i64 8, ptr %presorted_len, align 8
  br label %bb26

bb21:                                             ; preds = %bb15
; call core::ub_checks::check_language_ub
  %_4.i6 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i6, label %bb2.i7, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit8

bb2.i7:                                           ; preds = %bb21
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %v.0, ptr %scratch.0, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit8

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit8: ; preds = %bb21, %bb2.i7
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %scratch.0, ptr align 4 %v.0, i64 4, i1 false)
  %_0.i20 = getelementptr inbounds nuw i32, ptr %v.0, i64 %len_div_2
  %_0.i19 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %len_div_2
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i4, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit5

bb2.i4:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit8
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i20, ptr %_0.i19, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit5

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit5: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit8, %bb2.i4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i19, ptr align 4 %_0.i20, i64 4, i1 false)
  store i64 1, ptr %presorted_len, align 8
  br label %bb26

bb16:                                             ; preds = %bb15
; call core::slice::sort::shared::smallsort::sort4_stable::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr %v.0, ptr %scratch.0, ptr align 8 %is_less)
  %_0.i18 = getelementptr inbounds nuw i32, ptr %v.0, i64 %len_div_2
  %_0.i17 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %len_div_2
; call core::slice::sort::shared::smallsort::sort4_stable::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr %_0.i18, ptr %_0.i17, ptr align 8 %is_less)
  store i64 4, ptr %presorted_len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8, %bb16, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit5
  %1 = getelementptr inbounds nuw i64, ptr %_40, i64 0
  store i64 0, ptr %1, align 8
  %2 = getelementptr inbounds nuw i64, ptr %_40, i64 1
  store i64 %len_div_2, ptr %2, align 8
; call <[usize; 2] as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAjj2_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCshGsV4pNJ6ra_6object(ptr sret([32 x i8]) align 8 %_39, ptr align 8 %_40) #21
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter, ptr align 8 %_39, i64 32, i1 false)
  br label %bb28

bb28:                                             ; preds = %bb40, %bb26
; invoke <core::array::iter::IntoIter<usize, 2> as core::iter::traits::iterator::Iterator>::next
  %3 = invoke { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterjKj2_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCshGsV4pNJ6ra_6object(ptr align 8 %iter)
          to label %bb29 unwind label %cleanup

bb51:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<usize, 2>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterjKj2_EECshGsV4pNJ6ra_6object(ptr align 8 %iter) #22
          to label %bb52 unwind label %terminate

cleanup:                                          ; preds = %bb43, %bb45, %bb39, %bb37, %bb28
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb51

bb29:                                             ; preds = %bb28
  %8 = extractvalue { i64, i64 } %3, 0
  %9 = extractvalue { i64, i64 } %3, 1
  store i64 %8, ptr %_42, align 8
  %10 = getelementptr inbounds i8, ptr %_42, i64 8
  store i64 %9, ptr %10, align 8
  %_44 = load i64, ptr %_42, align 8
  %11 = getelementptr inbounds i8, ptr %_42, i64 8
  %12 = load i64, ptr %11, align 8
  %13 = trunc nuw i64 %_44 to i1
  br i1 %13, label %bb31, label %bb32

bb31:                                             ; preds = %bb29
  %14 = getelementptr inbounds i8, ptr %_42, i64 8
  %offset = load i64, ptr %14, align 8
  %_0.i12 = getelementptr inbounds nuw i32, ptr %v.0, i64 %offset
  br label %bb33

bb32:                                             ; preds = %bb29
; call core::ptr::drop_glue::<core::array::iter::IntoIter<usize, 2>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterjKj2_EECshGsV4pNJ6ra_6object(ptr align 8 %iter)
  store i8 1, ptr %_74, align 1
  store ptr %scratch.0, ptr %drop_guard, align 8
  %15 = getelementptr inbounds i8, ptr %drop_guard, i64 8
  store ptr %v.0, ptr %15, align 8
  %16 = getelementptr inbounds i8, ptr %drop_guard, i64 16
  store i64 %v.1, ptr %16, align 8
  %_69 = load ptr, ptr %drop_guard, align 8
  %17 = getelementptr inbounds i8, ptr %drop_guard, i64 16
  %_70 = load i64, ptr %17, align 8
; invoke core::slice::raw::from_raw_parts::<i32>
  %18 = invoke { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partslECshXA3KcOxU02_8closures(ptr %_69, i64 %_70, ptr align 8 @alloc_dea82b1a5cc143169db7b7d27413b6f6)
          to label %bb47 unwind label %cleanup2

bb54:                                             ; preds = %cleanup2
  %19 = load i8, ptr %_74, align 1
  %20 = trunc nuw i8 %19 to i1
  br i1 %20, label %bb53, label %bb52

cleanup2:                                         ; preds = %bb48, %bb47, %bb32
  %21 = landingpad { ptr, i32 }
          cleanup
  %22 = extractvalue { ptr, i32 } %21, 0
  %23 = extractvalue { ptr, i32 } %21, 1
  store ptr %22, ptr %0, align 8
  %24 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %23, ptr %24, align 8
  br label %bb54

bb47:                                             ; preds = %bb32
  %_68.0 = extractvalue { ptr, i64 } %18, 0
  %_68.1 = extractvalue { ptr, i64 } %18, 1
  %25 = getelementptr inbounds i8, ptr %drop_guard, i64 8
  %_71 = load ptr, ptr %25, align 8
; invoke core::slice::sort::shared::smallsort::bidirectional_merge::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  invoke void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort19bidirectional_mergelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB23_(ptr align 4 %_68.0, i64 %_68.1, ptr %_71, ptr align 8 %is_less)
          to label %bb48 unwind label %cleanup2

bb48:                                             ; preds = %bb47
  store i8 0, ptr %_74, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_73, ptr align 8 %drop_guard, i64 24, i1 false)
; invoke core::mem::forget::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECshXA3KcOxU02_8closures(ptr align 8 %_73)
          to label %bb49 unwind label %cleanup2

bb49:                                             ; preds = %bb48
  store i8 0, ptr %_74, align 1
  br label %bb50

bb52:                                             ; preds = %bb51, %bb53, %bb54
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr inbounds i8, ptr %0, i64 8
  %28 = load i32, ptr %27, align 8
  %29 = insertvalue { ptr, i32 } poison, ptr %26, 0
  %30 = insertvalue { ptr, i32 } %29, i32 %28, 1
  resume { ptr, i32 } %30

bb53:                                             ; preds = %bb54
; invoke core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECshXA3KcOxU02_8closures(ptr align 8 %drop_guard) #22
          to label %bb52 unwind label %terminate

terminate:                                        ; preds = %bb51, %bb53
  %31 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb33:                                             ; preds = %bb31
  %_0.i11 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %offset
  br label %bb34

bb34:                                             ; preds = %bb33
  %_49 = icmp eq i64 %offset, 0
  br i1 %_49, label %bb35, label %bb36

bb36:                                             ; preds = %bb34
  %32 = sub i64 %v.1, %len_div_2
  store i64 %32, ptr %desired_len, align 8
  br label %bb37

bb35:                                             ; preds = %bb34
  store i64 %len_div_2, ptr %desired_len, align 8
  br label %bb37

bb37:                                             ; preds = %bb35, %bb36
  %_52 = load i64, ptr %presorted_len, align 8
  %_53 = load i64, ptr %desired_len, align 8
; invoke <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %33 = invoke { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 %_52, i64 %_53)
          to label %bb38 unwind label %cleanup

bb38:                                             ; preds = %bb37
  %_50.0 = extractvalue { i64, i64 } %33, 0
  %_50.1 = extractvalue { i64, i64 } %33, 1
  store i64 %_50.0, ptr %iter1, align 8
  %34 = getelementptr inbounds i8, ptr %iter1, i64 8
  store i64 %_50.1, ptr %34, align 8
  br label %bb39

bb39:                                             ; preds = %bb55, %bb38
; invoke <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %35 = invoke { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter1)
          to label %bb40 unwind label %cleanup

bb40:                                             ; preds = %bb39
  %36 = extractvalue { i64, i64 } %35, 0
  %37 = extractvalue { i64, i64 } %35, 1
  store i64 %36, ptr %_55, align 8
  %38 = getelementptr inbounds i8, ptr %_55, i64 8
  store i64 %37, ptr %38, align 8
  %_57 = load i64, ptr %_55, align 8
  %39 = getelementptr inbounds i8, ptr %_55, i64 8
  %40 = load i64, ptr %39, align 8
  %41 = trunc nuw i64 %_57 to i1
  br i1 %41, label %bb41, label %bb28

bb41:                                             ; preds = %bb40
  %42 = getelementptr inbounds i8, ptr %_55, i64 8
  %i = load i64, ptr %42, align 8
  %_0.i10 = getelementptr inbounds nuw i32, ptr %_0.i12, i64 %i
  br label %bb42

bb42:                                             ; preds = %bb41
  %_0.i9 = getelementptr inbounds nuw i32, ptr %_0.i11, i64 %i
  br label %bb43

bb43:                                             ; preds = %bb42
; invoke core::ub_checks::check_language_ub
  %_4.i3 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
          to label %_4.i.noexc unwind label %cleanup

_4.i.noexc:                                       ; preds = %bb43
  br i1 %_4.i3, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %_4.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i10, ptr %_0.i9, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %_4.i.noexc, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i9, ptr align 4 %_0.i10, i64 4, i1 false)
  br label %bb44

bb44:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit
  %_0.i = getelementptr inbounds nuw i32, ptr %_0.i11, i64 %i
  br label %bb45

bb45:                                             ; preds = %bb44
; invoke core::slice::sort::shared::smallsort::insert_tail::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  invoke void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort11insert_taillNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1V_(ptr %_0.i11, ptr %_0.i, ptr align 8 %is_less)
          to label %bb55 unwind label %cleanup

bb55:                                             ; preds = %bb45
  br label %bb39

bb30:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::stable::drift::create_run::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift10create_runlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1Q_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %min_good_run_len, i1 zeroext %eager_sort, ptr align 8 %is_less) unnamed_addr #0 !guid !350 {
start:
  %run_len.i = alloca [8 x i8], align 8
  %_0.i = alloca [16 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %_8 = icmp uge i64 %v.1, %min_good_run_len
  br i1 %_8, label %bb1, label %bb7

bb7:                                              ; preds = %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1P_.exit, %start
  br i1 %eager_sort, label %bb8, label %bb13

bb1:                                              ; preds = %start
  %_4.i = icmp ult i64 %v.1, 2
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb1
  store i64 2, ptr %run_len.i, align 8
; call <[i32]>::get_unchecked::<usize>
  %_8.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECshXA3KcOxU02_8closures(ptr align 4 %v.0, i64 %v.1, i64 1, ptr align 8 @alloc_b1a59a7585543a4a25115f0cbf40f484) #21
; call <[i32]>::get_unchecked::<usize>
  %_9.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECshXA3KcOxU02_8closures(ptr align 4 %v.0, i64 %v.1, i64 0, ptr align 8 @alloc_4e95ed00d8479deaf9b8943b85759bde) #21
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %strictly_descending.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_8.i, ptr align 4 %_9.i) #21
  br i1 %strictly_descending.i, label %bb6.i, label %bb12.i

bb1.i:                                            ; preds = %bb1
  store i64 %v.1, ptr %_0.i, align 8
  %0 = getelementptr inbounds i8, ptr %_0.i, i64 8
  store i8 0, ptr %0, align 8
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1P_.exit

bb12.i:                                           ; preds = %bb17.i, %bb2.i
  %_20.i = load i64, ptr %run_len.i, align 8
  %_19.i = icmp ult i64 %_20.i, %v.1
  br i1 %_19.i, label %bb13.i, label %bb18.i

bb6.i:                                            ; preds = %bb11.i, %bb2.i
  %_11.i = load i64, ptr %run_len.i, align 8
  %_10.i = icmp ult i64 %_11.i, %v.1
  br i1 %_10.i, label %bb7.i, label %bb18.i

bb18.i:                                           ; preds = %bb7.i, %bb13.i, %bb6.i, %bb12.i
  %_28.i = load i64, ptr %run_len.i, align 8
  store i64 %_28.i, ptr %_0.i, align 8
  %1 = getelementptr inbounds i8, ptr %_0.i, i64 8
  %2 = zext i1 %strictly_descending.i to i8
  store i8 %2, ptr %1, align 8
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1P_.exit

bb13.i:                                           ; preds = %bb12.i
  %_24.i = load i64, ptr %run_len.i, align 8
; call <[i32]>::get_unchecked::<usize>
  %_23.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECshXA3KcOxU02_8closures(ptr align 4 %v.0, i64 %v.1, i64 %_24.i, ptr align 8 @alloc_0aa54d60960e578bf5dc3db64f9182b2) #21
  %_27.i = load i64, ptr %run_len.i, align 8
  %_26.i = sub i64 %_27.i, 1
; call <[i32]>::get_unchecked::<usize>
  %_25.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECshXA3KcOxU02_8closures(ptr align 4 %v.0, i64 %v.1, i64 %_26.i, ptr align 8 @alloc_34d92db687bf3e85a75e319cac8072d0) #21
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_21.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_23.i, ptr align 4 %_25.i) #21
  br i1 %_21.i, label %bb18.i, label %bb17.i

bb17.i:                                           ; preds = %bb13.i
  %3 = load i64, ptr %run_len.i, align 8
  %4 = add i64 %3, 1
  store i64 %4, ptr %run_len.i, align 8
  br label %bb12.i

bb7.i:                                            ; preds = %bb6.i
  %_15.i = load i64, ptr %run_len.i, align 8
; call <[i32]>::get_unchecked::<usize>
  %_14.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECshXA3KcOxU02_8closures(ptr align 4 %v.0, i64 %v.1, i64 %_15.i, ptr align 8 @alloc_3a54043bf62a6816be5c3584bd0aab69) #21
  %_18.i = load i64, ptr %run_len.i, align 8
  %_17.i = sub i64 %_18.i, 1
; call <[i32]>::get_unchecked::<usize>
  %_16.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECshXA3KcOxU02_8closures(ptr align 4 %v.0, i64 %v.1, i64 %_17.i, ptr align 8 @alloc_435a452c7ddb8b633a1045ff18a4d695) #21
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_12.i = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_14.i, ptr align 4 %_16.i) #21
  br i1 %_12.i, label %bb11.i, label %bb18.i

bb11.i:                                           ; preds = %bb7.i
  %5 = load i64, ptr %run_len.i, align 8
  %6 = add i64 %5, 1
  store i64 %6, ptr %run_len.i, align 8
  br label %bb6.i

_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1P_.exit: ; preds = %bb1.i, %bb18.i
  %7 = load i64, ptr %_0.i, align 8
  %8 = getelementptr inbounds i8, ptr %_0.i, i64 8
  %9 = load i8, ptr %8, align 8
  %10 = trunc nuw i8 %9 to i1
  %11 = insertvalue { i64, i1 } poison, i64 %7, 0
  %12 = insertvalue { i64, i1 } %11, i1 %10, 1
  %_11.0 = extractvalue { i64, i1 } %12, 0
  %_11.1 = extractvalue { i64, i1 } %12, 1
  %_13 = icmp ule i64 %_11.0, %v.1
  %_14 = icmp uge i64 %_11.0, %min_good_run_len
  br i1 %_14, label %bb3, label %bb7

bb3:                                              ; preds = %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1P_.exit
  br i1 %_11.1, label %bb4, label %bb6

bb13:                                             ; preds = %bb7
; call core::cmp::min::<usize>
  %_24 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %min_good_run_len, i64 %v.1) #21
  %_2.i3 = shl i64 %_24, 1
  store i64 %_2.i3, ptr %_0, align 8
  br label %bb15

bb8:                                              ; preds = %bb7
; call core::cmp::min::<usize>
  %eager_run_len = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 32, i64 %v.1) #21
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %13 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 %eager_run_len, ptr align 4 %v.0, i64 %v.1, ptr align 8 @alloc_ea3823fa310c0ac95d0d5924e997a992) #21
  %_0.0.i4 = extractvalue { ptr, i64 } %13, 0
  %_0.1.i5 = extractvalue { ptr, i64 } %13, 1
  %_21.0 = extractvalue { ptr, i64 } %13, 0
  %_21.1 = extractvalue { ptr, i64 } %13, 1
; call core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1S_(ptr align 4 %_21.0, i64 %_21.1, ptr align 4 %scratch.0, i64 %scratch.1, i32 0, ptr align 4 null, ptr align 8 %is_less) #26
  %_3.i1 = shl i64 %eager_run_len, 1
  %_2.i2 = or i64 %_3.i1, 1
  store i64 %_2.i2, ptr %_0, align 8
  br label %bb15

bb15:                                             ; preds = %bb6, %bb8, %bb13
  %14 = load i64, ptr %_0, align 8
  ret i64 %14

bb6:                                              ; preds = %bb4, %bb3
  %_3.i = shl i64 %_11.0, 1
  %_2.i = or i64 %_3.i, 1
  store i64 %_2.i, ptr %_0, align 8
  br label %bb15

bb4:                                              ; preds = %bb3
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %15 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 %_11.0, ptr align 4 %v.0, i64 %v.1, ptr align 8 @alloc_0b170457ff613254af1d0cbd2a159dca) #21
  %_0.0.i = extractvalue { ptr, i64 } %15, 0
  %_0.1.i = extractvalue { ptr, i64 } %15, 1
  %_16.0 = extractvalue { ptr, i64 } %15, 0
  %_16.1 = extractvalue { ptr, i64 } %15, 1
; call <[i32]>::reverse
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl7reverseCshXA3KcOxU02_8closures(ptr align 4 %_16.0, i64 %_16.1) #21
  br label %bb6
}

; core::slice::sort::stable::drift::stable_quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, ptr align 8 %is_less) unnamed_addr #0 !guid !351 {
start:
  %_6 = or i64 %v.1, 1
; call <usize>::ilog2
  %_5 = call i32 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj5ilog2CshXA3KcOxU02_8closures(i64 %_6, ptr align 8 @alloc_5b26bc7b45e7e23728885c9a7d45b9d3) #21
  %limit = mul i32 2, %_5
; call core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1S_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i32 %limit, ptr align 4 null, ptr align 8 %is_less) #26
  ret void
}

; core::slice::sort::stable::drift::sort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift4sortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1J_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i1 zeroext %eager_sort, ptr align 8 %is_less) unnamed_addr #0 !guid !352 {
start:
  %_0.i = alloca [8 x i8], align 8
  %desired_depth = alloca [1 x i8], align 1
  %next_run = alloca [8 x i8], align 8
  %prev_run = alloca [8 x i8], align 8
  %scan_idx = alloca [8 x i8], align 8
  %desired_depth_storage = alloca [66 x i8], align 1
  %run_storage = alloca [528 x i8], align 8
  %stack_len = alloca [8 x i8], align 8
  %min_good_run_len = alloca [8 x i8], align 8
  %_7 = icmp ult i64 %v.1, 2
  br i1 %_7, label %bb39, label %bb1

bb1:                                              ; preds = %start
; call <u64>::div_ceil
  %_0.i26 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8div_ceilCshXA3KcOxU02_8closures(i64 4611686018427387904, i64 %v.1, ptr align 8 @alloc_945f2c369c171e278c4be97205a79e9b) #21
  %_10 = icmp ule i64 %v.1, 4096
  br i1 %_10, label %bb3, label %bb5

bb39:                                             ; preds = %bb38, %bb34, %start
  ret void

bb5:                                              ; preds = %bb1
; call core::slice::sort::stable::drift::sqrt_approx
  %0 = call i64 @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift11sqrt_approx(i64 %v.1)
  store i64 %0, ptr %min_good_run_len, align 8
  br label %bb6

bb3:                                              ; preds = %bb1
  %_13 = udiv i64 %v.1, 2
  %_12 = sub i64 %v.1, %_13
; call core::cmp::min::<usize>
  %1 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %_12, i64 64) #21
  store i64 %1, ptr %min_good_run_len, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb5
  store i64 0, ptr %stack_len, align 8
  store i64 0, ptr %scan_idx, align 8
  store i64 1, ptr %prev_run, align 8
  br label %bb13

bb13:                                             ; preds = %bb35, %bb6
  %_29 = load i64, ptr %scan_idx, align 8
  %_28 = icmp ult i64 %_29, %v.1
  br i1 %_28, label %bb14, label %bb20

bb20:                                             ; preds = %bb13
  store i64 1, ptr %next_run, align 8
  store i8 0, ptr %desired_depth, align 1
  br label %bb22

bb14:                                             ; preds = %bb13
  %_33 = load i64, ptr %scan_idx, align 8
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %2 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 %_33, ptr align 4 %v.0, i64 %v.1, ptr align 8 @alloc_418d50aea1f432fc229dc42e85bc0c4e) #21
  %_0.0.i29 = extractvalue { ptr, i64 } %2, 0
  %_0.1.i30 = extractvalue { ptr, i64 } %2, 1
  %_31.0 = extractvalue { ptr, i64 } %2, 0
  %_31.1 = extractvalue { ptr, i64 } %2, 1
  %_34 = load i64, ptr %min_good_run_len, align 8
; call core::slice::sort::stable::drift::create_run::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  %_30 = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift10create_runlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1Q_(ptr align 4 %_31.0, i64 %_31.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %_34, i1 zeroext %eager_sort, ptr align 8 %is_less)
  store i64 %_30, ptr %next_run, align 8
  %_37 = load i64, ptr %scan_idx, align 8
  %_39 = load i64, ptr %prev_run, align 8
  %_0.i13 = lshr i64 %_39, 1
  %_36 = sub i64 %_37, %_0.i13
  %_40 = load i64, ptr %scan_idx, align 8
  %_42 = load i64, ptr %scan_idx, align 8
  %_44 = load i64, ptr %next_run, align 8
  %_0.i12 = lshr i64 %_44, 1
  %_41 = add i64 %_42, %_0.i12
  %x.i = add i64 %_36, %_40
  %y.i = add i64 %_40, %_41
  %_13.i = mul i64 %_0.i26, %x.i
  %_14.i = mul i64 %_0.i26, %y.i
  %_12.i = xor i64 %_13.i, %_14.i
  %3 = call i64 @llvm.ctlz.i64(i64 %_12.i, i1 false)
  %_0.i.i = trunc i64 %3 to i32
  %_0.i24 = trunc i32 %_0.i.i to i8
  store i8 %_0.i24, ptr %desired_depth, align 1
  br label %bb22

bb22:                                             ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1T_.exit, %bb14, %bb20
  %_47 = load i64, ptr %stack_len, align 8
  %_46 = icmp ugt i64 %_47, 1
  br i1 %_46, label %bb23, label %bb31

bb31:                                             ; preds = %bb23, %bb22
  %_69 = load i64, ptr %prev_run, align 8
  %_71 = load i64, ptr %stack_len, align 8
  %_0.i2 = getelementptr inbounds nuw i64, ptr %run_storage, i64 %_71
  store i64 %_69, ptr %_0.i2, align 8
  %_72 = load i8, ptr %desired_depth, align 1
  %_74 = load i64, ptr %stack_len, align 8
  %_0.i3 = getelementptr inbounds nuw i8, ptr %desired_depth_storage, i64 %_74
  store i8 %_72, ptr %_0.i3, align 1
  %4 = load i64, ptr %stack_len, align 8
  %5 = add i64 %4, 1
  store i64 %5, ptr %stack_len, align 8
  %_76 = load i64, ptr %scan_idx, align 8
  %_75 = icmp uge i64 %_76, %v.1
  br i1 %_75, label %bb34, label %bb35

bb23:                                             ; preds = %bb22
  %_52 = load i64, ptr %stack_len, align 8
  %_51 = sub i64 %_52, 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %desired_depth_storage, i64 %_51
  %_49 = load i8, ptr %_0.i4, align 1
  %_53 = load i8, ptr %desired_depth, align 1
  %_48 = icmp uge i8 %_49, %_53
  br i1 %_48, label %bb25, label %bb31

bb25:                                             ; preds = %bb23
  %_57 = load i64, ptr %stack_len, align 8
  %_56 = sub i64 %_57, 1
  %_0.i1 = getelementptr inbounds nuw i64, ptr %run_storage, i64 %_56
  %left = load i64, ptr %_0.i1, align 8
  %_0.i10 = lshr i64 %left, 1
  %_61 = load i64, ptr %prev_run, align 8
  %_0.i9 = lshr i64 %_61, 1
  %merged_len = add i64 %_0.i10, %_0.i9
  %_63 = load i64, ptr %scan_idx, align 8
  %merge_start_idx = sub i64 %_63, %merged_len
  %_66 = load i64, ptr %scan_idx, align 8
; call <[i32]>::get_unchecked_mut::<core::ops::range::Range<usize>>
  %6 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSl17get_unchecked_mutINtNtNtB5_3ops5range5RangejEECshXA3KcOxU02_8closures(ptr align 4 %v.0, i64 %v.1, i64 %merge_start_idx, i64 %_66, ptr align 8 @alloc_289e523c22daf4b02f0ced64176f9f7d) #21
  %merge_slice.0 = extractvalue { ptr, i64 } %6, 0
  %merge_slice.1 = extractvalue { ptr, i64 } %6, 1
  %_68 = load i64, ptr %prev_run, align 8
  %can_fit_in_scratch.i = icmp ule i64 %merge_slice.1, %scratch.1
  br i1 %can_fit_in_scratch.i, label %bb1.i, label %bb5.i

bb5.i:                                            ; preds = %bb3.i, %bb1.i, %bb25
  %_2.i20 = and i64 %left, 1
  %_0.i21 = icmp eq i64 %_2.i20, 1
  br i1 %_0.i21, label %bb10.i, label %bb7.i

bb1.i:                                            ; preds = %bb25
  %_2.i16 = and i64 %left, 1
  %_0.i17 = icmp eq i64 %_2.i16, 1
  br i1 %_0.i17, label %bb5.i, label %bb3.i

bb3.i:                                            ; preds = %bb1.i
  %_2.i14 = and i64 %_68, 1
  %_0.i15 = icmp eq i64 %_2.i14, 1
  br i1 %_0.i15, label %bb5.i, label %bb18.i

bb18.i:                                           ; preds = %bb3.i
  %_2.i5 = shl i64 %merge_slice.1, 1
  store i64 %_2.i5, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1T_.exit

bb7.i:                                            ; preds = %bb5.i
  %_0.i8 = lshr i64 %left, 1
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %7 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 %_0.i8, ptr align 4 %merge_slice.0, i64 %merge_slice.1, ptr align 8 @alloc_c54bc7e12f54e1b6a5d6ee337e066d20) #21
  %_0.0.i = extractvalue { ptr, i64 } %7, 0
  %_0.1.i = extractvalue { ptr, i64 } %7, 1
  %_15.0.i = extractvalue { ptr, i64 } %7, 0
  %_15.1.i = extractvalue { ptr, i64 } %7, 1
; call core::slice::sort::stable::drift::stable_quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr align 4 %_15.0.i, i64 %_15.1.i, ptr align 4 %scratch.0, i64 %scratch.1, ptr align 8 %is_less)
  br label %bb10.i

bb10.i:                                           ; preds = %bb7.i, %bb5.i
  %_2.i18 = and i64 %_68, 1
  %_0.i19 = icmp eq i64 %_2.i18, 1
  br i1 %_0.i19, label %bb15.i, label %bb12.i

bb12.i:                                           ; preds = %bb10.i
  %_0.i7 = lshr i64 %left, 1
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %8 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 %_0.i7, ptr align 4 %merge_slice.0, i64 %merge_slice.1, ptr align 8 @alloc_4b0ce783e358f6d901ee99bada134993) #21
  %_0.0.i27 = extractvalue { ptr, i64 } %8, 0
  %_0.1.i28 = extractvalue { ptr, i64 } %8, 1
  %_20.0.i = extractvalue { ptr, i64 } %8, 0
  %_20.1.i = extractvalue { ptr, i64 } %8, 1
; call core::slice::sort::stable::drift::stable_quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr align 4 %_20.0.i, i64 %_20.1.i, ptr align 4 %scratch.0, i64 %scratch.1, ptr align 8 %is_less)
  br label %bb15.i

bb15.i:                                           ; preds = %bb12.i, %bb10.i
  %_0.i6 = lshr i64 %left, 1
; call core::slice::sort::stable::merge::merge::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5merge5mergelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1K_(ptr align 4 %merge_slice.0, i64 %merge_slice.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %_0.i6, ptr align 8 %is_less)
  %_3.i = shl i64 %merge_slice.1, 1
  %_2.i = or i64 %_3.i, 1
  store i64 %_2.i, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1T_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1T_.exit: ; preds = %bb18.i, %bb15.i
  %9 = load i64, ptr %_0.i, align 8
  store i64 %9, ptr %prev_run, align 8
  %10 = load i64, ptr %stack_len, align 8
  %11 = sub i64 %10, 1
  store i64 %11, ptr %stack_len, align 8
  br label %bb22

bb35:                                             ; preds = %bb31
  %_78 = load i64, ptr %next_run, align 8
  %_0.i11 = lshr i64 %_78, 1
  %12 = load i64, ptr %scan_idx, align 8
  %13 = add i64 %12, %_0.i11
  store i64 %13, ptr %scan_idx, align 8
  %_79 = load i64, ptr %next_run, align 8
  store i64 %_79, ptr %prev_run, align 8
  br label %bb13

bb34:                                             ; preds = %bb31
  %_81 = load i64, ptr %prev_run, align 8
  %_2.i22 = and i64 %_81, 1
  %_0.i23 = icmp eq i64 %_2.i22, 1
  br i1 %_0.i23, label %bb39, label %bb38

bb38:                                             ; preds = %bb34
; call core::slice::sort::stable::drift::stable_quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1W_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, ptr align 8 %is_less)
  br label %bb39
}

; core::slice::sort::stable::merge::merge::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5merge5mergelNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1K_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %mid, ptr align 8 %is_less) unnamed_addr #0 personality ptr @rust_eh_personality !guid !353 {
start:
  %0 = alloca [16 x i8], align 8
  %merge_state = alloca [24 x i8], align 8
  %save_len = alloca [8 x i8], align 8
  %save_base = alloca [8 x i8], align 8
  %_7 = icmp eq i64 %mid, 0
  br i1 %_7, label %bb21, label %bb1

bb1:                                              ; preds = %start
  %_8 = icmp uge i64 %mid, %v.1
  br i1 %_8, label %bb21, label %bb2

bb21:                                             ; preds = %bb20, %bb2, %bb1, %start
  ret void

bb2:                                              ; preds = %bb1
  %_13 = sub i64 %v.1, %mid
; call core::cmp::min::<usize>
  %_12 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %mid, i64 %_13) #21
  %_9 = icmp ult i64 %scratch.1, %_12
  br i1 %_9, label %bb21, label %bb4

bb4:                                              ; preds = %bb2
  %_0.i2 = getelementptr inbounds nuw i32, ptr %v.0, i64 %mid
  %_0.i1 = getelementptr inbounds nuw i32, ptr %v.0, i64 %v.1
  %right_len = sub i64 %v.1, %mid
  %left_is_shorter = icmp ule i64 %mid, %right_len
  br i1 %left_is_shorter, label %bb10, label %bb11

bb11:                                             ; preds = %bb4
  store ptr %_0.i2, ptr %save_base, align 8
  br label %bb12

bb10:                                             ; preds = %bb4
  store ptr %v.0, ptr %save_base, align 8
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  br i1 %left_is_shorter, label %bb13, label %bb14

bb14:                                             ; preds = %bb12
  store i64 %right_len, ptr %save_len, align 8
  br label %bb15

bb13:                                             ; preds = %bb12
  store i64 %mid, ptr %save_len, align 8
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_25 = load ptr, ptr %save_base, align 8
  %_26 = load i64, ptr %save_len, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %bb15
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_25, ptr %scratch.0, i64 4, i64 4, i64 %_26, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %bb15, %bb2.i
  %1 = mul nuw nsw i64 %_26, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %scratch.0, ptr align 4 %_25, i64 %1, i1 false)
  %_29 = load i64, ptr %save_len, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %_29
  %_30 = load ptr, ptr %save_base, align 8
  store ptr %scratch.0, ptr %merge_state, align 8
  %2 = getelementptr inbounds i8, ptr %merge_state, i64 8
  store ptr %_0.i, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %merge_state, i64 16
  store ptr %_30, ptr %3, align 8
  br i1 %left_is_shorter, label %bb18, label %bb19

bb19:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit
; invoke <core::slice::sort::stable::merge::MergeState<i32>>::merge_down::<<[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  invoke void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStatelE10merge_downNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB2a_(ptr align 8 %merge_state, ptr %v.0, ptr %scratch.0, ptr %_0.i1, ptr align 8 %is_less)
          to label %bb25 unwind label %cleanup

bb18:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit
; invoke <core::slice::sort::stable::merge::MergeState<i32>>::merge_up::<<[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  invoke void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStatelE8merge_upNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB27_(ptr align 8 %merge_state, ptr %_0.i2, ptr %_0.i1, ptr align 8 %is_less)
          to label %bb24 unwind label %cleanup

bb22:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::slice::sort::stable::merge::MergeState<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6stable5merge10MergeStatelEECshXA3KcOxU02_8closures(ptr align 8 %merge_state) #22
          to label %bb23 unwind label %terminate

cleanup:                                          ; preds = %bb18, %bb19
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb22

bb25:                                             ; preds = %bb19
  br label %bb20

bb20:                                             ; preds = %bb24, %bb25
; call core::ptr::drop_glue::<core::slice::sort::stable::merge::MergeState<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6stable5merge10MergeStatelEECshXA3KcOxU02_8closures(ptr align 8 %merge_state)
  br label %bb21

bb24:                                             ; preds = %bb18
  br label %bb20

terminate:                                        ; preds = %bb22
  %8 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb23:                                             ; preds = %bb22
  %9 = load ptr, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { ptr, i32 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i32 } %12, i32 %11, 1
  resume { ptr, i32 } %13
}

; core::slice::sort::stable::quicksort::stable_partition::<i32, core::slice::sort::stable::quicksort::quicksort<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionlNCINvB2_9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0E0EB2j_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext %pivot_goes_left, ptr align 8 %is_less) unnamed_addr #0 !guid !354 {
start:
  %_0.i14 = alloca [1 x i8], align 1
  %_78 = alloca [16 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %loop_end_pos = alloca [8 x i8], align 8
  %pivot_in_scratch = alloca [8 x i8], align 8
  %state = alloca [32 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_10 = icmp ult i64 %scratch.1, %v.1
  br i1 %_10, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = icmp uge i64 %pivot_pos, %v.1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_9, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %_9, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_9, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb3
  store i8 0, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb3
  store i8 1, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i14, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb5, label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_0.i12 = getelementptr inbounds nuw i32, ptr %v.0, i64 %pivot_pos
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::new
  call void @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE3newCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %state, ptr %v.0, ptr %scratch.0, i64 %v.1)
; call core::ptr::metadata::from_raw_parts_mut::<i32, ()>
  %_0.i = call ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutluECsddYV2PBJW9h_3std(ptr null) #21
  store ptr %_0.i, ptr %pivot_in_scratch, align 8
  store i64 %pivot_pos, ptr %loop_end_pos, align 8
  br label %bb13

bb5:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  call void @llvm.trap()
  unreachable

bb13:                                             ; preds = %bb31, %bb6
  br label %bb14

bb14:                                             ; preds = %bb13
  %_24 = load i64, ptr %loop_end_pos, align 8
  %_0.i13 = call i64 @llvm.usub.sat.i64(i64 %_24, i64 3)
  %_0.i11 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_0.i13
  br label %bb16

bb16:                                             ; preds = %bb17, %bb14
  %6 = getelementptr inbounds i8, ptr %state, i64 8
  %_27 = load ptr, ptr %6, align 8
  %_26 = icmp ult ptr %_27, %_0.i11
  br i1 %_26, label %bb17, label %bb25

bb25:                                             ; preds = %bb16
  %_53 = load i64, ptr %loop_end_pos, align 8
  %_0.i10 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_53
  br label %bb26

bb17:                                             ; preds = %bb16
  %7 = getelementptr inbounds i8, ptr %state, i64 8
  %_90 = load ptr, ptr %7, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>::{closure#0}
  %_30 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0E0B1U_(ptr align 8 %is_less, ptr align 4 %_90, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_28 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_30)
  %8 = getelementptr inbounds i8, ptr %state, i64 8
  %_91 = load ptr, ptr %8, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>::{closure#0}
  %_36 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0E0B1U_(ptr align 8 %is_less, ptr align 4 %_91, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_34 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_36)
  %9 = getelementptr inbounds i8, ptr %state, i64 8
  %_92 = load ptr, ptr %9, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>::{closure#0}
  %_42 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0E0B1U_(ptr align 8 %is_less, ptr align 4 %_92, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_40 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_42)
  %10 = getelementptr inbounds i8, ptr %state, i64 8
  %_93 = load ptr, ptr %10, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>::{closure#0}
  %_48 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0E0B1U_(ptr align 8 %is_less, ptr align 4 %_93, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_46 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_48)
  br label %bb16

bb26:                                             ; preds = %bb27, %bb25
  %11 = getelementptr inbounds i8, ptr %state, i64 8
  %_55 = load ptr, ptr %11, align 8
  %_54 = icmp ult ptr %_55, %_0.i10
  br i1 %_54, label %bb27, label %bb29

bb29:                                             ; preds = %bb26
  %_63 = load i64, ptr %loop_end_pos, align 8
  %_62 = icmp eq i64 %_63, %v.1
  br i1 %_62, label %bb30, label %bb31

bb27:                                             ; preds = %bb26
  %12 = getelementptr inbounds i8, ptr %state, i64 8
  %_94 = load ptr, ptr %12, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>::{closure#0}
  %_58 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0E0B1U_(ptr align 8 %is_less, ptr align 4 %_94, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_56 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_58)
  br label %bb26

bb31:                                             ; preds = %bb29
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_64 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %pivot_goes_left)
  store ptr %_64, ptr %pivot_in_scratch, align 8
  store i64 %v.1, ptr %loop_end_pos, align 8
  br label %bb13

bb30:                                             ; preds = %bb29
; call core::slice::sort::stable::quicksort::has_direct_interior_mutability::<i32>
  %_66 = call zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilitylECshXA3KcOxU02_8closures()
  br i1 %_66, label %bb34, label %bb35

bb35:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit7, %bb30
  %13 = getelementptr inbounds i8, ptr %state, i64 16
  %_72 = load i64, ptr %13, align 8
; call core::ub_checks::check_language_ub
  %_4.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i2, label %bb2.i3, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit4

bb2.i3:                                           ; preds = %bb35
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %scratch.0, ptr %v.0, i64 4, i64 4, i64 %_72, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit4

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit4: ; preds = %bb35, %bb2.i3
  %14 = mul nuw nsw i64 %_72, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %v.0, ptr align 4 %scratch.0, i64 %14, i1 false)
  %15 = getelementptr inbounds i8, ptr %state, i64 16
  %_76 = load i64, ptr %15, align 8
  %_75 = sub i64 %v.1, %_76
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %16 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %_75) #21
  %_73.0 = extractvalue { i64, i64 } %16, 0
  %_73.1 = extractvalue { i64, i64 } %16, 1
  store i64 %_73.0, ptr %iter, align 8
  %17 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_73.1, ptr %17, align 8
  br label %bb39

bb34:                                             ; preds = %bb30
  %_68 = load ptr, ptr %pivot_in_scratch, align 8
; call core::ub_checks::check_language_ub
  %_4.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i5, label %bb2.i6, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit7

bb2.i6:                                           ; preds = %bb34
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i12, ptr %_68, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit7

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit7: ; preds = %bb34, %bb2.i6
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_68, ptr align 4 %_0.i12, i64 4, i1 false)
  br label %bb35

bb39:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit4
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %18 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #21
  %19 = extractvalue { i64, i64 } %18, 0
  %20 = extractvalue { i64, i64 } %18, 1
  store i64 %19, ptr %_78, align 8
  %21 = getelementptr inbounds i8, ptr %_78, i64 8
  store i64 %20, ptr %21, align 8
  %_80 = load i64, ptr %_78, align 8
  %22 = getelementptr inbounds i8, ptr %_78, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = trunc nuw i64 %_80 to i1
  br i1 %24, label %bb42, label %bb43

bb42:                                             ; preds = %bb39
  %25 = getelementptr inbounds i8, ptr %_78, i64 8
  %i = load i64, ptr %25, align 8
  %_86 = sub i64 %v.1, 1
  %_85 = sub i64 %_86, %i
  %_0.i9 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %_85
  %26 = getelementptr inbounds i8, ptr %state, i64 16
  %_89 = load i64, ptr %26, align 8
  %_88 = add i64 %_89, %i
  %_0.i8 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_88
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %bb42
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i9, ptr %_0.i8, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %bb42, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i8, ptr align 4 %_0.i9, i64 4, i1 false)
  br label %bb39

bb43:                                             ; preds = %bb39
  %27 = getelementptr inbounds i8, ptr %state, i64 16
  %_0 = load i64, ptr %27, align 8
  ret i64 %_0

bb41:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::stable::quicksort::stable_partition::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB20_(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext %pivot_goes_left, ptr align 8 %is_less) unnamed_addr #0 !guid !355 {
start:
  %_0.i14 = alloca [1 x i8], align 1
  %_78 = alloca [16 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %loop_end_pos = alloca [8 x i8], align 8
  %pivot_in_scratch = alloca [8 x i8], align 8
  %state = alloca [32 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_10 = icmp ult i64 %scratch.1, %v.1
  br i1 %_10, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = icmp uge i64 %pivot_pos, %v.1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_9, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %_9, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_9, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb3
  store i8 0, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb3
  store i8 1, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i14, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb5, label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_0.i12 = getelementptr inbounds nuw i32, ptr %v.0, i64 %pivot_pos
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::new
  call void @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE3newCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %state, ptr %v.0, ptr %scratch.0, i64 %v.1)
; call core::ptr::metadata::from_raw_parts_mut::<i32, ()>
  %_0.i = call ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutluECsddYV2PBJW9h_3std(ptr null) #21
  store ptr %_0.i, ptr %pivot_in_scratch, align 8
  store i64 %pivot_pos, ptr %loop_end_pos, align 8
  br label %bb13

bb5:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  call void @llvm.trap()
  unreachable

bb13:                                             ; preds = %bb31, %bb6
  br label %bb14

bb14:                                             ; preds = %bb13
  %_24 = load i64, ptr %loop_end_pos, align 8
  %_0.i13 = call i64 @llvm.usub.sat.i64(i64 %_24, i64 3)
  %_0.i11 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_0.i13
  br label %bb16

bb16:                                             ; preds = %bb17, %bb14
  %6 = getelementptr inbounds i8, ptr %state, i64 8
  %_27 = load ptr, ptr %6, align 8
  %_26 = icmp ult ptr %_27, %_0.i11
  br i1 %_26, label %bb17, label %bb25

bb25:                                             ; preds = %bb16
  %_53 = load i64, ptr %loop_end_pos, align 8
  %_0.i10 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_53
  br label %bb26

bb17:                                             ; preds = %bb16
  %7 = getelementptr inbounds i8, ptr %state, i64 8
  %_90 = load ptr, ptr %7, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_30 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_90, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_28 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_30)
  %8 = getelementptr inbounds i8, ptr %state, i64 8
  %_91 = load ptr, ptr %8, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_36 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_91, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_34 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_36)
  %9 = getelementptr inbounds i8, ptr %state, i64 8
  %_92 = load ptr, ptr %9, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_42 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_92, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_40 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_42)
  %10 = getelementptr inbounds i8, ptr %state, i64 8
  %_93 = load ptr, ptr %10, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_48 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_93, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_46 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_48)
  br label %bb16

bb26:                                             ; preds = %bb27, %bb25
  %11 = getelementptr inbounds i8, ptr %state, i64 8
  %_55 = load ptr, ptr %11, align 8
  %_54 = icmp ult ptr %_55, %_0.i10
  br i1 %_54, label %bb27, label %bb29

bb29:                                             ; preds = %bb26
  %_63 = load i64, ptr %loop_end_pos, align 8
  %_62 = icmp eq i64 %_63, %v.1
  br i1 %_62, label %bb30, label %bb31

bb27:                                             ; preds = %bb26
  %12 = getelementptr inbounds i8, ptr %state, i64 8
  %_94 = load ptr, ptr %12, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_58 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %_94, ptr align 4 %_0.i12) #21
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_56 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %_58)
  br label %bb26

bb31:                                             ; preds = %bb29
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_64 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %state, i1 zeroext %pivot_goes_left)
  store ptr %_64, ptr %pivot_in_scratch, align 8
  store i64 %v.1, ptr %loop_end_pos, align 8
  br label %bb13

bb30:                                             ; preds = %bb29
; call core::slice::sort::stable::quicksort::has_direct_interior_mutability::<i32>
  %_66 = call zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilitylECshXA3KcOxU02_8closures()
  br i1 %_66, label %bb34, label %bb35

bb35:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit7, %bb30
  %13 = getelementptr inbounds i8, ptr %state, i64 16
  %_72 = load i64, ptr %13, align 8
; call core::ub_checks::check_language_ub
  %_4.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i2, label %bb2.i3, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit4

bb2.i3:                                           ; preds = %bb35
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %scratch.0, ptr %v.0, i64 4, i64 4, i64 %_72, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit4

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit4: ; preds = %bb35, %bb2.i3
  %14 = mul nuw nsw i64 %_72, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %v.0, ptr align 4 %scratch.0, i64 %14, i1 false)
  %15 = getelementptr inbounds i8, ptr %state, i64 16
  %_76 = load i64, ptr %15, align 8
  %_75 = sub i64 %v.1, %_76
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %16 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %_75) #21
  %_73.0 = extractvalue { i64, i64 } %16, 0
  %_73.1 = extractvalue { i64, i64 } %16, 1
  store i64 %_73.0, ptr %iter, align 8
  %17 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_73.1, ptr %17, align 8
  br label %bb39

bb34:                                             ; preds = %bb30
  %_68 = load ptr, ptr %pivot_in_scratch, align 8
; call core::ub_checks::check_language_ub
  %_4.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i5, label %bb2.i6, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit7

bb2.i6:                                           ; preds = %bb34
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i12, ptr %_68, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit7

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit7: ; preds = %bb34, %bb2.i6
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_68, ptr align 4 %_0.i12, i64 4, i1 false)
  br label %bb35

bb39:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit4
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %18 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #21
  %19 = extractvalue { i64, i64 } %18, 0
  %20 = extractvalue { i64, i64 } %18, 1
  store i64 %19, ptr %_78, align 8
  %21 = getelementptr inbounds i8, ptr %_78, i64 8
  store i64 %20, ptr %21, align 8
  %_80 = load i64, ptr %_78, align 8
  %22 = getelementptr inbounds i8, ptr %_78, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = trunc nuw i64 %_80 to i1
  br i1 %24, label %bb42, label %bb43

bb42:                                             ; preds = %bb39
  %25 = getelementptr inbounds i8, ptr %_78, i64 8
  %i = load i64, ptr %25, align 8
  %_86 = sub i64 %v.1, 1
  %_85 = sub i64 %_86, %i
  %_0.i9 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %_85
  %26 = getelementptr inbounds i8, ptr %state, i64 16
  %_89 = load i64, ptr %26, align 8
  %_88 = add i64 %_89, %i
  %_0.i8 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_88
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %bb42
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_0.i9, ptr %_0.i8, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %bb42, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i8, ptr align 4 %_0.i9, i64 4, i1 false)
  br label %bb39

bb43:                                             ; preds = %bb39
  %27 = getelementptr inbounds i8, ptr %state, i64 16
  %_0 = load i64, ptr %27, align 8
  ret i64 %_0

bb41:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::stable::quicksort::has_direct_interior_mutability::<i32>
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilitylECshXA3KcOxU02_8closures() unnamed_addr #0 !guid !356 {
start:
; call <i32 as core::slice::sort::stable::quicksort::IsFreeze>::is_freeze
  %_1 = call zeroext i1 @_RNvXs0_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortlNtB5_8IsFreeze9is_freezeCshXA3KcOxU02_8closures()
  %_0 = xor i1 %_1, true
  ret i1 %_0
}

; core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1S_(ptr align 4 %0, i64 %1, ptr align 4 %scratch.0, i64 %scratch.1, i32 %2, ptr align 4 %3, ptr align 8 %is_less) unnamed_addr #3 !guid !357 {
start:
  %_55 = alloca [32 x i8], align 8
  %_48 = alloca [8 x i8], align 8
  %left_partition_len = alloca [8 x i8], align 8
  %perform_equal_partition = alloca [1 x i8], align 1
  %pivot_copy = alloca [4 x i8], align 4
  %left_ancestor_pivot = alloca [8 x i8], align 8
  %limit = alloca [4 x i8], align 4
  %v = alloca [16 x i8], align 8
  store ptr %0, ptr %v, align 8
  %4 = getelementptr inbounds i8, ptr %v, i64 8
  store i64 %1, ptr %4, align 8
  store i32 %2, ptr %limit, align 4
  store ptr %3, ptr %left_ancestor_pivot, align 8
  br label %bb1

bb1:                                              ; preds = %bb21, %bb24, %start
  %_7.0 = load ptr, ptr %v, align 8
  %5 = getelementptr inbounds i8, ptr %v, i64 8
  %_7.1 = load i64, ptr %5, align 8
  %_8 = icmp ule i64 %_7.1, 32
  br i1 %_8, label %bb3, label %bb4

bb4:                                              ; preds = %bb1
  %_13 = load i32, ptr %limit, align 4
  %_12 = icmp eq i32 %_13, 0
  br i1 %_12, label %bb5, label %bb6

bb3:                                              ; preds = %bb1
  %_11.0 = load ptr, ptr %v, align 8
  %6 = getelementptr inbounds i8, ptr %v, i64 8
  %_11.1 = load i64, ptr %6, align 8
; call core::slice::sort::shared::smallsort::small_sort_general_with_scratch::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB2f_(ptr align 4 %_11.0, i64 %_11.1, ptr align 4 %scratch.0, i64 %scratch.1, ptr align 8 %is_less)
  br label %bb27

bb6:                                              ; preds = %bb4
  %7 = load i32, ptr %limit, align 4
  %8 = sub i32 %7, 1
  store i32 %8, ptr %limit, align 4
  %_17.0 = load ptr, ptr %v, align 8
  %9 = getelementptr inbounds i8, ptr %v, i64 8
  %_17.1 = load i64, ptr %9, align 8
; call core::slice::sort::shared::pivot::choose_pivot::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  %pivot_pos = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot12choose_pivotlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1S_(ptr align 4 %_17.0, i64 %_17.1, ptr align 8 %is_less) #21
  %_21.0 = load ptr, ptr %v, align 8
  %10 = getelementptr inbounds i8, ptr %v, i64 8
  %_21.1 = load i64, ptr %10, align 8
  %_23 = icmp ult i64 %pivot_pos, %_21.1
  br i1 %_23, label %bb8, label %panic

bb5:                                              ; preds = %bb4
  %_15.0 = load ptr, ptr %v, align 8
  %11 = getelementptr inbounds i8, ptr %v, i64 8
  %_15.1 = load i64, ptr %11, align 8
; call core::slice::sort::stable::drift::sort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift4sortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1J_(ptr align 4 %_15.0, i64 %_15.1, ptr align 4 %scratch.0, i64 %scratch.1, i1 zeroext true, ptr align 8 %is_less)
  br label %bb27

bb8:                                              ; preds = %bb6
  %12 = load ptr, ptr %v, align 8
  %13 = getelementptr inbounds i8, ptr %v, i64 8
  %14 = load i64, ptr %13, align 8
  %_20 = getelementptr inbounds nuw i32, ptr %12, i64 %pivot_pos
  %_0.i = load i32, ptr %_20, align 4
  store i32 %_0.i, ptr %pivot_copy, align 4
; call core::slice::sort::stable::quicksort::has_direct_interior_mutability::<i32>
  %_26 = call zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilitylECshXA3KcOxU02_8closures()
  %_25 = xor i1 %_26, true
; call <bool>::then_some::<&i32>
  %pivot_ref = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core4boolb9then_someRlECshXA3KcOxU02_8closures(i1 zeroext %_25, ptr align 4 %pivot_copy) #21
  store i8 0, ptr %perform_equal_partition, align 1
  %15 = load ptr, ptr %left_ancestor_pivot, align 8
  %16 = ptrtoint ptr %15 to i64
  %17 = icmp eq i64 %16, 0
  %_31 = select i1 %17, i64 0, i64 1
  %18 = trunc nuw i64 %_31 to i1
  br i1 %18, label %bb14, label %bb17

panic:                                            ; preds = %bb6
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %pivot_pos, i64 %_21.1, ptr align 8 @alloc_4b681e459e5d8eeddb2bdf3b83cf18ab) #25
  unreachable

bb14:                                             ; preds = %bb8
  %la_pivot = load ptr, ptr %left_ancestor_pivot, align 8
  %_36.0 = load ptr, ptr %v, align 8
  %19 = getelementptr inbounds i8, ptr %v, i64 8
  %_36.1 = load i64, ptr %19, align 8
  %_38 = icmp ult i64 %pivot_pos, %_36.1
  br i1 %_38, label %bb15, label %panic1

bb17:                                             ; preds = %bb15, %bb8
  store i64 0, ptr %left_partition_len, align 8
  %20 = load i8, ptr %perform_equal_partition, align 1
  %_40 = trunc nuw i8 %20 to i1
  br i1 %_40, label %bb20, label %bb18

bb15:                                             ; preds = %bb14
  %21 = load ptr, ptr %v, align 8
  %22 = getelementptr inbounds i8, ptr %v, i64 8
  %23 = load i64, ptr %22, align 8
  %_35 = getelementptr inbounds nuw i32, ptr %21, i64 %pivot_pos
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_33 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %is_less, ptr align 4 %la_pivot, ptr align 4 %_35) #21
  %24 = xor i1 %_33, true
  %25 = zext i1 %24 to i8
  store i8 %25, ptr %perform_equal_partition, align 1
  br label %bb17

panic1:                                           ; preds = %bb14
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %pivot_pos, i64 %_36.1, ptr align 8 @alloc_2b7dc74fc6b7aa0b08aab5733d36da25) #25
  unreachable

bb18:                                             ; preds = %bb17
  %_42.0 = load ptr, ptr %v, align 8
  %26 = getelementptr inbounds i8, ptr %v, i64 8
  %_42.1 = load i64, ptr %26, align 8
; call core::slice::sort::stable::quicksort::stable_partition::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  %_41 = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB20_(ptr align 4 %_42.0, i64 %_42.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext false, ptr align 8 %is_less)
  store i64 %_41, ptr %left_partition_len, align 8
  %_43 = load i64, ptr %left_partition_len, align 8
  %27 = icmp eq i64 %_43, 0
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %perform_equal_partition, align 1
  br label %bb20

bb20:                                             ; preds = %bb18, %bb17
  %29 = load i8, ptr %perform_equal_partition, align 1
  %_44 = trunc nuw i8 %29 to i1
  br i1 %_44, label %bb21, label %bb24

bb24:                                             ; preds = %bb20
  %_56.0 = load ptr, ptr %v, align 8
  %30 = getelementptr inbounds i8, ptr %v, i64 8
  %_56.1 = load i64, ptr %30, align 8
  %_57 = load i64, ptr %left_partition_len, align 8
; call <[i32]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl12split_at_mutCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %_55, ptr align 4 %_56.0, i64 %_56.1, i64 %_57, ptr align 8 @alloc_06823d4b39e256f98f8c7a33a4ce85ea) #21
  %left.0 = load ptr, ptr %_55, align 8
  %31 = getelementptr inbounds i8, ptr %_55, i64 8
  %left.1 = load i64, ptr %31, align 8
  %32 = getelementptr inbounds i8, ptr %_55, i64 16
  %right.0 = load ptr, ptr %32, align 8
  %33 = getelementptr inbounds i8, ptr %32, i64 8
  %right.1 = load i64, ptr %33, align 8
  %_59 = load i32, ptr %limit, align 4
; call core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0EB1S_(ptr align 4 %right.0, i64 %right.1, ptr align 4 %scratch.0, i64 %scratch.1, i32 %_59, ptr align 4 %pivot_ref, ptr align 8 %is_less) #26
  store ptr %left.0, ptr %v, align 8
  %34 = getelementptr inbounds i8, ptr %v, i64 8
  store i64 %left.1, ptr %34, align 8
  br label %bb1

bb21:                                             ; preds = %bb20
  %_46.0 = load ptr, ptr %v, align 8
  %35 = getelementptr inbounds i8, ptr %v, i64 8
  %_46.1 = load i64, ptr %35, align 8
  store ptr %is_less, ptr %_48, align 8
; call core::slice::sort::stable::quicksort::stable_partition::<i32, core::slice::sort::stable::quicksort::quicksort<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>::{closure#0}>
  %mid_eq = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionlNCINvB2_9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0E0EB2j_(ptr align 4 %_46.0, i64 %_46.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext true, ptr align 8 %_48)
  %_50.0 = load ptr, ptr %v, align 8
  %36 = getelementptr inbounds i8, ptr %v, i64 8
  %_50.1 = load i64, ptr %36, align 8
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %37 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 %mid_eq, ptr align 4 %_50.0, i64 %_50.1, ptr align 8 @alloc_d82d96a4fa703c840ac11f4b07c0ef3c) #21
  %_0.0.i = extractvalue { ptr, i64 } %37, 0
  %_0.1.i = extractvalue { ptr, i64 } %37, 1
  %_49.0 = extractvalue { ptr, i64 } %37, 0
  %_49.1 = extractvalue { ptr, i64 } %37, 1
  store ptr %_49.0, ptr %v, align 8
  %38 = getelementptr inbounds i8, ptr %v, i64 8
  store i64 %_49.1, ptr %38, align 8
  store ptr null, ptr %left_ancestor_pivot, align 8
  br label %bb1

bb28:                                             ; No predecessors!
  unreachable

bb27:                                             ; preds = %bb3, %bb5
  ret void
}

; <[_]>::reverse::revswap::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvMNtCsl10jNU3mE6R_4core5sliceSp7reverse7revswaplECshXA3KcOxU02_8closures(ptr align 4 %a.0, i64 %a.1, ptr align 4 %b.0, i64 %b.1, i64 %n) unnamed_addr #1 !guid !358 {
start:
  %i = alloca [8 x i8], align 8
  %_7 = alloca [32 x i8], align 8
  %_5 = alloca [32 x i8], align 8
; call <[i32]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl12split_at_mutCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %_5, ptr align 4 %a.0, i64 %a.1, i64 %n, ptr align 8 @alloc_ab5ed840fe8613ddcabc97b74e0b565e) #21
  %a.01 = load ptr, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  %a.12 = load i64, ptr %0, align 8
; call <[i32]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl12split_at_mutCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %_7, ptr align 4 %b.0, i64 %b.1, i64 %n, ptr align 8 @alloc_f7fcaa33fdba299ee035b5518e72c889) #21
  %b.03 = load ptr, ptr %_7, align 8
  %1 = getelementptr inbounds i8, ptr %_7, i64 8
  %b.14 = load i64, ptr %1, align 8
  store i64 0, ptr %i, align 8
  br label %bb3

bb3:                                              ; preds = %bb6, %start
  %_10 = load i64, ptr %i, align 8
  %_9 = icmp ult i64 %_10, %n
  br i1 %_9, label %bb4, label %bb8

bb8:                                              ; preds = %bb3
  ret void

bb4:                                              ; preds = %bb3
  %_13 = load i64, ptr %i, align 8
  %_16 = icmp ult i64 %_13, %a.12
  br i1 %_16, label %bb5, label %panic

bb5:                                              ; preds = %bb4
  %_12 = getelementptr inbounds nuw i32, ptr %a.01, i64 %_13
  %_19 = sub i64 %n, 1
  %_20 = load i64, ptr %i, align 8
  %_18 = sub i64 %_19, %_20
  %_23 = icmp ult i64 %_18, %b.14
  br i1 %_23, label %bb6, label %panic5

panic:                                            ; preds = %bb4
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_13, i64 %a.12, ptr align 8 @alloc_1466797b2db3a3ca9645efa4732978a2) #25
  unreachable

bb6:                                              ; preds = %bb5
  %_17 = getelementptr inbounds nuw i32, ptr %b.03, i64 %_18
; call core::mem::swap::<i32>
  call void @_RINvNtCsl10jNU3mE6R_4core3mem4swaplECshXA3KcOxU02_8closures(ptr align 4 %_12, ptr align 4 %_17) #21
  %2 = load i64, ptr %i, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %i, align 8
  br label %bb3

panic5:                                           ; preds = %bb5
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_18, i64 %b.14, ptr align 8 @alloc_853b9dc5190658ffe6dc67504ed95441) #25
  unreachable
}

; core::ptr::swap_nonoverlapping::runtime::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping7runtimelECshXA3KcOxU02_8closures(ptr %x, ptr %y, i64 %count) unnamed_addr #1 !guid !359 {
start:
  %_7 = alloca [8 x i8], align 8
; call core::ptr::slice_from_raw_parts_mut::<i32>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECshXA3KcOxU02_8closures(ptr %x, i64 %count) #21
  %slice.0 = extractvalue { ptr, i64 } %0, 0
  %slice.1 = extractvalue { ptr, i64 } %0, 1
; call core::mem::size_of_val_raw::<[i32]>
  %bytes = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSlECshXA3KcOxU02_8closures(ptr %slice.0, i64 %slice.1) #21
; call <core::num::nonzero::NonZero<usize>>::new
  %1 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %bytes) #21
  store i64 %1, ptr %_7, align 8
  %2 = load i64, ptr %_7, align 8
  %3 = icmp eq i64 %2, 0
  %_8 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_8 to i1
  br i1 %4, label %bb4, label %bb7

bb4:                                              ; preds = %start
  %bytes1 = load i64, ptr %_7, align 8
; call core::ptr::swap_nonoverlapping_bytes
  call void @_RNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytesCshXA3KcOxU02_8closures(ptr %x, ptr %y, i64 %bytes1) #21
  br label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb8:                                              ; No predecessors!
  unreachable
}

; core::iter::traits::iterator::Iterator::for_each::call::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_ENCINvMsk_NtB1i_3vecINtB2B_3VecB1d_E14extend_trustedINtNtNtBa_8adapters3map3MapINtNtB1S_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0EB49_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %f) unnamed_addr #1 !guid !360 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %f, i64 24, i1 false)
  ret void
}

; core::iter::traits::iterator::Iterator::for_each::call::<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1n_3VecjE14extend_trustedINtNtNtBa_8adapters3map3MapINtNtNtBc_5slice4iter4IterINtNtB1p_5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0EB4b_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %f) unnamed_addr #1 !guid !361 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %f, i64 24, i1 false)
  ret void
}

; core::iter::traits::iterator::Iterator::for_each::call::<i32, closures::main::{closure#5}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0EB1i_(ptr align 4 %f) unnamed_addr #1 !guid !362 {
start:
  ret ptr %f
}

; <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB20_8for_each4callINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtB12_8function2FnuEp6OutputjEL_ENCINvMsk_NtB38_3vecINtB4m_3VecB33_E14extend_trustedBN_E0E0EB1t_(i64 %self.0, i64 %self.1, ptr align 8 %g) unnamed_addr #0 personality ptr @rust_eh_personality !guid !363 {
start:
  %0 = alloca [24 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  %_6 = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %g, i64 24, i1 false)
; call core::iter::adapters::map::map_fold::<usize, alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, (), closures::main::{closure#4}, core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldjINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_EuNCNvCshXA3KcOxU02_8closures4mains2_0NCINvNvNtNtNtB6_6traits8iterator8Iterator8for_each4callBT_NCINvMsk_NtBY_3vecINtB3O_3VecBT_E14extend_trustedINtB2_3MapINtNtB1y_5range5RangejEB29_EE0E0EB2d_(ptr sret([24 x i8]) align 8 %_6, ptr align 8 %0)
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::adapters::map::map_fold<usize, alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, (), closures::main::{closure#4}, core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangejENtNtNtNtBa_4iter6traits8iterator8Iterator4folduNCINvNtNtBR_8adapters3map8map_foldjINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtB8_8function2FnuEp6OutputjEL_EuNCNvCshXA3KcOxU02_8closures4mains2_0NCINvNvBL_8for_each4callB25_NCINvMsk_NtB2a_3vecINtB4q_3VecB25_E14extend_trustedINtB1B_3MapB3_B3f_EE0E0E0EB3j_(i64 %self.0, i64 %self.1, ptr align 8 %_6) #21
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_9, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB3e_8for_each4calljNCINvMsk_NtB1s_3vecINtB4r_3VecjE14extend_trustedBN_E0E0EB2H_(ptr %self.0, ptr %self.1, ptr align 8 %g) unnamed_addr #0 personality ptr @rust_eh_personality !guid !364 {
start:
  %0 = alloca [24 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  %_6 = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %g, i64 24, i1 false)
; call core::iter::adapters::map::map_fold::<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_EjuNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvNtNtNtB6_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtBY_3vecINtB3N_3VecjE14extend_trustedINtB2_3MapINtNtNtB8_5slice4iter4IterBT_EB2a_EE0E0EB2e_(ptr sret([24 x i8]) align 8 %_6, ptr align 8 %0)
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::adapters::map::map_fold<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBb_3ops8function2FnuEp6OutputjEL_EENtNtNtNtBb_4iter6traits8iterator8Iterator4folduNCINvNtNtB2c_8adapters3map8map_foldRBQ_juNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvB26_8for_each4calljNCINvMsk_NtBV_3vecINtB4F_3VecjE14extend_trustedINtB2W_3MapBF_B3w_EE0E0E0EB3A_(ptr %self.0, ptr %self.1, ptr align 8 %_6) #21
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_9, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::adapters::map::map_fold<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBb_3ops8function2FnuEp6OutputjEL_EENtNtNtNtBb_4iter6traits8iterator8Iterator4folduNCINvNtNtB2c_8adapters3map8map_foldRBQ_juNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvB26_8for_each4calljNCINvMsk_NtBV_3vecINtB4F_3VecjE14extend_trustedINtB2W_3MapBF_B3w_EE0E0E0EB3A_(ptr %0, ptr %1, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !365 {
start:
  %2 = alloca [16 x i8], align 8
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %4, align 8
  store ptr %_8, ptr %end, align 8
; invoke <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::cmp::PartialEq>::eq
  %5 = invoke zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EENtNtB9_3cmp9PartialEq2eqCshXA3KcOxU02_8closures(ptr align 8 %self, ptr align 8 %end)
          to label %bb25 unwind label %cleanup

bb17:                                             ; preds = %bb21, %bb22, %cleanup
; invoke core::ptr::drop_glue::<core::iter::adapters::map::map_fold<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>::{closure#0}>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldRINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EjuNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtB1m_3vecINtB4b_3VecjE14extend_trustedINtBG_3MapINtNtNtB4_5slice4iter4IterB1h_EB2y_EE0E0E0EB2C_(ptr align 8 %f) #22
          to label %bb24 unwind label %terminate

cleanup:                                          ; preds = %bb3
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %2, align 8
  %9 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb17

bb25:                                             ; preds = %bb3
  %10 = zext i1 %5 to i8
  store i8 %10, ptr %_4, align 1
  br label %bb4

bb4:                                              ; preds = %bb25
  %11 = load i8, ptr %_4, align 1
  %12 = trunc nuw i8 %11 to i1
  br i1 %12, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
; call core::ptr::drop_glue::<core::iter::adapters::map::map_fold<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldRINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EjuNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtB1m_3vecINtB4b_3VecjE14extend_trustedINtBG_3MapINtNtNtB4_5slice4iter4IterB1h_EB2y_EE0E0E0EB2C_(ptr align 8 %f)
  br label %bb16

bb8:                                              ; preds = %bb6
  %13 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %13, align 8
  %_18 = load ptr, ptr %self, align 8
; invoke <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::offset_from_unsigned
  %14 = invoke i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %_17, ptr %_18)
          to label %bb26 unwind label %cleanup1

bb22:                                             ; preds = %bb19, %bb20, %cleanup1
  %15 = load i8, ptr %_34, align 1
  %16 = trunc nuw i8 %15 to i1
  br i1 %16, label %bb21, label %bb17

cleanup1:                                         ; preds = %bb13, %bb8
  %17 = landingpad { ptr, i32 }
          cleanup
  %18 = extractvalue { ptr, i32 } %17, 0
  %19 = extractvalue { ptr, i32 } %17, 1
  store ptr %18, ptr %2, align 8
  %20 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %19, ptr %20, align 8
  br label %bb22

bb26:                                             ; preds = %bb8
  store i64 %14, ptr %len, align 8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  br label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE3addCshXA3KcOxU02_8closures.exit

_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE3addCshXA3KcOxU02_8closures.exit: ; preds = %bb10
  %_3.i = getelementptr inbounds nuw %"alloc::boxed::Box<dyn core::ops::function::Fn() -> usize>", ptr %_26, i64 %_27
  br label %bb11

bb20:                                             ; preds = %cleanup2
  %21 = load i8, ptr %_33, align 1
  %22 = trunc nuw i8 %21 to i1
  br i1 %22, label %bb19, label %bb22

cleanup2:                                         ; preds = %bb12
  %23 = landingpad { ptr, i32 }
          cleanup
  %24 = extractvalue { ptr, i32 } %23, 0
  %25 = extractvalue { ptr, i32 } %23, 1
  store ptr %24, ptr %2, align 8
  %26 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %25, ptr %26, align 8
  br label %bb20

bb11:                                             ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE3addCshXA3KcOxU02_8closures.exit
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; invoke core::iter::adapters::map::map_fold::<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>::{closure#0}
  invoke void @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EjuNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtB10_3vecINtB3P_3VecjE14extend_trustedINtB4_3MapINtNtNtBa_5slice4iter4IterBV_EB2c_EE0E0E0B2g_(ptr align 8 %f, ptr align 8 %_3.i)
          to label %bb13 unwind label %cleanup2

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  %_29 = load i64, ptr %i, align 8
; invoke core::ub_checks::check_language_ub
  %_3.i45 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
          to label %_3.i4.noexc unwind label %cleanup1

_3.i4.noexc:                                      ; preds = %bb13
  br i1 %_3.i45, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %_3.i4.noexc
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCshXA3KcOxU02_8closures(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #24
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %_3.i4.noexc, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_34, align 1
; call core::ptr::drop_glue::<core::iter::adapters::map::map_fold<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldRINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EjuNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtB1m_3vecINtB4b_3VecjE14extend_trustedINtBG_3MapINtNtNtB4_5slice4iter4IterB1h_EB2y_EE0E0E0EB2C_(ptr align 8 %f)
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  ret void

bb19:                                             ; preds = %bb20
  br label %bb22

bb21:                                             ; preds = %bb22
  br label %bb17

terminate:                                        ; preds = %bb17
  %27 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb24:                                             ; preds = %bb17
  %28 = load i8, ptr %_35, align 1
  %29 = trunc nuw i8 %28 to i1
  br i1 %29, label %bb23, label %bb18

bb18:                                             ; preds = %bb23, %bb24
  %30 = load ptr, ptr %2, align 8
  %31 = getelementptr inbounds i8, ptr %2, i64 8
  %32 = load i32, ptr %31, align 8
  %33 = insertvalue { ptr, i32 } poison, ptr %30, 0
  %34 = insertvalue { ptr, i32 } %33, i32 %32, 1
  resume { ptr, i32 } %34

bb23:                                             ; preds = %bb24
  br label %bb18

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<i32> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<(), <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), i32, core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<()>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivelENtB6_26RangeInclusiveIteratorImpl13spec_try_folduNCINvMNtBJ_9try_traitINtB29_17NeverShortCircuituE10wrap_mut_2ulNCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0E0B2o_EB42_(ptr align 4 %self, ptr align 4 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !366 {
start:
  %_37 = alloca [1 x i8], align 1
  %_36 = alloca [1 x i8], align 1
  %_26 = alloca [0 x i8], align 1
  %_15 = alloca [0 x i8], align 1
  %f = alloca [8 x i8], align 8
  store ptr %0, ptr %f, align 8
  store i8 0, ptr %_37, align 1
  store i8 0, ptr %_36, align 1
  store i8 1, ptr %_37, align 1
; call <core::ops::range::RangeInclusive<i32>>::is_empty
  %_4 = call zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivelE8is_emptyCshXA3KcOxU02_8closures(ptr align 4 %self) #21
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
  store i8 1, ptr %_36, align 1
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
; call <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::from_output
  call void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try11from_outputCs7CppTae75M1_5alloc() #21
  br label %bb32

bb4:                                              ; preds = %bb12, %bb3
  %_10 = getelementptr inbounds i8, ptr %self, i64 4
  %_3.i = load i32, ptr %self, align 4
  %_4.i = load i32, ptr %_10, align 4
  %_0.i = icmp slt i32 %_3.i, %_4.i
  br label %bb5

bb5:                                              ; preds = %bb4
  br i1 %_0.i, label %bb6, label %bb14

bb14:                                             ; preds = %bb5
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  store i8 1, ptr %1, align 4
  %_25 = getelementptr inbounds i8, ptr %self, i64 4
; call <i32 as core::cmp::PartialEq>::eq
  %_23 = call zeroext i1 @_RNvXss_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB7_9PartialEq2eqCshXA3KcOxU02_8closures(ptr align 4 %self, ptr align 4 %_25) #21
  br label %bb15

bb6:                                              ; preds = %bb5
  %_12 = load i32, ptr %self, align 4
; call <i32 as core::iter::range::Step>::forward_unchecked
  %n = call i32 @_RNvXsI_NtNtCsl10jNU3mE6R_4core4iter5rangelNtB5_4Step17forward_uncheckedCshXA3KcOxU02_8closures(i32 %_12, i64 1) #21
  br label %bb7

bb15:                                             ; preds = %bb14
  br i1 %_23, label %bb16, label %bb21

bb21:                                             ; preds = %bb19, %bb15
  store i8 0, ptr %_36, align 1
; call <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::from_output
  call void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try11from_outputCs7CppTae75M1_5alloc() #21
  br label %bb22

bb16:                                             ; preds = %bb15
  store i8 0, ptr %_36, align 1
  %_31 = load i32, ptr %self, align 4
; call <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), i32, core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>::{closure#0}
  call void @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituE10wrap_mut_2ulNCINvNvNtNtNtNtB9_4iter6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0E0B2q_(ptr align 8 %f, i32 %_31) #21
  br label %bb17

bb17:                                             ; preds = %bb16
; call <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::branch
  call void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try6branchCs7CppTae75M1_5alloc() #21
  br label %bb18

bb18:                                             ; preds = %bb17
  br label %bb19

bb19:                                             ; preds = %bb18
  store i8 1, ptr %_36, align 1
  br label %bb21

bb22:                                             ; preds = %bb21
  store i8 0, ptr %_36, align 1
  br label %bb25

bb25:                                             ; preds = %bb24, %bb22
  ret void

bb20:                                             ; No predecessors!
; call <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCs7CppTae75M1_5alloc() #21
  br label %bb34

bb34:                                             ; preds = %bb20
  br label %bb23

bb23:                                             ; preds = %bb33, %bb34
  store i8 0, ptr %_36, align 1
  br label %bb24

bb7:                                              ; preds = %bb6
; call core::mem::replace::<i32>
  %n1 = call i32 @_RINvNtCsl10jNU3mE6R_4core3mem7replacelECshXA3KcOxU02_8closures(ptr align 4 %self, i32 %n) #21
  br label %bb8

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_36, align 1
; call <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), i32, core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>::{closure#0}
  call void @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituE10wrap_mut_2ulNCINvNvNtNtNtNtB9_4iter6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0E0B2q_(ptr align 8 %f, i32 %n1) #21
  br label %bb9

bb9:                                              ; preds = %bb8
; call <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::branch
  call void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try6branchCs7CppTae75M1_5alloc() #21
  br label %bb10

bb10:                                             ; preds = %bb9
  br label %bb12

bb12:                                             ; preds = %bb10
  store i8 1, ptr %_36, align 1
  br label %bb4

bb13:                                             ; No predecessors!
; call <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCs7CppTae75M1_5alloc() #21
  br label %bb33

bb33:                                             ; preds = %bb13
  br label %bb23

bb24:                                             ; preds = %bb32, %bb23
  br label %bb25

bb11:                                             ; No predecessors!
  unreachable

bb32:                                             ; preds = %bb2
  br label %bb24

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable

bb28:                                             ; No predecessors!
  unreachable

bb29:                                             ; No predecessors!
  unreachable

bb30:                                             ; No predecessors!
  unreachable

bb31:                                             ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<i32> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivelENtNtNtB8_6traits8iterator8Iterator4folduNCINvNvB1g_8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0EB2o_(ptr align 4 %self, ptr align 4 %fold) unnamed_addr #1 personality ptr @rust_eh_personality !guid !367 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
; call <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), i32, core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>
  %_7 = call align 4 ptr @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuituE10wrap_mut_2ulNCINvNvNtNtNtNtB7_4iter6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0EB2o_(ptr align 4 %fold) #21
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_8, align 1
; call <core::ops::range::RangeInclusive<i32> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), i32, core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<()>>
  call void @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivelENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvMNtBJ_9try_traitINtB24_17NeverShortCircuituE10wrap_mut_2ulNCINvNvB1g_8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0E0B2j_EB3t_(ptr align 4 %self, ptr align 4 %_7) #21
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<i32> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), i32, core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<()>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivelENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvMNtBJ_9try_traitINtB24_17NeverShortCircuituE10wrap_mut_2ulNCINvNvB1g_8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0E0B2j_EB3t_(ptr align 4 %self, ptr align 4 %f) unnamed_addr #1 !guid !368 {
start:
; call <core::ops::range::RangeInclusive<i32> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<(), <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), i32, core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<()>>
  call void @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivelENtB6_26RangeInclusiveIteratorImpl13spec_try_folduNCINvMNtBJ_9try_traitINtB29_17NeverShortCircuituE10wrap_mut_2ulNCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0E0B2o_EB42_(ptr align 4 %self, ptr align 4 %f) #21
  ret void
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::iter::traits::collect::FromIterator<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::from_iter::<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EEINtNtNtNtB16_4iter6traits7collect12FromIteratorBG_E9from_iterINtNtNtB22_8adapters3map3MapINtNtB14_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EEB3N_(ptr sret([24 x i8]) align 8 %_0, i64 %iter.0, i64 %iter.1) unnamed_addr #1 !guid !369 {
start:
; call <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters3map3MapINtNtNtB8_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtB2_12IntoIterator9into_iterB1I_(i64 %iter.0, i64 %iter.1) #21
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as alloc::vec::spec_from_iter::SpecFromIter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EEINtB2_12SpecFromIterBU_INtNtNtNtB1k_4iter8adapters3map3MapINtNtB1i_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE9from_iterB3w_(ptr sret([24 x i8]) align 8 %_0, i64 %_2.0, i64 %_2.1)
  ret void
}

; <alloc::vec::Vec<usize> as core::iter::traits::collect::FromIterator<usize>>::from_iter::<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorjE9from_iterINtNtNtBP_8adapters3map3MapINtNtNtBR_5slice4iter4IterINtNtB8_5boxed3BoxDINtNtNtBR_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EEB3O_(ptr sret([24 x i8]) align 8 %_0, ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !370 {
start:
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters3map3MapINtNtNtB8_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtB2_12IntoIterator9into_iterB2W_(ptr %iter.0, ptr %iter.1) #21
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter::SpecFromIter<usize, core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecjEINtB2_12SpecFromIterjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1q_5slice4iter4IterINtNtB6_5boxed3BoxDINtNtNtB1q_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE9from_iterB3A_(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, ptr %_2.1)
  ret void
}

; <core::ops::range::RangeInclusive<i32> as core::iter::traits::iterator::Iterator>::for_each::<closures::main::{closure#5}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivelENtNtNtNtBa_4iter6traits8iterator8Iterator8for_eachNCNvCshXA3KcOxU02_8closures4mains3_0EB1N_(ptr align 4 %self, ptr align 4 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !371 {
start:
  %_6 = alloca [1 x i8], align 1
  %_4 = alloca [12 x i8], align 4
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_4, ptr align 4 %self, i64 12, i1 false)
; call core::iter::traits::iterator::Iterator::for_each::call::<i32, closures::main::{closure#5}>
  %_5 = call align 4 ptr @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0EB1i_(ptr align 4 %f) #21
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; call <core::ops::range::RangeInclusive<i32> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>
  call void @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivelENtNtNtB8_6traits8iterator8Iterator4folduNCINvNvB1g_8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0EB2o_(ptr align 4 %_4, ptr align 4 %_5) #21
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::map::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, closures::main::{closure#4}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangejENtNtNtNtBa_4iter6traits8iterator8Iterator3mapINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtB8_8function2FnuEp6OutputjEL_ENCNvCshXA3KcOxU02_8closures4mains2_0EB2H_(i64 %self.0, i64 %self.1) unnamed_addr #1 !guid !372 {
start:
; call <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::new
  %0 = call { i64, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0E3newB1p_(i64 %self.0, i64 %self.1)
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::adapters::map::map_fold<usize, alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, (), closures::main::{closure#4}, core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangejENtNtNtNtBa_4iter6traits8iterator8Iterator4folduNCINvNtNtBR_8adapters3map8map_foldjINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtB8_8function2FnuEp6OutputjEL_EuNCNvCshXA3KcOxU02_8closures4mains2_0NCINvNvBL_8for_each4callB25_NCINvMsk_NtB2a_3vecINtB4q_3VecB25_E14extend_trustedINtB1B_3MapB3_B3f_EE0E0E0EB3j_(i64 %0, i64 %1, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !373 {
start:
  %2 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %_5 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  br label %bb1

bb1:                                              ; preds = %bb4, %start
; invoke <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %4 = invoke { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %self)
          to label %bb2 unwind label %cleanup

bb12:                                             ; preds = %cleanup
  %5 = load i8, ptr %_13, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb11, label %bb8

cleanup:                                          ; preds = %bb3, %bb1
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %2, align 8
  %10 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb12

bb2:                                              ; preds = %bb1
  %11 = extractvalue { i64, i64 } %4, 0
  %12 = extractvalue { i64, i64 } %4, 1
  store i64 %11, ptr %_5, align 8
  %13 = getelementptr inbounds i8, ptr %_5, i64 8
  store i64 %12, ptr %13, align 8
  %_7 = load i64, ptr %_5, align 8
  %14 = getelementptr inbounds i8, ptr %_5, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = trunc nuw i64 %_7 to i1
  br i1 %16, label %bb3, label %bb5

bb3:                                              ; preds = %bb2
  %17 = getelementptr inbounds i8, ptr %_5, i64 8
  %x = load i64, ptr %17, align 8
  store i8 0, ptr %_13, align 1
; invoke core::iter::adapters::map::map_fold::<usize, alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, (), closures::main::{closure#4}, core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>::{closure#0}
  invoke void @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldjINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EuNCNvCshXA3KcOxU02_8closures4mains2_0NCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4callBV_NCINvMsk_NtB10_3vecINtB3Q_3VecBV_E14extend_trustedINtB4_3MapINtNtB1A_5range5RangejEB2b_EE0E0E0B2f_(ptr align 8 %f, i64 %x)
          to label %bb4 unwind label %cleanup

bb5:                                              ; preds = %bb2
  store i8 0, ptr %_13, align 1
  store i8 0, ptr %_13, align 1
; call core::ptr::drop_glue::<core::iter::adapters::map::map_fold<usize, alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, (), closures::main::{closure#4}, core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldjINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EuNCNvCshXA3KcOxU02_8closures4mains2_0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4callB1h_NCINvMsk_NtB1m_3vecINtB4d_3VecB1h_E14extend_trustedINtBG_3MapINtNtB1W_5range5RangejEB2x_EE0E0E0EB2B_(ptr align 8 %f)
  br label %bb6

bb4:                                              ; preds = %bb3
  store i8 1, ptr %_13, align 1
  br label %bb1

bb6:                                              ; preds = %bb5
  ret void

bb13:                                             ; No predecessors!
  unreachable

bb8:                                              ; preds = %bb11, %bb12
; invoke core::ptr::drop_glue::<core::iter::adapters::map::map_fold<usize, alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, (), closures::main::{closure#4}, core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>::{closure#0}>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldjINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EuNCNvCshXA3KcOxU02_8closures4mains2_0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4callB1h_NCINvMsk_NtB1m_3vecINtB4d_3VecB1h_E14extend_trustedINtBG_3MapINtNtB1W_5range5RangejEB2x_EE0E0E0EB2B_(ptr align 8 %f) #22
          to label %bb9 unwind label %terminate

bb11:                                             ; preds = %bb12
  br label %bb8

terminate:                                        ; preds = %bb8
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb9:                                              ; preds = %bb8
  %19 = load ptr, ptr %2, align 8
  %20 = getelementptr inbounds i8, ptr %2, i64 8
  %21 = load i32, ptr %20, align 8
  %22 = insertvalue { ptr, i32 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i32 } %22, i32 %21, 1
  resume { ptr, i32 } %23
}

; <core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::iter::traits::iterator::Iterator>::map::<usize, closures::main::{closure#12}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EENtNtNtNtBa_4iter6traits8iterator8Iterator3mapjNCNvCshXA3KcOxU02_8closures4mainsa_0EB2N_(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !374 {
start:
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0E3newB2D_(ptr %self.0, ptr %self.1)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtNtNtBa_6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB2F_5boxed3BoxDINtNtBW_8function2FnuEp6OutputjEL_EEEB1n_(ptr sret([24 x i8]) align 8 %_0, i64 %self.0, i64 %self.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !375 {
start:
  %_6 = alloca [1 x i8], align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  store i8 0, ptr %_6, align 1
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::iter::traits::collect::FromIterator<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::from_iter::<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>
  call void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EEINtNtNtNtB16_4iter6traits7collect12FromIteratorBG_E9from_iterINtNtNtB22_8adapters3map3MapINtNtB14_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EEB3N_(ptr sret([24 x i8]) align 8 %_0, i64 %self.0, i64 %self.1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2K_3VecINtNtB2M_5boxed3BoxDINtNtBW_8function2FnuEp6OutputjEL_EE14extend_trustedB3_E0EB1n_(i64 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !376 {
start:
  %0 = alloca [24 x i8], align 8
  %_6 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %f, i64 24, i1 false)
; call core::iter::traits::iterator::Iterator::for_each::call::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>
  call void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_ENCINvMsk_NtB1i_3vecINtB2B_3VecB1d_E14extend_trustedINtNtNtBa_8adapters3map3MapINtNtB1S_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0EB49_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %0) #21
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; call <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>
  call void @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB20_8for_each4callINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtB12_8function2FnuEp6OutputjEL_ENCINvMsk_NtB38_3vecINtB4m_3VecB33_E14extend_trustedBN_E0E0EB1t_(i64 %self.0, i64 %self.1, ptr align 8 %_5)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtNtNtBa_6traits8iterator8Iterator7collectINtNtB1m_3vec3VecjEEB2B_(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, ptr %self.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !377 {
start:
  %_6 = alloca [1 x i8], align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  store i8 0, ptr %_6, align 1
; call <alloc::vec::Vec<usize> as core::iter::traits::collect::FromIterator<usize>>::from_iter::<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>
  call void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorjE9from_iterINtNtNtBP_8adapters3map3MapINtNtNtBR_5slice4iter4IterINtNtB8_5boxed3BoxDINtNtNtBR_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EEB3O_(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, ptr %self.1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvMsk_NtB1m_3vecINtB3Y_3VecjE14extend_trustedB3_E0EB2B_(ptr %self.0, ptr %self.1, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !378 {
start:
  %0 = alloca [24 x i8], align 8
  %_6 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %f, i64 24, i1 false)
; call core::iter::traits::iterator::Iterator::for_each::call::<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>
  call void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1n_3VecjE14extend_trustedINtNtNtBa_8adapters3map3MapINtNtNtBc_5slice4iter4IterINtNtB1p_5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0EB4b_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %0) #21
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>
  call void @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB3e_8for_each4calljNCINvMsk_NtB1s_3vecINtB4r_3VecjE14extend_trustedBN_E0E0EB2H_(ptr %self.0, ptr %self.1, ptr align 8 %_5)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; closures::compose::<i32, i32, alloc::string::String, closures::main::{closure#1}, closures::main::{closure#2}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvCshXA3KcOxU02_8closures7composellNtNtCs7CppTae75M1_5alloc6string6StringNCNvB4_4mains_0NCB1f_s0_0E0B4_(ptr sret([24 x i8]) align 8 %_0, ptr %_1, i32 %x) unnamed_addr #1 !guid !379 {
start:
; call closures::main::{closure#1}
  %_5 = call i32 @_RNCNvCshXA3KcOxU02_8closures4mains_0B3_(ptr %_1, i32 %x) #21
; call closures::main::{closure#2}
  call void @_RNCNvCshXA3KcOxU02_8closures4mains0_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr %_1, i32 %_5) #21
  ret void
}

; <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %_1, ptr align 4 %a, ptr align 4 %b) unnamed_addr #1 !guid !380 {
start:
  %_5 = alloca [1 x i8], align 1
  %_8 = load ptr, ptr %_1, align 8
; call closures::main::{closure#3}
  %0 = call i8 @_RNCNvCshXA3KcOxU02_8closures4mains1_0B3_(ptr %_8, ptr align 4 %a, ptr align 4 %b) #21
  store i8 %0, ptr %_5, align 1
; call <core::cmp::Ordering as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXsb_NtCsl10jNU3mE6R_4core3cmpNtB5_8OrderingNtB5_9PartialEq2eqCshXA3KcOxU02_8closures(ptr %_5, ptr @alloc_9a72dc1c87ddefcce62e4b5ab68e5150) #21
  ret i1 %_0
}

; <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), i32, core::iter::traits::iterator::Iterator::for_each::call<i32, closures::main::{closure#5}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituE10wrap_mut_2ulNCINvNvNtNtNtNtB9_4iter6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0E0B2q_(ptr align 8 %_1, i32 %b) unnamed_addr #1 !guid !381 {
start:
; call core::iter::traits::iterator::Iterator::for_each::call::<i32, closures::main::{closure#5}>::{closure#0}
  call void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0B1k_(ptr align 8 %_1, i32 %b) #21
  ret void
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted::<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB8_3VecINtNtBa_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE14extend_trustedINtNtNtNtB18_4iter8adapters3map3MapINtNtB16_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0B3d_(ptr align 8 %_1, ptr %0, ptr align 8 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !382 {
start:
  %2 = alloca [16 x i8], align 8
  %_11 = alloca [1 x i8], align 1
  %element = alloca [16 x i8], align 8
  store ptr %0, ptr %element, align 8
  %3 = getelementptr inbounds i8, ptr %element, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_11, align 1
  store i8 1, ptr %_11, align 1
  %4 = getelementptr inbounds i8, ptr %_1, i64 16
  %_5 = load ptr, ptr %4, align 8
; invoke <alloc::vec::set_len_on_drop::SetLenOnDrop>::current_len
  %_6 = invoke i64 @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop11current_lenCshXA3KcOxU02_8closures(ptr align 8 %_1)
          to label %bb1 unwind label %cleanup

bb7:                                              ; preds = %cleanup
  %5 = load i8, ptr %_11, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

cleanup:                                          ; preds = %bb3, %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %2, align 8
  %10 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb7

bb1:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw %"alloc::boxed::Box<dyn core::ops::function::Fn() -> usize>", ptr %_5, i64 %_6
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_11, align 1
  %_8.0 = load ptr, ptr %element, align 8
  %11 = getelementptr inbounds i8, ptr %element, i64 8
  %_8.1 = load ptr, ptr %11, align 8
  store ptr %_8.0, ptr %_0.i, align 8
  %12 = getelementptr inbounds i8, ptr %_0.i, i64 8
  store ptr %_8.1, ptr %12, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
; invoke <alloc::vec::set_len_on_drop::SetLenOnDrop>::increment_len
  invoke void @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop13increment_lenCshXA3KcOxU02_8closures(ptr align 8 %_1, i64 1)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
  ret void

bb5:                                              ; preds = %bb6, %bb7
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb6:                                              ; preds = %bb7
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %element) #22
          to label %bb5 unwind label %terminate

terminate:                                        ; preds = %bb6
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable
}

; <alloc::vec::Vec<usize>>::extend_trusted::<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB8_3VecjE14extend_trustedINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB19_5slice4iter4IterINtNtBa_5boxed3BoxDINtNtNtB19_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0B3j_(ptr align 8 %_1, i64 %element) unnamed_addr #1 personality ptr @rust_eh_personality !guid !383 {
start:
  %_11 = alloca [1 x i8], align 1
  store i8 0, ptr %_11, align 1
  store i8 1, ptr %_11, align 1
  %0 = getelementptr inbounds i8, ptr %_1, i64 16
  %_5 = load ptr, ptr %0, align 8
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::current_len
  %_6 = call i64 @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop11current_lenCshXA3KcOxU02_8closures(ptr align 8 %_1) #21
  br label %bb1

bb1:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i64, ptr %_5, i64 %_6
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_11, align 1
  store i64 %element, ptr %_0.i, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::increment_len
  call void @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop13increment_lenCshXA3KcOxU02_8closures(ptr align 8 %_1, i64 1) #21
  br label %bb4

bb4:                                              ; preds = %bb3
  ret void

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshXA3KcOxU02_8closures(ptr align 8 %_1) unnamed_addr #1 !guid !384 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshXA3KcOxU02_8closures(ptr %_4) #26
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshXA3KcOxU02_8closures() #21
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshXA3KcOxU02_8closures(i8 %_2) #21
  ret i32 %_0
}

; core::iter::adapters::map::map_fold::<&alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, usize, (), closures::main::{closure#12}, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EjuNCNvCshXA3KcOxU02_8closures4mainsa_0NCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtB10_3vecINtB3P_3VecjE14extend_trustedINtB4_3MapINtNtNtBa_5slice4iter4IterBV_EB2c_EE0E0E0B2g_(ptr align 8 %_1, ptr align 8 %elt) unnamed_addr #1 personality ptr @rust_eh_personality !guid !385 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
  %_8 = getelementptr inbounds i8, ptr %_1, i64 24
; call closures::main::{closure#12}
  %_7 = call i64 @_RNCNvCshXA3KcOxU02_8closures4mainsa_0B3_(ptr %_8, ptr align 8 %elt) #21
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call core::iter::traits::iterator::Iterator::for_each::call::<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}
  call void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1p_3VecjE14extend_trustedINtNtNtBc_8adapters3map3MapINtNtNtBe_5slice4iter4IterINtNtB1r_5boxed3BoxDINtNtNtBe_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0E0B4d_(ptr align 8 %_1, i64 %_7) #21
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_10, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; core::iter::adapters::map::map_fold::<usize, alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, (), closures::main::{closure#4}, core::iter::traits::iterator::Iterator::for_each::call<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldjINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EuNCNvCshXA3KcOxU02_8closures4mains2_0NCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4callBV_NCINvMsk_NtB10_3vecINtB3Q_3VecBV_E14extend_trustedINtB4_3MapINtNtB1A_5range5RangejEB2b_EE0E0E0B2f_(ptr align 8 %_1, i64 %elt) unnamed_addr #1 personality ptr @rust_eh_personality !guid !386 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
  %_8 = getelementptr inbounds i8, ptr %_1, i64 24
; call closures::main::{closure#4}
  %0 = call { ptr, ptr } @_RNCNvCshXA3KcOxU02_8closures4mains2_0B3_(ptr %_8, i64 %elt) #21
  %_7.0 = extractvalue { ptr, ptr } %0, 0
  %_7.1 = extractvalue { ptr, ptr } %0, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call core::iter::traits::iterator::Iterator::for_each::call::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}
  call void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBe_3ops8function2FnuEp6OutputjEL_ENCINvMsk_NtB1k_3vecINtB2D_3VecB1f_E14extend_trustedINtNtNtBc_8adapters3map3MapINtNtB1U_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0E0B4b_(ptr align 8 %_1, ptr %_7.0, ptr align 8 %_7.1) #21
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_10, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; core::slice::sort::stable::quicksort::quicksort::<i32, <[i32]>::sort_by<closures::main::{closure#3}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0E0B1U_(ptr align 8 %_1, ptr align 4 %a, ptr align 4 %b) unnamed_addr #1 !guid !387 {
start:
  %_6 = load ptr, ptr %_1, align 8
; call <[i32]>::sort_by::<closures::main::{closure#3}>::{closure#0}
  %_4 = call zeroext i1 @_RNCINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0E0BL_(ptr align 8 %_6, ptr align 4 %b, ptr align 4 %a) #21
  %_0 = xor i1 %_4, true
  ret i1 %_0
}

; core::iter::traits::iterator::Iterator::for_each::call::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBe_3ops8function2FnuEp6OutputjEL_ENCINvMsk_NtB1k_3vecINtB2D_3VecB1f_E14extend_trustedINtNtNtBc_8adapters3map3MapINtNtB1U_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0E0B4b_(ptr align 8 %_1, ptr %item.0, ptr align 8 %item.1) unnamed_addr #1 !guid !388 {
start:
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted::<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::{closure#0}
  call void @_RNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB8_3VecINtNtBa_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE14extend_trustedINtNtNtNtB18_4iter8adapters3map3MapINtNtB16_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE0B3d_(ptr align 8 %_1, ptr %item.0, ptr align 8 %item.1) #21
  ret void
}

; core::iter::traits::iterator::Iterator::for_each::call::<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1p_3VecjE14extend_trustedINtNtNtBc_8adapters3map3MapINtNtNtBe_5slice4iter4IterINtNtB1r_5boxed3BoxDINtNtNtBe_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0E0B4d_(ptr align 8 %_1, i64 %item) unnamed_addr #1 !guid !389 {
start:
; call <alloc::vec::Vec<usize>>::extend_trusted::<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::{closure#0}
  call void @_RNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB8_3VecjE14extend_trustedINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB19_5slice4iter4IterINtNtBa_5boxed3BoxDINtNtNtB19_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE0B3j_(ptr align 8 %_1, i64 %item) #21
  ret void
}

; core::iter::traits::iterator::Iterator::for_each::call::<i32, closures::main::{closure#5}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calllNCNvCshXA3KcOxU02_8closures4mains3_0E0B1k_(ptr align 8 %_1, i32 %item) unnamed_addr #1 !guid !390 {
start:
; call closures::main::{closure#5}
  call void @_RNCNvCshXA3KcOxU02_8closures4mains3_0B3_(ptr align 8 %_1, i32 %item) #21
  ret void
}

; closures::main::{closure#4}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNCNvCshXA3KcOxU02_8closures4mains2_00B5_(ptr align 8 %_1) unnamed_addr #1 !guid !391 {
start:
  %_2 = load i64, ptr %_1, align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_2, i64 10)
  %_3.0 = extractvalue { i64, i1 } %0, 0
  %_3.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_3.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i64 %_3.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_11b7222e38e467be99f52fe6836b7504) #25
  unreachable
}

; closures::make_adder::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCshXA3KcOxU02_8closures10make_adder0B3_(ptr align 4 %_1, i32 %x) unnamed_addr #1 !guid !392 {
start:
  %_3 = load i32, ptr %_1, align 4
  %0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %x, i32 %_3)
  %_4.0 = extractvalue { i32, i1 } %0, 0
  %_4.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_4.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_4.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_49ce66a1f0abad2a7a12818bca93edfa) #25
  unreachable
}

; closures::make_counter::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCshXA3KcOxU02_8closures12make_counter0B3_(ptr align 4 %_1) unnamed_addr #1 !guid !393 {
start:
  %0 = load i32, ptr %_1, align 4
  %_2.0 = add i32 %0, 1
  %_2.1 = icmp ult i32 %_2.0, %0
  br i1 %_2.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  store i32 %_2.0, ptr %_1, align 4
  %_0 = load i32, ptr %_1, align 4
  ret i32 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_883f8141c9a30c7bbd66eeb6fd38f3b2) #25
  unreachable
}

; closures::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCshXA3KcOxU02_8closures4main0B3_(ptr align 8 %_1) unnamed_addr #1 !guid !394 {
start:
  %_4 = load ptr, ptr %_1, align 8
  %_5 = load ptr, ptr %_1, align 8
; call <alloc::vec::Vec<usize>>::len
  %_2 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE3lenCshXA3KcOxU02_8closures(ptr align 8 %_5) #21
; call <alloc::vec::Vec<usize>>::push
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE4pushCshXA3KcOxU02_8closures(ptr align 8 %_4, i64 %_2) #21
  ret void
}

; closures::main::{closure#2}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCshXA3KcOxU02_8closures4mains0_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr %_1, i32 %0) unnamed_addr #1 !guid !395 {
start:
  %_8 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_3 = alloca [24 x i8], align 8
  %y = alloca [4 x i8], align 4
  store i32 %0, ptr %y, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_8, ptr align 4 %y) #21
  %1 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %_8, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<6, 1>
  %2 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj6_Kj1_EB8_(ptr @alloc_19577330274845de4d5d8ab514a8941e, ptr align 8 %args) #21
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call alloc::fmt::format
  call void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_3, ptr %_4.0, ptr %_4.1) #21
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_3, i64 24, i1 false)
  ret void
}

; closures::main::{closure#3}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNCNvCshXA3KcOxU02_8closures4mains1_0B3_(ptr %_1, ptr align 4 %a, ptr align 4 %b) unnamed_addr #1 !guid !396 {
start:
; call <i32 as core::cmp::Ord>::cmp
  %_0 = call i8 @_RNvXs1d_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB8_3Ord3cmpCshXA3KcOxU02_8closures(ptr align 4 %b, ptr align 4 %a) #21
  ret i8 %_0
}

; closures::main::{closure#4}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNCNvCshXA3KcOxU02_8closures4mains2_0B3_(ptr %_1, i64 %i) unnamed_addr #1 personality ptr @rust_eh_personality !guid !397 {
start:
  %_4.i = alloca [1 x i8], align 1
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; call alloc::boxed::box_new_uninit
  %_3.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshXA3KcOxU02_8closures(i64 8, i64 8) #21
  store i8 0, ptr %_4.i, align 1
  store i64 %i, ptr %_3.i, align 8
  %0 = insertvalue { ptr, ptr } poison, ptr %_3.i, 0
  %1 = insertvalue { ptr, ptr } %0, ptr @vtable.3, 1
  ret { ptr, ptr } %1
}

; closures::main::{closure#5}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCshXA3KcOxU02_8closures4mains3_0B3_(ptr align 8 %_1, i32 %x) unnamed_addr #1 !guid !398 {
start:
; call core::hint::black_box::<i32>
  %_4 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshXA3KcOxU02_8closures(i32 2) #21
  %0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %x, i32 %_4)
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %panic, label %bb2

bb2:                                              ; preds = %start
  %_7 = load ptr, ptr %_1, align 8
  %1 = load i32, ptr %_7, align 4
  %2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %1, i32 %_5.0)
  %_6.0 = extractvalue { i32, i1 } %2, 0
  %_6.1 = extractvalue { i32, i1 } %2, 1
  %_8 = load ptr, ptr %_1, align 8
  br i1 %_6.1, label %panic1, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_7182b4eab97ac9715161e806fa0b46e7) #25
  unreachable

bb3:                                              ; preds = %bb2
  %_9 = load ptr, ptr %_1, align 8
  store i32 %_6.0, ptr %_9, align 4
  ret void

panic1:                                           ; preds = %bb2
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_eac2b581b65e96d58e47255cf376d3af) #25
  unreachable
}

; closures::main::{closure#6}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCshXA3KcOxU02_8closures4mains4_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_1) unnamed_addr #1 !guid !399 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_1, i64 24, i1 false)
  ret void
}

; closures::main::{closure#7}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNvCshXA3KcOxU02_8closures4mains5_0B3_(ptr %_1, i64 %n) unnamed_addr #1 !guid !400 {
start:
; call closures::main::{closure#7}::fact
  %_0 = call i64 @_RNvNCNvCshXA3KcOxU02_8closures4mains5_04fact(i64 %n)
  ret i64 %_0
}

; closures::main::{closure#8}
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNCNvCshXA3KcOxU02_8closures4mains6_0B3_(ptr %_1, double %a, double %b) unnamed_addr #1 !guid !401 {
start:
  %_0 = fadd double %a, %b
  ret double %_0
}

; closures::main::{closure#9}
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNCNvCshXA3KcOxU02_8closures4mains7_0B3_(ptr %_1, double %a, double %b) unnamed_addr #1 !guid !402 {
start:
  %_0 = fmul double %a, %b
  ret double %_0
}

; closures::main::{closure#10}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNvCshXA3KcOxU02_8closures4mains8_0B3_(ptr align 8 %_1, ptr align 8 %s) unnamed_addr #1 personality ptr @rust_eh_personality !guid !403 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::string::String>::len
  %_3 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCshXA3KcOxU02_8closures(ptr align 8 %s)
          to label %bb1 unwind label %cleanup

bb6:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %s) #22
          to label %bb7 unwind label %terminate

cleanup:                                          ; preds = %panic, %bb1, %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb6

bb1:                                              ; preds = %start
; invoke <alloc::string::String>::len
  %_5 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCshXA3KcOxU02_8closures(ptr align 8 %_1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  %_7.0 = add i64 %_3, %_5
  %_7.1 = icmp ult i64 %_7.0, %_3
  br i1 %_7.1, label %panic, label %bb3

bb3:                                              ; preds = %bb2
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %s)
          to label %bb4 unwind label %cleanup1

panic:                                            ; preds = %bb2
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_ad2cb06a096b843358bb7babe59e7320) #27
          to label %unreachable unwind label %cleanup

unreachable:                                      ; preds = %panic
  unreachable

bb7:                                              ; preds = %bb6, %cleanup1
; invoke core::ptr::drop_glue::<closures::main::{closure#10}>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCNvCshXA3KcOxU02_8closures4mains8_0EBF_(ptr align 8 %_1) #22
          to label %bb8 unwind label %terminate

cleanup1:                                         ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb7

bb4:                                              ; preds = %bb3
; call core::ptr::drop_glue::<closures::main::{closure#10}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCNvCshXA3KcOxU02_8closures4mains8_0EBF_(ptr align 8 %_1)
  ret i64 %_7.0

terminate:                                        ; preds = %bb7, %bb6
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb8:                                              ; preds = %bb7
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; closures::main::{closure#11}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCshXA3KcOxU02_8closures4mains9_0B3_(ptr %_1, i32 %x) unnamed_addr #1 !guid !404 {
start:
  %0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %x, i32 1)
  %_3.0 = extractvalue { i32, i1 } %0, 0
  %_3.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_3.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_3.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_1ee95cd7edfc13d03512a15866876812) #25
  unreachable
}

; closures::main::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCshXA3KcOxU02_8closures4mains_0B3_(ptr %_1, i32 %x) unnamed_addr #1 !guid !405 {
start:
  %0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %x, i32 1)
  %_3.0 = extractvalue { i32, i1 } %0, 0
  %_3.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_3.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_3.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_d408193c092dd785417ad926b4403743) #25
  unreachable
}

; closures::main::{closure#12}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNvCshXA3KcOxU02_8closures4mainsa_0B3_(ptr %_1, ptr align 8 %f) unnamed_addr #1 !guid !406 {
start:
; call <alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>> as core::ops::function::Fn<()>>::call
  %_0 = call i64 @_RNvXsv_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EIBJ_uE4callCshXA3KcOxU02_8closures(ptr align 8 %f)
  ret i64 %_0
}

; closures::boxed::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCshXA3KcOxU02_8closures5boxed0B3_(ptr %_1, i32 %x) unnamed_addr #1 !guid !407 {
start:
  %0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %x, i32 1)
  %_3.0 = extractvalue { i32, i1 } %0, 0
  %_3.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_3.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_3.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_05940ffd410c2695e9f6b6e120c9bc27) #25
  unreachable
}

; closures::boxed::{closure#2}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCshXA3KcOxU02_8closures5boxeds0_0B3_(ptr %_1, i32 %x) unnamed_addr #1 !guid !408 {
start:
  %_3 = icmp eq i32 %x, -2147483648
  br i1 %_3, label %panic, label %bb1

bb1:                                              ; preds = %start
  %_0 = sub i32 0, %x
  ret i32 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_neg_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_neg_overflow(ptr align 8 @alloc_292f47fe07f654b3daeb53c95309879e) #25
  unreachable
}

; closures::boxed::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCshXA3KcOxU02_8closures5boxeds_0B3_(ptr %_1, i32 %x) unnamed_addr #1 !guid !409 {
start:
  %0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %x, i32 %x)
  %_3.0 = extractvalue { i32, i1 } %0, 0
  %_3.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_3.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_3.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_823e4ac05cf949d91880645767c98b2e) #25
  unreachable
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitTReFddEdEEE4next0CshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_1.0, i64 %_1.1, i64 %idx) unnamed_addr #1 !guid !410 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>::get_unchecked::<usize>
  %_3 = call align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitTReFddEdEE13get_uncheckedjECshXA3KcOxU02_8closures(ptr align 8 %_1.0, i64 %_1.1, i64 %idx, ptr align 8 @alloc_ac893681874450253b62899ecf8cf06a) #21
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_3, i64 24, i1 false)
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshXA3KcOxU02_8closures(ptr %_1) unnamed_addr #1 !guid !411 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshXA3KcOxU02_8closures(ptr %0) #21
  ret i32 %_0
}

; <closures::main::{closure#4}::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNSNvYNCNCNvCshXA3KcOxU02_8closures4mains2_00INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableBa_(ptr %_1) unnamed_addr #1 !guid !412 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load i64, ptr %_1, align 8
; call <closures::main::{closure#4}::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i64 @_RNvYNCNCNvCshXA3KcOxU02_8closures4mains2_00INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceB8_(i64 %0) #21
  ret i64 %_0
}

; <closures::boxed::{closure#0} as core::ops::function::FnOnce<(i32,)>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCNvCshXA3KcOxU02_8closures5boxed0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_once6vtableB8_(ptr %_1, i32 %0) unnamed_addr #1 !guid !413 {
start:
  %_2 = alloca [4 x i8], align 4
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
; call <closures::boxed::{closure#0} as core::ops::function::FnOnce<(i32,)>>::call_once
  %_0 = call i32 @_RNvYNCNvCshXA3KcOxU02_8closures5boxed0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_onceB6_(i32 %1) #21
  ret i32 %_0
}

; <closures::boxed::{closure#2} as core::ops::function::FnOnce<(i32,)>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCNvCshXA3KcOxU02_8closures5boxeds0_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_once6vtableB8_(ptr %_1, i32 %0) unnamed_addr #1 !guid !414 {
start:
  %_2 = alloca [4 x i8], align 4
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
; call <closures::boxed::{closure#2} as core::ops::function::FnOnce<(i32,)>>::call_once
  %_0 = call i32 @_RNvYNCNvCshXA3KcOxU02_8closures5boxeds0_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_onceB6_(i32 %1) #21
  ret i32 %_0
}

; <closures::boxed::{closure#1} as core::ops::function::FnOnce<(i32,)>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCNvCshXA3KcOxU02_8closures5boxeds_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_once6vtableB8_(ptr %_1, i32 %0) unnamed_addr #1 !guid !415 {
start:
  %_2 = alloca [4 x i8], align 4
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
; call <closures::boxed::{closure#1} as core::ops::function::FnOnce<(i32,)>>::call_once
  %_0 = call i32 @_RNvYNCNvCshXA3KcOxU02_8closures5boxeds_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_onceB6_(i32 %1) #21
  ret i32 %_0
}

; closures::make_adder
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCshXA3KcOxU02_8closures10make_adder(i32 %n) unnamed_addr #0 !guid !416 {
start:
  ret i32 %n
}

; closures::make_counter
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCshXA3KcOxU02_8closures12make_counter() unnamed_addr #0 !guid !417 {
start:
  ret i32 0
}

; closures::dbl
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCshXA3KcOxU02_8closures3dbl(i32 %x) unnamed_addr #0 !guid !418 {
start:
  %0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %x, i32 2)
  %_2.0 = extractvalue { i32, i1 } %0, 0
  %_2.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_2.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_2.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_bdb8d18f3ed9bc69be55303901373737) #25
  unreachable
}

; closures::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCshXA3KcOxU02_8closures4main() unnamed_addr #0 personality ptr @rust_eh_personality !guid !419 {
start:
  %0 = alloca [72 x i8], align 8
  %1 = alloca [24 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %_224 = alloca [1 x i8], align 1
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_199 = alloca [8 x i8], align 8
  %n = alloca [16 x i8], align 8
  %_189 = alloca [24 x i8], align 8
  %iter13 = alloca [88 x i8], align 8
  %_187 = alloca [88 x i8], align 8
  %_184 = alloca [24 x i8], align 8
  %_181 = alloca [24 x i8], align 8
  %_178 = alloca [24 x i8], align 8
  %ops = alloca [72 x i8], align 8
  %_174 = alloca [16 x i8], align 8
  %args12 = alloca [16 x i8], align 8
  %_169 = alloca [8 x i8], align 8
  %_164 = alloca [0 x i8], align 1
  %_161 = alloca [16 x i8], align 8
  %args11 = alloca [16 x i8], align 8
  %_159 = alloca [24 x i8], align 8
  %once = alloca [24 x i8], align 8
  %s = alloca [24 x i8], align 8
  %_150 = alloca [16 x i8], align 8
  %args10 = alloca [16 x i8], align 8
  %_142 = alloca [12 x i8], align 4
  %total = alloca [4 x i8], align 4
  %_137 = alloca [16 x i8], align 8
  %args9 = alloca [16 x i8], align 8
  %_131 = alloca [24 x i8], align 8
  %fs = alloca [24 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args8 = alloca [16 x i8], align 8
  %v = alloca [24 x i8], align 8
  %_108 = alloca [16 x i8], align 8
  %_107 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_104 = alloca [4 x i8], align 4
  %_101 = alloca [4 x i8], align 4
  %_94 = alloca [16 x i8], align 8
  %args6 = alloca [16 x i8], align 8
  %_89 = alloca [24 x i8], align 8
  %_84 = alloca [0 x i8], align 1
  %_81 = alloca [16 x i8], align 8
  %args5 = alloca [16 x i8], align 8
  %hits = alloca [24 x i8], align 8
  %_69 = alloca [16 x i8], align 8
  %args4 = alloca [16 x i8], align 8
  %_66 = alloca [24 x i8], align 8
  %_65 = alloca [24 x i8], align 8
  %_64 = alloca [8 x i8], align 8
  %owned = alloca [24 x i8], align 8
  %_56 = alloca [16 x i8], align 8
  %args3 = alloca [16 x i8], align 8
  %_51 = alloca [16 x i8], align 8
  %_49 = alloca [4 x i8], align 4
  %_41 = alloca [2 x i8], align 1
  %iter = alloca [2 x i8], align 1
  %_35 = alloca [16 x i8], align 8
  %_34 = alloca [16 x i8], align 8
  %_33 = alloca [16 x i8], align 8
  %args2 = alloca [48 x i8], align 8
  %_30 = alloca [4 x i8], align 4
  %_27 = alloca [4 x i8], align 4
  %_24 = alloca [4 x i8], align 4
  %args1 = alloca [24 x i8], align 8
  %c = alloca [4 x i8], align 4
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_11 = alloca [4 x i8], align 4
  %_7 = alloca [4 x i8], align 4
  %add5 = alloca [4 x i8], align 4
  store i8 0, ptr %_224, align 1
; call core::hint::black_box::<i32>
  %_2 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshXA3KcOxU02_8closures(i32 5) #21
; call closures::make_adder
  %3 = call i32 @_RNvCshXA3KcOxU02_8closures10make_adder(i32 %_2)
  store i32 %3, ptr %add5, align 4
; call closures::make_adder::{closure#0}
  %4 = call i32 @_RNCNvCshXA3KcOxU02_8closures10make_adder0B3_(ptr align 4 %add5, i32 1) #21
  store i32 %4, ptr %_7, align 4
; call closures::make_adder::{closure#0}
  %5 = call i32 @_RNCNvCshXA3KcOxU02_8closures10make_adder0B3_(ptr align 4 %add5, i32 10) #21
  store i32 %5, ptr %_11, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_15, ptr align 4 %_7) #21
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_16, ptr align 4 %_11) #21
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_15, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_16, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args) #21
  %_4.0 = extractvalue { ptr, ptr } %8, 0
  %_4.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_4.0, ptr %_4.1)
; call closures::make_counter
  %9 = call i32 @_RNvCshXA3KcOxU02_8closures12make_counter()
  store i32 %9, ptr %c, align 4
; call closures::make_counter::{closure#0}
  %10 = call i32 @_RNCNvCshXA3KcOxU02_8closures12make_counter0B3_(ptr align 4 %c) #21
  store i32 %10, ptr %_24, align 4
; call closures::make_counter::{closure#0}
  %11 = call i32 @_RNCNvCshXA3KcOxU02_8closures12make_counter0B3_(ptr align 4 %c) #21
  store i32 %11, ptr %_27, align 4
; call closures::make_counter::{closure#0}
  %12 = call i32 @_RNCNvCshXA3KcOxU02_8closures12make_counter0B3_(ptr align 4 %c) #21
  store i32 %12, ptr %_30, align 4
  store ptr %_24, ptr %args1, align 8
  %13 = getelementptr inbounds i8, ptr %args1, i64 8
  store ptr %_27, ptr %13, align 8
  %14 = getelementptr inbounds i8, ptr %args1, i64 16
  store ptr %_30, ptr %14, align 8
  %_208 = load ptr, ptr %args1, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_33, ptr align 4 %_208) #21
  %15 = getelementptr inbounds i8, ptr %args1, i64 8
  %_209 = load ptr, ptr %15, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_34, ptr align 4 %_209) #21
  %16 = getelementptr inbounds i8, ptr %args1, i64 16
  %_210 = load ptr, ptr %16, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_35, ptr align 4 %_210) #21
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_33, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_34, i64 16, i1 false)
  %19 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %19, ptr align 8 %_35, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %20 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECshXA3KcOxU02_8closures(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args2) #21
  %_21.0 = extractvalue { ptr, ptr } %20, 0
  %_21.1 = extractvalue { ptr, ptr } %20, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
; call <core::ops::range::Range<u8> as core::iter::traits::collect::IntoIterator>::into_iter
  %21 = call { i8, i8 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangehENtB2_12IntoIterator9into_iterCsgE4ujGKm1Ln_11miniz_oxide(i8 0, i8 3) #21
  %_38.0 = extractvalue { i8, i8 } %21, 0
  %_38.1 = extractvalue { i8, i8 } %21, 1
  store i8 %_38.0, ptr %iter, align 1
  %22 = getelementptr inbounds i8, ptr %iter, i64 1
  store i8 %_38.1, ptr %22, align 1
  br label %bb19

bb19:                                             ; preds = %bb30, %start
; call <core::ops::range::Range<u8> as core::iter::traits::iterator::Iterator>::next
  %23 = call { i1, i8 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangehENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr %iter) #21
  %24 = extractvalue { i1, i8 } %23, 0
  %25 = extractvalue { i1, i8 } %23, 1
  %26 = zext i1 %24 to i8
  store i8 %26, ptr %_41, align 1
  %27 = getelementptr inbounds i8, ptr %_41, i64 1
  store i8 %25, ptr %27, align 1
  %28 = load i8, ptr %_41, align 1
  %29 = trunc nuw i8 %28 to i1
  %30 = getelementptr inbounds i8, ptr %_41, i64 1
  %31 = load i8, ptr %30, align 1
  %_43 = zext i1 %29 to i64
  %32 = trunc nuw i64 %_43 to i1
  br i1 %32, label %bb22, label %bb23

bb22:                                             ; preds = %bb19
  %33 = getelementptr inbounds i8, ptr %_41, i64 1
  %k = load i8, ptr %33, align 1
; call core::hint::black_box::<u8>
  %_52 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECshXA3KcOxU02_8closures(i8 %k) #21
; call closures::boxed
  %34 = call { ptr, ptr } @_RNvCshXA3KcOxU02_8closures5boxed(i8 %_52)
  %35 = extractvalue { ptr, ptr } %34, 0
  %36 = extractvalue { ptr, ptr } %34, 1
  store ptr %35, ptr %_51, align 8
  %37 = getelementptr inbounds i8, ptr %_51, i64 8
  store ptr %36, ptr %37, align 8
; invoke core::hint::black_box::<i32>
  %_54 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshXA3KcOxU02_8closures(i32 7)
          to label %bb26 unwind label %cleanup23

bb23:                                             ; preds = %bb19
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %owned, ptr @alloc_1a2b9f3efbe1a8edd339fa75af2334ed, i64 5) #21
  store i8 1, ptr %_224, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_65, ptr align 8 %owned, i64 24, i1 false)
; invoke <str as alloc::string::ToString>::to_string
  invoke void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8 %_66, ptr @alloc_13af184f83ea529683dab3456027e412, i64 3)
          to label %bb32 unwind label %cleanup

bb112:                                            ; preds = %cleanup
  %38 = load i8, ptr %_224, align 1
  %39 = trunc nuw i8 %38 to i1
  br i1 %39, label %bb111, label %bb110

cleanup:                                          ; preds = %bb32, %bb23
  %40 = landingpad { ptr, i32 }
          cleanup
  %41 = extractvalue { ptr, i32 } %40, 0
  %42 = extractvalue { ptr, i32 } %40, 1
  store ptr %41, ptr %2, align 8
  %43 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %42, ptr %43, align 8
  br label %bb112

bb32:                                             ; preds = %bb23
  store i8 0, ptr %_224, align 1
; invoke closures::apply::<closures::main::{closure#10}>
  %44 = invoke i64 @_RINvCshXA3KcOxU02_8closures5applyNCNvB2_4mains8_0EB2_(ptr align 8 %_65, ptr align 8 %_66)
          to label %bb33 unwind label %cleanup

bb33:                                             ; preds = %bb32
  store i64 %44, ptr %_64, align 8
  store i8 0, ptr %_224, align 1
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_69, ptr align 8 %_64) #21
  %45 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %45, ptr align 8 %_69, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %46 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args4) #21
  %_61.0 = extractvalue { ptr, ptr } %46, 0
  %_61.1 = extractvalue { ptr, ptr } %46, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_61.0, ptr %_61.1)
; call <alloc::vec::Vec<usize>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE3newCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %hits) #21
; invoke closures::twice::<closures::main::{closure#0}>
  invoke void @_RINvCshXA3KcOxU02_8closures5twiceNCNvB2_4main0EB2_(ptr align 8 %hits)
          to label %bb38 unwind label %cleanup15

bb108:                                            ; preds = %bb107, %bb106, %cleanup15
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECshXA3KcOxU02_8closures(ptr align 8 %hits) #22
          to label %bb110 unwind label %terminate

cleanup15:                                        ; preds = %bb54, %_3.i.noexc, %bb99, %bb53, %bb52, %bb51, %bb50, %bb49, %bb48, %bb47, %bb43, %bb42, %bb41, %bb40, %bb39, %bb38, %bb33
  %47 = landingpad { ptr, i32 }
          cleanup
  %48 = extractvalue { ptr, i32 } %47, 0
  %49 = extractvalue { ptr, i32 } %47, 1
  store ptr %48, ptr %2, align 8
  %50 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %49, ptr %50, align 8
  br label %bb108

bb38:                                             ; preds = %bb33
; invoke <core::fmt::rt::Argument>::new_debug::<alloc::vec::Vec<usize>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc3vec3VecjEECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_81, ptr align 8 %hits)
          to label %bb39 unwind label %cleanup15

bb39:                                             ; preds = %bb38
  %51 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %_81, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %52 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args5)
          to label %bb40 unwind label %cleanup15

bb40:                                             ; preds = %bb39
  %_77.0 = extractvalue { ptr, ptr } %52, 0
  %_77.1 = extractvalue { ptr, ptr } %52, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_77.0, ptr %_77.1)
          to label %bb41 unwind label %cleanup15

bb41:                                             ; preds = %bb40
; invoke closures::compose::<i32, i32, alloc::string::String, closures::main::{closure#1}, closures::main::{closure#2}>
  invoke void @_RINvCshXA3KcOxU02_8closures7composellNtNtCs7CppTae75M1_5alloc6string6StringNCNvB2_4mains_0NCB1d_s0_0EB2_()
          to label %bb42 unwind label %cleanup15

bb42:                                             ; preds = %bb41
; invoke core::hint::black_box::<i32>
  %_92 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshXA3KcOxU02_8closures(i32 41)
          to label %bb43 unwind label %cleanup15

bb43:                                             ; preds = %bb42
; invoke closures::compose::<i32, i32, alloc::string::String, closures::main::{closure#1}, closures::main::{closure#2}>::{closure#0}
  invoke void @_RNCINvCshXA3KcOxU02_8closures7composellNtNtCs7CppTae75M1_5alloc6string6StringNCNvB4_4mains_0NCB1f_s0_0E0B4_(ptr sret([24 x i8]) align 8 %_89, ptr %_84, i32 %_92)
          to label %bb44 unwind label %cleanup15

bb44:                                             ; preds = %bb43
; invoke <core::fmt::rt::Argument>::new_display::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_94, ptr align 8 %_89)
          to label %bb45 unwind label %cleanup16

bb107:                                            ; preds = %cleanup16
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_89) #22
          to label %bb108 unwind label %terminate

cleanup16:                                        ; preds = %bb46, %bb45, %bb44
  %53 = landingpad { ptr, i32 }
          cleanup
  %54 = extractvalue { ptr, i32 } %53, 0
  %55 = extractvalue { ptr, i32 } %53, 1
  store ptr %54, ptr %2, align 8
  %56 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %55, ptr %56, align 8
  br label %bb107

bb45:                                             ; preds = %bb44
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_94, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %58 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args6)
          to label %bb46 unwind label %cleanup16

bb46:                                             ; preds = %bb45
  %_86.0 = extractvalue { ptr, ptr } %58, 0
  %_86.1 = extractvalue { ptr, ptr } %58, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_86.0, ptr %_86.1)
          to label %bb47 unwind label %cleanup16

bb47:                                             ; preds = %bb46
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_89)
          to label %bb48 unwind label %cleanup15

bb48:                                             ; preds = %bb47
; invoke closures::fnptr
  %59 = invoke i32 @_RNvCshXA3KcOxU02_8closures5fnptr(ptr @_RNvCshXA3KcOxU02_8closures3dbl, i32 4)
          to label %bb49 unwind label %cleanup15

bb49:                                             ; preds = %bb48
  store i32 %59, ptr %_101, align 4
; invoke closures::fnptr
  %60 = invoke i32 @_RNvCshXA3KcOxU02_8closures5fnptr(ptr @_RNvYNCNvCshXA3KcOxU02_8closures4mains9_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_onceB6_, i32 4)
          to label %bb50 unwind label %cleanup15

bb50:                                             ; preds = %bb49
  store i32 %60, ptr %_104, align 4
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_107, ptr align 4 %_101)
          to label %bb51 unwind label %cleanup15

bb51:                                             ; preds = %bb50
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_108, ptr align 4 %_104)
          to label %bb52 unwind label %cleanup15

bb52:                                             ; preds = %bb51
  %61 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %61, ptr align 8 %_107, i64 16, i1 false)
  %62 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %62, ptr align 8 %_108, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %63 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7)
          to label %bb53 unwind label %cleanup15

bb53:                                             ; preds = %bb52
  %_98.0 = extractvalue { ptr, ptr } %63, 0
  %_98.1 = extractvalue { ptr, ptr } %63, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_98.0, ptr %_98.1)
          to label %bb54 unwind label %cleanup15

bb54:                                             ; preds = %bb53
; invoke alloc::boxed::box_new_uninit
  %_1.i25 = invoke align 4 ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshXA3KcOxU02_8closures(i64 4, i64 16) #21
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxAlj4_E10new_uninitCshXA3KcOxU02_8closures.exit unwind label %cleanup15

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxAlj4_E10new_uninitCshXA3KcOxU02_8closures.exit: ; preds = %bb54
  br label %bb55

bb55:                                             ; preds = %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxAlj4_E10new_uninitCshXA3KcOxU02_8closures.exit
  %_227 = ptrtoint ptr %_1.i25 to i64
  %_229 = and i64 %_227, 3
  %_230 = icmp eq i64 %_229, 0
  br i1 %_230, label %bb113, label %panic

bb113:                                            ; preds = %bb55
  %_232 = ptrtoint ptr %_1.i25 to i64
  %_234 = icmp eq i64 %_232, 0
  %_235 = and i1 %_234, true
  %_236 = xor i1 %_235, true
  br i1 %_236, label %bb114, label %panic17

panic:                                            ; preds = %bb55
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 4, i64 %_227, ptr align 8 @alloc_597f75f969a5bf2c5fb37f6e1a0a26a0) #28
  unreachable

bb114:                                            ; preds = %bb113
  %64 = getelementptr inbounds nuw i32, ptr %_1.i25, i64 0
  store i32 5, ptr %64, align 4
  %65 = getelementptr inbounds nuw i32, ptr %_1.i25, i64 1
  store i32 3, ptr %65, align 4
  %66 = getelementptr inbounds nuw i32, ptr %_1.i25, i64 2
  store i32 8, ptr %66, align 4
  %67 = getelementptr inbounds nuw i32, ptr %_1.i25, i64 3
  store i32 1, ptr %67, align 4
  br label %_3.i.noexc

_3.i.noexc:                                       ; preds = %bb114
; invoke <[i32]>::into_vec::<alloc::alloc::Global>
  invoke void @_RINvMNtCs7CppTae75M1_5alloc5sliceSl8into_vecNtNtB5_5alloc6GlobalECshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %v, ptr align 4 %_1.i25, i64 4) #21
          to label %_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafelKj4_ECshXA3KcOxU02_8closures.exit unwind label %cleanup15

_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafelKj4_ECshXA3KcOxU02_8closures.exit: ; preds = %_3.i.noexc
  br label %bb56

panic17:                                          ; preds = %bb113
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_597f75f969a5bf2c5fb37f6e1a0a26a0) #28
  unreachable

bb56:                                             ; preds = %_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafelKj4_ECshXA3KcOxU02_8closures.exit
; invoke <alloc::vec::Vec<i32> as core::ops::deref::DerefMut>::deref_mut
  %68 = invoke { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCshXA3KcOxU02_8closures(ptr align 8 %v)
          to label %bb57 unwind label %cleanup18

bb106:                                            ; preds = %bb105, %cleanup18
; invoke core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECshXA3KcOxU02_8closures(ptr align 8 %v) #22
          to label %bb108 unwind label %terminate

cleanup18:                                        ; preds = %bb98, %bb62, %bb61, %bb60, %bb59, %bb58, %bb57, %bb56
  %69 = landingpad { ptr, i32 }
          cleanup
  %70 = extractvalue { ptr, i32 } %69, 0
  %71 = extractvalue { ptr, i32 } %69, 1
  store ptr %70, ptr %2, align 8
  %72 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %71, ptr %72, align 8
  br label %bb106

bb57:                                             ; preds = %bb56
  %_114.0 = extractvalue { ptr, i64 } %68, 0
  %_114.1 = extractvalue { ptr, i64 } %68, 1
; invoke <[i32]>::sort_by::<closures::main::{closure#3}>
  invoke void @_RINvMNtCs7CppTae75M1_5alloc5sliceSl7sort_byNCNvCshXA3KcOxU02_8closures4mains1_0EBJ_(ptr align 4 %_114.0, i64 %_114.1)
          to label %bb58 unwind label %cleanup18

bb58:                                             ; preds = %bb57
; invoke <core::fmt::rt::Argument>::new_debug::<alloc::vec::Vec<i32>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc3vec3VeclEECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_121, ptr align 8 %v)
          to label %bb59 unwind label %cleanup18

bb59:                                             ; preds = %bb58
  %73 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %73, ptr align 8 %_121, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %74 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args8)
          to label %bb60 unwind label %cleanup18

bb60:                                             ; preds = %bb59
  %_117.0 = extractvalue { ptr, ptr } %74, 0
  %_117.1 = extractvalue { ptr, ptr } %74, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_117.0, ptr %_117.1)
          to label %bb61 unwind label %cleanup18

bb61:                                             ; preds = %bb60
; invoke <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::map::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, closures::main::{closure#4}>
  %75 = invoke { i64, i64 } @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangejENtNtNtNtBa_4iter6traits8iterator8Iterator3mapINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtB8_8function2FnuEp6OutputjEL_ENCNvCshXA3KcOxU02_8closures4mains2_0EB2H_(i64 0, i64 3)
          to label %bb62 unwind label %cleanup18

bb62:                                             ; preds = %bb61
  %_125.0 = extractvalue { i64, i64 } %75, 0
  %_125.1 = extractvalue { i64, i64 } %75, 1
; invoke <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>
  invoke void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtNtNtBa_6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VecINtNtB2F_5boxed3BoxDINtNtBW_8function2FnuEp6OutputjEL_EEEB1n_(ptr sret([24 x i8]) align 8 %fs, i64 %_125.0, i64 %_125.1)
          to label %bb63 unwind label %cleanup18

bb63:                                             ; preds = %bb62
; invoke <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::ops::deref::Deref>::deref
  %76 = invoke { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EENtNtB13_5deref5Deref5derefCshXA3KcOxU02_8closures(ptr align 8 %fs)
          to label %bb64 unwind label %cleanup19

bb105:                                            ; preds = %bb104, %bb103, %bb102, %cleanup19
; invoke core::ptr::drop_glue::<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtBG_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EEECshXA3KcOxU02_8closures(ptr align 8 %fs) #22
          to label %bb106 unwind label %terminate

cleanup19:                                        ; preds = %bb92, %bb87, %bb86, %bb85, %bb84, %bb83, %bb82, %bb81, %bb77, %bb76, %bb75, %bb74, %bb73, %bb72, %bb71, %bb70, %bb66, %bb65, %bb64, %bb63
  %77 = landingpad { ptr, i32 }
          cleanup
  %78 = extractvalue { ptr, i32 } %77, 0
  %79 = extractvalue { ptr, i32 } %77, 1
  store ptr %78, ptr %2, align 8
  %80 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %79, ptr %80, align 8
  br label %bb105

bb64:                                             ; preds = %bb63
  %_134.0 = extractvalue { ptr, i64 } %76, 0
  %_134.1 = extractvalue { ptr, i64 } %76, 1
; invoke <[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>]>::iter
  %81 = invoke { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_E4iterCshXA3KcOxU02_8closures(ptr align 8 %_134.0, i64 %_134.1)
          to label %bb65 unwind label %cleanup19

bb65:                                             ; preds = %bb64
  %_133.0 = extractvalue { ptr, ptr } %81, 0
  %_133.1 = extractvalue { ptr, ptr } %81, 1
; invoke <core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::iter::traits::iterator::Iterator>::map::<usize, closures::main::{closure#12}>
  %82 = invoke { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EENtNtNtNtBa_4iter6traits8iterator8Iterator3mapjNCNvCshXA3KcOxU02_8closures4mainsa_0EB2N_(ptr %_133.0, ptr %_133.1)
          to label %bb66 unwind label %cleanup19

bb66:                                             ; preds = %bb65
  %_132.0 = extractvalue { ptr, ptr } %82, 0
  %_132.1 = extractvalue { ptr, ptr } %82, 1
; invoke <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<usize>>
  invoke void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBc_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtNtNtBa_6traits8iterator8Iterator7collectINtNtB1m_3vec3VecjEEB2B_(ptr sret([24 x i8]) align 8 %_131, ptr %_132.0, ptr %_132.1)
          to label %bb67 unwind label %cleanup19

bb67:                                             ; preds = %bb66
; invoke <core::fmt::rt::Argument>::new_debug::<alloc::vec::Vec<usize>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc3vec3VecjEECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_137, ptr align 8 %_131)
          to label %bb68 unwind label %cleanup20

bb104:                                            ; preds = %cleanup20
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECshXA3KcOxU02_8closures(ptr align 8 %_131) #22
          to label %bb105 unwind label %terminate

cleanup20:                                        ; preds = %bb69, %bb68, %bb67
  %83 = landingpad { ptr, i32 }
          cleanup
  %84 = extractvalue { ptr, i32 } %83, 0
  %85 = extractvalue { ptr, i32 } %83, 1
  store ptr %84, ptr %2, align 8
  %86 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %85, ptr %86, align 8
  br label %bb104

bb68:                                             ; preds = %bb67
  %87 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %87, ptr align 8 %_137, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %88 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args9)
          to label %bb69 unwind label %cleanup20

bb69:                                             ; preds = %bb68
  %_128.0 = extractvalue { ptr, ptr } %88, 0
  %_128.1 = extractvalue { ptr, ptr } %88, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_128.0, ptr %_128.1)
          to label %bb70 unwind label %cleanup20

bb70:                                             ; preds = %bb69
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECshXA3KcOxU02_8closures(ptr align 8 %_131)
          to label %bb71 unwind label %cleanup19

bb71:                                             ; preds = %bb70
  store i32 0, ptr %total, align 4
; invoke <core::ops::range::RangeInclusive<i32>>::new
  invoke void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivelE3newCshXA3KcOxU02_8closures(ptr sret([12 x i8]) align 4 %_142, i32 1, i32 4)
          to label %bb72 unwind label %cleanup19

bb72:                                             ; preds = %bb71
; invoke <core::ops::range::RangeInclusive<i32> as core::iter::traits::iterator::Iterator>::for_each::<closures::main::{closure#5}>
  invoke void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivelENtNtNtNtBa_4iter6traits8iterator8Iterator8for_eachNCNvCshXA3KcOxU02_8closures4mains3_0EB1N_(ptr align 4 %_142, ptr align 4 %total)
          to label %bb73 unwind label %cleanup19

bb73:                                             ; preds = %bb72
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_150, ptr align 4 %total)
          to label %bb74 unwind label %cleanup19

bb74:                                             ; preds = %bb73
  %89 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %89, ptr align 8 %_150, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %90 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args10)
          to label %bb75 unwind label %cleanup19

bb75:                                             ; preds = %bb74
  %_146.0 = extractvalue { ptr, ptr } %90, 0
  %_146.1 = extractvalue { ptr, ptr } %90, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_146.0, ptr %_146.1)
          to label %bb76 unwind label %cleanup19

bb76:                                             ; preds = %bb75
; invoke <alloc::string::String as core::convert::From<&str>>::from
  invoke void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %s, ptr @alloc_58096495302c69ca26995c4c0084234f, i64 5)
          to label %bb77 unwind label %cleanup19

bb77:                                             ; preds = %bb76
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %once, ptr align 8 %s, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %once, i64 24, i1 false)
; invoke closures::main::{closure#6}
  invoke void @_RNCNvCshXA3KcOxU02_8closures4mains4_0B3_(ptr sret([24 x i8]) align 8 %_159, ptr align 8 %1)
          to label %bb78 unwind label %cleanup19

bb78:                                             ; preds = %bb77
; invoke <core::fmt::rt::Argument>::new_display::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_161, ptr align 8 %_159)
          to label %bb79 unwind label %cleanup21

bb103:                                            ; preds = %cleanup21
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_159) #22
          to label %bb105 unwind label %terminate

cleanup21:                                        ; preds = %bb80, %bb79, %bb78
  %91 = landingpad { ptr, i32 }
          cleanup
  %92 = extractvalue { ptr, i32 } %91, 0
  %93 = extractvalue { ptr, i32 } %91, 1
  store ptr %92, ptr %2, align 8
  %94 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %93, ptr %94, align 8
  br label %bb103

bb79:                                             ; preds = %bb78
  %95 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %95, ptr align 8 %_161, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %96 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args11)
          to label %bb80 unwind label %cleanup21

bb80:                                             ; preds = %bb79
  %_156.0 = extractvalue { ptr, ptr } %96, 0
  %_156.1 = extractvalue { ptr, ptr } %96, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_156.0, ptr %_156.1)
          to label %bb81 unwind label %cleanup21

bb81:                                             ; preds = %bb80
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_159)
          to label %bb82 unwind label %cleanup19

bb82:                                             ; preds = %bb81
; invoke core::hint::black_box::<u64>
  %_172 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECshXA3KcOxU02_8closures(i64 15)
          to label %bb83 unwind label %cleanup19

bb83:                                             ; preds = %bb82
; invoke closures::main::{closure#7}
  %97 = invoke i64 @_RNCNvCshXA3KcOxU02_8closures4mains5_0B3_(ptr %_164, i64 %_172)
          to label %bb84 unwind label %cleanup19

bb84:                                             ; preds = %bb83
  store i64 %97, ptr %_169, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_174, ptr align 8 %_169)
          to label %bb85 unwind label %cleanup19

bb85:                                             ; preds = %bb84
  %98 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %98, ptr align 8 %_174, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %99 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args12)
          to label %bb86 unwind label %cleanup19

bb86:                                             ; preds = %bb85
  %_166.0 = extractvalue { ptr, ptr } %99, 0
  %_166.1 = extractvalue { ptr, ptr } %99, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_166.0, ptr %_166.1)
          to label %bb87 unwind label %cleanup19

bb87:                                             ; preds = %bb86
  store ptr @alloc_570d9fe4b5961862179f7942a2cbdd3e, ptr %_178, align 8
  %100 = getelementptr inbounds i8, ptr %_178, i64 8
  store i64 3, ptr %100, align 8
  %101 = getelementptr inbounds i8, ptr %_178, i64 16
  store ptr @_RNvYNCNvCshXA3KcOxU02_8closures4mains6_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTddEE9call_onceB6_, ptr %101, align 8
  store ptr @alloc_a12a40a498c0d2454ea9e1174a89e908, ptr %_181, align 8
  %102 = getelementptr inbounds i8, ptr %_181, i64 8
  store i64 3, ptr %102, align 8
  %103 = getelementptr inbounds i8, ptr %_181, i64 16
  store ptr @_RNvYNCNvCshXA3KcOxU02_8closures4mains7_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTddEE9call_onceB6_, ptr %103, align 8
  store ptr @alloc_71df11005c9c3a274ea98edca8205c70, ptr %_184, align 8
  %104 = getelementptr inbounds i8, ptr %_184, i64 8
  store i64 3, ptr %104, align 8
  %105 = getelementptr inbounds i8, ptr %_184, i64 16
  store ptr @_RNvMNtCsddYV2PBJW9h_3std3f64d4powfCshXA3KcOxU02_8closures, ptr %105, align 8
  %106 = getelementptr inbounds nuw { { ptr, i64 }, ptr }, ptr %ops, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %106, ptr align 8 %_178, i64 24, i1 false)
  %107 = getelementptr inbounds nuw { { ptr, i64 }, ptr }, ptr %ops, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_181, i64 24, i1 false)
  %108 = getelementptr inbounds nuw { { ptr, i64 }, ptr }, ptr %ops, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %108, ptr align 8 %_184, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %ops, i64 72, i1 false)
; invoke <[(&str, fn(f64, f64) -> f64); 3] as core::iter::traits::collect::IntoIterator>::into_iter
  invoke void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterATReFddEdEj3_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCshXA3KcOxU02_8closures(ptr sret([88 x i8]) align 8 %_187, ptr align 8 %0)
          to label %bb88 unwind label %cleanup19

bb88:                                             ; preds = %bb87
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter13, ptr align 8 %_187, i64 88, i1 false)
  br label %bb89

bb89:                                             ; preds = %bb115, %bb88
; invoke <core::array::iter::IntoIter<(&str, fn(f64, f64) -> f64), 3> as core::iter::traits::iterator::Iterator>::next
  invoke void @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterTReFddEdEKj3_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_189, ptr align 8 %iter13)
          to label %bb90 unwind label %cleanup22

bb102:                                            ; preds = %cleanup22
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<(&str, fn(f64, f64) -> f64), 3>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterTReFddEdEKj3_EECshXA3KcOxU02_8closures(ptr align 8 %iter13) #22
          to label %bb105 unwind label %terminate

cleanup22:                                        ; preds = %bb97, %bb96, %bb95, %bb94, %bb93, %bb91, %bb89
  %109 = landingpad { ptr, i32 }
          cleanup
  %110 = extractvalue { ptr, i32 } %109, 0
  %111 = extractvalue { ptr, i32 } %109, 1
  store ptr %110, ptr %2, align 8
  %112 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %111, ptr %112, align 8
  br label %bb102

bb90:                                             ; preds = %bb89
  %113 = load ptr, ptr %_189, align 8
  %114 = ptrtoint ptr %113 to i64
  %115 = icmp eq i64 %114, 0
  %_191 = select i1 %115, i64 0, i64 1
  %116 = trunc nuw i64 %_191 to i1
  br i1 %116, label %bb91, label %bb92

bb91:                                             ; preds = %bb90
  %117 = load ptr, ptr %_189, align 8
  %118 = getelementptr inbounds i8, ptr %_189, i64 8
  %119 = load i64, ptr %118, align 8
  store ptr %117, ptr %n, align 8, !captures !270
  %120 = getelementptr inbounds i8, ptr %n, i64 8
  store i64 %119, ptr %120, align 8
  %121 = getelementptr inbounds i8, ptr %_189, i64 16
  %f = load ptr, ptr %121, align 8
; invoke core::hint::black_box::<f64>
  %_200 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECshXA3KcOxU02_8closures(double 2.000000e+00)
          to label %bb93 unwind label %cleanup22

bb92:                                             ; preds = %bb90
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<(&str, fn(f64, f64) -> f64), 3>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterTReFddEdEKj3_EECshXA3KcOxU02_8closures(ptr align 8 %iter13)
          to label %bb98 unwind label %cleanup19

bb98:                                             ; preds = %bb92
; invoke core::ptr::drop_glue::<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtBG_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EEECshXA3KcOxU02_8closures(ptr align 8 %fs)
          to label %bb99 unwind label %cleanup18

bb99:                                             ; preds = %bb98
; invoke core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECshXA3KcOxU02_8closures(ptr align 8 %v)
          to label %bb100 unwind label %cleanup15

bb100:                                            ; preds = %bb99
; call core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECshXA3KcOxU02_8closures(ptr align 8 %hits)
  ret void

bb93:                                             ; preds = %bb91
  %122 = invoke double %f(double %_200, double 1.000000e+01)
          to label %bb94 unwind label %cleanup22

bb94:                                             ; preds = %bb93
  store double %122, ptr %_199, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_202, ptr align 8 %n)
          to label %bb95 unwind label %cleanup22

bb95:                                             ; preds = %bb94
; invoke <core::fmt::rt::Argument>::new_display::<f64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECshXA3KcOxU02_8closures(ptr sret([16 x i8]) align 8 %_203, ptr align 8 %_199)
          to label %bb96 unwind label %cleanup22

bb96:                                             ; preds = %bb95
  %123 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %123, ptr align 8 %_202, i64 16, i1 false)
  %124 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %124, ptr align 8 %_203, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %125 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14)
          to label %bb97 unwind label %cleanup22

bb97:                                             ; preds = %bb96
  %_195.0 = extractvalue { ptr, ptr } %125, 0
  %_195.1 = extractvalue { ptr, ptr } %125, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_195.0, ptr %_195.1)
          to label %bb115 unwind label %cleanup22

bb115:                                            ; preds = %bb97
  br label %bb89

terminate:                                        ; preds = %bb109, %bb111, %bb108, %bb107, %bb106, %bb105, %bb104, %bb103, %bb102
  %126 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb110:                                            ; preds = %bb109, %bb111, %bb112, %bb108
  %127 = load ptr, ptr %2, align 8
  %128 = getelementptr inbounds i8, ptr %2, i64 8
  %129 = load i32, ptr %128, align 8
  %130 = insertvalue { ptr, i32 } poison, ptr %127, 0
  %131 = insertvalue { ptr, i32 } %130, i32 %129, 1
  resume { ptr, i32 } %131

bb111:                                            ; preds = %bb112
; invoke core::ptr::drop_glue::<closures::main::{closure#10}>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCNvCshXA3KcOxU02_8closures4mains8_0EBF_(ptr align 8 %_65) #22
          to label %bb110 unwind label %terminate

bb109:                                            ; preds = %cleanup23
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::ops::function::Fn<(i32,), Output = i32>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnTlEEp6OutputlEL_EECshXA3KcOxU02_8closures(ptr align 8 %_51) #22
          to label %bb110 unwind label %terminate

cleanup23:                                        ; preds = %bb29, %bb28, %bb27, %bb26, %bb22
  %132 = landingpad { ptr, i32 }
          cleanup
  %133 = extractvalue { ptr, i32 } %132, 0
  %134 = extractvalue { ptr, i32 } %132, 1
  store ptr %133, ptr %2, align 8
  %135 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %134, ptr %135, align 8
  br label %bb109

bb26:                                             ; preds = %bb22
; invoke <alloc::boxed::Box<dyn core::ops::function::Fn<(i32,), Output = i32>> as core::ops::function::Fn<(i32,)>>::call
  %136 = invoke i32 @_RNvXsv_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnTlEEp6OutputlEL_EIBJ_B1o_E4callCshXA3KcOxU02_8closures(ptr align 8 %_51, i32 %_54)
          to label %bb27 unwind label %cleanup23

bb27:                                             ; preds = %bb26
  store i32 %136, ptr %_49, align 4
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_56, ptr align 4 %_49)
          to label %bb28 unwind label %cleanup23

bb28:                                             ; preds = %bb27
  %137 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %137, ptr align 8 %_56, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %138 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args3)
          to label %bb29 unwind label %cleanup23

bb29:                                             ; preds = %bb28
  %_46.0 = extractvalue { ptr, ptr } %138, 0
  %_46.1 = extractvalue { ptr, ptr } %138, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_46.0, ptr %_46.1)
          to label %bb30 unwind label %cleanup23

bb30:                                             ; preds = %bb29
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::ops::function::Fn<(i32,), Output = i32>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnTlEEp6OutputlEL_EECshXA3KcOxU02_8closures(ptr align 8 %_51)
  br label %bb19

bb21:                                             ; No predecessors!
  unreachable
}

; closures::boxed
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvCshXA3KcOxU02_8closures5boxed(i8 %kind) unnamed_addr #0 personality ptr @rust_eh_personality !guid !420 {
start:
  %_4.i3 = alloca [1 x i8], align 1
  %_4.i1 = alloca [1 x i8], align 1
  %_4.i = alloca [1 x i8], align 1
  %_2 = alloca [16 x i8], align 8
  switch i8 %kind, label %bb1 [
    i8 0, label %bb3
    i8 1, label %bb2
  ]

bb1:                                              ; preds = %start
  store i8 0, ptr %_4.i1, align 1
  store i8 1, ptr %_4.i1, align 1
; call alloc::boxed::box_new_uninit
  %_3.i2 = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshXA3KcOxU02_8closures(i64 1, i64 0) #21
  store i8 0, ptr %_4.i1, align 1
  store ptr %_3.i2, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @vtable.6, ptr %0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; call alloc::boxed::box_new_uninit
  %_3.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshXA3KcOxU02_8closures(i64 1, i64 0) #21
  store i8 0, ptr %_4.i, align 1
  store ptr %_3.i, ptr %_2, align 8
  %1 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @vtable.4, ptr %1, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store i8 0, ptr %_4.i3, align 1
  store i8 1, ptr %_4.i3, align 1
; call alloc::boxed::box_new_uninit
  %_3.i4 = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshXA3KcOxU02_8closures(i64 1, i64 0) #21
  store i8 0, ptr %_4.i3, align 1
  store ptr %_3.i4, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @vtable.5, ptr %2, align 8
  br label %bb7

bb7:                                              ; preds = %bb1, %bb2, %bb3
  %_0.0 = load ptr, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  %_0.1 = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1, 1
  ret { ptr, ptr } %5
}

; closures::fnptr
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCshXA3KcOxU02_8closures5fnptr(ptr %f, i32 %x) unnamed_addr #0 !guid !421 {
start:
  %_0 = call i32 %f(i32 %x)
  ret i32 %_0
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecINtNtB4_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE13with_capacityCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !422 {
start:
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE16with_capacity_inCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #21
  ret void
}

; <alloc::vec::Vec<usize>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE13with_capacityCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !423 {
start:
; call <alloc::vec::Vec<usize>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE16with_capacity_inCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #21
  ret void
}

; <alloc::vec::Vec<usize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE3newCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #1 !guid !424 {
start:
; call <alloc::raw_vec::RawVec<usize>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecjE3newCshXA3KcOxU02_8closures()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<i32>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeclE13with_capacityCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !425 {
start:
; call <alloc::vec::Vec<i32>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclE16with_capacity_inCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #21
  ret void
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #1 !guid !426 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !427 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #21
  ret i64 %_0
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !428 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8 %self) #21
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCshXA3KcOxU02_8closures(ptr %_2.0, i64 %_2.1) #21
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <alloc::raw_vec::RawVec<usize>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecjE3newCshXA3KcOxU02_8closures() unnamed_addr #0 !guid !429 {
start:
; call <alloc::raw_vec::RawVec<usize>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE6new_inCshXA3KcOxU02_8closures() #21
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <f64>::powf
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d4powfCshXA3KcOxU02_8closures(double %self, double %n) unnamed_addr #1 !guid !430 {
start:
  %_0 = call double @llvm.pow.f64(double %self, double %n)
  ret double %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshXA3KcOxU02_8closures(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !431 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_E4iterCshXA3KcOxU02_8closures(ptr align 8 %self.0, i64 %self.1) unnamed_addr #1 !guid !432 {
start:
; call <core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE3newCshXA3KcOxU02_8closures(ptr align 8 %self.0, i64 %self.1) #21
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitTReFddEdEE8is_emptyCshXA3KcOxU02_8closures(ptr align 8 %self.0, i64 %self.1) unnamed_addr #1 !guid !433 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[i32]>::split_at_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl12split_at_mutCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %pair, ptr align 4 %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #1 !guid !434 {
start:
  %_3 = alloca [32 x i8], align 8
; call <[i32]>::split_at_mut_checked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl20split_at_mut_checkedCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %_3, ptr align 4 %self.0, i64 %self.1, i64 %mid) #21
  %1 = load ptr, ptr %_3, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_4 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %pair, ptr align 8 %_3, i64 32, i1 false)
  ret void

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %5 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_d1084648e479974e70c9329824bf76f9, i64 9) #21
  %_6.0 = extractvalue { ptr, ptr } %5, 0
  %_6.1 = extractvalue { ptr, ptr } %5, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 %0) #25
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <[i32]>::as_mut_ptr_range
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl16as_mut_ptr_rangeCshXA3KcOxU02_8closures(ptr align 4 %self.0, i64 %self.1) unnamed_addr #1 !guid !435 {
start:
  %_0.i = getelementptr inbounds nuw i32, ptr %self.0, i64 %self.1
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_0.i, 1
  ret { ptr, ptr } %1
}

; <[i32]>::split_at_mut_checked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl20split_at_mut_checkedCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %_0, ptr align 4 %self.0, i64 %self.1, i64 %mid) unnamed_addr #1 !guid !436 {
start:
  %_6 = alloca [32 x i8], align 8
  %_3 = icmp ule i64 %mid, %self.1
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb1:                                              ; preds = %start
; call <[i32]>::split_at_mut_unchecked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl22split_at_mut_uncheckedCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %_6, ptr align 4 %self.0, i64 %self.1, i64 %mid, ptr align 8 @alloc_a6541cbd0ddc1cb3d23757a1b3f12432) #21
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 32, i1 false)
  br label %bb4

bb4:                                              ; preds = %bb1, %bb3
  ret void
}

; <[i32]>::split_at_mut_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl22split_at_mut_uncheckedCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %_0, ptr align 4 %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #1 !guid !437 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <[_]>::split_at_mut_unchecked::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp22split_at_mut_unchecked18precondition_checkCshXA3KcOxU02_8closures(i64 %mid, i64 %self.1, ptr align 8 %0) #24
  br label %bb3

bb3:                                              ; preds = %bb2
; call core::slice::raw::from_raw_parts_mut::<i32>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECshXA3KcOxU02_8closures(ptr %self.0, i64 %mid, ptr align 8 %0) #21
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %_0.i = getelementptr inbounds nuw i32, ptr %self.0, i64 %mid
  %_11 = sub nuw i64 %self.1, %mid
; call core::slice::raw::from_raw_parts_mut::<i32>
  %2 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECshXA3KcOxU02_8closures(ptr %_0.i, i64 %_11, ptr align 8 %0) #21
  %_9.0 = extractvalue { ptr, i64 } %2, 0
  %_9.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_8.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8.1, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 16
  store ptr %_9.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %_9.1, ptr %5, align 8
  ret void
}

; <[i32]>::reverse
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl7reverseCshXA3KcOxU02_8closures(ptr align 4 %self.0, i64 %self.1) unnamed_addr #1 !guid !438 {
start:
  %_0.i = alloca [8 x i8], align 8
  %_11 = alloca [32 x i8], align 8
  %half_len = udiv i64 %self.1, 2
; call <[i32]>::as_mut_ptr_range
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl16as_mut_ptr_rangeCshXA3KcOxU02_8closures(ptr align 4 %self.0, i64 %self.1) #21
  %_8.0 = extractvalue { ptr, ptr } %0, 0
  %_8.1 = extractvalue { ptr, ptr } %0, 1
; call core::slice::raw::from_raw_parts_mut::<i32>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECshXA3KcOxU02_8closures(ptr %_8.0, i64 %half_len, ptr align 8 @alloc_c0be9056d9e7c9d32564b353e6cdd76b) #21
  %_12.0 = extractvalue { ptr, i64 } %1, 0
  %_12.1 = extractvalue { ptr, i64 } %1, 1
  %_3.i = sub nsw i64 0, %half_len
  %2 = getelementptr inbounds i32, ptr %_8.1, i64 %_3.i
  store ptr %2, ptr %_0.i, align 8
  %3 = load ptr, ptr %_0.i, align 8
; call core::slice::raw::from_raw_parts_mut::<i32>
  %4 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECshXA3KcOxU02_8closures(ptr %3, i64 %half_len, ptr align 8 @alloc_11a111513757e9d53adfd2e1c4df0866) #21
  %_13.0 = extractvalue { ptr, i64 } %4, 0
  %_13.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_12.0, ptr %_11, align 8
  %5 = getelementptr inbounds i8, ptr %_11, i64 8
  store i64 %_12.1, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_11, i64 16
  store ptr %_13.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %_13.1, ptr %7, align 8
  %front_half.0 = load ptr, ptr %_11, align 8
  %8 = getelementptr inbounds i8, ptr %_11, i64 8
  %front_half.1 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %_11, i64 16
  %back_half.0 = load ptr, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  %back_half.1 = load i64, ptr %10, align 8
; call <[_]>::reverse::revswap::<i32>
  call void @_RINvNvMNtCsl10jNU3mE6R_4core5sliceSp7reverse7revswaplECshXA3KcOxU02_8closures(ptr align 4 %front_half.0, i64 %front_half.1, ptr align 4 %back_half.0, i64 %back_half.1, i64 %half_len) #21
  ret void
}

; <alloc::vec::set_len_on_drop::SetLenOnDrop>::current_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop11current_lenCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !439 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <alloc::vec::set_len_on_drop::SetLenOnDrop>::increment_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop13increment_lenCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %increment) unnamed_addr #1 !guid !440 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = add i64 %2, %increment
  store i64 %3, ptr %0, align 8
  ret void
}

; <alloc::vec::set_len_on_drop::SetLenOnDrop>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop3newCshXA3KcOxU02_8closures(ptr align 8 %len) unnamed_addr #1 !guid !441 {
start:
  %_2 = load i64, ptr %len, align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %len, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %_2, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE3newCshXA3KcOxU02_8closures(ptr align 4 %x.0, i64 %x.1) unnamed_addr #0 !guid !442 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_mutCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !443 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_refCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !444 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitTReFddEdEEj3_EE3newCshXA3KcOxU02_8closures(ptr sret([88 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !445 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 88, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitTReFddEdEEj3_EE6as_mutCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !446 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtNtB6_5slice4sort6shared9smallsort10CopyOnDroplEE3newCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !447 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::hint::select_unpredictable::DropOnPanic<*const i32>>>::new
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNvNtB6_4hint20select_unpredictable11DropOnPanicPlEE3newCshXA3KcOxU02_8closures(ptr %x) unnamed_addr #0 !guid !448 {
start:
  ret ptr %x
}

; <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCshXA3KcOxU02_8closures(ptr %x) unnamed_addr #0 !guid !449 {
start:
  ret ptr %x
}

; <core::mem::maybe_dangling::MaybeDangling<i32>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 4 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE6as_refCshXA3KcOxU02_8closures(ptr align 4 %self) unnamed_addr #0 !guid !450 {
start:
  ret ptr %self
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCshXA3KcOxU02_8closures(i64 %align, ptr align 8 %0) unnamed_addr #1 !guid !451 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCshXA3KcOxU02_8closures(i64 %align, ptr align 8 %0) #24
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCshXA3KcOxU02_8closures(i64 %self) unnamed_addr #1 !guid !452 {
start:
  ret i64 %self
}

; <core::ops::index_range::IndexRange>::next_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !453 {
start:
  %value = load i64, ptr %self, align 8
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCshXA3KcOxU02_8closures(i64 %value, i64 1, ptr align 8 @alloc_de9a5d9a80d554992107c1ea3afec081) #24
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i64 %value, 1
  store i64 %_0.i, ptr %self, align 8
  ret i64 %value
}

; <core::ops::index_range::IndexRange>::end
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !454 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !455 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_2 = load i64, ptr %0, align 8
  %_3 = load i64, ptr %self, align 8
  %_0 = sub nuw i64 %_2, %_3
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::start
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !456 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::zero_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCshXA3KcOxU02_8closures(i64 %end) unnamed_addr #1 !guid !457 {
start:
  %0 = insertvalue { i64, i64 } { i64 0, i64 poison }, i64 %end, 1
  ret { i64, i64 } %0
}

; <*mut alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB6_3ops8function2FnuEp6OutputjEL_E20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #1 !guid !458 {
start:
; call <*const alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB6_3ops8function2FnuEp6OutputjEL_E20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %self, ptr %origin, ptr align 8 %0) #21
  ret i64 %_0
}

; <*mut i32>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #1 !guid !459 {
start:
; call <*const i32>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPl20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %self, ptr %origin, ptr align 8 %0) #21
  ret i64 %_0
}

; <*const alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB6_3ops8function2FnuEp6OutputjEL_E20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #1 !guid !460 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 16
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCshXA3KcOxU02_8closures(ptr %self, ptr %origin, ptr align 8 %0) #24
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #25
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 16, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 16
  ret i64 %_0
}

; <*const i32>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPl20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #1 !guid !461 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 4
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCshXA3KcOxU02_8closures(ptr %self, ptr %origin, ptr align 8 %0) #24
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #25
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 4, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 4
  ret i64 %_0
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !462 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCshXA3KcOxU02_8closures(i64 %_3) #21
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #21
  ret ptr %_0
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCshXA3KcOxU02_8closures(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #1 !guid !463 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCshXA3KcOxU02_8closures(i64 %size, i64 %alignment, ptr align 8 %0) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !464 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !465 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::array::iter::IntoIter<(&str, fn(f64, f64) -> f64), 3>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterTReFddEdEKj3_E10unsize_mutCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !466 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitTReFddEdEEj3_EE6as_mutCshXA3KcOxU02_8closures(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 3, 1
  ret { ptr, i64 } %1
}

; <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0E3newB1p_(i64 %iter.0, i64 %iter.1) unnamed_addr #0 !guid !467 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %iter.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %iter.1, 1
  ret { i64, i64 } %1
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0E3newB2D_(ptr %iter.0, ptr %iter.1) unnamed_addr #0 !guid !468 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %iter.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %iter.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::sort::stable::AlignedStorage<i32, 4096>>::as_uninit_slice_mut
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStoragelKj1000_E19as_uninit_slice_mutCshXA3KcOxU02_8closures(ptr align 4 %self) unnamed_addr #0 !guid !469 {
start:
  %_4 = icmp eq i64 4, 0
  br i1 %_4, label %panic, label %bb2

bb2:                                              ; preds = %start
  %len = udiv i64 4096, 4
; call core::slice::raw::from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEECshXA3KcOxU02_8closures(ptr %self, i64 %len, ptr align 8 @alloc_2491cc18f41182435b2301519a149a1c) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_f5abd596fd0c54395cb86286cae95a93) #25
  unreachable
}

; <core::slice::sort::stable::AlignedStorage<i32, 4096>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStoragelKj1000_E3newCshXA3KcOxU02_8closures(ptr sret([4096 x i8]) align 4 %_0) unnamed_addr #0 !guid !470 {
start:
  %_1 = alloca [4096 x i8], align 1
  call void @llvm.memset.p0.i64(ptr align 1 %_1, i8 undef, i64 4096, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 1 %_1, i64 4096, i1 false)
  ret void
}

; <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCshXA3KcOxU02_8closures(ptr align 8 %self, i1 zeroext %towards_left) unnamed_addr #0 !guid !471 {
start:
  %_0.i1 = alloca [8 x i8], align 8
  %dst_base = alloca [8 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 24
  %_4 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i32, ptr %_4, i64 -1
  store ptr %1, ptr %_0.i1, align 8
  %2 = load ptr, ptr %_0.i1, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 24
  store ptr %2, ptr %3, align 8
  br i1 %towards_left, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 24
  %5 = load ptr, ptr %4, align 8
  store ptr %5, ptr %dst_base, align 8
  br label %bb4

bb2:                                              ; preds = %start
  %6 = load ptr, ptr %self, align 8
  store ptr %6, ptr %dst_base, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %_6 = load ptr, ptr %dst_base, align 8
  %7 = getelementptr inbounds i8, ptr %self, i64 16
  %_7 = load i64, ptr %7, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_6, i64 %_7
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_9 = load ptr, ptr %8, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %bb4
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_9, ptr %_0.i, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %bb4, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i, ptr align 4 %_9, i64 4, i1 false)
  %_10 = zext i1 %towards_left to i64
  %9 = getelementptr inbounds i8, ptr %self, i64 16
  %10 = getelementptr inbounds i8, ptr %self, i64 16
  %11 = load i64, ptr %10, align 8
  %12 = add i64 %11, %_10
  store i64 %12, ptr %9, align 8
  %13 = getelementptr inbounds i8, ptr %self, i64 8
  %_12 = load ptr, ptr %13, align 8
  %_0.i3 = getelementptr inbounds nuw i32, ptr %_12, i64 1
  %14 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_0.i3, ptr %14, align 8
  ret ptr %_0.i
}

; <core::slice::sort::stable::quicksort::PartitionState<i32>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE3newCshXA3KcOxU02_8closures(ptr sret([32 x i8]) align 8 %_0, ptr %scan, ptr %scratch, i64 %len) unnamed_addr #0 !guid !472 {
start:
  %_0.i = getelementptr inbounds nuw i32, ptr %scratch, i64 %len
  store ptr %scratch, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %scan, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 24
  store ptr %_0.i, ptr %2, align 8
  ret void
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCshXA3KcOxU02_8closures(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #1 !guid !473 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCshXA3KcOxU02_8closures(i64 %3, i64 %5, i1 zeroext %8) #21
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCshXA3KcOxU02_8closures(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #1 !guid !474 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCshXA3KcOxU02_8closures(ptr %2, i64 %4, i64 %6) #21
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCshXA3KcOxU02_8closures(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #1 !guid !475 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #21
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCshXA3KcOxU02_8closures(i64 %11, i64 %13) #21
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCshXA3KcOxU02_8closures(i64 %15, i64 %17) #21
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #21
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #21
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #21
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #21
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #21
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCshXA3KcOxU02_8closures(ptr %ptr, i64 %0, i64 %1) unnamed_addr #1 !guid !476 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCshXA3KcOxU02_8closures(ptr %ptr, i64 %3, i64 %5) #21
  br label %bb3
}

; <alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE3ptrCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !477 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE7reserveCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #1 !guid !478 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8 %self, i64 %len, i64 %additional, i64 8, i64 16) #21
  ret void
}

; <alloc::raw_vec::RawVec<usize>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE6new_inCshXA3KcOxU02_8closures() unnamed_addr #1 personality ptr @rust_eh_personality !guid !479 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<usize>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofjECshXA3KcOxU02_8closures() #21
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64 %_4) #21
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<usize>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE7reserveCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #1 !guid !480 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8 %self, i64 %len, i64 %additional, i64 8, i64 8) #21
  ret void
}

; <alloc::raw_vec::RawVec<usize>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE8capacityCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !481 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 8) #21
  ret i64 %_0
}

; <alloc::raw_vec::RawVec<i32>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE17from_raw_parts_inCshXA3KcOxU02_8closures(ptr %ptr, i64 %capacity) unnamed_addr #1 personality ptr @rust_eh_personality !guid !482 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<i32>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_caplECshXA3KcOxU02_8closures(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr %ptr, i64 %capacity2) #21
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<i32>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE3ptrCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !483 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<i32>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrlECshXA3KcOxU02_8closures(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<i32>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE8capacityCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !484 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 4) #21
  ret i64 %_0
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCshXA3KcOxU02_8closures(i32 %self) unnamed_addr #1 !guid !485 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCshXA3KcOxU02_8closures(i32 %self) #21
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCshXA3KcOxU02_8closures(i32 %self) unnamed_addr #1 !guid !486 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <i32>::checked_add_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl20checked_add_unsignedCshXA3KcOxU02_8closures(i32 %self, i32 %rhs) unnamed_addr #1 !guid !487 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
; call <i32>::overflowing_add_unsigned
  %0 = call { i32, i1 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl24overflowing_add_unsignedCshXA3KcOxU02_8closures(i32 %self, i32 %rhs) #21
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::overflowing_add_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i1 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl24overflowing_add_unsignedCshXA3KcOxU02_8closures(i32 %self, i32 %rhs) unnamed_addr #1 !guid !488 {
start:
  %0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_6.0 = extractvalue { i32, i1 } %0, 0
  %_6.1 = extractvalue { i32, i1 } %0, 1
  %_8 = icmp slt i32 %rhs, 0
  %_7 = xor i1 %_6.1, %_8
  %1 = insertvalue { i32, i1 } poison, i32 %_6.0, 0
  %2 = insertvalue { i32, i1 } %1, i1 %_7, 1
  ret { i32, i1 } %2
}

; <core::ptr::unique::Unique<dyn core::ops::function::Fn<(i32,), Output = i32>>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDINtNtNtB9_3ops8function2FnTlEEp6OutputlEL_E6as_ptrCshXA3KcOxU02_8closures(ptr %self.0, ptr align 8 %self.1) unnamed_addr #1 !guid !489 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <core::ptr::unique::Unique<dyn core::ops::function::Fn<(), Output = usize>>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDINtNtNtB9_3ops8function2FnuEp6OutputjEL_E6as_ptrCshXA3KcOxU02_8closures(ptr %self.0, ptr align 8 %self.1) unnamed_addr #1 !guid !490 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <core::ptr::unique::Unique<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE15as_non_null_ptrCshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !491 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<[i32]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSlE6as_ptrCshXA3KcOxU02_8closures(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !492 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::unique::Unique<i32>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquelE15as_non_null_ptrCshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !493 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::vec::Vec<usize>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecjEE8from_refCshXA3KcOxU02_8closures(ptr align 8 %r) unnamed_addr #1 !guid !494 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::vec::Vec<i32>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VeclEE8from_refCshXA3KcOxU02_8closures(ptr align 8 %r) unnamed_addr #1 !guid !495 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %self, ptr %subtracted) unnamed_addr #1 !guid !496 {
start:
; call <*mut alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB6_3ops8function2FnuEp6OutputjEL_E20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #21
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCshXA3KcOxU02_8closures(ptr align 8 %r) unnamed_addr #1 !guid !497 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE8from_refCshXA3KcOxU02_8closures(ptr align 8 %r.0, i64 %r.1) unnamed_addr #1 !guid !498 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCshXA3KcOxU02_8closures(ptr align 8 %r) unnamed_addr #1 !guid !499 {
start:
  ret ptr %r
}

; <core::num::nonzero::NonZero<usize>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE13leading_zerosCshXA3KcOxU02_8closures(i64 %self) unnamed_addr #1 !guid !500 {
start:
; call <core::num::nonzero::NonZero<usize>>::get
  %_2 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %self) #21
  %0 = call i64 @llvm.ctlz.i64(i64 %_2, i1 true)
  %_0 = trunc i64 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<usize>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE5ilog2CshXA3KcOxU02_8closures(i64 %self) unnamed_addr #1 !guid !501 {
start:
; call <core::num::nonzero::NonZero<usize>>::leading_zeros
  %_3 = call i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE13leading_zerosCshXA3KcOxU02_8closures(i64 %self) #21
  %_0 = sub i32 63, %_3
  ret i32 %_0
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCshXA3KcOxU02_8closures(i64 %val) unnamed_addr #1 !guid !502 {
start:
  ret i64 %val
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitTReFddEdEEj3_E13new_uncheckedCshXA3KcOxU02_8closures(ptr sret([88 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 8 %data) unnamed_addr #1 !guid !503 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %data, i64 72, i1 false)
  ret void
}

; <alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE16with_capacity_inCshXA3KcOxU02_8closures(i64 %capacity) unnamed_addr #1 !guid !504 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 8, i64 16) #21
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<usize>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE16with_capacity_inCshXA3KcOxU02_8closures(i64 %capacity) unnamed_addr #1 !guid !505 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 8, i64 8) #21
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<usize>>::grow_one
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #3 !guid !506 {
start:
; call <alloc::raw_vec::RawVecInner>::grow_one
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneB7_(ptr align 8 %self, i64 8, i64 8) #21
  ret void
}

; <alloc::raw_vec::RawVec<i32>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE16with_capacity_inCshXA3KcOxU02_8closures(i64 %capacity) unnamed_addr #1 !guid !507 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 4, i64 4) #21
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !508 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #21
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCshXA3KcOxU02_8closures(ptr %_7.0, i64 %_7.1) #21
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !509 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshXA3KcOxU02_8closures(ptr %s.0, i64 %s.1) #21
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE3newCshXA3KcOxU02_8closures(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #1 !guid !510 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE8from_refCshXA3KcOxU02_8closures(ptr align 8 %slice.0, i64 %slice.1) #21
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>]>>::cast::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EE4castBV_ECshXA3KcOxU02_8closures(ptr %_4.0, i64 %_4.1) #21
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw %"alloc::boxed::Box<dyn core::ops::function::Fn() -> usize>", ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<i32>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivelE3newCshXA3KcOxU02_8closures(ptr sret([12 x i8]) align 4 %_0, i32 %start1, i32 %end) unnamed_addr #1 !guid !511 {
start:
  store i32 %start1, ptr %_0, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %end, ptr %0, align 4
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 0, ptr %1, align 4
  ret void
}

; <alloc::boxed::Box<[i32]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlE23into_raw_with_allocatorCshXA3KcOxU02_8closures(ptr align 4 %b.0, i64 %b.1) unnamed_addr #1 !guid !512 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE3newCshXA3KcOxU02_8closures(ptr align 4 %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_mutCshXA3KcOxU02_8closures(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_refCshXA3KcOxU02_8closures(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <u64>::div_ceil
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8div_ceilCshXA3KcOxU02_8closures(i64 %self, i64 %rhs, ptr align 8 %0) unnamed_addr #1 !guid !513 {
start:
  %_0 = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %panic, label %bb1

bb1:                                              ; preds = %start
  %d = udiv i64 %self, %rhs
  %_6 = icmp eq i64 %rhs, 0
  br i1 %_6, label %panic1, label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 %0) #25
  unreachable

bb2:                                              ; preds = %bb1
  %r = urem i64 %self, %rhs
  %_7 = icmp ugt i64 %r, 0
  br i1 %_7, label %bb3, label %bb4

panic1:                                           ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 %0) #25
  unreachable

bb4:                                              ; preds = %bb2
  store i64 %d, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb2
  %1 = add i64 %d, 1
  store i64 %1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %2 = load i64, ptr %_0, align 8
  ret i64 %2
}

; <core::ops::range::RangeInclusive<i32>>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivelE8is_emptyCshXA3KcOxU02_8closures(ptr align 4 %self) unnamed_addr #1 !guid !514 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i8, ptr %0, align 4
  %_2 = trunc nuw i8 %1 to i1
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_5 = getelementptr inbounds i8, ptr %self, i64 4
  %_3.i = load i32, ptr %self, align 4
  %_4.i = load i32, ptr %_5, align 4
  %_0.i = icmp sle i32 %_3.i, %_4.i
  %2 = xor i1 %_0.i, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitTReFddEdEEE4nextCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self.0, i64 %self.1) unnamed_addr #1 !guid !515 {
start:
; call <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCshXA3KcOxU02_8closures(ptr align 8 %self.0) #21
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_5.0 = getelementptr inbounds i8, ptr %self.0, i64 16
; call <core::option::Option<usize>>::map::<(&str, fn(f64, f64) -> f64), <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::next::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapTReFddEdENCNvMs8_NtNtNtB5_5array4iter10iter_innerINtB15_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %_2.0, i64 %_2.1, ptr align 8 %_5.0, i64 %self.1) #21
  ret void
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshXA3KcOxU02_8closures(ptr %self) unnamed_addr #1 !guid !516 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCshXA3KcOxU02_8closures(i64 %self, i64 %rhs) unnamed_addr #1 !guid !517 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCshXA3KcOxU02_8closures(i64 %self, i64 %rhs) unnamed_addr #1 !guid !518 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <usize>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj13checked_ilog2CshXA3KcOxU02_8closures(i64 %self) unnamed_addr #1 !guid !519 {
start:
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<usize>>::new
  %0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %self) #21
  store i64 %0, ptr %_2, align 8
  %1 = load i64, ptr %_2, align 8
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i64, ptr %_2, align 8
; call <core::num::nonzero::NonZero<usize>>::ilog2
  %_5 = call i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE5ilog2CshXA3KcOxU02_8closures(i64 %x) #21
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <usize>::is_multiple_of
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj14is_multiple_ofCshXA3KcOxU02_8closures(i64 %self, i64 %rhs) unnamed_addr #1 !guid !520 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = icmp eq i64 %rhs, 0
  br i1 %0, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %self, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_0, align 1
  br label %bb4

bb1:                                              ; preds = %start
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %panic, label %bb3

bb4:                                              ; preds = %bb3, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb3:                                              ; preds = %bb1
  %_3 = urem i64 %self, %rhs
  %5 = icmp eq i64 %_3, 0
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

panic:                                            ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_9f4cf96e0cfa121f5a07edf0a5a77ed7) #25
  unreachable
}

; <usize>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj5ilog2CshXA3KcOxU02_8closures(i64 %self, ptr align 8 %0) unnamed_addr #1 !guid !521 {
start:
  %_2 = alloca [8 x i8], align 4
; call <usize>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj13checked_ilog2CshXA3KcOxU02_8closures(i64 %self) #21
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #27
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCshXA3KcOxU02_8closures(i64 %self, i64 %other) unnamed_addr #1 !guid !522 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCshXA3KcOxU02_8closures(i32 %_0.i) #21
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE16with_capacity_inCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !523 {
start:
; call <alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE16with_capacity_inCshXA3KcOxU02_8closures(i64 %capacity) #21
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<usize>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE16with_capacity_inCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !524 {
start:
; call <alloc::raw_vec::RawVec<usize>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE16with_capacity_inCshXA3KcOxU02_8closures(i64 %capacity) #21
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<usize>>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE4pushCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %value) unnamed_addr #1 !guid !525 {
start:
; call <alloc::vec::Vec<usize>>::push_mut
  %_3 = call align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE8push_mutCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %value) #21
  ret void
}

; <alloc::vec::Vec<usize>>::push_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE8push_mutCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %value) unnamed_addr #1 personality ptr @rust_eh_personality !guid !526 {
start:
  %_13 = alloca [1 x i8], align 1
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<usize>>::capacity
  %_5 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE8capacityCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  br label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp eq i64 %len, %_5
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb10, %bb1
; call <alloc::vec::Vec<usize>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  br label %bb4

bb2:                                              ; preds = %bb1
; call <alloc::raw_vec::RawVec<usize>>::grow_one
  call void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCshXA3KcOxU02_8closures(ptr align 8 %self) #26
  br label %bb10

bb10:                                             ; preds = %bb2
  br label %bb3

bb4:                                              ; preds = %bb3
  %_0.i = getelementptr inbounds nuw i64, ptr %_10, i64 %len
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_13, align 1
  store i64 %value, ptr %_0.i, align 8
  br label %bb6

bb6:                                              ; preds = %bb5
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = add i64 %len, 1
  store i64 %2, ptr %1, align 8
  ret ptr %_0.i

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<i32>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclE16with_capacity_inCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !527 {
start:
; call <alloc::raw_vec::RawVec<i32>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE16with_capacity_inCshXA3KcOxU02_8closures(i64 %capacity) #21
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshXA3KcOxU02_8closures(i8 %0) unnamed_addr #1 !guid !528 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshXA3KcOxU02_8closures(ptr %self) #21
  ret i32 %_0
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !529 {
start:
; call <alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE3ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE6as_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !530 {
start:
; call <alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE3ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  ret ptr %_2
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE7reserveCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !531 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE7reserveCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %_5, i64 %additional) #21
  ret void
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE8as_sliceCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !532 {
start:
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE6as_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<usize>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !533 {
start:
; call <alloc::raw_vec::RawVec<usize>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE3ptrCshGsV4pNJ6ra_6object(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::vec::Vec<usize>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE3lenCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !534 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 1152921504606846975
  ret i64 %len
}

; <alloc::vec::Vec<usize>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE7reserveCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !535 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<usize>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE7reserveCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %_5, i64 %additional) #21
  ret void
}

; <alloc::vec::Vec<i32>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !536 {
start:
; call <alloc::raw_vec::RawVec<i32>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE3ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::vec::Vec<i32>>::as_mut_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE12as_mut_sliceCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !537 {
start:
; call <alloc::vec::Vec<i32>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<i32>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE17from_raw_parts_inCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #1 personality ptr @rust_eh_personality !guid !538 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCshXA3KcOxU02_8closures(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<i32>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE17from_raw_parts_inCshXA3KcOxU02_8closures(ptr %ptr, i64 %capacity) #21
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<i32>>::spare_capacity_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE18spare_capacity_mutCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !539 {
start:
; call <alloc::vec::Vec<i32>>::as_mut_ptr
  %_4 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_4, i64 %_5
; call <alloc::raw_vec::RawVec<i32>>::capacity
  %_7 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE8capacityCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_9 = load i64, ptr %1, align 8
  %_6 = sub i64 %_7, %_9
; call core::slice::raw::from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
  %2 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEECshXA3KcOxU02_8closures(ptr %_0.i, i64 %_6, ptr align 8 @alloc_027cef065c3c71aa2f31a680ec9e0201) #21
  %_0.0 = extractvalue { ptr, i64 } %2, 0
  %_0.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1, 1
  ret { ptr, i64 } %4
}

; <alloc::vec::Vec<i32>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE6as_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !540 {
start:
; call <alloc::raw_vec::RawVec<i32>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE3ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  ret ptr %_2
}

; <alloc::vec::Vec<i32>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE8as_sliceCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !541 {
start:
; call <alloc::vec::Vec<i32>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE6as_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitTReFddEdEEj3_EE4dropCshXA3KcOxU02_8closures(ptr align 8 %slot) unnamed_addr #1 !guid !542 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitTReFddEdEEj3_EE6as_mutCshXA3KcOxU02_8closures(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitTReFddEdEEj3_EECshXA3KcOxU02_8closures(ptr align 8 %_3)
  ret void
}

; <*mut alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_E10cast_sliceCshXA3KcOxU02_8closures(ptr %self, i64 %len) unnamed_addr #1 !guid !543 {
start:
; call core::ptr::slice_from_raw_parts_mut::<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr %self, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut usize>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOj10cast_sliceCshXA3KcOxU02_8closures(ptr %self, i64 %len) unnamed_addr #1 !guid !544 {
start:
; call core::ptr::slice_from_raw_parts_mut::<usize>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutjECshXA3KcOxU02_8closures(ptr %self, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut i32>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl10cast_sliceCshXA3KcOxU02_8closures(ptr %self, i64 %len) unnamed_addr #1 !guid !545 {
start:
; call core::ptr::slice_from_raw_parts_mut::<i32>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECshXA3KcOxU02_8closures(ptr %self, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; closures::main::{closure#7}::fact
; Function Attrs: nonlazybind uwtable
define internal i64 @_RNvNCNvCshXA3KcOxU02_8closures4mains5_04fact(i64 %n) unnamed_addr #0 !guid !546 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp eq i64 %n, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_5.0 = sub i64 %n, 1
  %_5.1 = icmp ult i64 %n, 1
  br i1 %_5.1, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb6

bb3:                                              ; preds = %bb2
; call closures::main::{closure#7}::fact
  %_3 = call i64 @_RNvNCNvCshXA3KcOxU02_8closures4mains5_04fact(i64 %_5.0)
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %n, i64 %_3)
  %_6.0 = extractvalue { i64, i1 } %0, 0
  %_6.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_6.1, label %panic1, label %bb5

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_a486ca5f44dc72a11bf5950520485aa9) #25
  unreachable

bb5:                                              ; preds = %bb3
  store i64 %_6.0, ptr %_0, align 8
  br label %bb6

panic1:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_65d221b36a247b637ff22be5417994a4) #25
  unreachable

bb6:                                              ; preds = %bb1, %bb5
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #1 !guid !547 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCshXA3KcOxU02_8closures(ptr align 8 %args) #21
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #21
  ret void
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCshXA3KcOxU02_8closures(i64 %0, i64 %1) unnamed_addr #1 !guid !548 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCshXA3KcOxU02_8closures(ptr %ptr, i64 %0, i64 %1) unnamed_addr #1 !guid !549 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #29
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCshXA3KcOxU02_8closures(i64 %0, i64 %1) unnamed_addr #1 !guid !550 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCshXA3KcOxU02_8closures(i64 %layout.0, i64 %layout.1) unnamed_addr #1 !guid !551 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCshXA3KcOxU02_8closures(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #21
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #27
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #21
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCshXA3KcOxU02_8closures() unnamed_addr #4 !guid !552 {
start:
  ret void
}

; core::ptr::swap_nonoverlapping_bytes
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytesCshXA3KcOxU02_8closures(ptr %x, ptr %y, i64 %bytes) unnamed_addr #1 !guid !553 {
start:
  %_15 = alloca [8 x i8], align 8
  %_9 = alloca [8 x i8], align 8
; call <core::num::nonzero::NonZero<usize>>::get
  %bytes1 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %bytes) #21
  %chunks = udiv i64 %bytes1, 8
  %tail = urem i64 %bytes1, 8
; call <core::num::nonzero::NonZero<usize>>::new
  %0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %chunks) #21
  store i64 %0, ptr %_9, align 8
  %1 = load i64, ptr %_9, align 8
  %2 = icmp eq i64 %1, 0
  %_10 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_10 to i1
  br i1 %3, label %bb5, label %bb8

bb5:                                              ; preds = %start
  %chunks2 = load i64, ptr %_9, align 8
; call core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_chunks::<8>
  call void @_RINvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes26swap_nonoverlapping_chunksKj8_ECshGsV4pNJ6ra_6object(ptr %x, ptr %y, i64 %chunks2)
  br label %bb8

bb8:                                              ; preds = %bb5, %start
; call <core::num::nonzero::NonZero<usize>>::new
  %4 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %tail) #21
  store i64 %4, ptr %_15, align 8
  %5 = load i64, ptr %_15, align 8
  %6 = icmp eq i64 %5, 0
  %_16 = select i1 %6, i64 0, i64 1
  %7 = trunc nuw i64 %_16 to i1
  br i1 %7, label %bb10, label %bb13

bb10:                                             ; preds = %bb8
  %tail3 = load i64, ptr %_15, align 8
  %delta = mul i64 %chunks, 8
  %_0.i4 = getelementptr inbounds nuw i8, ptr %x, i64 %delta
  %_0.i = getelementptr inbounds nuw i8, ptr %y, i64 %delta
; call core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_short
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes25swap_nonoverlapping_shortCshXA3KcOxU02_8closures(ptr %_0.i4, ptr %_0.i, i64 %tail3) #21
  br label %bb13

bb13:                                             ; preds = %bb10, %bb8
  ret void

bb14:                                             ; No predecessors!
  unreachable
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCshXA3KcOxU02_8closures(ptr %ptr, i64 %align) unnamed_addr #1 !guid !554 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCshXA3KcOxU02_8closures(ptr %ptr, i64 %align) #21
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() unnamed_addr #1 !guid !555 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCshXA3KcOxU02_8closures() #21
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCshXA3KcOxU02_8closures(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #1 !guid !556 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCshXA3KcOxU02_8closures(ptr %3, ptr %5, i64 %7, i64 %9) #21
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCshXA3KcOxU02_8closures(i64 %size, i64 %len) unnamed_addr #1 !guid !557 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #25
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshXA3KcOxU02_8closures(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #1 !guid !558 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCshXA3KcOxU02_8closures(ptr %ptr, i64 %align) #21
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr %ptr) #21
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCshXA3KcOxU02_8closures(ptr %v.0, i64 %v.1) unnamed_addr #1 !guid !559 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; <[_]>::split_at_mut_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp22split_at_mut_unchecked18precondition_checkCshXA3KcOxU02_8closures(i64 %mid, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !560 {
start:
  %_3 = icmp ule i64 %mid, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_6b0b11c9e93314b588b613b55005cf18, i64 221)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCshXA3KcOxU02_8closures(i64 %align, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !561 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCshXA3KcOxU02_8closures(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !562 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCshXA3KcOxU02_8closures(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !563 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCshXA3KcOxU02_8closures(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !564 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCshXA3KcOxU02_8closures(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !565 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !566 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshXA3KcOxU02_8closures(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshXA3KcOxU02_8closures(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCshXA3KcOxU02_8closures(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; core::ptr::swap_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %x, ptr %y, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !567 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %size, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %count, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_11 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshXA3KcOxU02_8closures(ptr %x, i64 %align, i1 zeroext %_11)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_14 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_12 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshXA3KcOxU02_8closures(ptr %y, i64 %align, i1 zeroext %_14)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_12, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCshXA3KcOxU02_8closures(ptr %x, ptr %y, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_2875d9f120b8cc0de1c30c014c7b6715, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_18.0 = extractvalue { ptr, ptr } %10, 0
  %_18.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_18.0, ptr %_18.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_short
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes25swap_nonoverlapping_shortCshXA3KcOxU02_8closures(ptr %x, ptr %y, i64 %bytes) unnamed_addr #1 !guid !568 {
start:
  %i = alloca [8 x i8], align 8
; call <core::num::nonzero::NonZero<usize>>::get
  %bytes1 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %bytes) #21
  store i64 0, ptr %i, align 8
  %_7 = and i64 %bytes1, 4
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb2, label %bb8

bb8:                                              ; preds = %bb2, %start
  %_18 = and i64 %bytes1, 2
  %_17 = icmp ne i64 %_18, 0
  br i1 %_17, label %bb9, label %bb15

bb2:                                              ; preds = %start
  %_12 = load i64, ptr %i, align 8
  %_0.i6 = getelementptr inbounds nuw i8, ptr %x, i64 %_12
  %_16 = load i64, ptr %i, align 8
  %_0.i5 = getelementptr inbounds nuw i8, ptr %y, i64 %_16
; call core::ptr::swap_chunk::<4>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj4_ECshGsV4pNJ6ra_6object(ptr %_0.i6, ptr %_0.i5) #21
  %0 = load i64, ptr %i, align 8
  %1 = or i64 %0, 4
  store i64 %1, ptr %i, align 8
  br label %bb8

bb15:                                             ; preds = %bb9, %bb8
  %_29 = and i64 %bytes1, 1
  %_28 = icmp ne i64 %_29, 0
  br i1 %_28, label %bb16, label %bb22

bb9:                                              ; preds = %bb8
  %_23 = load i64, ptr %i, align 8
  %_0.i4 = getelementptr inbounds nuw i8, ptr %x, i64 %_23
  %_27 = load i64, ptr %i, align 8
  %_0.i3 = getelementptr inbounds nuw i8, ptr %y, i64 %_27
; call core::ptr::swap_chunk::<2>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj2_ECshGsV4pNJ6ra_6object(ptr %_0.i4, ptr %_0.i3) #21
  %2 = load i64, ptr %i, align 8
  %3 = or i64 %2, 2
  store i64 %3, ptr %i, align 8
  br label %bb15

bb22:                                             ; preds = %bb16, %bb15
  ret void

bb16:                                             ; preds = %bb15
  %_34 = load i64, ptr %i, align 8
  %_0.i2 = getelementptr inbounds nuw i8, ptr %x, i64 %_34
  %_38 = load i64, ptr %i, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %y, i64 %_38
; call core::ptr::swap_chunk::<1>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj1_ECshGsV4pNJ6ra_6object(ptr %_0.i2, ptr %_0.i) #21
  %4 = load i64, ptr %i, align 8
  %5 = or i64 %4, 1
  store i64 %5, ptr %i, align 8
  br label %bb22
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCshXA3KcOxU02_8closures(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !569 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCshXA3KcOxU02_8closures(ptr %ptr, i64 %align) unnamed_addr #1 !guid !570 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr %ptr, i64 %align) #21
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCshXA3KcOxU02_8closures() unnamed_addr #1 !guid !571 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCshXA3KcOxU02_8closures(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #1 !guid !572 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCshXA3KcOxU02_8closures(i64 %size, i64 %count) #21
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCshXA3KcOxU02_8closures(i64 %_0.i2, i64 %_0.i) #21
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #28
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCshXA3KcOxU02_8closures(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !573 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshXA3KcOxU02_8closures(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_a28e8c8fd5088943a8b5d44af697ff83, i64 279)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCshXA3KcOxU02_8closures(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; core::slice::raw::from_raw_parts_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCshXA3KcOxU02_8closures(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !574 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCshXA3KcOxU02_8closures(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_5c1a2f972552229672fc942406cfc298, i64 283)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCshXA3KcOxU02_8closures(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCshXA3KcOxU02_8closures(i64 %this, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !575 {
start:
  %_3 = icmp ult i64 %this, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_97d92cbf2a68a6ac45a1b13da79836e4, i64 214)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCshXA3KcOxU02_8closures(i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !576 {
start:
  %_3 = icmp ule i64 %end, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_5a8fdd84b3281310cbf6b74bb6bf0065, i64 218)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtBb_3ops5range5RangejEINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCshXA3KcOxU02_8closures(i64 %start1, i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !577 {
start:
  %_4 = icmp uge i64 %end, %start1
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_18d73aa062d524e9620b9e3b55bd9eb1, i64 218)
          to label %bb4 unwind label %terminate

bb1:                                              ; preds = %start
  %_5 = icmp ule i64 %end, %len
  br i1 %_5, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  ret void

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb4:                                              ; preds = %bb3
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_7.0, ptr %_7.1, i1 zeroext false, ptr align 8 %0) #28
  unreachable
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as alloc::vec::spec_from_iter::SpecFromIter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EEINtB2_12SpecFromIterBU_INtNtNtNtB1k_4iter8adapters3map3MapINtNtB1i_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE9from_iterB3w_(ptr sret([24 x i8]) align 8 %_0, i64 %iterator.0, i64 %iterator.1) unnamed_addr #0 !guid !578 {
start:
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>>::from_iter
  call void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB6_3VecINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EEINtB4_18SpecFromIterNestedB13_INtNtNtNtB1t_4iter8adapters3map3MapINtNtB1r_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE9from_iterB3M_(ptr sret([24 x i8]) align 8 %_0, i64 %iterator.0, i64 %iterator.1)
  ret void
}

; <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter::SpecFromIter<usize, core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecjEINtB2_12SpecFromIterjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1q_5slice4iter4IterINtNtB6_5boxed3BoxDINtNtNtB1q_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE9from_iterB3A_(ptr sret([24 x i8]) align 8 %_0, ptr %iterator.0, ptr %iterator.1) unnamed_addr #0 !guid !579 {
start:
; call <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>>::from_iter
  call void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB6_3VecjEINtB4_18SpecFromIterNestedjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1F_5slice4iter4IterINtNtB8_5boxed3BoxDINtNtNtB1F_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE9from_iterB3P_(ptr sret([24 x i8]) align 8 %_0, ptr %iterator.0, ptr %iterator.1)
  ret void
}

; <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters3map3MapINtNtNtB8_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtB2_12IntoIterator9into_iterB1I_(i64 %self.0, i64 %self.1) unnamed_addr #1 !guid !580 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %self.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %self.1, 1
  ret { i64, i64 } %1
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters3map3MapINtNtNtB8_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtB2_12IntoIterator9into_iterB2W_(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !581 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<usize> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterjENtB2_12IntoIterator9into_iterCshXA3KcOxU02_8closures(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !582 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCshXA3KcOxU02_8closures(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !583 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitTReFddEdEENtB2_11PartialDrop12partial_dropCshXA3KcOxU02_8closures(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1) unnamed_addr #0 !guid !584 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitTReFddEdEE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECshXA3KcOxU02_8closures(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1, ptr align 8 @alloc_c7037efb906203803aa3ca07167c9120) #21
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitTReFddEdEE8is_emptyCshXA3KcOxU02_8closures(ptr align 8 %_3.0, i64 %_3.1) #21
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitTReFddEdEE16assume_init_dropCshXA3KcOxU02_8closures.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitTReFddEdEE16assume_init_dropCshXA3KcOxU02_8closures.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitTReFddEdEE16assume_init_dropCshXA3KcOxU02_8closures.exit: ; preds = %start, %bb2.i
  ret void
}

; <core::hint::select_unpredictable::DropOnPanic<*const i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNvNtCsl10jNU3mE6R_4core4hint20select_unpredictableINtB2_11DropOnPanicPlENtNtNtB6_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !585 {
start:
  %_2 = load ptr, ptr %self, align 8
  ret void
}

; <[(&str, fn(f64, f64) -> f64); 3] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterATReFddEdEj3_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCshXA3KcOxU02_8closures(ptr sret([88 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !586 {
start:
  %0 = alloca [88 x i8], align 8
  %_2.i = alloca [88 x i8], align 8
  %1 = alloca [88 x i8], align 8
  %2 = alloca [72 x i8], align 8
  %_5 = alloca [88 x i8], align 8
  %inner = alloca [88 x i8], align 8
  %data = alloca [72 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %self, i64 72, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCshXA3KcOxU02_8closures(i64 3) #21
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %data, i64 72, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitTReFddEdEEj3_E13new_uncheckedCshXA3KcOxU02_8closures(ptr sret([88 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 8 %2) #21
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 88, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 88, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitTReFddEdEEj3_EE3newCshXA3KcOxU02_8closures(ptr sret([88 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 88, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 88, i1 false)
  ret void
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitTReFddEdEEE13get_uncheckedCshXA3KcOxU02_8closures(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !587 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitTReFddEdEEECshXA3KcOxU02_8closures(ptr %slice.0, i64 %slice.1) #21
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>", ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitTReFddEdEEECshXA3KcOxU02_8closures(ptr %slice.0, i64 %slice.1) #21
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCshXA3KcOxU02_8closures(i64 %self, i64 %_0.i1, ptr align 8 %0) #24
  br label %bb4
}

; <usize as core::slice::index::SliceIndex<[i32]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSlE13get_uncheckedCshXA3KcOxU02_8closures(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !588 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[i32]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSlECshXA3KcOxU02_8closures(ptr %slice.0, i64 %slice.1) #21
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[i32]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSlECshXA3KcOxU02_8closures(ptr %slice.0, i64 %slice.1) #21
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCshXA3KcOxU02_8closures(i64 %self, i64 %_0.i1, ptr align 8 %0) #24
  br label %bb4
}

; <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtNtNtB9_6traits8iterator8Iterator9size_hintB1s_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !589 {
start:
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator9size_hintB9_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #21
  ret void
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBb_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtNtNtB9_6traits8iterator8Iterator9size_hintB2G_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !590 {
start:
; call <core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EENtNtNtNtBa_4iter6traits8iterator8Iterator9size_hintCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #21
  ret void
}

; <i32 as core::slice::sort::stable::quicksort::IsFreeze>::is_freeze
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs0_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortlNtB5_8IsFreeze9is_freezeCshXA3KcOxU02_8closures() unnamed_addr #0 !guid !591 {
start:
  ret i1 true
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCshXA3KcOxU02_8closures(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #1 !guid !592 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCshXA3KcOxU02_8closures(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #21
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCshXA3KcOxU02_8closures(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #1 !guid !593 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCshXA3KcOxU02_8closures(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EENtNtB1a_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !594 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 8, i64 16)
  ret void
}

; <alloc::raw_vec::RawVec<usize> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !595 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 8, i64 8)
  ret void
}

; <alloc::raw_vec::RawVec<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !596 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 4, i64 4)
  ret void
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitTReFddEdEEE17get_unchecked_mutCshXA3KcOxU02_8closures(i64 %0, i64 %1, ptr %slice.0, i64 %slice.1, ptr align 8 %2) unnamed_addr #1 !guid !597 {
start:
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ops::index_range::IndexRange>::end
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCshXA3KcOxU02_8closures(ptr align 8 %self) #21
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitTReFddEdEEECshXA3KcOxU02_8closures(ptr %slice.0, i64 %slice.1) #21
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCshXA3KcOxU02_8closures(i64 %_5, i64 %_0.i, ptr align 8 %2) #24
  br label %bb4

bb4:                                              ; preds = %bb1
; call <core::ops::index_range::IndexRange>::start
  %_8 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCshXA3KcOxU02_8closures(ptr align 8 %self) #21
; call <core::ops::index_range::IndexRange>::len
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %ptr.i = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>", ptr %slice.0, i64 %_8
  %4 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_10, 1
  %_0.0 = extractvalue { ptr, i64 } %5, 0
  %_0.1 = extractvalue { ptr, i64 } %5, 1
  %6 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %_0.1, 1
  ret { ptr, i64 } %7
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitTReFddEdEEj3_ENtNtNtBb_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !598 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitTReFddEdEEj3_NtB4_11PartialDrop12partial_dropCshXA3KcOxU02_8closures(ptr align 8 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <i32 as core::cmp::Ord>::cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXs1d_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB8_3Ord3cmpCshXA3KcOxU02_8closures(ptr align 4 %self, ptr align 4 %other) unnamed_addr #1 !guid !599 {
start:
  %_3 = load i32, ptr %self, align 4
  %_4 = load i32, ptr %other, align 4
  %_0 = call i8 @llvm.scmp.i8.i32(i32 %_3, i32 %_4)
  ret i8 %_0
}

; <core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBa_3ops8function2FnuEp6OutputjEL_EENtNtNtNtBa_4iter6traits8iterator8Iterator9size_hintCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !600 {
start:
  %exact = alloca [8 x i8], align 8
  br label %bb3

bb3:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_6 = load ptr, ptr %0, align 8
  %_7 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EE20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %_6, ptr %_7) #21
  store i64 %1, ptr %exact, align 8
  br label %bb4

bb4:                                              ; preds = %bb3
  %_8 = load i64, ptr %exact, align 8
  %_10 = load i64, ptr %exact, align 8
  store i64 %_8, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %_10, ptr %3, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !601 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #21
  ret void
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[i32]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSlE17get_unchecked_mutCshXA3KcOxU02_8closures(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !602 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[i32]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSlECshXA3KcOxU02_8closures(ptr %slice.0, i64 %slice.1) #21
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtBb_3ops5range5RangejEINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCshXA3KcOxU02_8closures(i64 %self.0, i64 %self.1, i64 %_0.i, ptr align 8 %0) #24
  br label %bb3

bb3:                                              ; preds = %bb1
  %new_len = sub nuw i64 %self.1, %self.0
  %ptr.i = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self.0
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %new_len, 1
  %_0.0 = extractvalue { ptr, i64 } %2, 0
  %_0.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1, 1
  ret { ptr, i64 } %4
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 %self.0, i64 %self.1, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !603 {
start:
  %_3 = alloca [16 x i8], align 8
; call <usize>::checked_sub
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCshXA3KcOxU02_8closures(i64 %self.1, i64 %self.0) #21
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_6 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_6 to i1
  br i1 %7, label %bb2, label %bb5

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %new_len = load i64, ptr %8, align 8
  %_8 = icmp ule i64 %self.1, %slice.1
  br i1 %_8, label %bb3, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %self.0, i64 %self.1, i64 %slice.1, ptr align 8 %0) #25
  unreachable

bb3:                                              ; preds = %bb2
  %ptr.i = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self.0
  %9 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %new_len, 1
  %_12.0 = extractvalue { ptr, i64 } %10, 0
  %_12.1 = extractvalue { ptr, i64 } %10, 1
  %11 = insertvalue { ptr, i64 } poison, ptr %_12.0, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %_12.1, 1
  ret { ptr, i64 } %12

bb6:                                              ; No predecessors!
  unreachable
}

; <core::array::iter::IntoIter<(&str, fn(f64, f64) -> f64), 3> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterTReFddEdEKj3_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !604 {
start:
; call <core::array::iter::IntoIter<(&str, fn(f64, f64) -> f64), 3>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterTReFddEdEKj3_E10unsize_mutCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>]>>::next
  call void @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitTReFddEdEEE4nextCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2.0, i64 %_2.1) #21
  ret void
}

; <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !605 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %1 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 0, i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) #21
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ops::index_range::IndexRange as core::clone::Clone>::clone
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !606 {
start:
  %_2 = load i64, ptr %self, align 8
  %_5 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %_5, align 8
  %0 = insertvalue { i64, i64 } poison, i64 %_2, 0
  %1 = insertvalue { i64, i64 } %0, i64 %_4, 1
  ret { i64, i64 } %1
}

; <core::array::iter::IntoIter<(&str, fn(f64, f64) -> f64), 3> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterTReFddEdEKj3_ENtNtNtB9_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !607 {
start:
; call core::mem::needs_drop::<(&str, fn(f64, f64) -> f64)>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropTReFddEdEECshXA3KcOxU02_8closures() #21
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitTReFddEdEEj3_EE4dropCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  br label %bb3
}

; <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSlE9index_mutCshXA3KcOxU02_8closures(i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !608 {
start:
  %_3 = icmp ugt i64 %self, %slice.1
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %new_len = sub nuw i64 %slice.1, %self
  %ptr.i = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %new_len, 1
  %_17.0 = extractvalue { ptr, i64 } %2, 0
  %_17.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_17.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_17.1, 1
  ret { ptr, i64 } %4

bb1:                                              ; preds = %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %self, i64 %slice.1, i64 %slice.1, ptr align 8 %0) #25
  unreachable
}

; <core::slice::sort::shared::smallsort::CopyOnDrop<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs5_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsortINtB5_10CopyOnDroplENtNtNtBd_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !609 {
start:
  %_3 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %1, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %start
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_3, ptr %_4, i64 4, i64 4, i64 %_5, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %start, %bb2.i
  %2 = mul nuw nsw i64 %_5, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_4, ptr align 4 %_3, i64 %2, i1 false)
  ret void
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EENtNtB13_5deref5Deref5derefCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !610 {
start:
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE8as_sliceCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<i32> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !611 {
start:
; call <alloc::vec::Vec<i32>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE8as_sliceCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::boxed::Box<dyn core::ops::function::Fn<(i32,), Output = i32>> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnTlEEp6OutputlEL_ENtNtBN_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !612 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<dyn core::ops::function::Fn<(i32,), Output = i32>>>::as_ptr
  %1 = call { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDINtNtNtB9_3ops8function2FnTlEEp6OutputlEL_E6as_ptrCshXA3KcOxU02_8closures(ptr %ptr.0, ptr align 8 %ptr.1) #21
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<dyn core::ops::function::Fn<(i32,), Output = i32>>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDINtNtNtB7_3ops8function2FnTlEEp6OutputlEL_ECshXA3KcOxU02_8closures(ptr %_5.0, ptr align 8 %_5.1) #21
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<dyn core::ops::function::Fn<(i32,), Output = i32>>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDINtNtNtBa_3ops8function2FnTlEEp6OutputlEL_E4casthECshXA3KcOxU02_8closures(ptr %ptr.0, ptr align 8 %ptr.1) #21
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #21
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCshXA3KcOxU02_8closures(ptr %_10, ptr %_11, i64 %6, i64 %8) #21
  br label %bb7
}

; <alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_ENtNtBN_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !613 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<dyn core::ops::function::Fn<(), Output = usize>>>::as_ptr
  %1 = call { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDINtNtNtB9_3ops8function2FnuEp6OutputjEL_E6as_ptrCshXA3KcOxU02_8closures(ptr %ptr.0, ptr align 8 %ptr.1) #21
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<dyn core::ops::function::Fn<(), Output = usize>>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDINtNtNtB7_3ops8function2FnuEp6OutputjEL_ECshXA3KcOxU02_8closures(ptr %_5.0, ptr align 8 %_5.1) #21
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<dyn core::ops::function::Fn<(), Output = usize>>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDINtNtNtBa_3ops8function2FnuEp6OutputjEL_E4casthECshXA3KcOxU02_8closures(ptr %ptr.0, ptr align 8 %ptr.1) #21
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #21
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCshXA3KcOxU02_8closures(ptr %_10, ptr %_11, i64 %6, i64 %8) #21
  br label %bb7
}

; <alloc::boxed::Box<[i32]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !614 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[i32]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSlE6as_ptrCshXA3KcOxU02_8closures(ptr %ptr.0, i64 %ptr.1) #21
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[i32]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSlECshXA3KcOxU02_8closures(ptr %_5.0, i64 %_5.1) #21
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCshXA3KcOxU02_8closures(ptr align 8 %layout) #21
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[i32]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSlE4casthECshXA3KcOxU02_8closures(ptr %ptr.0, i64 %ptr.1) #21
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #21
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCshXA3KcOxU02_8closures(ptr %_10, ptr %_11, i64 %6, i64 %8) #21
  br label %bb7
}

; <alloc::vec::Vec<i32> as core::slice::sort::stable::BufGuard<i32>>::with_capacity
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VeclEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardlE13with_capacityCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !615 {
start:
; call <alloc::vec::Vec<i32>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeclE13with_capacityCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #21
  ret void
}

; <alloc::vec::Vec<i32> as core::slice::sort::stable::BufGuard<i32>>::as_uninit_slice_mut
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VeclEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardlE19as_uninit_slice_mutCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !616 {
start:
; call <alloc::vec::Vec<i32>>::spare_capacity_mut
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE18spare_capacity_mutCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<i32> as core::ops::deref::DerefMut>::deref_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !617 {
start:
; call <alloc::vec::Vec<i32>>::as_mut_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE12as_mut_sliceCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <i32 as core::iter::range::Step>::forward_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXsI_NtNtCsl10jNU3mE6R_4core4iter5rangelNtB5_4Step17forward_uncheckedCshXA3KcOxU02_8closures(i32 %start1, i64 %n) unnamed_addr #1 !guid !618 {
start:
  %_4 = trunc i64 %n to i32
; call <i32>::checked_add_unsigned
  %0 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl20checked_add_unsignedCshXA3KcOxU02_8closures(i32 %start1, i32 %_4) #21
  %_3.0 = extractvalue { i32, i32 } %0, 0
  %_3.1 = extractvalue { i32, i32 } %0, 1
; call <core::option::Option<i32>>::unwrap_unchecked
  %_0 = call i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE16unwrap_uncheckedCsddYV2PBJW9h_3std(i32 %_3.0, i32 %_3.1, ptr align 8 @alloc_33c781d4b73231c4b72218e776044e11) #21
  ret i32 %_0
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !619 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #21
  ret void
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshXA3KcOxU02_8closures() unnamed_addr #1 !guid !620 {
start:
  ret i8 0
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as alloc::vec::spec_extend::SpecExtend<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB6_3VecINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EEINtB4_10SpecExtendBT_INtNtNtNtB1j_4iter8adapters3map3MapINtNtB1h_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE11spec_extendB3t_(ptr align 8 %self, i64 %iterator.0, i64 %iterator.1) unnamed_addr #0 !guid !621 {
start:
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::extend_trusted::<core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>
  call void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE14extend_trustedINtNtNtNtB16_4iter8adapters3map3MapINtNtB14_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EEB3b_(ptr align 8 %self, i64 %iterator.0, i64 %iterator.1)
  ret void
}

; <alloc::vec::Vec<usize> as alloc::vec::spec_extend::SpecExtend<usize, core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB6_3VecjEINtB4_10SpecExtendjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1n_5slice4iter4IterINtNtB8_5boxed3BoxDINtNtNtB1n_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE11spec_extendB3x_(ptr align 8 %self, ptr %iterator.0, ptr %iterator.1) unnamed_addr #0 !guid !622 {
start:
; call <alloc::vec::Vec<usize>>::extend_trusted::<core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>
  call void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterINtNtB8_5boxed3BoxDINtNtNtB17_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EEB3h_(ptr align 8 %self, ptr %iterator.0, ptr %iterator.1)
  ret void
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB6_3VecINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EEINtB4_18SpecFromIterNestedB13_INtNtNtNtB1t_4iter8adapters3map3MapINtNtB1r_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE9from_iterB3M_(ptr sret([24 x i8]) align 8 %_0, i64 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !623 {
start:
  %2 = alloca [16 x i8], align 8
  %_12 = alloca [1 x i8], align 1
  %_3 = alloca [24 x i8], align 8
  %vector = alloca [24 x i8], align 8
  %iterator = alloca [16 x i8], align 8
  store i64 %0, ptr %iterator, align 8
  %3 = getelementptr inbounds i8, ptr %iterator, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_12, align 1
  store i8 1, ptr %_12, align 1
; call <core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_3ops5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0ENtNtNtB9_6traits8iterator8Iterator9size_hintB1s_(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %iterator) #21
  br label %bb1

bb1:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %_5 = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb3, label %bb2

bb3:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %upper = load i64, ptr %9, align 8
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecINtNtB4_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE13with_capacityCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %vector, i64 %upper) #21
  br label %bb4

bb2:                                              ; preds = %bb1
; call <core::fmt::Arguments>::from_str
  %10 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_31365cfefba383c4d2bf6b6a04cc10aa, i64 17) #21
  %_8.0 = extractvalue { ptr, ptr } %10, 0
  %_8.1 = extractvalue { ptr, ptr } %10, 1
  br label %bb5

bb4:                                              ; preds = %bb3
  store i8 0, ptr %_12, align 1
  %_11.0 = load i64, ptr %iterator, align 8
  %11 = getelementptr inbounds i8, ptr %iterator, i64 8
  %_11.1 = load i64, ptr %11, align 8
; invoke <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as alloc::vec::spec_extend::SpecExtend<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>, core::iter::adapters::map::Map<core::ops::range::Range<usize>, closures::main::{closure#4}>>>::spec_extend
  invoke void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB6_3VecINtNtB8_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EEINtB4_10SpecExtendBT_INtNtNtNtB1j_4iter8adapters3map3MapINtNtB1h_5range5RangejENCNvCshXA3KcOxU02_8closures4mains2_0EE11spec_extendB3t_(ptr align 8 %vector, i64 %_11.0, i64 %_11.1)
          to label %bb6 unwind label %cleanup

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecINtNtBG_5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EEECshXA3KcOxU02_8closures(ptr align 8 %vector) #22
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4
  %12 = landingpad { ptr, i32 }
          cleanup
  %13 = extractvalue { ptr, i32 } %12, 0
  %14 = extractvalue { ptr, i32 } %12, 1
  store ptr %13, ptr %2, align 8
  %15 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %14, ptr %15, align 8
  br label %bb7

bb6:                                              ; preds = %bb4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %vector, i64 24, i1 false)
  ret void

terminate:                                        ; preds = %bb7
  %16 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb10:                                             ; preds = %bb7
  %17 = load i8, ptr %_12, align 1
  %18 = trunc nuw i8 %17 to i1
  br i1 %18, label %bb9, label %bb8

bb5:                                              ; preds = %bb2
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_8.0, ptr %_8.1, ptr align 8 @alloc_391673418deaa0b14b40e679e64fed1a) #25
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb8:                                              ; preds = %bb9, %bb10
  %19 = load ptr, ptr %2, align 8
  %20 = getelementptr inbounds i8, ptr %2, i64 8
  %21 = load i32, ptr %20, align 8
  %22 = insertvalue { ptr, i32 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i32 } %22, i32 %21, 1
  resume { ptr, i32 } %23

bb9:                                              ; preds = %bb10
  br label %bb8
}

; <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB6_3VecjEINtB4_18SpecFromIterNestedjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1F_5slice4iter4IterINtNtB8_5boxed3BoxDINtNtNtB1F_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE9from_iterB3P_(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !624 {
start:
  %2 = alloca [16 x i8], align 8
  %_12 = alloca [1 x i8], align 1
  %_3 = alloca [24 x i8], align 8
  %vector = alloca [24 x i8], align 8
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %3 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_12, align 1
  store i8 1, ptr %_12, align 1
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_5slice4iter4IterINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtBb_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0ENtNtNtB9_6traits8iterator8Iterator9size_hintB2G_(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %iterator) #21
  br label %bb1

bb1:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %_5 = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb3, label %bb2

bb3:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %upper = load i64, ptr %9, align 8
; call <alloc::vec::Vec<usize>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE13with_capacityCshXA3KcOxU02_8closures(ptr sret([24 x i8]) align 8 %vector, i64 %upper) #21
  br label %bb4

bb2:                                              ; preds = %bb1
; call <core::fmt::Arguments>::from_str
  %10 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshXA3KcOxU02_8closures(ptr @alloc_31365cfefba383c4d2bf6b6a04cc10aa, i64 17) #21
  %_8.0 = extractvalue { ptr, ptr } %10, 0
  %_8.1 = extractvalue { ptr, ptr } %10, 1
  br label %bb5

bb4:                                              ; preds = %bb3
  store i8 0, ptr %_12, align 1
  %_11.0 = load ptr, ptr %iterator, align 8
  %11 = getelementptr inbounds i8, ptr %iterator, i64 8
  %_11.1 = load ptr, ptr %11, align 8
; invoke <alloc::vec::Vec<usize> as alloc::vec::spec_extend::SpecExtend<usize, core::iter::adapters::map::Map<core::slice::iter::Iter<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>, closures::main::{closure#12}>>>::spec_extend
  invoke void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB6_3VecjEINtB4_10SpecExtendjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1n_5slice4iter4IterINtNtB8_5boxed3BoxDINtNtNtB1n_3ops8function2FnuEp6OutputjEL_EENCNvCshXA3KcOxU02_8closures4mainsa_0EE11spec_extendB3x_(ptr align 8 %vector, ptr %_11.0, ptr %_11.1)
          to label %bb6 unwind label %cleanup

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECshXA3KcOxU02_8closures(ptr align 8 %vector) #22
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4
  %12 = landingpad { ptr, i32 }
          cleanup
  %13 = extractvalue { ptr, i32 } %12, 0
  %14 = extractvalue { ptr, i32 } %12, 1
  store ptr %13, ptr %2, align 8
  %15 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %14, ptr %15, align 8
  br label %bb7

bb6:                                              ; preds = %bb4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %vector, i64 24, i1 false)
  ret void

terminate:                                        ; preds = %bb7
  %16 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb10:                                             ; preds = %bb7
  %17 = load i8, ptr %_12, align 1
  %18 = trunc nuw i8 %17 to i1
  br i1 %18, label %bb9, label %bb8

bb5:                                              ; preds = %bb2
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_8.0, ptr %_8.1, ptr align 8 @alloc_391673418deaa0b14b40e679e64fed1a) #25
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb8:                                              ; preds = %bb9, %bb10
  %19 = load ptr, ptr %2, align 8
  %20 = getelementptr inbounds i8, ptr %2, i64 8
  %21 = load i32, ptr %20, align 8
  %22 = insertvalue { ptr, i32 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i32 } %22, i32 %21, 1
  resume { ptr, i32 } %23

bb9:                                              ; preds = %bb10
  br label %bb8
}

; <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCshXA3KcOxU02_8closures(ptr align 8 %0) unnamed_addr #1 !guid !625 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
; call <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_3 = call i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenB8_(ptr align 8 %self)
  %_2 = icmp ugt i64 %_3, 0
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  %1 = load ptr, ptr %self, align 8
; call <core::ops::index_range::IndexRange>::next_unchecked
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCshXA3KcOxU02_8closures(ptr align 8 %1) #21
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>; 3] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitTReFddEdEEj3_NtB4_11PartialDrop12partial_dropCshXA3KcOxU02_8closures(ptr align 8 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #0 !guid !626 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<(&str, fn(f64, f64) -> f64)>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitTReFddEdEENtB2_11PartialDrop12partial_dropCshXA3KcOxU02_8closures(ptr align 8 %self, i64 3, i64 %alive.0, i64 %alive.1)
  ret void
}

; <core::slice::sort::stable::merge::MergeState<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB4_10MergeStatelENtNtNtBc_3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !627 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %_5 = load ptr, ptr %self, align 8
; call <*mut i32>::offset_from_unsigned
  %len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl20offset_from_unsignedCshXA3KcOxU02_8closures(ptr %_3, ptr %_5, ptr align 8 @alloc_4a07d64a21980758f07ef2afc3d73d2d) #21
  %_8 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_9 = load ptr, ptr %1, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCshXA3KcOxU02_8closures() #21
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

bb2.i:                                            ; preds = %start
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCshXA3KcOxU02_8closures(ptr %_8, ptr %_9, i64 4, i64 4, i64 %len, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECshXA3KcOxU02_8closures.exit: ; preds = %start, %bb2.i
  %2 = mul nuw nsw i64 %len, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_9, ptr align 4 %_8, i64 %2, i1 false)
  ret void
}

; <core::cmp::Ordering as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsb_NtCsl10jNU3mE6R_4core3cmpNtB5_8OrderingNtB5_9PartialEq2eqCshXA3KcOxU02_8closures(ptr %self, ptr %other) unnamed_addr #1 !guid !628 {
start:
  %__self_discr = load i8, ptr %self, align 1
  %__arg1_discr = load i8, ptr %other, align 1
  %_0 = icmp eq i8 %__self_discr, %__arg1_discr
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB9_3ops8function2FnuEp6OutputjEL_EENtNtB9_3cmp9PartialEq2eqCshXA3KcOxU02_8closures(ptr align 8 %self, ptr align 8 %other) unnamed_addr #1 !guid !629 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecINtNtB7_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EENtNtB13_4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !630 {
start:
; call <alloc::vec::Vec<alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecINtNtB6_5boxed3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB8_3ops8function2FnuEp6OutputjEL_E10cast_sliceCshXA3KcOxU02_8closures(ptr %_3, i64 %_4) #21
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
; call core::ptr::drop_glue::<[alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>>]>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSINtNtCs7CppTae75M1_5alloc5boxed3BoxDINtNtNtB4_3ops8function2FnuEp6OutputjEL_EECshXA3KcOxU02_8closures(ptr align 8 %_2.0, i64 %_2.1)
  ret void
}

; <alloc::vec::Vec<usize> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !631 {
start:
; call <alloc::vec::Vec<usize>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut usize>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOj10cast_sliceCshXA3KcOxU02_8closures(ptr %_3, i64 %_4) #21
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !632 {
start:
; call <alloc::vec::Vec<i32>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut i32>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl10cast_sliceCshXA3KcOxU02_8closures(ptr %_3, i64 %_4) #21
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCshXA3KcOxU02_8closures(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !633 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::vec::Vec<usize> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshXA3KcOxU02_8closures(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !634 {
start:
; call <alloc::vec::Vec<usize> as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshGsV4pNJ6ra_6object(ptr align 8 %self) #21
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[usize] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSjNtB5_5Debug3fmtCshXA3KcOxU02_8closures(ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::vec::Vec<i32> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCshXA3KcOxU02_8closures(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !635 {
start:
; call <alloc::vec::Vec<i32> as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[i32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCshXA3KcOxU02_8closures(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <[usize] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSjNtB5_5Debug3fmtCshXA3KcOxU02_8closures(ptr align 8 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #0 !guid !636 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[usize]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSj4iterB4_(ptr align 8 %self.0, i64 %self.1) #21
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&usize, core::slice::iter::Iter<usize>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRjINtNtNtBa_5slice4iter4IterjEECshXA3KcOxU02_8closures(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCshXA3KcOxU02_8closures(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #0 !guid !637 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[i32]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsddYV2PBJW9h_3std(ptr align 4 %self.0, i64 %self.1) #21
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECshXA3KcOxU02_8closures(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <i32 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXss_NtNtCsl10jNU3mE6R_4core3cmp5implslNtB7_9PartialEq2eqCshXA3KcOxU02_8closures(ptr align 4 %self, ptr align 4 %other) unnamed_addr #1 !guid !638 {
start:
  %_3 = load i32, ptr %self, align 4
  %_4 = load i32, ptr %other, align 4
  %_0 = icmp eq i32 %_3, %_4
  ret i1 %_0
}

; <alloc::boxed::Box<dyn core::ops::function::Fn<(i32,), Output = i32>> as core::ops::function::Fn<(i32,)>>::call
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvXsv_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnTlEEp6OutputlEL_EIBJ_B1o_E4callCshXA3KcOxU02_8closures(ptr align 8 %self, i32 %0) unnamed_addr #0 !guid !639 {
start:
  %args = alloca [4 x i8], align 4
  store i32 %0, ptr %args, align 4
  %_4.0 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %_4.1 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_4.1, i64 40
  %3 = load ptr, ptr %2, align 8, !invariant.load !283, !nonnull !283
  %4 = load i32, ptr %args, align 4
  %_0 = call i32 %3(ptr %_4.0, i32 %4) #21
  ret i32 %_0
}

; <alloc::boxed::Box<dyn core::ops::function::Fn<(), Output = usize>> as core::ops::function::Fn<()>>::call
; Function Attrs: nonlazybind uwtable
define internal i64 @_RNvXsv_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDINtNtNtCsl10jNU3mE6R_4core3ops8function2FnuEp6OutputjEL_EIBJ_uE4callCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #0 !guid !640 {
start:
  %args = alloca [0 x i8], align 1
  %_4.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4.1 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4.1, i64 40
  %2 = load ptr, ptr %1, align 8, !invariant.load !283, !nonnull !283
  %_0 = call i64 %2(ptr %_4.0) #21
  ret i64 %_0
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshXA3KcOxU02_8closures(ptr align 8 %self) unnamed_addr #1 !guid !641 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCshXA3KcOxU02_8closures(ptr align 8 %self) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshXA3KcOxU02_8closures(ptr %_1) unnamed_addr #1 !guid !642 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshXA3KcOxU02_8closures(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !643 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshXA3KcOxU02_8closures(ptr align 8 %_1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <closures::main::{closure#4}::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvYNCNCNvCshXA3KcOxU02_8closures4mains2_00INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceB8_(i64 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !644 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store i64 %0, ptr %_1, align 8
; call closures::main::{closure#4}::{closure#0}
  %_0 = call i64 @_RNCNCNvCshXA3KcOxU02_8closures4mains2_00B5_(ptr align 8 %_1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret i64 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <closures::main::{closure#8} as core::ops::function::FnOnce<(f64, f64)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvYNCNvCshXA3KcOxU02_8closures4mains6_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTddEE9call_onceB6_(double %0, double %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !645 {
start:
  %_2 = alloca [16 x i8], align 8
  %_1 = alloca [0 x i8], align 1
  store double %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store double %1, ptr %2, align 8
  %3 = load double, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load double, ptr %4, align 8
; call closures::main::{closure#8}
  %_0 = call double @_RNCNvCshXA3KcOxU02_8closures4mains6_0B3_(ptr %_1, double %3, double %5) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret double %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <closures::main::{closure#9} as core::ops::function::FnOnce<(f64, f64)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvYNCNvCshXA3KcOxU02_8closures4mains7_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTddEE9call_onceB6_(double %0, double %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !646 {
start:
  %_2 = alloca [16 x i8], align 8
  %_1 = alloca [0 x i8], align 1
  store double %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store double %1, ptr %2, align 8
  %3 = load double, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load double, ptr %4, align 8
; call closures::main::{closure#9}
  %_0 = call double @_RNCNvCshXA3KcOxU02_8closures4mains7_0B3_(ptr %_1, double %3, double %5) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret double %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <closures::main::{closure#11} as core::ops::function::FnOnce<(i32,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCNvCshXA3KcOxU02_8closures4mains9_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_onceB6_(i32 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !647 {
start:
  %_2 = alloca [4 x i8], align 4
  %_1 = alloca [0 x i8], align 1
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
; call closures::main::{closure#11}
  %_0 = call i32 @_RNCNvCshXA3KcOxU02_8closures4mains9_0B3_(ptr %_1, i32 %1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <closures::boxed::{closure#0} as core::ops::function::FnOnce<(i32,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCNvCshXA3KcOxU02_8closures5boxed0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_onceB6_(i32 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !648 {
start:
  %_2 = alloca [4 x i8], align 4
  %_1 = alloca [0 x i8], align 1
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
; call closures::boxed::{closure#0}
  %_0 = call i32 @_RNCNvCshXA3KcOxU02_8closures5boxed0B3_(ptr %_1, i32 %1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <closures::boxed::{closure#2} as core::ops::function::FnOnce<(i32,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCNvCshXA3KcOxU02_8closures5boxeds0_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_onceB6_(i32 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !649 {
start:
  %_2 = alloca [4 x i8], align 4
  %_1 = alloca [0 x i8], align 1
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
; call closures::boxed::{closure#2}
  %_0 = call i32 @_RNCNvCshXA3KcOxU02_8closures5boxeds0_0B3_(ptr %_1, i32 %1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <closures::boxed::{closure#1} as core::ops::function::FnOnce<(i32,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCNvCshXA3KcOxU02_8closures5boxeds_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTlEE9call_onceB6_(i32 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !650 {
start:
  %_2 = alloca [4 x i8], align 4
  %_1 = alloca [0 x i8], align 1
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
; call closures::boxed::{closure#1}
  %_0 = call i32 @_RNCNvCshXA3KcOxU02_8closures5boxeds_0B3_(ptr %_1, i32 %1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #6

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #0

; <core::slice::iter::Iter<usize> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterjENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBa_(ptr align 8) unnamed_addr #1

; <&usize as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRjNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #0

; <core::fmt::builders::DebugList>::entry
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8, ptr, ptr align 8) unnamed_addr #0

; <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #1

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::ptr::metadata::from_raw_parts_mut::<i32, ()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutluECsddYV2PBJW9h_3std(ptr) unnamed_addr #1

; core::ptr::drop_glue::<alloc::vec::set_len_on_drop::SetLenOnDrop>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtNtCs7CppTae75M1_5alloc3vec15set_len_on_drop12SetLenOnDropECsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #0

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; core::cmp::min::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64, i64) unnamed_addr #1

; core::cmp::max::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64, i64) unnamed_addr #1

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #9

; <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64, i64) unnamed_addr #1

; <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8) unnamed_addr #1

; core::slice::sort::shared::smallsort::panic_on_ord_violation
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort22panic_on_ord_violation() unnamed_addr #8

; <[usize; 2] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAjj2_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCshGsV4pNJ6ra_6object(ptr sret([32 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::array::iter::IntoIter<usize, 2> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterjKj2_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #1

; core::ptr::drop_glue::<core::array::iter::IntoIter<usize, 2>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterjKj2_EECshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #0

; core::slice::sort::stable::drift::sqrt_approx
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift11sqrt_approx(i64) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #10

; <core::num::nonzero::NonZero<usize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64) unnamed_addr #1

; <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try6branchCs7CppTae75M1_5alloc() unnamed_addr #1

; <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::from_output
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try11from_outputCs7CppTae75M1_5alloc() unnamed_addr #1

; <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCs7CppTae75M1_5alloc() unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #11

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #11

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #1

; <core::fmt::Arguments>::new::<6, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj6_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32) #11

; core::panicking::panic_const::panic_const_sub_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_neg_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_neg_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #1

; <core::ops::range::Range<u8> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { i8, i8 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangehENtB2_12IntoIterator9into_iterCsgE4ujGKm1Ln_11miniz_oxide(i8, i8) unnamed_addr #1

; <core::ops::range::Range<u8> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i1, i8 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangehENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr) unnamed_addr #1

; <str as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #7

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #7

; <core::fmt::rt::Argument>::new_display::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #1

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.pow.f64(double, double) #11

; <core::mem::maybe_dangling::MaybeDangling<i32>>::new
; Function Attrs: nonlazybind uwtable
declare i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCsddYV2PBJW9h_3std(i32) unnamed_addr #0

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #8

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #1

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #1

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #1

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8, i64, i64, i64, i64) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8, i64) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr, i64) unnamed_addr #1

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #13

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64, i64, i64) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::grow_one
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneB7_(ptr align 8, i64, i64) unnamed_addr #1

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #1

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.usub.sat.i64(i64, i64) #11

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #14

; <alloc::raw_vec::RawVec<usize>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE3ptrCshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #1

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #1

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #6

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #15

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #16

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #17

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #1

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #18

; core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_chunks::<8>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes26swap_nonoverlapping_chunksKj8_ECshGsV4pNJ6ra_6object(ptr, ptr, i64) unnamed_addr #0

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr) unnamed_addr #1

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #19

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #0

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #0

; core::ptr::swap_chunk::<4>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj4_ECshGsV4pNJ6ra_6object(ptr, ptr) unnamed_addr #1

; core::ptr::swap_chunk::<2>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj2_ECshGsV4pNJ6ra_6object(ptr, ptr) unnamed_addr #1

; core::ptr::swap_chunk::<1>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj1_ECshGsV4pNJ6ra_6object(ptr, ptr) unnamed_addr #1

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr, i64) unnamed_addr #1

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #19

; <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator9size_hintB9_(ptr sret([24 x i8]) align 8, ptr align 8) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8, i64, i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.scmp.i8.i32(i32, i32) #11

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
declare void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #0

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64, i64, i64, ptr align 8) unnamed_addr #8

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr) unnamed_addr #1

; <core::option::Option<i32>>::unwrap_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
declare i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE16unwrap_uncheckedCsddYV2PBJW9h_3std(i32, i32, ptr align 8) unnamed_addr #1

; <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenB8_(ptr align 8) unnamed_addr #0

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<usize> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <[usize]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSj4iterB4_(ptr align 8, i64) unnamed_addr #1

; <core::fmt::builders::DebugList>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8) unnamed_addr #0

; <[i32]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsddYV2PBJW9h_3std(ptr align 4, i64) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #20 !guid !651 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshXA3KcOxU02_8closures(ptr @_RNvCshXA3KcOxU02_8closures4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #10 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #13 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #14 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #20 = { nonlazybind "target-cpu"="x86-64" }
attributes #21 = { inlinehint }
attributes #22 = { cold }
attributes #23 = { cold noreturn nounwind }
attributes #24 = { inlinehint nounwind }
attributes #25 = { noinline noreturn }
attributes #26 = { noinline }
attributes #27 = { noreturn }
attributes #28 = { noinline noreturn nounwind }
attributes #29 = { nounwind }

!llvm.module.flags = !{!219, !220, !221, !222}
!llvm.ident = !{!223}

!0 = !{i64 5077852084141659222}
!1 = !{i64 -8087899929713221932}
!2 = !{i64 8299003840833641003}
!3 = !{i64 759230305336081008}
!4 = !{i64 2885752465915618238}
!5 = !{i64 -8985854857946768361}
!6 = !{i64 -5441502248871194658}
!7 = !{i64 7382406160851970224}
!8 = !{i64 769478986729229750}
!9 = !{i64 -3090202941413909653}
!10 = !{i64 3358371376315784329}
!11 = !{i64 -5008228524692341200}
!12 = !{i64 -7465815758366951034}
!13 = !{i64 2704384005921003042}
!14 = !{i64 -6456562960325731445}
!15 = !{i64 7013662199939576870}
!16 = !{i64 972571030494838855}
!17 = !{i64 6779083713738066544}
!18 = !{i64 3056689243967427709}
!19 = !{i64 3043325676223853267}
!20 = !{i64 -4403473838634263112}
!21 = !{i64 4165747141342775711}
!22 = !{i64 4972543565885820112}
!23 = !{i64 4654358241177132859}
!24 = !{i64 -1810172865118595582}
!25 = !{i64 1409274484143791819}
!26 = !{i64 -3729091365271287139}
!27 = !{i64 -3348635318791726114}
!28 = !{i64 -3319196917123981824}
!29 = !{i64 -2289853499146652946}
!30 = !{i64 5424680155270452399}
!31 = !{i64 6925296796615837578}
!32 = !{i64 8957515903630340315}
!33 = !{i64 -4037297790976563429}
!34 = !{i64 -1715833825663665122}
!35 = !{i64 7530501483031543797}
!36 = !{i64 -537473251828818520}
!37 = !{i64 -7521058413630073016}
!38 = !{i64 7728858992016317033}
!39 = !{i64 -9120569344904234193}
!40 = !{i64 5218591632675205794}
!41 = !{i64 -6960368568956297059}
!42 = !{i64 4114685246037196451}
!43 = !{i64 7882014380531315686}
!44 = !{i64 -9065402563838359763}
!45 = !{i64 -3171437050335856499}
!46 = !{i64 6831025512185487296}
!47 = !{i64 -3447481922439928440}
!48 = !{i64 926141928991213681}
!49 = !{i64 -1341933257295726152}
!50 = !{i64 -4623900239061405641}
!51 = !{i64 1888522049289951918}
!52 = !{i64 -1901358925134688218}
!53 = !{i64 6836408328405124975}
!54 = !{i64 4813376429806788131}
!55 = !{i64 4149115351282637589}
!56 = !{i64 -9086304877825961791}
!57 = !{i64 7193776995076540060}
!58 = !{i64 -2532285480564436676}
!59 = !{i64 3249882526406885039}
!60 = !{i64 -8570556294689148514}
!61 = !{i64 904504549951831917}
!62 = !{i64 4781201163311781837}
!63 = !{i64 6364658711456026689}
!64 = !{i64 5478707640364246222}
!65 = !{i64 -6752547449859980497}
!66 = !{i64 -6289645617114193481}
!67 = !{i64 -1527413138370337764}
!68 = !{i64 9198179492559153120}
!69 = !{i64 4931873715265630499}
!70 = !{i64 -1892255240991887452}
!71 = !{i64 -5645735822001907680}
!72 = !{i64 -4651137498803204143}
!73 = !{i64 -8083262281283633933}
!74 = !{i64 -363874195075783889}
!75 = !{i64 -546831075410871123}
!76 = !{i64 3214261782433128735}
!77 = !{i64 -2263576615188904075}
!78 = !{i64 112372963904593342}
!79 = !{i64 -521218651862106405}
!80 = !{i64 -4539522104316097299}
!81 = !{i64 -7602266226027032877}
!82 = !{i64 -1680466605948756009}
!83 = !{i64 5564171864749329547}
!84 = !{i64 7042040474619968987}
!85 = !{i64 3404622219541657204}
!86 = !{i64 -4583574751208470225}
!87 = !{i64 -4405396179217595470}
!88 = !{i64 -5253832427327960879}
!89 = !{i64 -2606499153134856899}
!90 = !{i64 1487075388438001098}
!91 = !{i64 -837998908087000938}
!92 = !{i64 5859415439197392000}
!93 = !{i64 -9077859584582020791}
!94 = !{i64 -6902377330295381891}
!95 = !{i64 -3503329129013383919}
!96 = !{i64 -2131708467738456156}
!97 = !{i64 -1423585236567958192}
!98 = !{i64 -4943220418274230201}
!99 = !{i64 3679597183604434461}
!100 = !{i64 -2476807868901925603}
!101 = !{i64 -6933426149365542803}
!102 = !{i64 1700367823389150048}
!103 = !{i64 -3073090554486852334}
!104 = !{i64 6634798143648059783}
!105 = !{i64 -4703672683221103110}
!106 = !{i64 -4616739972004222967}
!107 = !{i64 6139117732307976663}
!108 = !{i64 6668433661301415195}
!109 = !{i64 7500004431394430956}
!110 = !{i64 -6813701158307775888}
!111 = !{i64 3997932290616532996}
!112 = !{i64 7154665847547543251}
!113 = !{i64 -5283028696283016023}
!114 = !{i64 6881363260168709187}
!115 = !{i64 -1620514515035861233}
!116 = !{i64 4705821835949534608}
!117 = !{i64 -300450108195212888}
!118 = !{i64 -7616447900025201065}
!119 = !{i64 1906914123861988843}
!120 = !{i64 -5078868410417141372}
!121 = !{i64 -8150527774663545688}
!122 = !{i64 -8630058831810146670}
!123 = !{i64 -4183458275376930463}
!124 = !{i64 1839072366137676660}
!125 = !{i64 3897190477291779198}
!126 = !{i64 -7199683065556951999}
!127 = !{i64 -7144178794338047936}
!128 = !{i64 -690819378626975345}
!129 = !{i64 771204027606497748}
!130 = !{i64 -7671568750192363031}
!131 = !{i64 6780801600329031225}
!132 = !{i64 -1197584302487823239}
!133 = !{i64 3827720446176670153}
!134 = !{i64 -8221838377219953871}
!135 = !{i64 -680007305080016840}
!136 = !{i64 7961068038164476321}
!137 = !{i64 6358265710539734236}
!138 = !{i64 -6612539620846275615}
!139 = !{i64 -1564947579611701712}
!140 = !{i64 -6548026917914300991}
!141 = !{i64 4416695272657889995}
!142 = !{i64 -6732313690447400414}
!143 = !{i64 -3955438691056050673}
!144 = !{i64 -8761877185573868180}
!145 = !{i64 -1069426554387576809}
!146 = !{i64 5733771427153943936}
!147 = !{i64 3169457329851958186}
!148 = !{i64 -2785471683648589973}
!149 = !{i64 -3085248123618716981}
!150 = !{i64 -7910551398710565416}
!151 = !{i64 -2005473772155132620}
!152 = !{i64 -2720411314879016803}
!153 = !{i64 2335545646657464072}
!154 = !{i64 3891696698895612067}
!155 = !{i64 1407949411944300117}
!156 = !{i64 4224805485084794537}
!157 = !{i64 5859856076225781711}
!158 = !{i64 -307826009297391884}
!159 = !{i64 5507497831295173425}
!160 = !{i64 159106405139975413}
!161 = !{i64 4171027250969859879}
!162 = !{i64 -6103593030609779187}
!163 = !{i64 4555201407852838849}
!164 = !{i64 -1741819431286589231}
!165 = !{i64 3880855857961872326}
!166 = !{i64 3166511285077792554}
!167 = !{i64 3766297996309115632}
!168 = !{i64 1284859564422031389}
!169 = !{i64 -8331516927750086706}
!170 = !{i64 -9087488405484923154}
!171 = !{i64 4247834337194695112}
!172 = !{i64 4858542206365900041}
!173 = !{i64 -8539049949276891347}
!174 = !{i64 3664846755601267128}
!175 = !{i64 -2973136508974484995}
!176 = !{i64 1200404430925765719}
!177 = !{i64 -7481726372634968268}
!178 = !{i64 5074531367238607896}
!179 = !{i64 1776426665888035444}
!180 = !{i64 -5517050473555886983}
!181 = !{i64 5944448676807520769}
!182 = !{i64 9194036226048762232}
!183 = !{i64 -875124397169262234}
!184 = !{i64 5319424480667801038}
!185 = !{i64 -3348724069437796719}
!186 = !{i64 4281394116280766528}
!187 = !{i64 -6157707294598521300}
!188 = !{i64 6260093651685985326}
!189 = !{i64 6199720107004847806}
!190 = !{i64 8879486519771786508}
!191 = !{i64 -6501677988167731539}
!192 = !{i64 -4666657014713697595}
!193 = !{i64 -2267478415022621628}
!194 = !{i64 -2494181877056549162}
!195 = !{i64 -3315272884921866028}
!196 = !{i64 -3782878465700268150}
!197 = !{i64 -7916987781207882983}
!198 = !{i64 -7487693144075018643}
!199 = !{i64 7509160460270235284}
!200 = !{i64 -6898859348330255189}
!201 = !{i64 3248211585018562143}
!202 = !{i64 -3693435415866444064}
!203 = !{i64 1102473370431120398}
!204 = !{i64 2654238569257028002}
!205 = !{i64 -4565065950505394353}
!206 = !{i64 4977321884260569082}
!207 = !{i64 7475718239395861448}
!208 = !{i64 2055046306758968481}
!209 = !{i64 -5851240058367967124}
!210 = !{i64 6391277547069599145}
!211 = !{i64 6330007689960312352}
!212 = !{i64 7942979428949059368}
!213 = !{i64 1065843521872105452}
!214 = !{i64 3541589822068397678}
!215 = !{i64 -212023969722221955}
!216 = !{i64 4006894722791682279}
!217 = !{i64 -4598005448914535589}
!218 = !{i64 243126072842556548}
!219 = !{i32 8, !"PIC Level", i32 2}
!220 = !{i32 7, !"PIE Level", i32 2}
!221 = !{i32 2, !"RtLibUseGOT", i32 1}
!222 = !{i32 7, !"uwtable", i32 2}
!223 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!224 = !{i64 -1942654468169932303}
!225 = !{i64 -6489303827422399450}
!226 = !{i64 -8741566495073361620}
!227 = !{i64 4174003797133521055}
!228 = !{i64 -4733941842231495922}
!229 = !{i64 -1758546772206638053}
!230 = !{i64 3807803475012399941}
!231 = !{i64 -7271108099810378524}
!232 = !{i64 7521515011854077778}
!233 = !{i64 3592150926726332371}
!234 = !{i64 -4291045145562711009}
!235 = !{i64 -6290461193508223935}
!236 = !{i64 7795718931480759596}
!237 = !{i64 -4627050297095943168}
!238 = !{i64 -3413562541712471191}
!239 = !{i64 -9218970124766546464}
!240 = !{i64 -1719260371735438792}
!241 = !{i64 4655837789831426212}
!242 = !{i64 3037600258660655896}
!243 = !{i64 -2596503481716089477}
!244 = !{i64 9178625959201420144}
!245 = !{i64 -3538486451479361229}
!246 = !{i64 -73646800815071845}
!247 = !{i64 5243838650612264981}
!248 = !{i64 650409848537788693}
!249 = !{i64 67435622271156551}
!250 = !{i64 1804952400512226263}
!251 = !{i64 -648815671977219719}
!252 = !{i64 6566282264195396876}
!253 = !{i64 -2693138779009223816}
!254 = !{i64 1848627182181571975}
!255 = !{i64 -1646764334766286592}
!256 = !{i64 7629731371801078934}
!257 = !{i64 9119004258760321187}
!258 = !{i64 -3914801665741186794}
!259 = !{i64 8175055252386714852}
!260 = !{i64 -2155170183172118019}
!261 = !{i64 -4672799679363624982}
!262 = !{i64 7440591254589203594}
!263 = !{i64 6477696139413339189}
!264 = !{i64 6329483014436862085}
!265 = !{i64 -5305358522059405849}
!266 = !{i64 1308779820001700527}
!267 = !{i64 -7487659290905910154}
!268 = !{i64 6070958358080789405}
!269 = !{i64 635595383708619698}
!270 = !{!"address", !"read_provenance"}
!271 = !{i64 -2012401482010409990}
!272 = !{i64 -2131725582144737939}
!273 = !{i64 -4326051119338272942}
!274 = !{i64 6655960367561446586}
!275 = !{i64 8698352254066726519}
!276 = !{i64 -811377220728746510}
!277 = !{i64 -1803929854359426252}
!278 = !{i64 6460350757760864268}
!279 = !{i64 -3621276934730325685}
!280 = !{i64 -4747393765590837264}
!281 = !{i64 -1748455928311685190}
!282 = !{i64 -346890418927766667}
!283 = !{}
!284 = !{i64 1801041921646414563}
!285 = !{i64 -7795591768857386374}
!286 = !{i64 -6752374704314182527}
!287 = !{i64 8094002355193006345}
!288 = !{i64 -4760010514826074520}
!289 = !{i64 4506490930579560698}
!290 = !{i64 4612031424038225715}
!291 = !{i64 -4850413100160581060}
!292 = !{i64 8670266591026595870}
!293 = !{i64 3787942686450099713}
!294 = !{i64 -113735597328324660}
!295 = !{i64 -3393273098525633173}
!296 = !{i64 -560776216196383716}
!297 = !{i64 -8228559736258820573}
!298 = !{i64 -4391361287686907537}
!299 = !{i64 4892122866614628234}
!300 = !{i64 2679504096811696991}
!301 = !{i64 -8944322622101623566}
!302 = !{i64 -8571190262310041635}
!303 = !{i64 -5943617617284214713}
!304 = !{i64 8045802802579874639}
!305 = !{i64 2641562137461385454}
!306 = !{i64 1833169401808705523}
!307 = !{i64 7484535979422904780}
!308 = !{i64 -5744169007066581809}
!309 = !{i64 48781379769178430}
!310 = !{i64 9217585547755031285}
!311 = !{i64 563274730066886958}
!312 = !{i64 -1190453604823110516}
!313 = !{i64 1920254648658826253}
!314 = !{i64 -72283727781457500}
!315 = !{i64 -3169345997030478289}
!316 = !{i64 -3507993946040268736}
!317 = !{i64 713314691056160181}
!318 = !{i64 -7193392337711530151}
!319 = !{i64 -7980195695900887550}
!320 = !{i64 -5761609622086766818}
!321 = !{i64 -8477796169422341397}
!322 = !{i64 -8429121720100361935}
!323 = !{i64 198682796751373686}
!324 = !{i64 1320272947097765}
!325 = !{i64 -759219029023372760}
!326 = !{i64 -3860813397731639074}
!327 = !{i64 -9071071056323173453}
!328 = !{i64 4304061928979787508}
!329 = !{i64 8822192850649316573}
!330 = !{i64 -436987588003858980}
!331 = !{i64 5265585292260370010}
!332 = !{i64 1720260340271473334}
!333 = !{i64 848786362840824659}
!334 = !{i64 4757180002109380293}
!335 = !{i64 8582322635162422486}
!336 = !{i64 889385283297904767}
!337 = !{i64 9037683858277838283}
!338 = !{i64 3985964849923083020}
!339 = !{i64 6212082734123029934}
!340 = !{i64 -2110473385237451469}
!341 = !{i64 6306976123066621905}
!342 = !{i64 8073922863554298539}
!343 = !{i64 1781871661423712689}
!344 = !{i64 -3230438977224881706}
!345 = !{i64 8809870715318276153}
!346 = !{i64 -7130934161685473875}
!347 = !{i64 -8906399358861197986}
!348 = !{i64 -8084481403810057841}
!349 = !{i64 -5618174821814716101}
!350 = !{i64 -1084542609094558675}
!351 = !{i64 5681550953458505842}
!352 = !{i64 -8556214301299664880}
!353 = !{i64 -8057807259157815765}
!354 = !{i64 -1856658018841325871}
!355 = !{i64 -1259242170289529627}
!356 = !{i64 5004232192227552220}
!357 = !{i64 8437027343283442144}
!358 = !{i64 -3514805222641084059}
!359 = !{i64 -4706569163052495967}
!360 = !{i64 -1988760117579343617}
!361 = !{i64 6059906834952284167}
!362 = !{i64 -4572195136249303656}
!363 = !{i64 1855703733468032450}
!364 = !{i64 -942464032146484978}
!365 = !{i64 7560291583377429904}
!366 = !{i64 7156892029792382718}
!367 = !{i64 5860574997706587276}
!368 = !{i64 -7355197178269206730}
!369 = !{i64 -949315387016304416}
!370 = !{i64 3095104392169555564}
!371 = !{i64 -6590587803928128337}
!372 = !{i64 -1739244703586863}
!373 = !{i64 8357482727418673505}
!374 = !{i64 -4927376820568809401}
!375 = !{i64 -8748281606381905212}
!376 = !{i64 1951174987010412253}
!377 = !{i64 -7463695010964277308}
!378 = !{i64 8364427290864049664}
!379 = !{i64 -6802631713460011435}
!380 = !{i64 -648150825654427368}
!381 = !{i64 -797888033584260652}
!382 = !{i64 -6523901012044803282}
!383 = !{i64 4300540650510129518}
!384 = !{i64 1025312142601172843}
!385 = !{i64 -49101555968385437}
!386 = !{i64 -2744015054733681185}
!387 = !{i64 3109207151987130108}
!388 = !{i64 -1546551522514046194}
!389 = !{i64 7624925766853871903}
!390 = !{i64 -2222624312647771696}
!391 = !{i64 -134549088916420291}
!392 = !{i64 -6382476418637052574}
!393 = !{i64 -2210389941328710488}
!394 = !{i64 -6881231784750778380}
!395 = !{i64 6582865704565481822}
!396 = !{i64 3797958440995658361}
!397 = !{i64 763290315370991087}
!398 = !{i64 2693775367307393131}
!399 = !{i64 -7263951085506627610}
!400 = !{i64 -6302648949429040405}
!401 = !{i64 -1512583677320172682}
!402 = !{i64 6360817078188756466}
!403 = !{i64 4212893116489977136}
!404 = !{i64 369480197846942519}
!405 = !{i64 3558892194801823323}
!406 = !{i64 -2899143448514519578}
!407 = !{i64 -3249530789621993865}
!408 = !{i64 -5760192774629304999}
!409 = !{i64 4381322288570498142}
!410 = !{i64 -3138128730805903419}
!411 = !{i64 -2003172252440883254}
!412 = !{i64 5949465027529969127}
!413 = !{i64 -8598958341444837898}
!414 = !{i64 9109021181627658251}
!415 = !{i64 6984853718448932590}
!416 = !{i64 -3373628337164872745}
!417 = !{i64 -2463485044217394261}
!418 = !{i64 -1458476717858587887}
!419 = !{i64 8342046107022514064}
!420 = !{i64 -4509456475177234556}
!421 = !{i64 8561766915759376605}
!422 = !{i64 2098697082940874937}
!423 = !{i64 -6288719144848401359}
!424 = !{i64 -4136261350854945240}
!425 = !{i64 5130838954691082947}
!426 = !{i64 -7466893285909786817}
!427 = !{i64 9000471149367611291}
!428 = !{i64 -7967628952929424601}
!429 = !{i64 5847467989962372116}
!430 = !{i64 2430562583553172630}
!431 = !{i64 -1599570341823506968}
!432 = !{i64 -2932881450486229436}
!433 = !{i64 -7274477393420801391}
!434 = !{i64 -1846668406444343995}
!435 = !{i64 -6146991244001640863}
!436 = !{i64 4168438210163112223}
!437 = !{i64 8089548185523797266}
!438 = !{i64 -1238952142408982916}
!439 = !{i64 1648832883666674748}
!440 = !{i64 4338617983739077889}
!441 = !{i64 2248663548588266930}
!442 = !{i64 7962888966237869079}
!443 = !{i64 620145043981198558}
!444 = !{i64 -479605226789655941}
!445 = !{i64 477450314150632832}
!446 = !{i64 4076401182264687137}
!447 = !{i64 -1286806866940482424}
!448 = !{i64 357687080554345996}
!449 = !{i64 4860796885854642372}
!450 = !{i64 7450015137692689428}
!451 = !{i64 7250293692638451912}
!452 = !{i64 -3458794940488621773}
!453 = !{i64 -3031757527655733213}
!454 = !{i64 -1847411837360279283}
!455 = !{i64 -1332707130276564209}
!456 = !{i64 -9047479992457011258}
!457 = !{i64 5869981814492135492}
!458 = !{i64 -7937591008935863968}
!459 = !{i64 1793400273084791603}
!460 = !{i64 418427376122795246}
!461 = !{i64 -9096324498526186055}
!462 = !{i64 -3282584057939659079}
!463 = !{i64 6566608692434161622}
!464 = !{i64 4648511212614374767}
!465 = !{i64 1689650101535818211}
!466 = !{i64 141014163156864937}
!467 = !{i64 257389247350703217}
!468 = !{i64 -4699736804225695594}
!469 = !{i64 823821328120688975}
!470 = !{i64 -6896640840310973149}
!471 = !{i64 7156573990923898591}
!472 = !{i64 5479363788358300562}
!473 = !{i64 -8002028989395135514}
!474 = !{i64 4048102996315916693}
!475 = !{i64 8766320847494103780}
!476 = !{i64 -3005238459345791427}
!477 = !{i64 6424406718841733455}
!478 = !{i64 6249248888237390374}
!479 = !{i64 -5618447619597879159}
!480 = !{i64 7970960842725367568}
!481 = !{i64 4986481604286845943}
!482 = !{i64 8428787196974870580}
!483 = !{i64 8722293855444615166}
!484 = !{i64 -5989957335794275205}
!485 = !{i64 7814373305420981593}
!486 = !{i64 -5388805267195652366}
!487 = !{i64 -4714152272447296125}
!488 = !{i64 1999757856333288309}
!489 = !{i64 6862247468035422950}
!490 = !{i64 8947326734680404016}
!491 = !{i64 -8848923226898265614}
!492 = !{i64 -2905507708297537198}
!493 = !{i64 3975060919193393189}
!494 = !{i64 -1762610648478108075}
!495 = !{i64 -329439453166729705}
!496 = !{i64 3832648470126528224}
!497 = !{i64 -3594210300361077918}
!498 = !{i64 5763850344319678611}
!499 = !{i64 3709154031892896865}
!500 = !{i64 -5712906316053775193}
!501 = !{i64 -7550744250089094924}
!502 = !{i64 -2714481775231742110}
!503 = !{i64 -7941814733973311635}
!504 = !{i64 4838940672746232572}
!505 = !{i64 2204162814831529387}
!506 = !{i64 -5985655025696595433}
!507 = !{i64 -8487781711015712138}
!508 = !{i64 7900017515711087059}
!509 = !{i64 -249293486501545054}
!510 = !{i64 4632861305464678891}
!511 = !{i64 1380840706080589040}
!512 = !{i64 2700460973256771280}
!513 = !{i64 -6705331257925904675}
!514 = !{i64 550254384067026237}
!515 = !{i64 2408245721105492429}
!516 = !{i64 -6516240075380283175}
!517 = !{i64 625804515344841480}
!518 = !{i64 391091345423584024}
!519 = !{i64 4657956823316645693}
!520 = !{i64 -8407030337704252441}
!521 = !{i64 7330440866994909573}
!522 = !{i64 6147040558931049762}
!523 = !{i64 -4895575937857039825}
!524 = !{i64 1771698379993948479}
!525 = !{i64 -6926192768665737468}
!526 = !{i64 234248455458136587}
!527 = !{i64 1429291778298027650}
!528 = !{i64 4835853044344110126}
!529 = !{i64 -8754401481551067193}
!530 = !{i64 3484255799735249072}
!531 = !{i64 263461508004590323}
!532 = !{i64 -1157973385736262534}
!533 = !{i64 -2873772929656492308}
!534 = !{i64 -7096926552612839328}
!535 = !{i64 -4315576503209884676}
!536 = !{i64 -1347753311726881366}
!537 = !{i64 -826958975609754100}
!538 = !{i64 -1776862223431849057}
!539 = !{i64 -6900785419126318763}
!540 = !{i64 6291208462942535153}
!541 = !{i64 2316131383360329097}
!542 = !{i64 -8661587314428884304}
!543 = !{i64 -2762708175549343806}
!544 = !{i64 8397989975791602034}
!545 = !{i64 -538135558639043653}
!546 = !{i64 -1244376705560272127}
!547 = !{i64 1833665874787713594}
!548 = !{i64 51397869311092898}
!549 = !{i64 5825739609204877665}
!550 = !{i64 3842302099125885246}
!551 = !{i64 7276691802424342767}
!552 = !{i64 -9172462947195468607}
!553 = !{i64 5773730522073449491}
!554 = !{i64 -815484977616850739}
!555 = !{i64 9175045439047759258}
!556 = !{i64 5907293805136934945}
!557 = !{i64 -8986278667025033790}
!558 = !{i64 -6136913279246552249}
!559 = !{i64 7640621580046652130}
!560 = !{i64 -233247280277067073}
!561 = !{i64 -6675844845805306575}
!562 = !{i64 -3252290020080699588}
!563 = !{i64 7611935047412981326}
!564 = !{i64 -3857933674410615217}
!565 = !{i64 4503217546527854569}
!566 = !{i64 -5997969008178320315}
!567 = !{i64 -2678457016761529241}
!568 = !{i64 -7734924241418791313}
!569 = !{i64 -244937595774335180}
!570 = !{i64 5250161641425345033}
!571 = !{i64 9028317007967945965}
!572 = !{i64 1287211972594162023}
!573 = !{i64 2408933234679794270}
!574 = !{i64 -6509074277420214058}
!575 = !{i64 -5555275242736999935}
!576 = !{i64 -6082369396669353510}
!577 = !{i64 8457949355309461482}
!578 = !{i64 -4760488017992482010}
!579 = !{i64 589557909557244787}
!580 = !{i64 -2649194286725166877}
!581 = !{i64 -5835001583165349800}
!582 = !{i64 -1770015778496122318}
!583 = !{i64 6462316514577931240}
!584 = !{i64 7848152820011004955}
!585 = !{i64 7331759465371156426}
!586 = !{i64 1014421922628243268}
!587 = !{i64 -6755149762855508917}
!588 = !{i64 -5086497004948248604}
!589 = !{i64 -1234879650263940926}
!590 = !{i64 8794652582974643567}
!591 = !{i64 -7837067000368108728}
!592 = !{i64 -7642090851177953535}
!593 = !{i64 6691078446005706041}
!594 = !{i64 -6227659133708948451}
!595 = !{i64 -1911677426643848211}
!596 = !{i64 6978128534382244760}
!597 = !{i64 339553408493508049}
!598 = !{i64 -4906517696609625459}
!599 = !{i64 3633153379619025952}
!600 = !{i64 -8347340584576862751}
!601 = !{i64 -5330281989571395330}
!602 = !{i64 -3684732595560665511}
!603 = !{i64 2214512391879603071}
!604 = !{i64 8652708235128929592}
!605 = !{i64 -6467931233111162665}
!606 = !{i64 -1241135786041783130}
!607 = !{i64 -4206520603222814210}
!608 = !{i64 2538087269939475518}
!609 = !{i64 3904696400063037574}
!610 = !{i64 5971660672295855144}
!611 = !{i64 -1068646854253587005}
!612 = !{i64 8899151656444219703}
!613 = !{i64 -8598797014331895430}
!614 = !{i64 -6229657449359035232}
!615 = !{i64 -7871943556326448627}
!616 = !{i64 5303356105422543204}
!617 = !{i64 -7811177988270103382}
!618 = !{i64 -3588068575755541756}
!619 = !{i64 -7316267706511625565}
!620 = !{i64 5429867819239118918}
!621 = !{i64 -3464478511189384509}
!622 = !{i64 -4517701342104281817}
!623 = !{i64 -439357666429999676}
!624 = !{i64 -4573112969771750815}
!625 = !{i64 -8242519147453998828}
!626 = !{i64 1752885328699553536}
!627 = !{i64 7640885696170819215}
!628 = !{i64 1164947339758236972}
!629 = !{i64 -4917918747662284496}
!630 = !{i64 3006824586715563523}
!631 = !{i64 -7130517473395590428}
!632 = !{i64 -7932418578181229038}
!633 = !{i64 1985431767772487586}
!634 = !{i64 -7221365553797692883}
!635 = !{i64 4187962268419887061}
!636 = !{i64 279715120263701488}
!637 = !{i64 4400269206910464431}
!638 = !{i64 -7970731593081786195}
!639 = !{i64 -2948879122304501078}
!640 = !{i64 671138675762781665}
!641 = !{i64 -553047807642183713}
!642 = !{i64 -8554790782743216367}
!643 = !{i64 1609540421243130200}
!644 = !{i64 -3831222450773101897}
!645 = !{i64 -3846564270314270552}
!646 = !{i64 -7483084060212219356}
!647 = !{i64 -2898087330553432640}
!648 = !{i64 -9067408122728715495}
!649 = !{i64 -2126010159520831122}
!650 = !{i64 -3720072054714429371}
!651 = !{i64 -2624081020897602054}
