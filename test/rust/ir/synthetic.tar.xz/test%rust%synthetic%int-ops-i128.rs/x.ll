; ModuleID = 'int_ops_i128.dc2fb72df8f264e3-cgu.0'
source_filename = "int_ops_i128.dc2fb72df8f264e3-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsiU2UAVuqdYR_12int_ops_i128, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsiU2UAVuqdYR_12int_ops_i128, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsiU2UAVuqdYR_12int_ops_i128 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !3
@alloc_8ef33618ae8ccb51a896393da2a634dc = private unnamed_addr constant [4 x i8] c"\80\00\00\00", align 4, !guid !4
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !5
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !7
@alloc_66dd7d140c45fc11c0f98c7ae6048d62 = private unnamed_addr constant [36 x i8] c"test/rust/synthetic/int-ops-i128.rs\00", align 1, !guid !8
@alloc_9695c38ea34c2ac142a4f080a3b02a60 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_66dd7d140c45fc11c0f98c7ae6048d62, [16 x i8] c"#\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !9
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !10
@alloc_e316ba92980127ac84bf97586df7c910 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_66dd7d140c45fc11c0f98c7ae6048d62, [16 x i8] c"#\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !11
@alloc_2e6b052c42f8b8d426c0e7fd41caa964 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_66dd7d140c45fc11c0f98c7ae6048d62, [16 x i8] c"#\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !12
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !13
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !14
@alloc_df4a957ad1e30b2d28834f15b5b475f2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_66dd7d140c45fc11c0f98c7ae6048d62, [16 x i8] c"#\00\00\00\00\00\00\00\1A\00\00\00\1B\00\00\00" }>, align 8, !guid !15
@alloc_a069ea0994ebdb507669c3afe067af56 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_66dd7d140c45fc11c0f98c7ae6048d62, [16 x i8] c"#\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !16
@alloc_01e34181d0e442b37ac13d5382f4d462 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_66dd7d140c45fc11c0f98c7ae6048d62, [16 x i8] c"#\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !17
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !18
@alloc_bfce3a1a97a4440398b4f99aa3b8a6fa = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_66dd7d140c45fc11c0f98c7ae6048d62, [16 x i8] c"#\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !19
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !20
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !21
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !22
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !23
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !24
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !25
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !26
@alloc_d60754359a0b1c5bd37a3b37b82a8a1d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\DF\01\00\00\05\00\00\00" }>, align 8, !guid !27
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !28
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !29
@alloc_c2df0f2eed0ee910e76dda7517cc7a45 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\05\00\00\05\00\00\00" }>, align 8, !guid !30
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !31
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !32
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !33
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !34
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !35
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !36
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !37
@anon.9957a1d51e1f25d58a58fc56d761d36e.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !38
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !39
@alloc_dd07830ff498a5ad3af27fc9310868e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E5\00\00\00\12\00\00\00" }>, align 8, !guid !40
@alloc_73a63def61abd19c5b285b7e5bba6f74 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E6\00\00\00\05\00\00\00" }>, align 8, !guid !41
@alloc_c9c619c258f652778f0098fbdacd3593 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F1\00\00\00\12\00\00\00" }>, align 8, !guid !42
@alloc_debe392282102e1a17f340d9b53f07df = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F2\00\00\00\12\00\00\00" }>, align 8, !guid !43
@alloc_d1e64d3a180065bd6a022925cad00717 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F3\00\00\00\05\00\00\00" }>, align 8, !guid !44
@alloc_9a4d1999757609695fb8537fcdec871b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FE\00\00\00\12\00\00\00" }>, align 8, !guid !45
@alloc_ffea377e021bf2f87b4ad4aac9bcd041 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FF\00\00\00\12\00\00\00" }>, align 8, !guid !46
@alloc_3410a5a3f8bc9abd6709ddad50da91f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\00\01\00\00\12\00\00\00" }>, align 8, !guid !47
@alloc_cb646754bd05cd238e749888201337e6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\01\01\00\00\05\00\00\00" }>, align 8, !guid !48
@alloc_eda7b11e07c58ae313ac1fad01d041e9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\0C\01\00\00\12\00\00\00" }>, align 8, !guid !49
@alloc_6042291b1954087ab71387f1f17f0449 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\0D\01\00\00\12\00\00\00" }>, align 8, !guid !50
@alloc_ce4d3b1f48911fd97fc8507578e88cdb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\0E\01\00\00\12\00\00\00" }>, align 8, !guid !51
@alloc_2a09b92e9319e8cf7ffdc293d51a865d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\0F\01\00\00\12\00\00\00" }>, align 8, !guid !52
@alloc_cdc8401a47de3b375010692dbb496696 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\10\01\00\00\05\00\00\00" }>, align 8, !guid !53
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !54
@alloc_a61ecf1bbb59a9a75a6a223b3f565d28 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: i128::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !55
@alloc_cbb3b5e3f39ac9cfe0752e276da07645 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: i128::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !56
@alloc_8889105080bbd684fa4b755988461744 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: u128::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !57
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !58
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRnNtB6_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128 }>, align 8, !guid !59
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128 }>, align 8, !guid !60
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !61
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !62
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !63
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !64
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !65
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !66
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !67
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128 }>, align 8, !guid !68

; <str>::parse::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsenECsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !74 {
start:
; call <i128 as core::str::traits::FromStr>::from_str
  call void @_RNvXss_NtCsl10jNU3mE6R_4core3numnNtNtNtB7_3str6traits7FromStr8from_strCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, ptr %self.0, i64 %self.1) #17
  ret void
}

; <core::fmt::rt::Argument>::new_binary::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !75 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsH_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !76 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !77 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !78 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 4 %x) #17
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !79 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !80 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexnECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !81 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexnECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !82 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !83 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i128>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionnEE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<core::option::Option<i128>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionnEE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionnENtNtB7_3fmt5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i128, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultnNtNtNtB7_3num5error13ParseIntErrorEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !84 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultnNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultnNtNtNtBa_3num5error13ParseIntErrorEE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultnNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(i128, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTnbEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !85 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(i128, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTnbEE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<(i128, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTnbEE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTnbENtB6_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !86 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalnECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !87 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %x) #17
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsJ_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::option::Option<i128>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionnEE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %self) unnamed_addr #0 !guid !88 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultnNtNtNtBa_3num5error13ParseIntErrorEE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %self) unnamed_addr #0 !guid !89 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<(i128, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTnbEE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %self) unnamed_addr #0 !guid !90 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %self) unnamed_addr #0 !guid !91 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %self) unnamed_addr #0 !guid !92 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %self) unnamed_addr #0 !guid !93 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECsiU2UAVuqdYR_12int_ops_i128(ptr %self) unnamed_addr #0 !guid !94 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsiU2UAVuqdYR_12int_ops_i128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !95 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsiU2UAVuqdYR_12int_ops_i128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !96 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsiU2UAVuqdYR_12int_ops_i128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !97 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsiU2UAVuqdYR_12int_ops_i128(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !98 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u128>
; Function Attrs: nounwind nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftoECsiU2UAVuqdYR_12int_ops_i128(i128 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !99 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 16 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i128
  %_0 = call i128 @llvm.fshl.i128(i128 %x, i128 %x, i128 %1)
  ret i128 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u128>
; Function Attrs: nounwind nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightoECsiU2UAVuqdYR_12int_ops_i128(i128 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !100 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 16 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i128
  %_0 = call i128 @llvm.fshr.i128(i128 %x, i128 %x, i128 %1)
  ret i128 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::is_val_statically_known::<i128>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownnECsiU2UAVuqdYR_12int_ops_i128(i128 %_arg) unnamed_addr #2 !guid !101 {
start:
  ret i1 false
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsiU2UAVuqdYR_12int_ops_i128(i32 %dummy) unnamed_addr #0 !guid !102 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !103
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsiU2UAVuqdYR_12int_ops_i128(i32 %dummy) unnamed_addr #0 !guid !104 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !103
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECsiU2UAVuqdYR_12int_ops_i128(i128 %dummy) unnamed_addr #0 !guid !105 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !103
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsiU2UAVuqdYR_12int_ops_i128(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !106 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsiU2UAVuqdYR_12int_ops_i128(ptr %f) #17
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #17
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %_1) unnamed_addr #0 !guid !107 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsiU2UAVuqdYR_12int_ops_i128(ptr %_4) #20
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsiU2UAVuqdYR_12int_ops_i128() #17
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsiU2UAVuqdYR_12int_ops_i128(i8 %_2) #17
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsiU2UAVuqdYR_12int_ops_i128(ptr %_1) unnamed_addr #0 !guid !108 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsiU2UAVuqdYR_12int_ops_i128(ptr %0) #17
  ret i32 %_0
}

; int_ops_i128::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsiU2UAVuqdYR_12int_ops_i1284main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !109 {
start:
  %0 = alloca [16 x i8], align 8
  %_294 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_284 = alloca [24 x i8], align 8
  %_283 = alloca [24 x i8], align 8
  %_279 = alloca [24 x i8], align 8
  %_276 = alloca [8 x i8], align 8
  %_269 = alloca [16 x i8], align 8
  %_268 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_264 = alloca [4 x i8], align 4
  %_262 = alloca [16 x i8], align 16
  %_255 = alloca [16 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_252 = alloca [4 x i8], align 4
  %_250 = alloca [4 x i8], align 4
  %_243 = alloca [16 x i8], align 8
  %_242 = alloca [16 x i8], align 8
  %_241 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_239 = alloca [8 x i8], align 8
  %_237 = alloca [4 x i8], align 4
  %_233 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_226 = alloca [16 x i8], align 8
  %_225 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_222 = alloca [32 x i8], align 16
  %_220 = alloca [1 x i8], align 1
  %_216 = alloca [32 x i8], align 16
  %_209 = alloca [16 x i8], align 8
  %_208 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_206 = alloca [16 x i8], align 16
  %_203 = alloca [16 x i8], align 16
  %_196 = alloca [16 x i8], align 8
  %_195 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_193 = alloca [32 x i8], align 16
  %_190 = alloca [32 x i8], align 16
  %_183 = alloca [16 x i8], align 8
  %_182 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_176 = alloca [16 x i8], align 16
  %_170 = alloca [16 x i8], align 16
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [16 x i8], align 16
  %_156 = alloca [16 x i8], align 16
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [16 x i8], align 16
  %_144 = alloca [16 x i8], align 16
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [16 x i8], align 16
  %_130 = alloca [16 x i8], align 16
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [32 x i8], align 16
  %_98 = alloca [32 x i8], align 16
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [16 x i8], align 16
  %_86 = alloca [16 x i8], align 16
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [16 x i8], align 16
  %_74 = alloca [16 x i8], align 16
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [16 x i8], align 16
  %_62 = alloca [16 x i8], align 16
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [32 x i8], align 16
  %_50 = alloca [32 x i8], align 16
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [32 x i8], align 16
  %_38 = alloca [32 x i8], align 16
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [16 x i8], align 16
  %min = alloca [16 x i8], align 16
; call core::hint::black_box::<i128>
  %_4 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECsiU2UAVuqdYR_12int_ops_i128(i128 -170141183460469231731687303715884105728) #17
; call core::hint::black_box::<i128>
  %_5 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECsiU2UAVuqdYR_12int_ops_i128(i128 170141183460469231731687303715884105727) #17
  store i128 %_4, ptr %min, align 16
  store i128 %_5, ptr %max, align 16
; call core::hint::black_box::<i128>
  %one = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECsiU2UAVuqdYR_12int_ops_i128(i128 1) #17
; call core::hint::black_box::<i128>
  %three = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECsiU2UAVuqdYR_12int_ops_i128(i128 3) #17
  store ptr %min, ptr %args, align 8
  %1 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_8ef33618ae8ccb51a896393da2a634dc, ptr %2, align 8
  %_297 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_15, ptr align 16 %_297) #17
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  %_298 = load ptr, ptr %3, align 8
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_16, ptr align 16 %_298) #17
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  %_299 = load ptr, ptr %4, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_299) #17
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_15, i64 16, i1 false)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_16, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsiU2UAVuqdYR_12int_ops_i128(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #17
  %_9.0 = extractvalue { ptr, ptr } %8, 0
  %_9.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %9 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %11, align 8
  %_300 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexnECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_28, ptr align 16 %_300) #17
  %12 = getelementptr inbounds i8, ptr %args2, i64 8
  %_301 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_binary::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_29, ptr align 16 %_301) #17
  %13 = getelementptr inbounds i8, ptr %args2, i64 16
  %_302 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_octal::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalnECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_30, ptr align 16 %_302) #17
  %14 = getelementptr inbounds i8, ptr %args2, i64 24
  %_303 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexnECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_31, ptr align 16 %_303) #17
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_28, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_29, i64 16, i1 false)
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_30, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsiU2UAVuqdYR_12int_ops_i128(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #17
  %_21.0 = extractvalue { ptr, ptr } %19, 0
  %_21.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %20 = load i128, ptr %max, align 16
; call <i128>::checked_add
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_addCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_38, i128 %20, i128 %one) #17
  %21 = load i128, ptr %min, align 16
; call <i128>::checked_add
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_addCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_40, i128 %21, i128 %one) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_42, ptr align 16 %_38) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_43, ptr align 16 %_40) #17
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_42, i64 16, i1 false)
  %23 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %23, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %24 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #17
  %_35.0 = extractvalue { ptr, ptr } %24, 0
  %_35.1 = extractvalue { ptr, ptr } %24, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %25 = load i128, ptr %max, align 16
  %26 = call { i128, i1 } @llvm.sadd.with.overflow.i128(i128 %25, i128 %one)
  %_5.0.i = extractvalue { i128, i1 } %26, 0
  %_5.1.i = extractvalue { i128, i1 } %26, 1
  store i128 %_5.0.i, ptr %_50, align 16
  %27 = getelementptr inbounds i8, ptr %_50, i64 16
  %28 = zext i1 %_5.1.i to i8
  store i8 %28, ptr %27, align 16
  %29 = load i128, ptr %min, align 16
  %30 = call { i128, i1 } @llvm.ssub.with.overflow.i128(i128 %29, i128 %one)
  %_5.0.i53 = extractvalue { i128, i1 } %30, 0
  %_5.1.i54 = extractvalue { i128, i1 } %30, 1
  store i128 %_5.0.i53, ptr %_52, align 16
  %31 = getelementptr inbounds i8, ptr %_52, i64 16
  %32 = zext i1 %_5.1.i54 to i8
  store i8 %32, ptr %31, align 16
; call <core::fmt::rt::Argument>::new_debug::<(i128, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTnbEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_54, ptr align 16 %_50) #17
; call <core::fmt::rt::Argument>::new_debug::<(i128, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTnbEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_55, ptr align 16 %_52) #17
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_54, i64 16, i1 false)
  %34 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %34, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %35 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #17
  %_47.0 = extractvalue { ptr, ptr } %35, 0
  %_47.1 = extractvalue { ptr, ptr } %35, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %36 = load i128, ptr %max, align 16
  %_0.i35 = add i128 %36, %one
  store i128 %_0.i35, ptr %_62, align 16
  %37 = load i128, ptr %min, align 16
  %_0.i42 = sub i128 %37, %one
  store i128 %_0.i42, ptr %_64, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_66, ptr align 16 %_62) #17
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_67, ptr align 16 %_64) #17
  %38 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %38, ptr align 8 %_66, i64 16, i1 false)
  %39 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %39, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %40 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #17
  %_59.0 = extractvalue { ptr, ptr } %40, 0
  %_59.1 = extractvalue { ptr, ptr } %40, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %41 = load i128, ptr %max, align 16
  %_0.i49 = call i128 @llvm.sadd.sat.i128(i128 %41, i128 %three)
  store i128 %_0.i49, ptr %_74, align 16
  %42 = load i128, ptr %min, align 16
  %_0.i50 = call i128 @llvm.ssub.sat.i128(i128 %42, i128 %three)
  store i128 %_0.i50, ptr %_76, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_78, ptr align 16 %_74) #17
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_79, ptr align 16 %_76) #17
  %43 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %43, ptr align 8 %_78, i64 16, i1 false)
  %44 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %44, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %45 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #17
  %_71.0 = extractvalue { ptr, ptr } %45, 0
  %_71.1 = extractvalue { ptr, ptr } %45, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %46 = load i128, ptr %max, align 16
  %_0.i37 = mul i128 %46, %three
  store i128 %_0.i37, ptr %_86, align 16
  %47 = load i128, ptr %max, align 16
  %48 = load i128, ptr %max, align 16
  %_0.i36 = mul i128 %47, %48
  store i128 %_0.i36, ptr %_88, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_90, ptr align 16 %_86) #17
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_91, ptr align 16 %_88) #17
  %49 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %49, ptr align 8 %_90, i64 16, i1 false)
  %50 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %50, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %51 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #17
  %_83.0 = extractvalue { ptr, ptr } %51, 0
  %_83.1 = extractvalue { ptr, ptr } %51, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %52 = load i128, ptr %max, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_98, i128 %52, i128 %three) #17
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsiU2UAVuqdYR_12int_ops_i128(i32 5) #17
; call <i128>::checked_pow
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_powCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_100, i128 %three, i32 %_101) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_103, ptr align 16 %_98) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_104, ptr align 16 %_100) #17
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_103, i64 16, i1 false)
  %54 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %54, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %55 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #17
  %_95.0 = extractvalue { ptr, ptr } %55, 0
  %_95.1 = extractvalue { ptr, ptr } %55, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %56 = load i128, ptr %max, align 16
  %57 = call i128 @llvm.ctpop.i128(i128 %56)
  %_0.i55 = trunc i128 %57 to i32
  store i32 %_0.i55, ptr %_111, align 4
  %58 = load i128, ptr %max, align 16
  %59 = call i128 @llvm.ctlz.i128(i128 %58, i1 false)
  %_0.i61 = trunc i128 %59 to i32
  store i32 %_0.i61, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsiU2UAVuqdYR_12int_ops_i128(i32 3) #17
  %_119 = icmp ult i32 %_117, 128
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %60 = and i32 %_117, 127
  %61 = zext i32 %60 to i128
  %_116 = shl i128 %one, %61
  %62 = call i128 @llvm.cttz.i128(i128 %_116, i1 false)
  %_0.i62 = trunc i128 %62 to i32
  store i32 %_0.i62, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %63 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %63, align 8
  %64 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %64, align 8
  %_316 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_316) #17
  %65 = getelementptr inbounds i8, ptr %args10, i64 8
  %_317 = load ptr, ptr %65, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_317) #17
  %66 = getelementptr inbounds i8, ptr %args10, i64 16
  %_318 = load ptr, ptr %66, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_318) #17
  %67 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %67, ptr align 8 %_121, i64 16, i1 false)
  %68 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %68, ptr align 8 %_122, i64 16, i1 false)
  %69 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %69, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %70 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsiU2UAVuqdYR_12int_ops_i128(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #17
  %_108.0 = extractvalue { ptr, ptr } %70, 0
  %_108.1 = extractvalue { ptr, ptr } %70, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsiU2UAVuqdYR_12int_ops_i128(i32 5) #17
  %71 = load i128, ptr %max, align 16
; call core::intrinsics::rotate_left::<u128>
  %_0.i56 = call i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftoECsiU2UAVuqdYR_12int_ops_i128(i128 %71, i32 %_131) #21
  store i128 %_0.i56, ptr %_130, align 16
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsiU2UAVuqdYR_12int_ops_i128(i32 7) #17
  %72 = load i128, ptr %min, align 16
; call core::intrinsics::rotate_right::<u128>
  %_0.i59 = call i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightoECsiU2UAVuqdYR_12int_ops_i128(i128 %72, i32 %_134) #21
  store i128 %_0.i59, ptr %_133, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_136, ptr align 16 %_130) #17
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_137, ptr align 16 %_133) #17
  %73 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %73, ptr align 8 %_136, i64 16, i1 false)
  %74 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %74, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %75 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #17
  %_127.0 = extractvalue { ptr, ptr } %75, 0
  %_127.1 = extractvalue { ptr, ptr } %75, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %76 = load i128, ptr %max, align 16
  %_0.i = call i128 @llvm.bswap.i128(i128 %76)
  store i128 %_0.i, ptr %_144, align 16
  %77 = load i128, ptr %max, align 16
  %_0.i58 = call i128 @llvm.bitreverse.i128(i128 %77)
  store i128 %_0.i58, ptr %_146, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_148, ptr align 16 %_144) #17
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_149, ptr align 16 %_146) #17
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_148, i64 16, i1 false)
  %79 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %79, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %80 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #17
  %_141.0 = extractvalue { ptr, ptr } %80, 0
  %_141.1 = extractvalue { ptr, ptr } %80, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsiU2UAVuqdYR_12int_ops_i128(i32 70) #17
  %81 = load i128, ptr %max, align 16
  %_3.i38 = and i32 %_157, 127
; call core::ub_checks::check_language_ub
  %_3.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_3.i44, label %bb2.i, label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <i128>::unchecked_shl::precondition_check
  call void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i32 %_3.i38, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #22
  br label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %82 = zext i32 %_3.i38 to i128
  %_0.i45 = shl i128 %81, %82
  store i128 %_0.i45, ptr %_156, align 16
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsiU2UAVuqdYR_12int_ops_i128(i32 66) #17
  %83 = load i128, ptr %min, align 16
  %_3.i40 = and i32 %_160, 127
; call core::ub_checks::check_language_ub
  %_3.i46 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_3.i46, label %bb2.i48, label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shr.exit

bb2.i48:                                          ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit
; call <i128>::unchecked_shr::precondition_check
  call void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shr18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i32 %_3.i40, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #22
  br label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shr.exit

_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shr.exit: ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit, %bb2.i48
  %84 = zext i32 %_3.i40 to i128
  %_0.i47 = ashr i128 %83, %84
  store i128 %_0.i47, ptr %_159, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_162, ptr align 16 %_156) #17
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_163, ptr align 16 %_159) #17
  %85 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %85, ptr align 8 %_162, i64 16, i1 false)
  %86 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %86, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %87 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #17
  %_153.0 = extractvalue { ptr, ptr } %87, 0
  %_153.1 = extractvalue { ptr, ptr } %87, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i128 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_9695c38ea34c2ac142a4f080a3b02a60) #23
  unreachable

bb85:                                             ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shr.exit
  %_172 = icmp eq i128 %three, -1
  %88 = load i128, ptr %max, align 16
  %_173 = icmp eq i128 %88, -170141183460469231731687303715884105728
  %_174 = and i1 %_172, %_173
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_e316ba92980127ac84bf97586df7c910) #23
  unreachable

bb86:                                             ; preds = %bb85
  %89 = load i128, ptr %max, align 16
  %90 = sdiv i128 %89, %three
  store i128 %90, ptr %_170, align 16
  %_177 = icmp eq i128 %three, 0
  br i1 %_177, label %panic27, label %bb87

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_e316ba92980127ac84bf97586df7c910) #23
  unreachable

bb87:                                             ; preds = %bb86
  %_178 = icmp eq i128 %three, -1
  %91 = load i128, ptr %max, align 16
  %_179 = icmp eq i128 %91, -170141183460469231731687303715884105728
  %_180 = and i1 %_178, %_179
  br i1 %_180, label %panic28, label %bb88

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_2e6b052c42f8b8d426c0e7fd41caa964) #23
  unreachable

bb88:                                             ; preds = %bb87
  %92 = load i128, ptr %max, align 16
  %93 = srem i128 %92, %three
  store i128 %93, ptr %_176, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_182, ptr align 16 %_170) #17
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_183, ptr align 16 %_176) #17
  %94 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %94, ptr align 8 %_182, i64 16, i1 false)
  %95 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %95, ptr align 8 %_183, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %96 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #17
  %_167.0 = extractvalue { ptr, ptr } %96, 0
  %_167.1 = extractvalue { ptr, ptr } %96, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<i128>
  %_191 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECsiU2UAVuqdYR_12int_ops_i128(i128 0) #17
  %97 = load i128, ptr %max, align 16
; call <i128>::checked_div
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_divCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_190, i128 %97, i128 %_191) #17
  %98 = load i128, ptr %max, align 16
; call <i128>::checked_rem
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_remCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_193, i128 %98, i128 %three) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_195, ptr align 16 %_190) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_196, ptr align 16 %_193) #17
  %99 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %99, ptr align 8 %_195, i64 16, i1 false)
  %100 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %100, ptr align 8 %_196, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %101 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #17
  %_187.0 = extractvalue { ptr, ptr } %101, 0
  %_187.1 = extractvalue { ptr, ptr } %101, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_187.0, ptr %_187.1)
; call core::hint::black_box::<u32>
  %_204 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsiU2UAVuqdYR_12int_ops_i128(i32 4) #17
; call <i128>::pow
  %102 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn3powCsiU2UAVuqdYR_12int_ops_i128(i128 %three, i32 %_204) #17
  store i128 %102, ptr %_203, align 16
  %103 = load i128, ptr %max, align 16
  %104 = load i128, ptr %min, align 16
; call <i128>::abs_diff
  %105 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn8abs_diffCsiU2UAVuqdYR_12int_ops_i128(i128 %103, i128 %104) #17
  store i128 %105, ptr %_206, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_208, ptr align 16 %_203) #17
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_209, ptr align 16 %_206) #17
  %106 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %106, ptr align 8 %_208, i64 16, i1 false)
  %107 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_209, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %108 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #17
  %_200.0 = extractvalue { ptr, ptr } %108, 0
  %_200.1 = extractvalue { ptr, ptr } %108, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_200.0, ptr %_200.1)
; call core::hint::black_box::<u32>
  %_218 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsiU2UAVuqdYR_12int_ops_i128(i32 7) #17
; call <i128>::from_str_radix
  call void @_RNvMst_NtCsl10jNU3mE6R_4core3numn14from_str_radixCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_216, ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_218) #17
; call <str>::parse::<i128>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsenECsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_222, ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #17
; call <core::result::Result<i128, core::num::error::ParseIntError>>::is_ok
  %109 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultnNtNtNtB4_3num5error13ParseIntErrorE5is_okCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %_222) #17
  %110 = zext i1 %109 to i8
  store i8 %110, ptr %_220, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i128, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultnNtNtNtB7_3num5error13ParseIntErrorEECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_225, ptr align 16 %_216) #17
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_226, ptr %_220) #17
  %111 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %111, ptr align 8 %_225, i64 16, i1 false)
  %112 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %112, ptr align 8 %_226, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %113 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #17
  %_213.0 = extractvalue { ptr, ptr } %113, 0
  %_213.1 = extractvalue { ptr, ptr } %113, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_213.0, ptr %_213.1)
  %114 = load i128, ptr %max, align 16
  %_235 = sitofp i128 %114 to double
  %_234 = call i128 @llvm.fptosi.sat.i128.f64(double %_235)
  %115 = load i128, ptr %max, align 16
  %116 = icmp eq i128 %_234, %115
  %117 = zext i1 %116 to i8
  store i8 %117, ptr %_233, align 1
  %118 = load i128, ptr %max, align 16
  %119 = sitofp i128 %118 to float
  store float %119, ptr %_237, align 4
  %120 = load i128, ptr %min, align 16
  %121 = sitofp i128 %120 to double
  store double %121, ptr %_239, align 8
  store ptr %_233, ptr %args19, align 8
  %122 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_237, ptr %122, align 8
  %123 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_239, ptr %123, align 8
  %_333 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_241, ptr %_333) #17
  %124 = getelementptr inbounds i8, ptr %args19, i64 8
  %_334 = load ptr, ptr %124, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_242, ptr align 4 %_334) #17
  %125 = getelementptr inbounds i8, ptr %args19, i64 16
  %_335 = load ptr, ptr %125, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_243, ptr align 8 %_335) #17
  %126 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %126, ptr align 8 %_241, i64 16, i1 false)
  %127 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %127, ptr align 8 %_242, i64 16, i1 false)
  %128 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %128, ptr align 8 %_243, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %129 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsiU2UAVuqdYR_12int_ops_i128(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #17
  %_230.0 = extractvalue { ptr, ptr } %129, 0
  %_230.1 = extractvalue { ptr, ptr } %129, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_230.0, ptr %_230.1)
  %130 = load i128, ptr %max, align 16
  %_2.i = xor i128 %130, -1
  %131 = call i128 @llvm.ctlz.i128(i128 %_2.i, i1 false)
  %_0.i60 = trunc i128 %131 to i32
  store i32 %_0.i60, ptr %_250, align 4
  %132 = load i128, ptr %min, align 16
  %133 = call i128 @llvm.cttz.i128(i128 %132, i1 false)
  %_0.i63 = trunc i128 %133 to i32
  store i32 %_0.i63, ptr %_252, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_254, ptr align 4 %_250) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_255, ptr align 4 %_252) #17
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_254, i64 16, i1 false)
  %135 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %135, ptr align 8 %_255, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %136 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #17
  %_247.0 = extractvalue { ptr, ptr } %136, 0
  %_247.1 = extractvalue { ptr, ptr } %136, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_247.0, ptr %_247.1)
  %137 = load i128, ptr %max, align 16
; call <i128>::isqrt
  %138 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn5isqrtCsiU2UAVuqdYR_12int_ops_i128(i128 %137, ptr align 8 @alloc_df4a957ad1e30b2d28834f15b5b475f2) #17
  store i128 %138, ptr %_262, align 16
  %139 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %three, i128 %three)
  %_266.0 = extractvalue { i128, i1 } %139, 0
  %_266.1 = extractvalue { i128, i1 } %139, 1
  br i1 %_266.1, label %panic29, label %bb127

panic28:                                          ; preds = %bb87
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_2e6b052c42f8b8d426c0e7fd41caa964) #23
  unreachable

bb127:                                            ; preds = %bb88
; call <i128>::ilog2
  %140 = call i32 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn5ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %_266.0, ptr align 8 @alloc_01e34181d0e442b37ac13d5382f4d462) #17
  store i32 %140, ptr %_264, align 4
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_268, ptr align 16 %_262) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_269, ptr align 4 %_264) #17
  %141 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %141, ptr align 8 %_268, i64 16, i1 false)
  %142 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %142, ptr align 8 %_269, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %143 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #17
  %_259.0 = extractvalue { ptr, ptr } %143, 0
  %_259.1 = extractvalue { ptr, ptr } %143, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_259.0, ptr %_259.1)
; call <i128 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringnNtB5_8ToString9to_stringCsiU2UAVuqdYR_12int_ops_i128(ptr sret([24 x i8]) align 8 %_279, ptr align 16 %max) #17
; invoke <alloc::string::String>::len
  %_277 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %_279)
          to label %bb134 unwind label %cleanup

panic29:                                          ; preds = %bb88
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_a069ea0994ebdb507669c3afe067af56) #23
  unreachable

bb147:                                            ; preds = %bb146, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279) #24
          to label %bb148 unwind label %terminate

cleanup:                                          ; preds = %bb143, %bb136, %bb135, %bb134, %bb127
  %144 = landingpad { ptr, i32 }
          cleanup
  %145 = extractvalue { ptr, i32 } %144, 0
  %146 = extractvalue { ptr, i32 } %144, 1
  store ptr %145, ptr %0, align 8
  %147 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %146, ptr %147, align 8
  br label %bb147

bb134:                                            ; preds = %bb127
; invoke <core::fmt::rt::Argument>::new_display::<i128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECsiU2UAVuqdYR_12int_ops_i128(ptr sret([16 x i8]) align 8 %_289, ptr align 16 %min)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  %148 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %148, ptr align 8 %_289, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %149 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb136 unwind label %cleanup

bb136:                                            ; preds = %bb135
  %_285.0 = extractvalue { ptr, ptr } %149, 0
  %_285.1 = extractvalue { ptr, ptr } %149, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsiU2UAVuqdYR_12int_ops_i128(ptr sret([24 x i8]) align 8 %_284, ptr %_285.0, ptr %_285.1)
          to label %bb137 unwind label %cleanup

bb137:                                            ; preds = %bb136
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_283, ptr align 8 %_284, i64 24, i1 false)
  br label %bb138

bb138:                                            ; preds = %bb137
; invoke <alloc::string::String>::len
  %_281 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %_283)
          to label %bb139 unwind label %cleanup30

bb146:                                            ; preds = %cleanup30
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283) #24
          to label %bb147 unwind label %terminate

cleanup30:                                        ; preds = %bb142, %bb141, %bb140, %panic31, %bb138
  %150 = landingpad { ptr, i32 }
          cleanup
  %151 = extractvalue { ptr, i32 } %150, 0
  %152 = extractvalue { ptr, i32 } %150, 1
  store ptr %151, ptr %0, align 8
  %153 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %152, ptr %153, align 8
  br label %bb146

bb139:                                            ; preds = %bb138
  %_292.0 = add i64 %_277, %_281
  %_292.1 = icmp ult i64 %_292.0, %_277
  br i1 %_292.1, label %panic31, label %bb140

bb140:                                            ; preds = %bb139
  store i64 %_292.0, ptr %_276, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_294, ptr align 8 %_276)
          to label %bb141 unwind label %cleanup30

panic31:                                          ; preds = %bb139
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_bfce3a1a97a4440398b4f99aa3b8a6fa) #19
          to label %unreachable unwind label %cleanup30

unreachable:                                      ; preds = %panic31
  unreachable

bb141:                                            ; preds = %bb140
  %154 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %154, ptr align 8 %_294, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %155 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb142 unwind label %cleanup30

bb142:                                            ; preds = %bb141
  %_273.0 = extractvalue { ptr, ptr } %155, 0
  %_273.1 = extractvalue { ptr, ptr } %155, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_273.0, ptr %_273.1)
          to label %bb143 unwind label %cleanup30

bb143:                                            ; preds = %bb142
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283)
          to label %bb144 unwind label %cleanup

bb144:                                            ; preds = %bb143
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279)
  ret void

terminate:                                        ; preds = %bb147, %bb146
  %156 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable

bb148:                                            ; preds = %bb147
  %157 = load ptr, ptr %0, align 8
  %158 = getelementptr inbounds i8, ptr %0, i64 8
  %159 = load i32, ptr %158, align 8
  %160 = insertvalue { ptr, i32 } poison, ptr %157, 0
  %161 = insertvalue { ptr, i32 } %160, i32 %159, 1
  resume { ptr, i32 } %161
}

; <alloc::string::String>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCsiU2UAVuqdYR_12int_ops_i128(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !110 {
start:
  %_2 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8 %_2, i64 %capacity) #17
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self) unnamed_addr #0 !guid !111 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #17
  ret i64 %_0
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !112 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self) #17
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8CsiU2UAVuqdYR_12int_ops_i128(i32 %ch) #17
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self, i64 %ch_len) #17
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8 %self) #17
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCsiU2UAVuqdYR_12int_ops_i128(i32 %ch, ptr %_0.i) #17
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8 %self, i64 %_14) #17
  ret void
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !113 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::string::String>::push_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self, ptr %string.0, i64 %string.1) unnamed_addr #0 !guid !114 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %string.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %string.1, 1
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; call <alloc::vec::Vec<u8>>::extend_from_slice
  call void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8 %self, ptr %_4.0, i64 %_4.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsiU2UAVuqdYR_12int_ops_i128(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !115 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<i128>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_noneCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %self) unnamed_addr #0 !guid !116 {
start:
; call <core::option::Option<i128>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_someCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %self) #17
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::option::Option<i128>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_someCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %self) unnamed_addr #0 !guid !117 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i128, ptr %self, align 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i128, ptr %1, align 16
  %_2 = trunc i128 %0 to i64
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i128, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultnNtNtNtB4_3num5error13ParseIntErrorE5is_okCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %self) unnamed_addr #0 !guid !118 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8CsiU2UAVuqdYR_12int_ops_i128(i32 %self) unnamed_addr #0 !guid !119 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CsiU2UAVuqdYR_12int_ops_i128(i32 %self) #17
  ret i64 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsiU2UAVuqdYR_12int_ops_i128(i32 %self, i32 %radix) unnamed_addr #0 !guid !120 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsiU2UAVuqdYR_12int_ops_i128(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #17
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #23
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::num::nonzero::NonZero<u128>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE13leading_zerosCsiU2UAVuqdYR_12int_ops_i128(i128 %self) unnamed_addr #0 !guid !121 {
start:
; call <core::num::nonzero::NonZero<u128>>::get
  %_2 = call i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3getB9_(i128 %self) #17
  %0 = call i128 @llvm.ctlz.i128(i128 %_2, i1 true)
  %_0 = trunc i128 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u128>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE5ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %self) unnamed_addr #0 !guid !122 {
start:
; call <core::num::nonzero::NonZero<u128>>::leading_zeros
  %_3 = call i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE13leading_zerosCsiU2UAVuqdYR_12int_ops_i128(i128 %self) #17
  %_0 = sub i32 127, %_3
  ret i32 %_0
}

; <core::ptr::non_null::NonNull<core::option::Option<i128>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionnEE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %r) unnamed_addr #0 !guid !123 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultnNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %r) unnamed_addr #0 !guid !124 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<(i128, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTnbEE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %r) unnamed_addr #0 !guid !125 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr %r) unnamed_addr #0 !guid !126 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %r) unnamed_addr #0 !guid !127 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 4 %r) unnamed_addr #0 !guid !128 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %r) unnamed_addr #0 !guid !129 {
start:
  ret ptr %r
}

; <i128>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10strict_powCsiU2UAVuqdYR_12int_ops_i128(i128 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !130 {
start:
  %_3 = alloca [32 x i8], align 16
; call <i128>::checked_pow
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_powCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_3, i128 %self, i32 %exp) #17
  %1 = load i128, ptr %_3, align 16
  %2 = getelementptr inbounds i8, ptr %_3, i64 16
  %3 = load i128, ptr %2, align 16
  %_4 = trunc i128 %1 to i64
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %_3, i64 16
  %x = load i128, ptr %5, align 16
  ret i128 %x

bb3:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i128>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_addCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !131 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.sadd.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <i128>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_divCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !132 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_5 = icmp eq i128 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i128 %self, -170141183460469231731687303715884105728
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i128 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = sdiv i128 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_7, ptr %6, align 16
  store i128 1, ptr %_0, align 16
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  ret void
}

; <i128>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !133 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <i128>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_powCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !134 {
start:
  %_57 = alloca [32 x i8], align 16
  %_48 = alloca [32 x i8], align 16
  %_38 = alloca [32 x i8], align 16
  %_32 = alloca [32 x i8], align 16
  %_13 = alloca [8 x i8], align 4
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  %_6 = load i128, ptr %base, align 16
  %_5 = call i1 @llvm.is.constant.i128(i128 %_6)
  br i1 %_5, label %bb2, label %bb16

bb16:                                             ; preds = %bb2, %start
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp eq i32 %_24, 0
  br i1 %_23, label %bb17, label %bb18

bb2:                                              ; preds = %start
  %_9 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_8 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCsiU2UAVuqdYR_12int_ops_i128(i128 %_9) #17
  %1 = call i128 @llvm.ctpop.i128(i128 %_8)
  %_0.i.i = trunc i128 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb16

bb5:                                              ; preds = %bb2
  %_12 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_11 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCsiU2UAVuqdYR_12int_ops_i128(i128 %_12) #17
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %_11, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #17
  %_14 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsiU2UAVuqdYR_12int_ops_i128(i32 %k, i32 %_14) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_13, align 4
  %5 = getelementptr inbounds i8, ptr %_13, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_13, align 4
  %7 = getelementptr inbounds i8, ptr %_13, i64 4
  %8 = load i32, ptr %7, align 4
  %_15 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_15 to i1
  br i1 %9, label %bb11, label %bb10

bb18:                                             ; preds = %bb16
  %_26 = load i32, ptr %exp, align 4
  %_25 = call i1 @llvm.is.constant.i32(i32 %_26)
  br i1 %_25, label %bb20, label %bb32

bb17:                                             ; preds = %bb16
  %10 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 1, ptr %10, align 16
  store i128 1, ptr %_0, align 16
  br label %bb43

bb32:                                             ; preds = %bb42, %bb18
  %_47 = load i32, ptr %exp, align 4
  %_46 = and i32 %_47, 1
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb33, label %bb38

bb20:                                             ; preds = %bb30, %bb18
  %_28 = load i32, ptr %exp, align 4
  %_27 = icmp ugt i32 %_28, 1
  br i1 %_27, label %bb21, label %bb31

bb38:                                             ; preds = %bb36, %bb32
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_58 = load i128, ptr %base, align 16
  %_59 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_57, i128 %_58, i128 %_59) #17
  %13 = load i128, ptr %_57, align 16
  %14 = getelementptr inbounds i8, ptr %_57, i64 16
  %15 = load i128, ptr %14, align 16
  %_60 = trunc i128 %13 to i64
  %16 = trunc nuw i64 %_60 to i1
  br i1 %16, label %bb42, label %bb41

bb33:                                             ; preds = %bb32
  %_49 = load i128, ptr %acc, align 16
  %_50 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_48, i128 %_49, i128 %_50) #17
  %17 = load i128, ptr %_48, align 16
  %18 = getelementptr inbounds i8, ptr %_48, i64 16
  %19 = load i128, ptr %18, align 16
  %_51 = trunc i128 %17 to i64
  %20 = trunc nuw i64 %_51 to i1
  br i1 %20, label %bb36, label %bb35

bb36:                                             ; preds = %bb33
  %21 = getelementptr inbounds i8, ptr %_48, i64 16
  %x = load i128, ptr %21, align 16
  store i128 %x, ptr %acc, align 16
  %_54 = load i32, ptr %exp, align 4
  %_53 = icmp eq i32 %_54, 1
  br i1 %_53, label %bb37, label %bb38

bb35:                                             ; preds = %bb33
  store i128 0, ptr %_0, align 16
  br label %bb43

bb43:                                             ; preds = %bb14, %bb15, %bb10, %bb17, %bb29, %bb24, %bb31, %bb37, %bb41, %bb35
  ret void

bb37:                                             ; preds = %bb36
  %_55 = load i128, ptr %acc, align 16
  %22 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_55, ptr %22, align 16
  store i128 1, ptr %_0, align 16
  br label %bb43

bb42:                                             ; preds = %bb38
  %23 = getelementptr inbounds i8, ptr %_57, i64 16
  %x1 = load i128, ptr %23, align 16
  store i128 %x1, ptr %base, align 16
  br label %bb32

bb41:                                             ; preds = %bb38
  store i128 0, ptr %_0, align 16
  br label %bb43

bb31:                                             ; preds = %bb20
  %_43 = load i128, ptr %acc, align 16
  %_44 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %_43, i128 %_44) #17
  br label %bb43

bb21:                                             ; preds = %bb20
  %_31 = load i32, ptr %exp, align 4
  %_30 = and i32 %_31, 1
  %_29 = icmp eq i32 %_30, 1
  br i1 %_29, label %bb22, label %bb26

bb26:                                             ; preds = %bb25, %bb21
  %24 = load i32, ptr %exp, align 4
  %25 = udiv i32 %24, 2
  store i32 %25, ptr %exp, align 4
  %_39 = load i128, ptr %base, align 16
  %_40 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_38, i128 %_39, i128 %_40) #17
  %26 = load i128, ptr %_38, align 16
  %27 = getelementptr inbounds i8, ptr %_38, i64 16
  %28 = load i128, ptr %27, align 16
  %_41 = trunc i128 %26 to i64
  %29 = trunc nuw i64 %_41 to i1
  br i1 %29, label %bb30, label %bb29

bb22:                                             ; preds = %bb21
  %_33 = load i128, ptr %acc, align 16
  %_34 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_32, i128 %_33, i128 %_34) #17
  %30 = load i128, ptr %_32, align 16
  %31 = getelementptr inbounds i8, ptr %_32, i64 16
  %32 = load i128, ptr %31, align 16
  %_35 = trunc i128 %30 to i64
  %33 = trunc nuw i64 %_35 to i1
  br i1 %33, label %bb25, label %bb24

bb25:                                             ; preds = %bb22
  %34 = getelementptr inbounds i8, ptr %_32, i64 16
  %x2 = load i128, ptr %34, align 16
  store i128 %x2, ptr %acc, align 16
  br label %bb26

bb24:                                             ; preds = %bb22
  store i128 0, ptr %_0, align 16
  br label %bb43

bb30:                                             ; preds = %bb26
  %35 = getelementptr inbounds i8, ptr %_38, i64 16
  %x3 = load i128, ptr %35, align 16
  store i128 %x3, ptr %base, align 16
  br label %bb20

bb29:                                             ; preds = %bb26
  store i128 0, ptr %_0, align 16
  br label %bb43

bb11:                                             ; preds = %bb5
  %36 = getelementptr inbounds i8, ptr %_13, i64 4
  %shift = load i32, ptr %36, align 4
  %_18 = load i128, ptr %base, align 16
  %_17 = icmp slt i128 %_18, 0
  br i1 %_17, label %bb12, label %bb15

bb10:                                             ; preds = %bb5
  store i128 0, ptr %_0, align 16
  br label %bb43

bb15:                                             ; preds = %bb12, %bb11
; call <i128>::shl_exact
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 1, i32 %shift) #17
  br label %bb43

bb12:                                             ; preds = %bb11
  %_21 = load i32, ptr %exp, align 4
  %_20 = urem i32 %_21, 2
  %_19 = icmp eq i32 %_20, 1
  br i1 %_19, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
; call <i128>::shl_exact
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 -1, i32 %shift) #17
  br label %bb43

bb9:                                              ; No predecessors!
  unreachable
}

; <i128>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_remCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !135 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_5 = icmp eq i128 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i128 %self, -170141183460469231731687303715884105728
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i128 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = srem i128 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_7, ptr %6, align 16
  store i128 1, ptr %_0, align 16
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  ret void
}

; <i128>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_subCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !136 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.ssub.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <i128>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCsiU2UAVuqdYR_12int_ops_i128(i128 %self) unnamed_addr #0 !guid !137 {
start:
; call <i128>::wrapping_abs
  %_2 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCsiU2UAVuqdYR_12int_ops_i128(i128 %self) #17
  ret i128 %_2
}

; <i128>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCsiU2UAVuqdYR_12int_ops_i128(i128 %self) unnamed_addr #0 !guid !138 {
start:
  %_0 = alloca [16 x i8], align 16
  %_0.i = icmp slt i128 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i128 %self, ptr %_0, align 16
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i128 0, %self
  store i128 %_0.i2, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; <i128>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_powCsiU2UAVuqdYR_12int_ops_i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !139 {
start:
  %0 = alloca [32 x i8], align 16
; call <i128>::overflowing_pow
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn15overflowing_powCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %0, i128 %self, i32 %exp) #17
  %_3.0 = load i128, ptr %0, align 16
  %1 = getelementptr inbounds i8, ptr %0, i64 16
  %2 = load i8, ptr %1, align 16
  %_3.1 = trunc nuw i8 %2 to i1
  ret i128 %_3.0
}

; <i128>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13checked_ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %self) unnamed_addr #0 !guid !140 {
start:
  %_0 = alloca [8 x i8], align 4
  %_2 = icmp sle i128 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = call i128 @llvm.ctlz.i128(i128 %self, i1 true)
  %_5 = trunc i128 %0 to i32
  %log = sub i32 127, %_5
  %1 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %log, ptr %1, align 4
  store i32 1, ptr %_0, align 4
  br label %bb4

bb1:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  %2 = load i32, ptr %_0, align 4
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  %4 = load i32, ptr %3, align 4
  %5 = insertvalue { i32, i32 } poison, i32 %2, 0
  %6 = insertvalue { i32, i32 } %5, i32 %4, 1
  ret { i32, i32 } %6
}

; <i128>::checked_isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13checked_isqrtCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %self) unnamed_addr #0 !guid !141 {
start:
  %_2 = icmp slt i128 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call <u128>::isqrt
  %_4 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5isqrtCsiU2UAVuqdYR_12int_ops_i128(i128 %self) #17
  %_7 = icmp sle i128 %_4, 13043817825332782212
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb2
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_7, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb2, %bb2.i
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_4, ptr %0, align 16
  store i128 1, ptr %_0, align 16
  br label %bb7

bb1:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb7

bb7:                                              ; preds = %bb1, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  ret void
}

; <i128>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unbounded_shlCsiU2UAVuqdYR_12int_ops_i128(i128 %self, i32 %rhs) unnamed_addr #0 !guid !142 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp ult i32 %rhs, 128
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <i128>::unchecked_shl::precondition_check
  call void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i32 %rhs, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #22
  br label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i128
  %_0.i = shl i128 %self, %0
  store i128 %_0.i, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit, %bb2
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; <i128>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn15overflowing_powCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !143 {
start:
  %1 = alloca [32 x i8], align 16
  %2 = alloca [32 x i8], align 16
  %3 = alloca [32 x i8], align 16
  %4 = alloca [32 x i8], align 16
  %5 = alloca [32 x i8], align 16
  %_30 = alloca [32 x i8], align 16
  %base1 = alloca [16 x i8], align 16
  %_16 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  store i8 0, ptr %overflow, align 1
  %_8 = load i128, ptr %base, align 16
  %_7 = call i1 @llvm.is.constant.i128(i128 %_8)
  br i1 %_7, label %bb2, label %bb19

bb19:                                             ; preds = %bb2, %start
  %_33 = load i32, ptr %exp, align 4
  %_32 = icmp eq i32 %_33, 0
  br i1 %_32, label %bb20, label %bb21

bb2:                                              ; preds = %start
  %_11 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_10 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCsiU2UAVuqdYR_12int_ops_i128(i128 %_11) #17
  %6 = call i128 @llvm.ctpop.i128(i128 %_10)
  %_0.i.i = trunc i128 %6 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb19

bb5:                                              ; preds = %bb2
  %_14 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_13 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCsiU2UAVuqdYR_12int_ops_i128(i128 %_14) #17
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %_13, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #17
  %_17 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %7 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsiU2UAVuqdYR_12int_ops_i128(i32 %k, i32 %_17) #17
  %8 = extractvalue { i32, i32 } %7, 0
  %9 = extractvalue { i32, i32 } %7, 1
  store i32 %8, ptr %_16, align 4
  %10 = getelementptr inbounds i8, ptr %_16, i64 4
  store i32 %9, ptr %10, align 4
  %11 = load i32, ptr %_16, align 4
  %12 = getelementptr inbounds i8, ptr %_16, i64 4
  %13 = load i32, ptr %12, align 4
  %_18 = zext i32 %11 to i64
  %14 = trunc nuw i64 %_18 to i1
  br i1 %14, label %bb9, label %bb10

bb21:                                             ; preds = %bb19
  %_35 = load i32, ptr %exp, align 4
  %_34 = call i1 @llvm.is.constant.i32(i32 %_35)
  br i1 %_34, label %bb23, label %bb32

bb20:                                             ; preds = %bb19
  store i128 1, ptr %_0, align 16
  %15 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 0, ptr %15, align 16
  br label %bb39

bb32:                                             ; preds = %bb36, %bb21
  %_64 = load i32, ptr %exp, align 4
  %_63 = and i32 %_64, 1
  %_62 = icmp eq i32 %_63, 1
  br i1 %_62, label %bb33, label %bb36

bb23:                                             ; preds = %bb27, %bb21
  %_37 = load i32, ptr %exp, align 4
  %_36 = icmp ugt i32 %_37, 1
  br i1 %_36, label %bb24, label %bb30

bb36:                                             ; preds = %bb33, %bb32
  %16 = load i32, ptr %exp, align 4
  %17 = udiv i32 %16, 2
  store i32 %17, ptr %exp, align 4
  %_79 = load i128, ptr %base, align 16
  %_80 = load i128, ptr %base, align 16
  %18 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_79, i128 %_80)
  %_5.0.i6 = extractvalue { i128, i1 } %18, 0
  %_5.1.i7 = extractvalue { i128, i1 } %18, 1
  store i128 %_5.0.i6, ptr %4, align 16
  %19 = getelementptr inbounds i8, ptr %4, i64 16
  %20 = zext i1 %_5.1.i7 to i8
  store i8 %20, ptr %19, align 16
  %_78.0 = load i128, ptr %4, align 16
  %21 = getelementptr inbounds i8, ptr %4, i64 16
  %22 = load i8, ptr %21, align 16
  %_78.1 = trunc nuw i8 %22 to i1
  store i128 %_78.0, ptr %base, align 16
  %23 = zext i1 %_78.1 to i8
  store i8 %23, ptr %tmp_overflow, align 1
  %24 = load i8, ptr %tmp_overflow, align 1
  %_81 = trunc nuw i8 %24 to i1
  %25 = load i8, ptr %overflow, align 1
  %26 = trunc nuw i8 %25 to i1
  %27 = or i1 %26, %_81
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %overflow, align 1
  br label %bb32

bb33:                                             ; preds = %bb32
  %_68 = load i128, ptr %acc, align 16
  %_69 = load i128, ptr %base, align 16
  %29 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_68, i128 %_69)
  %_5.0.i8 = extractvalue { i128, i1 } %29, 0
  %_5.1.i9 = extractvalue { i128, i1 } %29, 1
  store i128 %_5.0.i8, ptr %5, align 16
  %30 = getelementptr inbounds i8, ptr %5, i64 16
  %31 = zext i1 %_5.1.i9 to i8
  store i8 %31, ptr %30, align 16
  %_67.0 = load i128, ptr %5, align 16
  %32 = getelementptr inbounds i8, ptr %5, i64 16
  %33 = load i8, ptr %32, align 16
  %_67.1 = trunc nuw i8 %33 to i1
  store i128 %_67.0, ptr %acc, align 16
  %34 = zext i1 %_67.1 to i8
  store i8 %34, ptr %tmp_overflow, align 1
  %35 = load i8, ptr %tmp_overflow, align 1
  %_70 = trunc nuw i8 %35 to i1
  %36 = load i8, ptr %overflow, align 1
  %37 = trunc nuw i8 %36 to i1
  %38 = or i1 %37, %_70
  %39 = zext i1 %38 to i8
  store i8 %39, ptr %overflow, align 1
  %_72 = load i32, ptr %exp, align 4
  %_71 = icmp eq i32 %_72, 1
  br i1 %_71, label %bb35, label %bb36

bb35:                                             ; preds = %bb33
  %_73 = load i128, ptr %acc, align 16
  %40 = load i8, ptr %overflow, align 1
  %_74 = trunc nuw i8 %40 to i1
  store i128 %_73, ptr %_0, align 16
  %41 = getelementptr inbounds i8, ptr %_0, i64 16
  %42 = zext i1 %_74 to i8
  store i8 %42, ptr %41, align 16
  br label %bb39

bb39:                                             ; preds = %bb10, %bb15, %bb20, %bb30, %bb35
  ret void

bb30:                                             ; preds = %bb23
  %_57 = load i128, ptr %acc, align 16
  %_58 = load i128, ptr %base, align 16
  %43 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_57, i128 %_58)
  %_5.0.i4 = extractvalue { i128, i1 } %43, 0
  %_5.1.i5 = extractvalue { i128, i1 } %43, 1
  store i128 %_5.0.i4, ptr %3, align 16
  %44 = getelementptr inbounds i8, ptr %3, i64 16
  %45 = zext i1 %_5.1.i5 to i8
  store i8 %45, ptr %44, align 16
  %_56.0 = load i128, ptr %3, align 16
  %46 = getelementptr inbounds i8, ptr %3, i64 16
  %47 = load i8, ptr %46, align 16
  %_56.1 = trunc nuw i8 %47 to i1
  store i128 %_56.0, ptr %acc, align 16
  %48 = zext i1 %_56.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_59 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_59
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  %_60 = load i128, ptr %acc, align 16
  %54 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %54 to i1
  store i128 %_60, ptr %_0, align 16
  %55 = getelementptr inbounds i8, ptr %_0, i64 16
  %56 = zext i1 %_61 to i8
  store i8 %56, ptr %55, align 16
  br label %bb39

bb24:                                             ; preds = %bb23
  %_40 = load i32, ptr %exp, align 4
  %_39 = and i32 %_40, 1
  %_38 = icmp eq i32 %_39, 1
  br i1 %_38, label %bb25, label %bb27

bb27:                                             ; preds = %bb25, %bb24
  %57 = load i32, ptr %exp, align 4
  %58 = udiv i32 %57, 2
  store i32 %58, ptr %exp, align 4
  %_51 = load i128, ptr %base, align 16
  %_52 = load i128, ptr %base, align 16
  %59 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_51, i128 %_52)
  %_5.0.i = extractvalue { i128, i1 } %59, 0
  %_5.1.i = extractvalue { i128, i1 } %59, 1
  store i128 %_5.0.i, ptr %1, align 16
  %60 = getelementptr inbounds i8, ptr %1, i64 16
  %61 = zext i1 %_5.1.i to i8
  store i8 %61, ptr %60, align 16
  %_50.0 = load i128, ptr %1, align 16
  %62 = getelementptr inbounds i8, ptr %1, i64 16
  %63 = load i8, ptr %62, align 16
  %_50.1 = trunc nuw i8 %63 to i1
  store i128 %_50.0, ptr %base, align 16
  %64 = zext i1 %_50.1 to i8
  store i8 %64, ptr %tmp_overflow, align 1
  %65 = load i8, ptr %tmp_overflow, align 1
  %_53 = trunc nuw i8 %65 to i1
  %66 = load i8, ptr %overflow, align 1
  %67 = trunc nuw i8 %66 to i1
  %68 = or i1 %67, %_53
  %69 = zext i1 %68 to i8
  store i8 %69, ptr %overflow, align 1
  br label %bb23

bb25:                                             ; preds = %bb24
  %_44 = load i128, ptr %acc, align 16
  %_45 = load i128, ptr %base, align 16
  %70 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_44, i128 %_45)
  %_5.0.i2 = extractvalue { i128, i1 } %70, 0
  %_5.1.i3 = extractvalue { i128, i1 } %70, 1
  store i128 %_5.0.i2, ptr %2, align 16
  %71 = getelementptr inbounds i8, ptr %2, i64 16
  %72 = zext i1 %_5.1.i3 to i8
  store i8 %72, ptr %71, align 16
  %_43.0 = load i128, ptr %2, align 16
  %73 = getelementptr inbounds i8, ptr %2, i64 16
  %74 = load i8, ptr %73, align 16
  %_43.1 = trunc nuw i8 %74 to i1
  store i128 %_43.0, ptr %acc, align 16
  %75 = zext i1 %_43.1 to i8
  store i8 %75, ptr %tmp_overflow, align 1
  %76 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %76 to i1
  %77 = load i8, ptr %overflow, align 1
  %78 = trunc nuw i8 %77 to i1
  %79 = or i1 %78, %_46
  %80 = zext i1 %79 to i8
  store i8 %80, ptr %overflow, align 1
  br label %bb27

bb9:                                              ; preds = %bb5
  %81 = getelementptr inbounds i8, ptr %_16, i64 4
  %shift = load i32, ptr %81, align 4
  %_21 = load i128, ptr %base, align 16
  %_20 = icmp slt i128 %_21, 0
  br i1 %_20, label %bb11, label %bb14

bb10:                                             ; preds = %bb5
  store i128 0, ptr %_0, align 16
  %82 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 1, ptr %82, align 16
  br label %bb39

bb14:                                             ; preds = %bb11, %bb9
  store i128 1, ptr %base1, align 16
  br label %bb15

bb11:                                             ; preds = %bb9
  %_24 = load i32, ptr %exp, align 4
  %_23 = urem i32 %_24, 2
  %_22 = icmp ne i32 %_23, 0
  br i1 %_22, label %bb13, label %bb14

bb13:                                             ; preds = %bb11
  store i128 -1, ptr %base1, align 16
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_27 = load i128, ptr %base1, align 16
; call <i128>::unbounded_shl
  %_26 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unbounded_shlCsiU2UAVuqdYR_12int_ops_i128(i128 %_27, i32 %shift) #17
  %_31 = load i128, ptr %base1, align 16
; call <i128>::shl_exact
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_30, i128 %_31, i32 %shift) #17
; call <core::option::Option<i128>>::is_none
  %_28 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_noneCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %_30) #17
  store i128 %_26, ptr %_0, align 16
  %83 = getelementptr inbounds i8, ptr %_0, i64 16
  %84 = zext i1 %_28 to i8
  store i8 %84, ptr %83, align 16
  br label %bb39

bb40:                                             ; No predecessors!
  unreachable
}

; <i128>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn3powCsiU2UAVuqdYR_12int_ops_i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !144 {
start:
  %_0 = alloca [16 x i8], align 16
  br label %bb1

bb1:                                              ; preds = %start
; call <i128>::strict_pow
  %0 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10strict_powCsiU2UAVuqdYR_12int_ops_i128(i128 %self, i32 %exp, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #17
  store i128 %0, ptr %_0, align 16
  br label %bb3

bb2:                                              ; No predecessors!
; call <i128>::wrapping_pow
  %1 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_powCsiU2UAVuqdYR_12int_ops_i128(i128 %self, i32 %exp) #17
  store i128 %1, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i128, ptr %_0, align 16
  ret i128 %2
}

; <i128>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn5ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %self, ptr align 8 %0) unnamed_addr #0 !guid !145 {
start:
  %_2 = alloca [8 x i8], align 4
; call <i128>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13checked_ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i128>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn5isqrtCsiU2UAVuqdYR_12int_ops_i128(i128 %self, ptr align 8 %0) unnamed_addr #0 !guid !146 {
start:
  %_2 = alloca [32 x i8], align 16
; call <i128>::checked_isqrt
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13checked_isqrtCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_2, i128 %self) #17
  %1 = load i128, ptr %_2, align 16
  %2 = getelementptr inbounds i8, ptr %_2, i64 16
  %3 = load i128, ptr %2, align 16
  %_3 = trunc i128 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %_2, i64 16
  %sqrt = load i128, ptr %5, align 16
  ret i128 %sqrt

bb3:                                              ; preds = %start
; call core::num::imp::int_sqrt::panic_for_negative_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i128>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn8abs_diffCsiU2UAVuqdYR_12int_ops_i128(i128 %self, i128 %other) unnamed_addr #0 !guid !147 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp slt i128 %self, %other
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_0.i1 = sub i128 %self, %other
  store i128 %_0.i1, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
  %_0.i = sub i128 %other, %self
  store i128 %_0.i, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; <i128>::shl_exact
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %rhs) unnamed_addr #0 !guid !148 {
start:
  %0 = call i128 @llvm.ctlz.i128(i128 %self, i1 false)
  %_0.i4 = trunc i128 %0 to i32
  %_3 = icmp ult i32 %rhs, %_0.i4
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_2.i = xor i128 %self, -1
  %1 = call i128 @llvm.ctlz.i128(i128 %_2.i, i1 false)
  %_0.i = trunc i128 %1 to i32
  %_5 = icmp ult i32 %rhs, %_0.i
  br i1 %_5, label %bb4, label %bb6

bb4:                                              ; preds = %bb2, %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

bb2.i:                                            ; preds = %bb4
; call <i128>::unchecked_shl::precondition_check
  call void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i32 %rhs, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #22
  br label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit: ; preds = %bb4, %bb2.i
  %2 = zext i32 %rhs to i128
  %_0.i2 = shl i128 %self, %2
  %3 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_0.i2, ptr %3, align 16
  store i128 1, ptr %_0, align 16
  br label %bb7

bb6:                                              ; preds = %bb2
  store i128 0, ptr %_0, align 16
  br label %bb7

bb7:                                              ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit, %bb6
  ret void
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self) unnamed_addr #0 !guid !149 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #17
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsiU2UAVuqdYR_12int_ops_i128(ptr %_7.0, i64 %_7.1) #17
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsiU2UAVuqdYR_12int_ops_i128(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !150 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsiU2UAVuqdYR_12int_ops_i128(ptr %s.0, i64 %s.1) #17
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsiU2UAVuqdYR_12int_ops_i128(i32 %self, i32 %rhs) unnamed_addr #0 !guid !151 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u128>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13checked_ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %self) unnamed_addr #0 !guid !152 {
start:
  %_2 = alloca [16 x i8], align 16
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u128>>::new
  %0 = call i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3newB9_(i128 %self) #17
  store i128 %0, ptr %_2, align 16
  %1 = load i128, ptr %_2, align 16
  %2 = icmp eq i128 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i128, ptr %_2, align 16
; call <core::num::nonzero::NonZero<u128>>::ilog2
  %_5 = call i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE5ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %x) #17
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u128>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %self, ptr align 8 %0) unnamed_addr #0 !guid !153 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u128>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13checked_ilog2CsiU2UAVuqdYR_12int_ops_i128(i128 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u128>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5isqrtCsiU2UAVuqdYR_12int_ops_i128(i128 %self) unnamed_addr #0 !guid !154 {
start:
; call core::num::imp::int_sqrt::u128
  %result = call i128 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt4u128CsiU2UAVuqdYR_12int_ops_i128(i128 %self) #17
  %_3 = icmp ule i128 %result, 18446744073709551615
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_3, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i128 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u128>::unchecked_mul::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i128 %result, i128 %result, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i128 %result, %result
  %_8 = icmp ule i128 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_8, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i128 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_11, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i128 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i128 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_6, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsiU2UAVuqdYR_12int_ops_i128(ptr %self) unnamed_addr #0 !guid !155 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsiU2UAVuqdYR_12int_ops_i128(i8 %0) unnamed_addr #0 !guid !156 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsiU2UAVuqdYR_12int_ops_i128(ptr %self) #17
  ret i32 %_0
}

; <i128>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMst_NtCsl10jNU3mE6R_4core3numn14from_str_radixCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !157 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <i128>::from_ascii_bytes_radix_impl
  call void @_RNvMst_NtCsl10jNU3mE6R_4core3numn27from_ascii_bytes_radix_implCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #17
  ret void
}

; <i128>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMst_NtCsl10jNU3mE6R_4core3numn27from_ascii_bytes_radix_implCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !158 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [32 x i8], align 16
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [32 x i8], align 16
  %_74 = alloca [32 x i8], align 16
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [32 x i8], align 16
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [16 x i8], align 16
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #23
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #17
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !159
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i128 0, ptr %result, align 16
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECsiU2UAVuqdYR_12int_ops_i128.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 31
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECsiU2UAVuqdYR_12int_ops_i128.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECsiU2UAVuqdYR_12int_ops_i128.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECsiU2UAVuqdYR_12int_ops_i128.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECsiU2UAVuqdYR_12int_ops_i128.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i128, ptr %result, align 16
  %33 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_105, ptr %33, align 16
  store i8 0, ptr %_0, align 16
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i128, ptr %result, align 16
  %_86 = zext i32 %radix to i128
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %mul1, i128 %_85, i128 %_86) #17
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %40 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsiU2UAVuqdYR_12int_ops_i128(i32 %_89, i32 %radix) #17
  %41 = extractvalue { i32, i32 } %40, 0
  %42 = extractvalue { i32, i32 } %40, 1
  store i32 %41, ptr %_88, align 4
  %43 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %42, ptr %43, align 4
  %44 = load i32, ptr %_88, align 4
  %45 = getelementptr inbounds i8, ptr %_88, i64 4
  %46 = load i32, ptr %45, align 4
  %_91 = zext i32 %44 to i64
  %47 = trunc nuw i64 %_91 to i1
  br i1 %47, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %48, align 4
  %x = zext i32 %value to i128
  %49 = load i128, ptr %mul1, align 16
  %50 = getelementptr inbounds i8, ptr %mul1, i64 16
  %51 = load i128, ptr %50, align 16
  %_95 = trunc i128 %49 to i64
  %52 = trunc nuw i64 %_95 to i1
  br i1 %52, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %53, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb48:                                             ; preds = %bb46
  %54 = getelementptr inbounds i8, ptr %mul1, i64 16
  %value4 = load i128, ptr %54, align 16
  store i128 %value4, ptr %result, align 16
  %_100 = load i128, ptr %result, align 16
; call <i128>::checked_sub
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_subCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_99, i128 %_100, i128 %x) #17
  %55 = load i128, ptr %_99, align 16
  %56 = getelementptr inbounds i8, ptr %_99, i64 16
  %57 = load i128, ptr %56, align 16
  %_101 = trunc i128 %55 to i64
  %58 = trunc nuw i64 %_101 to i1
  br i1 %58, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %59, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb51:                                             ; preds = %bb48
  %60 = getelementptr inbounds i8, ptr %_99, i64 16
  %value5 = load i128, ptr %60, align 16
  store i128 %value5, ptr %result, align 16
  store ptr %rest.02, ptr %digits, align 8, !captures !159
  %61 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %61, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %62 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %62, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb31:                                             ; preds = %bb30
  %63 = load ptr, ptr %digits, align 8
  %64 = getelementptr inbounds i8, ptr %digits, i64 8
  %65 = load i64, ptr %64, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %63, i64 0
  %66 = load ptr, ptr %digits, align 8
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  %68 = load i64, ptr %67, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %66, i64 1
  %rest.18 = sub i64 %68, 1
  %_60 = load i128, ptr %result, align 16
  %_61 = zext i32 %radix to i128
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %mul, i128 %_60, i128 %_61) #17
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %69 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsiU2UAVuqdYR_12int_ops_i128(i32 %_64, i32 %radix) #17
  %70 = extractvalue { i32, i32 } %69, 0
  %71 = extractvalue { i32, i32 } %69, 1
  store i32 %70, ptr %_63, align 4
  %72 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %71, ptr %72, align 4
  %73 = load i32, ptr %_63, align 4
  %74 = getelementptr inbounds i8, ptr %_63, i64 4
  %75 = load i32, ptr %74, align 4
  %_66 = zext i32 %73 to i64
  %76 = trunc nuw i64 %_66 to i1
  br i1 %76, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %77 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %77, align 4
  %x10 = zext i32 %value9 to i128
  %78 = load i128, ptr %mul, align 16
  %79 = getelementptr inbounds i8, ptr %mul, i64 16
  %80 = load i128, ptr %79, align 16
  %_70 = trunc i128 %78 to i64
  %81 = trunc nuw i64 %_70 to i1
  br i1 %81, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %82 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %82, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb37:                                             ; preds = %bb35
  %83 = getelementptr inbounds i8, ptr %mul, i64 16
  %value11 = load i128, ptr %83, align 16
  store i128 %value11, ptr %result, align 16
  %_75 = load i128, ptr %result, align 16
; call <i128>::checked_add
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_addCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_74, i128 %_75, i128 %x10) #17
  %84 = load i128, ptr %_74, align 16
  %85 = getelementptr inbounds i8, ptr %_74, i64 16
  %86 = load i128, ptr %85, align 16
  %_76 = trunc i128 %84 to i64
  %87 = trunc nuw i64 %_76 to i1
  br i1 %87, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %88 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %88, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb40:                                             ; preds = %bb37
  %89 = getelementptr inbounds i8, ptr %_74, i64 16
  %value12 = load i128, ptr %89, align 16
  store i128 %value12, ptr %result, align 16
  store ptr %rest.07, ptr %digits, align 8, !captures !159
  %90 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %90, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %91, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %92 = load ptr, ptr %digits, align 8
  %93 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %93, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %94 = load ptr, ptr %digits, align 8
  %95 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %95, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %96 = load ptr, ptr %digits, align 8
  %97 = getelementptr inbounds i8, ptr %digits, i64 8
  %98 = load i64, ptr %97, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %96, i64 0
  %99 = load ptr, ptr %digits, align 8
  %100 = getelementptr inbounds i8, ptr %digits, i64 8
  %101 = load i64, ptr %100, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %99, i64 1
  %rest.115 = sub i64 %101, 1
  %_44 = load i128, ptr %result, align 16
  %_45 = zext i32 %radix to i128
  %102 = mul i128 %_44, %_45
  store i128 %102, ptr %result, align 16
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %103 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsiU2UAVuqdYR_12int_ops_i128(i32 %_47, i32 %radix) #17
  %104 = extractvalue { i32, i32 } %103, 0
  %105 = extractvalue { i32, i32 } %103, 1
  store i32 %104, ptr %_46, align 4
  %106 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %105, ptr %106, align 4
  %107 = load i32, ptr %_46, align 4
  %108 = getelementptr inbounds i8, ptr %_46, i64 4
  %109 = load i32, ptr %108, align 4
  %_49 = zext i32 %107 to i64
  %110 = trunc nuw i64 %_49 to i1
  br i1 %110, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %111 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %111, align 4
  %_53 = load i128, ptr %result, align 16
  %_54 = zext i32 %x16 to i128
  %112 = sub i128 %_53, %_54
  store i128 %112, ptr %result, align 16
  store ptr %rest.014, ptr %digits, align 8, !captures !159
  %113 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %113, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %114 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %114, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb19:                                             ; preds = %bb18
  %115 = load ptr, ptr %digits, align 8
  %116 = getelementptr inbounds i8, ptr %digits, i64 8
  %117 = load i64, ptr %116, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %115, i64 0
  %118 = load ptr, ptr %digits, align 8
  %119 = getelementptr inbounds i8, ptr %digits, i64 8
  %120 = load i64, ptr %119, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %118, i64 1
  %rest.119 = sub i64 %120, 1
  %_29 = load i128, ptr %result, align 16
  %_30 = zext i32 %radix to i128
  %121 = mul i128 %_29, %_30
  store i128 %121, ptr %result, align 16
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %122 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsiU2UAVuqdYR_12int_ops_i128(i32 %_32, i32 %radix) #17
  %123 = extractvalue { i32, i32 } %122, 0
  %124 = extractvalue { i32, i32 } %122, 1
  store i32 %123, ptr %_31, align 4
  %125 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %124, ptr %125, align 4
  %126 = load i32, ptr %_31, align 4
  %127 = getelementptr inbounds i8, ptr %_31, i64 4
  %128 = load i32, ptr %127, align 4
  %_34 = zext i32 %126 to i64
  %129 = trunc nuw i64 %_34 to i1
  br i1 %129, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %130 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %130, align 4
  %_38 = load i128, ptr %result, align 16
  %_39 = zext i32 %x20 to i128
  %131 = add i128 %_38, %_39
  store i128 %131, ptr %result, align 16
  store ptr %rest.018, ptr %digits, align 8, !captures !159
  %132 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %132, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %133 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %133, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsiU2UAVuqdYR_12int_ops_i128(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !160 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %args) #17
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #17
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsiU2UAVuqdYR_12int_ops_i128() unnamed_addr #4 !guid !161 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() unnamed_addr #0 !guid !162 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsiU2UAVuqdYR_12int_ops_i128(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !163 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCsiU2UAVuqdYR_12int_ops_i128(i32 %code, ptr %dst) unnamed_addr #0 !guid !164 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CsiU2UAVuqdYR_12int_ops_i128(i32 %code) #17
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CsiU2UAVuqdYR_12int_ops_i128(i32 %code) unnamed_addr #0 !guid !165 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::num::imp::int_sqrt::u16_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsiU2UAVuqdYR_12int_ops_i128(i16 %n) unnamed_addr #0 !guid !166 {
start:
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n1 = lshr i16 %n, 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.9957a1d51e1f25d58a58fc56d761d36e.0, i64 512, i1 false)
  %_9 = zext i16 %n1 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s2 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s2, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_12, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb1, %bb2.i
  %lo = and i16 %n, 255
  %_16 = zext i8 %r to i16
  %_15 = shl i16 %_16, 4
  %_17 = lshr i16 %lo, 4
  %numerator = or i16 %_15, %_17
  %_19 = zext i8 %s2 to i16
  %denominator = shl i16 %_19, 1
  %_21 = icmp eq i16 %denominator, 0
  br i1 %_21, label %panic3, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q = udiv i16 %numerator, %denominator
  %_24 = shl i8 %s2, 4
  %_23 = zext i8 %_24 to i16
  %3 = add i16 %_23, %q
  store i16 %3, ptr %s, align 2
  %_28 = load i16, ptr %s, align 2
  %_29 = load i16, ptr %s, align 2
  %4 = call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %_28, i16 %_29)
  %_5.0.i = extractvalue { i16, i1 } %4, 0
  %_5.1.i = extractvalue { i16, i1 } %4, 1
  %_27.0 = extractvalue { i16, i1 } %4, 0
  %_27.1 = extractvalue { i16, i1 } %4, 1
  br i1 %_27.1, label %bb6, label %bb5

panic3:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_73a63def61abd19c5b285b7e5bba6f74) #23
  unreachable

bb5:                                              ; preds = %bb3
  %_30 = icmp ugt i16 %_27.0, %n
  br i1 %_30, label %bb6, label %bb7

bb6:                                              ; preds = %bb5, %bb3
  %5 = load i16, ptr %s, align 2
  %6 = sub i16 %5, 1
  store i16 %6, ptr %s, align 2
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5
  %_0 = load i16, ptr %s, align 2
  ret i16 %_0
}

; core::num::imp::int_sqrt::u32_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsiU2UAVuqdYR_12int_ops_i128(i32 %n) unnamed_addr #0 !guid !167 {
start:
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n2 = lshr i32 %n, 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.9957a1d51e1f25d58a58fc56d761d36e.0, i64 512, i1 false)
  %_9 = zext i32 %n2 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s3 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r4 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s3, 0
; call core::ub_checks::check_language_ub
  %_2.i15 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i15, label %bb2.i16, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

bb2.i16:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_12, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17: ; preds = %bb1, %bb2.i16
  %_17 = lshr i32 %n, 16
  %n5 = trunc i32 %_17 to i16
  %lo = and i16 %n5, 255
  %_21 = zext i8 %r4 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s3 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic6, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic7, label %bb4

panic6:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s3, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic7:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_45, ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb8, %bb2.i
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %lo8 = and i32 %n, 65535
  %_52 = zext i16 %_48 to i32
  %_51 = shl i32 %_52, 8
  %_53 = lshr i32 %lo8, 8
  %numerator9 = or i32 %_51, %_53
  %_55 = zext i16 %_47 to i32
  %denominator10 = shl i32 %_55, 1
  %_57 = icmp eq i32 %denominator10, 0
  br i1 %_57, label %panic11, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q12 = udiv i32 %numerator9, %denominator10
  %_60 = shl i16 %_47, 8
  %_59 = zext i16 %_60 to i32
  %8 = add i32 %_59, %q12
  store i32 %8, ptr %s1, align 4
  %_64 = load i32, ptr %s1, align 4
  %_65 = load i32, ptr %s1, align 4
  %9 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_64, i32 %_65)
  %_5.0.i13 = extractvalue { i32, i1 } %9, 0
  %_5.1.i14 = extractvalue { i32, i1 } %9, 1
  %_63.0 = extractvalue { i32, i1 } %9, 0
  %_63.1 = extractvalue { i32, i1 } %9, 1
  br i1 %_63.1, label %bb13, label %bb12

panic11:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_d1e64d3a180065bd6a022925cad00717) #23
  unreachable

bb12:                                             ; preds = %bb10
  %_66 = icmp ugt i32 %_63.0, %n
  br i1 %_66, label %bb13, label %bb14

bb13:                                             ; preds = %bb12, %bb10
  %10 = load i32, ptr %s1, align 4
  %11 = sub i32 %10, 1
  store i32 %11, ptr %s1, align 4
  br label %bb14

bb14:                                             ; preds = %bb13, %bb12
  %_0 = load i32, ptr %s1, align 4
  ret i32 %_0
}

; core::num::imp::int_sqrt::u64_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCsiU2UAVuqdYR_12int_ops_i128(i64 %n) unnamed_addr #0 !guid !168 {
start:
  %s3 = alloca [8 x i8], align 8
  %r2 = alloca [4 x i8], align 4
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n4 = lshr i64 %n, 56
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.9957a1d51e1f25d58a58fc56d761d36e.0, i64 512, i1 false)
  %_10 = icmp ult i64 %n4, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %s5 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r6 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s5, 0
; call core::ub_checks::check_language_ub
  %_2.i31 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i31, label %bb2.i32, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

bb2.i32:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_12, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33: ; preds = %bb1, %bb2.i32
  %_17 = lshr i64 %n, 48
  %n7 = trunc i64 %_17 to i16
  %lo = and i16 %n7, 255
  %_21 = zext i8 %r6 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s5 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic8, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %n4, i64 256, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic9, label %bb4

panic8:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s5, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic9:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i28 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i28, label %bb2.i29, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

bb2.i29:                                          ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_45, ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30: ; preds = %bb8, %bb2.i29
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %_53 = lshr i64 %n, 32
  %n10 = trunc i64 %_53 to i32
  %lo11 = and i32 %n10, 65535
  %_57 = zext i16 %_48 to i32
  %_56 = shl i32 %_57, 8
  %_58 = lshr i32 %lo11, 8
  %numerator12 = or i32 %_56, %_58
  %_60 = zext i16 %_47 to i32
  %denominator13 = shl i32 %_60, 1
  %_62 = icmp eq i32 %denominator13, 0
  br i1 %_62, label %panic14, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
  %q15 = udiv i32 %numerator12, %denominator13
  %_64 = icmp eq i32 %denominator13, 0
  br i1 %_64, label %panic16, label %bb11

panic14:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #23
  unreachable

bb11:                                             ; preds = %bb10
  %u17 = urem i32 %numerator12, %denominator13
  %_67 = shl i16 %_47, 8
  %_66 = zext i16 %_67 to i32
  %8 = add i32 %_66, %q15
  store i32 %8, ptr %s1, align 4
  %_72 = shl i32 %u17, 8
  %_73 = and i32 %lo11, 255
  %_71 = or i32 %_72, %_73
  %_74 = mul i32 %q15, %q15
  %_5.0.i24 = sub i32 %_71, %_74
  %_5.1.i25 = icmp ult i32 %_71, %_74
  %9 = insertvalue { i32, i1 } poison, i32 %_5.0.i24, 0
  %10 = insertvalue { i32, i1 } %9, i1 %_5.1.i25, 1
  %_70.0 = extractvalue { i32, i1 } %10, 0
  %_70.1 = extractvalue { i32, i1 } %10, 1
  store i32 %_70.0, ptr %r2, align 4
  br i1 %_70.1, label %bb13, label %bb15

panic16:                                          ; preds = %bb10
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #23
  unreachable

bb15:                                             ; preds = %bb13, %bb11
  %_82 = load i32, ptr %s1, align 4
  %_81 = icmp ne i32 %_82, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb15
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_81, ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb15, %bb2.i
  %_83 = load i32, ptr %s1, align 4
  %_84 = load i32, ptr %r2, align 4
  %lo18 = and i64 %n, 4294967295
  %_88 = zext i32 %_84 to i64
  %_87 = shl i64 %_88, 16
  %_89 = lshr i64 %lo18, 16
  %numerator19 = or i64 %_87, %_89
  %_91 = zext i32 %_83 to i64
  %denominator20 = shl i64 %_91, 1
  %_93 = icmp eq i64 %denominator20, 0
  br i1 %_93, label %panic21, label %bb17

bb13:                                             ; preds = %bb11
  %_76 = load i32, ptr %r2, align 4
  %_79 = load i32, ptr %s1, align 4
  %_78 = mul i32 2, %_79
  %_77 = sub i32 %_78, 1
  %_0.i23 = add i32 %_76, %_77
  store i32 %_0.i23, ptr %r2, align 4
  %11 = load i32, ptr %s1, align 4
  %12 = sub i32 %11, 1
  store i32 %12, ptr %s1, align 4
  br label %bb15

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q22 = udiv i64 %numerator19, %denominator20
  %_96 = shl i32 %_83, 16
  %_95 = zext i32 %_96 to i64
  %13 = add i64 %_95, %q22
  store i64 %13, ptr %s3, align 8
  %_100 = load i64, ptr %s3, align 8
  %_101 = load i64, ptr %s3, align 8
  %14 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_100, i64 %_101)
  %_5.0.i26 = extractvalue { i64, i1 } %14, 0
  %_5.1.i27 = extractvalue { i64, i1 } %14, 1
  %_99.0 = extractvalue { i64, i1 } %14, 0
  %_99.1 = extractvalue { i64, i1 } %14, 1
  br i1 %_99.1, label %bb20, label %bb19

panic21:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cb646754bd05cd238e749888201337e6) #23
  unreachable

bb19:                                             ; preds = %bb17
  %_102 = icmp ugt i64 %_99.0, %n
  br i1 %_102, label %bb20, label %bb21

bb20:                                             ; preds = %bb19, %bb17
  %15 = load i64, ptr %s3, align 8
  %16 = sub i64 %15, 1
  store i64 %16, ptr %s3, align 8
  br label %bb21

bb21:                                             ; preds = %bb20, %bb19
  %_0 = load i64, ptr %s3, align 8
  ret i64 %_0
}

; core::num::imp::int_sqrt::u128_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt11u128_stagesCsiU2UAVuqdYR_12int_ops_i128(i128 %n) unnamed_addr #0 !guid !169 {
start:
  %0 = alloca [32 x i8], align 16
  %s5 = alloca [16 x i8], align 16
  %r4 = alloca [8 x i8], align 8
  %s3 = alloca [8 x i8], align 8
  %r2 = alloca [4 x i8], align 4
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n6 = lshr i128 %n, 120
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.9957a1d51e1f25d58a58fc56d761d36e.0, i64 512, i1 false)
  %_9 = trunc i128 %n6 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s7 = load i8, ptr %1, align 1
  %2 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %3 = getelementptr inbounds i8, ptr %2, i64 1
  %r8 = load i8, ptr %3, align 1
  %_12 = icmp ne i8 %s7, 0
; call core::ub_checks::check_language_ub
  %_2.i47 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i47, label %bb2.i48, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49

bb2.i48:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_12, ptr align 8 @alloc_eda7b11e07c58ae313ac1fad01d041e9) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49: ; preds = %bb1, %bb2.i48
  %_17 = lshr i128 %n, 112
  %n9 = trunc i128 %_17 to i16
  %lo = and i16 %n9, 255
  %_21 = zext i8 %r8 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s7 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic10, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_eda7b11e07c58ae313ac1fad01d041e9) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic11, label %bb4

panic10:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit49
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_6042291b1954087ab71387f1f17f0449) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s7, 4
  %_30 = zext i8 %_31 to i16
  %4 = add i16 %_30, %q
  store i16 %4, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %5 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %6 = insertvalue { i16, i1 } %5, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %6, 0
  %_34.1 = extractvalue { i16, i1 } %6, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic11:                                          ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_6042291b1954087ab71387f1f17f0449) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i44, label %bb2.i45, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46

bb2.i45:                                          ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_45, ptr align 8 @alloc_6042291b1954087ab71387f1f17f0449) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46: ; preds = %bb8, %bb2.i45
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %_53 = lshr i128 %n, 96
  %n12 = trunc i128 %_53 to i32
  %lo13 = and i32 %n12, 65535
  %_57 = zext i16 %_48 to i32
  %_56 = shl i32 %_57, 8
  %_58 = lshr i32 %lo13, 8
  %numerator14 = or i32 %_56, %_58
  %_60 = zext i16 %_47 to i32
  %denominator15 = shl i32 %_60, 1
  %_62 = icmp eq i32 %denominator15, 0
  br i1 %_62, label %panic16, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %7 = load i16, ptr %s, align 2
  %8 = sub i16 %7, 1
  store i16 %8, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46
  %q17 = udiv i32 %numerator14, %denominator15
  %_64 = icmp eq i32 %denominator15, 0
  br i1 %_64, label %panic18, label %bb11

panic16:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit46
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_ce4d3b1f48911fd97fc8507578e88cdb) #23
  unreachable

bb11:                                             ; preds = %bb10
  %u19 = urem i32 %numerator14, %denominator15
  %_67 = shl i16 %_47, 8
  %_66 = zext i16 %_67 to i32
  %9 = add i32 %_66, %q17
  store i32 %9, ptr %s1, align 4
  %_72 = shl i32 %u19, 8
  %_73 = and i32 %lo13, 255
  %_71 = or i32 %_72, %_73
  %_74 = mul i32 %q17, %q17
  %_5.0.i34 = sub i32 %_71, %_74
  %_5.1.i35 = icmp ult i32 %_71, %_74
  %10 = insertvalue { i32, i1 } poison, i32 %_5.0.i34, 0
  %11 = insertvalue { i32, i1 } %10, i1 %_5.1.i35, 1
  %_70.0 = extractvalue { i32, i1 } %11, 0
  %_70.1 = extractvalue { i32, i1 } %11, 1
  store i32 %_70.0, ptr %r2, align 4
  br i1 %_70.1, label %bb13, label %bb15

panic18:                                          ; preds = %bb10
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_ce4d3b1f48911fd97fc8507578e88cdb) #23
  unreachable

bb15:                                             ; preds = %bb13, %bb11
  %_82 = load i32, ptr %s1, align 4
  %_81 = icmp ne i32 %_82, 0
; call core::ub_checks::check_language_ub
  %_2.i41 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i41, label %bb2.i42, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43

bb2.i42:                                          ; preds = %bb15
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_81, ptr align 8 @alloc_ce4d3b1f48911fd97fc8507578e88cdb) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43: ; preds = %bb15, %bb2.i42
  %_83 = load i32, ptr %s1, align 4
  %_84 = load i32, ptr %r2, align 4
  %_89 = lshr i128 %n, 64
  %n20 = trunc i128 %_89 to i64
  %lo21 = and i64 %n20, 4294967295
  %_93 = zext i32 %_84 to i64
  %_92 = shl i64 %_93, 16
  %_94 = lshr i64 %lo21, 16
  %numerator22 = or i64 %_92, %_94
  %_96 = zext i32 %_83 to i64
  %denominator23 = shl i64 %_96, 1
  %_98 = icmp eq i64 %denominator23, 0
  br i1 %_98, label %panic24, label %bb17

bb13:                                             ; preds = %bb11
  %_76 = load i32, ptr %r2, align 4
  %_79 = load i32, ptr %s1, align 4
  %_78 = mul i32 2, %_79
  %_77 = sub i32 %_78, 1
  %_0.i33 = add i32 %_76, %_77
  store i32 %_0.i33, ptr %r2, align 4
  %12 = load i32, ptr %s1, align 4
  %13 = sub i32 %12, 1
  store i32 %13, ptr %s1, align 4
  br label %bb15

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43
  %q25 = udiv i64 %numerator22, %denominator23
  %_100 = icmp eq i64 %denominator23, 0
  br i1 %_100, label %panic26, label %bb18

panic24:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit43
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_2a09b92e9319e8cf7ffdc293d51a865d) #23
  unreachable

bb18:                                             ; preds = %bb17
  %u27 = urem i64 %numerator22, %denominator23
  %_103 = shl i32 %_83, 16
  %_102 = zext i32 %_103 to i64
  %14 = add i64 %_102, %q25
  store i64 %14, ptr %s3, align 8
  %_108 = shl i64 %u27, 16
  %_109 = and i64 %lo21, 65535
  %_107 = or i64 %_108, %_109
  %_110 = mul i64 %q25, %q25
  %_5.0.i37 = sub i64 %_107, %_110
  %_5.1.i38 = icmp ult i64 %_107, %_110
  %15 = insertvalue { i64, i1 } poison, i64 %_5.0.i37, 0
  %16 = insertvalue { i64, i1 } %15, i1 %_5.1.i38, 1
  %_106.0 = extractvalue { i64, i1 } %16, 0
  %_106.1 = extractvalue { i64, i1 } %16, 1
  store i64 %_106.0, ptr %r4, align 8
  br i1 %_106.1, label %bb20, label %bb22

panic26:                                          ; preds = %bb17
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_2a09b92e9319e8cf7ffdc293d51a865d) #23
  unreachable

bb22:                                             ; preds = %bb20, %bb18
  %_118 = load i64, ptr %s3, align 8
  %_117 = icmp ne i64 %_118, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsiU2UAVuqdYR_12int_ops_i128() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb22
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %_117, ptr align 8 @alloc_2a09b92e9319e8cf7ffdc293d51a865d) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb22, %bb2.i
  %_119 = load i64, ptr %s3, align 8
  %_120 = load i64, ptr %r4, align 8
  %lo28 = and i128 %n, 18446744073709551615
  %_124 = zext i64 %_120 to i128
  %_123 = shl i128 %_124, 32
  %_125 = lshr i128 %lo28, 32
  %numerator29 = or i128 %_123, %_125
  %_127 = zext i64 %_119 to i128
  %denominator30 = shl i128 %_127, 1
  %_129 = icmp eq i128 %denominator30, 0
  br i1 %_129, label %panic31, label %bb24

bb20:                                             ; preds = %bb18
  %_112 = load i64, ptr %r4, align 8
  %_115 = load i64, ptr %s3, align 8
  %_114 = mul i64 2, %_115
  %_113 = sub i64 %_114, 1
  %_0.i36 = add i64 %_112, %_113
  store i64 %_0.i36, ptr %r4, align 8
  %17 = load i64, ptr %s3, align 8
  %18 = sub i64 %17, 1
  store i64 %18, ptr %s3, align 8
  br label %bb22

bb24:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q32 = udiv i128 %numerator29, %denominator30
  %_132 = shl i64 %_119, 32
  %_131 = zext i64 %_132 to i128
  %19 = add i128 %_131, %q32
  store i128 %19, ptr %s5, align 16
  %_136 = load i128, ptr %s5, align 16
  %_137 = load i128, ptr %s5, align 16
  %20 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_136, i128 %_137)
  %_5.0.i39 = extractvalue { i128, i1 } %20, 0
  %_5.1.i40 = extractvalue { i128, i1 } %20, 1
  store i128 %_5.0.i39, ptr %0, align 16
  %21 = getelementptr inbounds i8, ptr %0, i64 16
  %22 = zext i1 %_5.1.i40 to i8
  store i8 %22, ptr %21, align 16
  %_135.0 = load i128, ptr %0, align 16
  %23 = getelementptr inbounds i8, ptr %0, i64 16
  %24 = load i8, ptr %23, align 16
  %_135.1 = trunc nuw i8 %24 to i1
  br i1 %_135.1, label %bb27, label %bb26

panic31:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cdc8401a47de3b375010692dbb496696) #23
  unreachable

bb26:                                             ; preds = %bb24
  %_138 = icmp ugt i128 %_135.0, %n
  br i1 %_138, label %bb27, label %bb28

bb27:                                             ; preds = %bb26, %bb24
  %25 = load i128, ptr %s5, align 16
  %26 = sub i128 %25, 1
  store i128 %26, ptr %s5, align 16
  br label %bb28

bb28:                                             ; preds = %bb27, %bb26
  %_0 = load i128, ptr %s5, align 16
  ret i128 %_0
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsiU2UAVuqdYR_12int_ops_i128(i8 %n) unnamed_addr #0 !guid !170 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.9957a1d51e1f25d58a58fc56d761d36e.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #23
  unreachable
}

; core::num::imp::int_sqrt::u16
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsiU2UAVuqdYR_12int_ops_i128(i16 %0) unnamed_addr #0 !guid !171 {
start:
  %_0 = alloca [2 x i8], align 2
  %n = alloca [2 x i8], align 2
  store i16 %0, ptr %n, align 2
  %_3 = load i16, ptr %n, align 2
  %_2 = icmp ule i16 %_3, 255
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i16, ptr %n, align 2
  %1 = call i16 @llvm.ctlz.i16(i16 %_10, i1 false)
  %_0.i = zext i16 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i16, ptr %n, align 2
  %3 = and i32 %normalization_shift, 15
  %4 = trunc i32 %3 to i16
  %5 = shl i16 %2, %4
  store i16 %5, ptr %n, align 2
  %_12 = load i16, ptr %n, align 2
; call core::num::imp::int_sqrt::u16_stages
  %s = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsiU2UAVuqdYR_12int_ops_i128(i16 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 15
  %7 = trunc i32 %6 to i16
  %8 = lshr i16 %s, %7
  store i16 %8, ptr %_0, align 2
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i16, ptr %n, align 2
  %_6 = trunc i16 %_7 to i8
; call core::num::imp::int_sqrt::u8
  %_5 = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsiU2UAVuqdYR_12int_ops_i128(i8 %_6) #17
  %9 = zext i8 %_5 to i16
  store i16 %9, ptr %_0, align 2
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i16, ptr %_0, align 2
  ret i16 %10
}

; core::num::imp::int_sqrt::u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32CsiU2UAVuqdYR_12int_ops_i128(i32 %0) unnamed_addr #0 !guid !172 {
start:
  %_0 = alloca [4 x i8], align 4
  %n = alloca [4 x i8], align 4
  store i32 %0, ptr %n, align 4
  %_3 = load i32, ptr %n, align 4
  %_2 = icmp ule i32 %_3, 65535
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i32, ptr %n, align 4
  %_0.i = call i32 @llvm.ctlz.i32(i32 %_10, i1 false)
  %normalization_shift = and i32 %_0.i, -2
  %1 = load i32, ptr %n, align 4
  %2 = and i32 %normalization_shift, 31
  %3 = shl i32 %1, %2
  store i32 %3, ptr %n, align 4
  %_12 = load i32, ptr %n, align 4
; call core::num::imp::int_sqrt::u32_stages
  %s = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsiU2UAVuqdYR_12int_ops_i128(i32 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %4 = and i32 %denormalization_shift, 31
  %5 = lshr i32 %s, %4
  store i32 %5, ptr %_0, align 4
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i32, ptr %n, align 4
  %_6 = trunc i32 %_7 to i16
; call core::num::imp::int_sqrt::u16
  %_5 = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsiU2UAVuqdYR_12int_ops_i128(i16 %_6) #17
  %6 = zext i16 %_5 to i32
  store i32 %6, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %7 = load i32, ptr %_0, align 4
  ret i32 %7
}

; core::num::imp::int_sqrt::u64
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64CsiU2UAVuqdYR_12int_ops_i128(i64 %0) unnamed_addr #0 !guid !173 {
start:
  %_0 = alloca [8 x i8], align 8
  %n = alloca [8 x i8], align 8
  store i64 %0, ptr %n, align 8
  %_3 = load i64, ptr %n, align 8
  %_2 = icmp ule i64 %_3, 4294967295
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i64, ptr %n, align 8
  %1 = call i64 @llvm.ctlz.i64(i64 %_10, i1 false)
  %_0.i = trunc i64 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i64, ptr %n, align 8
  %3 = and i32 %normalization_shift, 63
  %4 = zext i32 %3 to i64
  %5 = shl i64 %2, %4
  store i64 %5, ptr %n, align 8
  %_12 = load i64, ptr %n, align 8
; call core::num::imp::int_sqrt::u64_stages
  %s = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCsiU2UAVuqdYR_12int_ops_i128(i64 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 63
  %7 = zext i32 %6 to i64
  %8 = lshr i64 %s, %7
  store i64 %8, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %n, align 8
  %_6 = trunc i64 %_7 to i32
; call core::num::imp::int_sqrt::u32
  %_5 = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32CsiU2UAVuqdYR_12int_ops_i128(i32 %_6) #17
  %9 = zext i32 %_5 to i64
  store i64 %9, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i64, ptr %_0, align 8
  ret i64 %10
}

; core::num::imp::int_sqrt::u128
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt4u128CsiU2UAVuqdYR_12int_ops_i128(i128 %0) unnamed_addr #0 !guid !174 {
start:
  %_0 = alloca [16 x i8], align 16
  %n = alloca [16 x i8], align 16
  store i128 %0, ptr %n, align 16
  %_3 = load i128, ptr %n, align 16
  %_2 = icmp ule i128 %_3, 18446744073709551615
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i128, ptr %n, align 16
  %1 = call i128 @llvm.ctlz.i128(i128 %_10, i1 false)
  %_0.i = trunc i128 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i128, ptr %n, align 16
  %3 = and i32 %normalization_shift, 127
  %4 = zext i32 %3 to i128
  %5 = shl i128 %2, %4
  store i128 %5, ptr %n, align 16
  %_12 = load i128, ptr %n, align 16
; call core::num::imp::int_sqrt::u128_stages
  %s = call i128 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt11u128_stagesCsiU2UAVuqdYR_12int_ops_i128(i128 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 127
  %7 = zext i32 %6 to i128
  %8 = lshr i128 %s, %7
  store i128 %8, ptr %_0, align 16
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i128, ptr %n, align 16
  %_6 = trunc i128 %_7 to i64
; call core::num::imp::int_sqrt::u64
  %_5 = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64CsiU2UAVuqdYR_12int_ops_i128(i64 %_6) #17
  %9 = zext i64 %_5 to i128
  store i128 %9, ptr %_0, align 16
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i128, ptr %_0, align 16
  ret i128 %10
}

; <i128>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !175 {
start:
  %_2 = icmp ult i32 %rhs, 128
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsiU2UAVuqdYR_12int_ops_i128(ptr @alloc_a61ecf1bbb59a9a75a6a223b3f565d28, i64 185)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <i128>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shr18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !176 {
start:
  %_2 = icmp ult i32 %rhs, 128
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsiU2UAVuqdYR_12int_ops_i128(ptr @alloc_cbb3b5e3f39ac9cfe0752e276da07645, i64 185)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <u128>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_mul18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i128 %lhs, i128 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !177 {
start:
  %1 = alloca [32 x i8], align 16
  %2 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %lhs, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %2, 0
  %_5.1.i = extractvalue { i128, i1 } %2, 1
  store i128 %_5.0.i, ptr %1, align 16
  %3 = getelementptr inbounds i8, ptr %1, i64 16
  %4 = zext i1 %_5.1.i to i8
  store i8 %4, ptr %3, align 16
  br label %bb1

terminate:                                        ; preds = %bb2
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = load i128, ptr %1, align 16
  %6 = getelementptr inbounds i8, ptr %1, i64 16
  %7 = load i8, ptr %6, align 16
  %_4.1 = trunc nuw i8 %7 to i1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %8 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsiU2UAVuqdYR_12int_ops_i128(ptr @alloc_8889105080bbd684fa4b755988461744, i64 185)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %8, 0
  %_6.1 = extractvalue { ptr, ptr } %8, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsiU2UAVuqdYR_12int_ops_i128(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !178 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsiU2UAVuqdYR_12int_ops_i128(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsiU2UAVuqdYR_12int_ops_i128() unnamed_addr #0 !guid !179 {
start:
  ret i1 true
}

; <(i128, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTnbENtB6_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #1 !guid !180 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <i128 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1Q_NtCs7CppTae75M1_5alloc6stringnNtB6_12SpecToString14spec_to_stringCsiU2UAVuqdYR_12int_ops_i128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !181 {
start:
  %0 = alloca [16 x i8], align 8
  %_19 = alloca [1 x i8], align 1
  %_11 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  %out = alloca [24 x i8], align 8
  %buf = alloca [39 x i8], align 1
  store i8 0, ptr %_19, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 39, i1 false)
  %_6 = load i128, ptr %self, align 16
  %_5 = icmp slt i128 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCsiU2UAVuqdYR_12int_ops_i128(ptr sret([24 x i8]) align 8 %_11, i64 39)
          to label %bb5 unwind label %cleanup

bb2:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCsiU2UAVuqdYR_12int_ops_i128(ptr sret([24 x i8]) align 8 %_7, i64 40)
          to label %bb3 unwind label %cleanup

bb12:                                             ; preds = %cleanup
  %1 = load i8, ptr %_19, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb11, label %bb10

cleanup:                                          ; preds = %bb8, %bb7, %bb6, %bb3, %bb2, %bb4
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb12

bb5:                                              ; preds = %bb4
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_11, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb13, %bb5
  %_16 = load i128, ptr %self, align 16
; invoke <i128>::unsigned_abs
  %_15 = invoke i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCsiU2UAVuqdYR_12int_ops_i128(i128 %_16)
          to label %bb7 unwind label %cleanup

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_7, i64 24, i1 false)
; invoke <alloc::string::String>::push
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %out, i32 45)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb3
  br label %bb6

bb7:                                              ; preds = %bb6
; invoke <u128>::_fmt
  %7 = invoke { ptr, i64 } @_RNvMs0_NtNtCsl10jNU3mE6R_4core3fmt3numo4__fmt(i128 %_15, ptr %buf, i64 39)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %_14.0 = extractvalue { ptr, i64 } %7, 0
  %_14.1 = extractvalue { ptr, i64 } %7, 1
; invoke <alloc::string::String>::push_str
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %out, ptr %_14.0, i64 %_14.1)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %out, i64 24, i1 false)
  store i8 0, ptr %_19, align 1
  ret void

bb10:                                             ; preds = %bb11, %bb12
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb11:                                             ; preds = %bb12
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %out) #24
          to label %bb10 unwind label %terminate

terminate:                                        ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !182 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !183 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&i128 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRnNtB6_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !184 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i128 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <i128 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringnNtB5_8ToString9to_stringCsiU2UAVuqdYR_12int_ops_i128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) unnamed_addr #0 !guid !185 {
start:
; call <i128 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1Q_NtCs7CppTae75M1_5alloc6stringnNtB6_12SpecToString14spec_to_stringCsiU2UAVuqdYR_12int_ops_i128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) #17
  ret void
}

; <core::option::Option<i128> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionnENtNtB7_3fmt5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !186 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i128, ptr %self, align 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i128, ptr %1, align 16
  %_3 = trunc i128 %0 to i64
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %4, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.1)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <i128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !187 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsiU2UAVuqdYR_12int_ops_i128() unnamed_addr #0 !guid !188 {
start:
  ret i8 0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !189 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !190 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <i128 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXss_NtCsl10jNU3mE6R_4core3numnNtNtNtB7_3str6traits7FromStr8from_strCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !191 {
start:
; call <i128>::from_str_radix
  call void @_RNvMst_NtCsl10jNU3mE6R_4core3numn14from_str_radixCsiU2UAVuqdYR_12int_ops_i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 10) #17
  ret void
}

; <core::result::Result<i128, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultnNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsiU2UAVuqdYR_12int_ops_i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !192 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsiU2UAVuqdYR_12int_ops_i128(ptr %_1) unnamed_addr #0 !guid !193 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsiU2UAVuqdYR_12int_ops_i128(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !194 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsiU2UAVuqdYR_12int_ops_i128(ptr align 8 %_1) #17
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i128 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsH_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_6Binary3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16) unnamed_addr #0

; <core::ptr::non_null::NonNull<u128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr) unnamed_addr #0

; <u128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsJ_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Octal3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fshl.i128(i128, i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fshr.i128(i128, i128, i128) #9

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptosi.sat.i128.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.smul.with.overflow.i128(i128, i128) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <alloc::vec::Vec<u8>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8, i64) unnamed_addr #1

; <alloc::vec::Vec<u8>>::extend_from_slice
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8, ptr, i64) unnamed_addr #1

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; <core::num::nonzero::NonZero<u128>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3getB9_(i128) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctlz.i128(i128, i1 immarg) #10

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #11

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i128(i128) #12

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.sadd.sat.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ssub.sat.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.sadd.with.overflow.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.ssub.with.overflow.i128(i128, i128) #9

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #11

; core::num::imp::int_sqrt::panic_for_negative_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8) unnamed_addr #11

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctlz.i16(i16, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.umul.with.overflow.i16(i16, i16) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctpop.i128(i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.bswap.i128(i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.bitreverse.i128(i128) #9

; <core::num::nonzero::NonZero<u128>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3newB9_(i128) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.cttz.i128(i128, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.umul.with.overflow.i128(i128, i128) #9

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #13

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #14

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #15

; <u128>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMs0_NtNtCsl10jNU3mE6R_4core3fmt3numo4__fmt(i128, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #16 !guid !195 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsiU2UAVuqdYR_12int_ops_i128(ptr @_RNvCsiU2UAVuqdYR_12int_ops_i1284main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #13 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #16 = { nonlazybind "target-cpu"="x86-64" }
attributes #17 = { inlinehint }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noreturn }
attributes #20 = { noinline }
attributes #21 = { nounwind }
attributes #22 = { inlinehint nounwind }
attributes #23 = { noinline noreturn }
attributes #24 = { cold }
attributes #25 = { noinline noreturn nounwind }

!llvm.module.flags = !{!69, !70, !71, !72}
!llvm.ident = !{!73}

!0 = !{i64 -3601157498903211692}
!1 = !{i64 -8550374735036965566}
!2 = !{i64 -7254621929536980292}
!3 = !{i64 285836590106158574}
!4 = !{i64 -2132799809478716288}
!5 = !{i64 -6003226178239014995}
!6 = !{i64 -3588451178518296615}
!7 = !{i64 -5530113749937038809}
!8 = !{i64 8800378433703622866}
!9 = !{i64 -8463768033654568078}
!10 = !{i64 5138447698467686413}
!11 = !{i64 -4374763960452745541}
!12 = !{i64 -8684801430754729604}
!13 = !{i64 -7462543509011707964}
!14 = !{i64 2511857365515285211}
!15 = !{i64 -1105476390054082468}
!16 = !{i64 5767472400336861009}
!17 = !{i64 -8896006404453301101}
!18 = !{i64 -2043851658750296571}
!19 = !{i64 5868573745163690442}
!20 = !{i64 -5709128359172431471}
!21 = !{i64 7304028700110654714}
!22 = !{i64 6723997885266224186}
!23 = !{i64 -3832728760795368614}
!24 = !{i64 6334551558442307207}
!25 = !{i64 1550613594388281421}
!26 = !{i64 649722104527370037}
!27 = !{i64 5095478912206921949}
!28 = !{i64 -1245350169439823982}
!29 = !{i64 -7409093618667876171}
!30 = !{i64 9117668012583317218}
!31 = !{i64 1238536173188534362}
!32 = !{i64 -428763378138272297}
!33 = !{i64 -645149515576920067}
!34 = !{i64 -3422169557898824647}
!35 = !{i64 4302861196641545853}
!36 = !{i64 2419279028528125723}
!37 = !{i64 -1800068842489903532}
!38 = !{i64 6423696553816313503}
!39 = !{i64 495915414376455868}
!40 = !{i64 5636984177486049162}
!41 = !{i64 -6490267743237658979}
!42 = !{i64 4821660325719296216}
!43 = !{i64 -2525696626631183215}
!44 = !{i64 1295404490904115738}
!45 = !{i64 -7019789185356701421}
!46 = !{i64 4351805882128509108}
!47 = !{i64 -6297272537744792483}
!48 = !{i64 -5613390436522743464}
!49 = !{i64 8244036402466761786}
!50 = !{i64 -4171201976956585768}
!51 = !{i64 192488654428054433}
!52 = !{i64 -1199376974182839865}
!53 = !{i64 5794851808440603685}
!54 = !{i64 -7043862200137813246}
!55 = !{i64 -1040994585811334764}
!56 = !{i64 4915723696948684983}
!57 = !{i64 -4457237315851897130}
!58 = !{i64 -5749128453832538990}
!59 = !{i64 -6138489762629589650}
!60 = !{i64 -7844015982351367609}
!61 = !{i64 -2058094396971616591}
!62 = !{i64 3407870920739101671}
!63 = !{i64 6616587870367814979}
!64 = !{i64 -7086880324138751398}
!65 = !{i64 9114956085445259938}
!66 = !{i64 -1097121331509188972}
!67 = !{i64 2829261676826072007}
!68 = !{i64 -6734301731409686268}
!69 = !{i32 8, !"PIC Level", i32 2}
!70 = !{i32 7, !"PIE Level", i32 2}
!71 = !{i32 2, !"RtLibUseGOT", i32 1}
!72 = !{i32 7, !"uwtable", i32 2}
!73 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!74 = !{i64 1111632156908651871}
!75 = !{i64 -8284539619423661392}
!76 = !{i64 8610035915761918873}
!77 = !{i64 588658177229323088}
!78 = !{i64 3405027200229402645}
!79 = !{i64 -1701014902958590901}
!80 = !{i64 2643745657609149631}
!81 = !{i64 -1321789108059144419}
!82 = !{i64 7898791019112946970}
!83 = !{i64 -5783830180530096267}
!84 = !{i64 7164571173373730089}
!85 = !{i64 3564017159927007356}
!86 = !{i64 7785346584492122516}
!87 = !{i64 2385868127001259044}
!88 = !{i64 1764361945446047917}
!89 = !{i64 6000261065481223510}
!90 = !{i64 -6965334426028683511}
!91 = !{i64 1998191010082807468}
!92 = !{i64 5965827668755953092}
!93 = !{i64 -4293266730628255025}
!94 = !{i64 4351251516766989990}
!95 = !{i64 2383081502182562886}
!96 = !{i64 -7803414316831771787}
!97 = !{i64 -1220134419000986538}
!98 = !{i64 2735439900282022967}
!99 = !{i64 3336321965691979928}
!100 = !{i64 -6244370707418414738}
!101 = !{i64 -1595270776754511625}
!102 = !{i64 8126570653543338760}
!103 = !{i64 1318434701094649}
!104 = !{i64 8789174008024185772}
!105 = !{i64 5775555663633642001}
!106 = !{i64 3373866208412130729}
!107 = !{i64 8019844994377901817}
!108 = !{i64 -1860141417409885772}
!109 = !{i64 5738805119774096009}
!110 = !{i64 5812528418967116550}
!111 = !{i64 -3137021619285485063}
!112 = !{i64 -5642526562460036893}
!113 = !{i64 -6244887477698910250}
!114 = !{i64 -3031060352556376330}
!115 = !{i64 -3550451090405308031}
!116 = !{i64 -2052127001778450324}
!117 = !{i64 -3267336969933167994}
!118 = !{i64 2012153401210365977}
!119 = !{i64 -7232639363728933312}
!120 = !{i64 -659153818870407060}
!121 = !{i64 -2381541699054892906}
!122 = !{i64 4006393673249519698}
!123 = !{i64 -3979020446451586354}
!124 = !{i64 -93116407396504849}
!125 = !{i64 7973875697495664713}
!126 = !{i64 -5311007468769033341}
!127 = !{i64 2217050956218741156}
!128 = !{i64 -4805699864679197052}
!129 = !{i64 4102642560292483113}
!130 = !{i64 -4673097784188221954}
!131 = !{i64 6565130226545511696}
!132 = !{i64 659777847367859255}
!133 = !{i64 -6267902706365200525}
!134 = !{i64 6109408597480223516}
!135 = !{i64 5648826699896197851}
!136 = !{i64 -3349889189623398203}
!137 = !{i64 -5161411587628956470}
!138 = !{i64 6529679073588109221}
!139 = !{i64 -4952101755907161343}
!140 = !{i64 6692937391977154553}
!141 = !{i64 -4957793909731022298}
!142 = !{i64 3050485884156004938}
!143 = !{i64 -8395988370776200521}
!144 = !{i64 4768113744131229966}
!145 = !{i64 1125196129172780968}
!146 = !{i64 -4297567994585723953}
!147 = !{i64 7563039417101708392}
!148 = !{i64 4406510213824204479}
!149 = !{i64 -8283643302210363121}
!150 = !{i64 -3620473908087814962}
!151 = !{i64 7448311144837702258}
!152 = !{i64 -5607045578395283975}
!153 = !{i64 -3141823315609885641}
!154 = !{i64 7028846311698028151}
!155 = !{i64 -1453906726157901093}
!156 = !{i64 2787869044029368376}
!157 = !{i64 7058075540163157248}
!158 = !{i64 -7123450123001691303}
!159 = !{!"address", !"read_provenance"}
!160 = !{i64 4424158784261878811}
!161 = !{i64 2193748657169569779}
!162 = !{i64 4188352532147828808}
!163 = !{i64 -6584318497033563664}
!164 = !{i64 5703457424811370178}
!165 = !{i64 6164666944609773413}
!166 = !{i64 3731627753604295851}
!167 = !{i64 5867647270772998899}
!168 = !{i64 3875361615953532773}
!169 = !{i64 3418882072818706386}
!170 = !{i64 3151419930473472208}
!171 = !{i64 -2817029513629961090}
!172 = !{i64 6376001066722388842}
!173 = !{i64 -4095248534710355179}
!174 = !{i64 8919701130623991247}
!175 = !{i64 2036004490830765705}
!176 = !{i64 161722830686663569}
!177 = !{i64 -2438326566879782021}
!178 = !{i64 1346863933243212981}
!179 = !{i64 -802476348041777499}
!180 = !{i64 -8659355176811262979}
!181 = !{i64 4178755950738058716}
!182 = !{i64 -4697229229758310823}
!183 = !{i64 2701879021675381316}
!184 = !{i64 -962575261704015877}
!185 = !{i64 8119096979193072053}
!186 = !{i64 -8643381723429252363}
!187 = !{i64 -657030081751734183}
!188 = !{i64 -2240437291056196350}
!189 = !{i64 3379409377012707484}
!190 = !{i64 -1351852870402435973}
!191 = !{i64 5419238906092421728}
!192 = !{i64 3017557686299412135}
!193 = !{i64 -2947900743501394732}
!194 = !{i64 3632314902810143703}
!195 = !{i64 -2624081020897602054}
