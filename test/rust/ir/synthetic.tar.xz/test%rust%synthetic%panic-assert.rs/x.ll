; ModuleID = 'panic_assert.cf28995c0fff400e-cgu.0'
source_filename = "panic_assert.cf28995c0fff400e-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshMHq0roLIfi_12panic_assert, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshMHq0roLIfi_12panic_assert, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshMHq0roLIfi_12panic_assert }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_20edccc1404afef8c0df4050e8037421 = private unnamed_addr constant [13 x i8] c"the assertion", align 1, !guid !2
@alloc_35035c7df55b95f7be5b1f91e54f1591 = private unnamed_addr constant [36 x i8] c"test/rust/synthetic/panic-assert.rs\00", align 1, !guid !3
@alloc_73dda9261f4b81e88b20a337470690dc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_35035c7df55b95f7be5b1f91e54f1591, [16 x i8] c"#\00\00\00\00\00\00\00\06\00\00\00\05\00\00\00" }>, align 8, !guid !4
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !5

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshMHq0roLIfi_12panic_assert(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !11 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshMHq0roLIfi_12panic_assert(i32 %dummy) unnamed_addr #1 !guid !12 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !13
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshMHq0roLIfi_12panic_assert(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !14 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshMHq0roLIfi_12panic_assert(ptr %f) #6
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #6
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshMHq0roLIfi_12panic_assert(ptr align 8 %_1) unnamed_addr #1 !guid !15 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECshMHq0roLIfi_12panic_assert(ptr %_4) #7
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshMHq0roLIfi_12panic_assert() #6
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshMHq0roLIfi_12panic_assert(i8 %_2) #6
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCshMHq0roLIfi_12panic_assert(ptr %_1) unnamed_addr #1 !guid !16 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshMHq0roLIfi_12panic_assert(ptr %0) #6
  ret i32 %_0
}

; panic_assert::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCshMHq0roLIfi_12panic_assert4main() unnamed_addr #0 !guid !17 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshMHq0roLIfi_12panic_assert(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #6
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<i32>
  %_4 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECshMHq0roLIfi_12panic_assert(i32 1) #6
  %_3 = icmp sgt i32 %_4, 2
  br i1 %_3, label %bb4, label %bb5

bb5:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshMHq0roLIfi_12panic_assert(ptr @alloc_20edccc1404afef8c0df4050e8037421, i64 13) #6
  %_6.0 = extractvalue { ptr, ptr } %1, 0
  %_6.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_73dda9261f4b81e88b20a337470690dc) #8
  unreachable

bb4:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %2 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshMHq0roLIfi_12panic_assert(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #6
  %_8.0 = extractvalue { ptr, ptr } %2, 0
  %_8.1 = extractvalue { ptr, ptr } %2, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_8.0, ptr %_8.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshMHq0roLIfi_12panic_assert(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !18 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCshMHq0roLIfi_12panic_assert(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !19 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCshMHq0roLIfi_12panic_assert(ptr %s.0, i64 %s.1) #6
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshMHq0roLIfi_12panic_assert(ptr %self) unnamed_addr #1 !guid !20 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CshMHq0roLIfi_12panic_assert(i8 %0) unnamed_addr #1 !guid !21 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CshMHq0roLIfi_12panic_assert(ptr %self) #6
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCshMHq0roLIfi_12panic_assert() unnamed_addr #1 !guid !22 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshMHq0roLIfi_12panic_assert(ptr %_1) unnamed_addr #1 !guid !23 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCshMHq0roLIfi_12panic_assert(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !24 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CshMHq0roLIfi_12panic_assert(ptr align 8 %_1) #6
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #4

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #5 !guid !25 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECshMHq0roLIfi_12panic_assert(ptr @_RNvCshMHq0roLIfi_12panic_assert4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nonlazybind "target-cpu"="x86-64" }
attributes #6 = { inlinehint }
attributes #7 = { noinline }
attributes #8 = { noinline noreturn }

!llvm.module.flags = !{!6, !7, !8, !9}
!llvm.ident = !{!10}

!0 = !{i64 1206294099392349898}
!1 = !{i64 6167341721828851365}
!2 = !{i64 -4840538585962610417}
!3 = !{i64 -8813186618117358687}
!4 = !{i64 1840186416423909590}
!5 = !{i64 4447000271731795636}
!6 = !{i32 8, !"PIC Level", i32 2}
!7 = !{i32 7, !"PIE Level", i32 2}
!8 = !{i32 2, !"RtLibUseGOT", i32 1}
!9 = !{i32 7, !"uwtable", i32 2}
!10 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!11 = !{i64 -6684078633498881723}
!12 = !{i64 -8021644665411496285}
!13 = !{i64 1312683739883966}
!14 = !{i64 8864728657921741472}
!15 = !{i64 6083469580245853945}
!16 = !{i64 -6988438995577753704}
!17 = !{i64 5006140717223375298}
!18 = !{i64 8126110531225465624}
!19 = !{i64 -924296335220172847}
!20 = !{i64 6706582987729161112}
!21 = !{i64 1803061563237929999}
!22 = !{i64 9189140443127412464}
!23 = !{i64 5530868488047319268}
!24 = !{i64 6173731704927905707}
!25 = !{i64 -2624081020897602054}
