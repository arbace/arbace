; ModuleID = 'overflow_neg_i32.60aeb224deb78a7e-cgu.0'
source_filename = "overflow_neg_i32.60aeb224deb78a7e-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs8iDz9v0dbbK_16overflow_neg_i32, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8iDz9v0dbbK_16overflow_neg_i32, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8iDz9v0dbbK_16overflow_neg_i32 }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_64322c2d79900299bf1840491acfa5de = private unnamed_addr constant [40 x i8] c"test/rust/synthetic/overflow-neg-i32.rs\00", align 1, !guid !2
@alloc_ef6a30bd60f852ef6db057edc16d9e21 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_64322c2d79900299bf1840491acfa5de, [16 x i8] c"'\00\00\00\00\00\00\00\07\00\00\00\0D\00\00\00" }>, align 8, !guid !3
@alloc_aba2f1a5110ca0d659951e181c97d362 = private unnamed_addr constant [20 x i8] c"\0Cunreachable \C0\01 \C0\01\0A\00", align 1, !guid !4

; <core::fmt::Arguments>::new::<20, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj2_ECs8iDz9v0dbbK_16overflow_neg_i32(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !10 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs8iDz9v0dbbK_16overflow_neg_i32(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !11 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs8iDz9v0dbbK_16overflow_neg_i32(i32 %dummy) unnamed_addr #0 !guid !12 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !13
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs8iDz9v0dbbK_16overflow_neg_i32(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !14 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8iDz9v0dbbK_16overflow_neg_i32(ptr %f) #7
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #7
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8iDz9v0dbbK_16overflow_neg_i32(ptr align 8 %_1) unnamed_addr #0 !guid !15 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs8iDz9v0dbbK_16overflow_neg_i32(ptr %_4) #8
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs8iDz9v0dbbK_16overflow_neg_i32() #7
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs8iDz9v0dbbK_16overflow_neg_i32(i8 %_2) #7
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs8iDz9v0dbbK_16overflow_neg_i32(ptr %_1) unnamed_addr #0 !guid !16 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8iDz9v0dbbK_16overflow_neg_i32(ptr %0) #7
  ret i32 %_0
}

; overflow_neg_i32::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs8iDz9v0dbbK_16overflow_neg_i324main() unnamed_addr #1 !guid !17 {
start:
  %_14 = alloca [16 x i8], align 8
  %_13 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %r = alloca [4 x i8], align 4
  %b = alloca [4 x i8], align 4
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8iDz9v0dbbK_16overflow_neg_i32(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #7
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<i32>
  %a = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs8iDz9v0dbbK_16overflow_neg_i32(i32 -2147483648) #7
; call core::hint::black_box::<i32>
  %1 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs8iDz9v0dbbK_16overflow_neg_i32(i32 0) #7
  store i32 %1, ptr %b, align 4
  %_6 = icmp eq i32 %a, -2147483648
  br i1 %_6, label %panic, label %bb5

bb5:                                              ; preds = %start
  %2 = sub i32 0, %a
  store i32 %2, ptr %r, align 4
; call <core::fmt::rt::Argument>::new_debug::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuglECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8 %_13, ptr align 4 %r) #7
; call <core::fmt::rt::Argument>::new_debug::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuglECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8 %_14, ptr align 4 %b) #7
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_13, i64 16, i1 false)
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_14, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<20, 2>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj2_ECs8iDz9v0dbbK_16overflow_neg_i32(ptr @alloc_aba2f1a5110ca0d659951e181c97d362, ptr align 8 %args) #7
  %_8.0 = extractvalue { ptr, ptr } %5, 0
  %_8.1 = extractvalue { ptr, ptr } %5, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_8.0, ptr %_8.1)
  ret void

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_neg_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_neg_overflow(ptr align 8 @alloc_ef6a30bd60f852ef6db057edc16d9e21) #9
  unreachable
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs8iDz9v0dbbK_16overflow_neg_i32(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !18 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8iDz9v0dbbK_16overflow_neg_i32(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !19 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs8iDz9v0dbbK_16overflow_neg_i32(ptr %s.0, i64 %s.1) #7
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs8iDz9v0dbbK_16overflow_neg_i32(ptr %self) unnamed_addr #0 !guid !20 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs8iDz9v0dbbK_16overflow_neg_i32(i8 %0) unnamed_addr #0 !guid !21 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs8iDz9v0dbbK_16overflow_neg_i32(ptr %self) #7
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs8iDz9v0dbbK_16overflow_neg_i32() unnamed_addr #0 !guid !22 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8iDz9v0dbbK_16overflow_neg_i32(ptr %_1) unnamed_addr #0 !guid !23 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8iDz9v0dbbK_16overflow_neg_i32(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !24 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8iDz9v0dbbK_16overflow_neg_i32(ptr align 8 %_1) #7
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_const::panic_const_neg_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_neg_overflow(ptr align 8) unnamed_addr #4

; <core::fmt::rt::Argument>::new_debug::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debuglECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #6 !guid !25 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs8iDz9v0dbbK_16overflow_neg_i32(ptr @_RNvCs8iDz9v0dbbK_16overflow_neg_i324main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nonlazybind "target-cpu"="x86-64" }
attributes #7 = { inlinehint }
attributes #8 = { noinline }
attributes #9 = { noinline noreturn }

!llvm.module.flags = !{!5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = !{i64 3222398259673169288}
!1 = !{i64 -5243349161555294488}
!2 = !{i64 -3819365830816107011}
!3 = !{i64 -1618657818865838296}
!4 = !{i64 -2646159620917360058}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 2, !"RtLibUseGOT", i32 1}
!8 = !{i32 7, !"uwtable", i32 2}
!9 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!10 = !{i64 -2849236704476693311}
!11 = !{i64 -2776447471527590887}
!12 = !{i64 8698780243300320195}
!13 = !{i64 1312696624785857}
!14 = !{i64 -2360000068423954929}
!15 = !{i64 3084819768963236962}
!16 = !{i64 2412287066473931280}
!17 = !{i64 -4452509330131485211}
!18 = !{i64 -8418065552782911945}
!19 = !{i64 1024610597593457464}
!20 = !{i64 2746409707492989102}
!21 = !{i64 -4153132083949196063}
!22 = !{i64 7782304817083306449}
!23 = !{i64 2514620257339287729}
!24 = !{i64 2228832407273891915}
!25 = !{i64 -2624081020897602054}
