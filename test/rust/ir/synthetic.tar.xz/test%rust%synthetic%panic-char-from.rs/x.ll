; ModuleID = 'panic_char_from.f51bcbfb6bcf7be6-cgu.0'
source_filename = "panic_char_from.f51bcbfb6bcf7be6-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsl2HQzUfB7Cc_15panic_char_from, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csl2HQzUfB7Cc_15panic_char_from, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csl2HQzUfB7Cc_15panic_char_from }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_0663ad51728d7a338c77ebebeff5529a = private unnamed_addr constant [39 x i8] c"test/rust/synthetic/panic-char-from.rs\00", align 1, !guid !2
@alloc_295a725fb2b177f11ed5f99815d86203 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0663ad51728d7a338c77ebebeff5529a, [16 x i8] c"&\00\00\00\00\00\00\00\06\00\00\00*\00\00\00" }>, align 8, !guid !3
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !4
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !5
@alloc_b423406b48ff027604baa6adfb8ddb69 = private unnamed_addr constant [42 x i8] c"from_digit: radix is too high (maximum 36)", align 1, !guid !6
@alloc_3dcac78da2883dc9473a3fc6600bcad4 = private unnamed_addr constant [25 x i8] c"core/src/char/convert.rs\00", align 1, !guid !7
@alloc_e7d3726364f2c6fbf3145faf671f353e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3dcac78da2883dc9473a3fc6600bcad4, [16 x i8] c"\18\00\00\00\00\00\00\00L\01\00\00\09\00\00\00" }>, align 8, !guid !8

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsl2HQzUfB7Cc_15panic_char_from(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !14 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsl2HQzUfB7Cc_15panic_char_from(i32 %dummy) unnamed_addr #1 !guid !15 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !16
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsl2HQzUfB7Cc_15panic_char_from(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !17 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsl2HQzUfB7Cc_15panic_char_from(ptr %f) #7
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #7
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csl2HQzUfB7Cc_15panic_char_from(ptr align 8 %_1) unnamed_addr #1 !guid !18 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsl2HQzUfB7Cc_15panic_char_from(ptr %_4) #8
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsl2HQzUfB7Cc_15panic_char_from() #7
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csl2HQzUfB7Cc_15panic_char_from(i8 %_2) #7
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsl2HQzUfB7Cc_15panic_char_from(ptr %_1) unnamed_addr #1 !guid !19 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsl2HQzUfB7Cc_15panic_char_from(ptr %0) #7
  ret i32 %_0
}

; panic_char_from::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsl2HQzUfB7Cc_15panic_char_from4main() unnamed_addr #0 !guid !20 {
start:
  %self.i = alloca [4 x i8], align 4
  %_11 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %c = alloca [4 x i8], align 4
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsl2HQzUfB7Cc_15panic_char_from(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #7
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<u32>
  %_5 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsl2HQzUfB7Cc_15panic_char_from(i32 40) #7
; call <char>::from_digit
  %_4 = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc10from_digitCsl2HQzUfB7Cc_15panic_char_from(i32 %_5, i32 10) #7
  store i32 %_4, ptr %self.i, align 4
  %1 = load i32, ptr %self.i, align 4
  %2 = icmp eq i32 %1, -1
  %_2.i = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2.i to i1
  br i1 %3, label %_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptioncE6unwrapCsl2HQzUfB7Cc_15panic_char_from.exit, label %bb2.i

bb2.i:                                            ; preds = %start
; call core::option::unwrap_failed
  call void @_RNvNtCsl10jNU3mE6R_4core6option13unwrap_failed(ptr align 8 @alloc_295a725fb2b177f11ed5f99815d86203) #9
  unreachable

_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptioncE6unwrapCsl2HQzUfB7Cc_15panic_char_from.exit: ; preds = %start
  %val.i = load i32, ptr %self.i, align 4
  store i32 %val.i, ptr %c, align 4
; call <core::fmt::rt::Argument>::new_display::<char>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaycECshGsV4pNJ6ra_6object(ptr sret([16 x i8]) align 8 %_11, ptr align 4 %c) #7
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_11, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args) #7
  %_7.0 = extractvalue { ptr, ptr } %5, 0
  %_7.1 = extractvalue { ptr, ptr } %5, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_7.0, ptr %_7.1)
; call <core::fmt::Arguments>::from_str
  %6 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsl2HQzUfB7Cc_15panic_char_from(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #7
  %_15.0 = extractvalue { ptr, ptr } %6, 0
  %_15.1 = extractvalue { ptr, ptr } %6, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_15.0, ptr %_15.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsl2HQzUfB7Cc_15panic_char_from(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !21 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <char>::from_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc10from_digitCsl2HQzUfB7Cc_15panic_char_from(i32 %num, i32 %radix) unnamed_addr #1 !guid !22 {
start:
; call core::char::convert::from_digit
  %_0 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert10from_digitCsl2HQzUfB7Cc_15panic_char_from(i32 %num, i32 %radix) #7
  ret i32 %_0
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsl2HQzUfB7Cc_15panic_char_from(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !23 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsl2HQzUfB7Cc_15panic_char_from(ptr %s.0, i64 %s.1) #7
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csl2HQzUfB7Cc_15panic_char_from(ptr %self) unnamed_addr #1 !guid !24 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csl2HQzUfB7Cc_15panic_char_from(i8 %0) unnamed_addr #1 !guid !25 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csl2HQzUfB7Cc_15panic_char_from(ptr %self) #7
  ret i32 %_0
}

; core::char::convert::from_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert10from_digitCsl2HQzUfB7Cc_15panic_char_from(i32 %num, i32 %radix) unnamed_addr #1 !guid !26 {
start:
  %_0 = alloca [4 x i8], align 4
  %_3 = icmp ugt i32 %radix, 36
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_6 = icmp ult i32 %num, %radix
  br i1 %_6, label %bb4, label %bb5

bb1:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsl2HQzUfB7Cc_15panic_char_from(ptr @alloc_b423406b48ff027604baa6adfb8ddb69, i64 42) #7
  %_5.0 = extractvalue { ptr, ptr } %0, 0
  %_5.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 @alloc_e7d3726364f2c6fbf3145faf671f353e) #9
  unreachable

bb5:                                              ; preds = %bb3
  store i32 -1, ptr %_0, align 4
  br label %bb8

bb4:                                              ; preds = %bb3
  %num1 = trunc i32 %num to i8
  %_8 = icmp ult i8 %num1, 10
  br i1 %_8, label %bb6, label %bb7

bb8:                                              ; preds = %bb6, %bb7, %bb5
  %1 = load i32, ptr %_0, align 4
  ret i32 %1

bb7:                                              ; preds = %bb4
  %_13 = add i8 97, %num1
  %_12 = sub i8 %_13, 10
  %_11 = zext i8 %_12 to i32
  store i32 %_11, ptr %_0, align 4
  br label %bb8

bb6:                                              ; preds = %bb4
  %_10 = add i8 48, %num1
  %_9 = zext i8 %_10 to i32
  store i32 %_9, ptr %_0, align 4
  br label %bb8
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsl2HQzUfB7Cc_15panic_char_from() unnamed_addr #1 !guid !27 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsl2HQzUfB7Cc_15panic_char_from(ptr %_1) unnamed_addr #1 !guid !28 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsl2HQzUfB7Cc_15panic_char_from(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !29 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csl2HQzUfB7Cc_15panic_char_from(ptr align 8 %_1) #7
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<char>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaycECshGsV4pNJ6ra_6object(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; core::option::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6option13unwrap_failed(ptr align 8) unnamed_addr #5

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #5

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #6 !guid !30 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsl2HQzUfB7Cc_15panic_char_from(ptr @_RNvCsl2HQzUfB7Cc_15panic_char_from4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nonlazybind "target-cpu"="x86-64" }
attributes #7 = { inlinehint }
attributes #8 = { noinline }
attributes #9 = { noinline noreturn }

!llvm.module.flags = !{!9, !10, !11, !12}
!llvm.ident = !{!13}

!0 = !{i64 5633123150700450624}
!1 = !{i64 -5272177678732518274}
!2 = !{i64 1264880736632219562}
!3 = !{i64 6685508078257732057}
!4 = !{i64 3640235951159909999}
!5 = !{i64 5612586242749410300}
!6 = !{i64 1217167586833990952}
!7 = !{i64 -1370270183709033510}
!8 = !{i64 -2888638431798942242}
!9 = !{i32 8, !"PIC Level", i32 2}
!10 = !{i32 7, !"PIE Level", i32 2}
!11 = !{i32 2, !"RtLibUseGOT", i32 1}
!12 = !{i32 7, !"uwtable", i32 2}
!13 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!14 = !{i64 8583766770495579091}
!15 = !{i64 -4164952727057041695}
!16 = !{i64 1312945732889083}
!17 = !{i64 -2442403765159909135}
!18 = !{i64 3076912337702691650}
!19 = !{i64 3893973885357932466}
!20 = !{i64 -8803243497876060748}
!21 = !{i64 3465426877149562420}
!22 = !{i64 2077028549032787776}
!23 = !{i64 4631757052074156979}
!24 = !{i64 -5445897156109042952}
!25 = !{i64 -3086588242206976834}
!26 = !{i64 2687630010943804418}
!27 = !{i64 7310267959154082516}
!28 = !{i64 -9132057555128076434}
!29 = !{i64 -248707765240568464}
!30 = !{i64 -2624081020897602054}
