; ModuleID = 'panic_hashmap_index.324078d7b92e31e8-cgu.0'
source_filename = "panic_hashmap_index.324078d7b92e31e8-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"std::sys::thread_local::native::lazy::Storage<core::cell::Cell<(u64, u64)>, !>" = type { %"core::cell::UnsafeCell<core::mem::maybe_uninit::MaybeUninit<core::cell::Cell<(u64, u64)>>>", i8, [7 x i8] }
%"core::cell::UnsafeCell<core::mem::maybe_uninit::MaybeUninit<core::cell::Cell<(u64, u64)>>>" = type { %"core::mem::maybe_uninit::MaybeUninit<core::cell::Cell<(u64, u64)>>" }
%"core::mem::maybe_uninit::MaybeUninit<core::cell::Cell<(u64, u64)>>" = type { [2 x i64] }
%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@alloc_e5aa43ad0b8d7697897e6c8b34c8d055 = private unnamed_addr constant [40 x i8] c"std/src/sys/thread_local/native/lazy.rs\00", align 1, !guid !0
@alloc_1ba7281dabc4731b2e56552f4ead51ad = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e5aa43ad0b8d7697897e6c8b34c8d055, [16 x i8] c"'\00\00\00\00\00\00\00P\00\00\00*\00\00\00" }>, align 8, !guid !1
@alloc_70165e1942fbf2cb7aee6a08556ee215 = private unnamed_addr constant [43 x i8] c"fatal runtime error: unreachable, aborting\0A", align 1, !guid !2
@alloc_005278a5235fae8022f5c4b51ab35b77 = private unnamed_addr constant [24 x i8] c"std/src/thread/local.rs\00", align 1, !guid !3
@alloc_dfdd876860e628589ded87286bda2bc5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_005278a5235fae8022f5c4b51ab35b77, [16 x i8] c"\17\00\00\00\00\00\00\00\AD\01\00\00\19\00\00\00" }>, align 8, !guid !4
@alloc_5211b2c5859a5f093c3004bfefe0c4bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_005278a5235fae8022f5c4b51ab35b77, [16 x i8] c"\17\00\00\00\00\00\00\00\CE\01\00\00%\00\00\00" }>, align 8, !guid !5
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtBd_8RawTableThhEE4findNCINvNtBf_3map14equivalent_keyhhhE0E0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTjEE9call_once6vtableCs4julcnN5YCW_19panic_hashmap_index, ptr @_RNCINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB8_8RawTableThhEE4findNCINvNtBa_3map14equivalent_keyhhhE0E0Cs4julcnN5YCW_19panic_hashmap_index }>, align 8, !guid !6
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs4julcnN5YCW_19panic_hashmap_index, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4julcnN5YCW_19panic_hashmap_index, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4julcnN5YCW_19panic_hashmap_index }>, align 8, !guid !7
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !8
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !9
@_RNvNCNKNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtBa_11RandomState3new4KEYS0s_023___RUST_STD_INTERNAL_VAL = external thread_local global %"std::sys::thread_local::native::lazy::Storage<core::cell::Cell<(u64, u64)>, !>"
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !10
@alloc_07df702e66747a0a22ce222ac977abf1 = private unnamed_addr constant [43 x i8] c"test/rust/synthetic/panic-hashmap-index.rs\00", align 1, !guid !11
@alloc_fb468a87e7f5fee6e2ac28f20228937e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_07df702e66747a0a22ce222ac977abf1, [16 x i8] c"*\00\00\00\00\00\00\00\06\00\00\00b\00\00\00" }>, align 8, !guid !12
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !13
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !14
@alloc_1d994709d59334fa22f8615b086434c8 = private unnamed_addr constant ptr @_RNvYNCNKNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtBb_11RandomState3new4KEYS0s_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTINtNtB1l_6option6OptionQIB20_INtNtB1l_4cell4CellTyyEEEEEE9call_onceCs4julcnN5YCW_19panic_hashmap_index, align 8, !guid !15
@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !16
@alloc_988c380202cc7b7a37ca3d8d5930c44f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\AD\00\00\00\1B\00\00\00" }>, align 8, !guid !17
@alloc_f23077b3a687c4843fc25e31cf862d9f = private unnamed_addr constant [24 x i8] c"core/src/ptr/mut_ptr.rs\00", align 1, !guid !18
@alloc_7e0b8ce8645638c5a2103a5fcc8de1c3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23077b3a687c4843fc25e31cf862d9f, [16 x i8] c"\17\00\00\00\00\00\00\00\C8\05\00\00\12\00\00\00" }>, align 8, !guid !19
@alloc_d40944fcd10884516cff9b7c875a8b6e = private unnamed_addr constant [37 x i8] c"./vendor/hashbrown-0.17.1/src/raw.rs\00", align 1, !guid !20
@alloc_738ae211beea0bce7ffb44e2c9946e50 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d40944fcd10884516cff9b7c875a8b6e, [16 x i8] c"$\00\00\00\00\00\00\00\E8\00\00\00\16\00\00\00" }>, align 8, !guid !21
@alloc_aa76ce2a45a8d8414d95a67e0bdb90d8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d40944fcd10884516cff9b7c875a8b6e, [16 x i8] c"$\00\00\00\00\00\00\00I\01\00\00$\00\00\00" }>, align 8, !guid !22
@alloc_98906c2a737ea6157b34427fbd8045c5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d40944fcd10884516cff9b7c875a8b6e, [16 x i8] c"$\00\00\00\00\00\00\00L\01\00\00\1B\00\00\00" }>, align 8, !guid !23
@alloc_f30e4716a06fb1ebce0b59604507b1e1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d40944fcd10884516cff9b7c875a8b6e, [16 x i8] c"$\00\00\00\00\00\00\00\A2\01\00\00(\00\00\00" }>, align 8, !guid !24
@alloc_d0776666182ad032bd1011cf266e2f3a = private unnamed_addr constant [16 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF", align 16, !guid !25
@anon.d97814a45295a1360f772f6204a83572.0 = private unnamed_addr constant <{ ptr, [24 x i8] }> <{ ptr @alloc_d0776666182ad032bd1011cf266e2f3a, [24 x i8] zeroinitializer }>, align 8, !guid !26
@alloc_ce5479cc7c79a6c41f8dc5cf14a25542 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d40944fcd10884516cff9b7c875a8b6e, [16 x i8] c"$\00\00\00\00\00\00\00J\0C\00\00\1D\00\00\00" }>, align 8, !guid !27
@alloc_bfb7196d4f02e20e3345e576f01434f9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d40944fcd10884516cff9b7c875a8b6e, [16 x i8] c"$\00\00\00\00\00\00\00N\0C\00\00@\00\00\00" }>, align 8, !guid !28
@alloc_a9e8aead2791cdafa63aa359258ea1bd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d40944fcd10884516cff9b7c875a8b6e, [16 x i8] c"$\00\00\00\00\00\00\00N\0C\00\00\16\00\00\00" }>, align 8, !guid !29
@alloc_265451f756f83386072250249f1df565 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d40944fcd10884516cff9b7c875a8b6e, [16 x i8] c"$\00\00\00\00\00\00\00@\0A\00\00%\00\00\00" }>, align 8, !guid !30
@alloc_527444d360737e9472b8a6b3cc6c0b07 = private unnamed_addr constant [21 x i8] c"core/src/hash/sip.rs\00", align 1, !guid !31
@alloc_d14c83b2cedfe7ed4a141c320527c329 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_527444d360737e9472b8a6b3cc6c0b07, [16 x i8] c"\14\00\00\00\00\00\00\00\81\00\00\00\18\00\00\00" }>, align 8, !guid !32
@alloc_e29f64de50d1060058752babd623993a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_527444d360737e9472b8a6b3cc6c0b07, [16 x i8] c"\14\00\00\00\00\00\00\00\86\00\00\00\1A\00\00\00" }>, align 8, !guid !33
@alloc_865bd8db0167b0f468f3000d3b44592d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_527444d360737e9472b8a6b3cc6c0b07, [16 x i8] c"\14\00\00\00\00\00\00\00\8B\00\00\00\1F\00\00\00" }>, align 8, !guid !34
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !35
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !36
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !37
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !38
@alloc_5f856c9c5a649671acdbf03081b5c1d0 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: ptr::replace requires that the pointer argument is aligned and non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !39
@alloc_75fb06c2453febd814e73f5f2e72ae38 = private unnamed_addr constant [199 x i8] c"unsafe precondition(s) violated: hint::unreachable_unchecked must never be reached\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !40
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !41
@alloc_54cd3cdc152bbdb5dbd048e7a409bdad = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_527444d360737e9472b8a6b3cc6c0b07, [16 x i8] c"\14\00\00\00\00\00\00\00\1E\01\00\00\1F\00\00\00" }>, align 8, !guid !42
@alloc_a7d7769291fb702cd4ca6ef64f027ff9 = private unnamed_addr constant [22 x i8] c"no entry found for key", align 1, !guid !43

; <core::option::Option<core::cell::Cell<(u64, u64)>>>::unwrap_or_else::<<std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtB5_4cell4CellTyyEEE14unwrap_or_elseNvNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB1t_11RandomState3new4KEYS27___rust_std_internal_init_fnECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr align 8 %0) unnamed_addr #0 !guid !49 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %_3 = load i64, ptr %self, align 8
  %1 = trunc nuw i64 %_3 to i1
  br i1 %1, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  %x.0 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  %x.1 = load i64, ptr %3, align 8
  store i64 %x.0, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %x.1, ptr %4, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; call <<std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn as core::ops::function::FnOnce<()>>::call_once
  %5 = call { i64, i64 } @_RNvYNvNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB9_11RandomState3new4KEYS27___rust_std_internal_init_fnINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4julcnN5YCW_19panic_hashmap_index() #18
  %6 = extractvalue { i64, i64 } %5, 0
  %7 = extractvalue { i64, i64 } %5, 1
  store i64 %6, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %7, ptr %8, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %9 = load i8, ptr %_6, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %11 = load i64, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { i64, i64 } poison, i64 %11, 0
  %15 = insertvalue { i64, i64 } %14, i64 %13, 1
  ret { i64, i64 } %15

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&mut core::option::Option<core::cell::Cell<(u64, u64)>>>>::and_then::<core::cell::Cell<(u64, u64)>, <core::option::Option<core::cell::Cell<(u64, u64)>>>::take>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionQIBw_INtNtB5_4cell4CellTyyEEEE8and_thenBN_NvMB3_BJ_4takeECs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !50 {
start:
  %_7 = alloca [1 x i8], align 1
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load ptr, ptr %self, align 8
  store i8 0, ptr %_7, align 1
; call <<core::option::Option<core::cell::Cell<(u64, u64)>>>::take as core::ops::function::FnOnce<(&mut core::option::Option<core::cell::Cell<(u64, u64)>>,)>>::call_once
  call void @_RNvYNvMNtCsl10jNU3mE6R_4core6optionINtB5_6OptionINtNtB7_4cell4CellTyyEEE4takeINtNtNtB7_3ops8function6FnOnceTQBx_EE9call_onceCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %x) #18
  br label %bb6

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_7, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&core::cell::Cell<(u64, u64)>>>::ok_or::<std::thread::local::AccessError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRINtNtB5_4cell4CellTyyEEE5ok_orNtNtNtCsddYV2PBJW9h_3std6thread5local11AccessErrorECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %0) unnamed_addr #0 !guid !51 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_6, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %7 = load ptr, ptr %_0, align 8
  ret ptr %7

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <std::sys::thread_local::native::lazy::Storage<core::cell::Cell<(u64, u64)>, !>>::get_or_init::<<std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs0_NtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEzE11get_or_initNvNvNvMNtNtBe_4hash6randomNtB2d_11RandomState3new4KEYS27___rust_std_internal_init_fnECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr align 8 %i) unnamed_addr #0 personality ptr @rust_eh_personality !guid !52 {
start:
  %_11 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  store i8 0, ptr %_11, align 1
  store i8 1, ptr %_11, align 1
  %_5 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::cell::Cell<std::sys::thread_local::native::lazy::State<!>>>::get
  %_4 = call zeroext i1 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CellINtNtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazy5StatezEE3getCs4julcnN5YCW_19panic_hashmap_index(ptr %_5) #18
  br label %bb1

bb1:                                              ; preds = %start
  %_6 = zext i1 %_4 to i64
  %0 = icmp eq i64 %_6, 1
  br i1 %0, label %bb2, label %bb5

bb2:                                              ; preds = %bb1
  br label %bb3

bb5:                                              ; preds = %bb1
  store i8 0, ptr %_11, align 1
; call <std::sys::thread_local::native::lazy::Storage<core::cell::Cell<(u64, u64)>, !>>::get_or_init_slow::<<std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
  %1 = call ptr @_RINvMs0_NtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEzE16get_or_init_slowNvNvNvMNtNtBe_4hash6randomNtB2i_11RandomState3new4KEYS27___rust_std_internal_init_fnECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr align 8 %i)
  store ptr %1, ptr %_0, align 8
  br label %bb12

bb3:                                              ; preds = %bb2
  br label %bb4

bb4:                                              ; preds = %bb3
  store ptr %self, ptr %_0, align 8
  br label %bb9

bb9:                                              ; preds = %bb12, %bb4
  %2 = load i8, ptr %_11, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb8, label %bb6

bb12:                                             ; preds = %bb5
  br label %bb9

bb6:                                              ; preds = %bb8, %bb9
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb8:                                              ; preds = %bb9
  br label %bb6

bb7:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <std::sys::thread_local::native::lazy::Storage<core::cell::Cell<(u64, u64)>, !>>::get_or_init_slow::<<std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
; Function Attrs: cold nonlazybind uwtable
define internal ptr @_RINvMs0_NtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEzE16get_or_init_slowNvNvNvMNtNtBe_4hash6randomNtB2i_11RandomState3new4KEYS27___rust_std_internal_init_fnECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr align 8 %i) unnamed_addr #1 personality ptr @rust_eh_personality !guid !53 {
start:
  %_9.i.i = alloca [1 x i8], align 1
  %_0.i.i = alloca [16 x i8], align 8
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_27 = alloca [8 x i8], align 8
  %_26 = alloca [0 x i8], align 1
  %old_value = alloca [16 x i8], align 8
  %_11 = alloca [24 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_35, align 1
  %_5 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::cell::Cell<std::sys::thread_local::native::lazy::State<!>>>::get
  %_4 = call zeroext i1 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CellINtNtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazy5StatezEE3getCs4julcnN5YCW_19panic_hashmap_index(ptr %_5) #18
  br label %bb1

bb1:                                              ; preds = %start
  %_6 = zext i1 %_4 to i64
  switch i64 %_6, label %bb2 [
    i64 0, label %bb5
    i64 1, label %bb4
    i64 2, label %bb3
  ]

bb2:                                              ; preds = %bb13, %bb1
  unreachable

bb5:                                              ; preds = %bb1
; call <core::option::Option<&mut core::option::Option<core::cell::Cell<(u64, u64)>>>>::and_then::<core::cell::Cell<(u64, u64)>, <core::option::Option<core::cell::Cell<(u64, u64)>>>::take>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionQIBw_INtNtB5_4cell4CellTyyEEEE8and_thenBN_NvMB3_BJ_4takeECs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_11, ptr align 8 %i) #18
  br label %bb8

bb4:                                              ; preds = %bb1
  br label %bb6

bb3:                                              ; preds = %bb1
; call core::ptr::metadata::from_raw_parts::<core::cell::Cell<(u64, u64)>, ()>
  %_0.i = call ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsINtNtB6_4cell4CellTyyEEuECs4julcnN5YCW_19panic_hashmap_index(ptr null) #18
  store ptr %_0.i, ptr %_0, align 8
  br label %bb32

bb8:                                              ; preds = %bb5
  store i8 0, ptr %_35, align 1
; call <core::option::Option<core::cell::Cell<(u64, u64)>>>::unwrap_or_else::<<std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
  %0 = call { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtB5_4cell4CellTyyEEE14unwrap_or_elseNvNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB1t_11RandomState3new4KEYS27___rust_std_internal_init_fnECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_11, ptr align 8 @alloc_1ba7281dabc4731b2e56552f4ead51ad) #18
  %v.0 = extractvalue { i64, i64 } %0, 0
  %v.1 = extractvalue { i64, i64 } %0, 1
  br label %bb9

bb9:                                              ; preds = %bb8
  store i8 1, ptr %_34, align 1
  br label %bb10

bb10:                                             ; preds = %bb9
  store i8 0, ptr %_34, align 1
; call <core::mem::maybe_dangling::MaybeDangling<core::cell::Cell<(u64, u64)>>>::new
  %1 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtB6_4cell4CellTyyEEE3newCs4julcnN5YCW_19panic_hashmap_index(i64 %v.0, i64 %v.1)
  %_2.0.i.i = extractvalue { i64, i64 } %1, 0
  %_2.1.i.i = extractvalue { i64, i64 } %1, 1
  %_2.0.i = extractvalue { i64, i64 } %1, 0
  %_2.1.i = extractvalue { i64, i64 } %1, 1
  %_16.0 = extractvalue { i64, i64 } %1, 0
  %_16.1 = extractvalue { i64, i64 } %1, 1
  br label %bb11

bb11:                                             ; preds = %bb10
  store i8 0, ptr %_9.i.i, align 1
  store i8 1, ptr %_9.i.i, align 1
; call core::ub_checks::check_language_ub
  %_3.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4julcnN5YCW_19panic_hashmap_index() #18
  br i1 %_3.i.i, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtNtB6_3mem12maybe_uninit11MaybeUninitINtNtB6_4cell4CellTyyEEE7replaceCs4julcnN5YCW_19panic_hashmap_index.exit

bb2.i.i:                                          ; preds = %bb11
; call core::ptr::replace::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr7replace18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr %self, i64 8, i1 zeroext false, ptr align 8 @alloc_7e0b8ce8645638c5a2103a5fcc8de1c3) #19
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtNtB6_3mem12maybe_uninit11MaybeUninitINtNtB6_4cell4CellTyyEEE7replaceCs4julcnN5YCW_19panic_hashmap_index.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtNtB6_3mem12maybe_uninit11MaybeUninitINtNtB6_4cell4CellTyyEEE7replaceCs4julcnN5YCW_19panic_hashmap_index.exit: ; preds = %bb11, %bb2.i.i
  store i8 0, ptr %_9.i.i, align 1
; call core::mem::replace::<core::mem::maybe_uninit::MaybeUninit<core::cell::Cell<(u64, u64)>>>
  %2 = call { i64, i64 } @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtB2_12maybe_uninit11MaybeUninitINtNtB4_4cell4CellTyyEEEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %_16.0, i64 %_16.1) #18
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %_0.i.i, align 8
  %5 = getelementptr inbounds i8, ptr %_0.i.i, i64 8
  store i64 %4, ptr %5, align 8
  %6 = load i64, ptr %_0.i.i, align 8
  %7 = getelementptr inbounds i8, ptr %_0.i.i, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { i64, i64 } poison, i64 %6, 0
  %10 = insertvalue { i64, i64 } %9, i64 %8, 1
  %11 = insertvalue { i64, i64 } poison, i64 %6, 0
  %12 = insertvalue { i64, i64 } %11, i64 %8, 1
  %13 = extractvalue { i64, i64 } %12, 0
  %14 = extractvalue { i64, i64 } %12, 1
  store i64 %13, ptr %old_value, align 8
  %15 = getelementptr inbounds i8, ptr %old_value, i64 8
  store i64 %14, ptr %15, align 8
  br label %bb12

bb12:                                             ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOINtNtNtB6_3mem12maybe_uninit11MaybeUninitINtNtB6_4cell4CellTyyEEE7replaceCs4julcnN5YCW_19panic_hashmap_index.exit
  %_20 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::cell::Cell<std::sys::thread_local::native::lazy::State<!>>>::replace
  %_19 = call zeroext i1 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CellINtNtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazy5StatezEE7replaceCs4julcnN5YCW_19panic_hashmap_index(ptr %_20, i1 zeroext true) #18
  br label %bb13

bb13:                                             ; preds = %bb12
  %_22 = zext i1 %_19 to i64
  switch i64 %_22, label %bb2 [
    i64 0, label %bb16
    i64 1, label %bb15
    i64 2, label %bb14
  ]

bb16:                                             ; preds = %bb13
; call <! as std::sys::thread_local::native::lazy::DestroyedState>::register_dtor::<core::cell::Cell<(u64, u64)>>
  call void @_RINvXNtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazyzNtB3_14DestroyedState13register_dtorINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self)
  br label %bb34

bb15:                                             ; preds = %bb13
; call <core::mem::maybe_uninit::MaybeUninit<core::cell::Cell<(u64, u64)>>>::assume_init_drop
  call void @_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitINtNtB9_4cell4CellTyyEEE16assume_init_dropCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %old_value)
  br label %bb33

bb14:                                             ; preds = %bb13
; call std::sys::stdio::unix::panic_output
  %_24 = call zeroext i1 @_RNvNtNtNtCsddYV2PBJW9h_3std3sys5stdio4unix12panic_output()
  br label %bb17

bb34:                                             ; preds = %bb16
  br label %bb22

bb22:                                             ; preds = %bb33, %bb34
  br label %bb23

bb33:                                             ; preds = %bb15
  br label %bb22

bb23:                                             ; preds = %bb22
  br label %bb24

bb24:                                             ; preds = %bb23
  store ptr %self, ptr %_0, align 8
  store i8 0, ptr %_34, align 1
  br label %bb26

bb26:                                             ; preds = %bb25, %bb24
  %16 = load ptr, ptr %_0, align 8
  ret ptr %16

bb17:                                             ; preds = %bb14
  %_25 = zext i1 %_24 to i64
  %17 = trunc nuw i64 %_25 to i1
  br i1 %17, label %bb18, label %bb21

bb18:                                             ; preds = %bb17
; call <core::fmt::Arguments>::from_str_nonconst
  %18 = call { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCs4julcnN5YCW_19panic_hashmap_index(ptr @alloc_70165e1942fbf2cb7aee6a08556ee215, i64 43) #18
  %_29.0 = extractvalue { ptr, ptr } %18, 0
  %_29.1 = extractvalue { ptr, ptr } %18, 1
  br label %bb19

bb21:                                             ; preds = %bb20, %bb17
; call std::process::abort
  call void @_RNvNtCsddYV2PBJW9h_3std7process5abort() #20
  unreachable

bb19:                                             ; preds = %bb18
; call <std::sys::stdio::unix::Stderr as core::io::write::Write>::write_fmt
  %19 = call ptr @_RNvYNtNtNtNtCsddYV2PBJW9h_3std3sys5stdio4unix6StderrNtNtNtCsl10jNU3mE6R_4core2io5write5Write9write_fmtBa_(ptr %_26, ptr %_29.0, ptr %_29.1)
  store ptr %19, ptr %_27, align 8
  br label %bb20

bb20:                                             ; preds = %bb19
; call core::ptr::drop_glue::<core::result::Result<(), core::io::error::Error>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultuNtNtNtB4_2io5error5ErrorEECsddYV2PBJW9h_3std(ptr align 8 %_27)
  br label %bb21

bb6:                                              ; preds = %bb4
  br label %bb7

bb7:                                              ; preds = %bb6
  store ptr %self, ptr %_0, align 8
  br label %bb25

bb25:                                             ; preds = %bb32, %bb7
  br label %bb26

bb32:                                             ; preds = %bb3
  br label %bb25

bb27:                                             ; No predecessors!
  unreachable

bb28:                                             ; No predecessors!
  unreachable

bb29:                                             ; No predecessors!
  unreachable

bb30:                                             ; No predecessors!
  unreachable

bb31:                                             ; No predecessors!
  unreachable
}

; <hashbrown::map::HashMap<u8, u8, std::hash::random::RandomState>>::get::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtCs7CvK5fPrMBK_9hashbrown3mapINtB6_7HashMaphhNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateE3gethECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %k) unnamed_addr #0 !guid !54 {
start:
  %_7 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
; call <hashbrown::raw::RawTable<(u8, u8)>>::is_empty
  %_3 = call zeroext i1 @_RNvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE8is_emptyCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_6 = getelementptr inbounds i8, ptr %self, i64 32
; call hashbrown::map::make_hash::<u8, std::hash::random::RandomState>
  %hash = call i64 @_RINvNtCs7CvK5fPrMBK_9hashbrown3map9make_hashhNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_6, ptr %k)
; call hashbrown::map::equivalent_key::<u8, u8, u8>
  %_9 = call ptr @_RINvNtCs7CvK5fPrMBK_9hashbrown3map14equivalent_keyhhhECs4julcnN5YCW_19panic_hashmap_index(ptr %k)
; call <hashbrown::raw::RawTable<(u8, u8)>>::get::<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>
  %0 = call ptr @_RINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB6_8RawTableThhEE3getNCINvNtB8_3map14equivalent_keyhhhE0ECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %hash, ptr %_9) #18
  store ptr %0, ptr %_7, align 8
  %1 = load ptr, ptr %_7, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_10 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_10 to i1
  br i1 %4, label %bb9, label %bb8

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb10

bb9:                                              ; preds = %bb3
  %_12 = load ptr, ptr %_7, align 8
  %v = getelementptr inbounds i8, ptr %_12, i64 1
  store ptr %v, ptr %_0, align 8
  br label %bb10

bb8:                                              ; preds = %bb3
  store ptr null, ptr %_0, align 8
  br label %bb10

bb10:                                             ; preds = %bb2, %bb9, %bb8
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb7:                                              ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<u8>>::cast::<(u8, u8)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castThhEECs4julcnN5YCW_19panic_hashmap_index(ptr %self) unnamed_addr #0 !guid !55 {
start:
  ret ptr %self
}

; <std::thread::local::LocalKey<core::cell::Cell<(u64, u64)>>>::with::<<std::hash::random::RandomState>::new::{closure#0}, std::hash::random::RandomState>
; Function Attrs: nonlazybind uwtable
define internal { i64, i64 } @_RINvMs2_NtNtCsddYV2PBJW9h_3std6thread5localINtB6_8LocalKeyINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEE4withNCNvMNtNtBa_4hash6randomNtB1I_11RandomState3new0B21_ECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #2 !guid !56 {
start:
  %_3 = alloca [24 x i8], align 8
; call <std::thread::local::LocalKey<core::cell::Cell<(u64, u64)>>>::try_with::<<std::hash::random::RandomState>::new::{closure#0}, std::hash::random::RandomState>
  call void @_RINvMs2_NtNtCsddYV2PBJW9h_3std6thread5localINtB6_8LocalKeyINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEE8try_withNCNvMNtNtBa_4hash6randomNtB1M_11RandomState3new0B25_ECs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %self) #18
  %_4 = load i64, ptr %_3, align 8
  %0 = trunc nuw i64 %_4 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call std::thread::local::panic_access_error
  call void @_RNvNtNtCsddYV2PBJW9h_3std6thread5local18panic_access_error(ptr align 8 @alloc_dfdd876860e628589ded87286bda2bc5) #21
  unreachable

bb4:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  %r.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %r.1 = load i64, ptr %2, align 8
  %3 = insertvalue { i64, i64 } poison, i64 %r.0, 0
  %4 = insertvalue { i64, i64 } %3, i64 %r.1, 1
  ret { i64, i64 } %4

bb2:                                              ; No predecessors!
  unreachable
}

; <std::thread::local::LocalKey<core::cell::Cell<(u64, u64)>>>::try_with::<<std::hash::random::RandomState>::new::{closure#0}, std::hash::random::RandomState>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMs2_NtNtCsddYV2PBJW9h_3std6thread5localINtB6_8LocalKeyINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEE8try_withNCNvMNtNtBa_4hash6randomNtB1M_11RandomState3new0B25_ECs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !57 {
start:
  %_14 = alloca [1 x i8], align 1
  %_3 = alloca [8 x i8], align 8
  store i8 0, ptr %_14, align 1
  store i8 1, ptr %_14, align 1
  %_7 = load ptr, ptr %self, align 8
  %_6 = call ptr %_7(ptr align 8 null)
  br label %bb1

bb1:                                              ; preds = %start
; call <*const core::cell::Cell<(u64, u64)>>::as_ref
  %_5 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPINtNtB6_4cell4CellTyyEE6as_refCs4julcnN5YCW_19panic_hashmap_index(ptr %_6) #18
  br label %bb2

bb2:                                              ; preds = %bb1
; call <core::option::Option<&core::cell::Cell<(u64, u64)>>>::ok_or::<std::thread::local::AccessError>
  %_4 = call align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRINtNtB5_4cell4CellTyyEEE5ok_orNtNtNtCsddYV2PBJW9h_3std6thread5local11AccessErrorECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_5) #18
  br label %bb3

bb3:                                              ; preds = %bb2
; call <core::result::Result<&core::cell::Cell<(u64, u64)>, std::thread::local::AccessError> as core::ops::try_trait::Try>::branch
  %0 = call align 8 ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultRINtNtB7_4cell4CellTyyEENtNtNtCsddYV2PBJW9h_3std6thread5local11AccessErrorENtNtNtB7_3ops9try_trait3Try6branchCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_4) #18
  store ptr %0, ptr %_3, align 8
  br label %bb4

bb4:                                              ; preds = %bb3
  %1 = load ptr, ptr %_3, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_9 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_9 to i1
  br i1 %4, label %bb7, label %bb6

bb7:                                              ; preds = %bb4
; call <core::result::Result<std::hash::random::RandomState, std::thread::local::AccessError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, std::thread::local::AccessError>>>::from_residual
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateNtNtNtBQ_6thread5local11AccessErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1x_EE13from_residualCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 @alloc_5211b2c5859a5f093c3004bfefe0c4bb) #18
  br label %bb8

bb6:                                              ; preds = %bb4
  %thread_local = load ptr, ptr %_3, align 8
  store i8 0, ptr %_14, align 1
; call <std::hash::random::RandomState>::new::{closure#0}
  %5 = call { i64, i64 } @_RNCNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB4_11RandomState3new0Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %thread_local) #18
  %_11.0 = extractvalue { i64, i64 } %5, 0
  %_11.1 = extractvalue { i64, i64 } %5, 1
  br label %bb9

bb9:                                              ; preds = %bb6
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_11.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %_11.1, ptr %7, align 8
  store i64 0, ptr %_0, align 8
  br label %bb10

bb10:                                             ; preds = %bb8, %bb9
  ret void

bb8:                                              ; preds = %bb7
  br label %bb10

bb5:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable
}

; <std::collections::hash::map::HashMap<u8, u8>>::get::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB6_7HashMaphhE3gethECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %k) unnamed_addr #0 !guid !58 {
start:
; call <hashbrown::map::HashMap<u8, u8, std::hash::random::RandomState>>::get::<u8>
  %_0 = call ptr @_RINvMs1_NtCs7CvK5fPrMBK_9hashbrown3mapINtB6_7HashMaphhNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateE3gethECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %k) #18
  ret ptr %_0
}

; <hashbrown::raw::RawTable<(u8, u8)>>::get::<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB6_8RawTableThhEE3getNCINvNtB8_3map14equivalent_keyhhhE0ECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %hash, ptr %eq) unnamed_addr #0 !guid !59 {
start:
  %bucket = alloca [8 x i8], align 8
  %_4 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
; call <hashbrown::raw::RawTable<(u8, u8)>>::find::<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>
  %0 = call ptr @_RINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB6_8RawTableThhEE4findNCINvNtB8_3map14equivalent_keyhhhE0ECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %hash, ptr %eq) #18
  store ptr %0, ptr %_4, align 8
  %1 = load ptr, ptr %_4, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_5 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_5 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %5 = load ptr, ptr %_4, align 8
  store ptr %5, ptr %bucket, align 8
; call <hashbrown::raw::Bucket<(u8, u8)>>::as_ref
  %_7 = call ptr @_RNvMs4_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_6BucketThhEE6as_refCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %bucket) #18
  store ptr %_7, ptr %_0, align 8
  br label %bb6

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %6 = load ptr, ptr %_0, align 8
  ret ptr %6

bb2:                                              ; No predecessors!
  unreachable
}

; <hashbrown::raw::RawTable<(u8, u8)>>::find::<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB6_8RawTableThhEE4findNCINvNtB8_3map14equivalent_keyhhhE0ECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %hash, ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !60 {
start:
  %_0.i3 = alloca [1 x i8], align 1
  %_0.i1 = alloca [1 x i8], align 1
  %1 = alloca [16 x i8], align 16
  %2 = alloca [16 x i8], align 16
  %3 = alloca [16 x i8], align 16
  %_13.i = alloca [16 x i8], align 8
  %iter.i = alloca [2 x i8], align 2
  %probe_seq.i = alloca [16 x i8], align 8
  %_0.i = alloca [16 x i8], align 8
  %_8 = alloca [16 x i8], align 8
  %result = alloca [16 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %eq = alloca [8 x i8], align 8
  store ptr %0, ptr %eq, align 8
  store ptr %eq, ptr %_8, align 8
  %4 = getelementptr inbounds i8, ptr %_8, i64 8
  store ptr %self, ptr %4, align 8
; call <hashbrown::control::tag::Tag>::full
  %tag_hash.i = call i8 @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control3tagNtB2_3Tag4fullCs4julcnN5YCW_19panic_hashmap_index(i64 %hash) #18
; call <hashbrown::raw::RawTableInner>::probe_seq
  %5 = call { i64, i64 } @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner9probe_seqCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %hash) #18
  %6 = extractvalue { i64, i64 } %5, 0
  %7 = extractvalue { i64, i64 } %5, 1
  store i64 %6, ptr %probe_seq.i, align 8
  %8 = getelementptr inbounds i8, ptr %probe_seq.i, i64 8
  store i64 %7, ptr %8, align 8
  br label %bb2.i

bb2.i:                                            ; preds = %bb19.i, %start
  %_9.i = load i64, ptr %probe_seq.i, align 8
; call <hashbrown::raw::RawTableInner>::ctrl
  %_8.i = call ptr @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner4ctrlCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %_9.i) #18
; call <hashbrown::control::group::sse2::Group>::load
  call void @_RNvMNtNtNtCs7CvK5fPrMBK_9hashbrown7control5group4sse2NtB2_5Group4loadCs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %3, ptr %_8.i) #18
  %group.i = load <2 x i64>, ptr %3, align 16
  store <2 x i64> %group.i, ptr %2, align 16
; call <hashbrown::control::group::sse2::Group>::match_tag
  %_11.i = call i16 @_RNvMNtNtNtCs7CvK5fPrMBK_9hashbrown7control5group4sse2NtB2_5Group9match_tagCs4julcnN5YCW_19panic_hashmap_index(ptr align 16 %2, i8 %tag_hash.i) #18
; call <hashbrown::control::bitmask::BitMask as core::iter::traits::collect::IntoIterator>::into_iter
  %_10.i = call i16 @_RNvXs_NtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB4_7BitMaskNtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12IntoIterator9into_iterCs4julcnN5YCW_19panic_hashmap_index(i16 %_11.i) #18
  store i16 %_10.i, ptr %iter.i, align 2
  br label %bb7.i

bb7.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit, %bb2.i
; call <hashbrown::control::bitmask::BitMaskIter as core::iter::traits::iterator::Iterator>::next
  %9 = call { i64, i64 } @_RNvXs0_NtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB5_11BitMaskIterNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator4nextCs4julcnN5YCW_19panic_hashmap_index(ptr align 2 %iter.i) #18
  %10 = extractvalue { i64, i64 } %9, 0
  %11 = extractvalue { i64, i64 } %9, 1
  store i64 %10, ptr %_13.i, align 8
  %12 = getelementptr inbounds i8, ptr %_13.i, i64 8
  store i64 %11, ptr %12, align 8
  %_15.i = load i64, ptr %_13.i, align 8
  %13 = getelementptr inbounds i8, ptr %_13.i, i64 8
  %14 = load i64, ptr %13, align 8
  %15 = trunc nuw i64 %_15.i to i1
  br i1 %15, label %bb10.i, label %bb11.i

bb10.i:                                           ; preds = %bb7.i
  %16 = getelementptr inbounds i8, ptr %_13.i, i64 8
  %bit.i = load i64, ptr %16, align 8
  %_19.i = load i64, ptr %probe_seq.i, align 8
  %_18.i = add i64 %_19.i, %bit.i
  %17 = getelementptr inbounds i8, ptr %self, i64 8
  %_20.i = load i64, ptr %17, align 8
  %index.i = and i64 %_18.i, %_20.i
; call <hashbrown::raw::RawTable<(u8, u8)>>::find::<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>::{closure#0}
  %_22.i = call zeroext i1 @_RNCINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB8_8RawTableThhEE4findNCINvNtBa_3map14equivalent_keyhhhE0E0Cs4julcnN5YCW_19panic_hashmap_index(ptr %_8, i64 %index.i) #18, !inline_history !61
  br i1 %_22.i, label %bb1.i, label %bb2.i2

bb2.i2:                                           ; preds = %bb10.i
  store i8 0, ptr %_0.i1, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit

bb1.i:                                            ; preds = %bb10.i
  store i8 1, ptr %_0.i1, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit: ; preds = %bb2.i2, %bb1.i
  %18 = load i8, ptr %_0.i1, align 1
  %19 = trunc nuw i8 %18 to i1
  br i1 %19, label %bb14.i, label %bb7.i

bb11.i:                                           ; preds = %bb7.i
  store <2 x i64> %group.i, ptr %1, align 16
; call <hashbrown::control::group::sse2::Group>::match_empty
  %_26.i = call i16 @_RNvMNtNtNtCs7CvK5fPrMBK_9hashbrown7control5group4sse2NtB2_5Group11match_emptyCs4julcnN5YCW_19panic_hashmap_index(ptr align 16 %1) #18
; call <hashbrown::control::bitmask::BitMask>::any_bit_set
  %_25.i = call zeroext i1 @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB2_7BitMask11any_bit_setCs4julcnN5YCW_19panic_hashmap_index(i16 %_26.i) #18
  br i1 %_25.i, label %bb1.i5, label %bb2.i4

bb2.i4:                                           ; preds = %bb11.i
  store i8 0, ptr %_0.i3, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit6

bb1.i5:                                           ; preds = %bb11.i
  store i8 1, ptr %_0.i3, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit6

_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit6: ; preds = %bb2.i4, %bb1.i5
  %20 = load i8, ptr %_0.i3, align 1
  %21 = trunc nuw i8 %20 to i1
  br i1 %21, label %bb18.i, label %bb19.i

bb19.i:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit6
  %22 = getelementptr inbounds i8, ptr %self, i64 8
  %_29.i = load i64, ptr %22, align 8
; call <hashbrown::raw::ProbeSeq>::move_next
  call void @_RNvMs0_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_8ProbeSeq9move_nextCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %probe_seq.i, i64 %_29.i) #18
  br label %bb2.i

bb18.i:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit6
  store i64 0, ptr %_0.i, align 8
  br label %_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner10find_inner.exit

bb14.i:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit
  %23 = getelementptr inbounds i8, ptr %_0.i, i64 8
  store i64 %index.i, ptr %23, align 8
  store i64 1, ptr %_0.i, align 8
  br label %_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner10find_inner.exit

_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner10find_inner.exit: ; preds = %bb18.i, %bb14.i
  %24 = load i64, ptr %_0.i, align 8
  %25 = getelementptr inbounds i8, ptr %_0.i, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = insertvalue { i64, i64 } poison, i64 %24, 0
  %28 = insertvalue { i64, i64 } %27, i64 %26, 1
  %29 = extractvalue { i64, i64 } %28, 0
  %30 = extractvalue { i64, i64 } %28, 1
  store i64 %29, ptr %result, align 8
  %31 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %30, ptr %31, align 8
  br label %bb1

bb1:                                              ; preds = %_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner10find_inner.exit
  %_10 = load i64, ptr %result, align 8
  %32 = getelementptr inbounds i8, ptr %result, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = trunc nuw i64 %_10 to i1
  br i1 %34, label %bb4, label %bb3

bb4:                                              ; preds = %bb1
  %35 = getelementptr inbounds i8, ptr %result, i64 8
  %index = load i64, ptr %35, align 8
; call <hashbrown::raw::RawTable<(u8, u8)>>::bucket
  %_12 = call ptr @_RNvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE6bucketCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %index) #18
  br label %bb5

bb3:                                              ; preds = %bb1
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb5, %bb3
  %36 = load ptr, ptr %_0, align 8
  ret ptr %36

bb5:                                              ; preds = %bb4
  store ptr %_12, ptr %_0, align 8
  br label %bb6

bb2:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable
}

; <hashbrown::raw::RawTableInner>::free_buckets::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB6_13RawTableInner12free_bucketsNtNtCs7CppTae75M1_5alloc5alloc6GlobalECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %alloc, i64 %table_layout.0, i64 %table_layout.1) unnamed_addr #0 !guid !62 {
start:
  %_6 = alloca [24 x i8], align 8
; call <hashbrown::raw::RawTableInner>::allocation_info
  call void @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner15allocation_infoCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_6, ptr align 8 %self, i64 %table_layout.0, i64 %table_layout.1) #18
  %ptr = load ptr, ptr %_6, align 8
  %0 = getelementptr inbounds i8, ptr %_6, i64 8
  %layout.0 = load i64, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  %layout.1 = load i64, ptr %1, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs4julcnN5YCW_19panic_hashmap_index(ptr %alloc, ptr %ptr, i64 %layout.0, i64 %layout.1) #18
  ret void
}

; <hashbrown::raw::RawTableInner>::drop_elements::<(u8, u8)>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB6_13RawTableInner13drop_elementsThhEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #2 !guid !63 {
start:
  br label %bb9

bb9:                                              ; preds = %start
  ret void

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <hashbrown::raw::RawTableInner>::drop_inner_table::<(u8, u8), alloc::alloc::Global>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB6_13RawTableInner16drop_inner_tableThhENtNtCs7CppTae75M1_5alloc5alloc6GlobalECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %alloc, i64 %table_layout.0, i64 %table_layout.1) unnamed_addr #2 !guid !64 {
start:
; call <hashbrown::raw::RawTableInner>::is_empty_singleton
  %_4 = call zeroext i1 @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner18is_empty_singletonCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
  br i1 %_4, label %bb4, label %bb2

bb2:                                              ; preds = %start
; call <hashbrown::raw::RawTableInner>::drop_elements::<(u8, u8)>
  call void @_RINvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB6_13RawTableInner13drop_elementsThhEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self)
; call <hashbrown::raw::RawTableInner>::free_buckets::<alloc::alloc::Global>
  call void @_RINvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB6_13RawTableInner12free_bucketsNtNtCs7CppTae75M1_5alloc5alloc6GlobalECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %alloc, i64 %table_layout.0, i64 %table_layout.1) #18
  br label %bb4

bb4:                                              ; preds = %bb2, %start
  ret void
}

; hashbrown::map::equivalent_key::<u8, u8, u8>
; Function Attrs: nonlazybind uwtable
define internal ptr @_RINvNtCs7CvK5fPrMBK_9hashbrown3map14equivalent_keyhhhECs4julcnN5YCW_19panic_hashmap_index(ptr %k) unnamed_addr #2 !guid !65 {
start:
  ret ptr %k
}

; hashbrown::map::make_hash::<u8, std::hash::random::RandomState>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CvK5fPrMBK_9hashbrown3map9make_hashhNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %hash_builder, ptr %val) unnamed_addr #2 !guid !66 {
start:
; call <std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&u8>
  %_0 = call i64 @_RINvYNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateNtNtCsl10jNU3mE6R_4core4hash11BuildHasher8hash_oneRhECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %hash_builder, ptr %val)
  ret i64 %_0
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs4julcnN5YCW_19panic_hashmap_index(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #2 !guid !67 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.1, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::mem::replace::<core::mem::maybe_uninit::MaybeUninit<core::cell::Cell<(u64, u64)>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtB2_12maybe_uninit11MaybeUninitINtNtB4_4cell4CellTyyEEEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %dest, i64 %src.0, i64 %src.1) unnamed_addr #0 !guid !68 {
start:
  %result.0 = load i64, ptr %dest, align 8
  %0 = getelementptr inbounds i8, ptr %dest, i64 8
  %result.1 = load i64, ptr %0, align 8
  store i64 %src.0, ptr %dest, align 8
  %1 = getelementptr inbounds i8, ptr %dest, i64 8
  store i64 %src.1, ptr %1, align 8
  %2 = insertvalue { i64, i64 } poison, i64 %result.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %result.1, 1
  ret { i64, i64 } %3
}

; core::mem::replace::<core::option::Option<core::cell::Cell<(u64, u64)>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtB4_6option6OptionINtNtB4_4cell4CellTyyEEEECs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %result, ptr align 8 %dest, ptr align 8 %src) unnamed_addr #0 !guid !69 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %result, ptr align 8 %dest, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %dest, ptr align 8 %src, i64 24, i1 false)
  ret void
}

; core::mem::replace::<std::sys::thread_local::native::lazy::State<!>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazy5StatezEECs4julcnN5YCW_19panic_hashmap_index(ptr %dest, i1 zeroext %src) unnamed_addr #0 !guid !70 {
start:
  %0 = load i8, ptr %dest, align 1
  %result = trunc nuw i8 %0 to i1
  %1 = zext i1 %src to i8
  store i8 %1, ptr %dest, align 1
  ret i1 %result
}

; core::mem::replace::<(u64, u64)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvNtCsl10jNU3mE6R_4core3mem7replaceTyyEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %dest, i64 %src.0, i64 %src.1) unnamed_addr #0 !guid !71 {
start:
  %result.0 = load i64, ptr %dest, align 8
  %0 = getelementptr inbounds i8, ptr %dest, i64 8
  %result.1 = load i64, ptr %0, align 8
  store i64 %src.0, ptr %dest, align 8
  %1 = getelementptr inbounds i8, ptr %dest, i64 8
  store i64 %src.1, ptr %1, align 8
  %2 = insertvalue { i64, i64 } poison, i64 %result.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %result.1, 1
  ret { i64, i64 } %3
}

; core::ptr::drop_glue::<hashbrown::map::HashMap<u8, u8, std::hash::random::RandomState>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CvK5fPrMBK_9hashbrown3map7HashMaphhNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1) unnamed_addr #2 !guid !72 {
start:
; call core::ptr::drop_glue::<hashbrown::raw::RawTable<(u8, u8)>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CvK5fPrMBK_9hashbrown3raw8RawTableThhEEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<hashbrown::raw::RawTable<(u8, u8)>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CvK5fPrMBK_9hashbrown3raw8RawTableThhEEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1) unnamed_addr #2 !guid !73 {
start:
; call <hashbrown::raw::RawTable<(u8, u8)> as core::ops::drop::Drop>::drop
  call void @_RNvXsg_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<std::collections::hash::map::HashMap<u8, u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtCsddYV2PBJW9h_3std11collections4hash3map7HashMaphhEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1) unnamed_addr #2 !guid !74 {
start:
; call core::ptr::drop_glue::<hashbrown::map::HashMap<u8, u8, std::hash::random::RandomState>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CvK5fPrMBK_9hashbrown3map7HashMaphhNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs4julcnN5YCW_19panic_hashmap_index(i8 %dummy) unnamed_addr #0 !guid !75 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !76
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4julcnN5YCW_19panic_hashmap_index(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !77 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4julcnN5YCW_19panic_hashmap_index(ptr %f) #18
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #18
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<core::cell::Cell<(u64, u64)>, ()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsINtNtB6_4cell4CellTyyEEuECs4julcnN5YCW_19panic_hashmap_index(ptr %data_pointer) unnamed_addr #0 !guid !78 {
start:
  ret ptr %data_pointer
}

; <! as std::sys::thread_local::native::lazy::DestroyedState>::register_dtor::<core::cell::Cell<(u64, u64)>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXNtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazyzNtB3_14DestroyedState13register_dtorINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1) unnamed_addr #2 !guid !79 {
start:
  ret void
}

; <&u8 as core::hash::Hash>::hash::<std::hash::random::DefaultHasher>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs3_NtNtCsl10jNU3mE6R_4core4hash5implsRhNtB8_4Hash4hashNtNtNtCsddYV2PBJW9h_3std4hash6random13DefaultHasherECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr align 8 %state) unnamed_addr #0 !guid !80 {
start:
  %_4 = load ptr, ptr %self, align 8
; call <u8 as core::hash::Hash>::hash::<std::hash::random::DefaultHasher>
  call void @_RINvXs7_NtNtCsl10jNU3mE6R_4core4hash5implshNtB8_4Hash4hashNtNtNtCsddYV2PBJW9h_3std4hash6random13DefaultHasherECs4julcnN5YCW_19panic_hashmap_index(ptr %_4, ptr align 8 %state) #18
  ret void
}

; <u8 as core::hash::Hash>::hash::<std::hash::random::DefaultHasher>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs7_NtNtCsl10jNU3mE6R_4core4hash5implshNtB8_4Hash4hashNtNtNtCsddYV2PBJW9h_3std4hash6random13DefaultHasherECs4julcnN5YCW_19panic_hashmap_index(ptr %self, ptr align 8 %state) unnamed_addr #0 !guid !81 {
start:
  %_3 = load i8, ptr %self, align 1
; call <std::hash::random::DefaultHasher as core::hash::Hasher>::write_u8
  call void @_RNvYNtNtNtCsddYV2PBJW9h_3std4hash6random13DefaultHasherNtNtCsl10jNU3mE6R_4core4hash6Hasher8write_u8Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %state, i8 %_3) #18
  ret void
}

; <std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&u8>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvYNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateNtNtCsl10jNU3mE6R_4core4hash11BuildHasher8hash_oneRhECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !82 {
start:
  %hasher = alloca [72 x i8], align 8
  %x = alloca [8 x i8], align 8
  store ptr %0, ptr %x, align 8
; call <std::hash::random::RandomState as core::hash::BuildHasher>::build_hasher
  call void @_RNvXs_NtNtCsddYV2PBJW9h_3std4hash6randomNtB4_11RandomStateNtNtCsl10jNU3mE6R_4core4hash11BuildHasher12build_hasherCs4julcnN5YCW_19panic_hashmap_index(ptr sret([72 x i8]) align 8 %hasher, ptr align 8 %self) #18
  br label %bb1

bb1:                                              ; preds = %start
; call <&u8 as core::hash::Hash>::hash::<std::hash::random::DefaultHasher>
  call void @_RINvXs3_NtNtCsl10jNU3mE6R_4core4hash5implsRhNtB8_4Hash4hashNtNtNtCsddYV2PBJW9h_3std4hash6random13DefaultHasherECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %x, ptr align 8 %hasher) #18
  br label %bb2

bb2:                                              ; preds = %bb1
; call <std::hash::random::DefaultHasher as core::hash::Hasher>::finish
  %_0 = call i64 @_RNvXs2_NtNtCsddYV2PBJW9h_3std4hash6randomNtB5_13DefaultHasherNtNtCsl10jNU3mE6R_4core4hash6Hasher6finishCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %hasher) #18
  br label %bb3

bb3:                                              ; preds = %bb2
  br label %bb4

bb4:                                              ; preds = %bb3
  ret i64 %_0

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <hashbrown::raw::RawTable<(u8, u8)>>::find::<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB8_8RawTableThhEE4findNCINvNtBa_3map14equivalent_keyhhhE0E0Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1, i64 %index) unnamed_addr #0 !guid !83 {
start:
  %_6 = alloca [8 x i8], align 8
  %_7 = load ptr, ptr %_1, align 8
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_8 = load ptr, ptr %0, align 8
; call <hashbrown::raw::RawTable<(u8, u8)>>::bucket
  %1 = call ptr @_RNvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE6bucketCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_8, i64 %index) #18
  store ptr %1, ptr %_6, align 8
; call <hashbrown::raw::Bucket<(u8, u8)>>::as_ref
  %_4 = call ptr @_RNvMs4_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_6BucketThhEE6as_refCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_6) #18
; call hashbrown::map::equivalent_key::<u8, u8, u8>::{closure#0}
  %_0 = call zeroext i1 @_RNCINvNtCs7CvK5fPrMBK_9hashbrown3map14equivalent_keyhhhE0Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_7, ptr %_4) #18
  ret i1 %_0
}

; hashbrown::map::equivalent_key::<u8, u8, u8>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCINvNtCs7CvK5fPrMBK_9hashbrown3map14equivalent_keyhhhE0Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1, ptr %x) unnamed_addr #0 !guid !84 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call <u8 as hashbrown::Equivalent<u8>>::equivalent
  %_0 = call zeroext i1 @_RNvXCs7CvK5fPrMBK_9hashbrownhINtB2_10EquivalenthE10equivalentCs4julcnN5YCW_19panic_hashmap_index(ptr %_4, ptr %x)
  ret i1 %_0
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1) unnamed_addr #0 !guid !85 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4julcnN5YCW_19panic_hashmap_index(ptr %_4) #22
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs4julcnN5YCW_19panic_hashmap_index() #18
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs4julcnN5YCW_19panic_hashmap_index(i8 %_2) #18
  ret i32 %_0
}

; <std::hash::random::RandomState>::new::KEYS::{K#0}::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNCNKNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB8_11RandomState3new4KEYS0s_0Cs4julcnN5YCW_19panic_hashmap_index(ptr %_1, ptr align 8 %__rust_std_internal_init) unnamed_addr #0 !guid !86 {
start:
  %_3 = call ptr @llvm.threadlocal.address.p0(ptr @_RNvNCNKNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtBa_11RandomState3new4KEYS0s_023___RUST_STD_INTERNAL_VAL)
; call <std::sys::thread_local::native::lazy::Storage<core::cell::Cell<(u64, u64)>, !>>::get_or_init::<<std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
  %_0 = call ptr @_RINvMs0_NtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEzE11get_or_initNvNvNvMNtNtBe_4hash6randomNtB2d_11RandomState3new4KEYS27___rust_std_internal_init_fnECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_3, ptr align 8 %__rust_std_internal_init) #18
  ret ptr %_0
}

; <std::hash::random::RandomState>::new::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB4_11RandomState3new0Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %keys) unnamed_addr #0 !guid !87 {
start:
; call <core::cell::Cell<(u64, u64)>>::get
  %0 = call { i64, i64 } @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CellTyyEE3getCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %keys) #18
  %_5.0 = extractvalue { i64, i64 } %0, 0
  %_5.1 = extractvalue { i64, i64 } %0, 1
  %_0.i = add i64 %_5.0, 1
; call <core::cell::Cell<(u64, u64)>>::set
  call void @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CellTyyEE3setCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %keys, i64 %_0.i, i64 %_5.1) #18
  %1 = insertvalue { i64, i64 } poison, i64 %_5.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_5.1, 1
  ret { i64, i64 } %2
}

; <<hashbrown::raw::RawTable<(u8, u8)>>::find<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>::{closure#0} as core::ops::function::FnOnce<(usize,)>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNSNvYNCINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtBd_8RawTableThhEE4findNCINvNtBf_3map14equivalent_keyhhhE0E0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTjEE9call_once6vtableCs4julcnN5YCW_19panic_hashmap_index(ptr %_1, i64 %0) unnamed_addr #0 !guid !88 {
start:
  %_2 = alloca [8 x i8], align 8
  store i64 %0, ptr %_2, align 8
  %1 = load ptr, ptr %_1, align 8
  %2 = getelementptr inbounds i8, ptr %_1, i64 8
  %3 = load ptr, ptr %2, align 8
  %4 = load i64, ptr %_2, align 8
; call <<hashbrown::raw::RawTable<(u8, u8)>>::find<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>::{closure#0} as core::ops::function::FnOnce<(usize,)>>::call_once
  %_0 = call zeroext i1 @_RNvYNCINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtBb_8RawTableThhEE4findNCINvNtBd_3map14equivalent_keyhhhE0E0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTjEE9call_onceCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %1, ptr align 8 %3, i64 %4) #18
  ret i1 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs4julcnN5YCW_19panic_hashmap_index(ptr %_1) unnamed_addr #0 !guid !89 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4julcnN5YCW_19panic_hashmap_index(ptr %0) #18
  ret i32 %_0
}

; panic_hashmap_index::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs4julcnN5YCW_19panic_hashmap_index4main() unnamed_addr #2 personality ptr @rust_eh_personality !guid !90 {
start:
  %0 = alloca [16 x i8], align 8
  %_12 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_10 = alloca [1 x i8], align 1
  %m = alloca [48 x i8], align 8
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #18
  %_2.0 = extractvalue { ptr, ptr } %1, 0
  %_2.1 = extractvalue { ptr, ptr } %1, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call <std::collections::hash::map::HashMap<u8, u8>>::new
  call void @_RNvMNtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB2_7HashMaphhE3newCs4julcnN5YCW_19panic_hashmap_index(ptr sret([48 x i8]) align 8 %m) #18
; invoke core::hint::black_box::<u8>
  %2 = invoke i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs4julcnN5YCW_19panic_hashmap_index(i8 1)
          to label %bb4 unwind label %cleanup

bb12:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<std::collections::hash::map::HashMap<u8, u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtCsddYV2PBJW9h_3std11collections4hash3map7HashMaphhEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %m) #23
          to label %bb13 unwind label %terminate

cleanup:                                          ; preds = %bb9, %bb8, %bb7, %bb6, %bb5, %bb4, %start
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb12

bb4:                                              ; preds = %start
  store i8 %2, ptr %_10, align 1
; invoke <std::collections::hash::map::HashMap<u8, u8> as core::ops::index::Index<&u8>>::index
  %_7 = invoke ptr @_RNvXs8_NtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB5_7HashMaphhEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexRhE5indexCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %m, ptr %_10, ptr align 8 @alloc_fb468a87e7f5fee6e2ac28f20228937e)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_12, ptr %_7)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_12, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %8 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
  %_5.0 = extractvalue { ptr, ptr } %8, 0
  %_5.1 = extractvalue { ptr, ptr } %8, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_5.0, ptr %_5.1)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
; invoke <core::fmt::Arguments>::from_str
  %9 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  %_16.0 = extractvalue { ptr, ptr } %9, 0
  %_16.1 = extractvalue { ptr, ptr } %9, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_16.0, ptr %_16.1)
          to label %bb10 unwind label %cleanup

bb10:                                             ; preds = %bb9
; call core::ptr::drop_glue::<std::collections::hash::map::HashMap<u8, u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtCsddYV2PBJW9h_3std11collections4hash3map7HashMaphhEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %m)
  ret void

terminate:                                        ; preds = %bb12
  %10 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb13:                                             ; preds = %bb12
  %11 = load ptr, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  %13 = load i32, ptr %12, align 8
  %14 = insertvalue { ptr, i32 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i32 } %14, i32 %13, 1
  resume { ptr, i32 } %15
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs4julcnN5YCW_19panic_hashmap_index(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !91 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<core::cell::Cell<(u64, u64)>>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionINtNtB4_4cell4CellTyyEEE4takeCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !92 {
start:
  %_2 = alloca [24 x i8], align 8
  store i64 0, ptr %_2, align 8
; call core::mem::replace::<core::option::Option<core::cell::Cell<(u64, u64)>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtB4_6option6OptionINtNtB4_4cell4CellTyyEEEECs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, ptr align 8 %_2) #18
  ret void
}

; <core::option::Option<&u8>>::expect
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE6expectCs4julcnN5YCW_19panic_hashmap_index(ptr %0, ptr %msg.0, i64 %msg.1, ptr align 8 %1) unnamed_addr #0 !guid !93 {
start:
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = load ptr, ptr %self, align 8
  %3 = ptrtoint ptr %2 to i64
  %4 = icmp eq i64 %3, 0
  %_3 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %val = load ptr, ptr %self, align 8
  ret ptr %val

bb2:                                              ; preds = %start
; call core::option::expect_failed
  call void @_RNvNtCsl10jNU3mE6R_4core6option13expect_failed(ptr %msg.0, i64 %msg.1, ptr align 8 %1) #21
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<(core::alloc::layout::Layout, usize)>>::unwrap_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionTNtNtNtB4_5alloc6layout6LayoutjEE16unwrap_uncheckedCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %val, ptr align 8 %self, ptr align 8 %0) unnamed_addr #0 !guid !94 {
start:
  %1 = load i64, ptr %self, align 8
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %val, ptr align 8 %self, i64 24, i1 false)
  ret void

bb2:                                              ; preds = %start
; call core::hint::unreachable_unchecked
  call void @_RNvNtCsl10jNU3mE6R_4core4hint21unreachable_uncheckedCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %0) #25
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <hashbrown::control::tag::Tag>::full
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control3tagNtB2_3Tag4fullCs4julcnN5YCW_19panic_hashmap_index(i64 %hash) unnamed_addr #0 !guid !95 {
start:
  %top7 = lshr i64 %hash, 57
  %_6 = and i64 %top7, 127
  %_5 = trunc i64 %_6 to i8
  ret i8 %_5
}

; <hashbrown::control::bitmask::BitMask>::any_bit_set
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB2_7BitMask11any_bit_setCs4julcnN5YCW_19panic_hashmap_index(i16 %self) unnamed_addr #0 !guid !96 {
start:
  %_0 = icmp ne i16 %self, 0
  ret i1 %_0
}

; <hashbrown::control::bitmask::BitMask>::lowest_set_bit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB2_7BitMask14lowest_set_bitCs4julcnN5YCW_19panic_hashmap_index(i16 %self) unnamed_addr #0 !guid !97 {
start:
  %_2 = alloca [2 x i8], align 2
  %_0 = alloca [16 x i8], align 8
; call <core::num::nonzero::NonZero<u16>>::new
  %0 = call i16 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE3newB9_(i16 %self) #18
  store i16 %0, ptr %_2, align 2
  %1 = load i16, ptr %_2, align 2
  %2 = icmp eq i16 %1, 0
  %_4 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_4 to i1
  br i1 %3, label %bb2, label %bb4

bb2:                                              ; preds = %start
  %nonzero = load i16, ptr %_2, align 2
; call <hashbrown::control::bitmask::BitMask>::nonzero_trailing_zeros
  %_6 = call i64 @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB2_7BitMask22nonzero_trailing_zerosCs4julcnN5YCW_19panic_hashmap_index(i16 %nonzero) #18
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb4, %bb2
  %5 = load i64, ptr %_0, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { i64, i64 } poison, i64 %5, 0
  %9 = insertvalue { i64, i64 } %8, i64 %7, 1
  ret { i64, i64 } %9

bb6:                                              ; No predecessors!
  unreachable
}

; <hashbrown::control::bitmask::BitMask>::remove_lowest_bit
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB2_7BitMask17remove_lowest_bitCs4julcnN5YCW_19panic_hashmap_index(i16 %self) unnamed_addr #0 !guid !98 {
start:
  %_4 = sub i16 %self, 1
  %_2 = and i16 %self, %_4
  ret i16 %_2
}

; <hashbrown::control::bitmask::BitMask>::nonzero_trailing_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB2_7BitMask22nonzero_trailing_zerosCs4julcnN5YCW_19panic_hashmap_index(i16 %nonzero) unnamed_addr #0 !guid !99 {
start:
; call <core::num::nonzero::NonZero<u16>>::trailing_zeros
  %_4 = call i32 @_RNvMsN_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE14trailing_zerosCs4julcnN5YCW_19panic_hashmap_index(i16 %nonzero) #18
  %_3 = zext i32 %_4 to i64
  %_0 = udiv i64 %_3, 1
  ret i64 %_0
}

; <std::hash::random::RandomState>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB2_11RandomState3newCs4julcnN5YCW_19panic_hashmap_index() unnamed_addr #0 !guid !100 {
start:
; call <std::thread::local::LocalKey<core::cell::Cell<(u64, u64)>>>::with::<<std::hash::random::RandomState>::new::{closure#0}, std::hash::random::RandomState>
  %0 = call { i64, i64 } @_RINvMs2_NtNtCsddYV2PBJW9h_3std6thread5localINtB6_8LocalKeyINtNtCsl10jNU3mE6R_4core4cell4CellTyyEEE4withNCNvMNtNtBa_4hash6randomNtB1I_11RandomState3new0B21_ECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 @alloc_1d994709d59334fa22f8615b086434c8)
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::mem::maybe_dangling::MaybeDangling<core::cell::Cell<(u64, u64)>>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtB6_4cell4CellTyyEEE3newCs4julcnN5YCW_19panic_hashmap_index(i64 %x.0, i64 %x.1) unnamed_addr #2 !guid !101 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %x.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %x.1, 1
  ret { i64, i64 } %1
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs4julcnN5YCW_19panic_hashmap_index(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !102 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4julcnN5YCW_19panic_hashmap_index() #18
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(i64 %align, ptr align 8 %0) #19
  br label %bb3
}

; <core::mem::alignment::Alignment>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCs4julcnN5YCW_19panic_hashmap_index(i64 %align) unnamed_addr #0 !guid !103 {
start:
  %_0 = alloca [8 x i8], align 8
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs4julcnN5YCW_19panic_hashmap_index(i64 %align, ptr align 8 @alloc_988c380202cc7b7a37ca3d8d5930c44f) #18
  store i64 %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <*const core::cell::Cell<(u64, u64)>>::as_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPINtNtB6_4cell4CellTyyEE6as_refCs4julcnN5YCW_19panic_hashmap_index(ptr %self) unnamed_addr #0 !guid !104 {
start:
  %_0 = alloca [8 x i8], align 8
; call <*const core::cell::Cell<(u64, u64)>>::is_null
  %_2 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPINtNtB6_4cell4CellTyyEE7is_nullCs4julcnN5YCW_19panic_hashmap_index(ptr %self) #18
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store ptr %self, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <*const core::cell::Cell<(u64, u64)>>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPINtNtB6_4cell4CellTyyEE7is_nullCs4julcnN5YCW_19panic_hashmap_index(ptr %self) unnamed_addr #0 !guid !105 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCs4julcnN5YCW_19panic_hashmap_index(ptr %self) #18
  ret i1 %_0
}

; <core::alloc::layout::Layout>::is_size_align_valid
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCs4julcnN5YCW_19panic_hashmap_index(i64 %size, i64 %align) unnamed_addr #0 !guid !106 {
start:
  %_4 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
; call <core::mem::alignment::Alignment>::new
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCs4julcnN5YCW_19panic_hashmap_index(i64 %align) #18
  store i64 %0, ptr %_4, align 8
  %1 = load i64, ptr %_4, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %alignment = load i64, ptr %_4, align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %4 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_align_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCs4julcnN5YCW_19panic_hashmap_index(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !107 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(i64 %size, i64 %align, ptr align 8 %0) #19
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %align, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !108 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !109 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <hashbrown::control::group::sse2::Group>::match_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMNtNtNtCs7CvK5fPrMBK_9hashbrown7control5group4sse2NtB2_5Group11match_emptyCs4julcnN5YCW_19panic_hashmap_index(ptr align 16 %self) unnamed_addr #0 !guid !110 {
start:
  %0 = alloca [16 x i8], align 16
  %1 = load <2 x i64>, ptr %self, align 16
  store <2 x i64> %1, ptr %0, align 16
; call <hashbrown::control::group::sse2::Group>::match_tag
  %_0 = call i16 @_RNvMNtNtNtCs7CvK5fPrMBK_9hashbrown7control5group4sse2NtB2_5Group9match_tagCs4julcnN5YCW_19panic_hashmap_index(ptr align 16 %0, i8 -1) #18
  ret i16 %_0
}

; <hashbrown::control::group::sse2::Group>::load
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtNtCs7CvK5fPrMBK_9hashbrown7control5group4sse2NtB2_5Group4loadCs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %_0, ptr %ptr) unnamed_addr #0 !guid !111 {
start:
  %0 = alloca [16 x i8], align 16
; call core::core_arch::x86::sse2::_mm_loadu_si128
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse215__mm_loadu_si128Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %0, ptr %ptr) #18
  %_2 = load <2 x i64>, ptr %0, align 16
  store <2 x i64> %_2, ptr %_0, align 16
  ret void
}

; <hashbrown::control::group::sse2::Group>::match_tag
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMNtNtNtCs7CvK5fPrMBK_9hashbrown7control5group4sse2NtB2_5Group9match_tagCs4julcnN5YCW_19panic_hashmap_index(ptr align 16 %self, i8 %tag) unnamed_addr #0 !guid !112 {
start:
  %0 = alloca [16 x i8], align 16
  %1 = alloca [16 x i8], align 16
  %2 = alloca [16 x i8], align 16
  %3 = alloca [16 x i8], align 16
  %4 = alloca [16 x i8], align 16
  %_4 = load <2 x i64>, ptr %self, align 16
; call core::core_arch::x86::sse2::_mm_set1_epi8
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse213__mm_set1_epi8Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %4, i8 %tag) #18
  %_5 = load <2 x i64>, ptr %4, align 16
  store <2 x i64> %_4, ptr %2, align 16
  store <2 x i64> %_5, ptr %1, align 16
; call core::core_arch::x86::sse2::_mm_cmpeq_epi8
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse214__mm_cmpeq_epi8Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %3, ptr align 16 %2, ptr align 16 %1) #18
  %cmp = load <2 x i64>, ptr %3, align 16
  store <2 x i64> %cmp, ptr %0, align 16
; call core::core_arch::x86::sse2::_mm_movemask_epi8
  %_9 = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse217__mm_movemask_epi8Cs4julcnN5YCW_19panic_hashmap_index(ptr align 16 %0) #18
  %_8 = trunc i32 %_9 to i16
  ret i16 %_8
}

; <std::collections::hash::map::HashMap<u8, u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB2_7HashMaphhE3newCs4julcnN5YCW_19panic_hashmap_index(ptr sret([48 x i8]) align 8 %_0) unnamed_addr #0 !guid !113 {
start:
; call <std::collections::hash::map::HashMap<u8, u8> as core::default::Default>::default
  call void @_RNvXs7_NtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB5_7HashMaphhENtNtCsl10jNU3mE6R_4core7default7Default7defaultCs4julcnN5YCW_19panic_hashmap_index(ptr sret([48 x i8]) align 8 %_0) #18
  ret void
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs4julcnN5YCW_19panic_hashmap_index(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !114 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs4julcnN5YCW_19panic_hashmap_index(ptr %2, i64 %4, i64 %6) #18
  ret void
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !115 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %layout) #18
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, i64 %3, i64 %5) #18
  br label %bb3
}

; <hashbrown::raw::ProbeSeq>::move_next
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_8ProbeSeq9move_nextCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %bucket_mask) unnamed_addr #0 !guid !116 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = add i64 %2, 16
  store i64 %3, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load i64, ptr %4, align 8
  %5 = load i64, ptr %self, align 8
  %6 = add i64 %5, %_3
  store i64 %6, ptr %self, align 8
  %7 = load i64, ptr %self, align 8
  %8 = and i64 %7, %bucket_mask
  store i64 %8, ptr %self, align 8
  ret void
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs4julcnN5YCW_19panic_hashmap_index(i32 %self) unnamed_addr #0 !guid !117 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs4julcnN5YCW_19panic_hashmap_index(i32 %self) #18
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs4julcnN5YCW_19panic_hashmap_index(i32 %self) unnamed_addr #0 !guid !118 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::hash::sip::Hasher<core::hash::sip::Sip13Rounds>>::new_with_keys
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtNtCsl10jNU3mE6R_4core4hash3sipINtB5_6HasherNtB5_11Sip13RoundsE13new_with_keysCs4julcnN5YCW_19panic_hashmap_index(ptr sret([72 x i8]) align 8 %_0, i64 %key0, i64 %key1) unnamed_addr #0 !guid !119 {
start:
  %_4 = alloca [32 x i8], align 8
  %state = alloca [72 x i8], align 8
  store i64 0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  store i64 0, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_4, i64 24
  store i64 0, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %state, i64 32
  store i64 %key0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %state, i64 40
  store i64 %key1, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %state, i64 48
  store i64 0, ptr %5, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %state, ptr align 8 %_4, i64 32, i1 false)
  %6 = getelementptr inbounds i8, ptr %state, i64 56
  store i64 0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %state, i64 64
  store i64 0, ptr %7, align 8
; call <core::hash::sip::Hasher<core::hash::sip::Sip13Rounds>>::reset
  call void @_RNvMs0_NtNtCsl10jNU3mE6R_4core4hash3sipINtB5_6HasherNtB5_11Sip13RoundsE5resetCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %state) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %state, i64 72, i1 false)
  ret void
}

; <core::hash::sip::Hasher<core::hash::sip::Sip13Rounds>>::reset
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtNtCsl10jNU3mE6R_4core4hash3sipINtB5_6HasherNtB5_11Sip13RoundsE5resetCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !120 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 48
  store i64 0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 32
  %_2 = load i64, ptr %1, align 8
  %2 = xor i64 %_2, 8317987319222330741
  store i64 %2, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 40
  %_3 = load i64, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 16
  %5 = xor i64 %_3, 7237128888997146477
  store i64 %5, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %self, i64 32
  %_4 = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %self, i64 8
  %8 = xor i64 %_4, 7816392313619706465
  store i64 %8, ptr %7, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 40
  %_5 = load i64, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %self, i64 24
  %11 = xor i64 %_5, 8387220255154660723
  store i64 %11, ptr %10, align 8
  %12 = getelementptr inbounds i8, ptr %self, i64 64
  store i64 0, ptr %12, align 8
  ret void
}

; <std::collections::hash::map::HashMap<u8, u8>>::with_hasher
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB5_7HashMaphhE11with_hasherCs4julcnN5YCW_19panic_hashmap_index(ptr sret([48 x i8]) align 8 %_0, i64 %hash_builder.0, i64 %hash_builder.1) unnamed_addr #0 !guid !121 {
start:
  %_2 = alloca [48 x i8], align 8
; call <hashbrown::map::HashMap<u8, u8, std::hash::random::RandomState>>::with_hasher
  call void @_RNvMs_NtCs7CvK5fPrMBK_9hashbrown3mapINtB4_7HashMaphhNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateE11with_hasherCs4julcnN5YCW_19panic_hashmap_index(ptr sret([48 x i8]) align 8 %_2, i64 %hash_builder.0, i64 %hash_builder.1)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 48, i1 false)
  ret void
}

; <core::core_arch::x86::__m128i>::as_i8x16
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs1K_NtNtCsl10jNU3mE6R_4core9core_arch3x86NtB6_7___m128i8as_i8x16Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %_0, ptr align 16 %self) unnamed_addr #0 !guid !122 {
start:
  %0 = load <2 x i64>, ptr %self, align 16
  store <2 x i64> %0, ptr %_0, align 16
  ret void
}

; <core::core_arch::simd::Simd<i8, 16>>::as_m128i
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs1P_NtNtCsl10jNU3mE6R_4core9core_arch3x86INtNtB8_4simd4SimdaKj10_E8as_m128iCs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %_0, ptr align 16 %self) unnamed_addr #0 !guid !123 {
start:
  %0 = load <16 x i8>, ptr %self, align 16
  store <16 x i8> %0, ptr %_0, align 16
  ret void
}

; <hashbrown::raw::TableLayout>::calculate_layout_for
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs1_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_11TableLayout20calculate_layout_forCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, i64 %self.0, i64 %self.1, i64 %buckets) unnamed_addr #0 !guid !124 {
start:
  %_26 = alloca [24 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_8 = alloca [16 x i8], align 8
  %_6 = alloca [16 x i8], align 8
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs4julcnN5YCW_19panic_hashmap_index(i64 %self.0, i64 %buckets) #18
  %_9.0 = extractvalue { i64, i64 } %0, 0
  %_9.1 = extractvalue { i64, i64 } %0, 1
; call <core::option::Option<usize> as core::ops::try_trait::Try>::branch
  %1 = call { i64, i64 } @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionjENtNtNtB7_3ops9try_trait3Try6branchB7_(i64 %_9.0, i64 %_9.1) #18
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_8, align 8
  %4 = getelementptr inbounds i8, ptr %_8, i64 8
  store i64 %3, ptr %4, align 8
  %_10 = load i64, ptr %_8, align 8
  %5 = getelementptr inbounds i8, ptr %_8, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_10 to i1
  br i1 %7, label %bb5, label %bb4

bb5:                                              ; preds = %start
; call <core::option::Option<(core::alloc::layout::Layout, usize)> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  call void @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTNtNtNtB7_5alloc6layout6LayoutjEEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0) #18
  br label %bb17

bb4:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_8, i64 8
  %val = load i64, ptr %8, align 8
  %_12 = sub i64 %self.1, 1
; call <usize>::checked_add
  %9 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCs4julcnN5YCW_19panic_hashmap_index(i64 %val, i64 %_12) #18
  %_7.0 = extractvalue { i64, i64 } %9, 0
  %_7.1 = extractvalue { i64, i64 } %9, 1
; call <core::option::Option<usize> as core::ops::try_trait::Try>::branch
  %10 = call { i64, i64 } @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionjENtNtNtB7_3ops9try_trait3Try6branchB7_(i64 %_7.0, i64 %_7.1) #18
  %11 = extractvalue { i64, i64 } %10, 0
  %12 = extractvalue { i64, i64 } %10, 1
  store i64 %11, ptr %_6, align 8
  %13 = getelementptr inbounds i8, ptr %_6, i64 8
  store i64 %12, ptr %13, align 8
  %_13 = load i64, ptr %_6, align 8
  %14 = getelementptr inbounds i8, ptr %_6, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = trunc nuw i64 %_13 to i1
  br i1 %16, label %bb9, label %bb8

bb9:                                              ; preds = %bb4
; call <core::option::Option<(core::alloc::layout::Layout, usize)> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  call void @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTNtNtNtB7_5alloc6layout6LayoutjEEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0) #18
  br label %bb17

bb8:                                              ; preds = %bb4
  %17 = getelementptr inbounds i8, ptr %_6, i64 8
  %val1 = load i64, ptr %17, align 8
  %_16 = sub i64 %self.1, 1
  %_15 = xor i64 %_16, -1
  %ctrl_offset = and i64 %val1, %_15
  %_19 = add i64 %buckets, 16
; call <usize>::checked_add
  %18 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCs4julcnN5YCW_19panic_hashmap_index(i64 %ctrl_offset, i64 %_19) #18
  %_18.0 = extractvalue { i64, i64 } %18, 0
  %_18.1 = extractvalue { i64, i64 } %18, 1
; call <core::option::Option<usize> as core::ops::try_trait::Try>::branch
  %19 = call { i64, i64 } @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionjENtNtNtB7_3ops9try_trait3Try6branchB7_(i64 %_18.0, i64 %_18.1) #18
  %20 = extractvalue { i64, i64 } %19, 0
  %21 = extractvalue { i64, i64 } %19, 1
  store i64 %20, ptr %_17, align 8
  %22 = getelementptr inbounds i8, ptr %_17, i64 8
  store i64 %21, ptr %22, align 8
  %_20 = load i64, ptr %_17, align 8
  %23 = getelementptr inbounds i8, ptr %_17, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = trunc nuw i64 %_20 to i1
  br i1 %25, label %bb13, label %bb12

bb13:                                             ; preds = %bb8
; call <core::option::Option<(core::alloc::layout::Layout, usize)> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  call void @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTNtNtNtB7_5alloc6layout6LayoutjEEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0) #18
  br label %bb17

bb12:                                             ; preds = %bb8
  %26 = getelementptr inbounds i8, ptr %_17, i64 8
  %len = load i64, ptr %26, align 8
  %_25 = sub i64 %self.1, 1
  %_23 = sub i64 9223372036854775807, %_25
  %_22 = icmp ugt i64 %len, %_23
  br i1 %_22, label %bb14, label %bb15

bb15:                                             ; preds = %bb12
; call <core::alloc::layout::Layout>::from_size_align_unchecked
  %27 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCs4julcnN5YCW_19panic_hashmap_index(i64 %len, i64 %self.1, ptr align 8 @alloc_738ae211beea0bce7ffb44e2c9946e50) #18
  %_27.0 = extractvalue { i64, i64 } %27, 0
  %_27.1 = extractvalue { i64, i64 } %27, 1
  store i64 %_27.0, ptr %_26, align 8
  %28 = getelementptr inbounds i8, ptr %_26, i64 8
  store i64 %_27.1, ptr %28, align 8
  %29 = getelementptr inbounds i8, ptr %_26, i64 16
  store i64 %ctrl_offset, ptr %29, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_26, i64 24, i1 false)
  br label %bb17

bb14:                                             ; preds = %bb12
  store i64 0, ptr %_0, align 8
  br label %bb17

bb17:                                             ; preds = %bb5, %bb9, %bb13, %bb14, %bb15
  ret void

bb3:                                              ; No predecessors!
  unreachable
}

; <core::mem::maybe_uninit::MaybeUninit<core::cell::Cell<(u64, u64)>>>::assume_init_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitINtNtB9_4cell4CellTyyEEE16assume_init_dropCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #2 !guid !125 {
start:
  ret void
}

; <core::ptr::non_null::NonNull<(u8, u8)>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullThhEE13new_uncheckedCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !126 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4julcnN5YCW_19panic_hashmap_index() #18
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, ptr align 8 %0) #19
  br label %bb3
}

; <core::fmt::Arguments>::from_str_nonconst
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCs4julcnN5YCW_19panic_hashmap_index(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !127 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr %s.0, i64 %s.1) #18
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <hashbrown::raw::Bucket<(u8, u8)>>::from_base_index
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_6BucketThhEE15from_base_indexCs4julcnN5YCW_19panic_hashmap_index(ptr %base, i64 %index) unnamed_addr #0 !guid !128 {
start:
  %_0.i = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
  %_3.i = sub nsw i64 0, %index
  %0 = getelementptr inbounds { i8, i8 }, ptr %base, i64 %_3.i
  store ptr %0, ptr %_0.i, align 8
  %1 = load ptr, ptr %_0.i, align 8
  store ptr %1, ptr %ptr, align 8
  br label %bb4

bb4:                                              ; preds = %bb2
  %_7 = load ptr, ptr %ptr, align 8
; call <core::ptr::non_null::NonNull<(u8, u8)>>::new_unchecked
  %_6 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullThhEE13new_uncheckedCs4julcnN5YCW_19panic_hashmap_index(ptr %_7, ptr align 8 @alloc_98906c2a737ea6157b34427fbd8045c5) #18
  ret ptr %_6

bb1:                                              ; No predecessors!
  unreachable
}

; <hashbrown::raw::Bucket<(u8, u8)>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_6BucketThhEE6as_ptrCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !129 {
start:
  %_0.i = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  br label %bb3

bb3:                                              ; preds = %start
  %_4 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds { i8, i8 }, ptr %_4, i64 -1
  store ptr %0, ptr %_0.i, align 8
  %1 = load ptr, ptr %_0.i, align 8
  store ptr %1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3
  %2 = load ptr, ptr %_0, align 8
  ret ptr %2

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <hashbrown::raw::Bucket<(u8, u8)>>::as_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_6BucketThhEE6as_refCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !130 {
start:
; call <hashbrown::raw::Bucket<(u8, u8)>>::as_ptr
  %_2 = call ptr @_RNvMs4_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_6BucketThhEE6as_ptrCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
  ret ptr %_2
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !131 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs4julcnN5YCW_19panic_hashmap_index(ptr %s.0, i64 %s.1) #18
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <hashbrown::raw::RawTable<(u8, u8)>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE3newCs4julcnN5YCW_19panic_hashmap_index(ptr sret([32 x i8]) align 8 %_0) unnamed_addr #0 !guid !132 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.d97814a45295a1360f772f6204a83572.0, i64 32, i1 false)
  ret void
}

; <hashbrown::raw::RawTable<(u8, u8)>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE3lenCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !133 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 24
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <hashbrown::raw::RawTable<(u8, u8)>>::bucket
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE6bucketCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %index) unnamed_addr #0 !guid !134 {
start:
; call <hashbrown::raw::RawTable<(u8, u8)>>::data_end
  %_6 = call ptr @_RNvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE8data_endCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
; call <hashbrown::raw::Bucket<(u8, u8)>>::from_base_index
  %_0 = call ptr @_RNvMs4_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_6BucketThhEE15from_base_indexCs4julcnN5YCW_19panic_hashmap_index(ptr %_6, i64 %index) #18
  ret ptr %_0
}

; <hashbrown::raw::RawTable<(u8, u8)>>::data_end
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE8data_endCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !135 {
start:
  %_2 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast::<(u8, u8)>
  %_0 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castThhEECs4julcnN5YCW_19panic_hashmap_index(ptr %_2) #18
  ret ptr %_0
}

; <hashbrown::raw::RawTable<(u8, u8)>>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE8is_emptyCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !136 {
start:
; call <hashbrown::raw::RawTable<(u8, u8)>>::len
  %_2 = call i64 @_RNvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE3lenCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
  %_0 = icmp eq i64 %_2, 0
  ret i1 %_0
}

; <core::cell::Cell<std::sys::thread_local::native::lazy::State<!>>>::replace
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CellINtNtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazy5StatezEE7replaceCs4julcnN5YCW_19panic_hashmap_index(ptr %self, i1 zeroext %val) unnamed_addr #0 personality ptr @rust_eh_personality !guid !137 {
start:
  %_7 = alloca [1 x i8], align 1
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_7, align 1
; call core::mem::replace::<std::sys::thread_local::native::lazy::State<!>>
  %_0 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazy5StatezEECs4julcnN5YCW_19panic_hashmap_index(ptr %self, i1 zeroext %val) #18
  br label %bb2

bb2:                                              ; preds = %bb1
  ret i1 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::cell::Cell<(u64, u64)>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CellTyyEE3newCs4julcnN5YCW_19panic_hashmap_index(i64 %value.0, i64 %value.1) unnamed_addr #0 !guid !138 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %value.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %value.1, 1
  %_2.0 = extractvalue { i64, i64 } %1, 0
  %_2.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_2.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_2.1, 1
  ret { i64, i64 } %3
}

; <core::cell::Cell<(u64, u64)>>::set
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CellTyyEE3setCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %val.0, i64 %val.1) unnamed_addr #0 !guid !139 {
start:
; call <core::cell::Cell<(u64, u64)>>::replace
  %0 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CellTyyEE7replaceCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %val.0, i64 %val.1) #18
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
  ret void
}

; <core::cell::Cell<(u64, u64)>>::replace
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CellTyyEE7replaceCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %val.0, i64 %val.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !140 {
start:
  %_7 = alloca [1 x i8], align 1
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_7, align 1
; call core::mem::replace::<(u64, u64)>
  %0 = call { i64, i64 } @_RINvNtCsl10jNU3mE6R_4core3mem7replaceTyyEECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %val.0, i64 %val.1) #18
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::cell::Cell<std::sys::thread_local::native::lazy::State<!>>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CellINtNtNtNtNtCsddYV2PBJW9h_3std3sys12thread_local6native4lazy5StatezEE3getCs4julcnN5YCW_19panic_hashmap_index(ptr %self) unnamed_addr #0 !guid !141 {
start:
  %0 = load i8, ptr %self, align 1
  %_0 = trunc nuw i8 %0 to i1
  ret i1 %_0
}

; <core::cell::Cell<(u64, u64)>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CellTyyEE3getCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !142 {
start:
  %_0.0 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0.1 = load i64, ptr %0, align 8
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs4julcnN5YCW_19panic_hashmap_index(ptr %self) unnamed_addr #0 !guid !143 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCs4julcnN5YCW_19panic_hashmap_index(i64 %self, i64 %rhs) unnamed_addr #0 !guid !144 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5.0 = add i64 %self, %rhs
  %_5.1 = icmp ult i64 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs4julcnN5YCW_19panic_hashmap_index(i64 %self, i64 %rhs) unnamed_addr #0 !guid !145 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs4julcnN5YCW_19panic_hashmap_index(i64 %self, i64 %other) unnamed_addr #0 !guid !146 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs4julcnN5YCW_19panic_hashmap_index(i32 %_0.i) #18
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <core::num::nonzero::NonZero<u16>>::trailing_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsN_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE14trailing_zerosCs4julcnN5YCW_19panic_hashmap_index(i16 %self) unnamed_addr #0 !guid !147 {
start:
; call <core::num::nonzero::NonZero<u16>>::get
  %_2 = call i16 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE3getB9_(i16 %self) #18
  %0 = call i16 @llvm.cttz.i16(i16 %_2, i1 true)
  %_0 = zext i16 %0 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs4julcnN5YCW_19panic_hashmap_index(i8 %0) unnamed_addr #0 !guid !148 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs4julcnN5YCW_19panic_hashmap_index(ptr %self) #18
  ret i32 %_0
}

; <hashbrown::map::HashMap<u8, u8, std::hash::random::RandomState>>::with_hasher
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CvK5fPrMBK_9hashbrown3mapINtB4_7HashMaphhNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateE11with_hasherCs4julcnN5YCW_19panic_hashmap_index(ptr sret([48 x i8]) align 8 %_0, i64 %hash_builder.0, i64 %hash_builder.1) unnamed_addr #2 personality ptr @rust_eh_personality !guid !149 {
start:
  %_3 = alloca [32 x i8], align 8
; call <hashbrown::raw::RawTable<(u8, u8)>>::new
  call void @_RNvMs5_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEE3newCs4julcnN5YCW_19panic_hashmap_index(ptr sret([32 x i8]) align 8 %_3) #18
  br label %bb1

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %_0, i64 32
  store i64 %hash_builder.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %hash_builder.1, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_3, i64 32, i1 false)
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <core::hash::sip::SipHasher13>::new_with_keys
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core4hash3sipNtB4_11SipHasher1313new_with_keysCs4julcnN5YCW_19panic_hashmap_index(ptr sret([72 x i8]) align 8 %_0, i64 %key0, i64 %key1) unnamed_addr #0 !guid !150 {
start:
  %_3 = alloca [72 x i8], align 8
; call <core::hash::sip::Hasher<core::hash::sip::Sip13Rounds>>::new_with_keys
  call void @_RNvMs0_NtNtCsl10jNU3mE6R_4core4hash3sipINtB5_6HasherNtB5_11Sip13RoundsE13new_with_keysCs4julcnN5YCW_19panic_hashmap_index(ptr sret([72 x i8]) align 8 %_3, i64 %key0, i64 %key1) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_3, i64 72, i1 false)
  ret void
}

; <hashbrown::raw::RawTableInner>::num_buckets
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner11num_bucketsCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !151 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_2 = load i64, ptr %0, align 8
  %_0 = add i64 %_2, 1
  ret i64 %_0
}

; <hashbrown::raw::RawTableInner>::allocation_info
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner15allocation_infoCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %table_layout.0, i64 %table_layout.1) unnamed_addr #0 !guid !152 {
start:
  %_0.i = alloca [8 x i8], align 8
  %0 = alloca [24 x i8], align 8
  %option = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
; call <hashbrown::raw::RawTableInner>::num_buckets
  %_7 = call i64 @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner11num_bucketsCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
; call <hashbrown::raw::TableLayout>::calculate_layout_for
  call void @_RNvMs1_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_11TableLayout20calculate_layout_forCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %option, i64 %table_layout.0, i64 %table_layout.1, i64 %_7) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %option, i64 24, i1 false)
; call <core::option::Option<(core::alloc::layout::Layout, usize)>>::unwrap_unchecked
  call void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionTNtNtNtB4_5alloc6layout6LayoutjEE16unwrap_uncheckedCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %0, ptr align 8 @alloc_ce5479cc7c79a6c41f8dc5cf14a25542) #18
  %layout.0 = load i64, ptr %_5, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 8
  %layout.1 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 16
  %ctrl_offset = load i64, ptr %2, align 8
  %_11 = load ptr, ptr %self, align 8
  %_3.i = sub nsw i64 0, %ctrl_offset
  %3 = getelementptr inbounds i8, ptr %_11, i64 %_3.i
  store ptr %3, ptr %_0.i, align 8
  %4 = load ptr, ptr %_0.i, align 8
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_8 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCs7CppTae75M1_5alloc(ptr %4, ptr align 8 @alloc_a9e8aead2791cdafa63aa359258ea1bd) #18
  store ptr %_8, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %layout.0, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  store i64 %layout.1, ptr %6, align 8
  ret void
}

; <hashbrown::raw::RawTableInner>::is_empty_singleton
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner18is_empty_singletonCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !153 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_2 = load i64, ptr %0, align 8
  %_0 = icmp eq i64 %_2, 0
  ret i1 %_0
}

; <hashbrown::raw::RawTableInner>::ctrl
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner4ctrlCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %index) unnamed_addr #0 !guid !154 {
start:
  %_5 = load ptr, ptr %self, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %_5, i64 %index
  ret ptr %_0.i
}

; <hashbrown::raw::RawTableInner>::probe_seq
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB5_13RawTableInner9probe_seqCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i64 %hash) unnamed_addr #0 !guid !155 {
start:
; call hashbrown::raw::h1
  %_4 = call i64 @_RNvNtCs7CvK5fPrMBK_9hashbrown3raw2h1Cs4julcnN5YCW_19panic_hashmap_index(i64 %hash) #18
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_5 = load i64, ptr %0, align 8
  %_3 = and i64 %_4, %_5
  %1 = insertvalue { i64, i64 } poison, i64 %_3, 0
  %2 = insertvalue { i64, i64 } %1, i64 0, 1
  ret { i64, i64 } %2
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !156 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %layout) #18
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %layout) #18
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #26
  ret void
}

; hashbrown::raw::h1
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtCs7CvK5fPrMBK_9hashbrown3raw2h1Cs4julcnN5YCW_19panic_hashmap_index(i64 %hash) unnamed_addr #0 !guid !157 {
start:
  ret i64 %hash
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCs4julcnN5YCW_19panic_hashmap_index() unnamed_addr #4 !guid !158 {
start:
  ret void
}

; core::hint::unreachable_unchecked
; Function Attrs: inlinehint noreturn nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core4hint21unreachable_uncheckedCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %0) unnamed_addr #5 !guid !159 {
start:
; call core::ub_checks::check_language_ub
  %_1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4julcnN5YCW_19panic_hashmap_index() #18
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  unreachable

bb2:                                              ; preds = %start
; call core::hint::unreachable_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint21unreachable_unchecked18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %0) #19
  br label %bb3
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, i64 %align) unnamed_addr #0 !guid !160 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, i64 %align) #18
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4julcnN5YCW_19panic_hashmap_index() unnamed_addr #0 !guid !161 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs4julcnN5YCW_19panic_hashmap_index() #18
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs4julcnN5YCW_19panic_hashmap_index(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !162 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs4julcnN5YCW_19panic_hashmap_index(ptr %3, ptr %5, i64 %7, i64 %9) #18
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !163 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, i64 %align) #18
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr %ptr) #18
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::hash::sip::u8to64_le
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4hash3sip9u8to64_leCs4julcnN5YCW_19panic_hashmap_index(ptr %buf.0, i64 %buf.1, i64 %start1, i64 %len) unnamed_addr #0 !guid !164 {
start:
  %data2 = alloca [2 x i8], align 2
  %data = alloca [4 x i8], align 4
  %out = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  store i64 0, ptr %i, align 8
  store i64 0, ptr %out, align 8
  %_8 = load i64, ptr %i, align 8
  %_7 = add i64 %_8, 3
  %_6 = icmp ult i64 %_7, %len
  br i1 %_6, label %bb1, label %bb7

bb7:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit5, %start
  %_23 = load i64, ptr %i, align 8
  %_22 = add i64 %_23, 1
  %_21 = icmp ult i64 %_22, %len
  br i1 %_21, label %bb8, label %bb14

bb1:                                              ; preds = %start
  store i32 0, ptr %data, align 4
  %_15 = load i64, ptr %i, align 8
  %_14 = add i64 %start1, %_15
  %_0.i6 = getelementptr inbounds nuw i8, ptr %buf.0, i64 %_14
; call core::ub_checks::check_language_ub
  %_4.i3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4julcnN5YCW_19panic_hashmap_index() #18
  br i1 %_4.i3, label %bb2.i4, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit5

bb2.i4:                                           ; preds = %bb1
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr %_0.i6, ptr %data, i64 1, i64 1, i64 4, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #19
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit5

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit5: ; preds = %bb1, %bb2.i4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %data, ptr align 1 %_0.i6, i64 4, i1 false)
  %_20 = load i32, ptr %data, align 4
  %0 = zext i32 %_20 to i64
  store i64 %0, ptr %out, align 8
  %1 = load i64, ptr %i, align 8
  %2 = add i64 %1, 4
  store i64 %2, ptr %i, align 8
  br label %bb7

bb14:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit, %bb7
  %_41 = load i64, ptr %i, align 8
  %_40 = icmp ult i64 %_41, %len
  br i1 %_40, label %bb15, label %bb17

bb8:                                              ; preds = %bb7
  store i16 0, ptr %data2, align 2
  %_32 = load i64, ptr %i, align 8
  %_31 = add i64 %start1, %_32
  %_0.i = getelementptr inbounds nuw i8, ptr %buf.0, i64 %_31
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4julcnN5YCW_19panic_hashmap_index() #18
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit

bb2.i:                                            ; preds = %bb8
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr %_0.i, ptr %data2, i64 1, i64 1, i64 2, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #19
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit: ; preds = %bb8, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %data2, ptr align 1 %_0.i, i64 2, i1 false)
  %_37 = load i16, ptr %data2, align 2
  %_25 = zext i16 %_37 to i64
  %_39 = load i64, ptr %i, align 8
  %_38 = mul i64 %_39, 8
  %3 = and i64 %_38, 63
  %_24 = shl i64 %_25, %3
  %4 = load i64, ptr %out, align 8
  %5 = or i64 %4, %_24
  store i64 %5, ptr %out, align 8
  %6 = load i64, ptr %i, align 8
  %7 = add i64 %6, 2
  store i64 %7, ptr %i, align 8
  br label %bb14

bb17:                                             ; preds = %bb15, %bb14
  %_0 = load i64, ptr %out, align 8
  ret i64 %_0

bb15:                                             ; preds = %bb14
  %_47 = load i64, ptr %i, align 8
  %_46 = add i64 %start1, %_47
; call <[u8]>::get_unchecked::<usize>
  %_45 = call ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSh13get_uncheckedjEB5_(ptr %buf.0, i64 %buf.1, i64 %_46, ptr align 8 @alloc_865bd8db0167b0f468f3000d3b44592d) #18
  %_44 = load i8, ptr %_45, align 1
  %_43 = zext i8 %_44 to i64
  %_49 = load i64, ptr %i, align 8
  %_48 = mul i64 %_49, 8
  %8 = and i64 %_48, 63
  %_42 = shl i64 %_43, %8
  %9 = load i64, ptr %out, align 8
  %10 = or i64 %9, %_42
  store i64 %10, ptr %out, align 8
  %11 = load i64, ptr %i, align 8
  %12 = add i64 %11, 1
  store i64 %12, ptr %i, align 8
  br label %bb17
}

; core::core_arch::x86::sse2::_mm_set1_epi8
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse213__mm_set1_epi8Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %_0, i8 %a) unnamed_addr #6 !guid !165 {
start:
  %0 = alloca [16 x i8], align 16
  %1 = alloca [16 x i8], align 16
; call <core::core_arch::simd::Simd<i8, 16>>::splat
  call void @_RNvMsb_NtNtCsl10jNU3mE6R_4core9core_arch4simdINtB5_4SimdaKj10_E5splatCs7CvK5fPrMBK_9hashbrown(ptr sret([16 x i8]) align 16 %1, i8 %a) #18
  %_2 = load <16 x i8>, ptr %1, align 16
  store <16 x i8> %_2, ptr %0, align 16
; call <core::core_arch::simd::Simd<i8, 16>>::as_m128i
  call void @_RNvMs1P_NtNtCsl10jNU3mE6R_4core9core_arch3x86INtNtB8_4simd4SimdaKj10_E8as_m128iCs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %_0, ptr align 16 %0) #18
  ret void
}

; core::core_arch::x86::sse2::_mm_cmpeq_epi8
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse214__mm_cmpeq_epi8Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %_0, ptr align 16 %a, ptr align 16 %b) unnamed_addr #6 !guid !166 {
start:
  %0 = alloca [16 x i8], align 16
  %1 = alloca [16 x i8], align 16
  %2 = alloca [16 x i8], align 16
  %3 = alloca [16 x i8], align 16
  %4 = load <2 x i64>, ptr %a, align 16
  store <2 x i64> %4, ptr %2, align 16
; call <core::core_arch::x86::__m128i>::as_i8x16
  call void @_RNvMs1K_NtNtCsl10jNU3mE6R_4core9core_arch3x86NtB6_7___m128i8as_i8x16Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %3, ptr align 16 %2) #18
  %_4 = load <16 x i8>, ptr %3, align 16
  %5 = load <2 x i64>, ptr %b, align 16
  store <2 x i64> %5, ptr %0, align 16
; call <core::core_arch::x86::__m128i>::as_i8x16
  call void @_RNvMs1K_NtNtCsl10jNU3mE6R_4core9core_arch3x86NtB6_7___m128i8as_i8x16Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %1, ptr align 16 %0) #18
  %_5 = load <16 x i8>, ptr %1, align 16
  %6 = icmp eq <16 x i8> %_4, %_5
  %_3 = sext <16 x i1> %6 to <16 x i8>
  store <16 x i8> %_3, ptr %_0, align 16
  ret void
}

; core::core_arch::x86::sse2::_mm_loadu_si128
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse215__mm_loadu_si128Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %_0, ptr %mem_addr) unnamed_addr #6 !guid !167 {
start:
  %dst = alloca [16 x i8], align 16
; call core::core_arch::x86::sse2::_mm_undefined_si128
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse219__mm_undefined_si128Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %dst) #18
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4julcnN5YCW_19panic_hashmap_index() #18
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit

bb2.i:                                            ; preds = %start
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr %mem_addr, ptr %dst, i64 1, i64 1, i64 16, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #19
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit: ; preds = %start, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %dst, ptr align 1 %mem_addr, i64 16, i1 false)
  %0 = load <2 x i64>, ptr %dst, align 16
  store <2 x i64> %0, ptr %_0, align 16
  ret void
}

; core::core_arch::x86::sse2::_mm_movemask_epi8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse217__mm_movemask_epi8Cs4julcnN5YCW_19panic_hashmap_index(ptr align 16 %a) unnamed_addr #6 !guid !168 {
start:
  %0 = alloca [16 x i8], align 16
  %1 = alloca [16 x i8], align 16
  %2 = load <2 x i64>, ptr %a, align 16
  store <2 x i64> %2, ptr %0, align 16
; call <core::core_arch::x86::__m128i>::as_i8x16
  call void @_RNvMs1K_NtNtCsl10jNU3mE6R_4core9core_arch3x86NtB6_7___m128i8as_i8x16Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %1, ptr align 16 %0) #18
  %_3 = load <16 x i8>, ptr %1, align 16
  %3 = icmp slt <16 x i8> %_3, zeroinitializer
  %m = sext <16 x i1> %3 to <16 x i8>
  %4 = lshr <16 x i8> %m, splat (i8 7)
  %5 = trunc <16 x i8> %4 to <16 x i1>
  %_6 = bitcast <16 x i1> %5 to i16
  %_5 = zext i16 %_6 to i32
  ret i32 %_5
}

; core::core_arch::x86::sse2::_mm_undefined_si128
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtNtCsl10jNU3mE6R_4core9core_arch3x864sse219__mm_undefined_si128Cs4julcnN5YCW_19panic_hashmap_index(ptr sret([16 x i8]) align 16 %_0) unnamed_addr #6 !guid !169 {
start:
  store <2 x i64> zeroinitializer, ptr %_0, align 16
  ret void
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(i64 %align, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !170 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr) unnamed_addr #0 !guid !171 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !172 {
start:
; invoke <core::alloc::layout::Layout>::is_size_align_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCs4julcnN5YCW_19panic_hashmap_index(i64 %size, i64 %align)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr @alloc_1be5ea12ba708d9a11b6e93a7d387a75, i64 281)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !173 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullB6_(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !174 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs4julcnN5YCW_19panic_hashmap_index(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs4julcnN5YCW_19panic_hashmap_index(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs4julcnN5YCW_19panic_hashmap_index(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; core::ptr::replace::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr7replace18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr %addr, i64 %align, i1 zeroext %is_zst, ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !175 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_4 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs4julcnN5YCW_19panic_hashmap_index(ptr %addr, i64 %align, i1 zeroext %is_zst)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr @alloc_5f856c9c5a649671acdbf03081b5c1d0, i64 221)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_6.0 = extractvalue { ptr, ptr } %2, 0
  %_6.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; core::hint::unreachable_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint21unreachable_unchecked18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %0) unnamed_addr #7 personality ptr @rust_eh_personality !guid !176 {
start:
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs4julcnN5YCW_19panic_hashmap_index(ptr @alloc_75fb06c2453febd814e73f5f2e72ae38, i64 199)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  %_2.0 = extractvalue { ptr, ptr } %1, 0
  %_2.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_2.0, ptr %_2.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs4julcnN5YCW_19panic_hashmap_index(ptr %ptr, i64 %align) unnamed_addr #0 !guid !177 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr %ptr, i64 %align) #18
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs4julcnN5YCW_19panic_hashmap_index() unnamed_addr #0 !guid !178 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs4julcnN5YCW_19panic_hashmap_index(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !179 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs4julcnN5YCW_19panic_hashmap_index(i64 %size, i64 %count) #18
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs4julcnN5YCW_19panic_hashmap_index(i64 %_0.i2, i64 %_0.i) #18
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #27
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB6_11RandomState3new4KEYS27___rust_std_internal_init_fnCs4julcnN5YCW_19panic_hashmap_index() unnamed_addr #0 !guid !180 {
start:
; call std::sys::random::linux::hashmap_random_keys
  %0 = call { i64, i64 } @_RNvNtNtNtCsddYV2PBJW9h_3std3sys6random5linux19hashmap_random_keys()
  %_1.0 = extractvalue { i64, i64 } %0, 0
  %_1.1 = extractvalue { i64, i64 } %0, 1
; call <core::cell::Cell<(u64, u64)>>::new
  %1 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CellTyyEE3newCs4julcnN5YCW_19panic_hashmap_index(i64 %_1.0, i64 %_1.1) #18
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <u8 as hashbrown::Equivalent<u8>>::equivalent
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXCs7CvK5fPrMBK_9hashbrownhINtB2_10EquivalenthE10equivalentCs4julcnN5YCW_19panic_hashmap_index(ptr %0, ptr %key) unnamed_addr #2 !guid !181 {
start:
  %_5 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
; call <u8 as core::borrow::Borrow<u8>>::borrow
  %1 = call ptr @_RNvXNtCsl10jNU3mE6R_4core6borrowhINtB2_6BorrowhE6borrowCs4julcnN5YCW_19panic_hashmap_index(ptr %key)
  store ptr %1, ptr %_5, align 8
; call <&u8 as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRhNtB7_9PartialEq2eqCsddYV2PBJW9h_3std(ptr align 8 %self, ptr align 8 %_5) #18
  ret i1 %_0
}

; <u8 as core::borrow::Borrow<u8>>::borrow
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvXNtCsl10jNU3mE6R_4core6borrowhINtB2_6BorrowhE6borrowCs4julcnN5YCW_19panic_hashmap_index(ptr %self) unnamed_addr #2 !guid !182 {
start:
  ret ptr %self
}

; <hashbrown::control::bitmask::BitMaskIter as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs0_NtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB5_11BitMaskIterNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator4nextCs4julcnN5YCW_19panic_hashmap_index(ptr align 2 %self) unnamed_addr #0 !guid !183 {
start:
  %_2 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %_4 = load i16, ptr %self, align 2
; call <hashbrown::control::bitmask::BitMask>::lowest_set_bit
  %0 = call { i64, i64 } @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB2_7BitMask14lowest_set_bitCs4julcnN5YCW_19panic_hashmap_index(i16 %_4) #18
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <core::option::Option<usize> as core::ops::try_trait::Try>::branch
  %1 = call { i64, i64 } @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionjENtNtNtB7_3ops9try_trait3Try6branchB7_(i64 %_3.0, i64 %_3.1) #18
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb5, label %bb4

bb5:                                              ; preds = %start
; call <core::option::Option<usize> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  %8 = call { i64, i64 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionjEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualB7_() #18
  %9 = extractvalue { i64, i64 } %8, 0
  %10 = extractvalue { i64, i64 } %8, 1
  store i64 %9, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %10, ptr %11, align 8
  br label %bb7

bb4:                                              ; preds = %start
  %12 = getelementptr inbounds i8, ptr %_2, i64 8
  %bit = load i64, ptr %12, align 8
  %_8 = load i16, ptr %self, align 2
; call <hashbrown::control::bitmask::BitMask>::remove_lowest_bit
  %_7 = call i16 @_RNvMNtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB2_7BitMask17remove_lowest_bitCs4julcnN5YCW_19panic_hashmap_index(i16 %_8) #18
  store i16 %_7, ptr %self, align 2
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %bit, ptr %13, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb5, %bb4
  %14 = load i64, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  %16 = load i64, ptr %15, align 8
  %17 = insertvalue { i64, i64 } poison, i64 %14, 0
  %18 = insertvalue { i64, i64 } %17, i64 %16, 1
  ret { i64, i64 } %18

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs4julcnN5YCW_19panic_hashmap_index(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !184 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs4julcnN5YCW_19panic_hashmap_index(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #18
  ret void
}

; <std::hash::random::DefaultHasher as core::hash::Hasher>::write
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtNtCsddYV2PBJW9h_3std4hash6randomNtB5_13DefaultHasherNtNtCsl10jNU3mE6R_4core4hash6Hasher5writeCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %msg.0, i64 %msg.1) unnamed_addr #0 !guid !185 {
start:
; call <core::hash::sip::SipHasher13 as core::hash::Hasher>::write
  call void @_RNvXs2_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11SipHasher13NtB7_6Hasher5writeCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %msg.0, i64 %msg.1) #18
  ret void
}

; <std::hash::random::DefaultHasher as core::hash::Hasher>::finish
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs2_NtNtCsddYV2PBJW9h_3std4hash6randomNtB5_13DefaultHasherNtNtCsl10jNU3mE6R_4core4hash6Hasher6finishCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !186 {
start:
; call <core::hash::sip::SipHasher13 as core::hash::Hasher>::finish
  %_0 = call i64 @_RNvXs2_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11SipHasher13NtB7_6Hasher6finishCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
  ret i64 %_0
}

; <core::hash::sip::SipHasher13 as core::hash::Hasher>::write
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11SipHasher13NtB7_6Hasher5writeCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %msg.0, i64 %msg.1) unnamed_addr #0 !guid !187 {
start:
; call <core::hash::sip::Hasher<core::hash::sip::Sip13Rounds> as core::hash::Hasher>::write
  call void @_RNvXs3_NtNtCsl10jNU3mE6R_4core4hash3sipINtB5_6HasherNtB5_11Sip13RoundsENtB7_6Hasher5writeCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %msg.0, i64 %msg.1) #18
  ret void
}

; <core::hash::sip::SipHasher13 as core::hash::Hasher>::finish
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs2_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11SipHasher13NtB7_6Hasher6finishCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !188 {
start:
; call <core::hash::sip::Hasher<core::hash::sip::Sip13Rounds> as core::hash::Hasher>::finish
  %_0 = call i64 @_RNvXs3_NtNtCsl10jNU3mE6R_4core4hash3sipINtB5_6HasherNtB5_11Sip13RoundsENtB7_6Hasher6finishCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
  ret i64 %_0
}

; <std::hash::random::RandomState as core::default::Default>::default
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs3_NtNtCsddYV2PBJW9h_3std4hash6randomNtB5_11RandomStateNtNtCsl10jNU3mE6R_4core7default7Default7defaultCs4julcnN5YCW_19panic_hashmap_index() unnamed_addr #0 !guid !189 {
start:
; call <std::hash::random::RandomState>::new
  %0 = call { i64, i64 } @_RNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB2_11RandomState3newCs4julcnN5YCW_19panic_hashmap_index() #18
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::hash::sip::Hasher<core::hash::sip::Sip13Rounds> as core::hash::Hasher>::write
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs3_NtNtCsl10jNU3mE6R_4core4hash3sipINtB5_6HasherNtB5_11Sip13RoundsENtB7_6Hasher5writeCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %msg.0, i64 %msg.1) unnamed_addr #0 !guid !190 {
start:
  %data = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %needed = alloca [8 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 48
  %1 = getelementptr inbounds i8, ptr %self, i64 48
  %2 = load i64, ptr %1, align 8
  %3 = add i64 %2, %msg.1
  store i64 %3, ptr %0, align 8
  store i64 0, ptr %needed, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 64
  %_6 = load i64, ptr %4, align 8
  %_5 = icmp ne i64 %_6, 0
  br i1 %_5, label %bb1, label %bb7

bb7:                                              ; preds = %bb5, %start
  %_21 = load i64, ptr %needed, align 8
  %len = sub i64 %msg.1, %_21
  %left = and i64 %len, 7
  %5 = load i64, ptr %needed, align 8
  store i64 %5, ptr %i, align 8
  br label %bb8

bb1:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 64
  %_7 = load i64, ptr %6, align 8
  %7 = sub i64 8, %_7
  store i64 %7, ptr %needed, align 8
  %_11 = load i64, ptr %needed, align 8
; call core::cmp::min::<usize>
  %_10 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %msg.1, i64 %_11) #18
; call core::hash::sip::u8to64_le
  %_9 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4hash3sip9u8to64_leCs4julcnN5YCW_19panic_hashmap_index(ptr %msg.0, i64 %msg.1, i64 0, i64 %_10) #18
  %8 = getelementptr inbounds i8, ptr %self, i64 64
  %_13 = load i64, ptr %8, align 8
  %_12 = mul i64 8, %_13
  %9 = and i64 %_12, 63
  %_8 = shl i64 %_9, %9
  %10 = getelementptr inbounds i8, ptr %self, i64 56
  %11 = getelementptr inbounds i8, ptr %self, i64 56
  %12 = load i64, ptr %11, align 8
  %13 = or i64 %12, %_8
  store i64 %13, ptr %10, align 8
  %_15 = load i64, ptr %needed, align 8
  %_14 = icmp ult i64 %msg.1, %_15
  br i1 %_14, label %bb4, label %bb5

bb5:                                              ; preds = %bb1
  %14 = getelementptr inbounds i8, ptr %self, i64 56
  %_16 = load i64, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %self, i64 24
  %16 = getelementptr inbounds i8, ptr %self, i64 24
  %17 = load i64, ptr %16, align 8
  %18 = xor i64 %17, %_16
  store i64 %18, ptr %15, align 8
; call <core::hash::sip::Sip13Rounds as core::hash::sip::Sip>::c_rounds
  call void @_RNvXs6_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11Sip13RoundsNtB5_3Sip8c_roundsCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
  %19 = getelementptr inbounds i8, ptr %self, i64 56
  %_19 = load i64, ptr %19, align 8
  %20 = load i64, ptr %self, align 8
  %21 = xor i64 %20, %_19
  store i64 %21, ptr %self, align 8
  %22 = getelementptr inbounds i8, ptr %self, i64 64
  store i64 0, ptr %22, align 8
  br label %bb7

bb4:                                              ; preds = %bb1
  %23 = getelementptr inbounds i8, ptr %self, i64 64
  %24 = getelementptr inbounds i8, ptr %self, i64 64
  %25 = load i64, ptr %24, align 8
  %26 = add i64 %25, %msg.1
  store i64 %26, ptr %23, align 8
  br label %bb18

bb8:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit, %bb7
  %_25 = load i64, ptr %i, align 8
  %_26 = sub i64 %len, %left
  %_24 = icmp ult i64 %_25, %_26
  br i1 %_24, label %bb9, label %bb16

bb16:                                             ; preds = %bb8
  %_41 = load i64, ptr %i, align 8
; call core::hash::sip::u8to64_le
  %_40 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4hash3sip9u8to64_leCs4julcnN5YCW_19panic_hashmap_index(ptr %msg.0, i64 %msg.1, i64 %_41, i64 %left) #18
  %27 = getelementptr inbounds i8, ptr %self, i64 56
  store i64 %_40, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %self, i64 64
  store i64 %left, ptr %28, align 8
  br label %bb18

bb9:                                              ; preds = %bb8
  store i64 0, ptr %data, align 8
  %_32 = load i64, ptr %i, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %msg.0, i64 %_32
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs4julcnN5YCW_19panic_hashmap_index() #18
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit

bb2.i:                                            ; preds = %bb9
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs4julcnN5YCW_19panic_hashmap_index(ptr %_0.i, ptr %data, i64 1, i64 1, i64 8, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #19
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs4julcnN5YCW_19panic_hashmap_index.exit: ; preds = %bb9, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %data, ptr align 1 %_0.i, i64 8, i1 false)
  %_37 = load i64, ptr %data, align 8
  %29 = getelementptr inbounds i8, ptr %self, i64 24
  %30 = getelementptr inbounds i8, ptr %self, i64 24
  %31 = load i64, ptr %30, align 8
  %32 = xor i64 %31, %_37
  store i64 %32, ptr %29, align 8
; call <core::hash::sip::Sip13Rounds as core::hash::sip::Sip>::c_rounds
  call void @_RNvXs6_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11Sip13RoundsNtB5_3Sip8c_roundsCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) #18
  %33 = load i64, ptr %self, align 8
  %34 = xor i64 %33, %_37
  store i64 %34, ptr %self, align 8
  %35 = load i64, ptr %i, align 8
  %36 = add i64 %35, 8
  store i64 %36, ptr %i, align 8
  br label %bb8

bb18:                                             ; preds = %bb4, %bb16
  ret void
}

; <core::hash::sip::Hasher<core::hash::sip::Sip13Rounds> as core::hash::Hasher>::finish
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs3_NtNtCsl10jNU3mE6R_4core4hash3sipINtB5_6HasherNtB5_11Sip13RoundsENtB7_6Hasher6finishCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #0 !guid !191 {
start:
  %state = alloca [32 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %state, ptr align 8 %self, i64 32, i1 false)
  %0 = getelementptr inbounds i8, ptr %self, i64 48
  %_7 = load i64, ptr %0, align 8
  %_5 = and i64 %_7, 255
  %_4 = shl i64 %_5, 56
  %1 = getelementptr inbounds i8, ptr %self, i64 56
  %_8 = load i64, ptr %1, align 8
  %b = or i64 %_4, %_8
  %2 = getelementptr inbounds i8, ptr %state, i64 24
  %3 = getelementptr inbounds i8, ptr %state, i64 24
  %4 = load i64, ptr %3, align 8
  %5 = xor i64 %4, %b
  store i64 %5, ptr %2, align 8
; call <core::hash::sip::Sip13Rounds as core::hash::sip::Sip>::c_rounds
  call void @_RNvXs6_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11Sip13RoundsNtB5_3Sip8c_roundsCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %state) #18
  %6 = load i64, ptr %state, align 8
  %7 = xor i64 %6, %b
  store i64 %7, ptr %state, align 8
  %8 = getelementptr inbounds i8, ptr %state, i64 8
  %9 = getelementptr inbounds i8, ptr %state, i64 8
  %10 = load i64, ptr %9, align 8
  %11 = xor i64 %10, 255
  store i64 %11, ptr %8, align 8
; call <core::hash::sip::Sip13Rounds as core::hash::sip::Sip>::d_rounds
  call void @_RNvXs6_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11Sip13RoundsNtB5_3Sip8d_roundsCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %state) #18
  %_15 = load i64, ptr %state, align 8
  %12 = getelementptr inbounds i8, ptr %state, i64 16
  %_16 = load i64, ptr %12, align 8
  %_14 = xor i64 %_15, %_16
  %13 = getelementptr inbounds i8, ptr %state, i64 8
  %_17 = load i64, ptr %13, align 8
  %_13 = xor i64 %_14, %_17
  %14 = getelementptr inbounds i8, ptr %state, i64 24
  %_18 = load i64, ptr %14, align 8
  %_0 = xor i64 %_13, %_18
  ret i64 %_0
}

; <core::hash::sip::Sip13Rounds as core::hash::sip::Sip>::c_rounds
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs6_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11Sip13RoundsNtB5_3Sip8c_roundsCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %state) unnamed_addr #0 !guid !192 {
start:
  %_3 = load i64, ptr %state, align 8
  %0 = getelementptr inbounds i8, ptr %state, i64 16
  %_4 = load i64, ptr %0, align 8
  %_0.i9 = add i64 %_3, %_4
  store i64 %_0.i9, ptr %state, align 8
  %1 = getelementptr inbounds i8, ptr %state, i64 8
  %_6 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %state, i64 24
  %_7 = load i64, ptr %2, align 8
  %_0.i8 = add i64 %_6, %_7
  %3 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i8, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %state, i64 16
  %_9 = load i64, ptr %4, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i5 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_9, i32 13) #26
  %5 = getelementptr inbounds i8, ptr %state, i64 16
  store i64 %_0.i5, ptr %5, align 8
  %_10 = load i64, ptr %state, align 8
  %6 = getelementptr inbounds i8, ptr %state, i64 16
  %7 = getelementptr inbounds i8, ptr %state, i64 16
  %8 = load i64, ptr %7, align 8
  %9 = xor i64 %8, %_10
  store i64 %9, ptr %6, align 8
  %10 = getelementptr inbounds i8, ptr %state, i64 24
  %_12 = load i64, ptr %10, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i4 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_12, i32 16) #26
  %11 = getelementptr inbounds i8, ptr %state, i64 24
  store i64 %_0.i4, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %state, i64 8
  %_13 = load i64, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %state, i64 24
  %14 = getelementptr inbounds i8, ptr %state, i64 24
  %15 = load i64, ptr %14, align 8
  %16 = xor i64 %15, %_13
  store i64 %16, ptr %13, align 8
  %_15 = load i64, ptr %state, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i3 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_15, i32 32) #26
  store i64 %_0.i3, ptr %state, align 8
  %17 = getelementptr inbounds i8, ptr %state, i64 8
  %_17 = load i64, ptr %17, align 8
  %18 = getelementptr inbounds i8, ptr %state, i64 16
  %_18 = load i64, ptr %18, align 8
  %_0.i7 = add i64 %_17, %_18
  %19 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i7, ptr %19, align 8
  %_20 = load i64, ptr %state, align 8
  %20 = getelementptr inbounds i8, ptr %state, i64 24
  %_21 = load i64, ptr %20, align 8
  %_0.i6 = add i64 %_20, %_21
  store i64 %_0.i6, ptr %state, align 8
  %21 = getelementptr inbounds i8, ptr %state, i64 16
  %_23 = load i64, ptr %21, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i2 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_23, i32 17) #26
  %22 = getelementptr inbounds i8, ptr %state, i64 16
  store i64 %_0.i2, ptr %22, align 8
  %23 = getelementptr inbounds i8, ptr %state, i64 8
  %_24 = load i64, ptr %23, align 8
  %24 = getelementptr inbounds i8, ptr %state, i64 16
  %25 = getelementptr inbounds i8, ptr %state, i64 16
  %26 = load i64, ptr %25, align 8
  %27 = xor i64 %26, %_24
  store i64 %27, ptr %24, align 8
  %28 = getelementptr inbounds i8, ptr %state, i64 24
  %_26 = load i64, ptr %28, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i1 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_26, i32 21) #26
  %29 = getelementptr inbounds i8, ptr %state, i64 24
  store i64 %_0.i1, ptr %29, align 8
  %_27 = load i64, ptr %state, align 8
  %30 = getelementptr inbounds i8, ptr %state, i64 24
  %31 = getelementptr inbounds i8, ptr %state, i64 24
  %32 = load i64, ptr %31, align 8
  %33 = xor i64 %32, %_27
  store i64 %33, ptr %30, align 8
  %34 = getelementptr inbounds i8, ptr %state, i64 8
  %_29 = load i64, ptr %34, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_29, i32 32) #26
  %35 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i, ptr %35, align 8
  ret void
}

; <core::hash::sip::Sip13Rounds as core::hash::sip::Sip>::d_rounds
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs6_NtNtCsl10jNU3mE6R_4core4hash3sipNtB5_11Sip13RoundsNtB5_3Sip8d_roundsCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %state) unnamed_addr #0 !guid !193 {
start:
  %_3 = load i64, ptr %state, align 8
  %0 = getelementptr inbounds i8, ptr %state, i64 16
  %_4 = load i64, ptr %0, align 8
  %_0.i29 = add i64 %_3, %_4
  store i64 %_0.i29, ptr %state, align 8
  %1 = getelementptr inbounds i8, ptr %state, i64 8
  %_6 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %state, i64 24
  %_7 = load i64, ptr %2, align 8
  %_0.i28 = add i64 %_6, %_7
  %3 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i28, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %state, i64 16
  %_9 = load i64, ptr %4, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i17 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_9, i32 13) #26
  %5 = getelementptr inbounds i8, ptr %state, i64 16
  store i64 %_0.i17, ptr %5, align 8
  %_10 = load i64, ptr %state, align 8
  %6 = getelementptr inbounds i8, ptr %state, i64 16
  %7 = getelementptr inbounds i8, ptr %state, i64 16
  %8 = load i64, ptr %7, align 8
  %9 = xor i64 %8, %_10
  store i64 %9, ptr %6, align 8
  %10 = getelementptr inbounds i8, ptr %state, i64 24
  %_12 = load i64, ptr %10, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i16 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_12, i32 16) #26
  %11 = getelementptr inbounds i8, ptr %state, i64 24
  store i64 %_0.i16, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %state, i64 8
  %_13 = load i64, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %state, i64 24
  %14 = getelementptr inbounds i8, ptr %state, i64 24
  %15 = load i64, ptr %14, align 8
  %16 = xor i64 %15, %_13
  store i64 %16, ptr %13, align 8
  %_15 = load i64, ptr %state, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i15 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_15, i32 32) #26
  store i64 %_0.i15, ptr %state, align 8
  %17 = getelementptr inbounds i8, ptr %state, i64 8
  %_17 = load i64, ptr %17, align 8
  %18 = getelementptr inbounds i8, ptr %state, i64 16
  %_18 = load i64, ptr %18, align 8
  %_0.i27 = add i64 %_17, %_18
  %19 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i27, ptr %19, align 8
  %_20 = load i64, ptr %state, align 8
  %20 = getelementptr inbounds i8, ptr %state, i64 24
  %_21 = load i64, ptr %20, align 8
  %_0.i26 = add i64 %_20, %_21
  store i64 %_0.i26, ptr %state, align 8
  %21 = getelementptr inbounds i8, ptr %state, i64 16
  %_23 = load i64, ptr %21, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i14 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_23, i32 17) #26
  %22 = getelementptr inbounds i8, ptr %state, i64 16
  store i64 %_0.i14, ptr %22, align 8
  %23 = getelementptr inbounds i8, ptr %state, i64 8
  %_24 = load i64, ptr %23, align 8
  %24 = getelementptr inbounds i8, ptr %state, i64 16
  %25 = getelementptr inbounds i8, ptr %state, i64 16
  %26 = load i64, ptr %25, align 8
  %27 = xor i64 %26, %_24
  store i64 %27, ptr %24, align 8
  %28 = getelementptr inbounds i8, ptr %state, i64 24
  %_26 = load i64, ptr %28, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i13 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_26, i32 21) #26
  %29 = getelementptr inbounds i8, ptr %state, i64 24
  store i64 %_0.i13, ptr %29, align 8
  %_27 = load i64, ptr %state, align 8
  %30 = getelementptr inbounds i8, ptr %state, i64 24
  %31 = getelementptr inbounds i8, ptr %state, i64 24
  %32 = load i64, ptr %31, align 8
  %33 = xor i64 %32, %_27
  store i64 %33, ptr %30, align 8
  %34 = getelementptr inbounds i8, ptr %state, i64 8
  %_29 = load i64, ptr %34, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i12 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_29, i32 32) #26
  %35 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i12, ptr %35, align 8
  %_31 = load i64, ptr %state, align 8
  %36 = getelementptr inbounds i8, ptr %state, i64 16
  %_32 = load i64, ptr %36, align 8
  %_0.i25 = add i64 %_31, %_32
  store i64 %_0.i25, ptr %state, align 8
  %37 = getelementptr inbounds i8, ptr %state, i64 8
  %_34 = load i64, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %state, i64 24
  %_35 = load i64, ptr %38, align 8
  %_0.i24 = add i64 %_34, %_35
  %39 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i24, ptr %39, align 8
  %40 = getelementptr inbounds i8, ptr %state, i64 16
  %_37 = load i64, ptr %40, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i11 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_37, i32 13) #26
  %41 = getelementptr inbounds i8, ptr %state, i64 16
  store i64 %_0.i11, ptr %41, align 8
  %_38 = load i64, ptr %state, align 8
  %42 = getelementptr inbounds i8, ptr %state, i64 16
  %43 = getelementptr inbounds i8, ptr %state, i64 16
  %44 = load i64, ptr %43, align 8
  %45 = xor i64 %44, %_38
  store i64 %45, ptr %42, align 8
  %46 = getelementptr inbounds i8, ptr %state, i64 24
  %_40 = load i64, ptr %46, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i10 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_40, i32 16) #26
  %47 = getelementptr inbounds i8, ptr %state, i64 24
  store i64 %_0.i10, ptr %47, align 8
  %48 = getelementptr inbounds i8, ptr %state, i64 8
  %_41 = load i64, ptr %48, align 8
  %49 = getelementptr inbounds i8, ptr %state, i64 24
  %50 = getelementptr inbounds i8, ptr %state, i64 24
  %51 = load i64, ptr %50, align 8
  %52 = xor i64 %51, %_41
  store i64 %52, ptr %49, align 8
  %_43 = load i64, ptr %state, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i9 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_43, i32 32) #26
  store i64 %_0.i9, ptr %state, align 8
  %53 = getelementptr inbounds i8, ptr %state, i64 8
  %_45 = load i64, ptr %53, align 8
  %54 = getelementptr inbounds i8, ptr %state, i64 16
  %_46 = load i64, ptr %54, align 8
  %_0.i23 = add i64 %_45, %_46
  %55 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i23, ptr %55, align 8
  %_48 = load i64, ptr %state, align 8
  %56 = getelementptr inbounds i8, ptr %state, i64 24
  %_49 = load i64, ptr %56, align 8
  %_0.i22 = add i64 %_48, %_49
  store i64 %_0.i22, ptr %state, align 8
  %57 = getelementptr inbounds i8, ptr %state, i64 16
  %_51 = load i64, ptr %57, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i8 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_51, i32 17) #26
  %58 = getelementptr inbounds i8, ptr %state, i64 16
  store i64 %_0.i8, ptr %58, align 8
  %59 = getelementptr inbounds i8, ptr %state, i64 8
  %_52 = load i64, ptr %59, align 8
  %60 = getelementptr inbounds i8, ptr %state, i64 16
  %61 = getelementptr inbounds i8, ptr %state, i64 16
  %62 = load i64, ptr %61, align 8
  %63 = xor i64 %62, %_52
  store i64 %63, ptr %60, align 8
  %64 = getelementptr inbounds i8, ptr %state, i64 24
  %_54 = load i64, ptr %64, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i7 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_54, i32 21) #26
  %65 = getelementptr inbounds i8, ptr %state, i64 24
  store i64 %_0.i7, ptr %65, align 8
  %_55 = load i64, ptr %state, align 8
  %66 = getelementptr inbounds i8, ptr %state, i64 24
  %67 = getelementptr inbounds i8, ptr %state, i64 24
  %68 = load i64, ptr %67, align 8
  %69 = xor i64 %68, %_55
  store i64 %69, ptr %66, align 8
  %70 = getelementptr inbounds i8, ptr %state, i64 8
  %_57 = load i64, ptr %70, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i6 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_57, i32 32) #26
  %71 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i6, ptr %71, align 8
  %_59 = load i64, ptr %state, align 8
  %72 = getelementptr inbounds i8, ptr %state, i64 16
  %_60 = load i64, ptr %72, align 8
  %_0.i21 = add i64 %_59, %_60
  store i64 %_0.i21, ptr %state, align 8
  %73 = getelementptr inbounds i8, ptr %state, i64 8
  %_62 = load i64, ptr %73, align 8
  %74 = getelementptr inbounds i8, ptr %state, i64 24
  %_63 = load i64, ptr %74, align 8
  %_0.i20 = add i64 %_62, %_63
  %75 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i20, ptr %75, align 8
  %76 = getelementptr inbounds i8, ptr %state, i64 16
  %_65 = load i64, ptr %76, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i5 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_65, i32 13) #26
  %77 = getelementptr inbounds i8, ptr %state, i64 16
  store i64 %_0.i5, ptr %77, align 8
  %_66 = load i64, ptr %state, align 8
  %78 = getelementptr inbounds i8, ptr %state, i64 16
  %79 = getelementptr inbounds i8, ptr %state, i64 16
  %80 = load i64, ptr %79, align 8
  %81 = xor i64 %80, %_66
  store i64 %81, ptr %78, align 8
  %82 = getelementptr inbounds i8, ptr %state, i64 24
  %_68 = load i64, ptr %82, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i4 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_68, i32 16) #26
  %83 = getelementptr inbounds i8, ptr %state, i64 24
  store i64 %_0.i4, ptr %83, align 8
  %84 = getelementptr inbounds i8, ptr %state, i64 8
  %_69 = load i64, ptr %84, align 8
  %85 = getelementptr inbounds i8, ptr %state, i64 24
  %86 = getelementptr inbounds i8, ptr %state, i64 24
  %87 = load i64, ptr %86, align 8
  %88 = xor i64 %87, %_69
  store i64 %88, ptr %85, align 8
  %_71 = load i64, ptr %state, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i3 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_71, i32 32) #26
  store i64 %_0.i3, ptr %state, align 8
  %89 = getelementptr inbounds i8, ptr %state, i64 8
  %_73 = load i64, ptr %89, align 8
  %90 = getelementptr inbounds i8, ptr %state, i64 16
  %_74 = load i64, ptr %90, align 8
  %_0.i19 = add i64 %_73, %_74
  %91 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i19, ptr %91, align 8
  %_76 = load i64, ptr %state, align 8
  %92 = getelementptr inbounds i8, ptr %state, i64 24
  %_77 = load i64, ptr %92, align 8
  %_0.i18 = add i64 %_76, %_77
  store i64 %_0.i18, ptr %state, align 8
  %93 = getelementptr inbounds i8, ptr %state, i64 16
  %_79 = load i64, ptr %93, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i2 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_79, i32 17) #26
  %94 = getelementptr inbounds i8, ptr %state, i64 16
  store i64 %_0.i2, ptr %94, align 8
  %95 = getelementptr inbounds i8, ptr %state, i64 8
  %_80 = load i64, ptr %95, align 8
  %96 = getelementptr inbounds i8, ptr %state, i64 16
  %97 = getelementptr inbounds i8, ptr %state, i64 16
  %98 = load i64, ptr %97, align 8
  %99 = xor i64 %98, %_80
  store i64 %99, ptr %96, align 8
  %100 = getelementptr inbounds i8, ptr %state, i64 24
  %_82 = load i64, ptr %100, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i1 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_82, i32 21) #26
  %101 = getelementptr inbounds i8, ptr %state, i64 24
  store i64 %_0.i1, ptr %101, align 8
  %_83 = load i64, ptr %state, align 8
  %102 = getelementptr inbounds i8, ptr %state, i64 24
  %103 = getelementptr inbounds i8, ptr %state, i64 24
  %104 = load i64, ptr %103, align 8
  %105 = xor i64 %104, %_83
  store i64 %105, ptr %102, align 8
  %106 = getelementptr inbounds i8, ptr %state, i64 8
  %_85 = load i64, ptr %106, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_85, i32 32) #26
  %107 = getelementptr inbounds i8, ptr %state, i64 8
  store i64 %_0.i, ptr %107, align 8
  ret void
}

; <std::collections::hash::map::HashMap<u8, u8> as core::default::Default>::default
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs7_NtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB5_7HashMaphhENtNtCsl10jNU3mE6R_4core7default7Default7defaultCs4julcnN5YCW_19panic_hashmap_index(ptr sret([48 x i8]) align 8 %_0) unnamed_addr #0 !guid !194 {
start:
; call <std::hash::random::RandomState as core::default::Default>::default
  %0 = call { i64, i64 } @_RNvXs3_NtNtCsddYV2PBJW9h_3std4hash6randomNtB5_11RandomStateNtNtCsl10jNU3mE6R_4core7default7Default7defaultCs4julcnN5YCW_19panic_hashmap_index() #18
  %_1.0 = extractvalue { i64, i64 } %0, 0
  %_1.1 = extractvalue { i64, i64 } %0, 1
; call <std::collections::hash::map::HashMap<u8, u8>>::with_hasher
  call void @_RNvMs0_NtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB5_7HashMaphhE11with_hasherCs4julcnN5YCW_19panic_hashmap_index(ptr sret([48 x i8]) align 8 %_0, i64 %_1.0, i64 %_1.1) #18
  ret void
}

; <std::collections::hash::map::HashMap<u8, u8> as core::ops::index::Index<&u8>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs8_NtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB5_7HashMaphhEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexRhE5indexCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %key, ptr align 8 %0) unnamed_addr #0 !guid !195 {
start:
; call <std::collections::hash::map::HashMap<u8, u8>>::get::<u8>
  %_3 = call ptr @_RINvMs2_NtNtNtCsddYV2PBJW9h_3std11collections4hash3mapINtB6_7HashMaphhE3gethECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %key) #18
; call <core::option::Option<&u8>>::expect
  %_0 = call ptr @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionRhE6expectCs4julcnN5YCW_19panic_hashmap_index(ptr %_3, ptr @alloc_a7d7769291fb702cd4ca6ef64f027ff9, i64 22, ptr align 8 %0) #18
  ret ptr %_0
}

; <core::option::Option<(core::alloc::layout::Layout, usize)> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionTNtNtNtB7_5alloc6layout6LayoutjEEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !196 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs4julcnN5YCW_19panic_hashmap_index() unnamed_addr #0 !guid !197 {
start:
  ret i8 0
}

; <hashbrown::control::bitmask::BitMask as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvXs_NtNtCs7CvK5fPrMBK_9hashbrown7control7bitmaskNtB4_7BitMaskNtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12IntoIterator9into_iterCs4julcnN5YCW_19panic_hashmap_index(i16 %self) unnamed_addr #0 !guid !198 {
start:
  %_3 = and i16 %self, -1
  ret i16 %_3
}

; <std::hash::random::RandomState as core::hash::BuildHasher>::build_hasher
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs_NtNtCsddYV2PBJW9h_3std4hash6randomNtB4_11RandomStateNtNtCsl10jNU3mE6R_4core4hash11BuildHasher12build_hasherCs4julcnN5YCW_19panic_hashmap_index(ptr sret([72 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !199 {
start:
  %_2 = alloca [72 x i8], align 8
  %_3 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %0, align 8
; call <core::hash::sip::SipHasher13>::new_with_keys
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core4hash3sipNtB4_11SipHasher1313new_with_keysCs4julcnN5YCW_19panic_hashmap_index(ptr sret([72 x i8]) align 8 %_2, i64 %_3, i64 %_4) #18
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 72, i1 false)
  ret void
}

; <hashbrown::raw::RawTable<(u8, u8)> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsg_NtCs7CvK5fPrMBK_9hashbrown3rawINtB5_8RawTableThhEENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self) unnamed_addr #2 !guid !200 {
start:
  %_4 = getelementptr inbounds i8, ptr %self, i64 32
; call <hashbrown::raw::RawTableInner>::drop_inner_table::<(u8, u8), alloc::alloc::Global>
  call void @_RINvMsa_NtCs7CvK5fPrMBK_9hashbrown3rawNtB6_13RawTableInner16drop_inner_tableThhENtNtCs7CppTae75M1_5alloc5alloc6GlobalECs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %_4, i64 2, i64 16)
  ret void
}

; <core::result::Result<&core::cell::Cell<(u64, u64)>, std::thread::local::AccessError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultRINtNtB7_4cell4CellTyyEENtNtNtCsddYV2PBJW9h_3std6thread5local11AccessErrorENtNtNtB7_3ops9try_trait3Try6branchCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %0) unnamed_addr #0 !guid !201 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<std::hash::random::RandomState, std::thread::local::AccessError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, std::thread::local::AccessError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtCsddYV2PBJW9h_3std4hash6random11RandomStateNtNtNtBQ_6thread5local11AccessErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1x_EE13from_residualCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !202 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4julcnN5YCW_19panic_hashmap_index(ptr %_1) unnamed_addr #0 !guid !203 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <<hashbrown::raw::RawTable<(u8, u8)>>::find<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>::{closure#0} as core::ops::function::FnOnce<(usize,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvYNCINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtBb_8RawTableThhEE4findNCINvNtBd_3map14equivalent_keyhhhE0E0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTjEE9call_onceCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %0, ptr align 8 %1, i64 %2) unnamed_addr #0 personality ptr @rust_eh_personality !guid !204 {
start:
  %_2 = alloca [8 x i8], align 8
  %_1 = alloca [16 x i8], align 8
  store ptr %0, ptr %_1, align 8
  %3 = getelementptr inbounds i8, ptr %_1, i64 8
  store ptr %1, ptr %3, align 8
  store i64 %2, ptr %_2, align 8
  %4 = load i64, ptr %_2, align 8
; call <hashbrown::raw::RawTable<(u8, u8)>>::find::<hashbrown::map::equivalent_key<u8, u8, u8>::{closure#0}>::{closure#0}
  %_0 = call zeroext i1 @_RNCINvMs6_NtCs7CvK5fPrMBK_9hashbrown3rawINtB8_8RawTableThhEE4findNCINvNtBa_3map14equivalent_keyhhhE0E0Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1, i64 %4) #18
  br label %bb1

bb1:                                              ; preds = %start
  ret i1 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4julcnN5YCW_19panic_hashmap_index(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !205 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %_1) #18
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<std::hash::random::RandomState>::new::KEYS::{K#0}::{closure#1} as core::ops::function::FnOnce<(core::option::Option<&mut core::option::Option<core::cell::Cell<(u64, u64)>>>,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvYNCNKNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtBb_11RandomState3new4KEYS0s_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTINtNtB1l_6option6OptionQIB20_INtNtB1l_4cell4CellTyyEEEEEE9call_onceCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !206 {
start:
  %_2 = alloca [8 x i8], align 8
  %_1 = alloca [0 x i8], align 1
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call <std::hash::random::RandomState>::new::KEYS::{K#0}::{closure#1}
  %_0 = call ptr @_RNCNKNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB8_11RandomState3new4KEYS0s_0Cs4julcnN5YCW_19panic_hashmap_index(ptr %_1, ptr align 8 %1) #18
  br label %bb1

bb1:                                              ; preds = %start
  ret ptr %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <std::hash::random::DefaultHasher as core::hash::Hasher>::write_u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNtNtNtCsddYV2PBJW9h_3std4hash6random13DefaultHasherNtNtCsl10jNU3mE6R_4core4hash6Hasher8write_u8Cs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, i8 %i) unnamed_addr #0 !guid !207 {
start:
  %_5 = alloca [1 x i8], align 1
  %0 = getelementptr inbounds nuw i8, ptr %_5, i64 0
  store i8 %i, ptr %0, align 1
; call <std::hash::random::DefaultHasher as core::hash::Hasher>::write
  call void @_RNvXs2_NtNtCsddYV2PBJW9h_3std4hash6randomNtB5_13DefaultHasherNtNtCsl10jNU3mE6R_4core4hash6Hasher5writeCs4julcnN5YCW_19panic_hashmap_index(ptr align 8 %self, ptr %_5, i64 1) #18
  ret void
}

; <<core::option::Option<core::cell::Cell<(u64, u64)>>>::take as core::ops::function::FnOnce<(&mut core::option::Option<core::cell::Cell<(u64, u64)>>,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNvMNtCsl10jNU3mE6R_4core6optionINtB5_6OptionINtNtB7_4cell4CellTyyEEE4takeINtNtNtB7_3ops8function6FnOnceTQBx_EE9call_onceCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !208 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call <core::option::Option<core::cell::Cell<(u64, u64)>>>::take
  call void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionINtNtB4_4cell4CellTyyEEE4takeCs4julcnN5YCW_19panic_hashmap_index(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %1) #18
  ret void
}

; <<std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvYNvNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB9_11RandomState3new4KEYS27___rust_std_internal_init_fnINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs4julcnN5YCW_19panic_hashmap_index() unnamed_addr #0 !guid !209 {
start:
  %_2 = alloca [0 x i8], align 1
; call <std::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn
  %0 = call { i64, i64 } @_RNvNvNvMNtNtCsddYV2PBJW9h_3std4hash6randomNtB6_11RandomState3new4KEYS27___rust_std_internal_init_fnCs4julcnN5YCW_19panic_hashmap_index() #18
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #8

; std::sys::stdio::unix::panic_output
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNtNtNtCsddYV2PBJW9h_3std3sys5stdio4unix12panic_output() unnamed_addr #2

; <std::sys::stdio::unix::Stderr as core::io::write::Write>::write_fmt
; Function Attrs: nonlazybind uwtable
declare ptr @_RNvYNtNtNtNtCsddYV2PBJW9h_3std3sys5stdio4unix6StderrNtNtNtCsl10jNU3mE6R_4core2io5write5Write9write_fmtBa_(ptr, ptr, ptr) unnamed_addr #2

; core::ptr::drop_glue::<core::result::Result<(), core::io::error::Error>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultuNtNtNtB4_2io5error5ErrorEECsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #2

; std::process::abort
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std7process5abort() unnamed_addr #9

; std::thread::local::panic_access_error
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std6thread5local18panic_access_error(ptr align 8) unnamed_addr #10

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #11

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare nonnull ptr @llvm.threadlocal.address.p0(ptr nonnull) #12

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #2

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #13

; core::option::expect_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6option13expect_failed(ptr, i64, ptr align 8) unnamed_addr #10

; <core::num::nonzero::NonZero<u16>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i16 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE3newB9_(i16) unnamed_addr #0

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #2

; <core::option::Option<usize> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionjENtNtNtB7_3ops9try_trait3Try6branchB7_(i64, i64) unnamed_addr #0

; core::intrinsics::rotate_left::<u64>
; Function Attrs: nounwind nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64, i32) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #14

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #14

; <core::num::nonzero::NonZero<u16>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i16 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE3getB9_(i16) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.cttz.i16(i16, i1 immarg) #12

; <core::ptr::non_null::NonNull<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCs7CppTae75M1_5alloc(ptr, ptr align 8) unnamed_addr #0

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #15

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr) unnamed_addr #0

; <[u8]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSh13get_uncheckedjEB5_(ptr, i64, i64, ptr align 8) unnamed_addr #0

; <core::core_arch::simd::Simd<i8, 16>>::splat
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMsb_NtNtCsl10jNU3mE6R_4core9core_arch4simdINtB5_4SimdaKj10_E5splatCs7CvK5fPrMBK_9hashbrown(ptr sret([16 x i8]) align 16, i8) unnamed_addr #0

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #13

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #16

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullB6_(ptr) unnamed_addr #0

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr, i64) unnamed_addr #0

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #16

; std::sys::random::linux::hashmap_random_keys
; Function Attrs: nonlazybind uwtable
declare { i64, i64 } @_RNvNtNtNtCsddYV2PBJW9h_3std3sys6random5linux19hashmap_random_keys() unnamed_addr #2

; <&u8 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3cmp5implsRhNtB7_9PartialEq2eqCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #0

; <core::option::Option<usize> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionjEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualB7_() unnamed_addr #0

; core::cmp::min::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64, i64) unnamed_addr #0

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #17 !guid !210 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs4julcnN5YCW_19panic_hashmap_index(ptr @_RNvCs4julcnN5YCW_19panic_hashmap_index4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { cold nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" "target-features"="+sse,+sse2" }
attributes #7 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #12 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #15 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nonlazybind "target-cpu"="x86-64" }
attributes #18 = { inlinehint }
attributes #19 = { inlinehint nounwind }
attributes #20 = { noreturn }
attributes #21 = { noinline noreturn }
attributes #22 = { noinline }
attributes #23 = { cold }
attributes #24 = { cold noreturn nounwind }
attributes #25 = { inlinehint noreturn }
attributes #26 = { nounwind }
attributes #27 = { noinline noreturn nounwind }

!llvm.module.flags = !{!44, !45, !46, !47}
!llvm.ident = !{!48}

!0 = !{i64 -9197118356105144648}
!1 = !{i64 -4811912973382882197}
!2 = !{i64 2681083382303645061}
!3 = !{i64 7496325738727419640}
!4 = !{i64 -5915342617138467967}
!5 = !{i64 -6486772282025845979}
!6 = !{i64 -859274604847467087}
!7 = !{i64 1529691046539470214}
!8 = !{i64 -137501263653055452}
!9 = !{i64 4879237904585245757}
!10 = !{i64 -2249278468962315342}
!11 = !{i64 9155749415554583958}
!12 = !{i64 -7236785537714950620}
!13 = !{i64 -3252559275859028193}
!14 = !{i64 7310030794422870644}
!15 = !{i64 -8244545505184724115}
!16 = !{i64 8638081273788949920}
!17 = !{i64 3046466437634611838}
!18 = !{i64 1936906093597607805}
!19 = !{i64 1508077838888686113}
!20 = !{i64 1782378592044312105}
!21 = !{i64 -6378585753784346443}
!22 = !{i64 -6518917042248424976}
!23 = !{i64 3663266393927105246}
!24 = !{i64 855309155386167987}
!25 = !{i64 4363378794722457913}
!26 = !{i64 -823105786734773417}
!27 = !{i64 -3929095228167443711}
!28 = !{i64 -980743516189269280}
!29 = !{i64 -1976712438020499396}
!30 = !{i64 1584478925376980133}
!31 = !{i64 2896762332458114582}
!32 = !{i64 -8415284307662509487}
!33 = !{i64 8782314391302558527}
!34 = !{i64 -3744356981848045134}
!35 = !{i64 7861279579026029192}
!36 = !{i64 5758627411611523646}
!37 = !{i64 1925576009614819921}
!38 = !{i64 -5335783517166560803}
!39 = !{i64 7846629944915335817}
!40 = !{i64 5090657073899788390}
!41 = !{i64 4662155162923904486}
!42 = !{i64 -3566500641706226336}
!43 = !{i64 8129820326600546631}
!44 = !{i32 8, !"PIC Level", i32 2}
!45 = !{i32 7, !"PIE Level", i32 2}
!46 = !{i32 2, !"RtLibUseGOT", i32 1}
!47 = !{i32 7, !"uwtable", i32 2}
!48 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!49 = !{i64 -5755319513425990979}
!50 = !{i64 -460160396112746976}
!51 = !{i64 1109197427370885617}
!52 = !{i64 -4312221059168684510}
!53 = !{i64 -1124430466785450137}
!54 = !{i64 8246837298746136298}
!55 = !{i64 9024831069383307397}
!56 = !{i64 3230634688516518842}
!57 = !{i64 2691714319095292165}
!58 = !{i64 3618666912780608147}
!59 = !{i64 -8769307157291703980}
!60 = !{i64 -9116530801681979125}
!61 = distinct !{null}
!62 = !{i64 5691384628616640339}
!63 = !{i64 -2639049299472189661}
!64 = !{i64 -4885383371554750327}
!65 = !{i64 1938685876647298797}
!66 = !{i64 -2530103263361550246}
!67 = !{i64 8065476262060259843}
!68 = !{i64 -7832153506444102199}
!69 = !{i64 8948815151240981919}
!70 = !{i64 -2008014511235872614}
!71 = !{i64 7749059679706652029}
!72 = !{i64 -8660298359835779900}
!73 = !{i64 -8862851543010881815}
!74 = !{i64 -1865694261974319818}
!75 = !{i64 -6736358016164344758}
!76 = !{i64 1313289330272843}
!77 = !{i64 1478504810324487199}
!78 = !{i64 1944884099810745053}
!79 = !{i64 -6999200864559175345}
!80 = !{i64 -2561055321057584699}
!81 = !{i64 980727668439541601}
!82 = !{i64 -5230258393737323845}
!83 = !{i64 -417830796459413930}
!84 = !{i64 8704175235557799265}
!85 = !{i64 -453646358048781975}
!86 = !{i64 -4195818792076749472}
!87 = !{i64 -5802893869302275850}
!88 = !{i64 -5756214597634692134}
!89 = !{i64 4145150143888659912}
!90 = !{i64 1749356458583617810}
!91 = !{i64 6600661857335851143}
!92 = !{i64 2482926728672506561}
!93 = !{i64 826080590747153096}
!94 = !{i64 598590069027425289}
!95 = !{i64 3642150475742080844}
!96 = !{i64 8342386888934896732}
!97 = !{i64 8666780882023206313}
!98 = !{i64 -7156475999134890056}
!99 = !{i64 -200021931904908725}
!100 = !{i64 3985667861993573750}
!101 = !{i64 7215912043043150256}
!102 = !{i64 1880890190170209813}
!103 = !{i64 -4369776918159658176}
!104 = !{i64 -5296127614493736122}
!105 = !{i64 -796780069267723465}
!106 = !{i64 -9005208842985292797}
!107 = !{i64 7917229806289714785}
!108 = !{i64 7893978585490596922}
!109 = !{i64 6442811356716864228}
!110 = !{i64 -1797027227093933259}
!111 = !{i64 -5470831741489192300}
!112 = !{i64 1218278723115111228}
!113 = !{i64 -1477526989824958180}
!114 = !{i64 -2947670178743593892}
!115 = !{i64 -6849072608531177779}
!116 = !{i64 4403411649630885730}
!117 = !{i64 -7574606786256713042}
!118 = !{i64 -1667451194173558394}
!119 = !{i64 -459206372390731644}
!120 = !{i64 1759349976686547504}
!121 = !{i64 -8246491851802801535}
!122 = !{i64 1604944078202869625}
!123 = !{i64 263431604836306332}
!124 = !{i64 8621472042145227658}
!125 = !{i64 577739242088162207}
!126 = !{i64 -1765507791940752033}
!127 = !{i64 -2977949905396885904}
!128 = !{i64 5682420147018339987}
!129 = !{i64 -1803517147745877469}
!130 = !{i64 7095005041332807749}
!131 = !{i64 -9165348843414238052}
!132 = !{i64 -5042945471267645515}
!133 = !{i64 -9047621663906858806}
!134 = !{i64 -3604017514677112468}
!135 = !{i64 7324763236883027481}
!136 = !{i64 -284510977663552033}
!137 = !{i64 8540355229353176613}
!138 = !{i64 -1396643412959637061}
!139 = !{i64 5282247879904784407}
!140 = !{i64 9067713633682371413}
!141 = !{i64 -2899916521644090208}
!142 = !{i64 -4296047973881280409}
!143 = !{i64 8439072904299225677}
!144 = !{i64 -1587094038518833037}
!145 = !{i64 -4257474687660421123}
!146 = !{i64 8477684025316917333}
!147 = !{i64 4922024345065560313}
!148 = !{i64 -4200925979177793802}
!149 = !{i64 -3487224446849595855}
!150 = !{i64 -534838556767015530}
!151 = !{i64 -5220799157646269586}
!152 = !{i64 -8791854775646549108}
!153 = !{i64 -3979529178510389975}
!154 = !{i64 -8998483044044901988}
!155 = !{i64 5775215681334838738}
!156 = !{i64 1775428068531643292}
!157 = !{i64 -6275297649807015413}
!158 = !{i64 -4703475926865761757}
!159 = !{i64 7372352298499565038}
!160 = !{i64 3052561468724870978}
!161 = !{i64 -2964844738587680714}
!162 = !{i64 -7107786397417694241}
!163 = !{i64 -3234906564494625193}
!164 = !{i64 -7507665602201468137}
!165 = !{i64 -2067954167230702579}
!166 = !{i64 -5094405952377475024}
!167 = !{i64 7134170872011566924}
!168 = !{i64 4092814192334557616}
!169 = !{i64 -7696943250196661556}
!170 = !{i64 -2370347148582333061}
!171 = !{i64 4833170852633010280}
!172 = !{i64 8076169096024815663}
!173 = !{i64 -4394481064054140213}
!174 = !{i64 -4556659690687160885}
!175 = !{i64 3323133256946694244}
!176 = !{i64 -8197803947231924751}
!177 = !{i64 -1003758120140975649}
!178 = !{i64 8956641805048846860}
!179 = !{i64 -6540963829364779338}
!180 = !{i64 1945479574686239143}
!181 = !{i64 -2547073130480442203}
!182 = !{i64 -7116388604683724456}
!183 = !{i64 8561429920274143010}
!184 = !{i64 336084819883729319}
!185 = !{i64 457429358112925140}
!186 = !{i64 7377741012368704268}
!187 = !{i64 -7814017197531323394}
!188 = !{i64 5534539640235561103}
!189 = !{i64 -4128227918285680451}
!190 = !{i64 6762789264653537837}
!191 = !{i64 -1397695594215499136}
!192 = !{i64 5246819794606615283}
!193 = !{i64 5737798722712416889}
!194 = !{i64 -220742987627874301}
!195 = !{i64 -1318020902035058933}
!196 = !{i64 -6760690950529747258}
!197 = !{i64 8743910786000749142}
!198 = !{i64 -1175524296410159516}
!199 = !{i64 8928927201641677446}
!200 = !{i64 -7731590144819310792}
!201 = !{i64 6576944507513860726}
!202 = !{i64 -8788102259874178071}
!203 = !{i64 1621750522221372051}
!204 = !{i64 91686529798036074}
!205 = !{i64 -4821037565297899876}
!206 = !{i64 -721470801230103970}
!207 = !{i64 -8844932221354107516}
!208 = !{i64 3472914622387220875}
!209 = !{i64 -6094974795589079580}
!210 = !{i64 -2624081020897602054}
