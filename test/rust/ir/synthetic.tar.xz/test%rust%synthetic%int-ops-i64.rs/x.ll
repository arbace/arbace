; ModuleID = 'int_ops_i64.52e1d976adc0c9b5-cgu.0'
source_filename = "int_ops_i64.52e1d976adc0c9b5-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs77bartfBdiX_11int_ops_i64, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs77bartfBdiX_11int_ops_i64, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs77bartfBdiX_11int_ops_i64 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_b7f057a700061b96879a1cf049d1c13f = private unnamed_addr constant [4 x i8] c"@\00\00\00", align 4, !guid !3
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !4
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !5
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_0650fc06e3555b19ed30b4a487fcae53 = private unnamed_addr constant [35 x i8] c"test/rust/synthetic/int-ops-i64.rs\00", align 1, !guid !7
@alloc_ba4c6190b56bcc0f877727600bd354cf = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0650fc06e3555b19ed30b4a487fcae53, [16 x i8] c"\22\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !8
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !9
@alloc_e598637865b4604db8d3f58303cc6b74 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0650fc06e3555b19ed30b4a487fcae53, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !10
@alloc_283e2a02700f31caca1da06606fb5843 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0650fc06e3555b19ed30b4a487fcae53, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !11
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !12
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !13
@alloc_68b05c5b0d03faa1c11c6ffaa026f68e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0650fc06e3555b19ed30b4a487fcae53, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\00\1B\00\00\00" }>, align 8, !guid !14
@alloc_1aa2b2a2e12d4fb598e89543968040ce = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0650fc06e3555b19ed30b4a487fcae53, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !15
@alloc_fbea81e43716b56690e272d8e7e1b05c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0650fc06e3555b19ed30b4a487fcae53, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !16
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !17
@alloc_8b8d3a11c33c4c0b1dfc5088c30b1e2a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0650fc06e3555b19ed30b4a487fcae53, [16 x i8] c"\22\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !18
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !19
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !20
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !21
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !22
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !23
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !24
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !25
@alloc_ed657afd685e700993d44be1cb580312 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\C6\01\00\00\05\00\00\00" }>, align 8, !guid !26
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !27
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !28
@alloc_ae2de464f9b6df44eca1585c04dc7532 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00*\05\00\00\05\00\00\00" }>, align 8, !guid !29
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !30
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !31
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !32
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !33
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !34
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !35
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !36
@anon.80d8b92db779f2033b21acf97d35048d.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !37
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !38
@alloc_dd07830ff498a5ad3af27fc9310868e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E5\00\00\00\12\00\00\00" }>, align 8, !guid !39
@alloc_73a63def61abd19c5b285b7e5bba6f74 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E6\00\00\00\05\00\00\00" }>, align 8, !guid !40
@alloc_c9c619c258f652778f0098fbdacd3593 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F1\00\00\00\12\00\00\00" }>, align 8, !guid !41
@alloc_debe392282102e1a17f340d9b53f07df = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F2\00\00\00\12\00\00\00" }>, align 8, !guid !42
@alloc_d1e64d3a180065bd6a022925cad00717 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F3\00\00\00\05\00\00\00" }>, align 8, !guid !43
@alloc_9a4d1999757609695fb8537fcdec871b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FE\00\00\00\12\00\00\00" }>, align 8, !guid !44
@alloc_ffea377e021bf2f87b4ad4aac9bcd041 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FF\00\00\00\12\00\00\00" }>, align 8, !guid !45
@alloc_3410a5a3f8bc9abd6709ddad50da91f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\00\01\00\00\12\00\00\00" }>, align 8, !guid !46
@alloc_cb646754bd05cd238e749888201337e6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\01\01\00\00\05\00\00\00" }>, align 8, !guid !47
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !48
@alloc_b8612ffe3ceba24ef9f5ec716441ab42 = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: i64::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !49
@alloc_e284038bdc5c065a225db887d5238d07 = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: i64::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !50
@alloc_c856595eac66a24654d670eae8c59bb6 = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u64::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !51
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !52
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRxNtB6_5Debug3fmtCs2d0hS33vDhg_5gimli }>, align 8, !guid !53
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs77bartfBdiX_11int_ops_i64 }>, align 8, !guid !54
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !55
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !56
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !57
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !58
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !59
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !60
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !61
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCs77bartfBdiX_11int_ops_i64 }>, align 8, !guid !62

; <str>::parse::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsexECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !68 {
start:
; call <i64 as core::str::traits::FromStr>::from_str
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core3numxNtNtNtB7_3str6traits7FromStr8from_strCs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #17
  ret void
}

; <core::fmt::rt::Argument>::new_binary::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !69 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsz_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !70 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs77bartfBdiX_11int_ops_i64(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !71 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !72 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 4 %x) #17
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !73 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !74 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsD_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !75 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsF_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i64>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionxEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !76 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i64>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionxEE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<core::option::Option<i64>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionxEE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionxENtNtB7_3fmt5Debug3fmtCs77bartfBdiX_11int_ops_i64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i64, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultxNtNtNtB7_3num5error13ParseIntErrorEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !77 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i64, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultxNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<core::result::Result<i64, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultxNtNtNtBa_3num5error13ParseIntErrorEE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs77bartfBdiX_11int_ops_i64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(i64, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTxbEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !78 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(i64, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTxbEE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<(i64, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTxbEE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTxbENtB6_5Debug3fmtCs77bartfBdiX_11int_ops_i64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !79 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs77bartfBdiX_11int_ops_i64(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs77bartfBdiX_11int_ops_i64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !80 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs77bartfBdiX_11int_ops_i64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsB_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::option::Option<i64>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionxEE4castuECs77bartfBdiX_11int_ops_i64(ptr %self) unnamed_addr #0 !guid !81 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i64, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultxNtNtNtBa_3num5error13ParseIntErrorEE4castuECs77bartfBdiX_11int_ops_i64(ptr %self) unnamed_addr #0 !guid !82 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<(i64, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTxbEE4castuECs77bartfBdiX_11int_ops_i64(ptr %self) unnamed_addr #0 !guid !83 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs77bartfBdiX_11int_ops_i64(ptr %self) unnamed_addr #0 !guid !84 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs77bartfBdiX_11int_ops_i64(ptr %self) unnamed_addr #0 !guid !85 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs77bartfBdiX_11int_ops_i64(ptr %self) unnamed_addr #0 !guid !86 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs77bartfBdiX_11int_ops_i64(ptr %self) unnamed_addr #0 !guid !87 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECs77bartfBdiX_11int_ops_i64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !88 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs77bartfBdiX_11int_ops_i64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !89 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECs77bartfBdiX_11int_ops_i64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !90 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs77bartfBdiX_11int_ops_i64(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !91 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_right::<u64>
; Function Attrs: nounwind nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightyECs77bartfBdiX_11int_ops_i64(i64 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !92 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 8 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i64
  %_0 = call i64 @llvm.fshr.i64(i64 %x, i64 %x, i64 %1)
  ret i64 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::is_val_statically_known::<i64>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownxECs77bartfBdiX_11int_ops_i64(i64 %_arg) unnamed_addr #2 !guid !93 {
start:
  ret i1 false
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs77bartfBdiX_11int_ops_i64(i32 %dummy) unnamed_addr #0 !guid !94 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !95
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs77bartfBdiX_11int_ops_i64(i32 %dummy) unnamed_addr #0 !guid !96 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !95
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs77bartfBdiX_11int_ops_i64(i64 %dummy) unnamed_addr #0 !guid !97 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !95
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs77bartfBdiX_11int_ops_i64(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !98 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs77bartfBdiX_11int_ops_i64(ptr %f) #17
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #17
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs77bartfBdiX_11int_ops_i64(ptr align 8 %_1) unnamed_addr #0 !guid !99 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs77bartfBdiX_11int_ops_i64(ptr %_4) #20
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs77bartfBdiX_11int_ops_i64() #17
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs77bartfBdiX_11int_ops_i64(i8 %_2) #17
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs77bartfBdiX_11int_ops_i64(ptr %_1) unnamed_addr #0 !guid !100 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs77bartfBdiX_11int_ops_i64(ptr %0) #17
  ret i32 %_0
}

; int_ops_i64::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs77bartfBdiX_11int_ops_i644main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !101 {
start:
  %0 = alloca [16 x i8], align 8
  %_294 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_284 = alloca [24 x i8], align 8
  %_283 = alloca [24 x i8], align 8
  %_279 = alloca [24 x i8], align 8
  %_276 = alloca [8 x i8], align 8
  %_269 = alloca [16 x i8], align 8
  %_268 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_264 = alloca [4 x i8], align 4
  %_262 = alloca [8 x i8], align 8
  %_255 = alloca [16 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_252 = alloca [4 x i8], align 4
  %_250 = alloca [4 x i8], align 4
  %_243 = alloca [16 x i8], align 8
  %_242 = alloca [16 x i8], align 8
  %_241 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_239 = alloca [8 x i8], align 8
  %_237 = alloca [4 x i8], align 4
  %_233 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_226 = alloca [16 x i8], align 8
  %_225 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_222 = alloca [16 x i8], align 8
  %_220 = alloca [1 x i8], align 1
  %_216 = alloca [16 x i8], align 8
  %_209 = alloca [16 x i8], align 8
  %_208 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_206 = alloca [8 x i8], align 8
  %_203 = alloca [8 x i8], align 8
  %_196 = alloca [16 x i8], align 8
  %_195 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_193 = alloca [16 x i8], align 8
  %_190 = alloca [16 x i8], align 8
  %_183 = alloca [16 x i8], align 8
  %_182 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_176 = alloca [8 x i8], align 8
  %_170 = alloca [8 x i8], align 8
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [8 x i8], align 8
  %_156 = alloca [8 x i8], align 8
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [8 x i8], align 8
  %_144 = alloca [8 x i8], align 8
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [8 x i8], align 8
  %_130 = alloca [8 x i8], align 8
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [16 x i8], align 8
  %_98 = alloca [16 x i8], align 8
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [8 x i8], align 8
  %_86 = alloca [8 x i8], align 8
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [8 x i8], align 8
  %_74 = alloca [8 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [8 x i8], align 8
  %_62 = alloca [8 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %_50 = alloca [16 x i8], align 8
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_38 = alloca [16 x i8], align 8
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [8 x i8], align 8
  %min = alloca [8 x i8], align 8
; call core::hint::black_box::<i64>
  %_4 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs77bartfBdiX_11int_ops_i64(i64 -9223372036854775808) #17
; call core::hint::black_box::<i64>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs77bartfBdiX_11int_ops_i64(i64 9223372036854775807) #17
  store i64 %_4, ptr %min, align 8
  store i64 %_5, ptr %max, align 8
; call core::hint::black_box::<i64>
  %one = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs77bartfBdiX_11int_ops_i64(i64 1) #17
; call core::hint::black_box::<i64>
  %three = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs77bartfBdiX_11int_ops_i64(i64 3) #17
  store ptr %min, ptr %args, align 8
  %1 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_b7f057a700061b96879a1cf049d1c13f, ptr %2, align 8
  %_297 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_15, ptr align 8 %_297) #17
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  %_298 = load ptr, ptr %3, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_16, ptr align 8 %_298) #17
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  %_299 = load ptr, ptr %4, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_299) #17
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_15, i64 16, i1 false)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_16, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECs77bartfBdiX_11int_ops_i64(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #17
  %_9.0 = extractvalue { ptr, ptr } %8, 0
  %_9.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %9 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %11, align 8
  %_300 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_28, ptr align 8 %_300) #17
  %12 = getelementptr inbounds i8, ptr %args2, i64 8
  %_301 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_binary::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_29, ptr align 8 %_301) #17
  %13 = getelementptr inbounds i8, ptr %args2, i64 16
  %_302 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_octal::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_30, ptr align 8 %_302) #17
  %14 = getelementptr inbounds i8, ptr %args2, i64 24
  %_303 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_31, ptr align 8 %_303) #17
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_28, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_29, i64 16, i1 false)
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_30, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECs77bartfBdiX_11int_ops_i64(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #17
  %_21.0 = extractvalue { ptr, ptr } %19, 0
  %_21.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %20 = load i64, ptr %max, align 8
; call <i64>::checked_add
  %21 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_addCs77bartfBdiX_11int_ops_i64(i64 %20, i64 %one) #17
  %22 = extractvalue { i64, i64 } %21, 0
  %23 = extractvalue { i64, i64 } %21, 1
  store i64 %22, ptr %_38, align 8
  %24 = getelementptr inbounds i8, ptr %_38, i64 8
  store i64 %23, ptr %24, align 8
  %25 = load i64, ptr %min, align 8
; call <i64>::checked_add
  %26 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_addCs77bartfBdiX_11int_ops_i64(i64 %25, i64 %one) #17
  %27 = extractvalue { i64, i64 } %26, 0
  %28 = extractvalue { i64, i64 } %26, 1
  store i64 %27, ptr %_40, align 8
  %29 = getelementptr inbounds i8, ptr %_40, i64 8
  store i64 %28, ptr %29, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionxEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_42, ptr align 8 %_38) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionxEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_43, ptr align 8 %_40) #17
  %30 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %30, ptr align 8 %_42, i64 16, i1 false)
  %31 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %31, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %32 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #17
  %_35.0 = extractvalue { ptr, ptr } %32, 0
  %_35.1 = extractvalue { ptr, ptr } %32, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %33 = load i64, ptr %max, align 8
  %34 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %33, i64 %one)
  %_5.0.i = extractvalue { i64, i1 } %34, 0
  %_5.1.i = extractvalue { i64, i1 } %34, 1
  %35 = extractvalue { i64, i1 } %34, 0
  %36 = extractvalue { i64, i1 } %34, 1
  store i64 %35, ptr %_50, align 8
  %37 = getelementptr inbounds i8, ptr %_50, i64 8
  %38 = zext i1 %36 to i8
  store i8 %38, ptr %37, align 8
  %39 = load i64, ptr %min, align 8
  %40 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %39, i64 %one)
  %_5.0.i53 = extractvalue { i64, i1 } %40, 0
  %_5.1.i54 = extractvalue { i64, i1 } %40, 1
  %41 = extractvalue { i64, i1 } %40, 0
  %42 = extractvalue { i64, i1 } %40, 1
  store i64 %41, ptr %_52, align 8
  %43 = getelementptr inbounds i8, ptr %_52, i64 8
  %44 = zext i1 %42 to i8
  store i8 %44, ptr %43, align 8
; call <core::fmt::rt::Argument>::new_debug::<(i64, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTxbEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_54, ptr align 8 %_50) #17
; call <core::fmt::rt::Argument>::new_debug::<(i64, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTxbEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_55, ptr align 8 %_52) #17
  %45 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %45, ptr align 8 %_54, i64 16, i1 false)
  %46 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %46, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %47 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #17
  %_47.0 = extractvalue { ptr, ptr } %47, 0
  %_47.1 = extractvalue { ptr, ptr } %47, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %48 = load i64, ptr %max, align 8
  %_0.i35 = add i64 %48, %one
  store i64 %_0.i35, ptr %_62, align 8
  %49 = load i64, ptr %min, align 8
  %_0.i42 = sub i64 %49, %one
  store i64 %_0.i42, ptr %_64, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_66, ptr align 8 %_62) #17
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_67, ptr align 8 %_64) #17
  %50 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %50, ptr align 8 %_66, i64 16, i1 false)
  %51 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %52 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #17
  %_59.0 = extractvalue { ptr, ptr } %52, 0
  %_59.1 = extractvalue { ptr, ptr } %52, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %53 = load i64, ptr %max, align 8
  %_0.i49 = call i64 @llvm.sadd.sat.i64(i64 %53, i64 %three)
  store i64 %_0.i49, ptr %_74, align 8
  %54 = load i64, ptr %min, align 8
  %_0.i50 = call i64 @llvm.ssub.sat.i64(i64 %54, i64 %three)
  store i64 %_0.i50, ptr %_76, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_78, ptr align 8 %_74) #17
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_79, ptr align 8 %_76) #17
  %55 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %55, ptr align 8 %_78, i64 16, i1 false)
  %56 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %57 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #17
  %_71.0 = extractvalue { ptr, ptr } %57, 0
  %_71.1 = extractvalue { ptr, ptr } %57, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %58 = load i64, ptr %max, align 8
  %_0.i37 = mul i64 %58, %three
  store i64 %_0.i37, ptr %_86, align 8
  %59 = load i64, ptr %max, align 8
  %60 = load i64, ptr %max, align 8
  %_0.i36 = mul i64 %59, %60
  store i64 %_0.i36, ptr %_88, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_90, ptr align 8 %_86) #17
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_91, ptr align 8 %_88) #17
  %61 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %61, ptr align 8 %_90, i64 16, i1 false)
  %62 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %62, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %63 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #17
  %_83.0 = extractvalue { ptr, ptr } %63, 0
  %_83.1 = extractvalue { ptr, ptr } %63, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %64 = load i64, ptr %max, align 8
; call <i64>::checked_mul
  %65 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs77bartfBdiX_11int_ops_i64(i64 %64, i64 %three) #17
  %66 = extractvalue { i64, i64 } %65, 0
  %67 = extractvalue { i64, i64 } %65, 1
  store i64 %66, ptr %_98, align 8
  %68 = getelementptr inbounds i8, ptr %_98, i64 8
  store i64 %67, ptr %68, align 8
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs77bartfBdiX_11int_ops_i64(i32 5) #17
; call <i64>::checked_pow
  %69 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_powCs77bartfBdiX_11int_ops_i64(i64 %three, i32 %_101) #17
  %70 = extractvalue { i64, i64 } %69, 0
  %71 = extractvalue { i64, i64 } %69, 1
  store i64 %70, ptr %_100, align 8
  %72 = getelementptr inbounds i8, ptr %_100, i64 8
  store i64 %71, ptr %72, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionxEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_103, ptr align 8 %_98) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionxEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_104, ptr align 8 %_100) #17
  %73 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %73, ptr align 8 %_103, i64 16, i1 false)
  %74 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %74, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %75 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #17
  %_95.0 = extractvalue { ptr, ptr } %75, 0
  %_95.1 = extractvalue { ptr, ptr } %75, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %76 = load i64, ptr %max, align 8
  %77 = call i64 @llvm.ctpop.i64(i64 %76)
  %_0.i55 = trunc i64 %77 to i32
  store i32 %_0.i55, ptr %_111, align 4
  %78 = load i64, ptr %max, align 8
  %79 = call i64 @llvm.ctlz.i64(i64 %78, i1 false)
  %_0.i61 = trunc i64 %79 to i32
  store i32 %_0.i61, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs77bartfBdiX_11int_ops_i64(i32 3) #17
  %_119 = icmp ult i32 %_117, 64
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %80 = and i32 %_117, 63
  %81 = zext i32 %80 to i64
  %_116 = shl i64 %one, %81
  %82 = call i64 @llvm.cttz.i64(i64 %_116, i1 false)
  %_0.i62 = trunc i64 %82 to i32
  store i32 %_0.i62, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %83 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %83, align 8
  %84 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %84, align 8
  %_316 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_316) #17
  %85 = getelementptr inbounds i8, ptr %args10, i64 8
  %_317 = load ptr, ptr %85, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_317) #17
  %86 = getelementptr inbounds i8, ptr %args10, i64 16
  %_318 = load ptr, ptr %86, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_318) #17
  %87 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %87, ptr align 8 %_121, i64 16, i1 false)
  %88 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %88, ptr align 8 %_122, i64 16, i1 false)
  %89 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %89, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %90 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs77bartfBdiX_11int_ops_i64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #17
  %_108.0 = extractvalue { ptr, ptr } %90, 0
  %_108.1 = extractvalue { ptr, ptr } %90, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs77bartfBdiX_11int_ops_i64(i32 5) #17
  %91 = load i64, ptr %max, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i56 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %91, i32 %_131) #21
  store i64 %_0.i56, ptr %_130, align 8
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs77bartfBdiX_11int_ops_i64(i32 7) #17
  %92 = load i64, ptr %min, align 8
; call core::intrinsics::rotate_right::<u64>
  %_0.i59 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightyECs77bartfBdiX_11int_ops_i64(i64 %92, i32 %_134) #21
  store i64 %_0.i59, ptr %_133, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_136, ptr align 8 %_130) #17
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_137, ptr align 8 %_133) #17
  %93 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %93, ptr align 8 %_136, i64 16, i1 false)
  %94 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %94, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %95 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #17
  %_127.0 = extractvalue { ptr, ptr } %95, 0
  %_127.1 = extractvalue { ptr, ptr } %95, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %96 = load i64, ptr %max, align 8
  %_0.i = call i64 @llvm.bswap.i64(i64 %96)
  store i64 %_0.i, ptr %_144, align 8
  %97 = load i64, ptr %max, align 8
  %_0.i58 = call i64 @llvm.bitreverse.i64(i64 %97)
  store i64 %_0.i58, ptr %_146, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_148, ptr align 8 %_144) #17
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_149, ptr align 8 %_146) #17
  %98 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %98, ptr align 8 %_148, i64 16, i1 false)
  %99 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %99, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %100 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #17
  %_141.0 = extractvalue { ptr, ptr } %100, 0
  %_141.1 = extractvalue { ptr, ptr } %100, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs77bartfBdiX_11int_ops_i64(i32 70) #17
  %101 = load i64, ptr %max, align 8
  %_3.i38 = and i32 %_157, 63
; call core::ub_checks::check_language_ub
  %_3.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_3.i44, label %bb2.i, label %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <i64>::unchecked_shl::precondition_check
  call void @_RNvNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl18precondition_checkCs77bartfBdiX_11int_ops_i64(i32 %_3.i38, ptr align 8 @alloc_ed657afd685e700993d44be1cb580312) #22
  br label %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit

_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %102 = zext i32 %_3.i38 to i64
  %_0.i45 = shl i64 %101, %102
  store i64 %_0.i45, ptr %_156, align 8
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs77bartfBdiX_11int_ops_i64(i32 66) #17
  %103 = load i64, ptr %min, align 8
  %_3.i40 = and i32 %_160, 63
; call core::ub_checks::check_language_ub
  %_3.i46 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_3.i46, label %bb2.i48, label %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shr.exit

bb2.i48:                                          ; preds = %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit
; call <i64>::unchecked_shr::precondition_check
  call void @_RNvNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shr18precondition_checkCs77bartfBdiX_11int_ops_i64(i32 %_3.i40, ptr align 8 @alloc_ed657afd685e700993d44be1cb580312) #22
  br label %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shr.exit

_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shr.exit: ; preds = %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit, %bb2.i48
  %104 = zext i32 %_3.i40 to i64
  %_0.i47 = ashr i64 %103, %104
  store i64 %_0.i47, ptr %_159, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_162, ptr align 8 %_156) #17
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_163, ptr align 8 %_159) #17
  %105 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %105, ptr align 8 %_162, i64 16, i1 false)
  %106 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %106, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %107 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #17
  %_153.0 = extractvalue { ptr, ptr } %107, 0
  %_153.1 = extractvalue { ptr, ptr } %107, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i64 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_ba4c6190b56bcc0f877727600bd354cf) #23
  unreachable

bb85:                                             ; preds = %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shr.exit
  %_172 = icmp eq i64 %three, -1
  %108 = load i64, ptr %max, align 8
  %_173 = icmp eq i64 %108, -9223372036854775808
  %_174 = and i1 %_172, %_173
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_e598637865b4604db8d3f58303cc6b74) #23
  unreachable

bb86:                                             ; preds = %bb85
  %109 = load i64, ptr %max, align 8
  %110 = sdiv i64 %109, %three
  store i64 %110, ptr %_170, align 8
  %_177 = icmp eq i64 %three, 0
  br i1 %_177, label %panic27, label %bb87

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_e598637865b4604db8d3f58303cc6b74) #23
  unreachable

bb87:                                             ; preds = %bb86
  %_178 = icmp eq i64 %three, -1
  %111 = load i64, ptr %max, align 8
  %_179 = icmp eq i64 %111, -9223372036854775808
  %_180 = and i1 %_178, %_179
  br i1 %_180, label %panic28, label %bb88

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_283e2a02700f31caca1da06606fb5843) #23
  unreachable

bb88:                                             ; preds = %bb87
  %112 = load i64, ptr %max, align 8
  %113 = srem i64 %112, %three
  store i64 %113, ptr %_176, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_182, ptr align 8 %_170) #17
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_183, ptr align 8 %_176) #17
  %114 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %114, ptr align 8 %_182, i64 16, i1 false)
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_183, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %116 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #17
  %_167.0 = extractvalue { ptr, ptr } %116, 0
  %_167.1 = extractvalue { ptr, ptr } %116, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<i64>
  %_191 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs77bartfBdiX_11int_ops_i64(i64 0) #17
  %117 = load i64, ptr %max, align 8
; call <i64>::checked_div
  %118 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_divCs77bartfBdiX_11int_ops_i64(i64 %117, i64 %_191) #17
  %119 = extractvalue { i64, i64 } %118, 0
  %120 = extractvalue { i64, i64 } %118, 1
  store i64 %119, ptr %_190, align 8
  %121 = getelementptr inbounds i8, ptr %_190, i64 8
  store i64 %120, ptr %121, align 8
  %122 = load i64, ptr %max, align 8
; call <i64>::checked_rem
  %123 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_remCs77bartfBdiX_11int_ops_i64(i64 %122, i64 %three) #17
  %124 = extractvalue { i64, i64 } %123, 0
  %125 = extractvalue { i64, i64 } %123, 1
  store i64 %124, ptr %_193, align 8
  %126 = getelementptr inbounds i8, ptr %_193, i64 8
  store i64 %125, ptr %126, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionxEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_195, ptr align 8 %_190) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionxEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_196, ptr align 8 %_193) #17
  %127 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %127, ptr align 8 %_195, i64 16, i1 false)
  %128 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %128, ptr align 8 %_196, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %129 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #17
  %_187.0 = extractvalue { ptr, ptr } %129, 0
  %_187.1 = extractvalue { ptr, ptr } %129, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_187.0, ptr %_187.1)
; call core::hint::black_box::<u32>
  %_204 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs77bartfBdiX_11int_ops_i64(i32 4) #17
; call <i64>::pow
  %130 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx3powCs77bartfBdiX_11int_ops_i64(i64 %three, i32 %_204) #17
  store i64 %130, ptr %_203, align 8
  %131 = load i64, ptr %max, align 8
  %132 = load i64, ptr %min, align 8
; call <i64>::abs_diff
  %133 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx8abs_diffCs77bartfBdiX_11int_ops_i64(i64 %131, i64 %132) #17
  store i64 %133, ptr %_206, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_208, ptr align 8 %_203) #17
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_209, ptr align 8 %_206) #17
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_208, i64 16, i1 false)
  %135 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %135, ptr align 8 %_209, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %136 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #17
  %_200.0 = extractvalue { ptr, ptr } %136, 0
  %_200.1 = extractvalue { ptr, ptr } %136, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_200.0, ptr %_200.1)
; call core::hint::black_box::<u32>
  %_218 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs77bartfBdiX_11int_ops_i64(i32 7) #17
; call <i64>::from_str_radix
  call void @_RNvMsr_NtCsl10jNU3mE6R_4core3numx14from_str_radixCs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_216, ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_218) #17
; call <str>::parse::<i64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsexECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_222, ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #17
; call <core::result::Result<i64, core::num::error::ParseIntError>>::is_ok
  %137 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultxNtNtNtB4_3num5error13ParseIntErrorE5is_okCs77bartfBdiX_11int_ops_i64(ptr align 8 %_222) #17
  %138 = zext i1 %137 to i8
  store i8 %138, ptr %_220, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i64, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultxNtNtNtB7_3num5error13ParseIntErrorEECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_225, ptr align 8 %_216) #17
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_226, ptr %_220) #17
  %139 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %139, ptr align 8 %_225, i64 16, i1 false)
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_226, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %141 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #17
  %_213.0 = extractvalue { ptr, ptr } %141, 0
  %_213.1 = extractvalue { ptr, ptr } %141, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_213.0, ptr %_213.1)
  %142 = load i64, ptr %max, align 8
  %_235 = sitofp i64 %142 to double
  %_234 = call i64 @llvm.fptosi.sat.i64.f64(double %_235)
  %143 = load i64, ptr %max, align 8
  %144 = icmp eq i64 %_234, %143
  %145 = zext i1 %144 to i8
  store i8 %145, ptr %_233, align 1
  %146 = load i64, ptr %max, align 8
  %147 = sitofp i64 %146 to float
  store float %147, ptr %_237, align 4
  %148 = load i64, ptr %min, align 8
  %149 = sitofp i64 %148 to double
  store double %149, ptr %_239, align 8
  store ptr %_233, ptr %args19, align 8
  %150 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_237, ptr %150, align 8
  %151 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_239, ptr %151, align 8
  %_333 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_241, ptr %_333) #17
  %152 = getelementptr inbounds i8, ptr %args19, i64 8
  %_334 = load ptr, ptr %152, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_242, ptr align 4 %_334) #17
  %153 = getelementptr inbounds i8, ptr %args19, i64 16
  %_335 = load ptr, ptr %153, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_243, ptr align 8 %_335) #17
  %154 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %154, ptr align 8 %_241, i64 16, i1 false)
  %155 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %155, ptr align 8 %_242, i64 16, i1 false)
  %156 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %156, ptr align 8 %_243, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %157 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs77bartfBdiX_11int_ops_i64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #17
  %_230.0 = extractvalue { ptr, ptr } %157, 0
  %_230.1 = extractvalue { ptr, ptr } %157, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_230.0, ptr %_230.1)
  %158 = load i64, ptr %max, align 8
  %_2.i = xor i64 %158, -1
  %159 = call i64 @llvm.ctlz.i64(i64 %_2.i, i1 false)
  %_0.i60 = trunc i64 %159 to i32
  store i32 %_0.i60, ptr %_250, align 4
  %160 = load i64, ptr %min, align 8
  %161 = call i64 @llvm.cttz.i64(i64 %160, i1 false)
  %_0.i63 = trunc i64 %161 to i32
  store i32 %_0.i63, ptr %_252, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_254, ptr align 4 %_250) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_255, ptr align 4 %_252) #17
  %162 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %162, ptr align 8 %_254, i64 16, i1 false)
  %163 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %163, ptr align 8 %_255, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %164 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #17
  %_247.0 = extractvalue { ptr, ptr } %164, 0
  %_247.1 = extractvalue { ptr, ptr } %164, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_247.0, ptr %_247.1)
  %165 = load i64, ptr %max, align 8
; call <i64>::isqrt
  %166 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx5isqrtCs77bartfBdiX_11int_ops_i64(i64 %165, ptr align 8 @alloc_68b05c5b0d03faa1c11c6ffaa026f68e) #17
  store i64 %166, ptr %_262, align 8
  %167 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %three, i64 %three)
  %_266.0 = extractvalue { i64, i1 } %167, 0
  %_266.1 = extractvalue { i64, i1 } %167, 1
  br i1 %_266.1, label %panic29, label %bb127

panic28:                                          ; preds = %bb87
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_283e2a02700f31caca1da06606fb5843) #23
  unreachable

bb127:                                            ; preds = %bb88
; call <i64>::ilog2
  %168 = call i32 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx5ilog2Cs77bartfBdiX_11int_ops_i64(i64 %_266.0, ptr align 8 @alloc_fbea81e43716b56690e272d8e7e1b05c) #17
  store i32 %168, ptr %_264, align 4
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_268, ptr align 8 %_262) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_269, ptr align 4 %_264) #17
  %169 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %169, ptr align 8 %_268, i64 16, i1 false)
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_269, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %171 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #17
  %_259.0 = extractvalue { ptr, ptr } %171, 0
  %_259.1 = extractvalue { ptr, ptr } %171, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_259.0, ptr %_259.1)
; call <i64 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringxNtB5_8ToString9to_stringCs77bartfBdiX_11int_ops_i64(ptr sret([24 x i8]) align 8 %_279, ptr align 8 %max) #17
; invoke <alloc::string::String>::len
  %_277 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs77bartfBdiX_11int_ops_i64(ptr align 8 %_279)
          to label %bb134 unwind label %cleanup

panic29:                                          ; preds = %bb88
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_1aa2b2a2e12d4fb598e89543968040ce) #23
  unreachable

bb147:                                            ; preds = %bb146, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279) #24
          to label %bb148 unwind label %terminate

cleanup:                                          ; preds = %bb143, %bb136, %bb135, %bb134, %bb127
  %172 = landingpad { ptr, i32 }
          cleanup
  %173 = extractvalue { ptr, i32 } %172, 0
  %174 = extractvalue { ptr, i32 } %172, 1
  store ptr %173, ptr %0, align 8
  %175 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %174, ptr %175, align 8
  br label %bb147

bb134:                                            ; preds = %bb127
; invoke <core::fmt::rt::Argument>::new_display::<i64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_289, ptr align 8 %min)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  %176 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %176, ptr align 8 %_289, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %177 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb136 unwind label %cleanup

bb136:                                            ; preds = %bb135
  %_285.0 = extractvalue { ptr, ptr } %177, 0
  %_285.1 = extractvalue { ptr, ptr } %177, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCs77bartfBdiX_11int_ops_i64(ptr sret([24 x i8]) align 8 %_284, ptr %_285.0, ptr %_285.1)
          to label %bb137 unwind label %cleanup

bb137:                                            ; preds = %bb136
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_283, ptr align 8 %_284, i64 24, i1 false)
  br label %bb138

bb138:                                            ; preds = %bb137
; invoke <alloc::string::String>::len
  %_281 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs77bartfBdiX_11int_ops_i64(ptr align 8 %_283)
          to label %bb139 unwind label %cleanup30

bb146:                                            ; preds = %cleanup30
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283) #24
          to label %bb147 unwind label %terminate

cleanup30:                                        ; preds = %bb142, %bb141, %bb140, %panic31, %bb138
  %178 = landingpad { ptr, i32 }
          cleanup
  %179 = extractvalue { ptr, i32 } %178, 0
  %180 = extractvalue { ptr, i32 } %178, 1
  store ptr %179, ptr %0, align 8
  %181 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %180, ptr %181, align 8
  br label %bb146

bb139:                                            ; preds = %bb138
  %_292.0 = add i64 %_277, %_281
  %_292.1 = icmp ult i64 %_292.0, %_277
  br i1 %_292.1, label %panic31, label %bb140

bb140:                                            ; preds = %bb139
  store i64 %_292.0, ptr %_276, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_294, ptr align 8 %_276)
          to label %bb141 unwind label %cleanup30

panic31:                                          ; preds = %bb139
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_8b8d3a11c33c4c0b1dfc5088c30b1e2a) #19
          to label %unreachable unwind label %cleanup30

unreachable:                                      ; preds = %panic31
  unreachable

bb141:                                            ; preds = %bb140
  %182 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %182, ptr align 8 %_294, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %183 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb142 unwind label %cleanup30

bb142:                                            ; preds = %bb141
  %_273.0 = extractvalue { ptr, ptr } %183, 0
  %_273.1 = extractvalue { ptr, ptr } %183, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_273.0, ptr %_273.1)
          to label %bb143 unwind label %cleanup30

bb143:                                            ; preds = %bb142
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283)
          to label %bb144 unwind label %cleanup

bb144:                                            ; preds = %bb143
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279)
  ret void

terminate:                                        ; preds = %bb147, %bb146
  %184 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable

bb148:                                            ; preds = %bb147
  %185 = load ptr, ptr %0, align 8
  %186 = getelementptr inbounds i8, ptr %0, i64 8
  %187 = load i32, ptr %186, align 8
  %188 = insertvalue { ptr, i32 } poison, ptr %185, 0
  %189 = insertvalue { ptr, i32 } %188, i32 %187, 1
  resume { ptr, i32 } %189
}

; <alloc::string::String>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCs77bartfBdiX_11int_ops_i64(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !102 {
start:
  %_2 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8 %_2, i64 %capacity) #17
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs77bartfBdiX_11int_ops_i64(ptr align 8 %self) unnamed_addr #0 !guid !103 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #17
  ret i64 %_0
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs77bartfBdiX_11int_ops_i64(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !104 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs77bartfBdiX_11int_ops_i64(ptr align 8 %self) #17
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs77bartfBdiX_11int_ops_i64(i32 %ch) #17
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs77bartfBdiX_11int_ops_i64(ptr align 8 %self, i64 %ch_len) #17
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8 %self) #17
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs77bartfBdiX_11int_ops_i64(i32 %ch, ptr %_0.i) #17
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8 %self, i64 %_14) #17
  ret void
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs77bartfBdiX_11int_ops_i64(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !105 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::string::String>::push_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCs77bartfBdiX_11int_ops_i64(ptr align 8 %self, ptr %string.0, i64 %string.1) unnamed_addr #0 !guid !106 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %string.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %string.1, 1
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; call <alloc::vec::Vec<u8>>::extend_from_slice
  call void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8 %self, ptr %_4.0, i64 %_4.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs77bartfBdiX_11int_ops_i64(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !107 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<i64>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionxE7is_noneCs77bartfBdiX_11int_ops_i64(ptr align 8 %self) unnamed_addr #0 !guid !108 {
start:
; call <core::option::Option<i64>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionxE7is_someCs77bartfBdiX_11int_ops_i64(ptr align 8 %self) #17
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::option::Option<i64>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionxE7is_someCs77bartfBdiX_11int_ops_i64(ptr align 8 %self) unnamed_addr #0 !guid !109 {
start:
  %_0 = alloca [1 x i8], align 1
  %_2 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i64, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultxNtNtNtB4_3num5error13ParseIntErrorE5is_okCs77bartfBdiX_11int_ops_i64(ptr align 8 %self) unnamed_addr #0 !guid !110 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs77bartfBdiX_11int_ops_i64(i32 %self) unnamed_addr #0 !guid !111 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs77bartfBdiX_11int_ops_i64(i32 %self) #17
  ret i64 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs77bartfBdiX_11int_ops_i64(i32 %self, i32 %radix) unnamed_addr #0 !guid !112 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs77bartfBdiX_11int_ops_i64(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #17
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #23
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::num::nonzero::NonZero<u64>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE13leading_zerosCs77bartfBdiX_11int_ops_i64(i64 %self) unnamed_addr #0 !guid !113 {
start:
; call <core::num::nonzero::NonZero<u64>>::get
  %_2 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3getB9_(i64 %self) #17
  %0 = call i64 @llvm.ctlz.i64(i64 %_2, i1 true)
  %_0 = trunc i64 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u64>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE5ilog2Cs77bartfBdiX_11int_ops_i64(i64 %self) unnamed_addr #0 !guid !114 {
start:
; call <core::num::nonzero::NonZero<u64>>::leading_zeros
  %_3 = call i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE13leading_zerosCs77bartfBdiX_11int_ops_i64(i64 %self) #17
  %_0 = sub i32 63, %_3
  ret i32 %_0
}

; <i64>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx10strict_powCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !115 {
start:
  %_3 = alloca [16 x i8], align 8
; call <i64>::checked_pow
  %1 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_powCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %exp) #17
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_4 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_4 to i1
  br i1 %7, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %x = load i64, ptr %8, align 8
  ret i64 %x

bb3:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i64>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_addCs77bartfBdiX_11int_ops_i64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !116 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <i64>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_divCs77bartfBdiX_11int_ops_i64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !117 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5 = icmp eq i64 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %self, -9223372036854775808
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i64 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = sdiv i64 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_7, ptr %6, align 8
  store i64 1, ptr %_0, align 8
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i64, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { i64, i64 } poison, i64 %7, 0
  %11 = insertvalue { i64, i64 } %10, i64 %9, 1
  ret { i64, i64 } %11
}

; <i64>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs77bartfBdiX_11int_ops_i64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !118 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <i64>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_powCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %0) unnamed_addr #0 !guid !119 {
start:
  %_57 = alloca [16 x i8], align 8
  %_48 = alloca [16 x i8], align 8
  %_38 = alloca [16 x i8], align 8
  %_32 = alloca [16 x i8], align 8
  %_13 = alloca [8 x i8], align 4
  %acc = alloca [8 x i8], align 8
  %base = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i64 %self, ptr %base, align 8
  store i64 1, ptr %acc, align 8
  %_6 = load i64, ptr %base, align 8
  %_5 = call i1 @llvm.is.constant.i64(i64 %_6)
  br i1 %_5, label %bb2, label %bb16

bb16:                                             ; preds = %bb2, %start
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp eq i32 %_24, 0
  br i1 %_23, label %bb17, label %bb18

bb2:                                              ; preds = %start
  %_9 = load i64, ptr %base, align 8
; call <i64>::unsigned_abs
  %_8 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12unsigned_absCs77bartfBdiX_11int_ops_i64(i64 %_9) #17
  %1 = call i64 @llvm.ctpop.i64(i64 %_8)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb16

bb5:                                              ; preds = %bb2
  %_12 = load i64, ptr %base, align 8
; call <i64>::unsigned_abs
  %_11 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12unsigned_absCs77bartfBdiX_11int_ops_i64(i64 %_12) #17
; call <u64>::ilog2
  %k = call i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2Cs77bartfBdiX_11int_ops_i64(i64 %_11, ptr align 8 @alloc_ed657afd685e700993d44be1cb580312) #17
  %_14 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs77bartfBdiX_11int_ops_i64(i32 %k, i32 %_14) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_13, align 4
  %5 = getelementptr inbounds i8, ptr %_13, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_13, align 4
  %7 = getelementptr inbounds i8, ptr %_13, i64 4
  %8 = load i32, ptr %7, align 4
  %_15 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_15 to i1
  br i1 %9, label %bb11, label %bb10

bb18:                                             ; preds = %bb16
  %_26 = load i32, ptr %exp, align 4
  %_25 = call i1 @llvm.is.constant.i32(i32 %_26)
  br i1 %_25, label %bb20, label %bb32

bb17:                                             ; preds = %bb16
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb43

bb32:                                             ; preds = %bb42, %bb18
  %_47 = load i32, ptr %exp, align 4
  %_46 = and i32 %_47, 1
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb33, label %bb38

bb20:                                             ; preds = %bb30, %bb18
  %_28 = load i32, ptr %exp, align 4
  %_27 = icmp ugt i32 %_28, 1
  br i1 %_27, label %bb21, label %bb31

bb38:                                             ; preds = %bb36, %bb32
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_58 = load i64, ptr %base, align 8
  %_59 = load i64, ptr %base, align 8
; call <i64>::checked_mul
  %13 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs77bartfBdiX_11int_ops_i64(i64 %_58, i64 %_59) #17
  %14 = extractvalue { i64, i64 } %13, 0
  %15 = extractvalue { i64, i64 } %13, 1
  store i64 %14, ptr %_57, align 8
  %16 = getelementptr inbounds i8, ptr %_57, i64 8
  store i64 %15, ptr %16, align 8
  %_60 = load i64, ptr %_57, align 8
  %17 = getelementptr inbounds i8, ptr %_57, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = trunc nuw i64 %_60 to i1
  br i1 %19, label %bb42, label %bb41

bb33:                                             ; preds = %bb32
  %_49 = load i64, ptr %acc, align 8
  %_50 = load i64, ptr %base, align 8
; call <i64>::checked_mul
  %20 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs77bartfBdiX_11int_ops_i64(i64 %_49, i64 %_50) #17
  %21 = extractvalue { i64, i64 } %20, 0
  %22 = extractvalue { i64, i64 } %20, 1
  store i64 %21, ptr %_48, align 8
  %23 = getelementptr inbounds i8, ptr %_48, i64 8
  store i64 %22, ptr %23, align 8
  %_51 = load i64, ptr %_48, align 8
  %24 = getelementptr inbounds i8, ptr %_48, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = trunc nuw i64 %_51 to i1
  br i1 %26, label %bb36, label %bb35

bb36:                                             ; preds = %bb33
  %27 = getelementptr inbounds i8, ptr %_48, i64 8
  %x = load i64, ptr %27, align 8
  store i64 %x, ptr %acc, align 8
  %_54 = load i32, ptr %exp, align 4
  %_53 = icmp eq i32 %_54, 1
  br i1 %_53, label %bb37, label %bb38

bb35:                                             ; preds = %bb33
  store i64 0, ptr %_0, align 8
  br label %bb43

bb43:                                             ; preds = %bb14, %bb15, %bb10, %bb17, %bb29, %bb24, %bb31, %bb37, %bb41, %bb35
  %28 = load i64, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { i64, i64 } poison, i64 %28, 0
  %32 = insertvalue { i64, i64 } %31, i64 %30, 1
  ret { i64, i64 } %32

bb37:                                             ; preds = %bb36
  %_55 = load i64, ptr %acc, align 8
  %33 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_55, ptr %33, align 8
  store i64 1, ptr %_0, align 8
  br label %bb43

bb42:                                             ; preds = %bb38
  %34 = getelementptr inbounds i8, ptr %_57, i64 8
  %x1 = load i64, ptr %34, align 8
  store i64 %x1, ptr %base, align 8
  br label %bb32

bb41:                                             ; preds = %bb38
  store i64 0, ptr %_0, align 8
  br label %bb43

bb31:                                             ; preds = %bb20
  %_43 = load i64, ptr %acc, align 8
  %_44 = load i64, ptr %base, align 8
; call <i64>::checked_mul
  %35 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs77bartfBdiX_11int_ops_i64(i64 %_43, i64 %_44) #17
  %36 = extractvalue { i64, i64 } %35, 0
  %37 = extractvalue { i64, i64 } %35, 1
  store i64 %36, ptr %_0, align 8
  %38 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %37, ptr %38, align 8
  br label %bb43

bb21:                                             ; preds = %bb20
  %_31 = load i32, ptr %exp, align 4
  %_30 = and i32 %_31, 1
  %_29 = icmp eq i32 %_30, 1
  br i1 %_29, label %bb22, label %bb26

bb26:                                             ; preds = %bb25, %bb21
  %39 = load i32, ptr %exp, align 4
  %40 = udiv i32 %39, 2
  store i32 %40, ptr %exp, align 4
  %_39 = load i64, ptr %base, align 8
  %_40 = load i64, ptr %base, align 8
; call <i64>::checked_mul
  %41 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs77bartfBdiX_11int_ops_i64(i64 %_39, i64 %_40) #17
  %42 = extractvalue { i64, i64 } %41, 0
  %43 = extractvalue { i64, i64 } %41, 1
  store i64 %42, ptr %_38, align 8
  %44 = getelementptr inbounds i8, ptr %_38, i64 8
  store i64 %43, ptr %44, align 8
  %_41 = load i64, ptr %_38, align 8
  %45 = getelementptr inbounds i8, ptr %_38, i64 8
  %46 = load i64, ptr %45, align 8
  %47 = trunc nuw i64 %_41 to i1
  br i1 %47, label %bb30, label %bb29

bb22:                                             ; preds = %bb21
  %_33 = load i64, ptr %acc, align 8
  %_34 = load i64, ptr %base, align 8
; call <i64>::checked_mul
  %48 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs77bartfBdiX_11int_ops_i64(i64 %_33, i64 %_34) #17
  %49 = extractvalue { i64, i64 } %48, 0
  %50 = extractvalue { i64, i64 } %48, 1
  store i64 %49, ptr %_32, align 8
  %51 = getelementptr inbounds i8, ptr %_32, i64 8
  store i64 %50, ptr %51, align 8
  %_35 = load i64, ptr %_32, align 8
  %52 = getelementptr inbounds i8, ptr %_32, i64 8
  %53 = load i64, ptr %52, align 8
  %54 = trunc nuw i64 %_35 to i1
  br i1 %54, label %bb25, label %bb24

bb25:                                             ; preds = %bb22
  %55 = getelementptr inbounds i8, ptr %_32, i64 8
  %x2 = load i64, ptr %55, align 8
  store i64 %x2, ptr %acc, align 8
  br label %bb26

bb24:                                             ; preds = %bb22
  store i64 0, ptr %_0, align 8
  br label %bb43

bb30:                                             ; preds = %bb26
  %56 = getelementptr inbounds i8, ptr %_38, i64 8
  %x3 = load i64, ptr %56, align 8
  store i64 %x3, ptr %base, align 8
  br label %bb20

bb29:                                             ; preds = %bb26
  store i64 0, ptr %_0, align 8
  br label %bb43

bb11:                                             ; preds = %bb5
  %57 = getelementptr inbounds i8, ptr %_13, i64 4
  %shift = load i32, ptr %57, align 4
  %_18 = load i64, ptr %base, align 8
  %_17 = icmp slt i64 %_18, 0
  br i1 %_17, label %bb12, label %bb15

bb10:                                             ; preds = %bb5
  store i64 0, ptr %_0, align 8
  br label %bb43

bb15:                                             ; preds = %bb12, %bb11
; call <i64>::shl_exact
  %58 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx9shl_exactCs77bartfBdiX_11int_ops_i64(i64 1, i32 %shift) #17
  %59 = extractvalue { i64, i64 } %58, 0
  %60 = extractvalue { i64, i64 } %58, 1
  store i64 %59, ptr %_0, align 8
  %61 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %60, ptr %61, align 8
  br label %bb43

bb12:                                             ; preds = %bb11
  %_21 = load i32, ptr %exp, align 4
  %_20 = urem i32 %_21, 2
  %_19 = icmp eq i32 %_20, 1
  br i1 %_19, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
; call <i64>::shl_exact
  %62 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx9shl_exactCs77bartfBdiX_11int_ops_i64(i64 -1, i32 %shift) #17
  %63 = extractvalue { i64, i64 } %62, 0
  %64 = extractvalue { i64, i64 } %62, 1
  store i64 %63, ptr %_0, align 8
  %65 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %64, ptr %65, align 8
  br label %bb43

bb9:                                              ; No predecessors!
  unreachable
}

; <i64>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_remCs77bartfBdiX_11int_ops_i64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !120 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5 = icmp eq i64 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %self, -9223372036854775808
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i64 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = srem i64 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_7, ptr %6, align 8
  store i64 1, ptr %_0, align 8
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i64, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { i64, i64 } poison, i64 %7, 0
  %11 = insertvalue { i64, i64 } %10, i64 %9, 1
  ret { i64, i64 } %11
}

; <i64>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_subCs77bartfBdiX_11int_ops_i64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !121 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <i64>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12unsigned_absCs77bartfBdiX_11int_ops_i64(i64 %self) unnamed_addr #0 !guid !122 {
start:
; call <i64>::wrapping_abs
  %_2 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12wrapping_absCs77bartfBdiX_11int_ops_i64(i64 %self) #17
  ret i64 %_2
}

; <i64>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12wrapping_absCs77bartfBdiX_11int_ops_i64(i64 %self) unnamed_addr #0 !guid !123 {
start:
  %_0 = alloca [8 x i8], align 8
  %_0.i = icmp slt i64 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i64 %self, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i64 0, %self
  store i64 %_0.i2, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; <i64>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12wrapping_powCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %exp) unnamed_addr #0 !guid !124 {
start:
; call <i64>::overflowing_pow
  %0 = call { i64, i1 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx15overflowing_powCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %exp) #17
  %_3.0 = extractvalue { i64, i1 } %0, 0
  %_3.1 = extractvalue { i64, i1 } %0, 1
  ret i64 %_3.0
}

; <i64>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx13checked_ilog2Cs77bartfBdiX_11int_ops_i64(i64 %self) unnamed_addr #0 !guid !125 {
start:
  %_0 = alloca [8 x i8], align 4
  %_2 = icmp sle i64 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = call i64 @llvm.ctlz.i64(i64 %self, i1 true)
  %_5 = trunc i64 %0 to i32
  %log = sub i32 63, %_5
  %1 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %log, ptr %1, align 4
  store i32 1, ptr %_0, align 4
  br label %bb4

bb1:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  %2 = load i32, ptr %_0, align 4
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  %4 = load i32, ptr %3, align 4
  %5 = insertvalue { i32, i32 } poison, i32 %2, 0
  %6 = insertvalue { i32, i32 } %5, i32 %4, 1
  ret { i32, i32 } %6
}

; <i64>::checked_isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx13checked_isqrtCs77bartfBdiX_11int_ops_i64(i64 %self) unnamed_addr #0 !guid !126 {
start:
  %_0 = alloca [16 x i8], align 8
  %_2 = icmp slt i64 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call <u64>::isqrt
  %_4 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5isqrtCs77bartfBdiX_11int_ops_i64(i64 %self) #17
  %_7 = icmp sle i64 %_4, 3037000499
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb2
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_7, ptr align 8 @alloc_ed657afd685e700993d44be1cb580312) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb2, %bb2.i
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb1, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <i64>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unbounded_shlCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %rhs) unnamed_addr #0 !guid !127 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp ult i32 %rhs, 64
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <i64>::unchecked_shl::precondition_check
  call void @_RNvNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl18precondition_checkCs77bartfBdiX_11int_ops_i64(i32 %rhs, ptr align 8 @alloc_ed657afd685e700993d44be1cb580312) #22
  br label %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit

_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i64
  %_0.i = shl i64 %self, %0
  store i64 %_0.i, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <i64>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i1 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx15overflowing_powCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %0) unnamed_addr #0 !guid !128 {
start:
  %_30 = alloca [16 x i8], align 8
  %base1 = alloca [8 x i8], align 8
  %_16 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [8 x i8], align 8
  %base = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i64 %self, ptr %base, align 8
  store i64 1, ptr %acc, align 8
  store i8 0, ptr %overflow, align 1
  %_8 = load i64, ptr %base, align 8
  %_7 = call i1 @llvm.is.constant.i64(i64 %_8)
  br i1 %_7, label %bb2, label %bb19

bb19:                                             ; preds = %bb2, %start
  %_33 = load i32, ptr %exp, align 4
  %_32 = icmp eq i32 %_33, 0
  br i1 %_32, label %bb20, label %bb21

bb2:                                              ; preds = %start
  %_11 = load i64, ptr %base, align 8
; call <i64>::unsigned_abs
  %_10 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12unsigned_absCs77bartfBdiX_11int_ops_i64(i64 %_11) #17
  %1 = call i64 @llvm.ctpop.i64(i64 %_10)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb19

bb5:                                              ; preds = %bb2
  %_14 = load i64, ptr %base, align 8
; call <i64>::unsigned_abs
  %_13 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12unsigned_absCs77bartfBdiX_11int_ops_i64(i64 %_14) #17
; call <u64>::ilog2
  %k = call i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2Cs77bartfBdiX_11int_ops_i64(i64 %_13, ptr align 8 @alloc_ed657afd685e700993d44be1cb580312) #17
  %_17 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs77bartfBdiX_11int_ops_i64(i32 %k, i32 %_17) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_16, align 4
  %5 = getelementptr inbounds i8, ptr %_16, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_16, align 4
  %7 = getelementptr inbounds i8, ptr %_16, i64 4
  %8 = load i32, ptr %7, align 4
  %_18 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_18 to i1
  br i1 %9, label %bb9, label %bb10

bb21:                                             ; preds = %bb19
  %_35 = load i32, ptr %exp, align 4
  %_34 = call i1 @llvm.is.constant.i32(i32 %_35)
  br i1 %_34, label %bb23, label %bb32

bb20:                                             ; preds = %bb19
  store i128 1, ptr %_0, align 8
  br label %bb39

bb32:                                             ; preds = %bb36, %bb21
  %_64 = load i32, ptr %exp, align 4
  %_63 = and i32 %_64, 1
  %_62 = icmp eq i32 %_63, 1
  br i1 %_62, label %bb33, label %bb36

bb23:                                             ; preds = %bb27, %bb21
  %_37 = load i32, ptr %exp, align 4
  %_36 = icmp ugt i32 %_37, 1
  br i1 %_36, label %bb24, label %bb30

bb36:                                             ; preds = %bb33, %bb32
  %10 = load i32, ptr %exp, align 4
  %11 = udiv i32 %10, 2
  store i32 %11, ptr %exp, align 4
  %_79 = load i64, ptr %base, align 8
  %_80 = load i64, ptr %base, align 8
  %12 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %_79, i64 %_80)
  %_5.0.i6 = extractvalue { i64, i1 } %12, 0
  %_5.1.i7 = extractvalue { i64, i1 } %12, 1
  %_78.0 = extractvalue { i64, i1 } %12, 0
  %_78.1 = extractvalue { i64, i1 } %12, 1
  store i64 %_78.0, ptr %base, align 8
  %13 = zext i1 %_78.1 to i8
  store i8 %13, ptr %tmp_overflow, align 1
  %14 = load i8, ptr %tmp_overflow, align 1
  %_81 = trunc nuw i8 %14 to i1
  %15 = load i8, ptr %overflow, align 1
  %16 = trunc nuw i8 %15 to i1
  %17 = or i1 %16, %_81
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %overflow, align 1
  br label %bb32

bb33:                                             ; preds = %bb32
  %_68 = load i64, ptr %acc, align 8
  %_69 = load i64, ptr %base, align 8
  %19 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %_68, i64 %_69)
  %_5.0.i8 = extractvalue { i64, i1 } %19, 0
  %_5.1.i9 = extractvalue { i64, i1 } %19, 1
  %_67.0 = extractvalue { i64, i1 } %19, 0
  %_67.1 = extractvalue { i64, i1 } %19, 1
  store i64 %_67.0, ptr %acc, align 8
  %20 = zext i1 %_67.1 to i8
  store i8 %20, ptr %tmp_overflow, align 1
  %21 = load i8, ptr %tmp_overflow, align 1
  %_70 = trunc nuw i8 %21 to i1
  %22 = load i8, ptr %overflow, align 1
  %23 = trunc nuw i8 %22 to i1
  %24 = or i1 %23, %_70
  %25 = zext i1 %24 to i8
  store i8 %25, ptr %overflow, align 1
  %_72 = load i32, ptr %exp, align 4
  %_71 = icmp eq i32 %_72, 1
  br i1 %_71, label %bb35, label %bb36

bb35:                                             ; preds = %bb33
  %_73 = load i64, ptr %acc, align 8
  %26 = load i8, ptr %overflow, align 1
  %_74 = trunc nuw i8 %26 to i1
  store i64 %_73, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  %28 = zext i1 %_74 to i8
  store i8 %28, ptr %27, align 8
  br label %bb39

bb39:                                             ; preds = %bb10, %bb15, %bb20, %bb30, %bb35
  %29 = load i64, ptr %_0, align 8
  %30 = getelementptr inbounds i8, ptr %_0, i64 8
  %31 = load i8, ptr %30, align 8
  %32 = trunc nuw i8 %31 to i1
  %33 = insertvalue { i64, i1 } poison, i64 %29, 0
  %34 = insertvalue { i64, i1 } %33, i1 %32, 1
  ret { i64, i1 } %34

bb30:                                             ; preds = %bb23
  %_57 = load i64, ptr %acc, align 8
  %_58 = load i64, ptr %base, align 8
  %35 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %_57, i64 %_58)
  %_5.0.i4 = extractvalue { i64, i1 } %35, 0
  %_5.1.i5 = extractvalue { i64, i1 } %35, 1
  %_56.0 = extractvalue { i64, i1 } %35, 0
  %_56.1 = extractvalue { i64, i1 } %35, 1
  store i64 %_56.0, ptr %acc, align 8
  %36 = zext i1 %_56.1 to i8
  store i8 %36, ptr %tmp_overflow, align 1
  %37 = load i8, ptr %tmp_overflow, align 1
  %_59 = trunc nuw i8 %37 to i1
  %38 = load i8, ptr %overflow, align 1
  %39 = trunc nuw i8 %38 to i1
  %40 = or i1 %39, %_59
  %41 = zext i1 %40 to i8
  store i8 %41, ptr %overflow, align 1
  %_60 = load i64, ptr %acc, align 8
  %42 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %42 to i1
  store i64 %_60, ptr %_0, align 8
  %43 = getelementptr inbounds i8, ptr %_0, i64 8
  %44 = zext i1 %_61 to i8
  store i8 %44, ptr %43, align 8
  br label %bb39

bb24:                                             ; preds = %bb23
  %_40 = load i32, ptr %exp, align 4
  %_39 = and i32 %_40, 1
  %_38 = icmp eq i32 %_39, 1
  br i1 %_38, label %bb25, label %bb27

bb27:                                             ; preds = %bb25, %bb24
  %45 = load i32, ptr %exp, align 4
  %46 = udiv i32 %45, 2
  store i32 %46, ptr %exp, align 4
  %_51 = load i64, ptr %base, align 8
  %_52 = load i64, ptr %base, align 8
  %47 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %_51, i64 %_52)
  %_5.0.i = extractvalue { i64, i1 } %47, 0
  %_5.1.i = extractvalue { i64, i1 } %47, 1
  %_50.0 = extractvalue { i64, i1 } %47, 0
  %_50.1 = extractvalue { i64, i1 } %47, 1
  store i64 %_50.0, ptr %base, align 8
  %48 = zext i1 %_50.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_53 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_53
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  br label %bb23

bb25:                                             ; preds = %bb24
  %_44 = load i64, ptr %acc, align 8
  %_45 = load i64, ptr %base, align 8
  %54 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %_44, i64 %_45)
  %_5.0.i2 = extractvalue { i64, i1 } %54, 0
  %_5.1.i3 = extractvalue { i64, i1 } %54, 1
  %_43.0 = extractvalue { i64, i1 } %54, 0
  %_43.1 = extractvalue { i64, i1 } %54, 1
  store i64 %_43.0, ptr %acc, align 8
  %55 = zext i1 %_43.1 to i8
  store i8 %55, ptr %tmp_overflow, align 1
  %56 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %56 to i1
  %57 = load i8, ptr %overflow, align 1
  %58 = trunc nuw i8 %57 to i1
  %59 = or i1 %58, %_46
  %60 = zext i1 %59 to i8
  store i8 %60, ptr %overflow, align 1
  br label %bb27

bb9:                                              ; preds = %bb5
  %61 = getelementptr inbounds i8, ptr %_16, i64 4
  %shift = load i32, ptr %61, align 4
  %_21 = load i64, ptr %base, align 8
  %_20 = icmp slt i64 %_21, 0
  br i1 %_20, label %bb11, label %bb14

bb10:                                             ; preds = %bb5
  store i128 18446744073709551616, ptr %_0, align 8
  br label %bb39

bb14:                                             ; preds = %bb11, %bb9
  store i64 1, ptr %base1, align 8
  br label %bb15

bb11:                                             ; preds = %bb9
  %_24 = load i32, ptr %exp, align 4
  %_23 = urem i32 %_24, 2
  %_22 = icmp ne i32 %_23, 0
  br i1 %_22, label %bb13, label %bb14

bb13:                                             ; preds = %bb11
  store i64 -1, ptr %base1, align 8
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_27 = load i64, ptr %base1, align 8
; call <i64>::unbounded_shl
  %_26 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unbounded_shlCs77bartfBdiX_11int_ops_i64(i64 %_27, i32 %shift) #17
  %_31 = load i64, ptr %base1, align 8
; call <i64>::shl_exact
  %62 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx9shl_exactCs77bartfBdiX_11int_ops_i64(i64 %_31, i32 %shift) #17
  %63 = extractvalue { i64, i64 } %62, 0
  %64 = extractvalue { i64, i64 } %62, 1
  store i64 %63, ptr %_30, align 8
  %65 = getelementptr inbounds i8, ptr %_30, i64 8
  store i64 %64, ptr %65, align 8
; call <core::option::Option<i64>>::is_none
  %_28 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionxE7is_noneCs77bartfBdiX_11int_ops_i64(ptr align 8 %_30) #17
  store i64 %_26, ptr %_0, align 8
  %66 = getelementptr inbounds i8, ptr %_0, i64 8
  %67 = zext i1 %_28 to i8
  store i8 %67, ptr %66, align 8
  br label %bb39

bb40:                                             ; No predecessors!
  unreachable
}

; <i64>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx3powCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %exp) unnamed_addr #0 !guid !129 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <i64>::strict_pow
  %0 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx10strict_powCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %exp, ptr align 8 @alloc_ed657afd685e700993d44be1cb580312) #17
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb2:                                              ; No predecessors!
; call <i64>::wrapping_pow
  %1 = call i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12wrapping_powCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %exp) #17
  store i64 %1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i64, ptr %_0, align 8
  ret i64 %2
}

; <i64>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx5ilog2Cs77bartfBdiX_11int_ops_i64(i64 %self, ptr align 8 %0) unnamed_addr #0 !guid !130 {
start:
  %_2 = alloca [8 x i8], align 4
; call <i64>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx13checked_ilog2Cs77bartfBdiX_11int_ops_i64(i64 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i64>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx5isqrtCs77bartfBdiX_11int_ops_i64(i64 %self, ptr align 8 %0) unnamed_addr #0 !guid !131 {
start:
  %_2 = alloca [16 x i8], align 8
; call <i64>::checked_isqrt
  %1 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx13checked_isqrtCs77bartfBdiX_11int_ops_i64(i64 %self) #17
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %3, ptr %4, align 8
  %_3 = load i64, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_3 to i1
  br i1 %7, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_2, i64 8
  %sqrt = load i64, ptr %8, align 8
  ret i64 %sqrt

bb3:                                              ; preds = %start
; call core::num::imp::int_sqrt::panic_for_negative_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i64>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx8abs_diffCs77bartfBdiX_11int_ops_i64(i64 %self, i64 %other) unnamed_addr #0 !guid !132 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp slt i64 %self, %other
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_0.i1 = sub i64 %self, %other
  store i64 %_0.i1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  %_0.i = sub i64 %other, %self
  store i64 %_0.i, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; <i64>::shl_exact
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx9shl_exactCs77bartfBdiX_11int_ops_i64(i64 %self, i32 %rhs) unnamed_addr #0 !guid !133 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = call i64 @llvm.ctlz.i64(i64 %self, i1 false)
  %_0.i4 = trunc i64 %0 to i32
  %_3 = icmp ult i32 %rhs, %_0.i4
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_2.i = xor i64 %self, -1
  %1 = call i64 @llvm.ctlz.i64(i64 %_2.i, i1 false)
  %_0.i = trunc i64 %1 to i32
  %_5 = icmp ult i32 %rhs, %_0.i
  br i1 %_5, label %bb4, label %bb6

bb4:                                              ; preds = %bb2, %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit

bb2.i:                                            ; preds = %bb4
; call <i64>::unchecked_shl::precondition_check
  call void @_RNvNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl18precondition_checkCs77bartfBdiX_11int_ops_i64(i32 %rhs, ptr align 8 @alloc_ed657afd685e700993d44be1cb580312) #22
  br label %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit

_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit: ; preds = %bb4, %bb2.i
  %2 = zext i32 %rhs to i64
  %_0.i2 = shl i64 %self, %2
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_0.i2, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb6:                                              ; preds = %bb2
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %_RNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl.exit, %bb6
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <core::ptr::non_null::NonNull<core::option::Option<i64>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionxEE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %r) unnamed_addr #0 !guid !134 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i64, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultxNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %r) unnamed_addr #0 !guid !135 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<(i64, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTxbEE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %r) unnamed_addr #0 !guid !136 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs77bartfBdiX_11int_ops_i64(ptr %r) unnamed_addr #0 !guid !137 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %r) unnamed_addr #0 !guid !138 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 4 %r) unnamed_addr #0 !guid !139 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs77bartfBdiX_11int_ops_i64(ptr align 8 %r) unnamed_addr #0 !guid !140 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCs77bartfBdiX_11int_ops_i64(ptr align 8 %self) unnamed_addr #0 !guid !141 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #17
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs77bartfBdiX_11int_ops_i64(ptr %_7.0, i64 %_7.1) #17
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs77bartfBdiX_11int_ops_i64(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !142 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs77bartfBdiX_11int_ops_i64(ptr %s.0, i64 %s.1) #17
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs77bartfBdiX_11int_ops_i64(i32 %self, i32 %rhs) unnamed_addr #0 !guid !143 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u64>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13checked_ilog2Cs77bartfBdiX_11int_ops_i64(i64 %self) unnamed_addr #0 !guid !144 {
start:
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u64>>::new
  %0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3newB9_(i64 %self) #17
  store i64 %0, ptr %_2, align 8
  %1 = load i64, ptr %_2, align 8
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i64, ptr %_2, align 8
; call <core::num::nonzero::NonZero<u64>>::ilog2
  %_5 = call i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE5ilog2Cs77bartfBdiX_11int_ops_i64(i64 %x) #17
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u64>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2Cs77bartfBdiX_11int_ops_i64(i64 %self, ptr align 8 %0) unnamed_addr #0 !guid !145 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u64>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13checked_ilog2Cs77bartfBdiX_11int_ops_i64(i64 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u64>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5isqrtCs77bartfBdiX_11int_ops_i64(i64 %self) unnamed_addr #0 !guid !146 {
start:
; call core::num::imp::int_sqrt::u64
  %result = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64Cs77bartfBdiX_11int_ops_i64(i64 %self) #17
  %_3 = icmp ule i64 %result, 4294967295
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_3, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i64 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u64>::unchecked_mul::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul18precondition_checkCs77bartfBdiX_11int_ops_i64(i64 %result, i64 %result, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i64 %result, %result
  %_8 = icmp ule i64 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_8, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i64 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_11, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i64 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i64 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_6, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs77bartfBdiX_11int_ops_i64(ptr %self) unnamed_addr #0 !guid !147 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs77bartfBdiX_11int_ops_i64(i8 %0) unnamed_addr #0 !guid !148 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs77bartfBdiX_11int_ops_i64(ptr %self) #17
  ret i32 %_0
}

; <i64>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsr_NtCsl10jNU3mE6R_4core3numx14from_str_radixCs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !149 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <i64>::from_ascii_bytes_radix_impl
  call void @_RNvMsr_NtCsl10jNU3mE6R_4core3numx27from_ascii_bytes_radix_implCs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #17
  ret void
}

; <i64>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsr_NtCsl10jNU3mE6R_4core3numx27from_ascii_bytes_radix_implCs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !150 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [16 x i8], align 8
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [16 x i8], align 8
  %_74 = alloca [16 x i8], align 8
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [16 x i8], align 8
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [8 x i8], align 8
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #23
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #17
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !151
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i64 0, ptr %result, align 8
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs77bartfBdiX_11int_ops_i64.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 15
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs77bartfBdiX_11int_ops_i64.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs77bartfBdiX_11int_ops_i64.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs77bartfBdiX_11int_ops_i64.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowxECs77bartfBdiX_11int_ops_i64.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i64, ptr %result, align 8
  %33 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_105, ptr %33, align 8
  store i8 0, ptr %_0, align 8
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i64, ptr %result, align 8
  %_86 = zext i32 %radix to i64
; call <i64>::checked_mul
  %40 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs77bartfBdiX_11int_ops_i64(i64 %_85, i64 %_86) #17
  %41 = extractvalue { i64, i64 } %40, 0
  %42 = extractvalue { i64, i64 } %40, 1
  store i64 %41, ptr %mul1, align 8
  %43 = getelementptr inbounds i8, ptr %mul1, i64 8
  store i64 %42, ptr %43, align 8
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %44 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs77bartfBdiX_11int_ops_i64(i32 %_89, i32 %radix) #17
  %45 = extractvalue { i32, i32 } %44, 0
  %46 = extractvalue { i32, i32 } %44, 1
  store i32 %45, ptr %_88, align 4
  %47 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %46, ptr %47, align 4
  %48 = load i32, ptr %_88, align 4
  %49 = getelementptr inbounds i8, ptr %_88, i64 4
  %50 = load i32, ptr %49, align 4
  %_91 = zext i32 %48 to i64
  %51 = trunc nuw i64 %_91 to i1
  br i1 %51, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %52 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %52, align 4
  %x = zext i32 %value to i64
  %_95 = load i64, ptr %mul1, align 8
  %53 = getelementptr inbounds i8, ptr %mul1, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = trunc nuw i64 %_95 to i1
  br i1 %55, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %56 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %56, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb48:                                             ; preds = %bb46
  %57 = getelementptr inbounds i8, ptr %mul1, i64 8
  %value4 = load i64, ptr %57, align 8
  store i64 %value4, ptr %result, align 8
  %_100 = load i64, ptr %result, align 8
; call <i64>::checked_sub
  %58 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_subCs77bartfBdiX_11int_ops_i64(i64 %_100, i64 %x) #17
  %59 = extractvalue { i64, i64 } %58, 0
  %60 = extractvalue { i64, i64 } %58, 1
  store i64 %59, ptr %_99, align 8
  %61 = getelementptr inbounds i8, ptr %_99, i64 8
  store i64 %60, ptr %61, align 8
  %_101 = load i64, ptr %_99, align 8
  %62 = getelementptr inbounds i8, ptr %_99, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = trunc nuw i64 %_101 to i1
  br i1 %64, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %65 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %65, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb51:                                             ; preds = %bb48
  %66 = getelementptr inbounds i8, ptr %_99, i64 8
  %value5 = load i64, ptr %66, align 8
  store i64 %value5, ptr %result, align 8
  store ptr %rest.02, ptr %digits, align 8, !captures !151
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %67, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %68 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %68, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb31:                                             ; preds = %bb30
  %69 = load ptr, ptr %digits, align 8
  %70 = getelementptr inbounds i8, ptr %digits, i64 8
  %71 = load i64, ptr %70, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %69, i64 0
  %72 = load ptr, ptr %digits, align 8
  %73 = getelementptr inbounds i8, ptr %digits, i64 8
  %74 = load i64, ptr %73, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %72, i64 1
  %rest.18 = sub i64 %74, 1
  %_60 = load i64, ptr %result, align 8
  %_61 = zext i32 %radix to i64
; call <i64>::checked_mul
  %75 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_mulCs77bartfBdiX_11int_ops_i64(i64 %_60, i64 %_61) #17
  %76 = extractvalue { i64, i64 } %75, 0
  %77 = extractvalue { i64, i64 } %75, 1
  store i64 %76, ptr %mul, align 8
  %78 = getelementptr inbounds i8, ptr %mul, i64 8
  store i64 %77, ptr %78, align 8
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %79 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs77bartfBdiX_11int_ops_i64(i32 %_64, i32 %radix) #17
  %80 = extractvalue { i32, i32 } %79, 0
  %81 = extractvalue { i32, i32 } %79, 1
  store i32 %80, ptr %_63, align 4
  %82 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %81, ptr %82, align 4
  %83 = load i32, ptr %_63, align 4
  %84 = getelementptr inbounds i8, ptr %_63, i64 4
  %85 = load i32, ptr %84, align 4
  %_66 = zext i32 %83 to i64
  %86 = trunc nuw i64 %_66 to i1
  br i1 %86, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %87 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %87, align 4
  %x10 = zext i32 %value9 to i64
  %_70 = load i64, ptr %mul, align 8
  %88 = getelementptr inbounds i8, ptr %mul, i64 8
  %89 = load i64, ptr %88, align 8
  %90 = trunc nuw i64 %_70 to i1
  br i1 %90, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %91, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb37:                                             ; preds = %bb35
  %92 = getelementptr inbounds i8, ptr %mul, i64 8
  %value11 = load i64, ptr %92, align 8
  store i64 %value11, ptr %result, align 8
  %_75 = load i64, ptr %result, align 8
; call <i64>::checked_add
  %93 = call { i64, i64 } @_RNvMs1_NtCsl10jNU3mE6R_4core3numx11checked_addCs77bartfBdiX_11int_ops_i64(i64 %_75, i64 %x10) #17
  %94 = extractvalue { i64, i64 } %93, 0
  %95 = extractvalue { i64, i64 } %93, 1
  store i64 %94, ptr %_74, align 8
  %96 = getelementptr inbounds i8, ptr %_74, i64 8
  store i64 %95, ptr %96, align 8
  %_76 = load i64, ptr %_74, align 8
  %97 = getelementptr inbounds i8, ptr %_74, i64 8
  %98 = load i64, ptr %97, align 8
  %99 = trunc nuw i64 %_76 to i1
  br i1 %99, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %100 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %100, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb40:                                             ; preds = %bb37
  %101 = getelementptr inbounds i8, ptr %_74, i64 8
  %value12 = load i64, ptr %101, align 8
  store i64 %value12, ptr %result, align 8
  store ptr %rest.07, ptr %digits, align 8, !captures !151
  %102 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %102, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %103 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %103, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %104 = load ptr, ptr %digits, align 8
  %105 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %105, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %106 = load ptr, ptr %digits, align 8
  %107 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %107, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %108 = load ptr, ptr %digits, align 8
  %109 = getelementptr inbounds i8, ptr %digits, i64 8
  %110 = load i64, ptr %109, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %108, i64 0
  %111 = load ptr, ptr %digits, align 8
  %112 = getelementptr inbounds i8, ptr %digits, i64 8
  %113 = load i64, ptr %112, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %111, i64 1
  %rest.115 = sub i64 %113, 1
  %_44 = load i64, ptr %result, align 8
  %_45 = zext i32 %radix to i64
  %114 = mul i64 %_44, %_45
  store i64 %114, ptr %result, align 8
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %115 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs77bartfBdiX_11int_ops_i64(i32 %_47, i32 %radix) #17
  %116 = extractvalue { i32, i32 } %115, 0
  %117 = extractvalue { i32, i32 } %115, 1
  store i32 %116, ptr %_46, align 4
  %118 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %117, ptr %118, align 4
  %119 = load i32, ptr %_46, align 4
  %120 = getelementptr inbounds i8, ptr %_46, i64 4
  %121 = load i32, ptr %120, align 4
  %_49 = zext i32 %119 to i64
  %122 = trunc nuw i64 %_49 to i1
  br i1 %122, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %123 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %123, align 4
  %_53 = load i64, ptr %result, align 8
  %_54 = zext i32 %x16 to i64
  %124 = sub i64 %_53, %_54
  store i64 %124, ptr %result, align 8
  store ptr %rest.014, ptr %digits, align 8, !captures !151
  %125 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %125, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %126 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %126, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb19:                                             ; preds = %bb18
  %127 = load ptr, ptr %digits, align 8
  %128 = getelementptr inbounds i8, ptr %digits, i64 8
  %129 = load i64, ptr %128, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %127, i64 0
  %130 = load ptr, ptr %digits, align 8
  %131 = getelementptr inbounds i8, ptr %digits, i64 8
  %132 = load i64, ptr %131, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %130, i64 1
  %rest.119 = sub i64 %132, 1
  %_29 = load i64, ptr %result, align 8
  %_30 = zext i32 %radix to i64
  %133 = mul i64 %_29, %_30
  store i64 %133, ptr %result, align 8
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %134 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs77bartfBdiX_11int_ops_i64(i32 %_32, i32 %radix) #17
  %135 = extractvalue { i32, i32 } %134, 0
  %136 = extractvalue { i32, i32 } %134, 1
  store i32 %135, ptr %_31, align 4
  %137 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %136, ptr %137, align 4
  %138 = load i32, ptr %_31, align 4
  %139 = getelementptr inbounds i8, ptr %_31, i64 4
  %140 = load i32, ptr %139, align 4
  %_34 = zext i32 %138 to i64
  %141 = trunc nuw i64 %_34 to i1
  br i1 %141, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %142 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %142, align 4
  %_38 = load i64, ptr %result, align 8
  %_39 = zext i32 %x20 to i64
  %143 = add i64 %_38, %_39
  store i64 %143, ptr %result, align 8
  store ptr %rest.018, ptr %digits, align 8, !captures !151
  %144 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %144, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %145 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %145, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCs77bartfBdiX_11int_ops_i64(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !152 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCs77bartfBdiX_11int_ops_i64(ptr align 8 %args) #17
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #17
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCs77bartfBdiX_11int_ops_i64() unnamed_addr #4 !guid !153 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() unnamed_addr #0 !guid !154 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs77bartfBdiX_11int_ops_i64(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !155 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs77bartfBdiX_11int_ops_i64(i32 %code, ptr %dst) unnamed_addr #0 !guid !156 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs77bartfBdiX_11int_ops_i64(i32 %code) #17
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs77bartfBdiX_11int_ops_i64(i32 %code) unnamed_addr #0 !guid !157 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::num::imp::int_sqrt::u16_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCs77bartfBdiX_11int_ops_i64(i16 %n) unnamed_addr #0 !guid !158 {
start:
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n1 = lshr i16 %n, 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.80d8b92db779f2033b21acf97d35048d.0, i64 512, i1 false)
  %_9 = zext i16 %n1 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s2 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s2, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_12, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb1, %bb2.i
  %lo = and i16 %n, 255
  %_16 = zext i8 %r to i16
  %_15 = shl i16 %_16, 4
  %_17 = lshr i16 %lo, 4
  %numerator = or i16 %_15, %_17
  %_19 = zext i8 %s2 to i16
  %denominator = shl i16 %_19, 1
  %_21 = icmp eq i16 %denominator, 0
  br i1 %_21, label %panic3, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q = udiv i16 %numerator, %denominator
  %_24 = shl i8 %s2, 4
  %_23 = zext i8 %_24 to i16
  %3 = add i16 %_23, %q
  store i16 %3, ptr %s, align 2
  %_28 = load i16, ptr %s, align 2
  %_29 = load i16, ptr %s, align 2
  %4 = call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %_28, i16 %_29)
  %_5.0.i = extractvalue { i16, i1 } %4, 0
  %_5.1.i = extractvalue { i16, i1 } %4, 1
  %_27.0 = extractvalue { i16, i1 } %4, 0
  %_27.1 = extractvalue { i16, i1 } %4, 1
  br i1 %_27.1, label %bb6, label %bb5

panic3:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_73a63def61abd19c5b285b7e5bba6f74) #23
  unreachable

bb5:                                              ; preds = %bb3
  %_30 = icmp ugt i16 %_27.0, %n
  br i1 %_30, label %bb6, label %bb7

bb6:                                              ; preds = %bb5, %bb3
  %5 = load i16, ptr %s, align 2
  %6 = sub i16 %5, 1
  store i16 %6, ptr %s, align 2
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5
  %_0 = load i16, ptr %s, align 2
  ret i16 %_0
}

; core::num::imp::int_sqrt::u32_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCs77bartfBdiX_11int_ops_i64(i32 %n) unnamed_addr #0 !guid !159 {
start:
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n2 = lshr i32 %n, 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.80d8b92db779f2033b21acf97d35048d.0, i64 512, i1 false)
  %_9 = zext i32 %n2 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s3 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r4 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s3, 0
; call core::ub_checks::check_language_ub
  %_2.i15 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i15, label %bb2.i16, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

bb2.i16:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_12, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17: ; preds = %bb1, %bb2.i16
  %_17 = lshr i32 %n, 16
  %n5 = trunc i32 %_17 to i16
  %lo = and i16 %n5, 255
  %_21 = zext i8 %r4 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s3 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic6, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic7, label %bb4

panic6:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s3, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic7:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_45, ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb8, %bb2.i
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %lo8 = and i32 %n, 65535
  %_52 = zext i16 %_48 to i32
  %_51 = shl i32 %_52, 8
  %_53 = lshr i32 %lo8, 8
  %numerator9 = or i32 %_51, %_53
  %_55 = zext i16 %_47 to i32
  %denominator10 = shl i32 %_55, 1
  %_57 = icmp eq i32 %denominator10, 0
  br i1 %_57, label %panic11, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q12 = udiv i32 %numerator9, %denominator10
  %_60 = shl i16 %_47, 8
  %_59 = zext i16 %_60 to i32
  %8 = add i32 %_59, %q12
  store i32 %8, ptr %s1, align 4
  %_64 = load i32, ptr %s1, align 4
  %_65 = load i32, ptr %s1, align 4
  %9 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_64, i32 %_65)
  %_5.0.i13 = extractvalue { i32, i1 } %9, 0
  %_5.1.i14 = extractvalue { i32, i1 } %9, 1
  %_63.0 = extractvalue { i32, i1 } %9, 0
  %_63.1 = extractvalue { i32, i1 } %9, 1
  br i1 %_63.1, label %bb13, label %bb12

panic11:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_d1e64d3a180065bd6a022925cad00717) #23
  unreachable

bb12:                                             ; preds = %bb10
  %_66 = icmp ugt i32 %_63.0, %n
  br i1 %_66, label %bb13, label %bb14

bb13:                                             ; preds = %bb12, %bb10
  %10 = load i32, ptr %s1, align 4
  %11 = sub i32 %10, 1
  store i32 %11, ptr %s1, align 4
  br label %bb14

bb14:                                             ; preds = %bb13, %bb12
  %_0 = load i32, ptr %s1, align 4
  ret i32 %_0
}

; core::num::imp::int_sqrt::u64_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCs77bartfBdiX_11int_ops_i64(i64 %n) unnamed_addr #0 !guid !160 {
start:
  %s3 = alloca [8 x i8], align 8
  %r2 = alloca [4 x i8], align 4
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n4 = lshr i64 %n, 56
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.80d8b92db779f2033b21acf97d35048d.0, i64 512, i1 false)
  %_10 = icmp ult i64 %n4, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %s5 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r6 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s5, 0
; call core::ub_checks::check_language_ub
  %_2.i31 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i31, label %bb2.i32, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

bb2.i32:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_12, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33: ; preds = %bb1, %bb2.i32
  %_17 = lshr i64 %n, 48
  %n7 = trunc i64 %_17 to i16
  %lo = and i16 %n7, 255
  %_21 = zext i8 %r6 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s5 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic8, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %n4, i64 256, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic9, label %bb4

panic8:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s5, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic9:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i28 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i28, label %bb2.i29, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

bb2.i29:                                          ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_45, ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30: ; preds = %bb8, %bb2.i29
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %_53 = lshr i64 %n, 32
  %n10 = trunc i64 %_53 to i32
  %lo11 = and i32 %n10, 65535
  %_57 = zext i16 %_48 to i32
  %_56 = shl i32 %_57, 8
  %_58 = lshr i32 %lo11, 8
  %numerator12 = or i32 %_56, %_58
  %_60 = zext i16 %_47 to i32
  %denominator13 = shl i32 %_60, 1
  %_62 = icmp eq i32 %denominator13, 0
  br i1 %_62, label %panic14, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
  %q15 = udiv i32 %numerator12, %denominator13
  %_64 = icmp eq i32 %denominator13, 0
  br i1 %_64, label %panic16, label %bb11

panic14:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #23
  unreachable

bb11:                                             ; preds = %bb10
  %u17 = urem i32 %numerator12, %denominator13
  %_67 = shl i16 %_47, 8
  %_66 = zext i16 %_67 to i32
  %8 = add i32 %_66, %q15
  store i32 %8, ptr %s1, align 4
  %_72 = shl i32 %u17, 8
  %_73 = and i32 %lo11, 255
  %_71 = or i32 %_72, %_73
  %_74 = mul i32 %q15, %q15
  %_5.0.i24 = sub i32 %_71, %_74
  %_5.1.i25 = icmp ult i32 %_71, %_74
  %9 = insertvalue { i32, i1 } poison, i32 %_5.0.i24, 0
  %10 = insertvalue { i32, i1 } %9, i1 %_5.1.i25, 1
  %_70.0 = extractvalue { i32, i1 } %10, 0
  %_70.1 = extractvalue { i32, i1 } %10, 1
  store i32 %_70.0, ptr %r2, align 4
  br i1 %_70.1, label %bb13, label %bb15

panic16:                                          ; preds = %bb10
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #23
  unreachable

bb15:                                             ; preds = %bb13, %bb11
  %_82 = load i32, ptr %s1, align 4
  %_81 = icmp ne i32 %_82, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs77bartfBdiX_11int_ops_i64() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb15
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %_81, ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb15, %bb2.i
  %_83 = load i32, ptr %s1, align 4
  %_84 = load i32, ptr %r2, align 4
  %lo18 = and i64 %n, 4294967295
  %_88 = zext i32 %_84 to i64
  %_87 = shl i64 %_88, 16
  %_89 = lshr i64 %lo18, 16
  %numerator19 = or i64 %_87, %_89
  %_91 = zext i32 %_83 to i64
  %denominator20 = shl i64 %_91, 1
  %_93 = icmp eq i64 %denominator20, 0
  br i1 %_93, label %panic21, label %bb17

bb13:                                             ; preds = %bb11
  %_76 = load i32, ptr %r2, align 4
  %_79 = load i32, ptr %s1, align 4
  %_78 = mul i32 2, %_79
  %_77 = sub i32 %_78, 1
  %_0.i23 = add i32 %_76, %_77
  store i32 %_0.i23, ptr %r2, align 4
  %11 = load i32, ptr %s1, align 4
  %12 = sub i32 %11, 1
  store i32 %12, ptr %s1, align 4
  br label %bb15

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q22 = udiv i64 %numerator19, %denominator20
  %_96 = shl i32 %_83, 16
  %_95 = zext i32 %_96 to i64
  %13 = add i64 %_95, %q22
  store i64 %13, ptr %s3, align 8
  %_100 = load i64, ptr %s3, align 8
  %_101 = load i64, ptr %s3, align 8
  %14 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_100, i64 %_101)
  %_5.0.i26 = extractvalue { i64, i1 } %14, 0
  %_5.1.i27 = extractvalue { i64, i1 } %14, 1
  %_99.0 = extractvalue { i64, i1 } %14, 0
  %_99.1 = extractvalue { i64, i1 } %14, 1
  br i1 %_99.1, label %bb20, label %bb19

panic21:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cb646754bd05cd238e749888201337e6) #23
  unreachable

bb19:                                             ; preds = %bb17
  %_102 = icmp ugt i64 %_99.0, %n
  br i1 %_102, label %bb20, label %bb21

bb20:                                             ; preds = %bb19, %bb17
  %15 = load i64, ptr %s3, align 8
  %16 = sub i64 %15, 1
  store i64 %16, ptr %s3, align 8
  br label %bb21

bb21:                                             ; preds = %bb20, %bb19
  %_0 = load i64, ptr %s3, align 8
  ret i64 %_0
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8Cs77bartfBdiX_11int_ops_i64(i8 %n) unnamed_addr #0 !guid !161 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.80d8b92db779f2033b21acf97d35048d.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #23
  unreachable
}

; core::num::imp::int_sqrt::u16
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16Cs77bartfBdiX_11int_ops_i64(i16 %0) unnamed_addr #0 !guid !162 {
start:
  %_0 = alloca [2 x i8], align 2
  %n = alloca [2 x i8], align 2
  store i16 %0, ptr %n, align 2
  %_3 = load i16, ptr %n, align 2
  %_2 = icmp ule i16 %_3, 255
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i16, ptr %n, align 2
  %1 = call i16 @llvm.ctlz.i16(i16 %_10, i1 false)
  %_0.i = zext i16 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i16, ptr %n, align 2
  %3 = and i32 %normalization_shift, 15
  %4 = trunc i32 %3 to i16
  %5 = shl i16 %2, %4
  store i16 %5, ptr %n, align 2
  %_12 = load i16, ptr %n, align 2
; call core::num::imp::int_sqrt::u16_stages
  %s = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCs77bartfBdiX_11int_ops_i64(i16 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 15
  %7 = trunc i32 %6 to i16
  %8 = lshr i16 %s, %7
  store i16 %8, ptr %_0, align 2
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i16, ptr %n, align 2
  %_6 = trunc i16 %_7 to i8
; call core::num::imp::int_sqrt::u8
  %_5 = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8Cs77bartfBdiX_11int_ops_i64(i8 %_6) #17
  %9 = zext i8 %_5 to i16
  store i16 %9, ptr %_0, align 2
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i16, ptr %_0, align 2
  ret i16 %10
}

; core::num::imp::int_sqrt::u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32Cs77bartfBdiX_11int_ops_i64(i32 %0) unnamed_addr #0 !guid !163 {
start:
  %_0 = alloca [4 x i8], align 4
  %n = alloca [4 x i8], align 4
  store i32 %0, ptr %n, align 4
  %_3 = load i32, ptr %n, align 4
  %_2 = icmp ule i32 %_3, 65535
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i32, ptr %n, align 4
  %_0.i = call i32 @llvm.ctlz.i32(i32 %_10, i1 false)
  %normalization_shift = and i32 %_0.i, -2
  %1 = load i32, ptr %n, align 4
  %2 = and i32 %normalization_shift, 31
  %3 = shl i32 %1, %2
  store i32 %3, ptr %n, align 4
  %_12 = load i32, ptr %n, align 4
; call core::num::imp::int_sqrt::u32_stages
  %s = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCs77bartfBdiX_11int_ops_i64(i32 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %4 = and i32 %denormalization_shift, 31
  %5 = lshr i32 %s, %4
  store i32 %5, ptr %_0, align 4
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i32, ptr %n, align 4
  %_6 = trunc i32 %_7 to i16
; call core::num::imp::int_sqrt::u16
  %_5 = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16Cs77bartfBdiX_11int_ops_i64(i16 %_6) #17
  %6 = zext i16 %_5 to i32
  store i32 %6, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %7 = load i32, ptr %_0, align 4
  ret i32 %7
}

; core::num::imp::int_sqrt::u64
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64Cs77bartfBdiX_11int_ops_i64(i64 %0) unnamed_addr #0 !guid !164 {
start:
  %_0 = alloca [8 x i8], align 8
  %n = alloca [8 x i8], align 8
  store i64 %0, ptr %n, align 8
  %_3 = load i64, ptr %n, align 8
  %_2 = icmp ule i64 %_3, 4294967295
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i64, ptr %n, align 8
  %1 = call i64 @llvm.ctlz.i64(i64 %_10, i1 false)
  %_0.i = trunc i64 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i64, ptr %n, align 8
  %3 = and i32 %normalization_shift, 63
  %4 = zext i32 %3 to i64
  %5 = shl i64 %2, %4
  store i64 %5, ptr %n, align 8
  %_12 = load i64, ptr %n, align 8
; call core::num::imp::int_sqrt::u64_stages
  %s = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCs77bartfBdiX_11int_ops_i64(i64 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 63
  %7 = zext i32 %6 to i64
  %8 = lshr i64 %s, %7
  store i64 %8, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %n, align 8
  %_6 = trunc i64 %_7 to i32
; call core::num::imp::int_sqrt::u32
  %_5 = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32Cs77bartfBdiX_11int_ops_i64(i32 %_6) #17
  %9 = zext i32 %_5 to i64
  store i64 %9, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i64, ptr %_0, align 8
  ret i64 %10
}

; <i64>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shl18precondition_checkCs77bartfBdiX_11int_ops_i64(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !165 {
start:
  %_2 = icmp ult i32 %rhs, 64
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs77bartfBdiX_11int_ops_i64(ptr @alloc_b8612ffe3ceba24ef9f5ec716441ab42, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <i64>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtCsl10jNU3mE6R_4core3numx13unchecked_shr18precondition_checkCs77bartfBdiX_11int_ops_i64(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !166 {
start:
  %_2 = icmp ult i32 %rhs, 64
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs77bartfBdiX_11int_ops_i64(ptr @alloc_e284038bdc5c065a225db887d5238d07, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <u64>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul18precondition_checkCs77bartfBdiX_11int_ops_i64(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !167 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs77bartfBdiX_11int_ops_i64(ptr @alloc_c856595eac66a24654d670eae8c59bb6, i64 184)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs77bartfBdiX_11int_ops_i64(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !168 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs77bartfBdiX_11int_ops_i64(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs77bartfBdiX_11int_ops_i64() unnamed_addr #0 !guid !169 {
start:
  ret i1 true
}

; <(i64, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTxbENtB6_5Debug3fmtCs77bartfBdiX_11int_ops_i64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !170 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <i64 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1M_NtCs7CppTae75M1_5alloc6stringxNtB6_12SpecToString14spec_to_stringCs77bartfBdiX_11int_ops_i64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !171 {
start:
  %0 = alloca [16 x i8], align 8
  %_19 = alloca [1 x i8], align 1
  %_11 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  %out = alloca [24 x i8], align 8
  %buf = alloca [19 x i8], align 1
  store i8 0, ptr %_19, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 19, i1 false)
  %_6 = load i64, ptr %self, align 8
  %_5 = icmp slt i64 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCs77bartfBdiX_11int_ops_i64(ptr sret([24 x i8]) align 8 %_11, i64 19)
          to label %bb5 unwind label %cleanup

bb2:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCs77bartfBdiX_11int_ops_i64(ptr sret([24 x i8]) align 8 %_7, i64 20)
          to label %bb3 unwind label %cleanup

bb12:                                             ; preds = %cleanup
  %1 = load i8, ptr %_19, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb11, label %bb10

cleanup:                                          ; preds = %bb8, %bb7, %bb6, %bb3, %bb2, %bb4
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb12

bb5:                                              ; preds = %bb4
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_11, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb13, %bb5
  %_16 = load i64, ptr %self, align 8
; invoke <i64>::unsigned_abs
  %_15 = invoke i64 @_RNvMs1_NtCsl10jNU3mE6R_4core3numx12unsigned_absCs77bartfBdiX_11int_ops_i64(i64 %_16)
          to label %bb7 unwind label %cleanup

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_7, i64 24, i1 false)
; invoke <alloc::string::String>::push
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs77bartfBdiX_11int_ops_i64(ptr align 8 %out, i32 45)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb3
  br label %bb6

bb7:                                              ; preds = %bb6
; invoke <u64>::_fmt
  %7 = invoke { ptr, i64 } @_RNvMsf_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impy4__fmt(i64 %_15, ptr %buf, i64 19)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %_14.0 = extractvalue { ptr, i64 } %7, 0
  %_14.1 = extractvalue { ptr, i64 } %7, 1
; invoke <alloc::string::String>::push_str
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCs77bartfBdiX_11int_ops_i64(ptr align 8 %out, ptr %_14.0, i64 %_14.1)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %out, i64 24, i1 false)
  store i8 0, ptr %_19, align 1
  ret void

bb10:                                             ; preds = %bb11, %bb12
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb11:                                             ; preds = %bb12
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %out) #24
          to label %bb10 unwind label %terminate

terminate:                                        ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCs77bartfBdiX_11int_ops_i64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !172 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs77bartfBdiX_11int_ops_i64(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs77bartfBdiX_11int_ops_i64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !173 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs77bartfBdiX_11int_ops_i64(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <i64 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringxNtB5_8ToString9to_stringCs77bartfBdiX_11int_ops_i64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !174 {
start:
; call <i64 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1M_NtCs7CppTae75M1_5alloc6stringxNtB6_12SpecToString14spec_to_stringCs77bartfBdiX_11int_ops_i64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #17
  ret void
}

; <core::option::Option<i64> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionxENtNtB7_3fmt5Debug3fmtCs77bartfBdiX_11int_ops_i64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !175 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %_3 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.1)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs77bartfBdiX_11int_ops_i64() unnamed_addr #0 !guid !176 {
start:
  ret i8 0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs77bartfBdiX_11int_ops_i64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !177 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs77bartfBdiX_11int_ops_i64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !178 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <i64 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core3numxNtNtNtB7_3str6traits7FromStr8from_strCs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !179 {
start:
; call <i64>::from_str_radix
  call void @_RNvMsr_NtCsl10jNU3mE6R_4core3numx14from_str_radixCs77bartfBdiX_11int_ops_i64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 10) #17
  ret void
}

; <core::result::Result<i64, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultxNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs77bartfBdiX_11int_ops_i64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !180 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs77bartfBdiX_11int_ops_i64(ptr %_1) unnamed_addr #0 !guid !181 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs77bartfBdiX_11int_ops_i64(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !182 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs77bartfBdiX_11int_ops_i64(ptr align 8 %_1) #17
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i64 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsz_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_6Binary3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsD_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_8LowerHex3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsF_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_8UpperHex3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsB_NtNtCsl10jNU3mE6R_4core3fmt3numxNtB7_5Octal3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fshr.i64(i64, i64, i64) #9

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptosi.sat.i64.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <alloc::vec::Vec<u8>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8, i64) unnamed_addr #1

; <alloc::vec::Vec<u8>>::extend_from_slice
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8, ptr, i64) unnamed_addr #1

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; <core::num::nonzero::NonZero<u64>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3getB9_(i64) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #10

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #11

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i64(i64) #12

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.sadd.sat.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ssub.sat.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64) #9

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #11

; core::num::imp::int_sqrt::panic_for_negative_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8) unnamed_addr #11

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctlz.i16(i16, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.umul.with.overflow.i16(i16, i16) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #9

; core::intrinsics::rotate_left::<u64>
; Function Attrs: nounwind nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64, i32) unnamed_addr #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bitreverse.i64(i64) #9

; <core::num::nonzero::NonZero<u64>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3newB9_(i64) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.cttz.i64(i64, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #9

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #13

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #14

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <&i64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRxNtB6_5Debug3fmtCs2d0hS33vDhg_5gimli(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #15

; <u64>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMsf_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impy4__fmt(i64, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #16 !guid !183 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs77bartfBdiX_11int_ops_i64(ptr @_RNvCs77bartfBdiX_11int_ops_i644main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #13 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #16 = { nonlazybind "target-cpu"="x86-64" }
attributes #17 = { inlinehint }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noreturn }
attributes #20 = { noinline }
attributes #21 = { nounwind }
attributes #22 = { inlinehint nounwind }
attributes #23 = { noinline noreturn }
attributes #24 = { cold }
attributes #25 = { noinline noreturn nounwind }

!llvm.module.flags = !{!63, !64, !65, !66}
!llvm.ident = !{!67}

!0 = !{i64 604135669620496924}
!1 = !{i64 -3908300891803157308}
!2 = !{i64 -1894061959751136324}
!3 = !{i64 -4936510782505229660}
!4 = !{i64 2245012620836380826}
!5 = !{i64 -1890053646347758271}
!6 = !{i64 1224376426605523187}
!7 = !{i64 -5622934188825475120}
!8 = !{i64 -5267166850173607543}
!9 = !{i64 -2185362986311628811}
!10 = !{i64 3287368308247201329}
!11 = !{i64 7630230200554800281}
!12 = !{i64 -3512550400842497346}
!13 = !{i64 -1012207111042144892}
!14 = !{i64 -1457163432698793387}
!15 = !{i64 -7661313375032499885}
!16 = !{i64 6063252949737506505}
!17 = !{i64 2360068969176996912}
!18 = !{i64 8797456677150002155}
!19 = !{i64 6982446180164563970}
!20 = !{i64 8563324332945972913}
!21 = !{i64 -905120020179771028}
!22 = !{i64 4986898903616746425}
!23 = !{i64 -6368798500191774272}
!24 = !{i64 -236230123263997739}
!25 = !{i64 4486300253859858474}
!26 = !{i64 -5539034684895825848}
!27 = !{i64 -6541923333665337510}
!28 = !{i64 -4795066184270340007}
!29 = !{i64 1148973772348303667}
!30 = !{i64 -2159133080308601606}
!31 = !{i64 5045311279908406887}
!32 = !{i64 -3785865455159001183}
!33 = !{i64 -2334133108316262242}
!34 = !{i64 -2277564839331259607}
!35 = !{i64 4789329743480081770}
!36 = !{i64 -1693421044013867919}
!37 = !{i64 -8431386063015458937}
!38 = !{i64 3626553500396301962}
!39 = !{i64 1282897166440680058}
!40 = !{i64 -897375124141033147}
!41 = !{i64 -8966055855726694043}
!42 = !{i64 -9207226392481971016}
!43 = !{i64 -3224170095736515839}
!44 = !{i64 4596208283936812839}
!45 = !{i64 -3438060922615185946}
!46 = !{i64 -1941286359248153475}
!47 = !{i64 5559130229851607092}
!48 = !{i64 -5030168237989011492}
!49 = !{i64 -4908104986746848948}
!50 = !{i64 -1784752299423554581}
!51 = !{i64 -6138451191032200782}
!52 = !{i64 -1507998461025383728}
!53 = !{i64 -5492631039773591558}
!54 = !{i64 -3492059562480849241}
!55 = !{i64 5450036045073444728}
!56 = !{i64 1019512485058611201}
!57 = !{i64 1405787148396005430}
!58 = !{i64 26096940364786206}
!59 = !{i64 4124171977836536137}
!60 = !{i64 -6510125227369274667}
!61 = !{i64 6245215112343185331}
!62 = !{i64 6459650912474036150}
!63 = !{i32 8, !"PIC Level", i32 2}
!64 = !{i32 7, !"PIE Level", i32 2}
!65 = !{i32 2, !"RtLibUseGOT", i32 1}
!66 = !{i32 7, !"uwtable", i32 2}
!67 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!68 = !{i64 -7638714421858575429}
!69 = !{i64 -1086374184161639881}
!70 = !{i64 5211672736697350750}
!71 = !{i64 -6795256932126538183}
!72 = !{i64 1797606084338459094}
!73 = !{i64 -1257893396928435381}
!74 = !{i64 -4157120605129594578}
!75 = !{i64 195683428489966963}
!76 = !{i64 -4104128551508078120}
!77 = !{i64 2627258808566849429}
!78 = !{i64 2261667127710834510}
!79 = !{i64 6014510331078472823}
!80 = !{i64 -30404531960949712}
!81 = !{i64 -6145984270333380160}
!82 = !{i64 1289692276998454409}
!83 = !{i64 8798161926523613378}
!84 = !{i64 -3454035156822556999}
!85 = !{i64 -7531630038294062935}
!86 = !{i64 -5822699487242028732}
!87 = !{i64 -7691780232362133456}
!88 = !{i64 1002806816225129141}
!89 = !{i64 6196494158037256538}
!90 = !{i64 429008229104459940}
!91 = !{i64 -3815481202654024139}
!92 = !{i64 -5573810265489018181}
!93 = !{i64 -6091536634610910206}
!94 = !{i64 -1072474226785307506}
!95 = !{i64 1318421816192758}
!96 = !{i64 8620431982704036762}
!97 = !{i64 -2892365985051812567}
!98 = !{i64 -6730957368843824768}
!99 = !{i64 4043517035649056949}
!100 = !{i64 -3073930334915959597}
!101 = !{i64 -2869279907981035441}
!102 = !{i64 8001478034380992057}
!103 = !{i64 -6902050865183822101}
!104 = !{i64 5218660326495420525}
!105 = !{i64 6939801307939046411}
!106 = !{i64 6099256345811334720}
!107 = !{i64 6626237464692548289}
!108 = !{i64 -4057974187579476982}
!109 = !{i64 -2647455013855127702}
!110 = !{i64 8934651928392993090}
!111 = !{i64 -4088204354077091014}
!112 = !{i64 -5967855176487779150}
!113 = !{i64 -7024695094799258825}
!114 = !{i64 -8244386349983112628}
!115 = !{i64 -7207144926613352076}
!116 = !{i64 -3085311053358407180}
!117 = !{i64 4783063744719874723}
!118 = !{i64 9185680840601380368}
!119 = !{i64 2107706471011364395}
!120 = !{i64 8998836905882667693}
!121 = !{i64 -397114156667376400}
!122 = !{i64 -7910203061742839605}
!123 = !{i64 4047696761916383648}
!124 = !{i64 4444031071606865569}
!125 = !{i64 -4573634333811264173}
!126 = !{i64 148171135024559689}
!127 = !{i64 -8156186643484798354}
!128 = !{i64 -4717591352750775960}
!129 = !{i64 2427815730767554860}
!130 = !{i64 -5123131797848955460}
!131 = !{i64 -1921099422561091145}
!132 = !{i64 6301306165867863300}
!133 = !{i64 5269535441466457102}
!134 = !{i64 -443867263697636329}
!135 = !{i64 379768344478480801}
!136 = !{i64 3978437955339509989}
!137 = !{i64 7503316604979099980}
!138 = !{i64 8360316670167293404}
!139 = !{i64 -2626129929621122283}
!140 = !{i64 -681898589144765712}
!141 = !{i64 -9098675432809407244}
!142 = !{i64 -6830392966708497860}
!143 = !{i64 1649892993457933788}
!144 = !{i64 -2533406326778015260}
!145 = !{i64 397643097890774130}
!146 = !{i64 4812629372094301198}
!147 = !{i64 -7581740743951744111}
!148 = !{i64 7347758417523282792}
!149 = !{i64 -4987716897114020078}
!150 = !{i64 3081672424729806556}
!151 = !{!"address", !"read_provenance"}
!152 = !{i64 -7829773709608981283}
!153 = !{i64 -7461853754075906117}
!154 = !{i64 -8719576311996930103}
!155 = !{i64 -8651416973128800683}
!156 = !{i64 341655012460898396}
!157 = !{i64 7703175817728054357}
!158 = !{i64 -6601932093821120383}
!159 = !{i64 -8108501325317560845}
!160 = !{i64 87464868853556094}
!161 = !{i64 -7390951051365628026}
!162 = !{i64 2319473955783170731}
!163 = !{i64 -4533193249844385895}
!164 = !{i64 4483944201297371862}
!165 = !{i64 8644676765356418159}
!166 = !{i64 4391315876048774952}
!167 = !{i64 7238335336380212831}
!168 = !{i64 3887643125623289075}
!169 = !{i64 -380531774402187863}
!170 = !{i64 5853168138135254020}
!171 = !{i64 4214958260945045127}
!172 = !{i64 8344504788585640585}
!173 = !{i64 -1585131563395941568}
!174 = !{i64 -2040784292681537232}
!175 = !{i64 -5272726136221187746}
!176 = !{i64 -3653666569584072934}
!177 = !{i64 -3147963035895790370}
!178 = !{i64 -2631509215894652094}
!179 = !{i64 -8326727595446296892}
!180 = !{i64 -2606273478392370877}
!181 = !{i64 -1397533962852406266}
!182 = !{i64 -5537369858447539336}
!183 = !{i64 -2624081020897602054}
