; ModuleID = 'panic_slice_copy.e6daf7f73c8cbbfd-cgu.0'
source_filename = "panic_slice_copy.e6daf7f73c8cbbfd-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsjOPVHhJRRR9_16panic_slice_copy, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsjOPVHhJRRR9_16panic_slice_copy, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsjOPVHhJRRR9_16panic_slice_copy }>, align 8, !guid !0
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !1
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !2
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !3
@alloc_d8f94199956596cd8cda5e8d34e0ee12 = private unnamed_addr constant [2 x i8] c"\01\02", align 1, !guid !4
@alloc_217d3bc84a5aad802b6333e29f059ab3 = private unnamed_addr constant [40 x i8] c"test/rust/synthetic/panic-slice-copy.rs\00", align 1, !guid !5
@alloc_dd6ba87ff6190882e793252c6c2e6648 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_217d3bc84a5aad802b6333e29f059ab3, [16 x i8] c"'\00\00\00\00\00\00\00\06\00\00\006\00\00\00" }>, align 8, !guid !6
@alloc_6c78800390cfcb49e16e07024e4d4b16 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_217d3bc84a5aad802b6333e29f059ab3, [16 x i8] c"'\00\00\00\00\00\00\00\06\00\00\00\1D\00\00\00" }>, align 8, !guid !7
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !8
@alloc_fad0cd83b7d1858a846a172eb260e593 = private unnamed_addr constant [42 x i8] c"is_aligned_to: align is not a power-of-two", align 1, !guid !9
@alloc_3a97cab01964e354cab63e4d72a95bbc = private unnamed_addr constant [26 x i8] c"core/src/ptr/const_ptr.rs\00", align 1, !guid !10
@alloc_7abc4ceda2d1d9be88f00c5dc522bc84 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3a97cab01964e354cab63e4d72a95bbc, [16 x i8] c"\19\00\00\00\00\00\00\00M\05\00\00\0D\00\00\00" }>, align 8, !guid !11
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !12
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !13

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsjOPVHhJRRR9_16panic_slice_copy(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !19 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECsjOPVHhJRRR9_16panic_slice_copy(i64 %dummy) unnamed_addr #1 !guid !20 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !21
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsjOPVHhJRRR9_16panic_slice_copy() unnamed_addr #1 !guid !22 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !21
  ret void
}

; core::slice::copy_from_slice_impl::<u8>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core5slice20copy_from_slice_implhECsjOPVHhJRRR9_16panic_slice_copy(ptr %dest.0, i64 %dest.1, ptr %src.0, i64 %src.1, ptr align 8 %0) unnamed_addr #0 !guid !23 {
start:
  %_3 = icmp ne i64 %dest.1, %src.1
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsjOPVHhJRRR9_16panic_slice_copy() #13
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECsjOPVHhJRRR9_16panic_slice_copy.exit

bb2.i:                                            ; preds = %bb2
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCsjOPVHhJRRR9_16panic_slice_copy(ptr %src.0, ptr %dest.0, i64 1, i64 1, i64 %dest.1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #14
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECsjOPVHhJRRR9_16panic_slice_copy.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECsjOPVHhJRRR9_16panic_slice_copy.exit: ; preds = %bb2, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %dest.0, ptr align 1 %src.0, i64 %dest.1, i1 false)
  ret void

bb1:                                              ; preds = %start
; call core::slice::copy_from_slice_impl::len_mismatch_fail
  call void @_RNvNvNtCsl10jNU3mE6R_4core5slice20copy_from_slice_impl17len_mismatch_fail(i64 %dest.1, i64 %src.1, ptr align 8 %0) #15
  unreachable
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsjOPVHhJRRR9_16panic_slice_copy(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !24 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsjOPVHhJRRR9_16panic_slice_copy(ptr %f) #13
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsjOPVHhJRRR9_16panic_slice_copy() #13
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsjOPVHhJRRR9_16panic_slice_copy(ptr align 8 %_1) unnamed_addr #1 !guid !25 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsjOPVHhJRRR9_16panic_slice_copy(ptr %_4) #16
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsjOPVHhJRRR9_16panic_slice_copy() #13
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsjOPVHhJRRR9_16panic_slice_copy(i8 %_2) #13
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsjOPVHhJRRR9_16panic_slice_copy(ptr %_1) unnamed_addr #1 !guid !26 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsjOPVHhJRRR9_16panic_slice_copy(ptr %0) #13
  ret i32 %_0
}

; panic_slice_copy::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsjOPVHhJRRR9_16panic_slice_copy4main() unnamed_addr #0 !guid !27 {
start:
  %a = alloca [3 x i8], align 1
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsjOPVHhJRRR9_16panic_slice_copy(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #13
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
  call void @llvm.memset.p0.i64(ptr align 1 %a, i8 0, i64 3, i1 false)
; call core::hint::black_box::<usize>
  %_10 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECsjOPVHhJRRR9_16panic_slice_copy(i64 2) #13
; call <[u8; 2] as core::ops::index::Index<core::ops::range::RangeTo<usize>>>::index
  %1 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAhj2_INtNtNtB7_3ops5index5IndexINtNtBG_5range7RangeTojEE5indexCsjOPVHhJRRR9_16panic_slice_copy(ptr @alloc_d8f94199956596cd8cda5e8d34e0ee12, i64 %_10, ptr align 8 @alloc_dd6ba87ff6190882e793252c6c2e6648) #13
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8]>::copy_from_slice
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSh15copy_from_sliceCsjOPVHhJRRR9_16panic_slice_copy(ptr %a, i64 3, ptr %_7.0, i64 %_7.1, ptr align 8 @alloc_6c78800390cfcb49e16e07024e4d4b16) #13
; call <core::fmt::Arguments>::from_str
  %2 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsjOPVHhJRRR9_16panic_slice_copy(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #13
  %_12.0 = extractvalue { ptr, ptr } %2, 0
  %_12.1 = extractvalue { ptr, ptr } %2, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_12.0, ptr %_12.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsjOPVHhJRRR9_16panic_slice_copy(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !28 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <[u8]>::copy_from_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSh15copy_from_sliceCsjOPVHhJRRR9_16panic_slice_copy(ptr %self.0, i64 %self.1, ptr %src.0, i64 %src.1, ptr align 8 %0) unnamed_addr #1 !guid !29 {
start:
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCsl10jNU3mE6R_4core5slice20copy_from_slice_implhECsjOPVHhJRRR9_16panic_slice_copy(ptr %self.0, i64 %self.1, ptr %src.0, i64 %src.1, ptr align 8 %0)
  ret void
}

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCsjOPVHhJRRR9_16panic_slice_copy(ptr %self, i64 %align) unnamed_addr #1 !guid !30 {
start:
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i1 = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i1, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsjOPVHhJRRR9_16panic_slice_copy(ptr @alloc_fad0cd83b7d1858a846a172eb260e593, i64 42) #13
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 @alloc_7abc4ceda2d1d9be88f00c5dc522bc84) #15
  unreachable

bb2:                                              ; preds = %start
  %_0.i = ptrtoint ptr %self to i64
  %_8 = sub i64 %align, 1
  %_6 = and i64 %_0.i, %_8
  %_0 = icmp eq i64 %_6, 0
  ret i1 %_0
}

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCsjOPVHhJRRR9_16panic_slice_copy(ptr %self) unnamed_addr #1 !guid !31 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCsjOPVHhJRRR9_16panic_slice_copy(ptr %self) #13
  ret i1 %_0
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsjOPVHhJRRR9_16panic_slice_copy(i32 %self) unnamed_addr #1 !guid !32 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsjOPVHhJRRR9_16panic_slice_copy(i32 %self) #13
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsjOPVHhJRRR9_16panic_slice_copy(i32 %self) unnamed_addr #1 !guid !33 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsjOPVHhJRRR9_16panic_slice_copy(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !34 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsjOPVHhJRRR9_16panic_slice_copy(ptr %s.0, i64 %s.1) #13
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsjOPVHhJRRR9_16panic_slice_copy(ptr %self) unnamed_addr #1 !guid !35 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCsjOPVHhJRRR9_16panic_slice_copy(i64 %self, i64 %rhs) unnamed_addr #1 !guid !36 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCsjOPVHhJRRR9_16panic_slice_copy(i64 %self, i64 %rhs) unnamed_addr #1 !guid !37 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCsjOPVHhJRRR9_16panic_slice_copy(i64 %self, i64 %other) unnamed_addr #1 !guid !38 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsjOPVHhJRRR9_16panic_slice_copy(i32 %_0.i) #13
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsjOPVHhJRRR9_16panic_slice_copy(i8 %0) unnamed_addr #1 !guid !39 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsjOPVHhJRRR9_16panic_slice_copy(ptr %self) #13
  ret i32 %_0
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsjOPVHhJRRR9_16panic_slice_copy() unnamed_addr #3 !guid !40 {
start:
  ret void
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCsjOPVHhJRRR9_16panic_slice_copy(ptr %ptr, i64 %align) unnamed_addr #1 !guid !41 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCsjOPVHhJRRR9_16panic_slice_copy(ptr %ptr, i64 %align) #13
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsjOPVHhJRRR9_16panic_slice_copy() unnamed_addr #1 !guid !42 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsjOPVHhJRRR9_16panic_slice_copy() #13
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCsjOPVHhJRRR9_16panic_slice_copy(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #1 !guid !43 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCsjOPVHhJRRR9_16panic_slice_copy(ptr %3, ptr %5, i64 %7, i64 %9) #13
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsjOPVHhJRRR9_16panic_slice_copy(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #1 !guid !44 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCsjOPVHhJRRR9_16panic_slice_copy(ptr %ptr, i64 %align) #13
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCsjOPVHhJRRR9_16panic_slice_copy(ptr %ptr) #13
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCsjOPVHhJRRR9_16panic_slice_copy(ptr %ptr) unnamed_addr #1 !guid !45 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCsjOPVHhJRRR9_16panic_slice_copy(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !46 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsjOPVHhJRRR9_16panic_slice_copy(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsjOPVHhJRRR9_16panic_slice_copy(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCsjOPVHhJRRR9_16panic_slice_copy(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsjOPVHhJRRR9_16panic_slice_copy(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #18
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCsjOPVHhJRRR9_16panic_slice_copy(ptr %ptr, i64 %align) unnamed_addr #1 !guid !47 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCsjOPVHhJRRR9_16panic_slice_copy(ptr %ptr, i64 %align) #13
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsjOPVHhJRRR9_16panic_slice_copy() unnamed_addr #1 !guid !48 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCsjOPVHhJRRR9_16panic_slice_copy(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #1 !guid !49 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCsjOPVHhJRRR9_16panic_slice_copy(i64 %size, i64 %count) #13
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCsjOPVHhJRRR9_16panic_slice_copy(i64 %_0.i2, i64 %_0.i) #13
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #18
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsjOPVHhJRRR9_16panic_slice_copy() unnamed_addr #1 !guid !50 {
start:
  ret i8 0
}

; <[u8; 2] as core::ops::index::Index<core::ops::range::RangeTo<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAhj2_INtNtNtB7_3ops5index5IndexINtNtBG_5range7RangeTojEE5indexCsjOPVHhJRRR9_16panic_slice_copy(ptr %self, i64 %index, ptr align 8 %0) unnamed_addr #1 !guid !51 {
start:
  %_3.i.i = alloca [16 x i8], align 8
; call <usize>::checked_sub
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCsjOPVHhJRRR9_16panic_slice_copy(i64 %index, i64 0) #13
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3.i.i, align 8
  %4 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  store i64 %3, ptr %4, align 8
  %_6.i.i = load i64, ptr %_3.i.i, align 8
  %5 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_6.i.i to i1
  br i1 %7, label %bb2.i.i, label %bb5.i.i

bb2.i.i:                                          ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %new_len.i.i = load i64, ptr %8, align 8
  %_8.i.i = icmp ule i64 %index, 2
  br i1 %_8.i.i, label %_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexShE5indexCsjOPVHhJRRR9_16panic_slice_copy.exit, label %bb5.i.i

bb5.i.i:                                          ; preds = %bb2.i.i, %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 0, i64 %index, i64 2, ptr align 8 %0) #15
  unreachable

_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexShE5indexCsjOPVHhJRRR9_16panic_slice_copy.exit: ; preds = %bb2.i.i
  %9 = insertvalue { ptr, i64 } poison, ptr %self, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %new_len.i.i, 1
  %11 = insertvalue { ptr, i64 } poison, ptr %self, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %new_len.i.i, 1
  %13 = insertvalue { ptr, i64 } poison, ptr %self, 0
  %14 = insertvalue { ptr, i64 } %13, i64 %new_len.i.i, 1
  %_0.0.i = extractvalue { ptr, i64 } %14, 0
  %_0.1.i = extractvalue { ptr, i64 } %14, 1
  %_0.0 = extractvalue { ptr, i64 } %14, 0
  %_0.1 = extractvalue { ptr, i64 } %14, 1
  %15 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %16 = insertvalue { ptr, i64 } %15, i64 %_0.1, 1
  ret { ptr, i64 } %16
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsjOPVHhJRRR9_16panic_slice_copy(ptr %_1) unnamed_addr #1 !guid !52 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsjOPVHhJRRR9_16panic_slice_copy(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !53 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsjOPVHhJRRR9_16panic_slice_copy(ptr align 8 %_1) #13
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

; core::slice::copy_from_slice_impl::len_mismatch_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNvNtCsl10jNU3mE6R_4core5slice20copy_from_slice_impl17len_mismatch_fail(i64, i64, ptr align 8) unnamed_addr #6

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #7

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #8

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #6

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #9

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #10

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #11

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #11

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64, i64, i64, ptr align 8) unnamed_addr #6

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #12 !guid !54 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsjOPVHhJRRR9_16panic_slice_copy(ptr @_RNvCsjOPVHhJRRR9_16panic_slice_copy4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { nonlazybind "target-cpu"="x86-64" }
attributes #13 = { inlinehint }
attributes #14 = { inlinehint nounwind }
attributes #15 = { noinline noreturn }
attributes #16 = { noinline }
attributes #17 = { cold noreturn nounwind }
attributes #18 = { noinline noreturn nounwind }

!llvm.module.flags = !{!14, !15, !16, !17}
!llvm.ident = !{!18}

!0 = !{i64 6663187231275036244}
!1 = !{i64 3823368662226669961}
!2 = !{i64 -5661283864523979016}
!3 = !{i64 -209009019801176912}
!4 = !{i64 -3356882989066815052}
!5 = !{i64 -1803318309979823216}
!6 = !{i64 -2548927271174980067}
!7 = !{i64 5015909399917405854}
!8 = !{i64 7975118861990722324}
!9 = !{i64 3765857321643782991}
!10 = !{i64 3526919983027628091}
!11 = !{i64 2637563327208419764}
!12 = !{i64 5696599534904088387}
!13 = !{i64 5701140244635958851}
!14 = !{i32 8, !"PIC Level", i32 2}
!15 = !{i32 7, !"PIE Level", i32 2}
!16 = !{i32 2, !"RtLibUseGOT", i32 1}
!17 = !{i32 7, !"uwtable", i32 2}
!18 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!19 = !{i64 2665916280698475120}
!20 = !{i64 3379225216438469231}
!21 = !{i64 1312898488248816}
!22 = !{i64 656364906621367493}
!23 = !{i64 -1670379816582180559}
!24 = !{i64 8081442087428905452}
!25 = !{i64 1905002719325903853}
!26 = !{i64 7476510637547854615}
!27 = !{i64 -1921120859089761652}
!28 = !{i64 4877696405403617397}
!29 = !{i64 5031186018873441867}
!30 = !{i64 1394898075472999767}
!31 = !{i64 7855614632802913153}
!32 = !{i64 -3042159005755255353}
!33 = !{i64 442830980483256661}
!34 = !{i64 4897820595781959478}
!35 = !{i64 -6580596681722725625}
!36 = !{i64 1647585876517242539}
!37 = !{i64 -7156325840140707102}
!38 = !{i64 -5086700352837452273}
!39 = !{i64 -1558457647067651661}
!40 = !{i64 8475255577558566315}
!41 = !{i64 -2257297541505773538}
!42 = !{i64 3520784499865983401}
!43 = !{i64 4854480655027912031}
!44 = !{i64 -1465164944954584094}
!45 = !{i64 5887158349361919357}
!46 = !{i64 8615002741981151247}
!47 = !{i64 -3479467489374135502}
!48 = !{i64 -8964420931570695422}
!49 = !{i64 -4048118749254348679}
!50 = !{i64 -7739801802946101793}
!51 = !{i64 4407799920318824062}
!52 = !{i64 -8851736039165885392}
!53 = !{i64 -2486297194597377240}
!54 = !{i64 -2624081020897602054}
