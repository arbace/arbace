; ModuleID = 'panic_slice_copy.e6daf7f73c8cbbfd-cgu.0'
source_filename = "panic_slice_copy.e6daf7f73c8cbbfd-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsjOPVHhJRRR9_16panic_slice_copy, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsjOPVHhJRRR9_16panic_slice_copy, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsjOPVHhJRRR9_16panic_slice_copy }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_d8f94199956596cd8cda5e8d34e0ee12 = private unnamed_addr constant [2 x i8] c"\01\02", align 1, !guid !2
@alloc_217d3bc84a5aad802b6333e29f059ab3 = private unnamed_addr constant [40 x i8] c"test/rust/synthetic/panic-slice-copy.rs\00", align 1, !guid !3
@alloc_dd6ba87ff6190882e793252c6c2e6648 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_217d3bc84a5aad802b6333e29f059ab3, [16 x i8] c"'\00\00\00\00\00\00\00\06\00\00\006\00\00\00" }>, align 8, !guid !4
@alloc_6c78800390cfcb49e16e07024e4d4b16 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_217d3bc84a5aad802b6333e29f059ab3, [16 x i8] c"'\00\00\00\00\00\00\00\06\00\00\00\1D\00\00\00" }>, align 8, !guid !5
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !6

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsjOPVHhJRRR9_16panic_slice_copy(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !12 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECsjOPVHhJRRR9_16panic_slice_copy(i64 %dummy) unnamed_addr #1 !guid !13 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !14
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsjOPVHhJRRR9_16panic_slice_copy(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !15 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsjOPVHhJRRR9_16panic_slice_copy(ptr %f) #7
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #7
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsjOPVHhJRRR9_16panic_slice_copy(ptr align 8 %_1) unnamed_addr #1 !guid !16 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsjOPVHhJRRR9_16panic_slice_copy(ptr %_4) #8
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsjOPVHhJRRR9_16panic_slice_copy() #7
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsjOPVHhJRRR9_16panic_slice_copy(i8 %_2) #7
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsjOPVHhJRRR9_16panic_slice_copy(ptr %_1) unnamed_addr #1 !guid !17 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsjOPVHhJRRR9_16panic_slice_copy(ptr %0) #7
  ret i32 %_0
}

; panic_slice_copy::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsjOPVHhJRRR9_16panic_slice_copy4main() unnamed_addr #0 !guid !18 {
start:
  %a = alloca [3 x i8], align 1
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsjOPVHhJRRR9_16panic_slice_copy(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #7
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
  call void @llvm.memset.p0.i64(ptr align 1 %a, i8 0, i64 3, i1 false)
; call core::hint::black_box::<usize>
  %_10 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECsjOPVHhJRRR9_16panic_slice_copy(i64 2) #7
; call <[u8; 2] as core::ops::index::Index<core::ops::range::RangeTo<usize>>>::index
  %1 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAhj2_INtNtNtB7_3ops5index5IndexINtNtBG_5range7RangeTojEE5indexCsjOPVHhJRRR9_16panic_slice_copy(ptr @alloc_d8f94199956596cd8cda5e8d34e0ee12, i64 %_10, ptr align 8 @alloc_dd6ba87ff6190882e793252c6c2e6648) #7
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8]>::copy_from_slice
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSh15copy_from_sliceB4_(ptr %a, i64 3, ptr %_7.0, i64 %_7.1, ptr align 8 @alloc_6c78800390cfcb49e16e07024e4d4b16) #7
; call <core::fmt::Arguments>::from_str
  %2 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsjOPVHhJRRR9_16panic_slice_copy(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #7
  %_12.0 = extractvalue { ptr, ptr } %2, 0
  %_12.1 = extractvalue { ptr, ptr } %2, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_12.0, ptr %_12.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsjOPVHhJRRR9_16panic_slice_copy(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !19 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsjOPVHhJRRR9_16panic_slice_copy(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !20 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsjOPVHhJRRR9_16panic_slice_copy(ptr %s.0, i64 %s.1) #7
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsjOPVHhJRRR9_16panic_slice_copy(ptr %self) unnamed_addr #1 !guid !21 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCsjOPVHhJRRR9_16panic_slice_copy(i64 %self, i64 %rhs) unnamed_addr #1 !guid !22 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsjOPVHhJRRR9_16panic_slice_copy(i8 %0) unnamed_addr #1 !guid !23 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsjOPVHhJRRR9_16panic_slice_copy(ptr %self) #7
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsjOPVHhJRRR9_16panic_slice_copy() unnamed_addr #1 !guid !24 {
start:
  ret i8 0
}

; <[u8; 2] as core::ops::index::Index<core::ops::range::RangeTo<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAhj2_INtNtNtB7_3ops5index5IndexINtNtBG_5range7RangeTojEE5indexCsjOPVHhJRRR9_16panic_slice_copy(ptr %self, i64 %index, ptr align 8 %0) unnamed_addr #1 !guid !25 {
start:
  %_3.i.i = alloca [16 x i8], align 8
; call <usize>::checked_sub
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCsjOPVHhJRRR9_16panic_slice_copy(i64 %index, i64 0) #7
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3.i.i, align 8
  %4 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  store i64 %3, ptr %4, align 8
  %_6.i.i = load i64, ptr %_3.i.i, align 8
  %5 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_6.i.i to i1
  br i1 %7, label %bb2.i.i, label %bb5.i.i

bb2.i.i:                                          ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %new_len.i.i = load i64, ptr %8, align 8
  %_8.i.i = icmp ule i64 %index, 2
  br i1 %_8.i.i, label %_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexShE5indexCsjOPVHhJRRR9_16panic_slice_copy.exit, label %bb5.i.i

bb5.i.i:                                          ; preds = %bb2.i.i, %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 0, i64 %index, i64 2, ptr align 8 %0) #9
  unreachable

_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexShE5indexCsjOPVHhJRRR9_16panic_slice_copy.exit: ; preds = %bb2.i.i
  %9 = insertvalue { ptr, i64 } poison, ptr %self, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %new_len.i.i, 1
  %11 = insertvalue { ptr, i64 } poison, ptr %self, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %new_len.i.i, 1
  %13 = insertvalue { ptr, i64 } poison, ptr %self, 0
  %14 = insertvalue { ptr, i64 } %13, i64 %new_len.i.i, 1
  %_0.0.i = extractvalue { ptr, i64 } %14, 0
  %_0.1.i = extractvalue { ptr, i64 } %14, 1
  %_0.0 = extractvalue { ptr, i64 } %14, 0
  %_0.1 = extractvalue { ptr, i64 } %14, 1
  %15 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %16 = insertvalue { ptr, i64 } %15, i64 %_0.1, 1
  ret { ptr, i64 } %16
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsjOPVHhJRRR9_16panic_slice_copy(ptr %_1) unnamed_addr #1 !guid !26 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsjOPVHhJRRR9_16panic_slice_copy(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !27 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsjOPVHhJRRR9_16panic_slice_copy(ptr align 8 %_1) #7
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; <[u8]>::copy_from_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCsl10jNU3mE6R_4core5sliceSh15copy_from_sliceB4_(ptr, i64, ptr, i64, ptr align 8) unnamed_addr #1

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64, i64, i64, ptr align 8) unnamed_addr #5

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #6 !guid !28 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsjOPVHhJRRR9_16panic_slice_copy(ptr @_RNvCsjOPVHhJRRR9_16panic_slice_copy4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #5 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nonlazybind "target-cpu"="x86-64" }
attributes #7 = { inlinehint }
attributes #8 = { noinline }
attributes #9 = { noinline noreturn }

!llvm.module.flags = !{!7, !8, !9, !10}
!llvm.ident = !{!11}

!0 = !{i64 6663187231275036244}
!1 = !{i64 -209009019801176912}
!2 = !{i64 -3356882989066815052}
!3 = !{i64 -1803318309979823216}
!4 = !{i64 -2548927271174980067}
!5 = !{i64 5015909399917405854}
!6 = !{i64 7975118861990722324}
!7 = !{i32 8, !"PIC Level", i32 2}
!8 = !{i32 7, !"PIE Level", i32 2}
!9 = !{i32 2, !"RtLibUseGOT", i32 1}
!10 = !{i32 7, !"uwtable", i32 2}
!11 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!12 = !{i64 2665916280698475120}
!13 = !{i64 3379225216438469231}
!14 = !{i64 1312898488248816}
!15 = !{i64 8081442087428905452}
!16 = !{i64 1905002719325903853}
!17 = !{i64 7476510637547854615}
!18 = !{i64 -1921120859089761652}
!19 = !{i64 4877696405403617397}
!20 = !{i64 4897820595781959478}
!21 = !{i64 -6580596681722725625}
!22 = !{i64 -7156325840140707102}
!23 = !{i64 -1558457647067651661}
!24 = !{i64 -7739801802946101793}
!25 = !{i64 4407799920318824062}
!26 = !{i64 -8851736039165885392}
!27 = !{i64 -2486297194597377240}
!28 = !{i64 -2624081020897602054}
