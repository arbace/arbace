; ModuleID = 'drops.c62aff7120b64836-cgu.0'
source_filename = "drops.c62aff7120b64836-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%Noisy = type { { ptr, i64 } }
%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@anon.9272288e00ae9030dad991d666a836d8.0 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 6502902123337210253 to ptr), ptr inttoptr (i64 4696988212028008628 to ptr) }>, align 8, !guid !4
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsh0Qi2nYeXOY_5drops, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csh0Qi2nYeXOY_5drops, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csh0Qi2nYeXOY_5drops }>, align 8, !guid !5
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !6
@alloc_9c04098d1f5b2a23ccf9ca333796c0a8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\8C\02\00\00\09\00\00\00" }>, align 8, !guid !7
@alloc_f4174c467a61acfe2433069ec1752319 = private unnamed_addr constant [13 x i8] c"closure owns\0A", align 1, !guid !8
@alloc_ceece17bb2a95067e163e10dba85338a = private unnamed_addr constant [10 x i8] c"only-on-ok", align 1, !guid !9
@alloc_02b558d5b27198b9b90fbafced75e0cf = private unnamed_addr constant [11 x i8] c"\06hook: \C0\01\0A\00", align 1, !guid !10
@alloc_37f62a15fae368a2423b3a16c75adcc9 = private unnamed_addr constant [1 x i8] c"x", align 1, !guid !11
@alloc_cd51bc84b49b21a3fdb2800731f25c21 = private unnamed_addr constant [1 x i8] c"y", align 1, !guid !12
@alloc_50ab75e5eb17b3d68555764b0a52038b = private unnamed_addr constant [1 x i8] c"z", align 1, !guid !13
@alloc_bfa9db590d102452bb2240c9799dc0a4 = private unnamed_addr constant [6 x i8] c"inner\0A", align 1, !guid !14
@alloc_445113b618571905af6a1fcfc7645f0c = private unnamed_addr constant [10 x i8] c"end of fn\0A", align 1, !guid !15
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !16
@alloc_746fb851ca41fda1fbb7a144a5f490ed = private unnamed_addr constant [2 x i8] c"pa", align 1, !guid !17
@alloc_5680ca822aa60ec7d7c58da34ca7379a = private unnamed_addr constant [2 x i8] c"pb", align 1, !guid !18
@alloc_4fdc182f7ad16f33883e312fa459f448 = private unnamed_addr constant [2 x i8] c"v0", align 1, !guid !19
@alloc_4708833df625061546a6b3f99554ca2c = private unnamed_addr constant [2 x i8] c"v1", align 1, !guid !20
@alloc_8f96945e3024e6985f2e60d09c120143 = private unnamed_addr constant [2 x i8] c"v2", align 1, !guid !21
@alloc_e3d25921584f5528a9be06b72b53c211 = private unnamed_addr constant [29 x i8] c"test/rust/synthetic/drops.rs\00", align 1, !guid !22
@alloc_ea98943a8293369c2895be2854186f9a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3d25921584f5528a9be06b72b53c211, [16 x i8] c"\1C\00\00\00\00\00\00\00\10\00\00\00\0D\00\00\00" }>, align 8, !guid !23
@alloc_58096495302c69ca26995c4c0084234f = private unnamed_addr constant [5 x i8] c"moved", align 1, !guid !24
@alloc_4f5a4d88a3e7036a463ea4b830ed1b2c = private unnamed_addr constant [2 x i8] c"t1", align 1, !guid !25
@alloc_f50ba3d89e33bc7c62fad8509f137fbe = private unnamed_addr constant [2 x i8] c"t2", align 1, !guid !26
@alloc_6aaf6facd70cd530b375e106123ad25c = private unnamed_addr constant [10 x i8] c"\05kept \C0\01\0A\00", align 1, !guid !27
@alloc_1b8445ae95f2dff3fa24d051b1c9c28e = private unnamed_addr constant [7 x i8] c"ignored", align 1, !guid !28
@alloc_8299e65a658c2d21190987e78ed689e7 = private unnamed_addr constant [15 x i8] c"underscore-name", align 1, !guid !29
@alloc_04aa453a9624e79c0f1dd94a8599d702 = private unnamed_addr constant [2 x i8] c"rc", align 1, !guid !30
@alloc_8d6b7de0a69bd42b74d486a482d0a67a = private unnamed_addr constant [11 x i8] c"\06count \C0\01\0A\00", align 1, !guid !31
@alloc_8b60d7b1b40efae87eeacd57c2d9d148 = private unnamed_addr constant [17 x i8] c"after first drop\0A", align 1, !guid !32
@alloc_c3a2190175ff31f81b11c23e204f055e = private unnamed_addr constant [4 x i8] c"cell", align 1, !guid !33
@alloc_034c12b7c7ab98b6d915a63c1bcfd9cc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3d25921584f5528a9be06b72b53c211, [16 x i8] c"\1C\00\00\00\00\00\00\00 \00\00\00\1D\00\00\00" }>, align 8, !guid !34
@alloc_9f4c04b62fb6ca7af25844bad1ec38e4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3d25921584f5528a9be06b72b53c211, [16 x i8] c"\1C\00\00\00\00\00\00\00!\00\00\00\0A\00\00\00" }>, align 8, !guid !35
@alloc_353930aa67335a6536b3933f20e17fc0 = private unnamed_addr constant [5 x i8] c"cell2", align 1, !guid !36
@alloc_0194f36088aabb0cb5eac02e855cb228 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3d25921584f5528a9be06b72b53c211, [16 x i8] c"\1C\00\00\00\00\00\00\00\22\00\00\00\0A\00\00\00" }>, align 8, !guid !37
@alloc_7ffa290e9557fe6a97978d8537c1d1c4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3d25921584f5528a9be06b72b53c211, [16 x i8] c"\1C\00\00\00\00\00\00\00\22\00\00\00\17\00\00\00" }>, align 8, !guid !38
@alloc_5323f4f99fcf0c2b91520588b758980c = private unnamed_addr constant [9 x i8] c"boxed-any", align 1, !guid !39
@vtable.1 = private unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_, [16 x i8] c"\10\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXNtCsl10jNU3mE6R_4core3anyNtCsh0Qi2nYeXOY_5drops5NoisyNtB2_3Any7type_idBt_ }>, align 8, !guid !40
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNSNvYNCNvCsh0Qi2nYeXOY_5drops4mains_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_once6vtableB8_, ptr @_RNCNvCsh0Qi2nYeXOY_5drops4mains_0B3_, ptr @_RNCNvCsh0Qi2nYeXOY_5drops4mains_0B3_ }>, align 8, !guid !41
@alloc_57d0cedae8ee79c015dad926e59466fc = private unnamed_addr constant [12 x i8] c"\07caught \C0\01\0A\00", align 1, !guid !42
@alloc_c96b2bdbd1e873b6183a4bda3ab8772c = private unnamed_addr constant [8 x i8] c"\03ok \C0\01\0A\00", align 1, !guid !43
@alloc_d67b3c58cc3ff6868bcd8b4e30f3d1d9 = private unnamed_addr constant [9 x i8] c"forgotten", align 1, !guid !44
@alloc_6e09e81f0a9f57913bb586e3b3e3b6ff = private unnamed_addr constant [4 x i8] c"slot", align 1, !guid !45
@alloc_a9b3775cfa134afdd22f6f00a49b2e6d = private unnamed_addr constant [10 x i8] c"\05slot \C0\01\0A\00", align 1, !guid !46
@alloc_f96a0f7a17ca3bee53ed747e6cc66e37 = private unnamed_addr constant [5 x i8] c"done\0A", align 1, !guid !47
@alloc_6e8e49c99d5c78cc0547302e27c372f9 = private unnamed_addr constant [5 x i8] c"guard", align 1, !guid !48
@alloc_2b9b34ad9ea2d7dcff8586a2febe2bb6 = private unnamed_addr constant [4 x i8] c"late", align 1, !guid !49
@alloc_68572d84febe57999dddea25e3fc7f80 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3d25921584f5528a9be06b72b53c211, [16 x i8] c"\1C\00\00\00\00\00\00\00\0A\00\00\00c\00\00\00" }>, align 8, !guid !50
@alloc_b32139bb24fc9cbfa9ba1b0ab2732218 = private unnamed_addr constant [8 x i8] c"unwind-a", align 1, !guid !51
@alloc_e1ce7c519b9e352cc604b66dabe9205a = private unnamed_addr constant [8 x i8] c"unwind-b", align 1, !guid !52
@alloc_341cd808d2b25cca91eb1add2f252bed = private unnamed_addr constant [8 x i8] c"\05boom \C0\00", align 1, !guid !53
@alloc_228440ac4c7671a4b5d739068c3fdfbf = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3d25921584f5528a9be06b72b53c211, [16 x i8] c"\1C\00\00\00\00\00\00\00\0B\00\00\00b\00\00\00" }>, align 8, !guid !54
@alloc_04af5354bae90239a24027527d4c463d = private unnamed_addr constant [30 x i8] c"core/src/mem/manually_drop.rs\00", align 1, !guid !55
@alloc_622d398601f4d17fcdc4667dab4c4cb4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04af5354bae90239a24027527d4c463d, [16 x i8] c"\1D\00\00\00\00\00\00\00\CB\00\00\000\00\00\00" }>, align 8, !guid !56
@alloc_d9607be26b1182115ab3c853f5787a76 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04af5354bae90239a24027527d4c463d, [16 x i8] c"\1D\00\00\00\00\00\00\00\E4\00\00\00\12\00\00\00" }>, align 8, !guid !57
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !58
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !59
@alloc_d5775478081f42cd4f9216c1452822d5 = private unnamed_addr constant [16 x i8] c"alloc/src/rc.rs\00", align 1, !guid !60
@alloc_8005914618fe4afe560b492233173351 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d5775478081f42cd4f9216c1452822d5, [16 x i8] c"\0F\00\00\00\00\00\00\00\AF\01\00\00\16\00\00\00" }>, align 8, !guid !61
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !62
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !63
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !64
@alloc_9420a1aba537dc94842201b7589e1f0c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0C\04\00\00)\00\00\00" }>, align 8, !guid !65
@alloc_ce6d47b03c47f09012a85da1d9cb0822 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0D\04\00\00\0D\00\00\00" }>, align 8, !guid !66
@alloc_d57f55e9b6af1701fd9de9702359cd82 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\8B\09\00\00-\00\00\00" }>, align 8, !guid !67
@alloc_df8cf2a5a5c89ca4f9f99c5bd84f5957 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\8E\09\00\00\17\00\00\00" }>, align 8, !guid !68
@alloc_0d77a59642c5a3c35311ff5ab8da5ad9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\91\09\00\00\1F\00\00\00" }>, align 8, !guid !69
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !70
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !71
@alloc_d9efa9b520a36466fb4b57328b184287 = private unnamed_addr constant [17 x i8] c"core/src/cell.rs\00", align 1, !guid !72
@alloc_98f5b470f40a597b568a6efe978d8c0e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d9efa9b520a36466fb4b57328b184287, [16 x i8] c"\10\00\00\00\00\00\00\00\F3\04\00\00&\00\00\00" }>, align 8, !guid !73
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !74
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !75
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !76
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !77
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !78
@alloc_5ee6cd0de5bab89c84438a39fb5fb08c = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: ptr::copy requires that both pointer arguments are aligned and non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !79
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !80
@alloc_88523646262c2465cd77855ffd6da4ff = private unnamed_addr constant [10 x i8] c"\05drop \C0\01\0A\00", align 1, !guid !81
@alloc_2a34b8029ddd90836b1b40ec7c0e15b5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d5775478081f42cd4f9216c1452822d5, [16 x i8] c"\0F\00\00\00\00\00\00\00\C5\0E\00\00\0D\00\00\00" }>, align 8, !guid !82

; <[drops::Noisy]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCsh0Qi2nYeXOY_5drops5Noisy8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !88 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[drops::Noisy]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyE23into_raw_with_allocatorBK_(ptr align 8 %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<drops::Noisy>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[drops::Noisy]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyEEB1d_(ptr align 8 %self) #19
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<&std::panic::PanicHookInfo>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoECsh0Qi2nYeXOY_5drops(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !89 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&std::panic::PanicHookInfo>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoE8from_refCsh0Qi2nYeXOY_5drops(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<&std::panic::PanicHookInfo>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoE4castuECsh0Qi2nYeXOY_5drops(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoNtB6_7Display3fmtCsh0Qi2nYeXOY_5drops, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsh0Qi2nYeXOY_5drops(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !90 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsh0Qi2nYeXOY_5drops(ptr %x) #21
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsh0Qi2nYeXOY_5drops(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<u32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionmEECsh0Qi2nYeXOY_5drops(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !91 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<u32>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionmEE8from_refCsh0Qi2nYeXOY_5drops(ptr align 4 %x) #21
; call <core::ptr::non_null::NonNull<core::option::Option<u32>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionmEE4castuECsh0Qi2nYeXOY_5drops(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<dyn core::any::Any>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_3any3AnyEL_ECsh0Qi2nYeXOY_5drops(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !92 {
start:
; call core::mem::align_of_val_raw::<dyn core::any::Any>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_3any3AnyEL_ECsh0Qi2nYeXOY_5drops(ptr %val.0, ptr align 8 %val.1) #21
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsh0Qi2nYeXOY_5drops(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #21
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<alloc::rc::RcInner<drops::Noisy>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1H_(ptr %val) unnamed_addr #0 !guid !93 {
start:
; call core::mem::align_of_val_raw::<alloc::rc::RcInner<drops::Noisy>>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1l_(ptr %val) #21
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsh0Qi2nYeXOY_5drops(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #21
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<[drops::Noisy]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCsh0Qi2nYeXOY_5drops5NoisyEB18_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !94 {
start:
; call core::mem::align_of_val_raw::<[drops::Noisy]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCsh0Qi2nYeXOY_5drops5NoisyEBM_(ptr %val.0, i64 %val.1) #21
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsh0Qi2nYeXOY_5drops(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #21
  ret i64 %_0
}

; <core::alloc::layout::Layout>::for_value_raw::<dyn core::any::Any>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_3any3AnyEL_ECsh0Qi2nYeXOY_5drops(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !95 {
start:
; call core::mem::size_of_val_raw::<dyn core::any::Any>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_3any3AnyEL_ECsh0Qi2nYeXOY_5drops(ptr %val.0, ptr align 8 %val.1) #21
; call <core::mem::alignment::Alignment>::of_val_raw::<dyn core::any::Any>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_3any3AnyEL_ECsh0Qi2nYeXOY_5drops(ptr %val.0, ptr align 8 %val.1) #21
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsh0Qi2nYeXOY_5drops(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #21
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<alloc::rc::RcInner<drops::Noisy>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1G_(ptr %val) unnamed_addr #0 !guid !96 {
start:
; call core::mem::size_of_val_raw::<alloc::rc::RcInner<drops::Noisy>>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1k_(ptr %val) #21
; call <core::mem::alignment::Alignment>::of_val_raw::<alloc::rc::RcInner<drops::Noisy>>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1H_(ptr %val) #21
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsh0Qi2nYeXOY_5drops(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #21
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<[drops::Noisy]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCsh0Qi2nYeXOY_5drops5NoisyEB17_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !97 {
start:
; call core::mem::size_of_val_raw::<[drops::Noisy]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCsh0Qi2nYeXOY_5drops5NoisyEBL_(ptr %val.0, i64 %val.1) #21
; call <core::mem::alignment::Alignment>::of_val_raw::<[drops::Noisy]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCsh0Qi2nYeXOY_5drops5NoisyEB18_(ptr %val.0, i64 %val.1) #21
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsh0Qi2nYeXOY_5drops(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #21
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<dyn core::any::Any>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_3any3AnyEL_E4casthECsh0Qi2nYeXOY_5drops(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !98 {
start:
; call <core::ptr::non_null::NonNull<dyn core::any::Any>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_3any3AnyEL_E4casthECsh0Qi2nYeXOY_5drops(ptr %self.0, ptr align 8 %self.1) #21
  ret ptr %_2
}

; <core::ptr::unique::Unique<[drops::Noisy]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCsh0Qi2nYeXOY_5drops5NoisyE4casthEBU_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !99 {
start:
; call <core::ptr::non_null::NonNull<[drops::Noisy]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsh0Qi2nYeXOY_5drops5NoisyE4casthEBX_(ptr %self.0, i64 %self.1) #21
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<drops::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCsh0Qi2nYeXOY_5drops5NoisyEB10_(ptr %self) unnamed_addr #0 !guid !100 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<drops::Noisy>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCsh0Qi2nYeXOY_5drops5NoisyEB13_(ptr %self) #21
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<dyn core::any::Any>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_3any3AnyEL_E4casthECsh0Qi2nYeXOY_5drops(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !101 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<core::option::Option<u32>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionmEE4castuECsh0Qi2nYeXOY_5drops(ptr %self) unnamed_addr #0 !guid !102 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::rc::RcInner<drops::Noisy>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE4casthEB1w_(ptr %self) unnamed_addr #0 !guid !103 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&std::panic::PanicHookInfo>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoE4castuECsh0Qi2nYeXOY_5drops(ptr %self) unnamed_addr #0 !guid !104 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[drops::Noisy]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsh0Qi2nYeXOY_5drops5NoisyE4casthEBX_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !105 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsh0Qi2nYeXOY_5drops(ptr %self) unnamed_addr #0 !guid !106 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<drops::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCsh0Qi2nYeXOY_5drops5NoisyEB13_(ptr %self) unnamed_addr #0 !guid !107 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<drops::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCsh0Qi2nYeXOY_5drops5NoisyEBY_(ptr align 8 %self) unnamed_addr #0 !guid !108 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<drops::Noisy>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCsh0Qi2nYeXOY_5drops5NoisyEB13_(ptr align 8 %self) #21
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<drops::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCsh0Qi2nYeXOY_5drops5NoisyEB13_(ptr align 8 %self) unnamed_addr #0 !guid !109 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<drops::Noisy>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCsh0Qi2nYeXOY_5drops5NoisyEB10_(ptr %_3) #21
; call <core::ptr::unique::Unique<drops::Noisy>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCsh0Qi2nYeXOY_5drops5NoisyE15as_non_null_ptrBS_(ptr %_2) #21
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<12, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjc_Kj1_ECsh0Qi2nYeXOY_5drops(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !110 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::any::TypeId>::of::<drops::Noisy>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtCsh0Qi2nYeXOY_5drops5NoisyEBM_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !111 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.9272288e00ae9030dad991d666a836d8.0, i64 16, i1 false)
  ret void
}

; alloc::rc::is_dangling::<alloc::rc::RcInner<drops::Noisy>>
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RINvNtCs7CppTae75M1_5alloc2rc11is_danglingINtB2_7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEBU_(ptr %ptr) unnamed_addr #1 !guid !112 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, -1
  ret i1 %_0
}

; alloc::raw_vec::new_cap::<drops::Noisy>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCsh0Qi2nYeXOY_5drops5NoisyEBG_(i64 %cap) unnamed_addr #1 !guid !113 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsh0Qi2nYeXOY_5drops(i64 %cap) #21
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsh0Qi2nYeXOY_5drops(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !114 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; std::panic::catch_unwind::<drops::main::{closure#2}, u32>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsh0Qi2nYeXOY_5drops4mains0_0mEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !115 {
start:
; call std::panicking::catch_unwind::<u32, drops::main::{closure#2}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCsh0Qi2nYeXOY_5drops4mains0_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<drops::main::{closure#3}, u32>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsh0Qi2nYeXOY_5drops4mains1_0mEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !116 {
start:
; call std::panicking::catch_unwind::<u32, drops::main::{closure#3}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCsh0Qi2nYeXOY_5drops4mains1_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panicking::catch_unwind::<u32, drops::main::{closure#2}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCsh0Qi2nYeXOY_5drops4mains0_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !117 {
start:
  %slot.i1 = alloca [4 x i8], align 4
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<drops::main::{closure#2}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsh0Qi2nYeXOY_5drops4mains0_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsh0Qi2nYeXOY_5drops4mains0_0mEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsh0Qi2nYeXOY_5drops4mains0_0mEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i32, ptr %data, align 8
  store i32 %_11, ptr %slot.i1, align 4
  %_0.i.i = load i32, ptr %slot.i1, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<u32, drops::main::{closure#3}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCsh0Qi2nYeXOY_5drops4mains1_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !118 {
start:
  %slot.i1 = alloca [4 x i8], align 4
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<drops::main::{closure#3}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsh0Qi2nYeXOY_5drops4mains1_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsh0Qi2nYeXOY_5drops4mains1_0mEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsh0Qi2nYeXOY_5drops4mains1_0mEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i32, ptr %data, align 8
  store i32 %_11, ptr %slot.i1, align 4
  %_0.i.i = load i32, ptr %slot.i1, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; core::mem::size_of_val_raw::<dyn core::any::Any>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_3any3AnyEL_ECsh0Qi2nYeXOY_5drops(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !119 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %_0 = load i64, ptr %0, align 8, !invariant.load !120
  %1 = getelementptr inbounds i8, ptr %val.1, i64 16
  %2 = load i64, ptr %1, align 8, !invariant.load !120
  ret i64 %_0
}

; core::mem::size_of_val_raw::<alloc::rc::RcInner<drops::Noisy>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1k_(ptr %val) unnamed_addr #0 !guid !121 {
start:
  ret i64 32
}

; core::mem::size_of_val_raw::<[drops::Noisy]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCsh0Qi2nYeXOY_5drops5NoisyEBL_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !122 {
start:
  %_0 = mul nuw nsw i64 %val.1, 16
  ret i64 %_0
}

; core::mem::align_of_val_raw::<dyn core::any::Any>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_3any3AnyEL_ECsh0Qi2nYeXOY_5drops(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !123 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %1 = load i64, ptr %0, align 8, !invariant.load !120
  %2 = getelementptr inbounds i8, ptr %val.1, i64 16
  %_0 = load i64, ptr %2, align 8, !invariant.load !120
  ret i64 %_0
}

; core::mem::align_of_val_raw::<alloc::rc::RcInner<drops::Noisy>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1l_(ptr %val) unnamed_addr #0 !guid !124 {
start:
  ret i64 8
}

; core::mem::align_of_val_raw::<[drops::Noisy]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCsh0Qi2nYeXOY_5drops5NoisyEBM_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !125 {
start:
  %0 = mul nuw nsw i64 %val.1, 16
  ret i64 8
}

; core::mem::drop::<alloc::rc::Rc<drops::Noisy>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc2rc2RcNtCsh0Qi2nYeXOY_5drops5NoisyEEB13_(ptr %0) unnamed_addr #0 !guid !126 {
start:
  %_x = alloca [8 x i8], align 8
  store ptr %0, ptr %_x, align 8
; call core::ptr::drop_glue::<alloc::rc::Rc<drops::Noisy>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc2rc2RcNtCsh0Qi2nYeXOY_5drops5NoisyEEB18_(ptr align 8 %_x)
  ret void
}

; core::mem::drop::<alloc::vec::Vec<drops::Noisy>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEB15_(ptr align 8 %_x) unnamed_addr #0 !guid !127 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<drops::Noisy>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEB1a_(ptr align 8 %_x)
  ret void
}

; core::mem::drop::<alloc::boxed::Box<dyn core::any::Any>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyEL_EECsh0Qi2nYeXOY_5drops(ptr %0, ptr align 8 %1) unnamed_addr #0 !guid !128 {
start:
  %_x = alloca [16 x i8], align 8
  store ptr %0, ptr %_x, align 8
  %2 = getelementptr inbounds i8, ptr %_x, i64 8
  store ptr %1, ptr %2, align 8
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyEL_EECsh0Qi2nYeXOY_5drops(ptr align 8 %_x)
  ret void
}

; core::mem::forget::<drops::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetNtCsh0Qi2nYeXOY_5drops5NoisyEBA_(ptr %t.0, i64 %t.1) unnamed_addr #0 !guid !129 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<drops::Noisy>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtCsh0Qi2nYeXOY_5drops5NoisyE3newB16_(ptr %t.0, i64 %t.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
  ret void
}

; core::ptr::slice_from_raw_parts_mut::<drops::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCsh0Qi2nYeXOY_5drops5NoisyEBT_(ptr %data, i64 %len) unnamed_addr #0 !guid !130 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[drops::Noisy], drops::Noisy>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCsh0Qi2nYeXOY_5drops5NoisyBX_EBZ_(ptr %data, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<dyn core::any::Any>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueDNtNtB4_3any3AnyEL_ECsh0Qi2nYeXOY_5drops(ptr %_1.0, ptr align 8 %_1.1) unnamed_addr #1 !guid !131 {
start:
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 0
  %1 = load ptr, ptr %0, align 8, !invariant.load !120
  %2 = icmp ne ptr %1, null
  br i1 %2, label %is_not_null, label %bb1

is_not_null:                                      ; preds = %start
  call void %1(ptr %_1.0) #21
  br label %bb1

bb1:                                              ; preds = %is_not_null, %start
  ret void
}

; core::ptr::drop_glue::<core::cell::UnsafeCell<alloc::vec::Vec<drops::Noisy>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell10UnsafeCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1z_(ptr align 8 %_1) unnamed_addr #1 !guid !132 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<drops::Noisy>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEB1a_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::cell::RefMut<alloc::vec::Vec<drops::Noisy>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1u_(ptr align 8 %_1) unnamed_addr #1 !guid !133 {
start:
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<core::cell::BorrowRefMut>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtB4_4cell12BorrowRefMutECsddYV2PBJW9h_3std(ptr align 8 %0)
  ret void
}

; core::ptr::drop_glue::<core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1v_(ptr align 8 %_1) unnamed_addr #1 !guid !134 {
start:
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<core::cell::UnsafeCell<alloc::vec::Vec<drops::Noisy>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell10UnsafeCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1z_(ptr align 8 %0)
  ret void
}

; core::ptr::drop_glue::<core::option::Option<drops::Noisy>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtCsh0Qi2nYeXOY_5drops5NoisyEEBZ_(ptr align 8 %_1) unnamed_addr #1 !guid !135 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = icmp eq i64 %_2, 0
  br i1 %5, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<drops::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsh0Qi2nYeXOY_5drops(ptr align 8 %_1) unnamed_addr #1 !guid !136 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::rc::Rc<drops::Noisy>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc2rc2RcNtCsh0Qi2nYeXOY_5drops5NoisyEEB18_(ptr align 8 %_1) unnamed_addr #1 !guid !137 {
start:
; call <alloc::rc::Rc<drops::Noisy> as core::ops::drop::Drop>::drop
  call void @_RNvXsw_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBF_(ptr align 8 %_1) #21
  ret void
}

; core::ptr::drop_glue::<alloc::rc::Weak<drops::Noisy, &alloc::alloc::Global>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc2rc4WeakNtCsh0Qi2nYeXOY_5drops5NoisyRNtNtBG_5alloc6GlobalEEB1a_(ptr align 8 %_1) unnamed_addr #1 !guid !138 {
start:
; call <alloc::rc::Weak<drops::Noisy, &alloc::alloc::Global> as core::ops::drop::Drop>::drop
  call void @_RNvXs1d_NtCs7CppTae75M1_5alloc2rcINtB6_4WeakNtCsh0Qi2nYeXOY_5drops5NoisyRNtNtB8_5alloc6GlobalENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBI_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::rc::RcInner<drops::Noisy>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1d_(ptr align 8 %_1) unnamed_addr #1 !guid !139 {
start:
  %0 = getelementptr inbounds i8, ptr %_1, i64 16
; call core::ptr::drop_glue::<drops::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %0)
  ret void
}

; core::ptr::drop_glue::<alloc::vec::Vec<drops::Noisy>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEB1a_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !140 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<drops::Noisy> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsh0Qi2nYeXOY_5drops5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyEEB1h_(ptr align 8 %_1) #19
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<drops::Noisy>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyEEB1h_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyEL_EECsh0Qi2nYeXOY_5drops(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !141 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6.1, i64 0
  %3 = load ptr, ptr %2, align 8, !invariant.load !120
  %4 = icmp ne ptr %3, null
  br i1 %4, label %is_not_null, label %bb3

is_not_null:                                      ; preds = %start
  invoke void %3(ptr %_6.0)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %is_not_null, %start
; call <alloc::boxed::Box<dyn core::any::Any> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyEL_ENtNtNtBM_3ops4drop4Drop4dropCsh0Qi2nYeXOY_5drops(ptr align 8 %_1) #21
  ret void

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<dyn core::any::Any> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyEL_ENtNtNtBM_3ops4drop4Drop4dropCsh0Qi2nYeXOY_5drops(ptr align 8 %_1) #19
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %is_not_null
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb2:                                              ; preds = %bb4
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; core::ptr::drop_glue::<alloc::boxed::Box<[drops::Noisy]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyEEB1d_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !142 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
; invoke core::ptr::drop_glue::<[drops::Noisy]>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSNtCsh0Qi2nYeXOY_5drops5NoisyEBE_(ptr align 8 %_6.0, i64 %_6.1)
          to label %bb3 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<[drops::Noisy]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #19
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb4

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[drops::Noisy]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #21
  ret void

terminate:                                        ; preds = %bb4
  %6 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb2:                                              ; preds = %bb4
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = insertvalue { ptr, i32 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i32 } %10, i32 %9, 1
  resume { ptr, i32 } %11
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<drops::Noisy>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyEEB1h_(ptr align 8 %_1) unnamed_addr #1 !guid !143 {
start:
; call <alloc::raw_vec::RawVec<drops::Noisy> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<drops::Pair>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops4PairEBD_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !144 {
start:
  %0 = alloca [16 x i8], align 8
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
  %1 = getelementptr inbounds i8, ptr %_1, i64 16
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %1) #19
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb3

bb4:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %_1, i64 16
; call core::ptr::drop_glue::<drops::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %6)
  ret void

terminate:                                        ; preds = %bb3
  %7 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb2:                                              ; preds = %bb3
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12
}

; core::ptr::drop_glue::<drops::Noisy>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_1) unnamed_addr #1 !guid !145 {
start:
; call <drops::Noisy as core::ops::drop::Drop>::drop
  call void @_RNvXCsh0Qi2nYeXOY_5dropsNtB2_5NoisyNtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4drop(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<[drops::Noisy]>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSNtCsh0Qi2nYeXOY_5drops5NoisyEBE_(ptr align 8 %_1.0, i64 %_1.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !146 {
start:
  %0 = alloca [16 x i8], align 8
  %_3 = alloca [8 x i8], align 8
  store i64 0, ptr %_3, align 8
  br label %bb6

bb6:                                              ; preds = %bb5, %start
  %1 = load i64, ptr %_3, align 8
  %_7 = icmp eq i64 %1, %_1.1
  br i1 %_7, label %bb1, label %bb5

bb5:                                              ; preds = %bb6
  %2 = load i64, ptr %_3, align 8
  %_6 = getelementptr inbounds nuw %Noisy, ptr %_1.0, i64 %2
  %3 = load i64, ptr %_3, align 8
  %4 = add i64 %3, 1
  store i64 %4, ptr %_3, align 8
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_6)
          to label %bb6 unwind label %cleanup

bb1:                                              ; preds = %bb6
  ret void

bb4:                                              ; preds = %bb3, %cleanup
  %5 = load i64, ptr %_3, align 8
  %_5 = icmp eq i64 %5, %_1.1
  br i1 %_5, label %bb2, label %bb3

cleanup:                                          ; preds = %bb5
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb4

bb3:                                              ; preds = %bb4
  %10 = load i64, ptr %_3, align 8
  %_4 = getelementptr inbounds nuw %Noisy, ptr %_1.0, i64 %10
  %11 = load i64, ptr %_3, align 8
  %12 = add i64 %11, 1
  store i64 %12, ptr %_3, align 8
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_4) #19
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb4
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr inbounds i8, ptr %0, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

terminate:                                        ; preds = %bb3
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsh0Qi2nYeXOY_5drops(i32 %dummy) unnamed_addr #0 !guid !147 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !148
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsh0Qi2nYeXOY_5drops(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !149 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsh0Qi2nYeXOY_5drops(ptr %f) #21
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #21
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts_mut::<[drops::Noisy], drops::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCsh0Qi2nYeXOY_5drops5NoisyBX_EBZ_(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !150 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; std::panicking::catch_unwind::do_call::<drops::main::{closure#2}, u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsh0Qi2nYeXOY_5drops4mains0_0mEBY_(ptr %data) unnamed_addr #0 !guid !151 {
start:
; call <core::mem::manually_drop::ManuallyDrop<drops::main::{closure#2}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsh0Qi2nYeXOY_5drops4mains0_0E4takeB16_(ptr %data) #21
; call drops::main::{closure#2}
  %_5 = call i32 @_RNCNvCsh0Qi2nYeXOY_5drops4mains0_0B3_() #21
; call <core::mem::maybe_dangling::MaybeDangling<u32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCsh0Qi2nYeXOY_5drops(i32 %_5)
  store i32 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<drops::main::{closure#3}, u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsh0Qi2nYeXOY_5drops4mains1_0mEBY_(ptr %data) unnamed_addr #0 !guid !152 {
start:
; call <core::mem::manually_drop::ManuallyDrop<drops::main::{closure#3}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsh0Qi2nYeXOY_5drops4mains1_0E4takeB16_(ptr %data) #21
; call drops::main::{closure#3}
  %_5 = call i32 @_RNCNvCsh0Qi2nYeXOY_5drops4mains1_0B3_() #21
; call <core::mem::maybe_dangling::MaybeDangling<u32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCsh0Qi2nYeXOY_5drops(i32 %_5)
  store i32 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<drops::main::{closure#2}, u32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsh0Qi2nYeXOY_5drops4mains0_0mEBZ_(ptr %data, ptr %payload) unnamed_addr #3 personality ptr @rust_eh_personality !guid !153 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsh0Qi2nYeXOY_5drops.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsh0Qi2nYeXOY_5drops.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsh0Qi2nYeXOY_5drops.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<drops::main::{closure#3}, u32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsh0Qi2nYeXOY_5drops4mains1_0mEBZ_(ptr %data, ptr %payload) unnamed_addr #3 personality ptr @rust_eh_personality !guid !154 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsh0Qi2nYeXOY_5drops.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsh0Qi2nYeXOY_5drops.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsh0Qi2nYeXOY_5drops.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csh0Qi2nYeXOY_5drops(ptr align 8 %_1) unnamed_addr #0 !guid !155 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsh0Qi2nYeXOY_5drops(ptr %_4) #23
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsh0Qi2nYeXOY_5drops() #21
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csh0Qi2nYeXOY_5drops(i8 %_2) #21
  ret i32 %_0
}

; drops::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCsh0Qi2nYeXOY_5drops4main0B3_(ptr %_1.0, i64 %_1.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !156 {
start:
  %0 = alloca [16 x i8], align 8
  %_m = alloca [16 x i8], align 8
  store ptr %_1.0, ptr %_m, align 8
  %1 = getelementptr inbounds i8, ptr %_m, i64 8
  store i64 %_1.1, ptr %1, align 8
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_f4174c467a61acfe2433069ec1752319, i64 13)
          to label %bb1 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_m) #19
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb1, %start
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb4

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_4.0, ptr %_4.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
; call core::ptr::drop_glue::<drops::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_m)
  ret void

terminate:                                        ; preds = %bb4
  %7 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb5:                                              ; preds = %bb4
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12
}

; drops::main::{closure#2}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCsh0Qi2nYeXOY_5drops4mains0_0B3_() unnamed_addr #0 !guid !157 {
start:
; call core::hint::black_box::<u32>
  %_2 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsh0Qi2nYeXOY_5drops(i32 3) #21
; call drops::unwinding
  %_0 = call i32 @_RNvCsh0Qi2nYeXOY_5drops9unwinding(i32 %_2)
  ret i32 %_0
}

; drops::main::{closure#3}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCsh0Qi2nYeXOY_5drops4mains1_0B3_() unnamed_addr #0 personality ptr @rust_eh_personality !guid !158 {
start:
  %0 = alloca [16 x i8], align 8
  %_s = alloca [16 x i8], align 8
  store ptr @alloc_ceece17bb2a95067e163e10dba85338a, ptr %_s, align 8
  %1 = getelementptr inbounds i8, ptr %_s, i64 8
  store i64 10, ptr %1, align 8
; invoke core::hint::black_box::<u32>
  %_3 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsh0Qi2nYeXOY_5drops(i32 0)
          to label %bb1 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_s) #19
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb1, %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb4

bb1:                                              ; preds = %start
; invoke drops::unwinding
  %_0 = invoke i32 @_RNvCsh0Qi2nYeXOY_5drops9unwinding(i32 %_3)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
; call core::ptr::drop_glue::<drops::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_s)
  ret i32 %_0

terminate:                                        ; preds = %bb4
  %6 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb5:                                              ; preds = %bb4
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = insertvalue { ptr, i32 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i32 } %10, i32 %9, 1
  resume { ptr, i32 } %11
}

; drops::main::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCsh0Qi2nYeXOY_5drops4mains_0B3_(ptr %_1, ptr align 8 %0) unnamed_addr #0 !guid !159 {
start:
  %_8 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %i = alloca [8 x i8], align 8
  store ptr %0, ptr %i, align 8
; call <core::fmt::rt::Argument>::new_display::<&std::panic::PanicHookInfo>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoECsh0Qi2nYeXOY_5drops(ptr sret([16 x i8]) align 8 %_8, ptr align 8 %i) #21
  %1 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %_8, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<11, 1>
  %2 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr @alloc_02b558d5b27198b9b90fbafced75e0cf, ptr align 8 %args) #21
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_4.0, ptr %_4.1)
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsh0Qi2nYeXOY_5drops(ptr %_1) unnamed_addr #0 !guid !160 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsh0Qi2nYeXOY_5drops(ptr %0) #21
  ret i32 %_0
}

; <drops::main::{closure#1} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNSNvYNCNvCsh0Qi2nYeXOY_5drops4mains_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_once6vtableB8_(ptr %_1, ptr align 8 %0) unnamed_addr #0 !guid !161 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call <drops::main::{closure#1} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once
  call void @_RNvYNCNvCsh0Qi2nYeXOY_5drops4mains_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_onceB6_(ptr align 8 %1) #21
  ret void
}

; drops::scope_order
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCsh0Qi2nYeXOY_5drops11scope_order() unnamed_addr #1 personality ptr @rust_eh_personality !guid !162 {
start:
  %0 = alloca [16 x i8], align 8
  %_z = alloca [16 x i8], align 8
  %_y = alloca [16 x i8], align 8
  %_x = alloca [16 x i8], align 8
  store ptr @alloc_37f62a15fae368a2423b3a16c75adcc9, ptr %_x, align 8
  %1 = getelementptr inbounds i8, ptr %_x, i64 8
  store i64 1, ptr %1, align 8
  store ptr @alloc_cd51bc84b49b21a3fdb2800731f25c21, ptr %_y, align 8
  %2 = getelementptr inbounds i8, ptr %_y, i64 8
  store i64 1, ptr %2, align 8
  store ptr @alloc_50ab75e5eb17b3d68555764b0a52038b, ptr %_z, align 8
  %3 = getelementptr inbounds i8, ptr %_z, i64 8
  store i64 1, ptr %3, align 8
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_bfa9db590d102452bb2240c9799dc0a4, i64 6)
          to label %bb1 unwind label %cleanup

bb8:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_z) #19
          to label %bb9 unwind label %terminate

cleanup:                                          ; preds = %bb1, %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb8

bb1:                                              ; preds = %start
  %_5.0 = extractvalue { ptr, ptr } %4, 0
  %_5.1 = extractvalue { ptr, ptr } %4, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_5.0, ptr %_5.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_z)
          to label %bb3 unwind label %cleanup1

bb9:                                              ; preds = %bb8, %cleanup1
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_y) #19
          to label %bb10 unwind label %terminate

cleanup1:                                         ; preds = %bb4, %bb3, %bb2
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb9

bb3:                                              ; preds = %bb2
; invoke <core::fmt::Arguments>::from_str
  %13 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_445113b618571905af6a1fcfc7645f0c, i64 10)
          to label %bb4 unwind label %cleanup1

bb4:                                              ; preds = %bb3
  %_7.0 = extractvalue { ptr, ptr } %13, 0
  %_7.1 = extractvalue { ptr, ptr } %13, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_7.0, ptr %_7.1)
          to label %bb5 unwind label %cleanup1

bb5:                                              ; preds = %bb4
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_y)
          to label %bb6 unwind label %cleanup2

bb10:                                             ; preds = %bb9, %cleanup2
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_x) #19
          to label %bb11 unwind label %terminate

cleanup2:                                         ; preds = %bb5
  %14 = landingpad { ptr, i32 }
          cleanup
  %15 = extractvalue { ptr, i32 } %14, 0
  %16 = extractvalue { ptr, i32 } %14, 1
  store ptr %15, ptr %0, align 8
  %17 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %16, ptr %17, align 8
  br label %bb10

bb6:                                              ; preds = %bb5
; call core::ptr::drop_glue::<drops::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_x)
  ret void

terminate:                                        ; preds = %bb10, %bb9, %bb8
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb11:                                             ; preds = %bb10
  %19 = load ptr, ptr %0, align 8
  %20 = getelementptr inbounds i8, ptr %0, i64 8
  %21 = load i32, ptr %20, align 8
  %22 = insertvalue { ptr, i32 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i32 } %22, i32 %21, 1
  resume { ptr, i32 } %23
}

; drops::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsh0Qi2nYeXOY_5drops4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !163 {
start:
  %0 = alloca [16 x i8], align 8
  %_4.i28 = alloca [1 x i8], align 1
  %x.i = alloca [16 x i8], align 8
  %_4.i = alloca [1 x i8], align 1
  %1 = alloca [16 x i8], align 8
  %2 = alloca [24 x i8], align 8
  %3 = alloca [16 x i8], align 8
  %_131 = alloca [1 x i8], align 1
  %_130 = alloca [1 x i8], align 1
  %_118 = alloca [16 x i8], align 8
  %args6 = alloca [16 x i8], align 8
  %_115 = alloca [1 x i8], align 1
  %slot = alloca [16 x i8], align 8
  %_105 = alloca [16 x i8], align 8
  %_102 = alloca [16 x i8], align 8
  %args5 = alloca [16 x i8], align 8
  %_100 = alloca [8 x i8], align 4
  %r4 = alloca [16 x i8], align 8
  %_92 = alloca [16 x i8], align 8
  %args3 = alloca [16 x i8], align 8
  %_89 = alloca [1 x i8], align 1
  %r = alloca [16 x i8], align 8
  %_75 = alloca [16 x i8], align 8
  %_72 = alloca [16 x i8], align 8
  %_69 = alloca [16 x i8], align 8
  %_63 = alloca [24 x i8], align 8
  %cell = alloca [32 x i8], align 8
  %_53 = alloca [16 x i8], align 8
  %args2 = alloca [16 x i8], align 8
  %_50 = alloca [8 x i8], align 8
  %rc2 = alloca [8 x i8], align 8
  %rc = alloca [8 x i8], align 8
  %_kept = alloca [16 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_37 = alloca [16 x i8], align 8
  %args1 = alloca [16 x i8], align 8
  %keep = alloca [16 x i8], align 8
  %tmp = alloca [32 x i8], align 8
  %v = alloca [24 x i8], align 8
  %_p = alloca [32 x i8], align 8
  %_13 = alloca [16 x i8], align 8
  %_12 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_9 = alloca [4 x i8], align 4
  %_6 = alloca [4 x i8], align 4
  store i8 0, ptr %_131, align 1
  store i8 0, ptr %_130, align 1
; call drops::scope_order
  call void @_RNvCsh0Qi2nYeXOY_5drops11scope_order()
; call core::hint::black_box::<u32>
  %_7 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsh0Qi2nYeXOY_5drops(i32 5) #21
; call drops::early
  %4 = call i32 @_RNvCsh0Qi2nYeXOY_5drops5early(i32 %_7)
  store i32 %4, ptr %_6, align 4
; call core::hint::black_box::<u32>
  %_10 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsh0Qi2nYeXOY_5drops(i32 0) #21
; call drops::early
  %5 = call i32 @_RNvCsh0Qi2nYeXOY_5drops5early(i32 %_10)
  store i32 %5, ptr %_9, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_12, ptr align 4 %_6) #21
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_13, ptr align 4 %_9) #21
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_12, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_13, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args) #21
  %_3.0 = extractvalue { ptr, ptr } %8, 0
  %_3.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_3.0, ptr %_3.1)
  store ptr @alloc_746fb851ca41fda1fbb7a144a5f490ed, ptr %_p, align 8
  %9 = getelementptr inbounds i8, ptr %_p, i64 8
  store i64 2, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %_p, i64 16
  store ptr @alloc_5680ca822aa60ec7d7c58da34ca7379a, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 2, ptr %11, align 8
; invoke alloc::boxed::box_new_uninit
  %_1.i25 = invoke align 8 ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsh0Qi2nYeXOY_5drops(i64 8, i64 48) #21
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxANtCsh0Qi2nYeXOY_5drops5Noisyj3_E10new_uninitBH_.exit unwind label %cleanup

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxANtCsh0Qi2nYeXOY_5drops5Noisyj3_E10new_uninitBH_.exit: ; preds = %start
  br label %bb10

bb79:                                             ; preds = %bb85, %cleanup
; invoke core::ptr::drop_glue::<drops::Pair>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops4PairEBD_(ptr align 8 %_p) #19
          to label %bb80 unwind label %terminate

cleanup:                                          ; preds = %start, %_3.i.noexc22, %bb69, %bb12, %bb11
  %12 = landingpad { ptr, i32 }
          cleanup
  %13 = extractvalue { ptr, i32 } %12, 0
  %14 = extractvalue { ptr, i32 } %12, 1
  store ptr %13, ptr %3, align 8
  %15 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %14, ptr %15, align 8
  br label %bb79

bb10:                                             ; preds = %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxANtCsh0Qi2nYeXOY_5drops5Noisyj3_E10new_uninitBH_.exit
  %_140 = ptrtoint ptr %_1.i25 to i64
  %_142 = and i64 %_140, 7
  %_143 = icmp eq i64 %_142, 0
  br i1 %_143, label %bb87, label %panic

bb87:                                             ; preds = %bb10
  %_145 = ptrtoint ptr %_1.i25 to i64
  %_147 = icmp eq i64 %_145, 0
  %_148 = and i1 %_147, true
  %_149 = xor i1 %_148, true
  br i1 %_149, label %bb88, label %panic7

panic:                                            ; preds = %bb10
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_140, ptr align 8 @alloc_ea98943a8293369c2895be2854186f9a) #24
  unreachable

bb88:                                             ; preds = %bb87
  %16 = getelementptr inbounds nuw %Noisy, ptr %_1.i25, i64 0
  store ptr @alloc_4fdc182f7ad16f33883e312fa459f448, ptr %16, align 8
  %17 = getelementptr inbounds i8, ptr %16, i64 8
  store i64 2, ptr %17, align 8
  %18 = getelementptr inbounds nuw %Noisy, ptr %_1.i25, i64 1
  store ptr @alloc_4708833df625061546a6b3f99554ca2c, ptr %18, align 8
  %19 = getelementptr inbounds i8, ptr %18, i64 8
  store i64 2, ptr %19, align 8
  %20 = getelementptr inbounds nuw %Noisy, ptr %_1.i25, i64 2
  store ptr @alloc_8f96945e3024e6985f2e60d09c120143, ptr %20, align 8
  %21 = getelementptr inbounds i8, ptr %20, i64 8
  store i64 2, ptr %21, align 8
  br label %_3.i.noexc22

_3.i.noexc22:                                     ; preds = %bb88
; invoke <[drops::Noisy]>::into_vec::<alloc::alloc::Global>
  invoke void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCsh0Qi2nYeXOY_5drops5Noisy8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %v, ptr align 8 %_1.i25, i64 3) #21
          to label %_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafeNtCsh0Qi2nYeXOY_5drops5NoisyKj3_EB13_.exit unwind label %cleanup

_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafeNtCsh0Qi2nYeXOY_5drops5NoisyKj3_EB13_.exit: ; preds = %_3.i.noexc22
  br label %bb11

panic7:                                           ; preds = %bb87
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_ea98943a8293369c2895be2854186f9a) #24
  unreachable

bb11:                                             ; preds = %_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafeNtCsh0Qi2nYeXOY_5drops5NoisyKj3_EB13_.exit
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %v, i64 24, i1 false)
; invoke core::mem::drop::<alloc::vec::Vec<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEB15_(ptr align 8 %2)
          to label %bb12 unwind label %cleanup

bb12:                                             ; preds = %bb11
; invoke drops::main::{closure#0}
  invoke void @_RNCNvCsh0Qi2nYeXOY_5drops4main0B3_(ptr @alloc_58096495302c69ca26995c4c0084234f, i64 5)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb12
  store ptr @alloc_4f5a4d88a3e7036a463ea4b830ed1b2c, ptr %tmp, align 8
  %22 = getelementptr inbounds i8, ptr %tmp, i64 8
  store i64 2, ptr %22, align 8
  %23 = getelementptr inbounds i8, ptr %tmp, i64 16
  store ptr @alloc_f50ba3d89e33bc7c62fad8509f137fbe, ptr %23, align 8
  %24 = getelementptr inbounds i8, ptr %23, i64 8
  store i64 2, ptr %24, align 8
  %25 = getelementptr inbounds i8, ptr %tmp, i64 16
  %26 = load ptr, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %25, i64 8
  %28 = load i64, ptr %27, align 8
  store ptr %26, ptr %keep, align 8
  %29 = getelementptr inbounds i8, ptr %keep, i64 8
  store i64 %28, ptr %29, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_37, ptr align 8 %keep)
          to label %bb14 unwind label %cleanup8

bb78:                                             ; preds = %bb77, %cleanup8
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %keep) #19
          to label %bb85 unwind label %terminate

cleanup8:                                         ; preds = %bb67, %bb16, %bb15, %bb14, %bb13
  %30 = landingpad { ptr, i32 }
          cleanup
  %31 = extractvalue { ptr, i32 } %30, 0
  %32 = extractvalue { ptr, i32 } %30, 1
  store ptr %31, ptr %3, align 8
  %33 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %32, ptr %33, align 8
  br label %bb78

bb14:                                             ; preds = %bb13
  %34 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %34, ptr align 8 %_37, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 1>
  %35 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_EB8_(ptr @alloc_6aaf6facd70cd530b375e106123ad25c, ptr align 8 %args1)
          to label %bb15 unwind label %cleanup8

bb15:                                             ; preds = %bb14
  %_33.0 = extractvalue { ptr, ptr } %35, 0
  %_33.1 = extractvalue { ptr, ptr } %35, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_33.0, ptr %_33.1)
          to label %bb16 unwind label %cleanup8

bb16:                                             ; preds = %bb15
  store ptr @alloc_1b8445ae95f2dff3fa24d051b1c9c28e, ptr %_40, align 8
  %36 = getelementptr inbounds i8, ptr %_40, i64 8
  store i64 7, ptr %36, align 8
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_40)
          to label %bb17 unwind label %cleanup8

bb17:                                             ; preds = %bb16
  store ptr @alloc_8299e65a658c2d21190987e78ed689e7, ptr %_kept, align 8
  %37 = getelementptr inbounds i8, ptr %_kept, i64 8
  store i64 15, ptr %37, align 8
; invoke <alloc::rc::Rc<drops::Noisy>>::new
  %38 = invoke ptr @_RNvMs7_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE3newBF_(ptr @alloc_04aa453a9624e79c0f1dd94a8599d702, i64 2)
          to label %bb18 unwind label %cleanup9

bb77:                                             ; preds = %bb83, %bb84, %cleanup9
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_kept) #19
          to label %bb78 unwind label %terminate

cleanup9:                                         ; preds = %bb17
  %39 = landingpad { ptr, i32 }
          cleanup
  %40 = extractvalue { ptr, i32 } %39, 0
  %41 = extractvalue { ptr, i32 } %39, 1
  store ptr %40, ptr %3, align 8
  %42 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %41, ptr %42, align 8
  br label %bb77

bb18:                                             ; preds = %bb17
  store ptr %38, ptr %rc, align 8
  store i8 1, ptr %_131, align 1
; invoke <alloc::rc::Rc<drops::Noisy> as core::clone::Clone>::clone
  %43 = invoke ptr @_RNvXsx_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyENtNtCsl10jNU3mE6R_4core5clone5Clone5cloneBF_(ptr align 8 %rc)
          to label %bb19 unwind label %cleanup10

bb84:                                             ; preds = %bb81, %bb82, %cleanup10
  %44 = load i8, ptr %_131, align 1
  %45 = trunc nuw i8 %44 to i1
  br i1 %45, label %bb83, label %bb77

cleanup10:                                        ; preds = %bb18
  %46 = landingpad { ptr, i32 }
          cleanup
  %47 = extractvalue { ptr, i32 } %46, 0
  %48 = extractvalue { ptr, i32 } %46, 1
  store ptr %47, ptr %3, align 8
  %49 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %48, ptr %49, align 8
  br label %bb84

bb19:                                             ; preds = %bb18
  store ptr %43, ptr %rc2, align 8
  store i8 1, ptr %_130, align 1
; invoke <alloc::rc::Rc<drops::Noisy>>::strong_count
  %50 = invoke i64 @_RNvMsg_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE12strong_countBF_(ptr align 8 %rc)
          to label %bb20 unwind label %cleanup11

bb82:                                             ; preds = %bb76, %cleanup11
  %51 = load i8, ptr %_130, align 1
  %52 = trunc nuw i8 %51 to i1
  br i1 %52, label %bb81, label %bb84

cleanup11:                                        ; preds = %bb27, %_3.i.noexc, %bb66, %bb29, %bb26, %bb25, %bb24, %bb23, %bb22, %bb21, %bb20, %bb19
  %53 = landingpad { ptr, i32 }
          cleanup
  %54 = extractvalue { ptr, i32 } %53, 0
  %55 = extractvalue { ptr, i32 } %53, 1
  store ptr %54, ptr %3, align 8
  %56 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %55, ptr %56, align 8
  br label %bb82

bb20:                                             ; preds = %bb19
  store i64 %50, ptr %_50, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_53, ptr align 8 %_50)
          to label %bb21 unwind label %cleanup11

bb21:                                             ; preds = %bb20
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_53, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<11, 1>
  %58 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr @alloc_8d6b7de0a69bd42b74d486a482d0a67a, ptr align 8 %args2)
          to label %bb22 unwind label %cleanup11

bb22:                                             ; preds = %bb21
  %_47.0 = extractvalue { ptr, ptr } %58, 0
  %_47.1 = extractvalue { ptr, ptr } %58, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
          to label %bb23 unwind label %cleanup11

bb23:                                             ; preds = %bb22
  store i8 0, ptr %_131, align 1
  %_57 = load ptr, ptr %rc, align 8
; invoke core::mem::drop::<alloc::rc::Rc<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc2rc2RcNtCsh0Qi2nYeXOY_5drops5NoisyEEB13_(ptr %_57)
          to label %bb24 unwind label %cleanup11

bb24:                                             ; preds = %bb23
; invoke <core::fmt::Arguments>::from_str
  %59 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_8b60d7b1b40efae87eeacd57c2d9d148, i64 17)
          to label %bb25 unwind label %cleanup11

bb25:                                             ; preds = %bb24
  %_59.0 = extractvalue { ptr, ptr } %59, 0
  %_59.1 = extractvalue { ptr, ptr } %59, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
          to label %bb26 unwind label %cleanup11

bb26:                                             ; preds = %bb25
  store i8 0, ptr %_130, align 1
  %_61 = load ptr, ptr %rc2, align 8
; invoke core::mem::drop::<alloc::rc::Rc<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc2rc2RcNtCsh0Qi2nYeXOY_5drops5NoisyEEB13_(ptr %_61)
          to label %bb27 unwind label %cleanup11

bb27:                                             ; preds = %bb26
; invoke alloc::boxed::box_new_uninit
  %_1.i24 = invoke align 8 ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsh0Qi2nYeXOY_5drops(i64 8, i64 16) #21
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxANtCsh0Qi2nYeXOY_5drops5Noisyj1_E10new_uninitBH_.exit unwind label %cleanup11

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxANtCsh0Qi2nYeXOY_5drops5Noisyj1_E10new_uninitBH_.exit: ; preds = %bb27
  br label %bb28

bb28:                                             ; preds = %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxANtCsh0Qi2nYeXOY_5drops5Noisyj1_E10new_uninitBH_.exit
  %_135 = ptrtoint ptr %_1.i24 to i64
  %_137 = and i64 %_135, 7
  %_138 = icmp eq i64 %_137, 0
  br i1 %_138, label %bb86, label %panic12

bb86:                                             ; preds = %bb28
  %_151 = ptrtoint ptr %_1.i24 to i64
  %_153 = icmp eq i64 %_151, 0
  %_154 = and i1 %_153, true
  %_155 = xor i1 %_154, true
  br i1 %_155, label %bb89, label %panic13

panic12:                                          ; preds = %bb28
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_135, ptr align 8 @alloc_034c12b7c7ab98b6d915a63c1bcfd9cc) #24
  unreachable

bb89:                                             ; preds = %bb86
  %60 = getelementptr inbounds nuw %Noisy, ptr %_1.i24, i64 0
  store ptr @alloc_c3a2190175ff31f81b11c23e204f055e, ptr %60, align 8
  %61 = getelementptr inbounds i8, ptr %60, i64 8
  store i64 4, ptr %61, align 8
  br label %_3.i.noexc

_3.i.noexc:                                       ; preds = %bb89
; invoke <[drops::Noisy]>::into_vec::<alloc::alloc::Global>
  invoke void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCsh0Qi2nYeXOY_5drops5Noisy8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %_63, ptr align 8 %_1.i24, i64 1) #21
          to label %_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafeNtCsh0Qi2nYeXOY_5drops5NoisyKj1_EB13_.exit unwind label %cleanup11

_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafeNtCsh0Qi2nYeXOY_5drops5NoisyKj1_EB13_.exit: ; preds = %_3.i.noexc
  br label %bb29

panic13:                                          ; preds = %bb86
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_034c12b7c7ab98b6d915a63c1bcfd9cc) #24
  unreachable

bb29:                                             ; preds = %_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafeNtCsh0Qi2nYeXOY_5drops5NoisyKj1_EB13_.exit
; invoke <core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>::new
  invoke void @_RNvMss_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEE3newB1i_(ptr sret([32 x i8]) align 8 %cell, ptr align 8 %_63)
          to label %bb30 unwind label %cleanup11

bb30:                                             ; preds = %bb29
; invoke <core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>::borrow_mut
  %62 = invoke { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEE10borrow_mutB1i_(ptr align 8 %cell, ptr align 8 @alloc_9f4c04b62fb6ca7af25844bad1ec38e4)
          to label %bb31 unwind label %cleanup14

bb76:                                             ; preds = %bb75, %bb74, %bb73, %cleanup14.body
; invoke core::ptr::drop_glue::<core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1v_(ptr align 8 %cell) #19
          to label %bb82 unwind label %terminate

cleanup14:                                        ; preds = %bb41, %bb65, %bb43, %bb42, %bb40, %bb38, %bb34, %bb33, %bb30
  %63 = landingpad { ptr, i32 }
          cleanup
  br label %cleanup14.body

cleanup14.body:                                   ; preds = %bb2.i, %cleanup14
  %eh.lpad-body = phi { ptr, i32 } [ %63, %cleanup14 ], [ %97, %bb2.i ]
  %64 = extractvalue { ptr, i32 } %eh.lpad-body, 0
  %65 = extractvalue { ptr, i32 } %eh.lpad-body, 1
  store ptr %64, ptr %3, align 8
  %66 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %65, ptr %66, align 8
  br label %bb76

bb31:                                             ; preds = %bb30
  %67 = extractvalue { ptr, ptr } %62, 0
  %68 = extractvalue { ptr, ptr } %62, 1
  store ptr %67, ptr %_69, align 8
  %69 = getelementptr inbounds i8, ptr %_69, i64 8
  store ptr %68, ptr %69, align 8
; invoke <core::cell::RefMut<alloc::vec::Vec<drops::Noisy>> as core::ops::deref::DerefMut>::deref_mut
  %_67 = invoke align 8 ptr @_RNvXsR_NtCsl10jNU3mE6R_4core4cellINtB5_6RefMutINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEENtNtNtB7_3ops5deref8DerefMut9deref_mutB1h_(ptr align 8 %_69)
          to label %bb32 unwind label %cleanup15

bb75:                                             ; preds = %cleanup15
; invoke core::ptr::drop_glue::<core::cell::RefMut<alloc::vec::Vec<drops::Noisy>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1u_(ptr align 8 %_69) #19
          to label %bb76 unwind label %terminate

cleanup15:                                        ; preds = %bb32, %bb31
  %70 = landingpad { ptr, i32 }
          cleanup
  %71 = extractvalue { ptr, i32 } %70, 0
  %72 = extractvalue { ptr, i32 } %70, 1
  store ptr %71, ptr %3, align 8
  %73 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %72, ptr %73, align 8
  br label %bb75

bb32:                                             ; preds = %bb31
; invoke <alloc::vec::Vec<drops::Noisy>>::push
  invoke void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE4pushBH_(ptr align 8 %_67, ptr @alloc_353930aa67335a6536b3933f20e17fc0, i64 5)
          to label %bb33 unwind label %cleanup15

bb33:                                             ; preds = %bb32
; invoke core::ptr::drop_glue::<core::cell::RefMut<alloc::vec::Vec<drops::Noisy>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1u_(ptr align 8 %_69)
          to label %bb34 unwind label %cleanup14

bb34:                                             ; preds = %bb33
; invoke <core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>::borrow_mut
  %74 = invoke { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEE10borrow_mutB1i_(ptr align 8 %cell, ptr align 8 @alloc_0194f36088aabb0cb5eac02e855cb228)
          to label %bb35 unwind label %cleanup14

bb35:                                             ; preds = %bb34
  %75 = extractvalue { ptr, ptr } %74, 0
  %76 = extractvalue { ptr, ptr } %74, 1
  store ptr %75, ptr %_75, align 8
  %77 = getelementptr inbounds i8, ptr %_75, i64 8
  store ptr %76, ptr %77, align 8
; invoke <core::cell::RefMut<alloc::vec::Vec<drops::Noisy>> as core::ops::deref::DerefMut>::deref_mut
  %_73 = invoke align 8 ptr @_RNvXsR_NtCsl10jNU3mE6R_4core4cellINtB5_6RefMutINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEENtNtNtB7_3ops5deref8DerefMut9deref_mutB1h_(ptr align 8 %_75)
          to label %bb36 unwind label %cleanup16

bb74:                                             ; preds = %cleanup16
; invoke core::ptr::drop_glue::<core::cell::RefMut<alloc::vec::Vec<drops::Noisy>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1u_(ptr align 8 %_75) #19
          to label %bb76 unwind label %terminate

cleanup16:                                        ; preds = %bb37, %bb36, %bb35
  %78 = landingpad { ptr, i32 }
          cleanup
  %79 = extractvalue { ptr, i32 } %78, 0
  %80 = extractvalue { ptr, i32 } %78, 1
  store ptr %79, ptr %3, align 8
  %81 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %80, ptr %81, align 8
  br label %bb74

bb36:                                             ; preds = %bb35
; invoke <alloc::vec::Vec<drops::Noisy>>::remove
  %82 = invoke { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE6removeBG_(ptr align 8 %_73, i64 0, ptr align 8 @alloc_7ffa290e9557fe6a97978d8537c1d1c4)
          to label %bb37 unwind label %cleanup16

bb37:                                             ; preds = %bb36
  %83 = extractvalue { ptr, i64 } %82, 0
  %84 = extractvalue { ptr, i64 } %82, 1
  store ptr %83, ptr %_72, align 8
  %85 = getelementptr inbounds i8, ptr %_72, i64 8
  store i64 %84, ptr %85, align 8
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_72)
          to label %bb38 unwind label %cleanup16

bb38:                                             ; preds = %bb37
; invoke core::ptr::drop_glue::<core::cell::RefMut<alloc::vec::Vec<drops::Noisy>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell6RefMutINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1u_(ptr align 8 %_75)
          to label %bb39 unwind label %cleanup14

bb39:                                             ; preds = %bb38
  store ptr @alloc_5323f4f99fcf0c2b91520588b758980c, ptr %x.i, align 8
  %86 = getelementptr inbounds i8, ptr %x.i, i64 8
  store i64 9, ptr %86, align 8
  store i8 0, ptr %_4.i28, align 1
  store i8 1, ptr %_4.i28, align 1
; invoke alloc::boxed::box_new_uninit
  %_3.i = invoke ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsh0Qi2nYeXOY_5drops(i64 8, i64 16)
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtCsh0Qi2nYeXOY_5drops5NoisyE3newBG_.exit unwind label %cleanup.i

cleanup.i:                                        ; preds = %bb39
  %87 = landingpad { ptr, i32 }
          cleanup
  %88 = extractvalue { ptr, i32 } %87, 0
  %89 = extractvalue { ptr, i32 } %87, 1
  store ptr %88, ptr %0, align 8
  %90 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %89, ptr %90, align 8
  %91 = load i8, ptr %_4.i28, align 1
  %92 = trunc nuw i8 %91 to i1
  br i1 %92, label %bb3.i, label %bb2.i

bb2.i:                                            ; preds = %bb3.i, %cleanup.i
  %93 = load ptr, ptr %0, align 8
  %94 = getelementptr inbounds i8, ptr %0, i64 8
  %95 = load i32, ptr %94, align 8
  %96 = insertvalue { ptr, i32 } poison, ptr %93, 0
  %97 = insertvalue { ptr, i32 } %96, i32 %95, 1
  br label %cleanup14.body

bb3.i:                                            ; preds = %cleanup.i
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %x.i) #19
          to label %bb2.i unwind label %terminate.i

terminate.i:                                      ; preds = %bb3.i
  %98 = landingpad { ptr, i32 }
          cleanup
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtCsh0Qi2nYeXOY_5drops5NoisyE3newBG_.exit: ; preds = %bb39
  store i8 0, ptr %_4.i28, align 1
  %99 = load ptr, ptr %x.i, align 8
  %100 = getelementptr inbounds i8, ptr %x.i, i64 8
  %101 = load i64, ptr %100, align 8
  store ptr %99, ptr %_3.i, align 8
  %102 = getelementptr inbounds i8, ptr %_3.i, i64 8
  store i64 %101, ptr %102, align 8
  br label %bb40

bb40:                                             ; preds = %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtCsh0Qi2nYeXOY_5drops5NoisyE3newBG_.exit
; invoke core::mem::drop::<alloc::boxed::Box<dyn core::any::Any>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyEL_EECsh0Qi2nYeXOY_5drops(ptr %_3.i, ptr align 8 @vtable.1)
          to label %bb41 unwind label %cleanup14

bb41:                                             ; preds = %bb40
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; invoke alloc::boxed::box_new_uninit
  %_3.i27 = invoke ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsh0Qi2nYeXOY_5drops(i64 1, i64 0) #21
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNCNvCsh0Qi2nYeXOY_5drops4mains_0E3newBI_.exit unwind label %cleanup14

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNCNvCsh0Qi2nYeXOY_5drops4mains_0E3newBI_.exit: ; preds = %bb41
  store i8 0, ptr %_4.i, align 1
  br label %bb42

bb42:                                             ; preds = %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNCNvCsh0Qi2nYeXOY_5drops4mains_0E3newBI_.exit
; invoke std::panicking::set_hook
  invoke void @_RNvNtCsddYV2PBJW9h_3std9panicking8set_hook(ptr %_3.i27, ptr align 8 @vtable.2)
          to label %bb43 unwind label %cleanup14

bb43:                                             ; preds = %bb42
; invoke std::panic::catch_unwind::<drops::main::{closure#2}, u32>
  invoke void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsh0Qi2nYeXOY_5drops4mains0_0mEBK_(ptr sret([16 x i8]) align 8 %r)
          to label %bb44 unwind label %cleanup14

bb44:                                             ; preds = %bb43
; invoke <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
  %103 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCsh0Qi2nYeXOY_5drops(ptr align 8 %r)
          to label %bb45 unwind label %cleanup17

bb73:                                             ; preds = %bb72, %cleanup17
; invoke core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsh0Qi2nYeXOY_5drops(ptr align 8 %r) #19
          to label %bb76 unwind label %terminate

cleanup17:                                        ; preds = %bb64, %bb55, %bb54, %bb53, %bb52, %bb51, %bb50, %bb49, %bb48, %bb47, %bb46, %bb45, %bb44
  %104 = landingpad { ptr, i32 }
          cleanup
  %105 = extractvalue { ptr, i32 } %104, 0
  %106 = extractvalue { ptr, i32 } %104, 1
  store ptr %105, ptr %3, align 8
  %107 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %106, ptr %107, align 8
  br label %bb73

bb45:                                             ; preds = %bb44
  %108 = zext i1 %103 to i8
  store i8 %108, ptr %_89, align 1
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsh0Qi2nYeXOY_5drops(ptr sret([16 x i8]) align 8 %_92, ptr %_89)
          to label %bb46 unwind label %cleanup17

bb46:                                             ; preds = %bb45
  %109 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %109, ptr align 8 %_92, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<12, 1>
  %110 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjc_Kj1_ECsh0Qi2nYeXOY_5drops(ptr @alloc_57d0cedae8ee79c015dad926e59466fc, ptr align 8 %args3)
          to label %bb47 unwind label %cleanup17

bb47:                                             ; preds = %bb46
  %_86.0 = extractvalue { ptr, ptr } %110, 0
  %_86.1 = extractvalue { ptr, ptr } %110, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_86.0, ptr %_86.1)
          to label %bb48 unwind label %cleanup17

bb48:                                             ; preds = %bb47
; invoke std::panic::catch_unwind::<drops::main::{closure#3}, u32>
  invoke void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsh0Qi2nYeXOY_5drops4mains1_0mEBK_(ptr sret([16 x i8]) align 8 %r4)
          to label %bb49 unwind label %cleanup17

bb49:                                             ; preds = %bb48
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %r4, i64 16, i1 false)
; invoke <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
  %111 = invoke { i32, i32 } @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCsh0Qi2nYeXOY_5drops(ptr align 8 %1)
          to label %bb50 unwind label %cleanup17

bb50:                                             ; preds = %bb49
  %112 = extractvalue { i32, i32 } %111, 0
  %113 = extractvalue { i32, i32 } %111, 1
  store i32 %112, ptr %_100, align 4
  %114 = getelementptr inbounds i8, ptr %_100, i64 4
  store i32 %113, ptr %114, align 4
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<u32>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionmEECsh0Qi2nYeXOY_5drops(ptr sret([16 x i8]) align 8 %_102, ptr align 4 %_100)
          to label %bb51 unwind label %cleanup17

bb51:                                             ; preds = %bb50
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_102, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %116 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_c96b2bdbd1e873b6183a4bda3ab8772c, ptr align 8 %args5)
          to label %bb52 unwind label %cleanup17

bb52:                                             ; preds = %bb51
  %_97.0 = extractvalue { ptr, ptr } %116, 0
  %_97.1 = extractvalue { ptr, ptr } %116, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_97.0, ptr %_97.1)
          to label %bb53 unwind label %cleanup17

bb53:                                             ; preds = %bb52
; invoke std::panicking::take_hook
  %117 = invoke { ptr, ptr } @_RNvNtCsddYV2PBJW9h_3std9panicking9take_hook()
          to label %bb54 unwind label %cleanup17

bb54:                                             ; preds = %bb53
  %118 = extractvalue { ptr, ptr } %117, 0
  %119 = extractvalue { ptr, ptr } %117, 1
  store ptr %118, ptr %_105, align 8
  %120 = getelementptr inbounds i8, ptr %_105, i64 8
  store ptr %119, ptr %120, align 8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2I_4SendEL_EEB1O_(ptr align 8 %_105)
          to label %bb55 unwind label %cleanup17

bb55:                                             ; preds = %bb54
; invoke core::mem::forget::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetNtCsh0Qi2nYeXOY_5drops5NoisyEBA_(ptr @alloc_d67b3c58cc3ff6868bcd8b4e30f3d1d9, i64 9)
          to label %bb56 unwind label %cleanup17

bb56:                                             ; preds = %bb55
  store ptr @alloc_6e09e81f0a9f57913bb586e3b3e3b6ff, ptr %slot, align 8
  %121 = getelementptr inbounds i8, ptr %slot, i64 8
  store i64 4, ptr %121, align 8
; invoke core::ptr::drop_glue::<core::option::Option<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtCsh0Qi2nYeXOY_5drops5NoisyEEBZ_(ptr align 8 %slot)
          to label %bb57 unwind label %cleanup18

bb58:                                             ; preds = %cleanup18
  store ptr null, ptr %slot, align 8
  %122 = getelementptr inbounds i8, ptr %slot, i64 8
  store i64 undef, ptr %122, align 8
  br label %bb72

cleanup18:                                        ; preds = %bb56
  %123 = landingpad { ptr, i32 }
          cleanup
  %124 = extractvalue { ptr, i32 } %123, 0
  %125 = extractvalue { ptr, i32 } %123, 1
  store ptr %124, ptr %3, align 8
  %126 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %125, ptr %126, align 8
  br label %bb58

bb57:                                             ; preds = %bb56
  store ptr null, ptr %slot, align 8
  %127 = getelementptr inbounds i8, ptr %slot, i64 8
  store i64 undef, ptr %127, align 8
; invoke <core::option::Option<drops::Noisy>>::is_none
  %128 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtCsh0Qi2nYeXOY_5drops5NoisyE7is_noneBJ_(ptr align 8 %slot)
          to label %bb59 unwind label %cleanup19

bb72:                                             ; preds = %bb58, %cleanup19
; invoke core::ptr::drop_glue::<core::option::Option<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtCsh0Qi2nYeXOY_5drops5NoisyEEBZ_(ptr align 8 %slot) #19
          to label %bb73 unwind label %terminate

cleanup19:                                        ; preds = %bb63, %bb62, %bb61, %bb60, %bb59, %bb57
  %129 = landingpad { ptr, i32 }
          cleanup
  %130 = extractvalue { ptr, i32 } %129, 0
  %131 = extractvalue { ptr, i32 } %129, 1
  store ptr %130, ptr %3, align 8
  %132 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %131, ptr %132, align 8
  br label %bb72

bb59:                                             ; preds = %bb57
  %133 = zext i1 %128 to i8
  store i8 %133, ptr %_115, align 1
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsh0Qi2nYeXOY_5drops(ptr sret([16 x i8]) align 8 %_118, ptr %_115)
          to label %bb60 unwind label %cleanup19

bb60:                                             ; preds = %bb59
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_118, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 1>
  %135 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_EB8_(ptr @alloc_a9b3775cfa134afdd22f6f00a49b2e6d, ptr align 8 %args6)
          to label %bb61 unwind label %cleanup19

bb61:                                             ; preds = %bb60
  %_112.0 = extractvalue { ptr, ptr } %135, 0
  %_112.1 = extractvalue { ptr, ptr } %135, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_112.0, ptr %_112.1)
          to label %bb62 unwind label %cleanup19

bb62:                                             ; preds = %bb61
; invoke <core::fmt::Arguments>::from_str
  %136 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_f96a0f7a17ca3bee53ed747e6cc66e37, i64 5)
          to label %bb63 unwind label %cleanup19

bb63:                                             ; preds = %bb62
  %_122.0 = extractvalue { ptr, ptr } %136, 0
  %_122.1 = extractvalue { ptr, ptr } %136, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_122.0, ptr %_122.1)
          to label %bb64 unwind label %cleanup19

bb64:                                             ; preds = %bb63
; invoke core::ptr::drop_glue::<core::option::Option<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtCsh0Qi2nYeXOY_5drops5NoisyEEBZ_(ptr align 8 %slot)
          to label %bb65 unwind label %cleanup17

bb65:                                             ; preds = %bb64
; invoke core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsh0Qi2nYeXOY_5drops(ptr align 8 %r)
          to label %bb66 unwind label %cleanup14

bb66:                                             ; preds = %bb65
; invoke core::ptr::drop_glue::<core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1v_(ptr align 8 %cell)
          to label %bb67 unwind label %cleanup11

bb67:                                             ; preds = %bb66
  store i8 0, ptr %_130, align 1
  store i8 0, ptr %_131, align 1
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_kept)
          to label %bb68 unwind label %cleanup8

bb68:                                             ; preds = %bb67
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %keep)
          to label %bb69 unwind label %cleanup20

bb85:                                             ; preds = %bb78, %cleanup20
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %tmp) #19
          to label %bb79 unwind label %terminate

cleanup20:                                        ; preds = %bb68
  %137 = landingpad { ptr, i32 }
          cleanup
  %138 = extractvalue { ptr, i32 } %137, 0
  %139 = extractvalue { ptr, i32 } %137, 1
  store ptr %138, ptr %3, align 8
  %140 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %139, ptr %140, align 8
  br label %bb85

bb69:                                             ; preds = %bb68
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %tmp)
          to label %bb70 unwind label %cleanup

bb70:                                             ; preds = %bb69
; call core::ptr::drop_glue::<drops::Pair>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops4PairEBD_(ptr align 8 %_p)
  ret void

terminate:                                        ; preds = %bb79, %bb85, %bb78, %bb77, %bb83, %bb81, %bb76, %bb75, %bb74, %bb73, %bb72
  %141 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb81:                                             ; preds = %bb82
; invoke core::ptr::drop_glue::<alloc::rc::Rc<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc2rc2RcNtCsh0Qi2nYeXOY_5drops5NoisyEEB18_(ptr align 8 %rc2) #19
          to label %bb84 unwind label %terminate

bb83:                                             ; preds = %bb84
; invoke core::ptr::drop_glue::<alloc::rc::Rc<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc2rc2RcNtCsh0Qi2nYeXOY_5drops5NoisyEEB18_(ptr align 8 %rc) #19
          to label %bb77 unwind label %terminate

bb80:                                             ; preds = %bb79
  %142 = load ptr, ptr %3, align 8
  %143 = getelementptr inbounds i8, ptr %3, i64 8
  %144 = load i32, ptr %143, align 8
  %145 = insertvalue { ptr, i32 } poison, ptr %142, 0
  %146 = insertvalue { ptr, i32 } %145, i32 %144, 1
  resume { ptr, i32 } %146
}

; drops::early
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCsh0Qi2nYeXOY_5drops5early(i32 %n) unnamed_addr #1 personality ptr @rust_eh_personality !guid !164 {
start:
  %0 = alloca [16 x i8], align 8
  %_h = alloca [16 x i8], align 8
  %_g = alloca [16 x i8], align 8
  %_0 = alloca [4 x i8], align 4
  store ptr @alloc_6e8e49c99d5c78cc0547302e27c372f9, ptr %_g, align 8
  %1 = getelementptr inbounds i8, ptr %_g, i64 8
  store i64 5, ptr %1, align 8
  %_3 = icmp ugt i32 %n, 1
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr @alloc_2b9b34ad9ea2d7dcff8586a2febe2bb6, ptr %_h, align 8
  %2 = getelementptr inbounds i8, ptr %_h, i64 8
  store i64 4, ptr %2, align 8
  %_5.0 = add i32 %n, 1
  %_5.1 = icmp ult i32 %_5.0, %n
  br i1 %_5.1, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i32 %n, ptr %_0, align 4
; call core::ptr::drop_glue::<drops::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_g)
  br label %bb5

bb3:                                              ; preds = %bb2
  store i32 %_5.0, ptr %_0, align 4
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_h)
          to label %bb4 unwind label %cleanup1

panic:                                            ; preds = %bb2
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_68572d84febe57999dddea25e3fc7f80) #25
          to label %unreachable unwind label %cleanup

bb6:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_h) #19
          to label %bb7 unwind label %terminate

cleanup:                                          ; preds = %panic
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb6

unreachable:                                      ; preds = %panic
  unreachable

bb7:                                              ; preds = %bb6, %cleanup1
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_g) #19
          to label %bb8 unwind label %terminate

cleanup1:                                         ; preds = %bb3
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb7

bb4:                                              ; preds = %bb3
; call core::ptr::drop_glue::<drops::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_g)
  br label %bb5

bb5:                                              ; preds = %bb1, %bb4
  %11 = load i32, ptr %_0, align 4
  ret i32 %11

terminate:                                        ; preds = %bb7, %bb6
  %12 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb8:                                              ; preds = %bb7
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr inbounds i8, ptr %0, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17
}

; drops::unwinding
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCsh0Qi2nYeXOY_5drops9unwinding(i32 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !165 {
start:
  %1 = alloca [16 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_b = alloca [16 x i8], align 8
  %_a = alloca [16 x i8], align 8
  %n = alloca [4 x i8], align 4
  store i32 %0, ptr %n, align 4
  store ptr @alloc_b32139bb24fc9cbfa9ba1b0ab2732218, ptr %_a, align 8
  %2 = getelementptr inbounds i8, ptr %_a, i64 8
  store i64 8, ptr %2, align 8
  store ptr @alloc_e1ce7c519b9e352cc604b66dabe9205a, ptr %_b, align 8
  %3 = getelementptr inbounds i8, ptr %_b, i64 8
  store i64 8, ptr %3, align 8
  %4 = load i32, ptr %n, align 4
  %_4 = icmp ugt i32 %4, 0
  br i1 %_4, label %bb1, label %bb4

bb4:                                              ; preds = %start
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_b)
          to label %bb5 unwind label %cleanup

bb1:                                              ; preds = %start
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_10, ptr align 4 %n)
          to label %bb2 unwind label %cleanup1

bb8:                                              ; preds = %bb7, %cleanup
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_a) #19
          to label %bb9 unwind label %terminate

cleanup:                                          ; preds = %bb4
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %1, align 8
  %8 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
; call core::ptr::drop_glue::<drops::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_a)
  ret i32 0

bb7:                                              ; preds = %cleanup1
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_b) #19
          to label %bb8 unwind label %terminate

cleanup1:                                         ; preds = %bb3, %bb2, %bb1
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %1, align 8
  %12 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %13 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %_10, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %14 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_341cd808d2b25cca91eb1add2f252bed, ptr align 8 %args)
          to label %bb3 unwind label %cleanup1

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %14, 0
  %_6.1 = extractvalue { ptr, ptr } %14, 1
; invoke core::panicking::panic_fmt
  invoke void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_228440ac4c7671a4b5d739068c3fdfbf) #25
          to label %unreachable unwind label %cleanup1

unreachable:                                      ; preds = %bb3
  unreachable

terminate:                                        ; preds = %bb8, %bb7
  %15 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb9:                                              ; preds = %bb8
  %16 = load ptr, ptr %1, align 8
  %17 = getelementptr inbounds i8, ptr %1, i64 8
  %18 = load i32, ptr %17, align 8
  %19 = insertvalue { ptr, i32 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i32 } %19, i32 %18, 1
  resume { ptr, i32 } %20
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsh0Qi2nYeXOY_5drops(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !166 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<drops::Noisy>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtCsh0Qi2nYeXOY_5drops5NoisyE7is_noneBJ_(ptr align 8 %self) unnamed_addr #0 !guid !167 {
start:
; call <core::option::Option<drops::Noisy>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtCsh0Qi2nYeXOY_5drops5NoisyE7is_someBJ_(ptr align 8 %self) #21
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::option::Option<drops::Noisy>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtCsh0Qi2nYeXOY_5drops5NoisyE7is_someBJ_(ptr align 8 %self) unnamed_addr #0 !guid !168 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_2 to i1
  br i1 %5, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !169 {
start:
  %_0 = alloca [8 x i8], align 4
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i32, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %x, ptr %5, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3
  %6 = load ptr, ptr %self, align 8
  %7 = ptrtoint ptr %6 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb5, label %bb4

bb5:                                              ; preds = %bb6
; call core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsh0Qi2nYeXOY_5drops(ptr align 8 %self)
  br label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %10 = load i32, ptr %_0, align 4
  %11 = getelementptr inbounds i8, ptr %_0, i64 4
  %12 = load i32, ptr %11, align 4
  %13 = insertvalue { i32, i32 } poison, i32 %10, 0
  %14 = insertvalue { i32, i32 } %13, i32 %12, 1
  ret { i32, i32 } %14

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !170 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !171 {
start:
; call <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCsh0Qi2nYeXOY_5drops(ptr align 8 %self) #21
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::mem::manually_drop::ManuallyDrop<drops::main::{closure#2}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsh0Qi2nYeXOY_5drops4mains0_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !172 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<drops::main::{closure#2}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsh0Qi2nYeXOY_5drops4mains0_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<drops::main::{closure#3}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsh0Qi2nYeXOY_5drops4mains1_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !173 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<drops::main::{closure#3}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsh0Qi2nYeXOY_5drops4mains1_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>>::new
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtB19_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEE3newB1Z_(ptr align 8 %x) unnamed_addr #1 !guid !174 {
start:
  ret ptr %x
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtB19_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEE6as_mutB1Z_(ptr align 8 %self) unnamed_addr #1 !guid !175 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtB19_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEE6as_refB1Z_(ptr align 8 %self) unnamed_addr #1 !guid !176 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[drops::Noisy]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyEE3newB1G_(ptr align 8 %x.0, i64 %x.1) unnamed_addr #1 !guid !177 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[drops::Noisy]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyEE6as_mutB1G_(ptr align 8 %self) unnamed_addr #1 !guid !178 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[drops::Noisy]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyEE6as_refB1G_(ptr align 8 %self) unnamed_addr #1 !guid !179 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<drops::main::{closure#2}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsh0Qi2nYeXOY_5drops4mains0_0E3newB18_() unnamed_addr #1 !guid !180 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<drops::main::{closure#2}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsh0Qi2nYeXOY_5drops4mains0_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !181 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<drops::main::{closure#3}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsh0Qi2nYeXOY_5drops4mains1_0E3newB18_() unnamed_addr #1 !guid !182 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<drops::main::{closure#3}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsh0Qi2nYeXOY_5drops4mains1_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !183 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<drops::Noisy>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtCsh0Qi2nYeXOY_5drops5NoisyE3newB16_(ptr %x.0, i64 %x.1) unnamed_addr #1 !guid !184 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<u32>>::new
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCsh0Qi2nYeXOY_5drops(i32 %x) unnamed_addr #1 !guid !185 {
start:
  ret i32 %x
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsh0Qi2nYeXOY_5drops(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !186 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsh0Qi2nYeXOY_5drops() #21
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsh0Qi2nYeXOY_5drops(i64 %align, ptr align 8 %0) #26
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsh0Qi2nYeXOY_5drops(i64 %self) unnamed_addr #0 !guid !187 {
start:
  ret i64 %self
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !188 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsh0Qi2nYeXOY_5drops(i64 %_3) #21
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #21
  ret ptr %_0
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsh0Qi2nYeXOY_5drops(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !189 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsh0Qi2nYeXOY_5drops(i64 %size, i64 %alignment, ptr align 8 %0) #26
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !190 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !191 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsh0Qi2nYeXOY_5drops(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !192 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsh0Qi2nYeXOY_5drops(i64 %3, i64 %5, i1 zeroext %8) #21
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsh0Qi2nYeXOY_5drops(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !193 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsh0Qi2nYeXOY_5drops(ptr %2, i64 %4, i64 %6) #21
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsh0Qi2nYeXOY_5drops(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !194 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #21
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsh0Qi2nYeXOY_5drops(i64 %11, i64 %13) #21
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsh0Qi2nYeXOY_5drops(i64 %15, i64 %17) #21
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #21
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #21
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #21
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #21
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #21
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsh0Qi2nYeXOY_5drops(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !195 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsh0Qi2nYeXOY_5drops(ptr %ptr, i64 %3, i64 %5) #21
  br label %bb3
}

; <alloc::raw_vec::RawVec<drops::Noisy>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !196 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<drops::Noisy>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCsh0Qi2nYeXOY_5drops5NoisyEBG_(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr %ptr, i64 %capacity2) #21
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<drops::Noisy>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyE3ptrBO_(ptr align 8 %self) unnamed_addr #0 !guid !197 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<drops::Noisy>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCsh0Qi2nYeXOY_5drops5NoisyEBY_(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<drops::Noisy>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyE8capacityBO_(ptr align 8 %self) unnamed_addr #0 !guid !198 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 16) #21
  ret i64 %_0
}

; <core::ptr::unique::Unique<dyn core::any::Any>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_3any3AnyEL_E6as_ptrCsh0Qi2nYeXOY_5drops(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !199 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <core::ptr::unique::Unique<drops::Noisy>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCsh0Qi2nYeXOY_5drops5NoisyE15as_non_null_ptrBS_(ptr %self) unnamed_addr #0 !guid !200 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<[drops::Noisy]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCsh0Qi2nYeXOY_5drops5NoisyE6as_ptrBT_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !201 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::non_null::NonNull<core::option::Option<u32>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionmEE8from_refCsh0Qi2nYeXOY_5drops(ptr align 4 %r) unnamed_addr #0 !guid !202 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::rc::RcInner<drops::Noisy>>>::from_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE8from_mutB1v_(ptr align 8 %r) unnamed_addr #0 !guid !203 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::vec::Vec<drops::Noisy>>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEE13new_uncheckedB1s_(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !204 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsh0Qi2nYeXOY_5drops() #21
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCsh0Qi2nYeXOY_5drops(ptr %ptr, ptr align 8 %0) #26
  br label %bb3
}

; <core::ptr::non_null::NonNull<&std::panic::PanicHookInfo>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoE8from_refCsh0Qi2nYeXOY_5drops(ptr align 8 %r) unnamed_addr #0 !guid !205 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsh0Qi2nYeXOY_5drops(ptr %r) unnamed_addr #0 !guid !206 {
start:
  ret ptr %r
}

; <alloc::rc::Weak<drops::Noisy, &alloc::alloc::Global>>::inner
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs1c_NtCs7CppTae75M1_5alloc2rcINtB6_4WeakNtCsh0Qi2nYeXOY_5drops5NoisyRNtNtB8_5alloc6GlobalE5innerBI_(ptr align 8 %self) unnamed_addr #0 !guid !207 {
start:
  %_0 = alloca [16 x i8], align 8
  %_5 = load ptr, ptr %self, align 8
; call alloc::rc::is_dangling::<alloc::rc::RcInner<drops::Noisy>>
  %_2 = call zeroext i1 @_RINvNtCs7CppTae75M1_5alloc2rc11is_danglingINtB2_7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEBU_(ptr %_5)
  br i1 %_2, label %bb3, label %bb4

bb4:                                              ; preds = %start
  %_8 = load ptr, ptr %self, align 8
  %_10 = getelementptr inbounds i8, ptr %_8, i64 8
  store ptr %_10, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8, ptr %0, align 8
  br label %bb6

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb4
  %1 = load ptr, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load ptr, ptr %2, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %1, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %3, 1
  ret { ptr, ptr } %5
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsh0Qi2nYeXOY_5drops(i64 %val) unnamed_addr #0 !guid !208 {
start:
  ret i64 %val
}

; <alloc::raw_vec::RawVec<drops::Noisy>>::grow_one
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyE8grow_oneBO_(ptr align 8 %self) unnamed_addr #2 !guid !209 {
start:
; call <alloc::raw_vec::RawVecInner>::grow_one
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneB7_(ptr align 8 %self, i64 8, i64 16) #21
  ret void
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !210 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsh0Qi2nYeXOY_5drops(ptr %s.0, i64 %s.1) #21
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <alloc::rc::Rc<drops::Noisy>>::from_inner
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs5_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE10from_innerBF_(ptr %ptr) unnamed_addr #0 !guid !211 {
start:
; call <alloc::rc::Rc<drops::Noisy>>::from_inner_in
  %_0 = call ptr @_RNvMs6_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE13from_inner_inBF_(ptr %ptr) #21
  ret ptr %_0
}

; <alloc::rc::Rc<drops::Noisy>>::from_inner_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs6_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE13from_inner_inBF_(ptr %ptr) unnamed_addr #0 !guid !212 {
start:
  ret ptr %ptr
}

; <alloc::rc::Rc<drops::Noisy>>::drop_slow
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RNvMs6_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE9drop_slowBF_(ptr align 8 %self) unnamed_addr #2 personality ptr @rust_eh_personality !guid !213 {
start:
  %0 = alloca [16 x i8], align 8
  %_weak = alloca [16 x i8], align 8
  %_3 = load ptr, ptr %self, align 8
  %_4 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_3, ptr %_weak, align 8
  %1 = getelementptr inbounds i8, ptr %_weak, i64 8
  store ptr %_4, ptr %1, align 8
  %_9 = load ptr, ptr %self, align 8
  br label %bb1

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::rc::Weak<drops::Noisy, &alloc::alloc::Global>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc2rc4WeakNtCsh0Qi2nYeXOY_5drops5NoisyRNtNtBG_5alloc6GlobalEEB1a_(ptr align 8 %_weak) #19
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb4

bb1:                                              ; preds = %start
  %_7 = getelementptr inbounds i8, ptr %_9, i64 16
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %_7)
          to label %_RINvNtCsl10jNU3mE6R_4core3ptr13drop_in_placeNtCsh0Qi2nYeXOY_5drops5NoisyEBI_.exit unwind label %cleanup

_RINvNtCsl10jNU3mE6R_4core3ptr13drop_in_placeNtCsh0Qi2nYeXOY_5drops5NoisyEBI_.exit: ; preds = %bb1
  br label %bb2

bb2:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr13drop_in_placeNtCsh0Qi2nYeXOY_5drops5NoisyEBI_.exit
; call core::ptr::drop_glue::<alloc::rc::Weak<drops::Noisy, &alloc::alloc::Global>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc2rc4WeakNtCsh0Qi2nYeXOY_5drops5NoisyRNtNtBG_5alloc6GlobalEEB1a_(ptr align 8 %_weak)
  ret void

terminate:                                        ; preds = %bb4
  %6 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb5:                                              ; preds = %bb4
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = insertvalue { ptr, i32 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i32 } %10, i32 %9, 1
  resume { ptr, i32 } %11
}

; <alloc::rc::Rc<drops::Noisy>>::new
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMs7_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE3newBF_(ptr %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !214 {
start:
  %2 = alloca [16 x i8], align 8
  %_4.i = alloca [1 x i8], align 1
  %3 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_5 = alloca [32 x i8], align 8
  %value = alloca [16 x i8], align 8
  store ptr %0, ptr %value, align 8
  %4 = getelementptr inbounds i8, ptr %value, i64 8
  store i64 %1, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
; invoke <core::cell::Cell<usize>>::new
  %_6 = invoke i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3newCs7CppTae75M1_5alloc(i64 1)
          to label %bb1 unwind label %cleanup

bb9:                                              ; preds = %cleanup.body
  %5 = load i8, ptr %_9, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb8, label %bb7

cleanup:                                          ; preds = %bb5, %bb4, %bb3, %bb1, %start
  %7 = landingpad { ptr, i32 }
          cleanup
  br label %cleanup.body

cleanup.body:                                     ; preds = %bb2.i, %cleanup
  %eh.lpad-body = phi { ptr, i32 } [ %7, %cleanup ], [ %25, %bb2.i ]
  %8 = extractvalue { ptr, i32 } %eh.lpad-body, 0
  %9 = extractvalue { ptr, i32 } %eh.lpad-body, 1
  store ptr %8, ptr %3, align 8
  %10 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb9

bb1:                                              ; preds = %start
; invoke <core::cell::Cell<usize>>::new
  %_7 = invoke i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3newCs7CppTae75M1_5alloc(i64 1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
  %_8.0 = load ptr, ptr %value, align 8
  %11 = getelementptr inbounds i8, ptr %value, i64 8
  %_8.1 = load i64, ptr %11, align 8
  store i64 %_6, ptr %_5, align 8
  %12 = getelementptr inbounds i8, ptr %_5, i64 8
  store i64 %_7, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %_5, i64 16
  store ptr %_8.0, ptr %13, align 8
  %14 = getelementptr inbounds i8, ptr %13, i64 8
  store i64 %_8.1, ptr %14, align 8
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; invoke alloc::boxed::box_new_uninit
  %_3.i = invoke ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsh0Qi2nYeXOY_5drops(i64 8, i64 32)
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxINtNtB4_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE3newBZ_.exit unwind label %cleanup.i

cleanup.i:                                        ; preds = %bb2
  %15 = landingpad { ptr, i32 }
          cleanup
  %16 = extractvalue { ptr, i32 } %15, 0
  %17 = extractvalue { ptr, i32 } %15, 1
  store ptr %16, ptr %2, align 8
  %18 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %17, ptr %18, align 8
  %19 = load i8, ptr %_4.i, align 1
  %20 = trunc nuw i8 %19 to i1
  br i1 %20, label %bb3.i, label %bb2.i

bb2.i:                                            ; preds = %bb3.i, %cleanup.i
  %21 = load ptr, ptr %2, align 8
  %22 = getelementptr inbounds i8, ptr %2, i64 8
  %23 = load i32, ptr %22, align 8
  %24 = insertvalue { ptr, i32 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i32 } %24, i32 %23, 1
  br label %cleanup.body

bb3.i:                                            ; preds = %cleanup.i
; invoke core::ptr::drop_glue::<alloc::rc::RcInner<drops::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1d_(ptr align 8 %_5) #19
          to label %bb2.i unwind label %terminate.i

terminate.i:                                      ; preds = %bb3.i
  %26 = landingpad { ptr, i32 }
          cleanup
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxINtNtB4_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE3newBZ_.exit: ; preds = %bb2
  store i8 0, ptr %_4.i, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3.i, ptr align 8 %_5, i64 32, i1 false)
  br label %bb3

bb3:                                              ; preds = %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxINtNtB4_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE3newBZ_.exit
; invoke <alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>::leak
  %_3 = invoke align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtB7_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE4leakB12_(ptr align 8 %_3.i)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke <&mut alloc::rc::RcInner<drops::Noisy> as core::convert::Into<core::ptr::non_null::NonNull<alloc::rc::RcInner<drops::Noisy>>>>::into
  %_2 = invoke ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertQINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEINtB5_4IntoINtNtNtB7_3ptr8non_null7NonNullBz_EE4intoB1b_(ptr align 8 %_3, ptr align 8 @alloc_8005914618fe4afe560b492233173351)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
; invoke <alloc::rc::Rc<drops::Noisy>>::from_inner
  %_0 = invoke ptr @_RNvMs5_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE10from_innerBF_(ptr %_2)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  ret ptr %_0

bb7:                                              ; preds = %bb8, %bb9
  %27 = load ptr, ptr %3, align 8
  %28 = getelementptr inbounds i8, ptr %3, i64 8
  %29 = load i32, ptr %28, align 8
  %30 = insertvalue { ptr, i32 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i32 } %30, i32 %29, 1
  resume { ptr, i32 } %31

bb8:                                              ; preds = %bb9
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %value) #19
          to label %bb7 unwind label %terminate

terminate:                                        ; preds = %bb8
  %32 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable
}

; <alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtB7_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE23into_raw_with_allocatorB12_(ptr align 8 %b) unnamed_addr #0 !guid !215 {
start:
  %b1 = alloca [8 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>>::new
  %_2.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtB19_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEE3newB1Z_(ptr align 8 %b)
  store ptr %_2.i, ptr %b1, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>>::as_mut
  %_0.i2 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtB19_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEE6as_mutB1Z_(ptr align 8 %b1)
  %_11 = load ptr, ptr %_0.i2, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtB19_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEE6as_refB1Z_(ptr align 8 %b1)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 8
  ret ptr %_11
}

; <alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>::leak
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtB7_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE4leakB12_(ptr align 8 %b) unnamed_addr #0 !guid !216 {
start:
; call <alloc::boxed::Box<alloc::rc::RcInner<drops::Noisy>>>::into_raw_with_allocator
  %_4 = call ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtB7_2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE23into_raw_with_allocatorB12_(ptr align 8 %b) #21
; call core::mem::forget::<alloc::alloc::Global>
  call void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetNtNtCs7CppTae75M1_5alloc5alloc6GlobalECsddYV2PBJW9h_3std() #21
  ret ptr %_4
}

; <alloc::boxed::Box<[drops::Noisy]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyE23into_raw_with_allocatorBK_(ptr align 8 %b.0, i64 %b.1) unnamed_addr #0 !guid !217 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[drops::Noisy]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyEE3newB1G_(ptr align 8 %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[drops::Noisy]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyEE6as_mutB1G_(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[drops::Noisy]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyEE6as_refB1G_(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <core::cell::Cell<usize>>::set
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3setCsh0Qi2nYeXOY_5drops(ptr align 8 %self, i64 %val) unnamed_addr #0 !guid !218 {
start:
; call <core::cell::Cell<usize>>::replace
  %_3 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE7replaceCsh0Qi2nYeXOY_5drops(ptr align 8 %self, i64 %val) #21
  ret void
}

; <core::cell::Cell<usize>>::replace
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE7replaceCsh0Qi2nYeXOY_5drops(ptr align 8 %self, i64 %val) unnamed_addr #0 personality ptr @rust_eh_personality !guid !219 {
start:
  %_7 = alloca [1 x i8], align 1
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_7, align 1
; call core::mem::replace::<usize>
  %_0 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem7replacejECs2d0hS33vDhg_5gimli(ptr align 8 %self, i64 %val) #21
  br label %bb2

bb2:                                              ; preds = %bb1
  ret i64 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::cell::Cell<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3getCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !220 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csh0Qi2nYeXOY_5drops(ptr %self) unnamed_addr #0 !guid !221 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <alloc::vec::Vec<drops::Noisy>>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE4pushBH_(ptr align 8 %self, ptr %value.0, i64 %value.1) unnamed_addr #0 !guid !222 {
start:
; call <alloc::vec::Vec<drops::Noisy>>::push_mut
  %_3 = call align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE8push_mutBH_(ptr align 8 %self, ptr %value.0, i64 %value.1) #21
  ret void
}

; <alloc::vec::Vec<drops::Noisy>>::push_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE8push_mutBH_(ptr align 8 %self, ptr %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !223 {
start:
  %2 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %value = alloca [16 x i8], align 8
  store ptr %0, ptr %value, align 8
  %3 = getelementptr inbounds i8, ptr %value, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  %4 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %4, align 8
; invoke <alloc::raw_vec::RawVec<drops::Noisy>>::capacity
  %_5 = invoke i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyE8capacityBO_(ptr align 8 %self)
          to label %bb1 unwind label %cleanup

bb9:                                              ; preds = %cleanup
  %5 = load i8, ptr %_13, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb8, label %bb7

cleanup:                                          ; preds = %bb3, %bb2, %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %2, align 8
  %10 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb9

bb1:                                              ; preds = %start
  %_4 = icmp eq i64 %len, %_5
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb10, %bb1
; invoke <alloc::vec::Vec<drops::Noisy>>::as_mut_ptr
  %_10 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE10as_mut_ptrBG_(ptr align 8 %self)
          to label %bb4 unwind label %cleanup

bb2:                                              ; preds = %bb1
; invoke <alloc::raw_vec::RawVec<drops::Noisy>>::grow_one
  invoke void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyE8grow_oneBO_(ptr align 8 %self)
          to label %bb10 unwind label %cleanup

bb10:                                             ; preds = %bb2
  br label %bb3

bb4:                                              ; preds = %bb3
  %_0.i = getelementptr inbounds nuw %Noisy, ptr %_10, i64 %len
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_13, align 1
  %_12.0 = load ptr, ptr %value, align 8
  %11 = getelementptr inbounds i8, ptr %value, i64 8
  %_12.1 = load i64, ptr %11, align 8
  store ptr %_12.0, ptr %_0.i, align 8
  %12 = getelementptr inbounds i8, ptr %_0.i, i64 8
  store i64 %_12.1, ptr %12, align 8
  br label %bb6

bb6:                                              ; preds = %bb5
  %13 = getelementptr inbounds i8, ptr %self, i64 16
  %14 = add i64 %len, 1
  store i64 %14, ptr %13, align 8
  ret ptr %_0.i

bb7:                                              ; preds = %bb8, %bb9
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds i8, ptr %2, i64 8
  %17 = load i32, ptr %16, align 8
  %18 = insertvalue { ptr, i32 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i32 } %18, i32 %17, 1
  resume { ptr, i32 } %19

bb8:                                              ; preds = %bb9
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %value) #19
          to label %bb7 unwind label %terminate

terminate:                                        ; preds = %bb8
  %20 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csh0Qi2nYeXOY_5drops(i8 %0) unnamed_addr #0 !guid !224 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csh0Qi2nYeXOY_5drops(ptr %self) #21
  ret i32 %_0
}

; <core::cell::BorrowRefMut>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMsP_NtCsl10jNU3mE6R_4core4cellNtB5_12BorrowRefMut3newCsh0Qi2nYeXOY_5drops(ptr align 8 %borrow) unnamed_addr #0 !guid !225 {
start:
  %_0 = alloca [8 x i8], align 8
; call <core::cell::Cell<isize>>::get
  %_2 = call i64 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE3getCsddYV2PBJW9h_3std(ptr align 8 %borrow) #21
  %0 = icmp eq i64 %_2, 0
  br i1 %0, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::cell::Cell<isize>>::replace
  %_3 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE7replaceCsddYV2PBJW9h_3std(ptr align 8 %borrow, i64 -1) #21
  store ptr %borrow, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3
  %1 = load ptr, ptr %_0, align 8
  ret ptr %1
}

; <alloc::vec::Vec<drops::Noisy>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE10as_mut_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !226 {
start:
; call <alloc::raw_vec::RawVec<drops::Noisy>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyE3ptrBO_(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::vec::Vec<drops::Noisy>>::try_remove
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE10try_removeBG_(ptr align 8 %self, i64 %index) unnamed_addr #1 personality ptr @rust_eh_personality !guid !227 {
start:
  %_9.i = alloca [1 x i8], align 1
  %0 = alloca [16 x i8], align 8
  %_19 = alloca [1 x i8], align 1
  %ret = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  store i8 0, ptr %_19, align 1
; call <alloc::vec::Vec<drops::Noisy>>::len
  %len = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE3lenBG_(ptr align 8 %self) #21
  %_5 = icmp uge i64 %index, %len
  br i1 %_5, label %bb2, label %bb3

bb3:                                              ; preds = %start
; invoke <alloc::vec::Vec<drops::Noisy>>::as_mut_ptr
  %_8 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE10as_mut_ptrBG_(ptr align 8 %self)
          to label %bb4 unwind label %cleanup

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb10

bb13:                                             ; preds = %cleanup
  %1 = load i8, ptr %_19, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb12, label %bb11

cleanup:                                          ; preds = %bb7, %bb8, %bb3
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb13

bb4:                                              ; preds = %bb3
  %_0.i2 = getelementptr inbounds nuw %Noisy, ptr %_8, i64 %index
  br label %bb5

bb5:                                              ; preds = %bb4
  %_0.0.i = load ptr, ptr %_0.i2, align 8
  %7 = getelementptr inbounds i8, ptr %_0.i2, i64 8
  %_0.1.i = load i64, ptr %7, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %_0.0.i, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %_0.1.i, 1
  br label %bb6

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, i64 } %9, 0
  %_9.1 = extractvalue { ptr, i64 } %9, 1
  store i8 1, ptr %_19, align 1
  store ptr %_9.0, ptr %ret, align 8
  %10 = getelementptr inbounds i8, ptr %ret, i64 8
  store i64 %_9.1, ptr %10, align 8
  %_0.i = getelementptr inbounds nuw %Noisy, ptr %_0.i2, i64 1
  br label %bb7

bb7:                                              ; preds = %bb6
  %_15 = sub i64 %len, %index
  %_14 = sub i64 %_15, 1
; invoke core::ub_checks::check_language_ub
  %_4.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsh0Qi2nYeXOY_5drops() #21
          to label %_4.i.noexc unwind label %cleanup

_4.i.noexc:                                       ; preds = %bb7
  br i1 %_4.i1, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr4copyNtCsh0Qi2nYeXOY_5drops5NoisyEBy_.exit

bb2.i:                                            ; preds = %_4.i.noexc
  %11 = icmp eq i64 %_14, 0
  %12 = zext i1 %11 to i8
  store i8 %12, ptr %_9.i, align 1
  %13 = load i8, ptr %_9.i, align 1
  %14 = trunc nuw i8 %13 to i1
; call core::ptr::copy::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr4copy18precondition_checkCsh0Qi2nYeXOY_5drops(ptr %_0.i, ptr %_0.i2, i64 8, i1 zeroext %14, ptr align 8 @alloc_9c04098d1f5b2a23ccf9ca333796c0a8) #26
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr4copyNtCsh0Qi2nYeXOY_5drops5NoisyEBy_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr4copyNtCsh0Qi2nYeXOY_5drops5NoisyEBy_.exit: ; preds = %_4.i.noexc, %bb2.i
  %15 = mul nuw nsw i64 16, %_14
  call void @llvm.memmove.p0.p0.i64(ptr align 8 %_0.i2, ptr align 8 %_0.i, i64 %15, i1 false)
  br label %bb8

bb8:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr4copyNtCsh0Qi2nYeXOY_5drops5NoisyEBy_.exit
  %_17 = sub i64 %len, 1
; invoke <alloc::vec::Vec<drops::Noisy>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE7set_lenBG_(ptr align 8 %self, i64 %_17)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_19, align 1
  %_18.0 = load ptr, ptr %ret, align 8
  %16 = getelementptr inbounds i8, ptr %ret, i64 8
  %_18.1 = load i64, ptr %16, align 8
  store ptr %_18.0, ptr %_0, align 8
  %17 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_18.1, ptr %17, align 8
  store i8 0, ptr %_19, align 1
  br label %bb10

bb10:                                             ; preds = %bb2, %bb9
  %18 = load ptr, ptr %_0, align 8
  %19 = getelementptr inbounds i8, ptr %_0, i64 8
  %20 = load i64, ptr %19, align 8
  %21 = insertvalue { ptr, i64 } poison, ptr %18, 0
  %22 = insertvalue { ptr, i64 } %21, i64 %20, 1
  ret { ptr, i64 } %22

bb11:                                             ; preds = %bb12, %bb13
  %23 = load ptr, ptr %0, align 8
  %24 = getelementptr inbounds i8, ptr %0, i64 8
  %25 = load i32, ptr %24, align 8
  %26 = insertvalue { ptr, i32 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i32 } %26, i32 %25, 1
  resume { ptr, i32 } %27

bb12:                                             ; preds = %bb13
; invoke core::ptr::drop_glue::<drops::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsh0Qi2nYeXOY_5drops5NoisyEBD_(ptr align 8 %ret) #19
          to label %bb11 unwind label %terminate

terminate:                                        ; preds = %bb12
  %28 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable
}

; <alloc::vec::Vec<drops::Noisy>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !228 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCsh0Qi2nYeXOY_5drops(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #26
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<drops::Noisy>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) #21
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<drops::Noisy>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE3lenBG_(ptr align 8 %self) unnamed_addr #0 !guid !229 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 576460752303423487
  ret i64 %len
}

; <alloc::vec::Vec<drops::Noisy>>::remove
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE6removeBG_(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 !guid !230 {
start:
  %_3 = alloca [16 x i8], align 8
; call <alloc::vec::Vec<drops::Noisy>>::try_remove
  %1 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE10try_removeBG_(ptr align 8 %self, i64 %index)
  %2 = extractvalue { ptr, i64 } %1, 0
  %3 = extractvalue { ptr, i64 } %1, 1
  store ptr %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %5 = load ptr, ptr %_3, align 8
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = ptrtoint ptr %5 to i64
  %9 = icmp eq i64 %8, 0
  %_4 = select i1 %9, i64 0, i64 1
  %10 = trunc nuw i64 %_4 to i1
  br i1 %10, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %elem.0 = load ptr, ptr %_3, align 8
  %11 = getelementptr inbounds i8, ptr %_3, i64 8
  %elem.1 = load i64, ptr %11, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %elem.0, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %elem.1, 1
  ret { ptr, i64 } %13

bb3:                                              ; preds = %start
; call <alloc::vec::Vec<drops::Noisy>>::len
  %_6 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE3lenBG_(ptr align 8 %self) #21
; call <alloc::vec::Vec<_, _>>::remove::assert_failed
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE6remove13assert_failed(i64 %index, i64 %_6, ptr align 8 %0) #27
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<drops::Noisy>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE7set_lenBG_(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !231 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<drops::Noisy>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE8capacityBG_(ptr align 8 %self) #21
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCsh0Qi2nYeXOY_5drops(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #26
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<drops::Noisy>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE8capacityBG_(ptr align 8 %self) unnamed_addr #0 !guid !232 {
start:
; call <alloc::raw_vec::RawVec<drops::Noisy>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyE8capacityBO_(ptr align 8 %self) #21
  ret i64 %_0
}

; <*mut drops::Noisy>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCsh0Qi2nYeXOY_5drops5Noisy10cast_sliceBG_(ptr %self, i64 %len) unnamed_addr #0 !guid !233 {
start:
; call core::ptr::slice_from_raw_parts_mut::<drops::Noisy>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCsh0Qi2nYeXOY_5drops5NoisyEBT_(ptr %self, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::rc::Rc<drops::Noisy>>::strong_count
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMsg_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE12strong_countBF_(ptr align 8 %this) unnamed_addr #0 !guid !234 {
start:
  %_4.i.i = load ptr, ptr %this, align 8
; call <alloc::rc::RcInner<drops::Noisy> as alloc::rc::RcInnerPtr>::strong
  %_0 = call i64 @_RNvYINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyENtB5_10RcInnerPtr6strongBE_(ptr align 8 %_4.i.i) #21
  ret i64 %_0
}

; <core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMss_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEE3newB1i_(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %value) unnamed_addr #0 personality ptr @rust_eh_personality !guid !235 {
start:
  %0 = alloca [16 x i8], align 8
  %1 = alloca [24 x i8], align 8
  %_2 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %value, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_2, ptr align 8 %1, i64 24, i1 false)
; invoke <core::cell::Cell<isize>>::new
  %_3 = invoke i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE3newCsddYV2PBJW9h_3std(i64 0)
          to label %bb2 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::cell::UnsafeCell<alloc::vec::Vec<drops::Noisy>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_4cell10UnsafeCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEEEB1z_(ptr align 8 %_2) #19
          to label %bb4 unwind label %terminate

cleanup:                                          ; preds = %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb3

bb2:                                              ; preds = %start
  store i64 %_3, ptr %_0, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_2, i64 24, i1 false)
  ret void

terminate:                                        ; preds = %bb3
  %7 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb4:                                              ; preds = %bb3
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12
}

; <core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>::borrow_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEE10borrow_mutB1i_(ptr align 8 %self, ptr align 8 %0) unnamed_addr #0 !guid !236 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>::try_borrow_mut
  %1 = call { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEE14try_borrow_mutB1i_(ptr align 8 %self) #21
  %2 = extractvalue { ptr, ptr } %1, 0
  %3 = extractvalue { ptr, ptr } %1, 1
  store ptr %2, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr %3, ptr %4, align 8
  %5 = load ptr, ptr %_2, align 8
  %6 = getelementptr inbounds i8, ptr %_2, i64 8
  %7 = load ptr, ptr %6, align 8
  %8 = ptrtoint ptr %5 to i64
  %9 = icmp eq i64 %8, 0
  %_3 = select i1 %9, i64 1, i64 0
  %10 = trunc nuw i64 %_3 to i1
  br i1 %10, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call core::cell::panic_already_borrowed
  call void @_RNvNtCsl10jNU3mE6R_4core4cell22panic_already_borrowed(ptr align 8 %0) #27
  unreachable

bb4:                                              ; preds = %start
  %b.0 = load ptr, ptr %_2, align 8
  %11 = getelementptr inbounds i8, ptr %_2, i64 8
  %b.1 = load ptr, ptr %11, align 8
  %12 = insertvalue { ptr, ptr } poison, ptr %b.0, 0
  %13 = insertvalue { ptr, ptr } %12, ptr %b.1, 1
  ret { ptr, ptr } %13

bb2:                                              ; No predecessors!
  unreachable
}

; <core::cell::RefCell<alloc::vec::Vec<drops::Noisy>>>::try_borrow_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMst_NtCsl10jNU3mE6R_4core4cellINtB5_7RefCellINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEE14try_borrow_mutB1i_(ptr align 8 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !237 {
start:
  %0 = alloca [16 x i8], align 8
  %b = alloca [8 x i8], align 8
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::cell::BorrowRefMut>::new
  %1 = call align 8 ptr @_RNvMsP_NtCsl10jNU3mE6R_4core4cellNtB5_12BorrowRefMut3newCsh0Qi2nYeXOY_5drops(ptr align 8 %self) #21
  store ptr %1, ptr %_2, align 8
  %2 = load ptr, ptr %_2, align 8
  %3 = ptrtoint ptr %2 to i64
  %4 = icmp eq i64 %3, 0
  %_4 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_4 to i1
  br i1 %5, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %6 = load ptr, ptr %_2, align 8
  store ptr %6, ptr %b, align 8
  %_8 = getelementptr inbounds i8, ptr %self, i64 8
  br label %bb5

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb3
  %7 = load ptr, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  %9 = load ptr, ptr %8, align 8
  %10 = insertvalue { ptr, ptr } poison, ptr %7, 0
  %11 = insertvalue { ptr, ptr } %10, ptr %9, 1
  ret { ptr, ptr } %11

bb8:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::cell::BorrowRefMut>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtB4_4cell12BorrowRefMutECsddYV2PBJW9h_3std(ptr align 8 %b) #19
          to label %bb9 unwind label %terminate

cleanup:                                          ; preds = %bb5
  %12 = landingpad { ptr, i32 }
          cleanup
  %13 = extractvalue { ptr, i32 } %12, 0
  %14 = extractvalue { ptr, i32 } %12, 1
  store ptr %13, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %14, ptr %15, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
; invoke <core::ptr::non_null::NonNull<alloc::vec::Vec<drops::Noisy>>>::new_unchecked
  %value = invoke ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEE13new_uncheckedB1s_(ptr %_8, ptr align 8 @alloc_98f5b470f40a597b568a6efe978d8c0e)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  %_10 = load ptr, ptr %b, align 8
  store ptr %value, ptr %_0, align 8
  %16 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_10, ptr %16, align 8
  br label %bb7

terminate:                                        ; preds = %bb8
  %17 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb9:                                              ; preds = %bb8
  %18 = load ptr, ptr %0, align 8
  %19 = getelementptr inbounds i8, ptr %0, i64 8
  %20 = load i32, ptr %19, align 8
  %21 = insertvalue { ptr, i32 } poison, ptr %18, 0
  %22 = insertvalue { ptr, i32 } %21, i32 %20, 1
  resume { ptr, i32 } %22

bb2:                                              ; No predecessors!
  unreachable
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsh0Qi2nYeXOY_5drops(i64 %0, i64 %1) unnamed_addr #0 !guid !238 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #28
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #28
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsh0Qi2nYeXOY_5drops(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !239 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #28
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsh0Qi2nYeXOY_5drops(i64 %0, i64 %1) unnamed_addr #0 !guid !240 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #28
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #28
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsh0Qi2nYeXOY_5drops(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !241 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsh0Qi2nYeXOY_5drops(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #21
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #25
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #21
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsh0Qi2nYeXOY_5drops() unnamed_addr #4 !guid !242 {
start:
  ret void
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCsh0Qi2nYeXOY_5drops(ptr %ptr, i64 %align) unnamed_addr #0 !guid !243 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCsh0Qi2nYeXOY_5drops(ptr %ptr, i64 %align) #21
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsh0Qi2nYeXOY_5drops() unnamed_addr #0 !guid !244 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsh0Qi2nYeXOY_5drops() #21
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsh0Qi2nYeXOY_5drops(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !245 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCsh0Qi2nYeXOY_5drops(ptr %ptr, i64 %align) #21
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr %ptr) #21
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsh0Qi2nYeXOY_5drops(i64 %align, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !246 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsh0Qi2nYeXOY_5drops(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !247 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCsh0Qi2nYeXOY_5drops(ptr %ptr, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !248 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullB6_(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCsh0Qi2nYeXOY_5drops(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !249 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCsh0Qi2nYeXOY_5drops(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !250 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; core::ptr::copy::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr4copy18precondition_checkCsh0Qi2nYeXOY_5drops(ptr %src, ptr %dst, i64 %align, i1 zeroext %zero_size, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !251 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsh0Qi2nYeXOY_5drops(ptr %src, i64 %align, i1 zeroext %zero_size)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_5ee6cd0de5bab89c84438a39fb5fb08c, i64 221)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsh0Qi2nYeXOY_5drops(ptr %dst, i64 %align, i1 zeroext %zero_size)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsh0Qi2nYeXOY_5drops(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !252 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsh0Qi2nYeXOY_5drops(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCsh0Qi2nYeXOY_5drops(ptr %ptr, i64 %align) unnamed_addr #0 !guid !253 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr %ptr, i64 %align) #21
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsh0Qi2nYeXOY_5drops() unnamed_addr #0 !guid !254 {
start:
  ret i1 true
}

; <drops::Noisy as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXCsh0Qi2nYeXOY_5dropsNtB2_5NoisyNtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4drop(ptr align 8 %self) unnamed_addr #1 !guid !255 {
start:
  %_7 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_7, ptr align 8 %self) #21
  %0 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %_7, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 1>
  %1 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_EB8_(ptr @alloc_88523646262c2465cd77855ffd6da4ff, ptr align 8 %args) #21
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_3.0, ptr %_3.1)
  ret void
}

; <drops::Noisy as core::any::Any>::type_id
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtCsl10jNU3mE6R_4core3anyNtCsh0Qi2nYeXOY_5drops5NoisyNtB2_3Any7type_idBt_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !256 {
start:
; call <core::any::TypeId>::of::<drops::Noisy>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtCsh0Qi2nYeXOY_5drops5NoisyEBM_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsh0Qi2nYeXOY_5drops(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !257 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsh0Qi2nYeXOY_5drops(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #21
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsh0Qi2nYeXOY_5drops(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !258 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsh0Qi2nYeXOY_5drops(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<drops::Noisy> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsh0Qi2nYeXOY_5drops5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %self) unnamed_addr #1 !guid !259 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 8, i64 16)
  ret void
}

; <&mut alloc::rc::RcInner<drops::Noisy> as core::convert::Into<core::ptr::non_null::NonNull<alloc::rc::RcInner<drops::Noisy>>>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertQINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEINtB5_4IntoINtNtNtB7_3ptr8non_null7NonNullBz_EE4intoB1b_(ptr align 8 %self, ptr align 8 %0) unnamed_addr #0 !guid !260 {
start:
; call <core::ptr::non_null::NonNull<alloc::rc::RcInner<drops::Noisy>> as core::convert::From<&mut alloc::rc::RcInner<drops::Noisy>>>::from
  %_0 = call ptr @_RNvXsi_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEINtNtB9_7convert4FromQBT_E4fromB1v_(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::rc::Weak<drops::Noisy, &alloc::alloc::Global> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1d_NtCs7CppTae75M1_5alloc2rcINtB6_4WeakNtCsh0Qi2nYeXOY_5drops5NoisyRNtNtB8_5alloc6GlobalENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBI_(ptr align 8 %self) unnamed_addr #1 !guid !261 {
start:
  %_3 = alloca [16 x i8], align 8
  %inner = alloca [16 x i8], align 8
; call <alloc::rc::Weak<drops::Noisy, &alloc::alloc::Global>>::inner
  %0 = call { ptr, ptr } @_RNvMs1c_NtCs7CppTae75M1_5alloc2rcINtB6_4WeakNtCsh0Qi2nYeXOY_5drops5NoisyRNtNtB8_5alloc6GlobalE5innerBI_(ptr align 8 %self) #21
  %1 = extractvalue { ptr, ptr } %0, 0
  %2 = extractvalue { ptr, ptr } %0, 1
  store ptr %1, ptr %_3, align 8
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store ptr %2, ptr %3, align 8
  %4 = load ptr, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_5 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_5 to i1
  br i1 %9, label %bb2, label %bb9

bb2:                                              ; preds = %start
  %inner.0 = load ptr, ptr %_3, align 8
  %10 = getelementptr inbounds i8, ptr %_3, i64 8
  %inner.1 = load ptr, ptr %10, align 8
  store ptr %inner.0, ptr %inner, align 8
  %11 = getelementptr inbounds i8, ptr %inner, i64 8
  store ptr %inner.1, ptr %11, align 8
; call <alloc::rc::WeakInner as alloc::rc::RcInnerPtr>::dec_weak
  call void @_RNvYNtNtCs7CppTae75M1_5alloc2rc9WeakInnerNtB4_10RcInnerPtr8dec_weakCsh0Qi2nYeXOY_5drops(ptr align 8 %inner) #21
; call <alloc::rc::WeakInner as alloc::rc::RcInnerPtr>::weak
  %_10 = call i64 @_RNvYNtNtCs7CppTae75M1_5alloc2rc9WeakInnerNtB4_10RcInnerPtr4weakCsh0Qi2nYeXOY_5drops(ptr align 8 %inner) #21
  %_9 = icmp eq i64 %_10, 0
  br i1 %_9, label %bb5, label %bb9

bb9:                                              ; preds = %bb5, %bb2, %start
  ret void

bb5:                                              ; preds = %bb2
  %_13 = getelementptr inbounds i8, ptr %self, i64 8
  %_15 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<alloc::rc::RcInner<drops::Noisy>>>::cast::<u8>
  %_14 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE4casthEB1w_(ptr %_15) #21
  %_19 = load ptr, ptr %self, align 8
; call <core::alloc::layout::Layout>::for_value_raw::<alloc::rc::RcInner<drops::Noisy>>
  %12 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEB1G_(ptr %_19) #21
  %_16.0 = extractvalue { i64, i64 } %12, 0
  %_16.1 = extractvalue { i64, i64 } %12, 1
; call <&alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs0_NtCsl10jNU3mE6R_4core5allocRNtNtCs7CppTae75M1_5alloc5alloc6GlobalNtB5_9Allocator10deallocateCsddYV2PBJW9h_3std(ptr align 8 %_13, ptr %_14, i64 %_16.0, i64 %_16.1) #21
  br label %bb9

bb10:                                             ; No predecessors!
  unreachable
}

; <&std::panic::PanicHookInfo as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoNtB6_7Display3fmtCsh0Qi2nYeXOY_5drops(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !262 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <std::panic::PanicHookInfo as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXs_NtCsddYV2PBJW9h_3std5panicNtB4_13PanicHookInfoNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::alloc::Global as core::clone::Clone>::clone
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneCsh0Qi2nYeXOY_5drops(ptr %self) unnamed_addr #0 !guid !263 {
start:
  ret void
}

; <alloc::boxed::Box<dyn core::any::Any> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyEL_ENtNtNtBM_3ops4drop4Drop4dropCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !264 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<dyn core::any::Any>>::as_ptr
  %1 = call { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_3any3AnyEL_E6as_ptrCsh0Qi2nYeXOY_5drops(ptr %ptr.0, ptr align 8 %ptr.1) #21
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<dyn core::any::Any>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_3any3AnyEL_ECsh0Qi2nYeXOY_5drops(ptr %_5.0, ptr align 8 %_5.1) #21
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<dyn core::any::Any>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_3any3AnyEL_E4casthECsh0Qi2nYeXOY_5drops(ptr %ptr.0, ptr align 8 %ptr.1) #21
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #21
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsh0Qi2nYeXOY_5drops(ptr %_10, ptr %_11, i64 %6, i64 %8) #21
  br label %bb7
}

; <alloc::boxed::Box<[drops::Noisy]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsh0Qi2nYeXOY_5drops5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %self) unnamed_addr #0 !guid !265 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[drops::Noisy]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCsh0Qi2nYeXOY_5drops5NoisyE6as_ptrBT_(ptr %ptr.0, i64 %ptr.1) #21
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[drops::Noisy]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCsh0Qi2nYeXOY_5drops5NoisyEB17_(ptr %_5.0, i64 %_5.1) #21
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsh0Qi2nYeXOY_5drops(ptr align 8 %layout) #21
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[drops::Noisy]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCsh0Qi2nYeXOY_5drops5NoisyE4casthEBU_(ptr %ptr.0, i64 %ptr.1) #21
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #21
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsh0Qi2nYeXOY_5drops(ptr %_10, ptr %_11, i64 %6, i64 %8) #21
  br label %bb7
}

; <core::cell::RefMut<alloc::vec::Vec<drops::Noisy>> as core::ops::deref::DerefMut>::deref_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXsR_NtCsl10jNU3mE6R_4core4cellINtB5_6RefMutINtNtCs7CppTae75M1_5alloc3vec3VecNtCsh0Qi2nYeXOY_5drops5NoisyEENtNtNtB7_3ops5deref8DerefMut9deref_mutB1h_(ptr align 8 %self) unnamed_addr #0 !guid !266 {
start:
  %_3.i = load ptr, ptr %self, align 8
  ret ptr %_3.i
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsh0Qi2nYeXOY_5drops() unnamed_addr #0 !guid !267 {
start:
  ret i8 0
}

; <core::ptr::non_null::NonNull<alloc::rc::RcInner<drops::Noisy>> as core::convert::From<&mut alloc::rc::RcInner<drops::Noisy>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsi_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEEINtNtB9_7convert4FromQBT_E4fromB1v_(ptr align 8 %r) unnamed_addr #0 !guid !268 {
start:
; call <core::ptr::non_null::NonNull<alloc::rc::RcInner<drops::Noisy>>>::from_mut
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyEE8from_mutB1v_(ptr align 8 %r) #21
  ret ptr %_0
}

; <alloc::vec::Vec<drops::Noisy> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsh0Qi2nYeXOY_5drops5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %self) unnamed_addr #1 !guid !269 {
start:
; call <alloc::vec::Vec<drops::Noisy>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsh0Qi2nYeXOY_5drops5NoisyE10as_mut_ptrBG_(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut drops::Noisy>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCsh0Qi2nYeXOY_5drops5Noisy10cast_sliceBG_(ptr %_3, i64 %_4) #21
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
; call core::ptr::drop_glue::<[drops::Noisy]>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSNtCsh0Qi2nYeXOY_5drops5NoisyEBE_(ptr align 8 %_2.0, i64 %_2.1)
  ret void
}

; <alloc::rc::Rc<drops::Noisy> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsw_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBF_(ptr align 8 %self) unnamed_addr #0 !guid !270 {
start:
  %_4.i.i1 = load ptr, ptr %self, align 8
; call <alloc::rc::RcInner<drops::Noisy> as alloc::rc::RcInnerPtr>::dec_strong
  call void @_RNvYINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyENtB5_10RcInnerPtr10dec_strongBE_(ptr align 8 %_4.i.i1) #21
  %_4.i.i = load ptr, ptr %self, align 8
; call <alloc::rc::RcInner<drops::Noisy> as alloc::rc::RcInnerPtr>::strong
  %_6 = call i64 @_RNvYINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyENtB5_10RcInnerPtr6strongBE_(ptr align 8 %_4.i.i) #21
  %_5 = icmp eq i64 %_6, 0
  br i1 %_5, label %bb5, label %bb6

bb6:                                              ; preds = %bb5, %start
  ret void

bb5:                                              ; preds = %start
; call <alloc::rc::Rc<drops::Noisy>>::drop_slow
  call void @_RNvMs6_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE9drop_slowBF_(ptr align 8 %self) #23
  br label %bb6
}

; <alloc::rc::Rc<drops::Noisy> as core::clone::Clone>::clone
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsx_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyENtNtCsl10jNU3mE6R_4core5clone5Clone5cloneBF_(ptr align 8 %self) unnamed_addr #0 !guid !271 {
start:
  %_4.i.i = load ptr, ptr %self, align 8
; call <alloc::rc::RcInner<drops::Noisy> as alloc::rc::RcInnerPtr>::inc_strong
  call void @_RNvYINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyENtB5_10RcInnerPtr10inc_strongBE_(ptr align 8 %_4.i.i) #21
  %_4 = load ptr, ptr %self, align 8
  %_6 = getelementptr inbounds i8, ptr %self, i64 8
; call <alloc::alloc::Global as core::clone::Clone>::clone
  call void @_RNvXs5_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneCsh0Qi2nYeXOY_5drops(ptr %_6) #21
; call <alloc::rc::Rc<drops::Noisy>>::from_inner_in
  %_0 = call ptr @_RNvMs6_NtCs7CppTae75M1_5alloc2rcINtB5_2RcNtCsh0Qi2nYeXOY_5drops5NoisyE13from_inner_inBF_(ptr %_4) #21
  ret ptr %_0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsh0Qi2nYeXOY_5drops(ptr %_1) unnamed_addr #0 !guid !272 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <alloc::rc::RcInner<drops::Noisy> as alloc::rc::RcInnerPtr>::dec_strong
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyENtB5_10RcInnerPtr10dec_strongBE_(ptr align 8 %self) unnamed_addr #0 !guid !273 {
start:
; call <alloc::rc::RcInner<drops::Noisy> as alloc::rc::RcInnerPtr>::strong
  %_5 = call i64 @_RNvYINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyENtB5_10RcInnerPtr6strongBE_(ptr align 8 %self) #21
  %_4 = sub i64 %_5, 1
; call <core::cell::Cell<usize>>::set
  call void @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3setCsh0Qi2nYeXOY_5drops(ptr align 8 %self, i64 %_4) #21
  ret void
}

; <alloc::rc::RcInner<drops::Noisy> as alloc::rc::RcInnerPtr>::inc_strong
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyENtB5_10RcInnerPtr10inc_strongBE_(ptr align 8 %self) unnamed_addr #0 !guid !274 {
start:
  %_0.i2 = alloca [1 x i8], align 1
; call <alloc::rc::RcInner<drops::Noisy> as alloc::rc::RcInnerPtr>::strong
  %strong = call i64 @_RNvYINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyENtB5_10RcInnerPtr6strongBE_(ptr align 8 %self) #21
  %_4 = icmp ne i64 %strong, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsh0Qi2nYeXOY_5drops() #21
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsh0Qi2nYeXOY_5drops(i1 zeroext %_4, ptr align 8 @alloc_2a34b8029ddd90836b1b40ec7c0e15b5) #26
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %start, %bb2.i
  %_0.i = add i64 %strong, 1
; call <core::cell::Cell<usize>>::set
  call void @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3setCsh0Qi2nYeXOY_5drops(ptr align 8 %self, i64 %_0.i) #21
  %_9 = icmp eq i64 %_0.i, 0
  br i1 %_9, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  store i8 0, ptr %_0.i2, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  store i8 1, ptr %_0.i2, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i2, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  ret void

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  call void @llvm.trap()
  unreachable
}

; <alloc::rc::RcInner<drops::Noisy> as alloc::rc::RcInnerPtr>::strong
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvYINtNtCs7CppTae75M1_5alloc2rc7RcInnerNtCsh0Qi2nYeXOY_5drops5NoisyENtB5_10RcInnerPtr6strongBE_(ptr align 8 %self) unnamed_addr #0 !guid !275 {
start:
; call <core::cell::Cell<usize>>::get
  %_0 = call i64 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3getCsh0Qi2nYeXOY_5drops(ptr align 8 %self) #21
  ret i64 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsh0Qi2nYeXOY_5drops(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !276 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csh0Qi2nYeXOY_5drops(ptr align 8 %_1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <drops::main::{closure#1} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNCNvCsh0Qi2nYeXOY_5drops4mains_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_onceB6_(ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !277 {
start:
  %_2 = alloca [8 x i8], align 8
  %_1 = alloca [0 x i8], align 1
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call drops::main::{closure#1}
  call void @_RNCNvCsh0Qi2nYeXOY_5drops4mains_0B3_(ptr %_1, ptr align 8 %1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::rc::WeakInner as alloc::rc::RcInnerPtr>::weak
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvYNtNtCs7CppTae75M1_5alloc2rc9WeakInnerNtB4_10RcInnerPtr4weakCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !278 {
start:
  %_0.i = load ptr, ptr %self, align 8
; call <core::cell::Cell<usize>>::get
  %_0 = call i64 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3getCsh0Qi2nYeXOY_5drops(ptr align 8 %_0.i) #21
  ret i64 %_0
}

; <alloc::rc::WeakInner as alloc::rc::RcInnerPtr>::dec_weak
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNtNtCs7CppTae75M1_5alloc2rc9WeakInnerNtB4_10RcInnerPtr8dec_weakCsh0Qi2nYeXOY_5drops(ptr align 8 %self) unnamed_addr #0 !guid !279 {
start:
  %_0.i = load ptr, ptr %self, align 8
; call <alloc::rc::WeakInner as alloc::rc::RcInnerPtr>::weak
  %_5 = call i64 @_RNvYNtNtCs7CppTae75M1_5alloc2rc9WeakInnerNtB4_10RcInnerPtr4weakCsh0Qi2nYeXOY_5drops(ptr align 8 %self) #21
  %_4 = sub i64 %_5, 1
; call <core::cell::Cell<usize>>::set
  call void @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3setCsh0Qi2nYeXOY_5drops(ptr align 8 %_0.i, i64 %_4) #21
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #5

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #6

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <core::option::Option<u32> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std(ptr align 4, ptr align 8) unnamed_addr #0

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nonlazybind
define internal zeroext i1 @__rust_try(ptr %0, ptr %1, ptr %2) unnamed_addr #8 personality ptr @rust_eh_personality !guid !280 {
entry-block:
  invoke void %0(ptr %1)
          to label %then unwind label %catch

then:                                             ; preds = %entry-block
  ret i1 false

catch:                                            ; preds = %entry-block
  %3 = landingpad { ptr, i32 }
          catch ptr null
  %4 = extractvalue { ptr, i32 } %3, 0
  call void %2(ptr %1, ptr %4)
  ret i1 true
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #7

; core::ptr::drop_glue::<core::cell::BorrowRefMut>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtB4_4cell12BorrowRefMutECsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #1

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #1

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::panicking::catch_unwind::cleanup
; Function Attrs: cold minsize nonlazybind optsize uwtable
declare { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr) unnamed_addr #9

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #6

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::Arguments>::new::<11, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #6

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #6

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<10, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; std::panicking::set_hook
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std9panicking8set_hook(ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; std::panicking::take_hook
; Function Attrs: nonlazybind uwtable
declare { ptr, ptr } @_RNvNtCsddYV2PBJW9h_3std9panicking9take_hook() unnamed_addr #1

; core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2I_4SendEL_EEB1O_(ptr align 8) unnamed_addr #1

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #10

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #10

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
; Function Attrs: nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr, i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8, i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::grow_one
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneB7_(ptr align 8, i64, i64) unnamed_addr #0

; <core::cell::Cell<usize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelljE3newCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; core::mem::forget::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetNtNtCs7CppTae75M1_5alloc5alloc6GlobalECsddYV2PBJW9h_3std() unnamed_addr #0

; core::mem::replace::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3mem7replacejECs2d0hS33vDhg_5gimli(ptr align 8, i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #11

; <core::cell::Cell<isize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs8_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE3getCsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #0

; <core::cell::Cell<isize>>::replace
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE7replaceCsddYV2PBJW9h_3std(ptr align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<_, _>>::remove::assert_failed
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE6remove13assert_failed(i64, i64, ptr align 8) unnamed_addr #12

; <core::cell::Cell<isize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs7_NtCsl10jNU3mE6R_4core4cellINtB5_4CelliE3newCsddYV2PBJW9h_3std(i64) unnamed_addr #0

; core::cell::panic_already_borrowed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core4cell22panic_already_borrowed(ptr align 8) unnamed_addr #10

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #5

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #13

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #14

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #15

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #16

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr) unnamed_addr #0

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #17

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullB6_(ptr) unnamed_addr #0

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr, i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8, i64, i64) unnamed_addr #1

; <&alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs0_NtCsl10jNU3mE6R_4core5allocRNtNtCs7CppTae75M1_5alloc5alloc6GlobalNtB5_9Allocator10deallocateCsddYV2PBJW9h_3std(ptr align 8, ptr, i64, i64) unnamed_addr #0

; <std::panic::PanicHookInfo as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtCsddYV2PBJW9h_3std5panicNtB4_13PanicHookInfoNtNtCsl10jNU3mE6R_4core3fmt7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #18

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #8 !guid !281 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsh0Qi2nYeXOY_5drops(ptr @_RNvCsh0Qi2nYeXOY_5drops4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nonlazybind "target-cpu"="x86-64" }
attributes #9 = { cold minsize nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #19 = { cold }
attributes #20 = { cold noreturn nounwind }
attributes #21 = { inlinehint }
attributes #22 = { cold noinline noreturn nounwind }
attributes #23 = { noinline }
attributes #24 = { noinline noreturn nounwind }
attributes #25 = { noreturn }
attributes #26 = { inlinehint nounwind }
attributes #27 = { noinline noreturn }
attributes #28 = { nounwind }

!llvm.module.flags = !{!83, !84, !85, !86}
!llvm.ident = !{!87}

!0 = !{i64 2713702884652991415}
!1 = !{i64 -1431549995797690300}
!2 = !{i64 3231843993411654878}
!3 = !{i64 3013761185391039136}
!4 = !{i64 -3843571794548898761}
!5 = !{i64 494894172553718068}
!6 = !{i64 -4473772362188994650}
!7 = !{i64 -6433565065914892433}
!8 = !{i64 6900211186662259790}
!9 = !{i64 -7303141161090910170}
!10 = !{i64 2834923123989976019}
!11 = !{i64 -8943552645575587463}
!12 = !{i64 -4355047324745176873}
!13 = !{i64 -3550625874533682319}
!14 = !{i64 -2143082941540265039}
!15 = !{i64 8820343610142865341}
!16 = !{i64 251226169001066339}
!17 = !{i64 -6760662663152649313}
!18 = !{i64 -468882886427393738}
!19 = !{i64 -6414554778899469570}
!20 = !{i64 -7725457049182600034}
!21 = !{i64 4293894995703520050}
!22 = !{i64 -7241562218258427176}
!23 = !{i64 6455002445525107900}
!24 = !{i64 -9211746579715443110}
!25 = !{i64 7856254028511423950}
!26 = !{i64 756594377926937518}
!27 = !{i64 -7103451821143145938}
!28 = !{i64 -6368421642624452338}
!29 = !{i64 -5144234748341210715}
!30 = !{i64 7286530637988048167}
!31 = !{i64 3722869332430219103}
!32 = !{i64 7460652278581414436}
!33 = !{i64 8178045237481653572}
!34 = !{i64 -2386950111791206252}
!35 = !{i64 2954288428865157246}
!36 = !{i64 -6258423164915983147}
!37 = !{i64 934175383568658988}
!38 = !{i64 -725723571315263728}
!39 = !{i64 -3984191543079786341}
!40 = !{i64 -2426486685268185021}
!41 = !{i64 3465041385977136949}
!42 = !{i64 9177949720019104632}
!43 = !{i64 109696724465577120}
!44 = !{i64 -1838851465689220186}
!45 = !{i64 -8464893900259126186}
!46 = !{i64 -1789968606115973644}
!47 = !{i64 -1154080213957417552}
!48 = !{i64 -8484966517574050911}
!49 = !{i64 2410205346847763542}
!50 = !{i64 7528531372724898665}
!51 = !{i64 -5163357999688112328}
!52 = !{i64 821319256819709866}
!53 = !{i64 -5610092395765750073}
!54 = !{i64 7572316419836804516}
!55 = !{i64 6936933791104756948}
!56 = !{i64 -7556825608737923389}
!57 = !{i64 -2692757907668874398}
!58 = !{i64 1540917626061239440}
!59 = !{i64 7048214075933339657}
!60 = !{i64 4677318679105211589}
!61 = !{i64 -7641366434295906102}
!62 = !{i64 8976549055879526693}
!63 = !{i64 488773012087997456}
!64 = !{i64 -2551986920372366210}
!65 = !{i64 -3834640035943248477}
!66 = !{i64 4833831917786458120}
!67 = !{i64 4377760801553926525}
!68 = !{i64 2049918623992055465}
!69 = !{i64 -9027435180212630406}
!70 = !{i64 4502338513721786985}
!71 = !{i64 -1392057543789903487}
!72 = !{i64 -386403102008289983}
!73 = !{i64 -9211288703135846744}
!74 = !{i64 2860148978403951063}
!75 = !{i64 7905348958753862492}
!76 = !{i64 5208749152025153762}
!77 = !{i64 -8330385313551011965}
!78 = !{i64 2459095617970693570}
!79 = !{i64 3463499321040693703}
!80 = !{i64 427013966684172271}
!81 = !{i64 3607427422826496430}
!82 = !{i64 -2589505407708306725}
!83 = !{i32 8, !"PIC Level", i32 2}
!84 = !{i32 7, !"PIE Level", i32 2}
!85 = !{i32 2, !"RtLibUseGOT", i32 1}
!86 = !{i32 7, !"uwtable", i32 2}
!87 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!88 = !{i64 -5332217232577435295}
!89 = !{i64 4773329240078161938}
!90 = !{i64 4948084422780999525}
!91 = !{i64 -2680455919253784599}
!92 = !{i64 -6303232419952593480}
!93 = !{i64 -2528095635176460105}
!94 = !{i64 -8368629058446471946}
!95 = !{i64 -8315178913915318988}
!96 = !{i64 7707932678462250793}
!97 = !{i64 634298794793143406}
!98 = !{i64 -6096898387284786353}
!99 = !{i64 1167524656236949961}
!100 = !{i64 8019334852384349971}
!101 = !{i64 5760461300596040929}
!102 = !{i64 -4036847068514491445}
!103 = !{i64 5353463066733559222}
!104 = !{i64 1717409090890538387}
!105 = !{i64 6127266285990585319}
!106 = !{i64 3145037239381165788}
!107 = !{i64 -2318780246882007271}
!108 = !{i64 -140746754140980457}
!109 = !{i64 1007268313269664436}
!110 = !{i64 -50230182550651981}
!111 = !{i64 3821162835988504867}
!112 = !{i64 3042696143113396073}
!113 = !{i64 -6636791154216210674}
!114 = !{i64 -1869301379786180766}
!115 = !{i64 -6924314306223959565}
!116 = !{i64 969584331619286089}
!117 = !{i64 -576846977124947974}
!118 = !{i64 -7336214707356095938}
!119 = !{i64 5507628599657737321}
!120 = !{}
!121 = !{i64 8312163005203724992}
!122 = !{i64 1168724473532816088}
!123 = !{i64 -1387908501588875610}
!124 = !{i64 3322988472290041670}
!125 = !{i64 8665923322297778080}
!126 = !{i64 465854543866117646}
!127 = !{i64 4095041162191058082}
!128 = !{i64 -8104299409642703057}
!129 = !{i64 -3268653120321876032}
!130 = !{i64 -2645577126790709842}
!131 = !{i64 -3728322436225204259}
!132 = !{i64 -7767551947213901888}
!133 = !{i64 -7084716071993295130}
!134 = !{i64 -896968450346595389}
!135 = !{i64 -344376558563622138}
!136 = !{i64 -5645326313378301382}
!137 = !{i64 3787671451035736251}
!138 = !{i64 -7331532467741768133}
!139 = !{i64 7894406636045861994}
!140 = !{i64 798016638052563380}
!141 = !{i64 -1288232949054998528}
!142 = !{i64 -2125303174358247341}
!143 = !{i64 -6013159171620436427}
!144 = !{i64 -5035773351351280353}
!145 = !{i64 -4340557655284559187}
!146 = !{i64 -6375146998382342962}
!147 = !{i64 6311066799378902813}
!148 = !{i64 1742330793439361}
!149 = !{i64 3996134007004624948}
!150 = !{i64 2432918790140348916}
!151 = !{i64 529859057927740684}
!152 = !{i64 -5636500363754568418}
!153 = !{i64 8903429995393044095}
!154 = !{i64 9174570103667748071}
!155 = !{i64 -6649124911183102069}
!156 = !{i64 2417863045282429415}
!157 = !{i64 7224044524102791775}
!158 = !{i64 -4369580275300048113}
!159 = !{i64 4824981725517599202}
!160 = !{i64 1689287714405824494}
!161 = !{i64 8604440211733018570}
!162 = !{i64 8784265386306301582}
!163 = !{i64 3464841056547476934}
!164 = !{i64 6031400679403545110}
!165 = !{i64 -3552409414924328013}
!166 = !{i64 -5896283920923170294}
!167 = !{i64 -8537232944254483278}
!168 = !{i64 3858659979489800083}
!169 = !{i64 2889101213226500931}
!170 = !{i64 -2057618649826542888}
!171 = !{i64 4261223309990692151}
!172 = !{i64 -411103277838009115}
!173 = !{i64 -8300705434275560528}
!174 = !{i64 -9017543919276566173}
!175 = !{i64 -6581707603650025104}
!176 = !{i64 2776244716806602955}
!177 = !{i64 2943189372611335667}
!178 = !{i64 2188545719437998956}
!179 = !{i64 8914194163229874827}
!180 = !{i64 -6463138043287905080}
!181 = !{i64 -5742386203859004314}
!182 = !{i64 -5559460155302940638}
!183 = !{i64 407771646855543768}
!184 = !{i64 7363340066627157098}
!185 = !{i64 -6793387349976780932}
!186 = !{i64 5060845759121354357}
!187 = !{i64 -3410386406063386565}
!188 = !{i64 -4094179977101782405}
!189 = !{i64 -4638108675696881058}
!190 = !{i64 -4722956430864208198}
!191 = !{i64 -7248606370356923650}
!192 = !{i64 -5516674684574586256}
!193 = !{i64 -8557443763512668998}
!194 = !{i64 -8574068870098782918}
!195 = !{i64 -7138606017929397966}
!196 = !{i64 -5236197022967942024}
!197 = !{i64 5106570276610466545}
!198 = !{i64 -6332209304087563817}
!199 = !{i64 -7135481519802546561}
!200 = !{i64 -2864599019452333886}
!201 = !{i64 3586923864991143998}
!202 = !{i64 970756293146207494}
!203 = !{i64 -6555277727359819920}
!204 = !{i64 -637790041128080887}
!205 = !{i64 6952769239943291675}
!206 = !{i64 -5979777935226431086}
!207 = !{i64 1979018744579576192}
!208 = !{i64 2783330350655737153}
!209 = !{i64 -3327000072164136221}
!210 = !{i64 -4409646393492278123}
!211 = !{i64 -869555078769500830}
!212 = !{i64 1693411815664981553}
!213 = !{i64 2677480055013841818}
!214 = !{i64 -535585947057963408}
!215 = !{i64 -2104467261935852992}
!216 = !{i64 1691317551193385369}
!217 = !{i64 4941048918745680251}
!218 = !{i64 -5729591854256746147}
!219 = !{i64 -5292259704134566567}
!220 = !{i64 2247599021320285589}
!221 = !{i64 -5250485158029570241}
!222 = !{i64 2264537383456816882}
!223 = !{i64 -7508430202079091565}
!224 = !{i64 1195030572407111814}
!225 = !{i64 7157841718608050833}
!226 = !{i64 3046118837072864510}
!227 = !{i64 3707148448201222773}
!228 = !{i64 5989580082771754663}
!229 = !{i64 2667682722039361602}
!230 = !{i64 1241457842929130919}
!231 = !{i64 -2788639855112252529}
!232 = !{i64 764307180929797144}
!233 = !{i64 5734634873301127317}
!234 = !{i64 -7960512970974434403}
!235 = !{i64 -7279789047827421067}
!236 = !{i64 1954972723270690108}
!237 = !{i64 -7511971631932094401}
!238 = !{i64 817897413575242605}
!239 = !{i64 7918684848447524072}
!240 = !{i64 8384724690082887049}
!241 = !{i64 4192451177721351441}
!242 = !{i64 2575101700803759440}
!243 = !{i64 -161133104102858687}
!244 = !{i64 -7041456681088319941}
!245 = !{i64 -1517863743209610417}
!246 = !{i64 -3745407000091100654}
!247 = !{i64 7605346300329677849}
!248 = !{i64 -5691293965954187212}
!249 = !{i64 5118967784517511848}
!250 = !{i64 8876496867688538399}
!251 = !{i64 -9070473821706691304}
!252 = !{i64 -2007342418696969372}
!253 = !{i64 -4012115056956915684}
!254 = !{i64 -3839157705990806406}
!255 = !{i64 1635011949571665123}
!256 = !{i64 -1284784663576377365}
!257 = !{i64 2995943143372601022}
!258 = !{i64 -7028713384863639927}
!259 = !{i64 2223686695951915763}
!260 = !{i64 239103520354808321}
!261 = !{i64 3180913926605039087}
!262 = !{i64 6117667653936610033}
!263 = !{i64 1090399782638638514}
!264 = !{i64 532321507588932844}
!265 = !{i64 -6311781796296275528}
!266 = !{i64 2078782237138495400}
!267 = !{i64 5938512892111021106}
!268 = !{i64 2313212826411664953}
!269 = !{i64 5674766825402130075}
!270 = !{i64 7665358774312064819}
!271 = !{i64 -9173943869461016699}
!272 = !{i64 6904505155002727410}
!273 = !{i64 5529068720304162794}
!274 = !{i64 5606533042635890152}
!275 = !{i64 7934641824444381957}
!276 = !{i64 -6629502594903895}
!277 = !{i64 5823242692822571977}
!278 = !{i64 1537838800647686362}
!279 = !{i64 -3841562602290343203}
!280 = !{i64 -3675696115239171429}
!281 = !{i64 -2624081020897602054}
