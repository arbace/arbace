; ModuleID = 'panic_unwrap_none.8907a902ba6e63d8-cgu.0'
source_filename = "panic_unwrap_none.8907a902ba6e63d8-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsbLpeKtoPTls_17panic_unwrap_none, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsbLpeKtoPTls_17panic_unwrap_none, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsbLpeKtoPTls_17panic_unwrap_none }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_b1e1ac972ef3faad1e8ba7ebc170d54a = private unnamed_addr constant [41 x i8] c"test/rust/synthetic/panic-unwrap-none.rs\00", align 1, !guid !2
@alloc_ad56eca538ebd0e1ef357d4da8b395c8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b1e1ac972ef3faad1e8ba7ebc170d54a, [16 x i8] c"(\00\00\00\00\00\00\00\06\00\00\00%\00\00\00" }>, align 8, !guid !3
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !4

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsbLpeKtoPTls_17panic_unwrap_none(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !10 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<core::option::Option<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECsbLpeKtoPTls_17panic_unwrap_none(i1 zeroext %dummy.0, i8 %dummy.1) unnamed_addr #1 !guid !11 {
start:
  %_0 = alloca [2 x i8], align 1
  %0 = zext i1 %dummy.0 to i8
  store i8 %0, ptr %_0, align 1
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %dummy.1, ptr %1, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !12
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  %5 = load i8, ptr %4, align 1
  %6 = insertvalue { i1, i8 } poison, i1 %3, 0
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1
  ret { i1, i8 } %7
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsbLpeKtoPTls_17panic_unwrap_none(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !13 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsbLpeKtoPTls_17panic_unwrap_none(ptr %f) #6
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #6
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsbLpeKtoPTls_17panic_unwrap_none(ptr align 8 %_1) unnamed_addr #1 !guid !14 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsbLpeKtoPTls_17panic_unwrap_none(ptr %_4) #7
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsbLpeKtoPTls_17panic_unwrap_none() #6
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsbLpeKtoPTls_17panic_unwrap_none(i8 %_2) #6
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsbLpeKtoPTls_17panic_unwrap_none(ptr %_1) unnamed_addr #1 !guid !15 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsbLpeKtoPTls_17panic_unwrap_none(ptr %0) #6
  ret i32 %_0
}

; panic_unwrap_none::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsbLpeKtoPTls_17panic_unwrap_none4main() unnamed_addr #0 !guid !16 {
start:
  %self.i = alloca [2 x i8], align 1
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsbLpeKtoPTls_17panic_unwrap_none(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #6
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<core::option::Option<u8>>
  %1 = call { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECsbLpeKtoPTls_17panic_unwrap_none(i1 zeroext false, i8 undef) #6
  %o.0 = extractvalue { i1, i8 } %1, 0
  %o.1 = extractvalue { i1, i8 } %1, 1
  %2 = zext i1 %o.0 to i8
  store i8 %2, ptr %self.i, align 1
  %3 = getelementptr inbounds i8, ptr %self.i, i64 1
  store i8 %o.1, ptr %3, align 1
  %4 = load i8, ptr %self.i, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %self.i, i64 1
  %7 = load i8, ptr %6, align 1
  %_2.i = zext i1 %5 to i64
  br i1 %5, label %_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionhE6unwrapCsbLpeKtoPTls_17panic_unwrap_none.exit, label %bb2.i

bb2.i:                                            ; preds = %start
; call core::option::unwrap_failed
  call void @_RNvNtCsl10jNU3mE6R_4core6option13unwrap_failed(ptr align 8 @alloc_ad56eca538ebd0e1ef357d4da8b395c8) #8
  unreachable

_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionhE6unwrapCsbLpeKtoPTls_17panic_unwrap_none.exit: ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self.i, i64 1
  %val.i = load i8, ptr %8, align 1
; call <core::fmt::Arguments>::from_str
  %9 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsbLpeKtoPTls_17panic_unwrap_none(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #6
  %_7.0 = extractvalue { ptr, ptr } %9, 0
  %_7.1 = extractvalue { ptr, ptr } %9, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_7.0, ptr %_7.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsbLpeKtoPTls_17panic_unwrap_none(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !17 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsbLpeKtoPTls_17panic_unwrap_none(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !18 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsbLpeKtoPTls_17panic_unwrap_none(ptr %s.0, i64 %s.1) #6
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsbLpeKtoPTls_17panic_unwrap_none(ptr %self) unnamed_addr #1 !guid !19 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsbLpeKtoPTls_17panic_unwrap_none(i8 %0) unnamed_addr #1 !guid !20 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsbLpeKtoPTls_17panic_unwrap_none(ptr %self) #6
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsbLpeKtoPTls_17panic_unwrap_none() unnamed_addr #1 !guid !21 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsbLpeKtoPTls_17panic_unwrap_none(ptr %_1) unnamed_addr #1 !guid !22 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsbLpeKtoPTls_17panic_unwrap_none(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !23 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsbLpeKtoPTls_17panic_unwrap_none(ptr align 8 %_1) #6
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; core::option::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6option13unwrap_failed(ptr align 8) unnamed_addr #4

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #5 !guid !24 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsbLpeKtoPTls_17panic_unwrap_none(ptr @_RNvCsbLpeKtoPTls_17panic_unwrap_none4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nonlazybind "target-cpu"="x86-64" }
attributes #6 = { inlinehint }
attributes #7 = { noinline }
attributes #8 = { noinline noreturn }

!llvm.module.flags = !{!5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = !{i64 -8098850467594372105}
!1 = !{i64 -7543015018555430014}
!2 = !{i64 8338726450941884078}
!3 = !{i64 -3217551920937359141}
!4 = !{i64 3786980352892520479}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 2, !"RtLibUseGOT", i32 1}
!8 = !{i32 7, !"uwtable", i32 2}
!9 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!10 = !{i64 784996216426190405}
!11 = !{i64 3715642697099628975}
!12 = !{i64 1312739574458827}
!13 = !{i64 4028872776726497950}
!14 = !{i64 4616924421868808856}
!15 = !{i64 -62580665753956349}
!16 = !{i64 -2779473942161258584}
!17 = !{i64 1055009809493604947}
!18 = !{i64 -4854632404913837685}
!19 = !{i64 3840073128530784794}
!20 = !{i64 2012848104965013509}
!21 = !{i64 -929759306509095136}
!22 = !{i64 -2623251129511996200}
!23 = !{i64 -6720232358351160997}
!24 = !{i64 -2624081020897602054}
