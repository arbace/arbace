; ModuleID = 'overflow_sub_u8.4a020fd402b7285b-cgu.0'
source_filename = "overflow_sub_u8.4a020fd402b7285b-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs6lWtpsNa4u5_15overflow_sub_u8, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs6lWtpsNa4u5_15overflow_sub_u8, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs6lWtpsNa4u5_15overflow_sub_u8 }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_d3575eb51833ba6239e313f90d3e7518 = private unnamed_addr constant [39 x i8] c"test/rust/synthetic/overflow-sub-u8.rs\00", align 1, !guid !2
@alloc_f88e847d5193d29f986b75ff6560232a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d3575eb51833ba6239e313f90d3e7518, [16 x i8] c"&\00\00\00\00\00\00\00\07\00\00\00\0D\00\00\00" }>, align 8, !guid !3
@alloc_aba2f1a5110ca0d659951e181c97d362 = private unnamed_addr constant [20 x i8] c"\0Cunreachable \C0\01 \C0\01\0A\00", align 1, !guid !4

; <core::fmt::rt::Argument>::new_debug::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debughECs6lWtpsNa4u5_15overflow_sub_u8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !10 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refB9_(ptr %x) #7
; call <core::ptr::non_null::NonNull<u8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuEBa_(ptr %_4) #7
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCs6lWtpsNa4u5_15overflow_sub_u8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::Arguments>::new::<20, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj2_ECs6lWtpsNa4u5_15overflow_sub_u8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !11 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs6lWtpsNa4u5_15overflow_sub_u8(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !12 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs6lWtpsNa4u5_15overflow_sub_u8(i8 %dummy) unnamed_addr #0 !guid !13 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !14
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6lWtpsNa4u5_15overflow_sub_u8(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !15 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs6lWtpsNa4u5_15overflow_sub_u8(ptr %f) #7
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #7
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs6lWtpsNa4u5_15overflow_sub_u8(ptr align 8 %_1) unnamed_addr #0 !guid !16 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6lWtpsNa4u5_15overflow_sub_u8(ptr %_4) #8
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs6lWtpsNa4u5_15overflow_sub_u8() #7
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs6lWtpsNa4u5_15overflow_sub_u8(i8 %_2) #7
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs6lWtpsNa4u5_15overflow_sub_u8(ptr %_1) unnamed_addr #0 !guid !17 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs6lWtpsNa4u5_15overflow_sub_u8(ptr %0) #7
  ret i32 %_0
}

; overflow_sub_u8::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs6lWtpsNa4u5_15overflow_sub_u84main() unnamed_addr #1 !guid !18 {
start:
  %_14 = alloca [16 x i8], align 8
  %_13 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %r = alloca [1 x i8], align 1
  %b = alloca [1 x i8], align 1
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs6lWtpsNa4u5_15overflow_sub_u8(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #7
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<u8>
  %a = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs6lWtpsNa4u5_15overflow_sub_u8(i8 0) #7
; call core::hint::black_box::<u8>
  %1 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs6lWtpsNa4u5_15overflow_sub_u8(i8 1) #7
  store i8 %1, ptr %b, align 1
  %2 = load i8, ptr %b, align 1
  %_6.0 = sub i8 %a, %2
  %_6.1 = icmp ult i8 %a, %2
  br i1 %_6.1, label %panic, label %bb5

bb5:                                              ; preds = %start
  store i8 %_6.0, ptr %r, align 1
; call <core::fmt::rt::Argument>::new_debug::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debughECs6lWtpsNa4u5_15overflow_sub_u8(ptr sret([16 x i8]) align 8 %_13, ptr %r) #7
; call <core::fmt::rt::Argument>::new_debug::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debughECs6lWtpsNa4u5_15overflow_sub_u8(ptr sret([16 x i8]) align 8 %_14, ptr %b) #7
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_13, i64 16, i1 false)
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_14, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<20, 2>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj2_ECs6lWtpsNa4u5_15overflow_sub_u8(ptr @alloc_aba2f1a5110ca0d659951e181c97d362, ptr align 8 %args) #7
  %_8.0 = extractvalue { ptr, ptr } %5, 0
  %_8.1 = extractvalue { ptr, ptr } %5, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_8.0, ptr %_8.1)
  ret void

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_f88e847d5193d29f986b75ff6560232a) #9
  unreachable
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs6lWtpsNa4u5_15overflow_sub_u8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !19 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs6lWtpsNa4u5_15overflow_sub_u8(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !20 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs6lWtpsNa4u5_15overflow_sub_u8(ptr %s.0, i64 %s.1) #7
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs6lWtpsNa4u5_15overflow_sub_u8(ptr %self) unnamed_addr #0 !guid !21 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs6lWtpsNa4u5_15overflow_sub_u8(i8 %0) unnamed_addr #0 !guid !22 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs6lWtpsNa4u5_15overflow_sub_u8(ptr %self) #7
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs6lWtpsNa4u5_15overflow_sub_u8() unnamed_addr #0 !guid !23 {
start:
  ret i8 0
}

; <u8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCs6lWtpsNa4u5_15overflow_sub_u8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !24 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs6lWtpsNa4u5_15overflow_sub_u8(ptr %_1) unnamed_addr #0 !guid !25 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs6lWtpsNa4u5_15overflow_sub_u8(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !26 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs6lWtpsNa4u5_15overflow_sub_u8(ptr align 8 %_1) #7
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<u8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refB9_(ptr) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuEBa_(ptr) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #3

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #4

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_const::panic_const_sub_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8) unnamed_addr #5

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #6 !guid !27 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs6lWtpsNa4u5_15overflow_sub_u8(ptr @_RNvCs6lWtpsNa4u5_15overflow_sub_u84main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nonlazybind "target-cpu"="x86-64" }
attributes #7 = { inlinehint }
attributes #8 = { noinline }
attributes #9 = { noinline noreturn }

!llvm.module.flags = !{!5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = !{i64 -1230095780585046730}
!1 = !{i64 2696372944114473481}
!2 = !{i64 -8161661900724972294}
!3 = !{i64 -1165939731147319308}
!4 = !{i64 5207681588264798040}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 2, !"RtLibUseGOT", i32 1}
!8 = !{i32 7, !"uwtable", i32 2}
!9 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!10 = !{i64 -8502651835155379185}
!11 = !{i64 61159307908257957}
!12 = !{i64 -4830087196809571760}
!13 = !{i64 6824574206219003638}
!14 = !{i64 1312645085178293}
!15 = !{i64 835095531066872875}
!16 = !{i64 -1005019159333824909}
!17 = !{i64 1252602425870900759}
!18 = !{i64 -6546836982415114246}
!19 = !{i64 1362718206882794881}
!20 = !{i64 6665188219039352296}
!21 = !{i64 -2127610994598360742}
!22 = !{i64 -4531487246720543160}
!23 = !{i64 6501903640843262022}
!24 = !{i64 2788168540211934079}
!25 = !{i64 -2743130267564533809}
!26 = !{i64 -31976539934809231}
!27 = !{i64 -2624081020897602054}
