; ModuleID = 'int_ops_i8.620a7f4bdfbebc02-cgu.0'
source_filename = "int_ops_i8.620a7f4bdfbebc02-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs8pRW9QHXPaM_10int_ops_i8, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8pRW9QHXPaM_10int_ops_i8, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8pRW9QHXPaM_10int_ops_i8 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !3
@alloc_025a5709ba9544310ca8368ed72bebad = private unnamed_addr constant [4 x i8] c"\08\00\00\00", align 4, !guid !4
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !5
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !7
@alloc_4d7dd9ad0512c4d42677be0c7feb3348 = private unnamed_addr constant [34 x i8] c"test/rust/synthetic/int-ops-i8.rs\00", align 1, !guid !8
@alloc_9af50b32be45b2581e480bef6a4569d7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !9
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !10
@alloc_75b32a18bdd65834267dc4708dab54e5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !11
@alloc_0a1a1a880a14ee52073c6e8568cd70eb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !12
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !13
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !14
@alloc_41c0e125573be1c7c4cca5e7c50e098d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\1A\00\00\00\1B\00\00\00" }>, align 8, !guid !15
@alloc_e09845198ec90fbfc5a3565186e13680 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !16
@alloc_acad96cb9ad91deee27e5040e130883c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !17
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !18
@alloc_5cacace390a18a9774a0946b258a8e02 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !19
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !20
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !21
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !22
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !23
@alloc_67962a1ee7843a18e69bde6432c4d7d7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00{\01\00\00\05\00\00\00" }>, align 8, !guid !24
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !25
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !26
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !27
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !28
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !29
@alloc_1f1d7c1ec8c9041988f7c79d620acc00 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\02\00\00\05\00\00\00" }>, align 8, !guid !30
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !31
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !32
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !33
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !34
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !35
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !36
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !37
@anon.681c060d2bfd6770ec9e5f1a4ed3b4ec.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !38
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !39
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !40
@alloc_cbcfb4391f0fcdd0dcd48dbe6149ef89 = private unnamed_addr constant [183 x i8] c"unsafe precondition(s) violated: i8::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !41
@alloc_66558f7972e7e036e1d4ccb8be86690a = private unnamed_addr constant [183 x i8] c"unsafe precondition(s) violated: i8::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !42
@alloc_eff87de2e562ad9bea1d5ede245212a6 = private unnamed_addr constant [183 x i8] c"unsafe precondition(s) violated: u8::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !43
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !44
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8 }>, align 8, !guid !45
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8 }>, align 8, !guid !46
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !47
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !48
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !49
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !50
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !51
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !52
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !53
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8 }>, align 8, !guid !54

; <str>::parse::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parseaECs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !60 {
start:
; call <i8 as core::str::traits::FromStr>::from_str
  %0 = call { i1, i8 } @_RNvXsk_NtCsl10jNU3mE6R_4core3numaNtNtNtB7_3str6traits7FromStr8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) #17
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <core::fmt::rt::Argument>::new_binary::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !61 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsb_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !62 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !63 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !64 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !65 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 4 %x) #17
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !66 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !67 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !68 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i8>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionaEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<core::option::Option<i8>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionaEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionaENtNtB7_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i8, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultaNtNtNtB7_3num5error13ParseIntErrorEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !69 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultaNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultaNtNtNtBa_3num5error13ParseIntErrorEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultaNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(i8, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTabEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !70 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(i8, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTabEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<(i8, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTabEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTabENtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !71 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !72 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #17
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsd_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::option::Option<i8>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionaEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !73 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultaNtNtNtBa_3num5error13ParseIntErrorEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !74 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<(i8, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTabEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !75 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !76 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !77 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !78 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !79 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECs8pRW9QHXPaM_10int_ops_i8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !80 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !81 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !82 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs8pRW9QHXPaM_10int_ops_i8(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !83 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u8>
; Function Attrs: nounwind nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefthECs8pRW9QHXPaM_10int_ops_i8(i8 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !84 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 1 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i8
  %_0 = call i8 @llvm.fshl.i8(i8 %x, i8 %x, i8 %1)
  ret i8 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u8>
; Function Attrs: nounwind nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righthECs8pRW9QHXPaM_10int_ops_i8(i8 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !85 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 1 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i8
  %_0 = call i8 @llvm.fshr.i8(i8 %x, i8 %x, i8 %1)
  ret i8 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::is_val_statically_known::<i8>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownaECs8pRW9QHXPaM_10int_ops_i8(i8 %_arg) unnamed_addr #2 !guid !86 {
start:
  ret i1 false
}

; core::hint::black_box::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 %dummy) unnamed_addr #0 !guid !87 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !88
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs8pRW9QHXPaM_10int_ops_i8(i32 %dummy) unnamed_addr #0 !guid !89 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !88
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 %dummy) unnamed_addr #0 !guid !90 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !88
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs8pRW9QHXPaM_10int_ops_i8(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !91 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr %f) #17
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #17
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1) unnamed_addr #0 !guid !92 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #20
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs8pRW9QHXPaM_10int_ops_i8() #17
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs8pRW9QHXPaM_10int_ops_i8(i8 %_2) #17
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs8pRW9QHXPaM_10int_ops_i8(ptr %_1) unnamed_addr #0 !guid !93 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr %0) #17
  ret i32 %_0
}

; int_ops_i8::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs8pRW9QHXPaM_10int_ops_i84main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !94 {
start:
  %0 = alloca [16 x i8], align 8
  %_294 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_284 = alloca [24 x i8], align 8
  %_283 = alloca [24 x i8], align 8
  %_279 = alloca [24 x i8], align 8
  %_276 = alloca [8 x i8], align 8
  %_269 = alloca [16 x i8], align 8
  %_268 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_264 = alloca [4 x i8], align 4
  %_262 = alloca [1 x i8], align 1
  %_255 = alloca [16 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_252 = alloca [4 x i8], align 4
  %_250 = alloca [4 x i8], align 4
  %_243 = alloca [16 x i8], align 8
  %_242 = alloca [16 x i8], align 8
  %_241 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_239 = alloca [8 x i8], align 8
  %_237 = alloca [4 x i8], align 4
  %_233 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_226 = alloca [16 x i8], align 8
  %_225 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_222 = alloca [2 x i8], align 1
  %_220 = alloca [1 x i8], align 1
  %_216 = alloca [2 x i8], align 1
  %_209 = alloca [16 x i8], align 8
  %_208 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_206 = alloca [1 x i8], align 1
  %_203 = alloca [1 x i8], align 1
  %_196 = alloca [16 x i8], align 8
  %_195 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_193 = alloca [2 x i8], align 1
  %_190 = alloca [2 x i8], align 1
  %_183 = alloca [16 x i8], align 8
  %_182 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_176 = alloca [1 x i8], align 1
  %_170 = alloca [1 x i8], align 1
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [1 x i8], align 1
  %_156 = alloca [1 x i8], align 1
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [1 x i8], align 1
  %_144 = alloca [1 x i8], align 1
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [1 x i8], align 1
  %_130 = alloca [1 x i8], align 1
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [2 x i8], align 1
  %_98 = alloca [2 x i8], align 1
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [1 x i8], align 1
  %_86 = alloca [1 x i8], align 1
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [1 x i8], align 1
  %_74 = alloca [1 x i8], align 1
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [1 x i8], align 1
  %_62 = alloca [1 x i8], align 1
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [2 x i8], align 1
  %_50 = alloca [2 x i8], align 1
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [2 x i8], align 1
  %_38 = alloca [2 x i8], align 1
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [1 x i8], align 1
  %min = alloca [1 x i8], align 1
; call core::hint::black_box::<i8>
  %_4 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 -128) #17
; call core::hint::black_box::<i8>
  %_5 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 127) #17
  store i8 %_4, ptr %min, align 1
  store i8 %_5, ptr %max, align 1
; call core::hint::black_box::<i8>
  %one = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 1) #17
; call core::hint::black_box::<i8>
  %three = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 3) #17
  store ptr %min, ptr %args, align 8
  %1 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_025a5709ba9544310ca8368ed72bebad, ptr %2, align 8
  %_297 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_15, ptr %_297) #17
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  %_298 = load ptr, ptr %3, align 8
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_16, ptr %_298) #17
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  %_299 = load ptr, ptr %4, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_299) #17
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_15, i64 16, i1 false)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_16, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #17
  %_9.0 = extractvalue { ptr, ptr } %8, 0
  %_9.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %9 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %11, align 8
  %_300 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_28, ptr %_300) #17
  %12 = getelementptr inbounds i8, ptr %args2, i64 8
  %_301 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_binary::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_29, ptr %_301) #17
  %13 = getelementptr inbounds i8, ptr %args2, i64 16
  %_302 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_octal::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_30, ptr %_302) #17
  %14 = getelementptr inbounds i8, ptr %args2, i64 24
  %_303 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_31, ptr %_303) #17
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_28, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_29, i64 16, i1 false)
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_30, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #17
  %_21.0 = extractvalue { ptr, ptr } %19, 0
  %_21.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %20 = load i8, ptr %max, align 1
; call <i8>::checked_add
  %21 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs8pRW9QHXPaM_10int_ops_i8(i8 %20, i8 %one) #17
  %22 = extractvalue { i1, i8 } %21, 0
  %23 = extractvalue { i1, i8 } %21, 1
  %24 = zext i1 %22 to i8
  store i8 %24, ptr %_38, align 1
  %25 = getelementptr inbounds i8, ptr %_38, i64 1
  store i8 %23, ptr %25, align 1
  %26 = load i8, ptr %min, align 1
; call <i8>::checked_add
  %27 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs8pRW9QHXPaM_10int_ops_i8(i8 %26, i8 %one) #17
  %28 = extractvalue { i1, i8 } %27, 0
  %29 = extractvalue { i1, i8 } %27, 1
  %30 = zext i1 %28 to i8
  store i8 %30, ptr %_40, align 1
  %31 = getelementptr inbounds i8, ptr %_40, i64 1
  store i8 %29, ptr %31, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_42, ptr %_38) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_43, ptr %_40) #17
  %32 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %_42, i64 16, i1 false)
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %34 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #17
  %_35.0 = extractvalue { ptr, ptr } %34, 0
  %_35.1 = extractvalue { ptr, ptr } %34, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %35 = load i8, ptr %max, align 1
  %36 = call { i8, i1 } @llvm.sadd.with.overflow.i8(i8 %35, i8 %one)
  %_5.0.i = extractvalue { i8, i1 } %36, 0
  %_5.1.i = extractvalue { i8, i1 } %36, 1
  %37 = extractvalue { i8, i1 } %36, 0
  %38 = extractvalue { i8, i1 } %36, 1
  store i8 %37, ptr %_50, align 1
  %39 = getelementptr inbounds i8, ptr %_50, i64 1
  %40 = zext i1 %38 to i8
  store i8 %40, ptr %39, align 1
  %41 = load i8, ptr %min, align 1
  %42 = call { i8, i1 } @llvm.ssub.with.overflow.i8(i8 %41, i8 %one)
  %_5.0.i53 = extractvalue { i8, i1 } %42, 0
  %_5.1.i54 = extractvalue { i8, i1 } %42, 1
  %43 = extractvalue { i8, i1 } %42, 0
  %44 = extractvalue { i8, i1 } %42, 1
  store i8 %43, ptr %_52, align 1
  %45 = getelementptr inbounds i8, ptr %_52, i64 1
  %46 = zext i1 %44 to i8
  store i8 %46, ptr %45, align 1
; call <core::fmt::rt::Argument>::new_debug::<(i8, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTabEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_54, ptr %_50) #17
; call <core::fmt::rt::Argument>::new_debug::<(i8, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTabEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_55, ptr %_52) #17
  %47 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %47, ptr align 8 %_54, i64 16, i1 false)
  %48 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %48, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %49 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #17
  %_47.0 = extractvalue { ptr, ptr } %49, 0
  %_47.1 = extractvalue { ptr, ptr } %49, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %50 = load i8, ptr %max, align 1
  %_0.i35 = add i8 %50, %one
  store i8 %_0.i35, ptr %_62, align 1
  %51 = load i8, ptr %min, align 1
  %_0.i42 = sub i8 %51, %one
  store i8 %_0.i42, ptr %_64, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_66, ptr %_62) #17
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_67, ptr %_64) #17
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_66, i64 16, i1 false)
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %54 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #17
  %_59.0 = extractvalue { ptr, ptr } %54, 0
  %_59.1 = extractvalue { ptr, ptr } %54, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %55 = load i8, ptr %max, align 1
  %_0.i49 = call i8 @llvm.sadd.sat.i8(i8 %55, i8 %three)
  store i8 %_0.i49, ptr %_74, align 1
  %56 = load i8, ptr %min, align 1
  %_0.i50 = call i8 @llvm.ssub.sat.i8(i8 %56, i8 %three)
  store i8 %_0.i50, ptr %_76, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_78, ptr %_74) #17
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_79, ptr %_76) #17
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_78, i64 16, i1 false)
  %58 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %58, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %59 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #17
  %_71.0 = extractvalue { ptr, ptr } %59, 0
  %_71.1 = extractvalue { ptr, ptr } %59, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %60 = load i8, ptr %max, align 1
  %_0.i37 = mul i8 %60, %three
  store i8 %_0.i37, ptr %_86, align 1
  %61 = load i8, ptr %max, align 1
  %62 = load i8, ptr %max, align 1
  %_0.i36 = mul i8 %61, %62
  store i8 %_0.i36, ptr %_88, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_90, ptr %_86) #17
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_91, ptr %_88) #17
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_90, i64 16, i1 false)
  %64 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %64, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %65 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #17
  %_83.0 = extractvalue { ptr, ptr } %65, 0
  %_83.1 = extractvalue { ptr, ptr } %65, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %66 = load i8, ptr %max, align 1
; call <i8>::checked_mul
  %67 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %66, i8 %three) #17
  %68 = extractvalue { i1, i8 } %67, 0
  %69 = extractvalue { i1, i8 } %67, 1
  %70 = zext i1 %68 to i8
  store i8 %70, ptr %_98, align 1
  %71 = getelementptr inbounds i8, ptr %_98, i64 1
  store i8 %69, ptr %71, align 1
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 5) #17
; call <i8>::checked_pow
  %72 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_powCs8pRW9QHXPaM_10int_ops_i8(i8 %three, i32 %_101) #17
  %73 = extractvalue { i1, i8 } %72, 0
  %74 = extractvalue { i1, i8 } %72, 1
  %75 = zext i1 %73 to i8
  store i8 %75, ptr %_100, align 1
  %76 = getelementptr inbounds i8, ptr %_100, i64 1
  store i8 %74, ptr %76, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_103, ptr %_98) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_104, ptr %_100) #17
  %77 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %77, ptr align 8 %_103, i64 16, i1 false)
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %79 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #17
  %_95.0 = extractvalue { ptr, ptr } %79, 0
  %_95.1 = extractvalue { ptr, ptr } %79, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %80 = load i8, ptr %max, align 1
  %81 = call i8 @llvm.ctpop.i8(i8 %80)
  %_0.i55 = zext i8 %81 to i32
  store i32 %_0.i55, ptr %_111, align 4
  %82 = load i8, ptr %max, align 1
  %83 = call i8 @llvm.ctlz.i8(i8 %82, i1 false)
  %_0.i60 = zext i8 %83 to i32
  store i32 %_0.i60, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs8pRW9QHXPaM_10int_ops_i8(i32 3) #17
  %_119 = icmp ult i32 %_117, 8
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %84 = and i32 %_117, 7
  %85 = trunc i32 %84 to i8
  %_116 = shl i8 %one, %85
  %86 = call i8 @llvm.cttz.i8(i8 %_116, i1 false)
  %_0.i61 = zext i8 %86 to i32
  store i32 %_0.i61, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %87 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %87, align 8
  %88 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %88, align 8
  %_316 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_316) #17
  %89 = getelementptr inbounds i8, ptr %args10, i64 8
  %_317 = load ptr, ptr %89, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_317) #17
  %90 = getelementptr inbounds i8, ptr %args10, i64 16
  %_318 = load ptr, ptr %90, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_318) #17
  %91 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %91, ptr align 8 %_121, i64 16, i1 false)
  %92 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %92, ptr align 8 %_122, i64 16, i1 false)
  %93 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %93, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %94 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #17
  %_108.0 = extractvalue { ptr, ptr } %94, 0
  %_108.1 = extractvalue { ptr, ptr } %94, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 5) #17
  %95 = load i8, ptr %max, align 1
; call core::intrinsics::rotate_left::<u8>
  %_0.i = call i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefthECs8pRW9QHXPaM_10int_ops_i8(i8 %95, i32 %_131) #21
  store i8 %_0.i, ptr %_130, align 1
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 7) #17
  %96 = load i8, ptr %min, align 1
; call core::intrinsics::rotate_right::<u8>
  %_0.i58 = call i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righthECs8pRW9QHXPaM_10int_ops_i8(i8 %96, i32 %_134) #21
  store i8 %_0.i58, ptr %_133, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_136, ptr %_130) #17
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_137, ptr %_133) #17
  %97 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %97, ptr align 8 %_136, i64 16, i1 false)
  %98 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %98, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %99 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #17
  %_127.0 = extractvalue { ptr, ptr } %99, 0
  %_127.1 = extractvalue { ptr, ptr } %99, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %100 = load i8, ptr %max, align 1
  store i8 %100, ptr %_144, align 1
  %101 = load i8, ptr %max, align 1
  %_0.i57 = call i8 @llvm.bitreverse.i8(i8 %101)
  store i8 %_0.i57, ptr %_146, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_148, ptr %_144) #17
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_149, ptr %_146) #17
  %102 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %102, ptr align 8 %_148, i64 16, i1 false)
  %103 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %103, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %104 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #17
  %_141.0 = extractvalue { ptr, ptr } %104, 0
  %_141.1 = extractvalue { ptr, ptr } %104, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 70) #17
  %105 = load i8, ptr %max, align 1
  %_3.i38 = and i32 %_157, 7
; call core::ub_checks::check_language_ub
  %_3.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_3.i44, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <i8>::unchecked_shl::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %_3.i38, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #22
  br label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %106 = trunc nuw i32 %_3.i38 to i8
  %_0.i45 = shl i8 %105, %106
  store i8 %_0.i45, ptr %_156, align 1
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 66) #17
  %107 = load i8, ptr %min, align 1
  %_3.i40 = and i32 %_160, 7
; call core::ub_checks::check_language_ub
  %_3.i46 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_3.i46, label %bb2.i48, label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit

bb2.i48:                                          ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit
; call <i8>::unchecked_shr::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %_3.i40, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #22
  br label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit

_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit: ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit, %bb2.i48
  %108 = trunc nuw i32 %_3.i40 to i8
  %_0.i47 = ashr i8 %107, %108
  store i8 %_0.i47, ptr %_159, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_162, ptr %_156) #17
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_163, ptr %_159) #17
  %109 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %109, ptr align 8 %_162, i64 16, i1 false)
  %110 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %110, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %111 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #17
  %_153.0 = extractvalue { ptr, ptr } %111, 0
  %_153.1 = extractvalue { ptr, ptr } %111, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i8 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_9af50b32be45b2581e480bef6a4569d7) #23
  unreachable

bb85:                                             ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit
  %_172 = icmp eq i8 %three, -1
  %112 = load i8, ptr %max, align 1
  %_173 = icmp eq i8 %112, -128
  %_174 = and i1 %_172, %_173
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_75b32a18bdd65834267dc4708dab54e5) #23
  unreachable

bb86:                                             ; preds = %bb85
  %113 = load i8, ptr %max, align 1
  %114 = sdiv i8 %113, %three
  store i8 %114, ptr %_170, align 1
  %_177 = icmp eq i8 %three, 0
  br i1 %_177, label %panic27, label %bb87

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_75b32a18bdd65834267dc4708dab54e5) #23
  unreachable

bb87:                                             ; preds = %bb86
  %_178 = icmp eq i8 %three, -1
  %115 = load i8, ptr %max, align 1
  %_179 = icmp eq i8 %115, -128
  %_180 = and i1 %_178, %_179
  br i1 %_180, label %panic28, label %bb88

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_0a1a1a880a14ee52073c6e8568cd70eb) #23
  unreachable

bb88:                                             ; preds = %bb87
  %116 = load i8, ptr %max, align 1
  %117 = srem i8 %116, %three
  store i8 %117, ptr %_176, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_182, ptr %_170) #17
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_183, ptr %_176) #17
  %118 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %118, ptr align 8 %_182, i64 16, i1 false)
  %119 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %119, ptr align 8 %_183, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %120 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #17
  %_167.0 = extractvalue { ptr, ptr } %120, 0
  %_167.1 = extractvalue { ptr, ptr } %120, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<i8>
  %_191 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 0) #17
  %121 = load i8, ptr %max, align 1
; call <i8>::checked_div
  %122 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_divCs8pRW9QHXPaM_10int_ops_i8(i8 %121, i8 %_191) #17
  %123 = extractvalue { i1, i8 } %122, 0
  %124 = extractvalue { i1, i8 } %122, 1
  %125 = zext i1 %123 to i8
  store i8 %125, ptr %_190, align 1
  %126 = getelementptr inbounds i8, ptr %_190, i64 1
  store i8 %124, ptr %126, align 1
  %127 = load i8, ptr %max, align 1
; call <i8>::checked_rem
  %128 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_remCs8pRW9QHXPaM_10int_ops_i8(i8 %127, i8 %three) #17
  %129 = extractvalue { i1, i8 } %128, 0
  %130 = extractvalue { i1, i8 } %128, 1
  %131 = zext i1 %129 to i8
  store i8 %131, ptr %_193, align 1
  %132 = getelementptr inbounds i8, ptr %_193, i64 1
  store i8 %130, ptr %132, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_195, ptr %_190) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_196, ptr %_193) #17
  %133 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %133, ptr align 8 %_195, i64 16, i1 false)
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_196, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %135 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #17
  %_187.0 = extractvalue { ptr, ptr } %135, 0
  %_187.1 = extractvalue { ptr, ptr } %135, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_187.0, ptr %_187.1)
; call core::hint::black_box::<u32>
  %_204 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 4) #17
; call <i8>::pow
  %136 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa3powCs8pRW9QHXPaM_10int_ops_i8(i8 %three, i32 %_204) #17
  store i8 %136, ptr %_203, align 1
  %137 = load i8, ptr %max, align 1
  %138 = load i8, ptr %min, align 1
; call <i8>::abs_diff
  %139 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa8abs_diffCs8pRW9QHXPaM_10int_ops_i8(i8 %137, i8 %138) #17
  store i8 %139, ptr %_206, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_208, ptr %_203) #17
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_209, ptr %_206) #17
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_208, i64 16, i1 false)
  %141 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %141, ptr align 8 %_209, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %142 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #17
  %_200.0 = extractvalue { ptr, ptr } %142, 0
  %_200.1 = extractvalue { ptr, ptr } %142, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_200.0, ptr %_200.1)
; call core::hint::black_box::<u32>
  %_218 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 7) #17
; call <i8>::from_str_radix
  %143 = call { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa14from_str_radixCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_218) #17
  %144 = extractvalue { i1, i8 } %143, 0
  %145 = extractvalue { i1, i8 } %143, 1
  %146 = zext i1 %144 to i8
  store i8 %146, ptr %_216, align 1
  %147 = getelementptr inbounds i8, ptr %_216, i64 1
  store i8 %145, ptr %147, align 1
; call <str>::parse::<i8>
  %148 = call { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parseaECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #17
  %149 = extractvalue { i1, i8 } %148, 0
  %150 = extractvalue { i1, i8 } %148, 1
  %151 = zext i1 %149 to i8
  store i8 %151, ptr %_222, align 1
  %152 = getelementptr inbounds i8, ptr %_222, i64 1
  store i8 %150, ptr %152, align 1
; call <core::result::Result<i8, core::num::error::ParseIntError>>::is_ok
  %153 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultaNtNtNtB4_3num5error13ParseIntErrorE5is_okCs8pRW9QHXPaM_10int_ops_i8(ptr %_222) #17
  %154 = zext i1 %153 to i8
  store i8 %154, ptr %_220, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i8, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultaNtNtNtB7_3num5error13ParseIntErrorEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_225, ptr %_216) #17
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_226, ptr %_220) #17
  %155 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %155, ptr align 8 %_225, i64 16, i1 false)
  %156 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %156, ptr align 8 %_226, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %157 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #17
  %_213.0 = extractvalue { ptr, ptr } %157, 0
  %_213.1 = extractvalue { ptr, ptr } %157, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_213.0, ptr %_213.1)
  %158 = load i8, ptr %max, align 1
  %_235 = sitofp i8 %158 to double
  %_234 = call i8 @llvm.fptosi.sat.i8.f64(double %_235)
  %159 = load i8, ptr %max, align 1
  %160 = icmp eq i8 %_234, %159
  %161 = zext i1 %160 to i8
  store i8 %161, ptr %_233, align 1
  %162 = load i8, ptr %max, align 1
  %163 = sitofp i8 %162 to float
  store float %163, ptr %_237, align 4
  %164 = load i8, ptr %min, align 1
  %165 = sitofp i8 %164 to double
  store double %165, ptr %_239, align 8
  store ptr %_233, ptr %args19, align 8
  %166 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_237, ptr %166, align 8
  %167 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_239, ptr %167, align 8
  %_333 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_241, ptr %_333) #17
  %168 = getelementptr inbounds i8, ptr %args19, i64 8
  %_334 = load ptr, ptr %168, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_242, ptr align 4 %_334) #17
  %169 = getelementptr inbounds i8, ptr %args19, i64 16
  %_335 = load ptr, ptr %169, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_243, ptr align 8 %_335) #17
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_241, i64 16, i1 false)
  %171 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %171, ptr align 8 %_242, i64 16, i1 false)
  %172 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %172, ptr align 8 %_243, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %173 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #17
  %_230.0 = extractvalue { ptr, ptr } %173, 0
  %_230.1 = extractvalue { ptr, ptr } %173, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_230.0, ptr %_230.1)
  %174 = load i8, ptr %max, align 1
  %_2.i = xor i8 %174, -1
  %175 = call i8 @llvm.ctlz.i8(i8 %_2.i, i1 false)
  %_0.i59 = zext i8 %175 to i32
  store i32 %_0.i59, ptr %_250, align 4
  %176 = load i8, ptr %min, align 1
  %177 = call i8 @llvm.cttz.i8(i8 %176, i1 false)
  %_0.i62 = zext i8 %177 to i32
  store i32 %_0.i62, ptr %_252, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_254, ptr align 4 %_250) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_255, ptr align 4 %_252) #17
  %178 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %178, ptr align 8 %_254, i64 16, i1 false)
  %179 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %179, ptr align 8 %_255, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %180 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #17
  %_247.0 = extractvalue { ptr, ptr } %180, 0
  %_247.1 = extractvalue { ptr, ptr } %180, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_247.0, ptr %_247.1)
  %181 = load i8, ptr %max, align 1
; call <i8>::isqrt
  %182 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa5isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %181, ptr align 8 @alloc_41c0e125573be1c7c4cca5e7c50e098d) #17
  store i8 %182, ptr %_262, align 1
  %183 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %three, i8 %three)
  %_266.0 = extractvalue { i8, i1 } %183, 0
  %_266.1 = extractvalue { i8, i1 } %183, 1
  br i1 %_266.1, label %panic29, label %bb127

panic28:                                          ; preds = %bb87
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_0a1a1a880a14ee52073c6e8568cd70eb) #23
  unreachable

bb127:                                            ; preds = %bb88
; call <i8>::ilog2
  %184 = call i32 @_RNvMNtCsl10jNU3mE6R_4core3numa5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %_266.0, ptr align 8 @alloc_acad96cb9ad91deee27e5040e130883c) #17
  store i32 %184, ptr %_264, align 4
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_268, ptr %_262) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_269, ptr align 4 %_264) #17
  %185 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %185, ptr align 8 %_268, i64 16, i1 false)
  %186 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %186, ptr align 8 %_269, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %187 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #17
  %_259.0 = extractvalue { ptr, ptr } %187, 0
  %_259.1 = extractvalue { ptr, ptr } %187, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_259.0, ptr %_259.1)
; call <i8 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringaNtB5_8ToString9to_stringCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_279, ptr %max) #17
; invoke <alloc::string::String>::len
  %_277 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_279)
          to label %bb134 unwind label %cleanup

panic29:                                          ; preds = %bb88
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_e09845198ec90fbfc5a3565186e13680) #23
  unreachable

bb147:                                            ; preds = %bb146, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279) #24
          to label %bb148 unwind label %terminate

cleanup:                                          ; preds = %bb143, %bb136, %bb135, %bb134, %bb127
  %188 = landingpad { ptr, i32 }
          cleanup
  %189 = extractvalue { ptr, i32 } %188, 0
  %190 = extractvalue { ptr, i32 } %188, 1
  store ptr %189, ptr %0, align 8
  %191 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %190, ptr %191, align 8
  br label %bb147

bb134:                                            ; preds = %bb127
; invoke <core::fmt::rt::Argument>::new_display::<i8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_289, ptr %min)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  %192 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %192, ptr align 8 %_289, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %193 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb136 unwind label %cleanup

bb136:                                            ; preds = %bb135
  %_285.0 = extractvalue { ptr, ptr } %193, 0
  %_285.1 = extractvalue { ptr, ptr } %193, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_284, ptr %_285.0, ptr %_285.1)
          to label %bb137 unwind label %cleanup

bb137:                                            ; preds = %bb136
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_283, ptr align 8 %_284, i64 24, i1 false)
  br label %bb138

bb138:                                            ; preds = %bb137
; invoke <alloc::string::String>::len
  %_281 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_283)
          to label %bb139 unwind label %cleanup30

bb146:                                            ; preds = %cleanup30
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283) #24
          to label %bb147 unwind label %terminate

cleanup30:                                        ; preds = %bb142, %bb141, %bb140, %panic31, %bb138
  %194 = landingpad { ptr, i32 }
          cleanup
  %195 = extractvalue { ptr, i32 } %194, 0
  %196 = extractvalue { ptr, i32 } %194, 1
  store ptr %195, ptr %0, align 8
  %197 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %196, ptr %197, align 8
  br label %bb146

bb139:                                            ; preds = %bb138
  %_292.0 = add i64 %_277, %_281
  %_292.1 = icmp ult i64 %_292.0, %_277
  br i1 %_292.1, label %panic31, label %bb140

bb140:                                            ; preds = %bb139
  store i64 %_292.0, ptr %_276, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_294, ptr align 8 %_276)
          to label %bb141 unwind label %cleanup30

panic31:                                          ; preds = %bb139
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_5cacace390a18a9774a0946b258a8e02) #19
          to label %unreachable unwind label %cleanup30

unreachable:                                      ; preds = %panic31
  unreachable

bb141:                                            ; preds = %bb140
  %198 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %198, ptr align 8 %_294, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %199 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb142 unwind label %cleanup30

bb142:                                            ; preds = %bb141
  %_273.0 = extractvalue { ptr, ptr } %199, 0
  %_273.1 = extractvalue { ptr, ptr } %199, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_273.0, ptr %_273.1)
          to label %bb143 unwind label %cleanup30

bb143:                                            ; preds = %bb142
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283)
          to label %bb144 unwind label %cleanup

bb144:                                            ; preds = %bb143
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279)
  ret void

terminate:                                        ; preds = %bb147, %bb146
  %200 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable

bb148:                                            ; preds = %bb147
  %201 = load ptr, ptr %0, align 8
  %202 = getelementptr inbounds i8, ptr %0, i64 8
  %203 = load i32, ptr %202, align 8
  %204 = insertvalue { ptr, i32 } poison, ptr %201, 0
  %205 = insertvalue { ptr, i32 } %204, i32 %203, 1
  resume { ptr, i32 } %205
}

; <alloc::string::String>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !95 {
start:
  %_2 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8 %_2, i64 %capacity) #17
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !96 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #17
  ret i64 %_0
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !97 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #17
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %ch) #17
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %ch_len) #17
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8 %self) #17
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i32 %ch, ptr %_0.i) #17
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8 %self, i64 %_14) #17
  ret void
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !98 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::string::String>::push_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %string.0, i64 %string.1) unnamed_addr #0 !guid !99 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %string.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %string.1, 1
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; call <alloc::vec::Vec<u8>>::extend_from_slice
  call void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8 %self, ptr %_4.0, i64 %_4.1)
  ret void
}

; <i8>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa10strict_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !100 {
start:
  %_3 = alloca [2 x i8], align 1
; call <i8>::checked_pow
  %1 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) #17
  %2 = extractvalue { i1, i8 } %1, 0
  %3 = extractvalue { i1, i8 } %1, 1
  %4 = zext i1 %2 to i8
  store i8 %4, ptr %_3, align 1
  %5 = getelementptr inbounds i8, ptr %_3, i64 1
  store i8 %3, ptr %5, align 1
  %6 = load i8, ptr %_3, align 1
  %7 = trunc nuw i8 %6 to i1
  %8 = getelementptr inbounds i8, ptr %_3, i64 1
  %9 = load i8, ptr %8, align 1
  %_4 = zext i1 %7 to i64
  %10 = trunc nuw i64 %_4 to i1
  br i1 %10, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %11 = getelementptr inbounds i8, ptr %_3, i64 1
  %x = load i8, ptr %11, align 1
  ret i8 %x

bb3:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i8>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !101 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.sadd.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <i8>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_divCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !102 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %_5 = icmp eq i8 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i8 %self, -128
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i8 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = sdiv i8 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_7, ptr %6, align 1
  store i8 1, ptr %_0, align 1
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  %9 = getelementptr inbounds i8, ptr %_0, i64 1
  %10 = load i8, ptr %9, align 1
  %11 = insertvalue { i1, i8 } poison, i1 %8, 0
  %12 = insertvalue { i1, i8 } %11, i8 %10, 1
  ret { i1, i8 } %12
}

; <i8>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !103 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <i8>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %0) unnamed_addr #0 !guid !104 {
start:
  %_57 = alloca [2 x i8], align 1
  %_48 = alloca [2 x i8], align 1
  %_38 = alloca [2 x i8], align 1
  %_32 = alloca [2 x i8], align 1
  %_13 = alloca [8 x i8], align 4
  %acc = alloca [1 x i8], align 1
  %base = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i8 %self, ptr %base, align 1
  store i8 1, ptr %acc, align 1
  %_6 = load i8, ptr %base, align 1
  %_5 = call i1 @llvm.is.constant.i8(i8 %_6)
  br i1 %_5, label %bb2, label %bb16

bb16:                                             ; preds = %bb2, %start
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp eq i32 %_24, 0
  br i1 %_23, label %bb17, label %bb18

bb2:                                              ; preds = %start
  %_9 = load i8, ptr %base, align 1
; call <i8>::unsigned_abs
  %_8 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_9) #17
  %1 = call i8 @llvm.ctpop.i8(i8 %_8)
  %_0.i.i = zext i8 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb16

bb5:                                              ; preds = %bb2
  %_12 = load i8, ptr %base, align 1
; call <i8>::unsigned_abs
  %_11 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_12) #17
; call <u8>::ilog2
  %k = call i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %_11, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #17
  %_14 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i32 %k, i32 %_14) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_13, align 4
  %5 = getelementptr inbounds i8, ptr %_13, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_13, align 4
  %7 = getelementptr inbounds i8, ptr %_13, i64 4
  %8 = load i32, ptr %7, align 4
  %_15 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_15 to i1
  br i1 %9, label %bb11, label %bb10

bb18:                                             ; preds = %bb16
  %_26 = load i32, ptr %exp, align 4
  %_25 = call i1 @llvm.is.constant.i32(i32 %_26)
  br i1 %_25, label %bb20, label %bb32

bb17:                                             ; preds = %bb16
  %10 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %10, align 1
  store i8 1, ptr %_0, align 1
  br label %bb43

bb32:                                             ; preds = %bb42, %bb18
  %_47 = load i32, ptr %exp, align 4
  %_46 = and i32 %_47, 1
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb33, label %bb38

bb20:                                             ; preds = %bb30, %bb18
  %_28 = load i32, ptr %exp, align 4
  %_27 = icmp ugt i32 %_28, 1
  br i1 %_27, label %bb21, label %bb31

bb38:                                             ; preds = %bb36, %bb32
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_58 = load i8, ptr %base, align 1
  %_59 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %13 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_58, i8 %_59) #17
  %14 = extractvalue { i1, i8 } %13, 0
  %15 = extractvalue { i1, i8 } %13, 1
  %16 = zext i1 %14 to i8
  store i8 %16, ptr %_57, align 1
  %17 = getelementptr inbounds i8, ptr %_57, i64 1
  store i8 %15, ptr %17, align 1
  %18 = load i8, ptr %_57, align 1
  %19 = trunc nuw i8 %18 to i1
  %20 = getelementptr inbounds i8, ptr %_57, i64 1
  %21 = load i8, ptr %20, align 1
  %_60 = zext i1 %19 to i64
  %22 = trunc nuw i64 %_60 to i1
  br i1 %22, label %bb42, label %bb41

bb33:                                             ; preds = %bb32
  %_49 = load i8, ptr %acc, align 1
  %_50 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %23 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_49, i8 %_50) #17
  %24 = extractvalue { i1, i8 } %23, 0
  %25 = extractvalue { i1, i8 } %23, 1
  %26 = zext i1 %24 to i8
  store i8 %26, ptr %_48, align 1
  %27 = getelementptr inbounds i8, ptr %_48, i64 1
  store i8 %25, ptr %27, align 1
  %28 = load i8, ptr %_48, align 1
  %29 = trunc nuw i8 %28 to i1
  %30 = getelementptr inbounds i8, ptr %_48, i64 1
  %31 = load i8, ptr %30, align 1
  %_51 = zext i1 %29 to i64
  %32 = trunc nuw i64 %_51 to i1
  br i1 %32, label %bb36, label %bb35

bb36:                                             ; preds = %bb33
  %33 = getelementptr inbounds i8, ptr %_48, i64 1
  %x = load i8, ptr %33, align 1
  store i8 %x, ptr %acc, align 1
  %_54 = load i32, ptr %exp, align 4
  %_53 = icmp eq i32 %_54, 1
  br i1 %_53, label %bb37, label %bb38

bb35:                                             ; preds = %bb33
  store i8 0, ptr %_0, align 1
  br label %bb43

bb43:                                             ; preds = %bb14, %bb15, %bb10, %bb17, %bb29, %bb24, %bb31, %bb37, %bb41, %bb35
  %34 = load i8, ptr %_0, align 1
  %35 = trunc nuw i8 %34 to i1
  %36 = getelementptr inbounds i8, ptr %_0, i64 1
  %37 = load i8, ptr %36, align 1
  %38 = insertvalue { i1, i8 } poison, i1 %35, 0
  %39 = insertvalue { i1, i8 } %38, i8 %37, 1
  ret { i1, i8 } %39

bb37:                                             ; preds = %bb36
  %_55 = load i8, ptr %acc, align 1
  %40 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_55, ptr %40, align 1
  store i8 1, ptr %_0, align 1
  br label %bb43

bb42:                                             ; preds = %bb38
  %41 = getelementptr inbounds i8, ptr %_57, i64 1
  %x1 = load i8, ptr %41, align 1
  store i8 %x1, ptr %base, align 1
  br label %bb32

bb41:                                             ; preds = %bb38
  store i8 0, ptr %_0, align 1
  br label %bb43

bb31:                                             ; preds = %bb20
  %_43 = load i8, ptr %acc, align 1
  %_44 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %42 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_43, i8 %_44) #17
  %43 = extractvalue { i1, i8 } %42, 0
  %44 = extractvalue { i1, i8 } %42, 1
  %45 = zext i1 %43 to i8
  store i8 %45, ptr %_0, align 1
  %46 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %44, ptr %46, align 1
  br label %bb43

bb21:                                             ; preds = %bb20
  %_31 = load i32, ptr %exp, align 4
  %_30 = and i32 %_31, 1
  %_29 = icmp eq i32 %_30, 1
  br i1 %_29, label %bb22, label %bb26

bb26:                                             ; preds = %bb25, %bb21
  %47 = load i32, ptr %exp, align 4
  %48 = udiv i32 %47, 2
  store i32 %48, ptr %exp, align 4
  %_39 = load i8, ptr %base, align 1
  %_40 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %49 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_39, i8 %_40) #17
  %50 = extractvalue { i1, i8 } %49, 0
  %51 = extractvalue { i1, i8 } %49, 1
  %52 = zext i1 %50 to i8
  store i8 %52, ptr %_38, align 1
  %53 = getelementptr inbounds i8, ptr %_38, i64 1
  store i8 %51, ptr %53, align 1
  %54 = load i8, ptr %_38, align 1
  %55 = trunc nuw i8 %54 to i1
  %56 = getelementptr inbounds i8, ptr %_38, i64 1
  %57 = load i8, ptr %56, align 1
  %_41 = zext i1 %55 to i64
  %58 = trunc nuw i64 %_41 to i1
  br i1 %58, label %bb30, label %bb29

bb22:                                             ; preds = %bb21
  %_33 = load i8, ptr %acc, align 1
  %_34 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %59 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_33, i8 %_34) #17
  %60 = extractvalue { i1, i8 } %59, 0
  %61 = extractvalue { i1, i8 } %59, 1
  %62 = zext i1 %60 to i8
  store i8 %62, ptr %_32, align 1
  %63 = getelementptr inbounds i8, ptr %_32, i64 1
  store i8 %61, ptr %63, align 1
  %64 = load i8, ptr %_32, align 1
  %65 = trunc nuw i8 %64 to i1
  %66 = getelementptr inbounds i8, ptr %_32, i64 1
  %67 = load i8, ptr %66, align 1
  %_35 = zext i1 %65 to i64
  %68 = trunc nuw i64 %_35 to i1
  br i1 %68, label %bb25, label %bb24

bb25:                                             ; preds = %bb22
  %69 = getelementptr inbounds i8, ptr %_32, i64 1
  %x2 = load i8, ptr %69, align 1
  store i8 %x2, ptr %acc, align 1
  br label %bb26

bb24:                                             ; preds = %bb22
  store i8 0, ptr %_0, align 1
  br label %bb43

bb30:                                             ; preds = %bb26
  %70 = getelementptr inbounds i8, ptr %_38, i64 1
  %x3 = load i8, ptr %70, align 1
  store i8 %x3, ptr %base, align 1
  br label %bb20

bb29:                                             ; preds = %bb26
  store i8 0, ptr %_0, align 1
  br label %bb43

bb11:                                             ; preds = %bb5
  %71 = getelementptr inbounds i8, ptr %_13, i64 4
  %shift = load i32, ptr %71, align 4
  %_18 = load i8, ptr %base, align 1
  %_17 = icmp slt i8 %_18, 0
  br i1 %_17, label %bb12, label %bb15

bb10:                                             ; preds = %bb5
  store i8 0, ptr %_0, align 1
  br label %bb43

bb15:                                             ; preds = %bb12, %bb11
; call <i8>::shl_exact
  %72 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa9shl_exactCs8pRW9QHXPaM_10int_ops_i8(i8 1, i32 %shift) #17
  %73 = extractvalue { i1, i8 } %72, 0
  %74 = extractvalue { i1, i8 } %72, 1
  %75 = zext i1 %73 to i8
  store i8 %75, ptr %_0, align 1
  %76 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %74, ptr %76, align 1
  br label %bb43

bb12:                                             ; preds = %bb11
  %_21 = load i32, ptr %exp, align 4
  %_20 = urem i32 %_21, 2
  %_19 = icmp eq i32 %_20, 1
  br i1 %_19, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
; call <i8>::shl_exact
  %77 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa9shl_exactCs8pRW9QHXPaM_10int_ops_i8(i8 -1, i32 %shift) #17
  %78 = extractvalue { i1, i8 } %77, 0
  %79 = extractvalue { i1, i8 } %77, 1
  %80 = zext i1 %78 to i8
  store i8 %80, ptr %_0, align 1
  %81 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %79, ptr %81, align 1
  br label %bb43

bb9:                                              ; No predecessors!
  unreachable
}

; <i8>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_remCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !105 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %_5 = icmp eq i8 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i8 %self, -128
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i8 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = srem i8 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_7, ptr %6, align 1
  store i8 1, ptr %_0, align 1
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  %9 = getelementptr inbounds i8, ptr %_0, i64 1
  %10 = load i8, ptr %9, align 1
  %11 = insertvalue { i1, i8 } poison, i1 %8, 0
  %12 = insertvalue { i1, i8 } %11, i8 %10, 1
  ret { i1, i8 } %12
}

; <i8>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_subCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !106 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.ssub.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <i8>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !107 {
start:
; call <i8>::wrapping_abs
  %_2 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12wrapping_absCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #17
  ret i8 %_2
}

; <i8>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12wrapping_absCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !108 {
start:
  %_0 = alloca [1 x i8], align 1
  %_0.i = icmp slt i8 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 %self, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i8 0, %self
  store i8 %_0.i2, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; <i8>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12wrapping_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) unnamed_addr #0 !guid !109 {
start:
; call <i8>::overflowing_pow
  %0 = call { i8, i1 } @_RNvMNtCsl10jNU3mE6R_4core3numa15overflowing_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) #17
  %_3.0 = extractvalue { i8, i1 } %0, 0
  %_3.1 = extractvalue { i8, i1 } %0, 1
  ret i8 %_3.0
}

; <i8>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtCsl10jNU3mE6R_4core3numa13checked_ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !110 {
start:
  %_0 = alloca [8 x i8], align 4
  %_2 = icmp sle i8 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = call i8 @llvm.ctlz.i8(i8 %self, i1 true)
  %_5 = zext i8 %0 to i32
  %log = sub i32 7, %_5
  %1 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %log, ptr %1, align 4
  store i32 1, ptr %_0, align 4
  br label %bb4

bb1:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  %2 = load i32, ptr %_0, align 4
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  %4 = load i32, ptr %3, align 4
  %5 = insertvalue { i32, i32 } poison, i32 %2, 0
  %6 = insertvalue { i32, i32 } %5, i32 %4, 1
  ret { i32, i32 } %6
}

; <i8>::checked_isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa13checked_isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !111 {
start:
  %_0 = alloca [2 x i8], align 1
  %_2 = icmp slt i8 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call <u8>::isqrt
  %_4 = call i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #17
  %_7 = icmp sle i8 %_4, 11
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb2
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_7, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb2, %bb2.i
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_4, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb7

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb1, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %1 = load i8, ptr %_0, align 1
  %2 = trunc nuw i8 %1 to i1
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  %4 = load i8, ptr %3, align 1
  %5 = insertvalue { i1, i8 } poison, i1 %2, 0
  %6 = insertvalue { i1, i8 } %5, i8 %4, 1
  ret { i1, i8 } %6
}

; <i8>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa13unbounded_shlCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %rhs) unnamed_addr #0 !guid !112 {
start:
  %_0 = alloca [1 x i8], align 1
  %_3 = icmp ult i32 %rhs, 8
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <i8>::unchecked_shl::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %rhs, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #22
  br label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = trunc nuw i32 %rhs to i8
  %_0.i = shl i8 %self, %0
  store i8 %_0.i, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit, %bb2
  %1 = load i8, ptr %_0, align 1
  ret i8 %1
}

; <i8>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i8, i1 } @_RNvMNtCsl10jNU3mE6R_4core3numa15overflowing_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %0) unnamed_addr #0 !guid !113 {
start:
  %_30 = alloca [2 x i8], align 1
  %base1 = alloca [1 x i8], align 1
  %_16 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [1 x i8], align 1
  %base = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i8 %self, ptr %base, align 1
  store i8 1, ptr %acc, align 1
  store i8 0, ptr %overflow, align 1
  %_8 = load i8, ptr %base, align 1
  %_7 = call i1 @llvm.is.constant.i8(i8 %_8)
  br i1 %_7, label %bb2, label %bb19

bb19:                                             ; preds = %bb2, %start
  %_33 = load i32, ptr %exp, align 4
  %_32 = icmp eq i32 %_33, 0
  br i1 %_32, label %bb20, label %bb21

bb2:                                              ; preds = %start
  %_11 = load i8, ptr %base, align 1
; call <i8>::unsigned_abs
  %_10 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_11) #17
  %1 = call i8 @llvm.ctpop.i8(i8 %_10)
  %_0.i.i = zext i8 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb19

bb5:                                              ; preds = %bb2
  %_14 = load i8, ptr %base, align 1
; call <i8>::unsigned_abs
  %_13 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_14) #17
; call <u8>::ilog2
  %k = call i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %_13, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #17
  %_17 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i32 %k, i32 %_17) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_16, align 4
  %5 = getelementptr inbounds i8, ptr %_16, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_16, align 4
  %7 = getelementptr inbounds i8, ptr %_16, i64 4
  %8 = load i32, ptr %7, align 4
  %_18 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_18 to i1
  br i1 %9, label %bb9, label %bb10

bb21:                                             ; preds = %bb19
  %_35 = load i32, ptr %exp, align 4
  %_34 = call i1 @llvm.is.constant.i32(i32 %_35)
  br i1 %_34, label %bb23, label %bb32

bb20:                                             ; preds = %bb19
  store i16 1, ptr %_0, align 1
  br label %bb39

bb32:                                             ; preds = %bb36, %bb21
  %_64 = load i32, ptr %exp, align 4
  %_63 = and i32 %_64, 1
  %_62 = icmp eq i32 %_63, 1
  br i1 %_62, label %bb33, label %bb36

bb23:                                             ; preds = %bb27, %bb21
  %_37 = load i32, ptr %exp, align 4
  %_36 = icmp ugt i32 %_37, 1
  br i1 %_36, label %bb24, label %bb30

bb36:                                             ; preds = %bb33, %bb32
  %10 = load i32, ptr %exp, align 4
  %11 = udiv i32 %10, 2
  store i32 %11, ptr %exp, align 4
  %_79 = load i8, ptr %base, align 1
  %_80 = load i8, ptr %base, align 1
  %12 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_79, i8 %_80)
  %_5.0.i6 = extractvalue { i8, i1 } %12, 0
  %_5.1.i7 = extractvalue { i8, i1 } %12, 1
  %_78.0 = extractvalue { i8, i1 } %12, 0
  %_78.1 = extractvalue { i8, i1 } %12, 1
  store i8 %_78.0, ptr %base, align 1
  %13 = zext i1 %_78.1 to i8
  store i8 %13, ptr %tmp_overflow, align 1
  %14 = load i8, ptr %tmp_overflow, align 1
  %_81 = trunc nuw i8 %14 to i1
  %15 = load i8, ptr %overflow, align 1
  %16 = trunc nuw i8 %15 to i1
  %17 = or i1 %16, %_81
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %overflow, align 1
  br label %bb32

bb33:                                             ; preds = %bb32
  %_68 = load i8, ptr %acc, align 1
  %_69 = load i8, ptr %base, align 1
  %19 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_68, i8 %_69)
  %_5.0.i8 = extractvalue { i8, i1 } %19, 0
  %_5.1.i9 = extractvalue { i8, i1 } %19, 1
  %_67.0 = extractvalue { i8, i1 } %19, 0
  %_67.1 = extractvalue { i8, i1 } %19, 1
  store i8 %_67.0, ptr %acc, align 1
  %20 = zext i1 %_67.1 to i8
  store i8 %20, ptr %tmp_overflow, align 1
  %21 = load i8, ptr %tmp_overflow, align 1
  %_70 = trunc nuw i8 %21 to i1
  %22 = load i8, ptr %overflow, align 1
  %23 = trunc nuw i8 %22 to i1
  %24 = or i1 %23, %_70
  %25 = zext i1 %24 to i8
  store i8 %25, ptr %overflow, align 1
  %_72 = load i32, ptr %exp, align 4
  %_71 = icmp eq i32 %_72, 1
  br i1 %_71, label %bb35, label %bb36

bb35:                                             ; preds = %bb33
  %_73 = load i8, ptr %acc, align 1
  %26 = load i8, ptr %overflow, align 1
  %_74 = trunc nuw i8 %26 to i1
  store i8 %_73, ptr %_0, align 1
  %27 = getelementptr inbounds i8, ptr %_0, i64 1
  %28 = zext i1 %_74 to i8
  store i8 %28, ptr %27, align 1
  br label %bb39

bb39:                                             ; preds = %bb10, %bb15, %bb20, %bb30, %bb35
  %29 = load i8, ptr %_0, align 1
  %30 = getelementptr inbounds i8, ptr %_0, i64 1
  %31 = load i8, ptr %30, align 1
  %32 = trunc nuw i8 %31 to i1
  %33 = insertvalue { i8, i1 } poison, i8 %29, 0
  %34 = insertvalue { i8, i1 } %33, i1 %32, 1
  ret { i8, i1 } %34

bb30:                                             ; preds = %bb23
  %_57 = load i8, ptr %acc, align 1
  %_58 = load i8, ptr %base, align 1
  %35 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_57, i8 %_58)
  %_5.0.i4 = extractvalue { i8, i1 } %35, 0
  %_5.1.i5 = extractvalue { i8, i1 } %35, 1
  %_56.0 = extractvalue { i8, i1 } %35, 0
  %_56.1 = extractvalue { i8, i1 } %35, 1
  store i8 %_56.0, ptr %acc, align 1
  %36 = zext i1 %_56.1 to i8
  store i8 %36, ptr %tmp_overflow, align 1
  %37 = load i8, ptr %tmp_overflow, align 1
  %_59 = trunc nuw i8 %37 to i1
  %38 = load i8, ptr %overflow, align 1
  %39 = trunc nuw i8 %38 to i1
  %40 = or i1 %39, %_59
  %41 = zext i1 %40 to i8
  store i8 %41, ptr %overflow, align 1
  %_60 = load i8, ptr %acc, align 1
  %42 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %42 to i1
  store i8 %_60, ptr %_0, align 1
  %43 = getelementptr inbounds i8, ptr %_0, i64 1
  %44 = zext i1 %_61 to i8
  store i8 %44, ptr %43, align 1
  br label %bb39

bb24:                                             ; preds = %bb23
  %_40 = load i32, ptr %exp, align 4
  %_39 = and i32 %_40, 1
  %_38 = icmp eq i32 %_39, 1
  br i1 %_38, label %bb25, label %bb27

bb27:                                             ; preds = %bb25, %bb24
  %45 = load i32, ptr %exp, align 4
  %46 = udiv i32 %45, 2
  store i32 %46, ptr %exp, align 4
  %_51 = load i8, ptr %base, align 1
  %_52 = load i8, ptr %base, align 1
  %47 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_51, i8 %_52)
  %_5.0.i = extractvalue { i8, i1 } %47, 0
  %_5.1.i = extractvalue { i8, i1 } %47, 1
  %_50.0 = extractvalue { i8, i1 } %47, 0
  %_50.1 = extractvalue { i8, i1 } %47, 1
  store i8 %_50.0, ptr %base, align 1
  %48 = zext i1 %_50.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_53 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_53
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  br label %bb23

bb25:                                             ; preds = %bb24
  %_44 = load i8, ptr %acc, align 1
  %_45 = load i8, ptr %base, align 1
  %54 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_44, i8 %_45)
  %_5.0.i2 = extractvalue { i8, i1 } %54, 0
  %_5.1.i3 = extractvalue { i8, i1 } %54, 1
  %_43.0 = extractvalue { i8, i1 } %54, 0
  %_43.1 = extractvalue { i8, i1 } %54, 1
  store i8 %_43.0, ptr %acc, align 1
  %55 = zext i1 %_43.1 to i8
  store i8 %55, ptr %tmp_overflow, align 1
  %56 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %56 to i1
  %57 = load i8, ptr %overflow, align 1
  %58 = trunc nuw i8 %57 to i1
  %59 = or i1 %58, %_46
  %60 = zext i1 %59 to i8
  store i8 %60, ptr %overflow, align 1
  br label %bb27

bb9:                                              ; preds = %bb5
  %61 = getelementptr inbounds i8, ptr %_16, i64 4
  %shift = load i32, ptr %61, align 4
  %_21 = load i8, ptr %base, align 1
  %_20 = icmp slt i8 %_21, 0
  br i1 %_20, label %bb11, label %bb14

bb10:                                             ; preds = %bb5
  store i16 256, ptr %_0, align 1
  br label %bb39

bb14:                                             ; preds = %bb11, %bb9
  store i8 1, ptr %base1, align 1
  br label %bb15

bb11:                                             ; preds = %bb9
  %_24 = load i32, ptr %exp, align 4
  %_23 = urem i32 %_24, 2
  %_22 = icmp ne i32 %_23, 0
  br i1 %_22, label %bb13, label %bb14

bb13:                                             ; preds = %bb11
  store i8 -1, ptr %base1, align 1
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_27 = load i8, ptr %base1, align 1
; call <i8>::unbounded_shl
  %_26 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa13unbounded_shlCs8pRW9QHXPaM_10int_ops_i8(i8 %_27, i32 %shift) #17
  %_31 = load i8, ptr %base1, align 1
; call <i8>::shl_exact
  %62 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa9shl_exactCs8pRW9QHXPaM_10int_ops_i8(i8 %_31, i32 %shift) #17
  %63 = extractvalue { i1, i8 } %62, 0
  %64 = extractvalue { i1, i8 } %62, 1
  %65 = zext i1 %63 to i8
  store i8 %65, ptr %_30, align 1
  %66 = getelementptr inbounds i8, ptr %_30, i64 1
  store i8 %64, ptr %66, align 1
; call <core::option::Option<i8>>::is_none
  %_28 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionaE7is_noneCs8pRW9QHXPaM_10int_ops_i8(ptr %_30) #17
  store i8 %_26, ptr %_0, align 1
  %67 = getelementptr inbounds i8, ptr %_0, i64 1
  %68 = zext i1 %_28 to i8
  store i8 %68, ptr %67, align 1
  br label %bb39

bb40:                                             ; No predecessors!
  unreachable
}

; <i8>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa3powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) unnamed_addr #0 !guid !114 {
start:
  %_0 = alloca [1 x i8], align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <i8>::strict_pow
  %0 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa10strict_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #17
  store i8 %0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; No predecessors!
; call <i8>::wrapping_pow
  %1 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12wrapping_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) #17
  store i8 %1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_0, align 1
  ret i8 %2
}

; <i8>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtCsl10jNU3mE6R_4core3numa5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self, ptr align 8 %0) unnamed_addr #0 !guid !115 {
start:
  %_2 = alloca [8 x i8], align 4
; call <i8>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMNtCsl10jNU3mE6R_4core3numa13checked_ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i8>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa5isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self, ptr align 8 %0) unnamed_addr #0 !guid !116 {
start:
  %_2 = alloca [2 x i8], align 1
; call <i8>::checked_isqrt
  %1 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa13checked_isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #17
  %2 = extractvalue { i1, i8 } %1, 0
  %3 = extractvalue { i1, i8 } %1, 1
  %4 = zext i1 %2 to i8
  store i8 %4, ptr %_2, align 1
  %5 = getelementptr inbounds i8, ptr %_2, i64 1
  store i8 %3, ptr %5, align 1
  %6 = load i8, ptr %_2, align 1
  %7 = trunc nuw i8 %6 to i1
  %8 = getelementptr inbounds i8, ptr %_2, i64 1
  %9 = load i8, ptr %8, align 1
  %_3 = zext i1 %7 to i64
  %10 = trunc nuw i64 %_3 to i1
  br i1 %10, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %11 = getelementptr inbounds i8, ptr %_2, i64 1
  %sqrt = load i8, ptr %11, align 1
  ret i8 %sqrt

bb3:                                              ; preds = %start
; call core::num::imp::int_sqrt::panic_for_negative_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i8>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa8abs_diffCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %other) unnamed_addr #0 !guid !117 {
start:
  %_0 = alloca [1 x i8], align 1
  %_3 = icmp slt i8 %self, %other
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_0.i1 = sub i8 %self, %other
  store i8 %_0.i1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  %_0.i = sub i8 %other, %self
  store i8 %_0.i, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; <i8>::shl_exact
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa9shl_exactCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %rhs) unnamed_addr #0 !guid !118 {
start:
  %_0 = alloca [2 x i8], align 1
  %0 = call i8 @llvm.ctlz.i8(i8 %self, i1 false)
  %_0.i4 = zext i8 %0 to i32
  %_3 = icmp ult i32 %rhs, %_0.i4
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_2.i = xor i8 %self, -1
  %1 = call i8 @llvm.ctlz.i8(i8 %_2.i, i1 false)
  %_0.i = zext i8 %1 to i32
  %_5 = icmp ult i32 %rhs, %_0.i
  br i1 %_5, label %bb4, label %bb6

bb4:                                              ; preds = %bb2, %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

bb2.i:                                            ; preds = %bb4
; call <i8>::unchecked_shl::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %rhs, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #22
  br label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit: ; preds = %bb4, %bb2.i
  %2 = trunc nuw i32 %rhs to i8
  %_0.i2 = shl i8 %self, %2
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_0.i2, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb2
  store i8 0, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit, %bb6
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !119 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<i8>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionaE7is_noneCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !120 {
start:
; call <core::option::Option<i8>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionaE7is_someCs8pRW9QHXPaM_10int_ops_i8(ptr %self) #17
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::option::Option<i8>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionaE7is_someCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !121 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_2 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %5 = load i8, ptr %_0, align 1
  %6 = trunc nuw i8 %5 to i1
  ret i1 %6

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i8, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultaNtNtNtB4_3num5error13ParseIntErrorE5is_okCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !122 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_2 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %5 = load i8, ptr %_0, align 1
  %6 = trunc nuw i8 %5 to i1
  ret i1 %6

bb4:                                              ; No predecessors!
  unreachable
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %self) unnamed_addr #0 !guid !123 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %self) #17
  ret i64 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %self, i32 %radix) unnamed_addr #0 !guid !124 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #17
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #23
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::ptr::non_null::NonNull<core::option::Option<i8>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionaEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !125 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultaNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !126 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<(i8, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTabEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !127 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !128 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !129 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %r) unnamed_addr #0 !guid !130 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 4 %r) unnamed_addr #0 !guid !131 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !132 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #17
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr %_7.0, i64 %_7.1) #17
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !133 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs8pRW9QHXPaM_10int_ops_i8(ptr %s.0, i64 %s.1) #17
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u8>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh13checked_ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !134 {
start:
  %_2 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u8>>::new
  %0 = call i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3newB9_(i8 %self) #17
  store i8 %0, ptr %_2, align 1
  %1 = load i8, ptr %_2, align 1
  %2 = icmp eq i8 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i8, ptr %_2, align 1
; call <core::num::nonzero::NonZero<u8>>::ilog2
  %_5 = call i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %x) #17
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u8>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self, ptr align 8 %0) unnamed_addr #0 !guid !135 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u8>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh13checked_ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u8>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !136 {
start:
; call core::num::imp::int_sqrt::u8
  %result = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) #17
  %_3 = icmp ule i8 %result, 15
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_3, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i8 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u8>::unchecked_mul::precondition_check
  call void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i8 %result, i8 %result, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit

_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i8 %result, %result
  %_8 = icmp ule i8 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_8, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i8 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_11, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i8 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i8 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_6, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i32 %self, i32 %rhs) unnamed_addr #0 !guid !137 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !138 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u8>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE13leading_zerosCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !139 {
start:
; call <core::num::nonzero::NonZero<u8>>::get
  %_2 = call i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3getB9_(i8 %self) #17
  %0 = call i8 @llvm.ctlz.i8(i8 %_2, i1 true)
  %_0 = zext i8 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u8>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !140 {
start:
; call <core::num::nonzero::NonZero<u8>>::leading_zeros
  %_3 = call i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE13leading_zerosCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #17
  %_0 = sub i32 7, %_3
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs8pRW9QHXPaM_10int_ops_i8(i8 %0) unnamed_addr #0 !guid !141 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs8pRW9QHXPaM_10int_ops_i8(ptr %self) #17
  ret i32 %_0
}

; <i8>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa14from_str_radixCs8pRW9QHXPaM_10int_ops_i8(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !142 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <i8>::from_ascii_bytes_radix_impl
  %2 = call { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa27from_ascii_bytes_radix_implCs8pRW9QHXPaM_10int_ops_i8(ptr %_3.0, i64 %_3.1, i32 %radix) #17
  %_0.0 = extractvalue { i1, i8 } %2, 0
  %_0.1 = extractvalue { i1, i8 } %2, 1
  %3 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %4 = insertvalue { i1, i8 } %3, i8 %_0.1, 1
  ret { i1, i8 } %4
}

; <i8>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa27from_ascii_bytes_radix_implCs8pRW9QHXPaM_10int_ops_i8(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !143 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [2 x i8], align 1
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [2 x i8], align 1
  %_74 = alloca [2 x i8], align 1
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [2 x i8], align 1
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [1 x i8], align 1
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [2 x i8], align 1
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #23
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #17
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %10 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 %src.1, ptr %11, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %12 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %13 = load i8, ptr %12, align 1
  switch i8 %13, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %14, i64 8
  store i64 %rest.1, ptr %15, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %16 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %17 = sub i64 %src.1, 1
  store ptr %16, ptr %rest, align 8
  %18 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %19 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %19 to i1
  %20 = getelementptr inbounds i8, ptr %_12, i64 8
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr inbounds i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  store ptr %21, ptr %digits, align 8, !captures !144
  %24 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %23, ptr %24, align 8
  store i8 0, ptr %result, align 1
  %_24.0 = load ptr, ptr %digits, align 8
  %25 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %25, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit

bb1.i:                                            ; preds = %bb15
  %26 = icmp ule i64 %_24.1, 1
  %27 = zext i1 %26 to i8
  store i8 %27, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit: ; preds = %bb2.i, %bb1.i
  %28 = load i8, ptr %_0.i, align 1
  %29 = trunc nuw i8 %28 to i1
  br i1 %29, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %30 = load ptr, ptr %rest, align 8
  %31 = getelementptr inbounds i8, ptr %rest, i64 8
  %32 = load i64, ptr %31, align 8
  %33 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %30, ptr %33, align 8
  %34 = getelementptr inbounds i8, ptr %33, i64 8
  store i64 %32, ptr %34, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %36, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %38, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i8, ptr %result, align 1
  %39 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_105, ptr %39, align 1
  store i8 0, ptr %_0, align 1
  br label %bb53

bb42:                                             ; preds = %bb41
  %40 = load ptr, ptr %digits, align 8
  %41 = getelementptr inbounds i8, ptr %digits, i64 8
  %42 = load i64, ptr %41, align 8
  %c = getelementptr inbounds nuw i8, ptr %40, i64 0
  %43 = load ptr, ptr %digits, align 8
  %44 = getelementptr inbounds i8, ptr %digits, i64 8
  %45 = load i64, ptr %44, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %43, i64 1
  %rest.13 = sub i64 %45, 1
  %_85 = load i8, ptr %result, align 1
  %_86 = trunc i32 %radix to i8
; call <i8>::checked_mul
  %46 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_85, i8 %_86) #17
  %47 = extractvalue { i1, i8 } %46, 0
  %48 = extractvalue { i1, i8 } %46, 1
  %49 = zext i1 %47 to i8
  store i8 %49, ptr %mul1, align 1
  %50 = getelementptr inbounds i8, ptr %mul1, i64 1
  store i8 %48, ptr %50, align 1
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %51 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %_89, i32 %radix) #17
  %52 = extractvalue { i32, i32 } %51, 0
  %53 = extractvalue { i32, i32 } %51, 1
  store i32 %52, ptr %_88, align 4
  %54 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %53, ptr %54, align 4
  %55 = load i32, ptr %_88, align 4
  %56 = getelementptr inbounds i8, ptr %_88, i64 4
  %57 = load i32, ptr %56, align 4
  %_91 = zext i32 %55 to i64
  %58 = trunc nuw i64 %_91 to i1
  br i1 %58, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %59 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %59, align 4
  %x = trunc i32 %value to i8
  %60 = load i8, ptr %mul1, align 1
  %61 = trunc nuw i8 %60 to i1
  %62 = getelementptr inbounds i8, ptr %mul1, i64 1
  %63 = load i8, ptr %62, align 1
  %_95 = zext i1 %61 to i64
  %64 = trunc nuw i64 %_95 to i1
  br i1 %64, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %65 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %65, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb48:                                             ; preds = %bb46
  %66 = getelementptr inbounds i8, ptr %mul1, i64 1
  %value4 = load i8, ptr %66, align 1
  store i8 %value4, ptr %result, align 1
  %_100 = load i8, ptr %result, align 1
; call <i8>::checked_sub
  %67 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_subCs8pRW9QHXPaM_10int_ops_i8(i8 %_100, i8 %x) #17
  %68 = extractvalue { i1, i8 } %67, 0
  %69 = extractvalue { i1, i8 } %67, 1
  %70 = zext i1 %68 to i8
  store i8 %70, ptr %_99, align 1
  %71 = getelementptr inbounds i8, ptr %_99, i64 1
  store i8 %69, ptr %71, align 1
  %72 = load i8, ptr %_99, align 1
  %73 = trunc nuw i8 %72 to i1
  %74 = getelementptr inbounds i8, ptr %_99, i64 1
  %75 = load i8, ptr %74, align 1
  %_101 = zext i1 %73 to i64
  %76 = trunc nuw i64 %_101 to i1
  br i1 %76, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %77 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %77, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb51:                                             ; preds = %bb48
  %78 = getelementptr inbounds i8, ptr %_99, i64 1
  %value5 = load i8, ptr %78, align 1
  store i8 %value5, ptr %result, align 1
  store ptr %rest.02, ptr %digits, align 8, !captures !144
  %79 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %79, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %80 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %80, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb31:                                             ; preds = %bb30
  %81 = load ptr, ptr %digits, align 8
  %82 = getelementptr inbounds i8, ptr %digits, i64 8
  %83 = load i64, ptr %82, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %81, i64 0
  %84 = load ptr, ptr %digits, align 8
  %85 = getelementptr inbounds i8, ptr %digits, i64 8
  %86 = load i64, ptr %85, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %84, i64 1
  %rest.18 = sub i64 %86, 1
  %_60 = load i8, ptr %result, align 1
  %_61 = trunc i32 %radix to i8
; call <i8>::checked_mul
  %87 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_60, i8 %_61) #17
  %88 = extractvalue { i1, i8 } %87, 0
  %89 = extractvalue { i1, i8 } %87, 1
  %90 = zext i1 %88 to i8
  store i8 %90, ptr %mul, align 1
  %91 = getelementptr inbounds i8, ptr %mul, i64 1
  store i8 %89, ptr %91, align 1
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %92 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %_64, i32 %radix) #17
  %93 = extractvalue { i32, i32 } %92, 0
  %94 = extractvalue { i32, i32 } %92, 1
  store i32 %93, ptr %_63, align 4
  %95 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %94, ptr %95, align 4
  %96 = load i32, ptr %_63, align 4
  %97 = getelementptr inbounds i8, ptr %_63, i64 4
  %98 = load i32, ptr %97, align 4
  %_66 = zext i32 %96 to i64
  %99 = trunc nuw i64 %_66 to i1
  br i1 %99, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %100 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %100, align 4
  %x10 = trunc i32 %value9 to i8
  %101 = load i8, ptr %mul, align 1
  %102 = trunc nuw i8 %101 to i1
  %103 = getelementptr inbounds i8, ptr %mul, i64 1
  %104 = load i8, ptr %103, align 1
  %_70 = zext i1 %102 to i64
  %105 = trunc nuw i64 %_70 to i1
  br i1 %105, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %106 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %106, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb37:                                             ; preds = %bb35
  %107 = getelementptr inbounds i8, ptr %mul, i64 1
  %value11 = load i8, ptr %107, align 1
  store i8 %value11, ptr %result, align 1
  %_75 = load i8, ptr %result, align 1
; call <i8>::checked_add
  %108 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs8pRW9QHXPaM_10int_ops_i8(i8 %_75, i8 %x10) #17
  %109 = extractvalue { i1, i8 } %108, 0
  %110 = extractvalue { i1, i8 } %108, 1
  %111 = zext i1 %109 to i8
  store i8 %111, ptr %_74, align 1
  %112 = getelementptr inbounds i8, ptr %_74, i64 1
  store i8 %110, ptr %112, align 1
  %113 = load i8, ptr %_74, align 1
  %114 = trunc nuw i8 %113 to i1
  %115 = getelementptr inbounds i8, ptr %_74, i64 1
  %116 = load i8, ptr %115, align 1
  %_76 = zext i1 %114 to i64
  %117 = trunc nuw i64 %_76 to i1
  br i1 %117, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %118 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %118, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb40:                                             ; preds = %bb37
  %119 = getelementptr inbounds i8, ptr %_74, i64 1
  %value12 = load i8, ptr %119, align 1
  store i8 %value12, ptr %result, align 1
  store ptr %rest.07, ptr %digits, align 8, !captures !144
  %120 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %120, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %121 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %121, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %122 = load ptr, ptr %digits, align 8
  %123 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %123, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %124 = load ptr, ptr %digits, align 8
  %125 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %125, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %126 = load ptr, ptr %digits, align 8
  %127 = getelementptr inbounds i8, ptr %digits, i64 8
  %128 = load i64, ptr %127, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %126, i64 0
  %129 = load ptr, ptr %digits, align 8
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  %131 = load i64, ptr %130, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %129, i64 1
  %rest.115 = sub i64 %131, 1
  %_44 = load i8, ptr %result, align 1
  %_45 = trunc i32 %radix to i8
  %132 = mul i8 %_44, %_45
  store i8 %132, ptr %result, align 1
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %133 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %_47, i32 %radix) #17
  %134 = extractvalue { i32, i32 } %133, 0
  %135 = extractvalue { i32, i32 } %133, 1
  store i32 %134, ptr %_46, align 4
  %136 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %135, ptr %136, align 4
  %137 = load i32, ptr %_46, align 4
  %138 = getelementptr inbounds i8, ptr %_46, i64 4
  %139 = load i32, ptr %138, align 4
  %_49 = zext i32 %137 to i64
  %140 = trunc nuw i64 %_49 to i1
  br i1 %140, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %141 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %141, align 4
  %_53 = load i8, ptr %result, align 1
  %_54 = trunc i32 %x16 to i8
  %142 = sub i8 %_53, %_54
  store i8 %142, ptr %result, align 1
  store ptr %rest.014, ptr %digits, align 8, !captures !144
  %143 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %143, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %144 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %144, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb19:                                             ; preds = %bb18
  %145 = load ptr, ptr %digits, align 8
  %146 = getelementptr inbounds i8, ptr %digits, i64 8
  %147 = load i64, ptr %146, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %145, i64 0
  %148 = load ptr, ptr %digits, align 8
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  %150 = load i64, ptr %149, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %148, i64 1
  %rest.119 = sub i64 %150, 1
  %_29 = load i8, ptr %result, align 1
  %_30 = trunc i32 %radix to i8
  %151 = mul i8 %_29, %_30
  store i8 %151, ptr %result, align 1
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %152 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %_32, i32 %radix) #17
  %153 = extractvalue { i32, i32 } %152, 0
  %154 = extractvalue { i32, i32 } %152, 1
  store i32 %153, ptr %_31, align 4
  %155 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %154, ptr %155, align 4
  %156 = load i32, ptr %_31, align 4
  %157 = getelementptr inbounds i8, ptr %_31, i64 4
  %158 = load i32, ptr %157, align 4
  %_34 = zext i32 %156 to i64
  %159 = trunc nuw i64 %_34 to i1
  br i1 %159, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %160 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %160, align 4
  %_38 = load i8, ptr %result, align 1
  %_39 = trunc i32 %x20 to i8
  %161 = add i8 %_38, %_39
  store i8 %161, ptr %result, align 1
  store ptr %rest.018, ptr %digits, align 8, !captures !144
  %162 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %162, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %163 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %163, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !145 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %args) #17
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #17
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #4 !guid !146 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #0 !guid !147 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs8pRW9QHXPaM_10int_ops_i8() #17
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !148 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i32 %code, ptr %dst) unnamed_addr #0 !guid !149 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %code) #17
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %code) unnamed_addr #0 !guid !150 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8Cs8pRW9QHXPaM_10int_ops_i8(i8 %n) unnamed_addr #0 !guid !151 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.681c060d2bfd6770ec9e5f1a4ed3b4ec.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #23
  unreachable
}

; <i8>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !152 {
start:
  %_2 = icmp ult i32 %rhs, 8
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_cbcfb4391f0fcdd0dcd48dbe6149ef89, i64 183)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <i8>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !153 {
start:
  %_2 = icmp ult i32 %rhs, 8
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_66558f7972e7e036e1d4ccb8be86690a, i64 183)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <u8>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i8 %lhs, i8 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !154 {
start:
  %1 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %lhs, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %1, 0
  %_5.1.i = extractvalue { i8, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i8, i1 } %1, 0
  %_4.1 = extractvalue { i8, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_eff87de2e562ad9bea1d5ede245212a6, i64 183)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !155 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #0 !guid !156 {
start:
  ret i1 true
}

; <i8 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1G_NtCs7CppTae75M1_5alloc6stringaNtB6_12SpecToString14spec_to_stringCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !157 {
start:
  %0 = alloca [16 x i8], align 8
  %_19 = alloca [1 x i8], align 1
  %_11 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  %out = alloca [24 x i8], align 8
  %buf = alloca [3 x i8], align 1
  store i8 0, ptr %_19, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 3, i1 false)
  %_6 = load i8, ptr %self, align 1
  %_5 = icmp slt i8 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_11, i64 3)
          to label %bb5 unwind label %cleanup

bb2:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_7, i64 4)
          to label %bb3 unwind label %cleanup

bb12:                                             ; preds = %cleanup
  %1 = load i8, ptr %_19, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb11, label %bb10

cleanup:                                          ; preds = %bb8, %bb7, %bb6, %bb3, %bb2, %bb4
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb12

bb5:                                              ; preds = %bb4
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_11, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb13, %bb5
  %_16 = load i8, ptr %self, align 1
; invoke <i8>::unsigned_abs
  %_15 = invoke i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_16)
          to label %bb7 unwind label %cleanup

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_7, i64 24, i1 false)
; invoke <alloc::string::String>::push
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %out, i32 45)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb3
  br label %bb6

bb7:                                              ; preds = %bb6
; invoke <u8>::_fmt
  %7 = invoke { ptr, i64 } @_RNvMs0_NtNtNtCsl10jNU3mE6R_4core3fmt3num3imph4__fmt(i8 %_15, ptr %buf, i64 3)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %_14.0 = extractvalue { ptr, i64 } %7, 0
  %_14.1 = extractvalue { ptr, i64 } %7, 1
; invoke <alloc::string::String>::push_str
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %out, ptr %_14.0, i64 %_14.1)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %out, i64 24, i1 false)
  store i8 0, ptr %_19, align 1
  ret void

bb10:                                             ; preds = %bb11, %bb12
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb11:                                             ; preds = %bb12
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %out) #24
          to label %bb10 unwind label %terminate

terminate:                                        ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable
}

; <(i8, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTabENtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #1 !guid !158 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !159 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&i8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !160 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !161 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <i8 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringaNtB5_8ToString9to_stringCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self) unnamed_addr #0 !guid !162 {
start:
; call <i8 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1G_NtCs7CppTae75M1_5alloc6stringaNtB6_12SpecToString14spec_to_stringCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self) #17
  ret void
}

; <i8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !163 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::option::Option<i8> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionaENtNtB7_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !164 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.1)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %8 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %10 = load i8, ptr %_0, align 1
  %11 = trunc nuw i8 %10 to i1
  ret i1 %11

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #0 !guid !165 {
start:
  ret i8 0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !166 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !167 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <i8 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXsk_NtCsl10jNU3mE6R_4core3numaNtNtNtB7_3str6traits7FromStr8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !168 {
start:
; call <i8>::from_str_radix
  %0 = call { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa14from_str_radixCs8pRW9QHXPaM_10int_ops_i8(ptr %src.0, i64 %src.1, i32 10) #17
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <core::result::Result<i8, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultaNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !169 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %8, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr %_1) unnamed_addr #0 !guid !170 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !171 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1) #17
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i8 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsb_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_6Binary3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <i8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Octal3fmt(ptr, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshr.i8(i8, i8, i8) #9

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptosi.sat.i8.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.smul.with.overflow.i8(i8, i8) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <alloc::vec::Vec<u8>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8, i64) unnamed_addr #1

; <alloc::vec::Vec<u8>>::extend_from_slice
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8, ptr, i64) unnamed_addr #1

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #10

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i8(i8) #11

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #11

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctlz.i8(i8, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.sadd.sat.i8(i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ssub.sat.i8(i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.sadd.with.overflow.i8(i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.ssub.with.overflow.i8(i8, i8) #9

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #10

; core::num::imp::int_sqrt::panic_for_negative_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8) unnamed_addr #10

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.bitreverse.i8(i8) #9

; <core::num::nonzero::NonZero<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3newB9_(i8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.umul.with.overflow.i8(i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; <core::num::nonzero::NonZero<u8>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3getB9_(i8) unnamed_addr #0

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #13

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #14

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #15

; <u8>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMs0_NtNtNtCsl10jNU3mE6R_4core3fmt3num3imph4__fmt(i8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #16 !guid !172 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs8pRW9QHXPaM_10int_ops_i8(ptr @_RNvCs8pRW9QHXPaM_10int_ops_i84main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #12 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #16 = { nonlazybind "target-cpu"="x86-64" }
attributes #17 = { inlinehint }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noreturn }
attributes #20 = { noinline }
attributes #21 = { nounwind }
attributes #22 = { inlinehint nounwind }
attributes #23 = { noinline noreturn }
attributes #24 = { cold }
attributes #25 = { noinline noreturn nounwind }

!llvm.module.flags = !{!55, !56, !57, !58}
!llvm.ident = !{!59}

!0 = !{i64 -231811119702298589}
!1 = !{i64 1627918097327993552}
!2 = !{i64 -7186227141894428387}
!3 = !{i64 -8462893436423512569}
!4 = !{i64 2339777916950468276}
!5 = !{i64 9200414950919056093}
!6 = !{i64 7005753805548094033}
!7 = !{i64 -2482644806863570627}
!8 = !{i64 -8270359268209314662}
!9 = !{i64 985414084263398404}
!10 = !{i64 839883819937048617}
!11 = !{i64 5598952451498884255}
!12 = !{i64 6711613617591893746}
!13 = !{i64 2284079182993286730}
!14 = !{i64 6096617137591710508}
!15 = !{i64 -4979049871268947785}
!16 = !{i64 -3766203042379901973}
!17 = !{i64 -8391964322720101965}
!18 = !{i64 6186363249997158534}
!19 = !{i64 1820177022998017088}
!20 = !{i64 7185607696991017120}
!21 = !{i64 3170344625128639015}
!22 = !{i64 5950960751232096636}
!23 = !{i64 -1292389738209633339}
!24 = !{i64 -1496993316832575839}
!25 = !{i64 -5065788685522228924}
!26 = !{i64 3469734340739607060}
!27 = !{i64 6587673182149693805}
!28 = !{i64 -8013207056352054987}
!29 = !{i64 5375155062528837600}
!30 = !{i64 630402870009472745}
!31 = !{i64 8952173774811826314}
!32 = !{i64 3613622563516115043}
!33 = !{i64 -1711109261662215044}
!34 = !{i64 -2018257573178347867}
!35 = !{i64 -8866024751411950791}
!36 = !{i64 -6896510811643439653}
!37 = !{i64 6867694494244344612}
!38 = !{i64 1121415654624485592}
!39 = !{i64 -5028488198391436407}
!40 = !{i64 3396443473577093621}
!41 = !{i64 4725918547886087660}
!42 = !{i64 6233688453882552751}
!43 = !{i64 -4658513590439525295}
!44 = !{i64 -4446915978933345016}
!45 = !{i64 -6551228146769144036}
!46 = !{i64 -6464180414009011217}
!47 = !{i64 -6690027042761200406}
!48 = !{i64 4200867167045553950}
!49 = !{i64 8302928940902348880}
!50 = !{i64 4130859301185652538}
!51 = !{i64 -3684910825114679743}
!52 = !{i64 275741863242984816}
!53 = !{i64 6786581519239467311}
!54 = !{i64 3400590130564905192}
!55 = !{i32 8, !"PIC Level", i32 2}
!56 = !{i32 7, !"PIE Level", i32 2}
!57 = !{i32 2, !"RtLibUseGOT", i32 1}
!58 = !{i32 7, !"uwtable", i32 2}
!59 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!60 = !{i64 -1272639083554690612}
!61 = !{i64 -4309304959152731381}
!62 = !{i64 2943238650568865876}
!63 = !{i64 4225153140278608578}
!64 = !{i64 -3019047442724908341}
!65 = !{i64 2807302442807436542}
!66 = !{i64 1249863713070727800}
!67 = !{i64 6411712447348415194}
!68 = !{i64 8398074791962234488}
!69 = !{i64 -6621187115060729338}
!70 = !{i64 2829382348910480962}
!71 = !{i64 -1018826032422589531}
!72 = !{i64 5403494602209393194}
!73 = !{i64 -4000245448264364237}
!74 = !{i64 8853581885191568162}
!75 = !{i64 -3342763812896783743}
!76 = !{i64 7578392872536609854}
!77 = !{i64 3306754484827253149}
!78 = !{i64 -1397141111031991345}
!79 = !{i64 2505353759612624396}
!80 = !{i64 322686200539535245}
!81 = !{i64 -2510845614077365955}
!82 = !{i64 4899027182402096494}
!83 = !{i64 -3788568941359767621}
!84 = !{i64 8075538089374431073}
!85 = !{i64 -6411692031015737204}
!86 = !{i64 3670821828460970046}
!87 = !{i64 1419560702882146867}
!88 = !{i64 1318408931290867}
!89 = !{i64 8388289925956227278}
!90 = !{i64 5767378019705201578}
!91 = !{i64 8673042614193218345}
!92 = !{i64 7545019899455347417}
!93 = !{i64 1187024892979646960}
!94 = !{i64 -7918674937762339878}
!95 = !{i64 9197239541090565855}
!96 = !{i64 -4197342846181166104}
!97 = !{i64 226624794215944283}
!98 = !{i64 4195243100483847287}
!99 = !{i64 2177476641349198007}
!100 = !{i64 3278903359499034659}
!101 = !{i64 2259868532719024707}
!102 = !{i64 2907029474899853371}
!103 = !{i64 -7915035406328227509}
!104 = !{i64 1488517909097051618}
!105 = !{i64 9048754610404298211}
!106 = !{i64 1116276806529228056}
!107 = !{i64 -4011269015754829179}
!108 = !{i64 8837404120423718869}
!109 = !{i64 3229347956189358893}
!110 = !{i64 2335624965543040710}
!111 = !{i64 -4261402430198146822}
!112 = !{i64 6989986041373324270}
!113 = !{i64 -4671178029838392901}
!114 = !{i64 -7160604710982458421}
!115 = !{i64 -5315576812704648233}
!116 = !{i64 9013287496805006689}
!117 = !{i64 -1138178988895417888}
!118 = !{i64 -1531165787355503763}
!119 = !{i64 -2695100759826215605}
!120 = !{i64 6190138099927234181}
!121 = !{i64 -7504409451498908113}
!122 = !{i64 4211476645378370700}
!123 = !{i64 -2045898418285042371}
!124 = !{i64 -6692238444980787517}
!125 = !{i64 -4155004339579993972}
!126 = !{i64 -8706677508718103479}
!127 = !{i64 6480642166745255934}
!128 = !{i64 4822153089850407028}
!129 = !{i64 136500941329156373}
!130 = !{i64 2249466770569311950}
!131 = !{i64 2043987595326608168}
!132 = !{i64 4508485235837754312}
!133 = !{i64 -2483294033825902577}
!134 = !{i64 260739515263420325}
!135 = !{i64 -1275807116667170554}
!136 = !{i64 -6783209186136442115}
!137 = !{i64 8683819143661757692}
!138 = !{i64 -7718625286968355154}
!139 = !{i64 2648270007436411699}
!140 = !{i64 -9050464301050623596}
!141 = !{i64 -4663946249522021254}
!142 = !{i64 -7541739765477939055}
!143 = !{i64 9153567770271161350}
!144 = !{!"address", !"read_provenance"}
!145 = !{i64 245652462807287992}
!146 = !{i64 -1008308770781732775}
!147 = !{i64 -4601944371211567393}
!148 = !{i64 2504595208785849312}
!149 = !{i64 -9220938209089895214}
!150 = !{i64 -7848698329863819841}
!151 = !{i64 3637638400887307096}
!152 = !{i64 -1865683072856102220}
!153 = !{i64 -4989470731684053591}
!154 = !{i64 5008747724183722785}
!155 = !{i64 -772869830968744197}
!156 = !{i64 -381481221403957222}
!157 = !{i64 -3568928923056826690}
!158 = !{i64 -631471637345165722}
!159 = !{i64 -2291488004151589649}
!160 = !{i64 68128407672385200}
!161 = !{i64 2127355910086119976}
!162 = !{i64 4926164966366098713}
!163 = !{i64 3562063318605835487}
!164 = !{i64 8209617229793568220}
!165 = !{i64 5467853982495736095}
!166 = !{i64 5800646367850684976}
!167 = !{i64 -1053406264645486642}
!168 = !{i64 -351312941439062581}
!169 = !{i64 483868382555017973}
!170 = !{i64 5754977748173972930}
!171 = !{i64 271159050325069440}
!172 = !{i64 -2624081020897602054}
