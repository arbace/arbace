; ModuleID = 'int_ops_i8.620a7f4bdfbebc02-cgu.0'
source_filename = "int_ops_i8.620a7f4bdfbebc02-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs8pRW9QHXPaM_10int_ops_i8, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8pRW9QHXPaM_10int_ops_i8, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8pRW9QHXPaM_10int_ops_i8 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !3
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !4
@alloc_2fc439fdc88563e15d315d43214d38e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\D6\02\00\00\09\00\00\00" }>, align 8, !guid !5
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !6
@alloc_d5d54240cab534dcfdfc9e1f15f834f2 = private unnamed_addr constant [19 x i8] c"alloc/src/slice.rs\00", align 1, !guid !7
@alloc_50f7a04d493c3c635bb162890af45f79 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d5d54240cab534dcfdfc9e1f15f834f2, [16 x i8] c"\12\00\00\00\00\00\00\00\C6\01\00\00$\00\00\00" }>, align 8, !guid !8
@alloc_16d8701a704195662253a9809cf298d1 = private unnamed_addr constant [25 x i8] c"alloc/src/raw_vec/mod.rs\00", align 1, !guid !9
@alloc_c53d1dc14d9dfd00f89649d83c62a8b7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\003\02\00\00X\00\00\00" }>, align 8, !guid !10
@alloc_84e24ad25dfa3f90d9808e22947b437c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\85\03\00\00G\00\00\00" }>, align 8, !guid !11
@alloc_025a5709ba9544310ca8368ed72bebad = private unnamed_addr constant [4 x i8] c"\08\00\00\00", align 4, !guid !12
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !13
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !14
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !15
@alloc_4d7dd9ad0512c4d42677be0c7feb3348 = private unnamed_addr constant [34 x i8] c"test/rust/synthetic/int-ops-i8.rs\00", align 1, !guid !16
@alloc_9af50b32be45b2581e480bef6a4569d7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !17
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !18
@alloc_75b32a18bdd65834267dc4708dab54e5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !19
@alloc_0a1a1a880a14ee52073c6e8568cd70eb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !20
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !21
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !22
@alloc_41c0e125573be1c7c4cca5e7c50e098d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\1A\00\00\00\1B\00\00\00" }>, align 8, !guid !23
@alloc_e09845198ec90fbfc5a3565186e13680 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !24
@alloc_acad96cb9ad91deee27e5040e130883c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !25
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !26
@alloc_5cacace390a18a9774a0946b258a8e02 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4d7dd9ad0512c4d42677be0c7feb3348, [16 x i8] c"!\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !27
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !28
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !29
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !30
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !31
@alloc_67962a1ee7843a18e69bde6432c4d7d7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00{\01\00\00\05\00\00\00" }>, align 8, !guid !32
@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !33
@alloc_988c380202cc7b7a37ca3d8d5930c44f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\AD\00\00\00\1B\00\00\00" }>, align 8, !guid !34
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !35
@alloc_fad0cd83b7d1858a846a172eb260e593 = private unnamed_addr constant [42 x i8] c"is_aligned_to: align is not a power-of-two", align 1, !guid !36
@alloc_3a97cab01964e354cab63e4d72a95bbc = private unnamed_addr constant [26 x i8] c"core/src/ptr/const_ptr.rs\00", align 1, !guid !37
@alloc_7abc4ceda2d1d9be88f00c5dc522bc84 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3a97cab01964e354cab63e4d72a95bbc, [16 x i8] c"\19\00\00\00\00\00\00\00M\05\00\00\0D\00\00\00" }>, align 8, !guid !38
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !39
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !40
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !41
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !42
@alloc_6379aaa2812385052216e7dc8e3279fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00m\01\00\00\1F\00\00\00" }>, align 8, !guid !43
@alloc_9e1ff22d96cae328e0e878f28b86a5f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00]\01\00\00\11\00\00\00" }>, align 8, !guid !44
@alloc_dc3b17f8cb85ad2cd97bd426be5b5da4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00b\01\00\00\1D\00\00\00" }>, align 8, !guid !45
@alloc_4a0c97dbbf49263ee47df53bd3d86fcc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00b\01\00\00+\00\00\00" }>, align 8, !guid !46
@alloc_a699fef46c42b266f9e12652c07a696a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00`\01\00\00\1B\00\00\00" }>, align 8, !guid !47
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !48
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !49
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !50
@alloc_e469ef44bf39c45bcb672a4bc963b9cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\1A\01\00\00\1B\00\00\00" }>, align 8, !guid !51
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !52
@alloc_5bb642ca6df5ad9ba078972a9d3a5201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !53
@alloc_85bcb8feb56634093aba2b8644936af9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\7F\02\00\005\00\00\00" }>, align 8, !guid !54
@alloc_17de00c3327446355700bd7db4b78ded = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\80\02\00\00\1E\00\00\00" }>, align 8, !guid !55
@alloc_b9419d44288097f84422e162822ba96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\81\02\00\00 \00\00\00" }>, align 8, !guid !56
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !57
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !58
@alloc_1f1d7c1ec8c9041988f7c79d620acc00 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\02\00\00\05\00\00\00" }>, align 8, !guid !59
@alloc_af3623564924928dd3d563c9d84a8a0e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00s\05\00\00\12\00\00\00" }>, align 8, !guid !60
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !61
@alloc_02ed5979549ad728dcb1e213f787b0ae = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00,\02\00\00\11\00\00\00" }>, align 8, !guid !62
@alloc_9c2bc03755f157121052fe1398e358d1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00%\02\00\00\1A\00\00\00" }>, align 8, !guid !63
@alloc_8b924c2e6c70ef47ed23cadbb79c2da4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\11\02\00\00\1C\00\00\00" }>, align 8, !guid !64
@alloc_91dabd4c1d2514ecf79277c06422ef65 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\07\02\00\00\1C\00\00\00" }>, align 8, !guid !65
@alloc_289c68237f406b28ee6ba245eefcd312 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\03\02\00\00)\00\00\00" }>, align 8, !guid !66
@alloc_33dfd402c6ecbe2e6a32e76edf5f31a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\D8\01\00\00L\00\00\00" }>, align 8, !guid !67
@alloc_099d793709fa470a3d5e7c79c938e035 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\C9\01\00\003\00\00\00" }>, align 8, !guid !68
@alloc_51424262946dd0794fad6132df857999 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\B7\01\00\00\15\00\00\00" }>, align 8, !guid !69
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !70
@alloc_5ea8f0c52284eef1a8a88866fb554c40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\0B\00\00O\00\00\00" }>, align 8, !guid !71
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !72
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !73
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !74
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !75
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !76
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !77
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !78
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !79
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !80
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !81
@anon.681c060d2bfd6770ec9e5f1a4ed3b4ec.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !82
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !83
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !84
@alloc_cbcfb4391f0fcdd0dcd48dbe6149ef89 = private unnamed_addr constant [183 x i8] c"unsafe precondition(s) violated: i8::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !85
@alloc_66558f7972e7e036e1d4ccb8be86690a = private unnamed_addr constant [183 x i8] c"unsafe precondition(s) violated: i8::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !86
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !87
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !88
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !89
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !90
@alloc_eff87de2e562ad9bea1d5ede245212a6 = private unnamed_addr constant [183 x i8] c"unsafe precondition(s) violated: u8::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !91
@alloc_db07ae5a9ce650d9b7cc970d048e6f0c = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !92
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !93
@alloc_dd79dfae92e8fdc23813c4c7a1b7cf72 = private unnamed_addr constant [228 x i8] c"unsafe precondition(s) violated: ptr::write_bytes requires that the destination pointer is aligned and non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !94
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !95
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !96
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !97
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !98
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8 }>, align 8, !guid !99
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8 }>, align 8, !guid !100
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !101
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !102
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !103
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !104
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8 }>, align 8, !guid !105
@alloc_59ba7b9f7211443cd55a366616eef46a = private unnamed_addr constant [5 x i8] c"Empty", align 1, !guid !106
@alloc_00315c78e51d29fe6b3102a4c1ecf6ef = private unnamed_addr constant [12 x i8] c"InvalidDigit", align 1, !guid !107
@alloc_bd3a3f3879e0d5f64554753e977f58d4 = private unnamed_addr constant [11 x i8] c"PosOverflow", align 1, !guid !108
@alloc_0964bb2a4870637395c77a018495bd5c = private unnamed_addr constant [11 x i8] c"NegOverflow", align 1, !guid !109
@alloc_6566120a3a17f930e960a0863fcbd591 = private unnamed_addr constant [4 x i8] c"Zero", align 1, !guid !110
@alloc_6c17bac0c71cba42380f8445f4dcbd16 = private unnamed_addr constant [14 x i8] c"NotAPowerOfTwo", align 1, !guid !111
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !112
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !113
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8 }>, align 8, !guid !114

; <[u8]>::to_vec_in::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !120 {
start:
; call <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
  call void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #23
  ret void
}

; <str>::parse::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parseaECs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !121 {
start:
; call <i8 as core::str::traits::FromStr>::from_str
  %0 = call { i1, i8 } @_RNvXsk_NtCsl10jNU3mE6R_4core3numaNtNtNtB7_3str6traits7FromStr8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) #23
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs8pRW9QHXPaM_10int_ops_i8(ptr %0) unnamed_addr #0 !guid !122 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_6, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %7 = load ptr, ptr %_0, align 8
  ret ptr %7

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1, ptr align 8 %default) unnamed_addr #0 personality ptr @rust_eh_personality !guid !123 {
start:
  %_10 = alloca [1 x i8], align 1
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_10, align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_10, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_4 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_4 to i1
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %t.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %9, align 8
  store i8 0, ptr %_9, align 1
; call <<str as alloc::borrow::ToOwned>::to_owned as core::ops::function::FnOnce<(&str,)>>::call_once
  call void @_RNvYNvYeNtNtCs7CppTae75M1_5alloc6borrow7ToOwned8to_ownedINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTReEE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %t.0, i64 %t.1) #23
  br label %bb15

bb2:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call alloc::fmt::format::{closure#0}
  call void @_RNCNvNtCs7CppTae75M1_5alloc3fmt6format0Cs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %default) #23
  br label %bb14

bb14:                                             ; preds = %bb2
  br label %bb9

bb9:                                              ; preds = %bb15, %bb14
  %10 = load i8, ptr %_9, align 1
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %bb8, label %bb4

bb15:                                             ; preds = %bb3
  br label %bb9

bb4:                                              ; preds = %bb8, %bb9
  %12 = load i8, ptr %_10, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb10, label %bb5

bb8:                                              ; preds = %bb9
  br label %bb4

bb5:                                              ; preds = %bb10, %bb4
  ret void

bb10:                                             ; preds = %bb4
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable
}

; <core::option::Option<usize>>::ok_or::<alloc::collections::TryReserveErrorKind>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE5ok_orNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, i64 %0, i64 %1, i64 %err.0, i64 %err.1) unnamed_addr #0 !guid !124 {
start:
  %_6 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %7, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store i64 %err.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %err.1, ptr %8, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %9 = load i8, ptr %_6, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError>>::map_err::<alloc::collections::TryReserveError, <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtNtB5_3ptr8non_null7NonNullShENtNtB5_5alloc10AllocErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvMs5_NtB1S_7raw_vecNtB2O_11RawVecInner11finish_grow0ECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1, ptr align 8 %op) unnamed_addr #0 !guid !125 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_3 = select i1 %7, i64 1, i64 0
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}
  %9 = call { i64, i64 } @_RNCNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB7_11RawVecInner11finish_grow0Cs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %op) #23
  %_6.0 = extractvalue { i64, i64 } %9, 0
  %_6.1 = extractvalue { i64, i64 } %9, 1
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 %_6.1, ptr %11, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load ptr, ptr %self, align 8
  %12 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %t.0, ptr %13, align 8
  %14 = getelementptr inbounds i8, ptr %13, i64 8
  store i64 %t.1, ptr %14, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %15 = load i8, ptr %_9, align 1
  %16 = trunc nuw i8 %15 to i1
  br i1 %16, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %0, i64 %1) unnamed_addr #0 !guid !126 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load i64, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = icmp eq i64 %3, 0
  %_3 = select i1 %6, i64 1, i64 0
  %7 = trunc nuw i64 %_3 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call alloc::raw_vec::layout_array::{closure#0}
  %8 = call { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0Cs8pRW9QHXPaM_10int_ops_i8() #23
  %_6.0 = extractvalue { i64, i64 } %8, 0
  %_6.1 = extractvalue { i64, i64 } %8, 1
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %_6.1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load i64, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %t.0, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 8
  store i64 %t.1, ptr %13, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %14 = load i8, ptr %_9, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_binary::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !127 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsb_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !128 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !129 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !130 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %x) #23
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !131 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 4 %x) #23
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !132 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<u8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !133 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<usize>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %x) #23
; call <core::ptr::non_null::NonNull<usize>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !134 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 4 %x) #23
; call <core::ptr::non_null::NonNull<u32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !135 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !136 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !137 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i8>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionaEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<core::option::Option<i8>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionaEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionaENtNtB7_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i8, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultaNtNtNtB7_3num5error13ParseIntErrorEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !138 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultaNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultaNtNtNtBa_3num5error13ParseIntErrorEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultaNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(i8, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTabEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !139 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(i8, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTabEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<(i8, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTabEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTabENtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !140 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !141 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %x) #23
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsd_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::unique::Unique<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !142 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECs8pRW9QHXPaM_10int_ops_i8(ptr %self) #23
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<core::option::Option<i8>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionaEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !143 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultaNtNtNtBa_3num5error13ParseIntErrorEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !144 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !145 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<(i8, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTabEE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !146 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !147 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !148 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !149 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !150 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !151 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !152 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<usize>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !153 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !154 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !155 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u8>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !156 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECs8pRW9QHXPaM_10int_ops_i8(ptr %_3) #23
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr %_2) #23
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECs8pRW9QHXPaM_10int_ops_i8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !157 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs8pRW9QHXPaM_10int_ops_i8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !158 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !159 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECs8pRW9QHXPaM_10int_ops_i8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !160 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !161 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !162 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs8pRW9QHXPaM_10int_ops_i8(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !163 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u8>
; Function Attrs: nounwind nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefthECs8pRW9QHXPaM_10int_ops_i8(i8 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !164 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 1 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i8
  %_0 = call i8 @llvm.fshl.i8(i8 %x, i8 %x, i8 %1)
  ret i8 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #25
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u8>
; Function Attrs: nounwind nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righthECs8pRW9QHXPaM_10int_ops_i8(i8 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !165 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 1 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i8
  %_0 = call i8 @llvm.fshr.i8(i8 %x, i8 %x, i8 %1)
  ret i8 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #25
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::is_val_statically_known::<i8>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownaECs8pRW9QHXPaM_10int_ops_i8(i8 %_arg) unnamed_addr #2 !guid !166 {
start:
  ret i1 false
}

; core::intrinsics::is_val_statically_known::<u32>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownmECs8pRW9QHXPaM_10int_ops_i8(i32 %_arg) unnamed_addr #2 !guid !167 {
start:
  ret i1 false
}

; core::cmp::max::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECs8pRW9QHXPaM_10int_ops_i8(i64 %v1, i64 %v2) unnamed_addr #0 !guid !168 {
start:
; call <usize as core::cmp::Ord>::max
  %_0 = call i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxCs8pRW9QHXPaM_10int_ops_i8(i64 %v1, i64 %v2) #23
  ret i64 %_0
}

; core::ptr::slice_from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %len) unnamed_addr #0 !guid !169 {
start:
; call core::ptr::metadata::from_raw_parts::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %len) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %len) unnamed_addr #0 !guid !170 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %len) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !171 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1) #26
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1) unnamed_addr #1 !guid !172 {
start:
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1) unnamed_addr #1 !guid !173 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 %dummy) unnamed_addr #0 !guid !174 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !175
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs8pRW9QHXPaM_10int_ops_i8(i32 %dummy) unnamed_addr #0 !guid !176 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !175
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 %dummy) unnamed_addr #0 !guid !177 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !175
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #0 !guid !178 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !175
  ret void
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs8pRW9QHXPaM_10int_ops_i8(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !179 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr %f) #23
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECs8pRW9QHXPaM_10int_ops_i8() #23
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECs8pRW9QHXPaM_10int_ops_i8(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !180 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECs8pRW9QHXPaM_10int_ops_i8(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !181 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECs8pRW9QHXPaM_10int_ops_i8(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !182 {
start:
  ret i64 %ptr.1
}

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !183 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %len) #23
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 1, i64 1, i64 %len, ptr align 8 %0) #27
  br label %bb5
}

; <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
; Function Attrs: cold nonlazybind uwtable
define internal void @_RINvNvMs2_NtCs7CppTae75M1_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %slf, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #4 !guid !184 {
start:
  %_5 = alloca [16 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::grow_amortized
  %0 = call { i64, i64 } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %slf, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1)
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_5, align 8
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load i64, ptr %_5, align 8
  %5 = getelementptr inbounds i8, ptr %_5, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = icmp eq i64 %4, -1
  %_6 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_6 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %err.0 = load i64, ptr %_5, align 8
  %9 = getelementptr inbounds i8, ptr %_5, i64 8
  %err.1 = load i64, ptr %9, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #25
  unreachable

bb3:                                              ; preds = %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !185 {
start:
  %0 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %v = alloca [24 x i8], align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  store i8 0, ptr %_13, align 1
; call <alloc::vec::Vec<u8>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %v, i64 %s.1) #23
  br label %bb1

bb1:                                              ; preds = %start
  %_6 = icmp ugt i64 %s.1, 0
  br i1 %_6, label %bb2, label %bb6

bb6:                                              ; preds = %bb11, %bb1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %v, i64 24, i1 false)
  ret void

bb2:                                              ; preds = %bb1
  br label %bb3

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %v) #26
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4, %bb5, %bb3
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
; invoke <alloc::vec::Vec<u8>>::as_mut_ptr
  %_9 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %v)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke core::ub_checks::check_language_ub
  %_4.i.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
          to label %_4.i.i.noexc unwind label %cleanup

_4.i.i.noexc:                                     ; preds = %bb4
  br i1 %_4.i.i1, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCs8pRW9QHXPaM_10int_ops_i8.exit

bb2.i.i:                                          ; preds = %_4.i.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %s.0, ptr %_9, i64 1, i64 1, i64 %s.1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #27
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCs8pRW9QHXPaM_10int_ops_i8.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCs8pRW9QHXPaM_10int_ops_i8.exit: ; preds = %_4.i.i.noexc, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_9, ptr align 1 %s.0, i64 %s.1, i1 false)
  br label %bb5

bb5:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCs8pRW9QHXPaM_10int_ops_i8.exit
; invoke <alloc::vec::Vec<u8>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %v, i64 %s.1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb5
  br label %bb6

terminate:                                        ; preds = %bb7
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb10:                                             ; preds = %bb7
  %6 = load i8, ptr %_13, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb9, label %bb8

bb8:                                              ; preds = %bb9, %bb10
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb9:                                              ; preds = %bb10
  br label %bb8
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1) unnamed_addr #0 !guid !186 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #28
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs8pRW9QHXPaM_10int_ops_i8() #23
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs8pRW9QHXPaM_10int_ops_i8(i8 %_2) #23
  ret i32 %_0
}

; <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB7_11RawVecInner11finish_grow0Cs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1) unnamed_addr #0 !guid !187 {
start:
  %_4.0 = load i64, ptr %_1, align 8
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_4.1 = load i64, ptr %0, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %1 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs8pRW9QHXPaM_10int_ops_i8(i64 %_4.0, i64 %_4.1, ptr align 8 @alloc_c53d1dc14d9dfd00f89649d83c62a8b7) #23
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; alloc::fmt::format::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvNtCs7CppTae75M1_5alloc3fmt6format0Cs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_1) unnamed_addr #0 !guid !188 {
start:
  %_2.0 = load ptr, ptr %_1, align 8
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_2.1 = load ptr, ptr %0, align 8
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCs7CppTae75M1_5alloc3fmt6format12format_inner(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, ptr %_2.1)
  ret void
}

; alloc::raw_vec::layout_array::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0Cs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #0 !guid !189 {
start:
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %0 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs8pRW9QHXPaM_10int_ops_i8(i64 0, i64 undef, ptr align 8 @alloc_84e24ad25dfa3f90d9808e22947b437c) #23
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs8pRW9QHXPaM_10int_ops_i8(ptr %_1) unnamed_addr #0 !guid !190 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr %0) #23
  ret i32 %_0
}

; int_ops_i8::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs8pRW9QHXPaM_10int_ops_i84main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !191 {
start:
  %0 = alloca [16 x i8], align 8
  %_294 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_284 = alloca [24 x i8], align 8
  %_283 = alloca [24 x i8], align 8
  %_279 = alloca [24 x i8], align 8
  %_276 = alloca [8 x i8], align 8
  %_269 = alloca [16 x i8], align 8
  %_268 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_264 = alloca [4 x i8], align 4
  %_262 = alloca [1 x i8], align 1
  %_255 = alloca [16 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_252 = alloca [4 x i8], align 4
  %_250 = alloca [4 x i8], align 4
  %_243 = alloca [16 x i8], align 8
  %_242 = alloca [16 x i8], align 8
  %_241 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_239 = alloca [8 x i8], align 8
  %_237 = alloca [4 x i8], align 4
  %_233 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_226 = alloca [16 x i8], align 8
  %_225 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_222 = alloca [2 x i8], align 1
  %_220 = alloca [1 x i8], align 1
  %_216 = alloca [2 x i8], align 1
  %_209 = alloca [16 x i8], align 8
  %_208 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_206 = alloca [1 x i8], align 1
  %_203 = alloca [1 x i8], align 1
  %_196 = alloca [16 x i8], align 8
  %_195 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_193 = alloca [2 x i8], align 1
  %_190 = alloca [2 x i8], align 1
  %_183 = alloca [16 x i8], align 8
  %_182 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_176 = alloca [1 x i8], align 1
  %_170 = alloca [1 x i8], align 1
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [1 x i8], align 1
  %_156 = alloca [1 x i8], align 1
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [1 x i8], align 1
  %_144 = alloca [1 x i8], align 1
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [1 x i8], align 1
  %_130 = alloca [1 x i8], align 1
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [2 x i8], align 1
  %_98 = alloca [2 x i8], align 1
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [1 x i8], align 1
  %_86 = alloca [1 x i8], align 1
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [1 x i8], align 1
  %_74 = alloca [1 x i8], align 1
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [1 x i8], align 1
  %_62 = alloca [1 x i8], align 1
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [2 x i8], align 1
  %_50 = alloca [2 x i8], align 1
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [2 x i8], align 1
  %_38 = alloca [2 x i8], align 1
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [1 x i8], align 1
  %min = alloca [1 x i8], align 1
; call core::hint::black_box::<i8>
  %_4 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 -128) #23
; call core::hint::black_box::<i8>
  %_5 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 127) #23
  store i8 %_4, ptr %min, align 1
  store i8 %_5, ptr %max, align 1
; call core::hint::black_box::<i8>
  %one = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 1) #23
; call core::hint::black_box::<i8>
  %three = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 3) #23
  store ptr %min, ptr %args, align 8
  %1 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_025a5709ba9544310ca8368ed72bebad, ptr %2, align 8
  %_297 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_15, ptr %_297) #23
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  %_298 = load ptr, ptr %3, align 8
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_16, ptr %_298) #23
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  %_299 = load ptr, ptr %4, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_299) #23
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_15, i64 16, i1 false)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_16, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #23
  %_9.0 = extractvalue { ptr, ptr } %8, 0
  %_9.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %9 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %11, align 8
  %_300 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_28, ptr %_300) #23
  %12 = getelementptr inbounds i8, ptr %args2, i64 8
  %_301 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_binary::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_29, ptr %_301) #23
  %13 = getelementptr inbounds i8, ptr %args2, i64 16
  %_302 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_octal::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_30, ptr %_302) #23
  %14 = getelementptr inbounds i8, ptr %args2, i64 24
  %_303 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_31, ptr %_303) #23
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_28, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_29, i64 16, i1 false)
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_30, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #23
  %_21.0 = extractvalue { ptr, ptr } %19, 0
  %_21.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %20 = load i8, ptr %max, align 1
; call <i8>::checked_add
  %21 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs8pRW9QHXPaM_10int_ops_i8(i8 %20, i8 %one) #23
  %22 = extractvalue { i1, i8 } %21, 0
  %23 = extractvalue { i1, i8 } %21, 1
  %24 = zext i1 %22 to i8
  store i8 %24, ptr %_38, align 1
  %25 = getelementptr inbounds i8, ptr %_38, i64 1
  store i8 %23, ptr %25, align 1
  %26 = load i8, ptr %min, align 1
; call <i8>::checked_add
  %27 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs8pRW9QHXPaM_10int_ops_i8(i8 %26, i8 %one) #23
  %28 = extractvalue { i1, i8 } %27, 0
  %29 = extractvalue { i1, i8 } %27, 1
  %30 = zext i1 %28 to i8
  store i8 %30, ptr %_40, align 1
  %31 = getelementptr inbounds i8, ptr %_40, i64 1
  store i8 %29, ptr %31, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_42, ptr %_38) #23
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_43, ptr %_40) #23
  %32 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %_42, i64 16, i1 false)
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %34 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #23
  %_35.0 = extractvalue { ptr, ptr } %34, 0
  %_35.1 = extractvalue { ptr, ptr } %34, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %35 = load i8, ptr %max, align 1
  %36 = call { i8, i1 } @llvm.sadd.with.overflow.i8(i8 %35, i8 %one)
  %_5.0.i = extractvalue { i8, i1 } %36, 0
  %_5.1.i = extractvalue { i8, i1 } %36, 1
  %37 = extractvalue { i8, i1 } %36, 0
  %38 = extractvalue { i8, i1 } %36, 1
  store i8 %37, ptr %_50, align 1
  %39 = getelementptr inbounds i8, ptr %_50, i64 1
  %40 = zext i1 %38 to i8
  store i8 %40, ptr %39, align 1
  %41 = load i8, ptr %min, align 1
  %42 = call { i8, i1 } @llvm.ssub.with.overflow.i8(i8 %41, i8 %one)
  %_5.0.i53 = extractvalue { i8, i1 } %42, 0
  %_5.1.i54 = extractvalue { i8, i1 } %42, 1
  %43 = extractvalue { i8, i1 } %42, 0
  %44 = extractvalue { i8, i1 } %42, 1
  store i8 %43, ptr %_52, align 1
  %45 = getelementptr inbounds i8, ptr %_52, i64 1
  %46 = zext i1 %44 to i8
  store i8 %46, ptr %45, align 1
; call <core::fmt::rt::Argument>::new_debug::<(i8, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTabEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_54, ptr %_50) #23
; call <core::fmt::rt::Argument>::new_debug::<(i8, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTabEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_55, ptr %_52) #23
  %47 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %47, ptr align 8 %_54, i64 16, i1 false)
  %48 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %48, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %49 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #23
  %_47.0 = extractvalue { ptr, ptr } %49, 0
  %_47.1 = extractvalue { ptr, ptr } %49, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %50 = load i8, ptr %max, align 1
  %_0.i35 = add i8 %50, %one
  store i8 %_0.i35, ptr %_62, align 1
  %51 = load i8, ptr %min, align 1
  %_0.i42 = sub i8 %51, %one
  store i8 %_0.i42, ptr %_64, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_66, ptr %_62) #23
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_67, ptr %_64) #23
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_66, i64 16, i1 false)
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %54 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #23
  %_59.0 = extractvalue { ptr, ptr } %54, 0
  %_59.1 = extractvalue { ptr, ptr } %54, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %55 = load i8, ptr %max, align 1
  %_0.i49 = call i8 @llvm.sadd.sat.i8(i8 %55, i8 %three)
  store i8 %_0.i49, ptr %_74, align 1
  %56 = load i8, ptr %min, align 1
  %_0.i50 = call i8 @llvm.ssub.sat.i8(i8 %56, i8 %three)
  store i8 %_0.i50, ptr %_76, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_78, ptr %_74) #23
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_79, ptr %_76) #23
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_78, i64 16, i1 false)
  %58 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %58, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %59 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #23
  %_71.0 = extractvalue { ptr, ptr } %59, 0
  %_71.1 = extractvalue { ptr, ptr } %59, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %60 = load i8, ptr %max, align 1
  %_0.i37 = mul i8 %60, %three
  store i8 %_0.i37, ptr %_86, align 1
  %61 = load i8, ptr %max, align 1
  %62 = load i8, ptr %max, align 1
  %_0.i36 = mul i8 %61, %62
  store i8 %_0.i36, ptr %_88, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_90, ptr %_86) #23
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_91, ptr %_88) #23
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_90, i64 16, i1 false)
  %64 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %64, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %65 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #23
  %_83.0 = extractvalue { ptr, ptr } %65, 0
  %_83.1 = extractvalue { ptr, ptr } %65, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %66 = load i8, ptr %max, align 1
; call <i8>::checked_mul
  %67 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %66, i8 %three) #23
  %68 = extractvalue { i1, i8 } %67, 0
  %69 = extractvalue { i1, i8 } %67, 1
  %70 = zext i1 %68 to i8
  store i8 %70, ptr %_98, align 1
  %71 = getelementptr inbounds i8, ptr %_98, i64 1
  store i8 %69, ptr %71, align 1
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 5) #23
; call <i8>::checked_pow
  %72 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_powCs8pRW9QHXPaM_10int_ops_i8(i8 %three, i32 %_101) #23
  %73 = extractvalue { i1, i8 } %72, 0
  %74 = extractvalue { i1, i8 } %72, 1
  %75 = zext i1 %73 to i8
  store i8 %75, ptr %_100, align 1
  %76 = getelementptr inbounds i8, ptr %_100, i64 1
  store i8 %74, ptr %76, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_103, ptr %_98) #23
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_104, ptr %_100) #23
  %77 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %77, ptr align 8 %_103, i64 16, i1 false)
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %79 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #23
  %_95.0 = extractvalue { ptr, ptr } %79, 0
  %_95.1 = extractvalue { ptr, ptr } %79, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %80 = load i8, ptr %max, align 1
  %81 = call i8 @llvm.ctpop.i8(i8 %80)
  %_0.i55 = zext i8 %81 to i32
  store i32 %_0.i55, ptr %_111, align 4
  %82 = load i8, ptr %max, align 1
  %83 = call i8 @llvm.ctlz.i8(i8 %82, i1 false)
  %_0.i60 = zext i8 %83 to i32
  store i32 %_0.i60, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs8pRW9QHXPaM_10int_ops_i8(i32 3) #23
  %_119 = icmp ult i32 %_117, 8
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %84 = and i32 %_117, 7
  %85 = trunc i32 %84 to i8
  %_116 = shl i8 %one, %85
  %86 = call i8 @llvm.cttz.i8(i8 %_116, i1 false)
  %_0.i61 = zext i8 %86 to i32
  store i32 %_0.i61, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %87 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %87, align 8
  %88 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %88, align 8
  %_316 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_316) #23
  %89 = getelementptr inbounds i8, ptr %args10, i64 8
  %_317 = load ptr, ptr %89, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_317) #23
  %90 = getelementptr inbounds i8, ptr %args10, i64 16
  %_318 = load ptr, ptr %90, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_318) #23
  %91 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %91, ptr align 8 %_121, i64 16, i1 false)
  %92 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %92, ptr align 8 %_122, i64 16, i1 false)
  %93 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %93, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %94 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #23
  %_108.0 = extractvalue { ptr, ptr } %94, 0
  %_108.1 = extractvalue { ptr, ptr } %94, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 5) #23
  %95 = load i8, ptr %max, align 1
; call core::intrinsics::rotate_left::<u8>
  %_0.i = call i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefthECs8pRW9QHXPaM_10int_ops_i8(i8 %95, i32 %_131) #29
  store i8 %_0.i, ptr %_130, align 1
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 7) #23
  %96 = load i8, ptr %min, align 1
; call core::intrinsics::rotate_right::<u8>
  %_0.i58 = call i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righthECs8pRW9QHXPaM_10int_ops_i8(i8 %96, i32 %_134) #29
  store i8 %_0.i58, ptr %_133, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_136, ptr %_130) #23
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_137, ptr %_133) #23
  %97 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %97, ptr align 8 %_136, i64 16, i1 false)
  %98 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %98, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %99 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #23
  %_127.0 = extractvalue { ptr, ptr } %99, 0
  %_127.1 = extractvalue { ptr, ptr } %99, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %100 = load i8, ptr %max, align 1
  store i8 %100, ptr %_144, align 1
  %101 = load i8, ptr %max, align 1
  %_0.i57 = call i8 @llvm.bitreverse.i8(i8 %101)
  store i8 %_0.i57, ptr %_146, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_148, ptr %_144) #23
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_149, ptr %_146) #23
  %102 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %102, ptr align 8 %_148, i64 16, i1 false)
  %103 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %103, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %104 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #23
  %_141.0 = extractvalue { ptr, ptr } %104, 0
  %_141.1 = extractvalue { ptr, ptr } %104, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 70) #23
  %105 = load i8, ptr %max, align 1
  %_3.i38 = and i32 %_157, 7
; call core::ub_checks::check_language_ub
  %_3.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_3.i44, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <i8>::unchecked_shl::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %_3.i38, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #27
  br label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %106 = trunc nuw i32 %_3.i38 to i8
  %_0.i45 = shl i8 %105, %106
  store i8 %_0.i45, ptr %_156, align 1
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 66) #23
  %107 = load i8, ptr %min, align 1
  %_3.i40 = and i32 %_160, 7
; call core::ub_checks::check_language_ub
  %_3.i46 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_3.i46, label %bb2.i48, label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit

bb2.i48:                                          ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit
; call <i8>::unchecked_shr::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %_3.i40, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #27
  br label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit

_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit: ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit, %bb2.i48
  %108 = trunc nuw i32 %_3.i40 to i8
  %_0.i47 = ashr i8 %107, %108
  store i8 %_0.i47, ptr %_159, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_162, ptr %_156) #23
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_163, ptr %_159) #23
  %109 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %109, ptr align 8 %_162, i64 16, i1 false)
  %110 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %110, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %111 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #23
  %_153.0 = extractvalue { ptr, ptr } %111, 0
  %_153.1 = extractvalue { ptr, ptr } %111, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i8 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_9af50b32be45b2581e480bef6a4569d7) #30
  unreachable

bb85:                                             ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit
  %_172 = icmp eq i8 %three, -1
  %112 = load i8, ptr %max, align 1
  %_173 = icmp eq i8 %112, -128
  %_174 = and i1 %_172, %_173
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_75b32a18bdd65834267dc4708dab54e5) #30
  unreachable

bb86:                                             ; preds = %bb85
  %113 = load i8, ptr %max, align 1
  %114 = sdiv i8 %113, %three
  store i8 %114, ptr %_170, align 1
  %_177 = icmp eq i8 %three, 0
  br i1 %_177, label %panic27, label %bb87

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_75b32a18bdd65834267dc4708dab54e5) #30
  unreachable

bb87:                                             ; preds = %bb86
  %_178 = icmp eq i8 %three, -1
  %115 = load i8, ptr %max, align 1
  %_179 = icmp eq i8 %115, -128
  %_180 = and i1 %_178, %_179
  br i1 %_180, label %panic28, label %bb88

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_0a1a1a880a14ee52073c6e8568cd70eb) #30
  unreachable

bb88:                                             ; preds = %bb87
  %116 = load i8, ptr %max, align 1
  %117 = srem i8 %116, %three
  store i8 %117, ptr %_176, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_182, ptr %_170) #23
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_183, ptr %_176) #23
  %118 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %118, ptr align 8 %_182, i64 16, i1 false)
  %119 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %119, ptr align 8 %_183, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %120 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #23
  %_167.0 = extractvalue { ptr, ptr } %120, 0
  %_167.1 = extractvalue { ptr, ptr } %120, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<i8>
  %_191 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs8pRW9QHXPaM_10int_ops_i8(i8 0) #23
  %121 = load i8, ptr %max, align 1
; call <i8>::checked_div
  %122 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_divCs8pRW9QHXPaM_10int_ops_i8(i8 %121, i8 %_191) #23
  %123 = extractvalue { i1, i8 } %122, 0
  %124 = extractvalue { i1, i8 } %122, 1
  %125 = zext i1 %123 to i8
  store i8 %125, ptr %_190, align 1
  %126 = getelementptr inbounds i8, ptr %_190, i64 1
  store i8 %124, ptr %126, align 1
  %127 = load i8, ptr %max, align 1
; call <i8>::checked_rem
  %128 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_remCs8pRW9QHXPaM_10int_ops_i8(i8 %127, i8 %three) #23
  %129 = extractvalue { i1, i8 } %128, 0
  %130 = extractvalue { i1, i8 } %128, 1
  %131 = zext i1 %129 to i8
  store i8 %131, ptr %_193, align 1
  %132 = getelementptr inbounds i8, ptr %_193, i64 1
  store i8 %130, ptr %132, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_195, ptr %_190) #23
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i8>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionaEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_196, ptr %_193) #23
  %133 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %133, ptr align 8 %_195, i64 16, i1 false)
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_196, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %135 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #23
  %_187.0 = extractvalue { ptr, ptr } %135, 0
  %_187.1 = extractvalue { ptr, ptr } %135, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_187.0, ptr %_187.1)
; call core::hint::black_box::<u32>
  %_204 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 4) #23
; call <i8>::pow
  %136 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa3powCs8pRW9QHXPaM_10int_ops_i8(i8 %three, i32 %_204) #23
  store i8 %136, ptr %_203, align 1
  %137 = load i8, ptr %max, align 1
  %138 = load i8, ptr %min, align 1
; call <i8>::abs_diff
  %139 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa8abs_diffCs8pRW9QHXPaM_10int_ops_i8(i8 %137, i8 %138) #23
  store i8 %139, ptr %_206, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_208, ptr %_203) #23
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_209, ptr %_206) #23
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_208, i64 16, i1 false)
  %141 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %141, ptr align 8 %_209, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %142 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #23
  %_200.0 = extractvalue { ptr, ptr } %142, 0
  %_200.1 = extractvalue { ptr, ptr } %142, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_200.0, ptr %_200.1)
; call core::hint::black_box::<u32>
  %_218 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs8pRW9QHXPaM_10int_ops_i8(i32 7) #23
; call <i8>::from_str_radix
  %143 = call { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa14from_str_radixCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_218) #23
  %144 = extractvalue { i1, i8 } %143, 0
  %145 = extractvalue { i1, i8 } %143, 1
  %146 = zext i1 %144 to i8
  store i8 %146, ptr %_216, align 1
  %147 = getelementptr inbounds i8, ptr %_216, i64 1
  store i8 %145, ptr %147, align 1
; call <str>::parse::<i8>
  %148 = call { i1, i8 } @_RINvMNtCsl10jNU3mE6R_4core3stre5parseaECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #23
  %149 = extractvalue { i1, i8 } %148, 0
  %150 = extractvalue { i1, i8 } %148, 1
  %151 = zext i1 %149 to i8
  store i8 %151, ptr %_222, align 1
  %152 = getelementptr inbounds i8, ptr %_222, i64 1
  store i8 %150, ptr %152, align 1
; call <core::result::Result<i8, core::num::error::ParseIntError>>::is_ok
  %153 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultaNtNtNtB4_3num5error13ParseIntErrorE5is_okCs8pRW9QHXPaM_10int_ops_i8(ptr %_222) #23
  %154 = zext i1 %153 to i8
  store i8 %154, ptr %_220, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i8, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultaNtNtNtB7_3num5error13ParseIntErrorEECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_225, ptr %_216) #23
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_226, ptr %_220) #23
  %155 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %155, ptr align 8 %_225, i64 16, i1 false)
  %156 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %156, ptr align 8 %_226, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %157 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #23
  %_213.0 = extractvalue { ptr, ptr } %157, 0
  %_213.1 = extractvalue { ptr, ptr } %157, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_213.0, ptr %_213.1)
  %158 = load i8, ptr %max, align 1
  %_235 = sitofp i8 %158 to double
  %_234 = call i8 @llvm.fptosi.sat.i8.f64(double %_235)
  %159 = load i8, ptr %max, align 1
  %160 = icmp eq i8 %_234, %159
  %161 = zext i1 %160 to i8
  store i8 %161, ptr %_233, align 1
  %162 = load i8, ptr %max, align 1
  %163 = sitofp i8 %162 to float
  store float %163, ptr %_237, align 4
  %164 = load i8, ptr %min, align 1
  %165 = sitofp i8 %164 to double
  store double %165, ptr %_239, align 8
  store ptr %_233, ptr %args19, align 8
  %166 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_237, ptr %166, align 8
  %167 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_239, ptr %167, align 8
  %_333 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_241, ptr %_333) #23
  %168 = getelementptr inbounds i8, ptr %args19, i64 8
  %_334 = load ptr, ptr %168, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_242, ptr align 4 %_334) #23
  %169 = getelementptr inbounds i8, ptr %args19, i64 16
  %_335 = load ptr, ptr %169, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_243, ptr align 8 %_335) #23
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_241, i64 16, i1 false)
  %171 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %171, ptr align 8 %_242, i64 16, i1 false)
  %172 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %172, ptr align 8 %_243, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %173 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #23
  %_230.0 = extractvalue { ptr, ptr } %173, 0
  %_230.1 = extractvalue { ptr, ptr } %173, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_230.0, ptr %_230.1)
  %174 = load i8, ptr %max, align 1
  %_2.i = xor i8 %174, -1
  %175 = call i8 @llvm.ctlz.i8(i8 %_2.i, i1 false)
  %_0.i59 = zext i8 %175 to i32
  store i32 %_0.i59, ptr %_250, align 4
  %176 = load i8, ptr %min, align 1
  %177 = call i8 @llvm.cttz.i8(i8 %176, i1 false)
  %_0.i62 = zext i8 %177 to i32
  store i32 %_0.i62, ptr %_252, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_254, ptr align 4 %_250) #23
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_255, ptr align 4 %_252) #23
  %178 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %178, ptr align 8 %_254, i64 16, i1 false)
  %179 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %179, ptr align 8 %_255, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %180 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #23
  %_247.0 = extractvalue { ptr, ptr } %180, 0
  %_247.1 = extractvalue { ptr, ptr } %180, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_247.0, ptr %_247.1)
  %181 = load i8, ptr %max, align 1
; call <i8>::isqrt
  %182 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa5isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %181, ptr align 8 @alloc_41c0e125573be1c7c4cca5e7c50e098d) #23
  store i8 %182, ptr %_262, align 1
  %183 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %three, i8 %three)
  %_266.0 = extractvalue { i8, i1 } %183, 0
  %_266.1 = extractvalue { i8, i1 } %183, 1
  br i1 %_266.1, label %panic29, label %bb127

panic28:                                          ; preds = %bb87
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_0a1a1a880a14ee52073c6e8568cd70eb) #30
  unreachable

bb127:                                            ; preds = %bb88
; call <i8>::ilog2
  %184 = call i32 @_RNvMNtCsl10jNU3mE6R_4core3numa5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %_266.0, ptr align 8 @alloc_acad96cb9ad91deee27e5040e130883c) #23
  store i32 %184, ptr %_264, align 4
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_268, ptr %_262) #23
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_269, ptr align 4 %_264) #23
  %185 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %185, ptr align 8 %_268, i64 16, i1 false)
  %186 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %186, ptr align 8 %_269, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %187 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #23
  %_259.0 = extractvalue { ptr, ptr } %187, 0
  %_259.1 = extractvalue { ptr, ptr } %187, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_259.0, ptr %_259.1)
; call <i8 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringaNtB5_8ToString9to_stringCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_279, ptr %max) #23
; invoke <alloc::string::String>::len
  %_277 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_279)
          to label %bb134 unwind label %cleanup

panic29:                                          ; preds = %bb88
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_e09845198ec90fbfc5a3565186e13680) #30
  unreachable

bb147:                                            ; preds = %bb146, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_279) #26
          to label %bb148 unwind label %terminate

cleanup:                                          ; preds = %bb143, %bb136, %bb135, %bb134, %bb127
  %188 = landingpad { ptr, i32 }
          cleanup
  %189 = extractvalue { ptr, i32 } %188, 0
  %190 = extractvalue { ptr, i32 } %188, 1
  store ptr %189, ptr %0, align 8
  %191 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %190, ptr %191, align 8
  br label %bb147

bb134:                                            ; preds = %bb127
; invoke <core::fmt::rt::Argument>::new_display::<i8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_289, ptr %min)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  %192 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %192, ptr align 8 %_289, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %193 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb136 unwind label %cleanup

bb136:                                            ; preds = %bb135
  %_285.0 = extractvalue { ptr, ptr } %193, 0
  %_285.1 = extractvalue { ptr, ptr } %193, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_284, ptr %_285.0, ptr %_285.1)
          to label %bb137 unwind label %cleanup

bb137:                                            ; preds = %bb136
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_283, ptr align 8 %_284, i64 24, i1 false)
  br label %bb138

bb138:                                            ; preds = %bb137
; invoke <alloc::string::String>::len
  %_281 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_283)
          to label %bb139 unwind label %cleanup30

bb146:                                            ; preds = %cleanup30
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_283) #26
          to label %bb147 unwind label %terminate

cleanup30:                                        ; preds = %bb142, %bb141, %bb140, %panic31, %bb138
  %194 = landingpad { ptr, i32 }
          cleanup
  %195 = extractvalue { ptr, i32 } %194, 0
  %196 = extractvalue { ptr, i32 } %194, 1
  store ptr %195, ptr %0, align 8
  %197 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %196, ptr %197, align 8
  br label %bb146

bb139:                                            ; preds = %bb138
  %_292.0 = add i64 %_277, %_281
  %_292.1 = icmp ult i64 %_292.0, %_277
  br i1 %_292.1, label %panic31, label %bb140

bb140:                                            ; preds = %bb139
  store i64 %_292.0, ptr %_276, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_294, ptr align 8 %_276)
          to label %bb141 unwind label %cleanup30

panic31:                                          ; preds = %bb139
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_5cacace390a18a9774a0946b258a8e02) #25
          to label %unreachable unwind label %cleanup30

unreachable:                                      ; preds = %panic31
  unreachable

bb141:                                            ; preds = %bb140
  %198 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %198, ptr align 8 %_294, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %199 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb142 unwind label %cleanup30

bb142:                                            ; preds = %bb141
  %_273.0 = extractvalue { ptr, ptr } %199, 0
  %_273.1 = extractvalue { ptr, ptr } %199, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_273.0, ptr %_273.1)
          to label %bb143 unwind label %cleanup30

bb143:                                            ; preds = %bb142
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_283)
          to label %bb144 unwind label %cleanup

bb144:                                            ; preds = %bb143
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_279)
  ret void

terminate:                                        ; preds = %bb147, %bb146
  %200 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable

bb148:                                            ; preds = %bb147
  %201 = load ptr, ptr %0, align 8
  %202 = getelementptr inbounds i8, ptr %0, i64 8
  %203 = load i32, ptr %202, align 8
  %204 = insertvalue { ptr, i32 } poison, ptr %201, 0
  %205 = insertvalue { ptr, i32 } %204, i32 %203, 1
  resume { ptr, i32 } %205
}

; <alloc::vec::Vec<u8>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !192 {
start:
; call <alloc::vec::Vec<u8>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #23
  ret void
}

; <[u8]>::to_vec
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !193 {
start:
; call <[u8]>::to_vec_in::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #23
  ret void
}

; <alloc::string::String>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !194 {
start:
  %_2 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_2, i64 %capacity) #23
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !195 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !196 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
  ret i64 %_0
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !197 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %ch) #23
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %ch_len) #23
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i32 %ch, ptr %_0.i) #23
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %_14) #23
  ret void
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !198 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::string::String>::push_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %string.0, i64 %string.1) unnamed_addr #0 !guid !199 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %string.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %string.1, 1
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; call <alloc::vec::Vec<u8>>::extend_from_slice
  call void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %_4.0, i64 %_4.1)
  ret void
}

; <i8>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa10strict_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !200 {
start:
  %_3 = alloca [2 x i8], align 1
; call <i8>::checked_pow
  %1 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) #23
  %2 = extractvalue { i1, i8 } %1, 0
  %3 = extractvalue { i1, i8 } %1, 1
  %4 = zext i1 %2 to i8
  store i8 %4, ptr %_3, align 1
  %5 = getelementptr inbounds i8, ptr %_3, i64 1
  store i8 %3, ptr %5, align 1
  %6 = load i8, ptr %_3, align 1
  %7 = trunc nuw i8 %6 to i1
  %8 = getelementptr inbounds i8, ptr %_3, i64 1
  %9 = load i8, ptr %8, align 1
  %_4 = zext i1 %7 to i64
  %10 = trunc nuw i64 %_4 to i1
  br i1 %10, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %11 = getelementptr inbounds i8, ptr %_3, i64 1
  %x = load i8, ptr %11, align 1
  ret i8 %x

bb3:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #25
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i8>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !201 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.sadd.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <i8>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_divCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !202 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %_5 = icmp eq i8 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i8 %self, -128
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i8 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = sdiv i8 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_7, ptr %6, align 1
  store i8 1, ptr %_0, align 1
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  %9 = getelementptr inbounds i8, ptr %_0, i64 1
  %10 = load i8, ptr %9, align 1
  %11 = insertvalue { i1, i8 } poison, i1 %8, 0
  %12 = insertvalue { i1, i8 } %11, i8 %10, 1
  ret { i1, i8 } %12
}

; <i8>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !203 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <i8>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %0) unnamed_addr #0 !guid !204 {
start:
  %_57 = alloca [2 x i8], align 1
  %_48 = alloca [2 x i8], align 1
  %_38 = alloca [2 x i8], align 1
  %_32 = alloca [2 x i8], align 1
  %_13 = alloca [8 x i8], align 4
  %acc = alloca [1 x i8], align 1
  %base = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i8 %self, ptr %base, align 1
  store i8 1, ptr %acc, align 1
  %_6 = load i8, ptr %base, align 1
  %_5 = call i1 @llvm.is.constant.i8(i8 %_6)
  br i1 %_5, label %bb2, label %bb16

bb16:                                             ; preds = %bb2, %start
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp eq i32 %_24, 0
  br i1 %_23, label %bb17, label %bb18

bb2:                                              ; preds = %start
  %_9 = load i8, ptr %base, align 1
; call <i8>::unsigned_abs
  %_8 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_9) #23
  %1 = call i8 @llvm.ctpop.i8(i8 %_8)
  %_0.i.i = zext i8 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb16

bb5:                                              ; preds = %bb2
  %_12 = load i8, ptr %base, align 1
; call <i8>::unsigned_abs
  %_11 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_12) #23
; call <u8>::ilog2
  %k = call i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %_11, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #23
  %_14 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i32 %k, i32 %_14) #23
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_13, align 4
  %5 = getelementptr inbounds i8, ptr %_13, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_13, align 4
  %7 = getelementptr inbounds i8, ptr %_13, i64 4
  %8 = load i32, ptr %7, align 4
  %_15 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_15 to i1
  br i1 %9, label %bb11, label %bb10

bb18:                                             ; preds = %bb16
  %_26 = load i32, ptr %exp, align 4
  %_25 = call i1 @llvm.is.constant.i32(i32 %_26)
  br i1 %_25, label %bb20, label %bb32

bb17:                                             ; preds = %bb16
  %10 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %10, align 1
  store i8 1, ptr %_0, align 1
  br label %bb43

bb32:                                             ; preds = %bb42, %bb18
  %_47 = load i32, ptr %exp, align 4
  %_46 = and i32 %_47, 1
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb33, label %bb38

bb20:                                             ; preds = %bb30, %bb18
  %_28 = load i32, ptr %exp, align 4
  %_27 = icmp ugt i32 %_28, 1
  br i1 %_27, label %bb21, label %bb31

bb38:                                             ; preds = %bb36, %bb32
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_58 = load i8, ptr %base, align 1
  %_59 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %13 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_58, i8 %_59) #23
  %14 = extractvalue { i1, i8 } %13, 0
  %15 = extractvalue { i1, i8 } %13, 1
  %16 = zext i1 %14 to i8
  store i8 %16, ptr %_57, align 1
  %17 = getelementptr inbounds i8, ptr %_57, i64 1
  store i8 %15, ptr %17, align 1
  %18 = load i8, ptr %_57, align 1
  %19 = trunc nuw i8 %18 to i1
  %20 = getelementptr inbounds i8, ptr %_57, i64 1
  %21 = load i8, ptr %20, align 1
  %_60 = zext i1 %19 to i64
  %22 = trunc nuw i64 %_60 to i1
  br i1 %22, label %bb42, label %bb41

bb33:                                             ; preds = %bb32
  %_49 = load i8, ptr %acc, align 1
  %_50 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %23 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_49, i8 %_50) #23
  %24 = extractvalue { i1, i8 } %23, 0
  %25 = extractvalue { i1, i8 } %23, 1
  %26 = zext i1 %24 to i8
  store i8 %26, ptr %_48, align 1
  %27 = getelementptr inbounds i8, ptr %_48, i64 1
  store i8 %25, ptr %27, align 1
  %28 = load i8, ptr %_48, align 1
  %29 = trunc nuw i8 %28 to i1
  %30 = getelementptr inbounds i8, ptr %_48, i64 1
  %31 = load i8, ptr %30, align 1
  %_51 = zext i1 %29 to i64
  %32 = trunc nuw i64 %_51 to i1
  br i1 %32, label %bb36, label %bb35

bb36:                                             ; preds = %bb33
  %33 = getelementptr inbounds i8, ptr %_48, i64 1
  %x = load i8, ptr %33, align 1
  store i8 %x, ptr %acc, align 1
  %_54 = load i32, ptr %exp, align 4
  %_53 = icmp eq i32 %_54, 1
  br i1 %_53, label %bb37, label %bb38

bb35:                                             ; preds = %bb33
  store i8 0, ptr %_0, align 1
  br label %bb43

bb43:                                             ; preds = %bb14, %bb15, %bb10, %bb17, %bb29, %bb24, %bb31, %bb37, %bb41, %bb35
  %34 = load i8, ptr %_0, align 1
  %35 = trunc nuw i8 %34 to i1
  %36 = getelementptr inbounds i8, ptr %_0, i64 1
  %37 = load i8, ptr %36, align 1
  %38 = insertvalue { i1, i8 } poison, i1 %35, 0
  %39 = insertvalue { i1, i8 } %38, i8 %37, 1
  ret { i1, i8 } %39

bb37:                                             ; preds = %bb36
  %_55 = load i8, ptr %acc, align 1
  %40 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_55, ptr %40, align 1
  store i8 1, ptr %_0, align 1
  br label %bb43

bb42:                                             ; preds = %bb38
  %41 = getelementptr inbounds i8, ptr %_57, i64 1
  %x1 = load i8, ptr %41, align 1
  store i8 %x1, ptr %base, align 1
  br label %bb32

bb41:                                             ; preds = %bb38
  store i8 0, ptr %_0, align 1
  br label %bb43

bb31:                                             ; preds = %bb20
  %_43 = load i8, ptr %acc, align 1
  %_44 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %42 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_43, i8 %_44) #23
  %43 = extractvalue { i1, i8 } %42, 0
  %44 = extractvalue { i1, i8 } %42, 1
  %45 = zext i1 %43 to i8
  store i8 %45, ptr %_0, align 1
  %46 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %44, ptr %46, align 1
  br label %bb43

bb21:                                             ; preds = %bb20
  %_31 = load i32, ptr %exp, align 4
  %_30 = and i32 %_31, 1
  %_29 = icmp eq i32 %_30, 1
  br i1 %_29, label %bb22, label %bb26

bb26:                                             ; preds = %bb25, %bb21
  %47 = load i32, ptr %exp, align 4
  %48 = udiv i32 %47, 2
  store i32 %48, ptr %exp, align 4
  %_39 = load i8, ptr %base, align 1
  %_40 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %49 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_39, i8 %_40) #23
  %50 = extractvalue { i1, i8 } %49, 0
  %51 = extractvalue { i1, i8 } %49, 1
  %52 = zext i1 %50 to i8
  store i8 %52, ptr %_38, align 1
  %53 = getelementptr inbounds i8, ptr %_38, i64 1
  store i8 %51, ptr %53, align 1
  %54 = load i8, ptr %_38, align 1
  %55 = trunc nuw i8 %54 to i1
  %56 = getelementptr inbounds i8, ptr %_38, i64 1
  %57 = load i8, ptr %56, align 1
  %_41 = zext i1 %55 to i64
  %58 = trunc nuw i64 %_41 to i1
  br i1 %58, label %bb30, label %bb29

bb22:                                             ; preds = %bb21
  %_33 = load i8, ptr %acc, align 1
  %_34 = load i8, ptr %base, align 1
; call <i8>::checked_mul
  %59 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_33, i8 %_34) #23
  %60 = extractvalue { i1, i8 } %59, 0
  %61 = extractvalue { i1, i8 } %59, 1
  %62 = zext i1 %60 to i8
  store i8 %62, ptr %_32, align 1
  %63 = getelementptr inbounds i8, ptr %_32, i64 1
  store i8 %61, ptr %63, align 1
  %64 = load i8, ptr %_32, align 1
  %65 = trunc nuw i8 %64 to i1
  %66 = getelementptr inbounds i8, ptr %_32, i64 1
  %67 = load i8, ptr %66, align 1
  %_35 = zext i1 %65 to i64
  %68 = trunc nuw i64 %_35 to i1
  br i1 %68, label %bb25, label %bb24

bb25:                                             ; preds = %bb22
  %69 = getelementptr inbounds i8, ptr %_32, i64 1
  %x2 = load i8, ptr %69, align 1
  store i8 %x2, ptr %acc, align 1
  br label %bb26

bb24:                                             ; preds = %bb22
  store i8 0, ptr %_0, align 1
  br label %bb43

bb30:                                             ; preds = %bb26
  %70 = getelementptr inbounds i8, ptr %_38, i64 1
  %x3 = load i8, ptr %70, align 1
  store i8 %x3, ptr %base, align 1
  br label %bb20

bb29:                                             ; preds = %bb26
  store i8 0, ptr %_0, align 1
  br label %bb43

bb11:                                             ; preds = %bb5
  %71 = getelementptr inbounds i8, ptr %_13, i64 4
  %shift = load i32, ptr %71, align 4
  %_18 = load i8, ptr %base, align 1
  %_17 = icmp slt i8 %_18, 0
  br i1 %_17, label %bb12, label %bb15

bb10:                                             ; preds = %bb5
  store i8 0, ptr %_0, align 1
  br label %bb43

bb15:                                             ; preds = %bb12, %bb11
; call <i8>::shl_exact
  %72 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa9shl_exactCs8pRW9QHXPaM_10int_ops_i8(i8 1, i32 %shift) #23
  %73 = extractvalue { i1, i8 } %72, 0
  %74 = extractvalue { i1, i8 } %72, 1
  %75 = zext i1 %73 to i8
  store i8 %75, ptr %_0, align 1
  %76 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %74, ptr %76, align 1
  br label %bb43

bb12:                                             ; preds = %bb11
  %_21 = load i32, ptr %exp, align 4
  %_20 = urem i32 %_21, 2
  %_19 = icmp eq i32 %_20, 1
  br i1 %_19, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
; call <i8>::shl_exact
  %77 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa9shl_exactCs8pRW9QHXPaM_10int_ops_i8(i8 -1, i32 %shift) #23
  %78 = extractvalue { i1, i8 } %77, 0
  %79 = extractvalue { i1, i8 } %77, 1
  %80 = zext i1 %78 to i8
  store i8 %80, ptr %_0, align 1
  %81 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %79, ptr %81, align 1
  br label %bb43

bb9:                                              ; No predecessors!
  unreachable
}

; <i8>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_remCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !205 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %_5 = icmp eq i8 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i8 %self, -128
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i8 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = srem i8 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_7, ptr %6, align 1
  store i8 1, ptr %_0, align 1
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  %9 = getelementptr inbounds i8, ptr %_0, i64 1
  %10 = load i8, ptr %9, align 1
  %11 = insertvalue { i1, i8 } poison, i1 %8, 0
  %12 = insertvalue { i1, i8 } %11, i8 %10, 1
  ret { i1, i8 } %12
}

; <i8>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_subCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %rhs) unnamed_addr #0 !guid !206 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %0 = call { i8, i1 } @llvm.ssub.with.overflow.i8(i8 %self, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %0, 0
  %_5.1.i = extractvalue { i8, i1 } %0, 1
  %_5.0 = extractvalue { i8, i1 } %0, 0
  %_5.1 = extractvalue { i8, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_5.0, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <i8>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !207 {
start:
; call <i8>::wrapping_abs
  %_2 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12wrapping_absCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #23
  ret i8 %_2
}

; <i8>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12wrapping_absCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !208 {
start:
  %_0 = alloca [1 x i8], align 1
  %_0.i = icmp slt i8 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 %self, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i8 0, %self
  store i8 %_0.i2, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; <i8>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12wrapping_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) unnamed_addr #0 !guid !209 {
start:
; call <i8>::overflowing_pow
  %0 = call { i8, i1 } @_RNvMNtCsl10jNU3mE6R_4core3numa15overflowing_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) #23
  %_3.0 = extractvalue { i8, i1 } %0, 0
  %_3.1 = extractvalue { i8, i1 } %0, 1
  ret i8 %_3.0
}

; <i8>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtCsl10jNU3mE6R_4core3numa13checked_ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !210 {
start:
  %_0 = alloca [8 x i8], align 4
  %_2 = icmp sle i8 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = call i8 @llvm.ctlz.i8(i8 %self, i1 true)
  %_5 = zext i8 %0 to i32
  %log = sub i32 7, %_5
  %1 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %log, ptr %1, align 4
  store i32 1, ptr %_0, align 4
  br label %bb4

bb1:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  %2 = load i32, ptr %_0, align 4
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  %4 = load i32, ptr %3, align 4
  %5 = insertvalue { i32, i32 } poison, i32 %2, 0
  %6 = insertvalue { i32, i32 } %5, i32 %4, 1
  ret { i32, i32 } %6
}

; <i8>::checked_isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa13checked_isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !211 {
start:
  %_0 = alloca [2 x i8], align 1
  %_2 = icmp slt i8 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call <u8>::isqrt
  %_4 = call i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #23
  %_7 = icmp sle i8 %_4, 11
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb2
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_7, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb2, %bb2.i
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_4, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb7

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb1, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %1 = load i8, ptr %_0, align 1
  %2 = trunc nuw i8 %1 to i1
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  %4 = load i8, ptr %3, align 1
  %5 = insertvalue { i1, i8 } poison, i1 %2, 0
  %6 = insertvalue { i1, i8 } %5, i8 %4, 1
  ret { i1, i8 } %6
}

; <i8>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa13unbounded_shlCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %rhs) unnamed_addr #0 !guid !212 {
start:
  %_0 = alloca [1 x i8], align 1
  %_3 = icmp ult i32 %rhs, 8
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_3.i, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <i8>::unchecked_shl::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %rhs, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #27
  br label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = trunc nuw i32 %rhs to i8
  %_0.i = shl i8 %self, %0
  store i8 %_0.i, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit, %bb2
  %1 = load i8, ptr %_0, align 1
  ret i8 %1
}

; <i8>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i8, i1 } @_RNvMNtCsl10jNU3mE6R_4core3numa15overflowing_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %0) unnamed_addr #0 !guid !213 {
start:
  %_30 = alloca [2 x i8], align 1
  %base1 = alloca [1 x i8], align 1
  %_16 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [1 x i8], align 1
  %base = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i8 %self, ptr %base, align 1
  store i8 1, ptr %acc, align 1
  store i8 0, ptr %overflow, align 1
  %_8 = load i8, ptr %base, align 1
  %_7 = call i1 @llvm.is.constant.i8(i8 %_8)
  br i1 %_7, label %bb2, label %bb19

bb19:                                             ; preds = %bb2, %start
  %_33 = load i32, ptr %exp, align 4
  %_32 = icmp eq i32 %_33, 0
  br i1 %_32, label %bb20, label %bb21

bb2:                                              ; preds = %start
  %_11 = load i8, ptr %base, align 1
; call <i8>::unsigned_abs
  %_10 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_11) #23
  %1 = call i8 @llvm.ctpop.i8(i8 %_10)
  %_0.i.i = zext i8 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb19

bb5:                                              ; preds = %bb2
  %_14 = load i8, ptr %base, align 1
; call <i8>::unsigned_abs
  %_13 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_14) #23
; call <u8>::ilog2
  %k = call i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %_13, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #23
  %_17 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i32 %k, i32 %_17) #23
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_16, align 4
  %5 = getelementptr inbounds i8, ptr %_16, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_16, align 4
  %7 = getelementptr inbounds i8, ptr %_16, i64 4
  %8 = load i32, ptr %7, align 4
  %_18 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_18 to i1
  br i1 %9, label %bb9, label %bb10

bb21:                                             ; preds = %bb19
  %_35 = load i32, ptr %exp, align 4
  %_34 = call i1 @llvm.is.constant.i32(i32 %_35)
  br i1 %_34, label %bb23, label %bb32

bb20:                                             ; preds = %bb19
  store i16 1, ptr %_0, align 1
  br label %bb39

bb32:                                             ; preds = %bb36, %bb21
  %_64 = load i32, ptr %exp, align 4
  %_63 = and i32 %_64, 1
  %_62 = icmp eq i32 %_63, 1
  br i1 %_62, label %bb33, label %bb36

bb23:                                             ; preds = %bb27, %bb21
  %_37 = load i32, ptr %exp, align 4
  %_36 = icmp ugt i32 %_37, 1
  br i1 %_36, label %bb24, label %bb30

bb36:                                             ; preds = %bb33, %bb32
  %10 = load i32, ptr %exp, align 4
  %11 = udiv i32 %10, 2
  store i32 %11, ptr %exp, align 4
  %_79 = load i8, ptr %base, align 1
  %_80 = load i8, ptr %base, align 1
  %12 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_79, i8 %_80)
  %_5.0.i6 = extractvalue { i8, i1 } %12, 0
  %_5.1.i7 = extractvalue { i8, i1 } %12, 1
  %_78.0 = extractvalue { i8, i1 } %12, 0
  %_78.1 = extractvalue { i8, i1 } %12, 1
  store i8 %_78.0, ptr %base, align 1
  %13 = zext i1 %_78.1 to i8
  store i8 %13, ptr %tmp_overflow, align 1
  %14 = load i8, ptr %tmp_overflow, align 1
  %_81 = trunc nuw i8 %14 to i1
  %15 = load i8, ptr %overflow, align 1
  %16 = trunc nuw i8 %15 to i1
  %17 = or i1 %16, %_81
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %overflow, align 1
  br label %bb32

bb33:                                             ; preds = %bb32
  %_68 = load i8, ptr %acc, align 1
  %_69 = load i8, ptr %base, align 1
  %19 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_68, i8 %_69)
  %_5.0.i8 = extractvalue { i8, i1 } %19, 0
  %_5.1.i9 = extractvalue { i8, i1 } %19, 1
  %_67.0 = extractvalue { i8, i1 } %19, 0
  %_67.1 = extractvalue { i8, i1 } %19, 1
  store i8 %_67.0, ptr %acc, align 1
  %20 = zext i1 %_67.1 to i8
  store i8 %20, ptr %tmp_overflow, align 1
  %21 = load i8, ptr %tmp_overflow, align 1
  %_70 = trunc nuw i8 %21 to i1
  %22 = load i8, ptr %overflow, align 1
  %23 = trunc nuw i8 %22 to i1
  %24 = or i1 %23, %_70
  %25 = zext i1 %24 to i8
  store i8 %25, ptr %overflow, align 1
  %_72 = load i32, ptr %exp, align 4
  %_71 = icmp eq i32 %_72, 1
  br i1 %_71, label %bb35, label %bb36

bb35:                                             ; preds = %bb33
  %_73 = load i8, ptr %acc, align 1
  %26 = load i8, ptr %overflow, align 1
  %_74 = trunc nuw i8 %26 to i1
  store i8 %_73, ptr %_0, align 1
  %27 = getelementptr inbounds i8, ptr %_0, i64 1
  %28 = zext i1 %_74 to i8
  store i8 %28, ptr %27, align 1
  br label %bb39

bb39:                                             ; preds = %bb10, %bb15, %bb20, %bb30, %bb35
  %29 = load i8, ptr %_0, align 1
  %30 = getelementptr inbounds i8, ptr %_0, i64 1
  %31 = load i8, ptr %30, align 1
  %32 = trunc nuw i8 %31 to i1
  %33 = insertvalue { i8, i1 } poison, i8 %29, 0
  %34 = insertvalue { i8, i1 } %33, i1 %32, 1
  ret { i8, i1 } %34

bb30:                                             ; preds = %bb23
  %_57 = load i8, ptr %acc, align 1
  %_58 = load i8, ptr %base, align 1
  %35 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_57, i8 %_58)
  %_5.0.i4 = extractvalue { i8, i1 } %35, 0
  %_5.1.i5 = extractvalue { i8, i1 } %35, 1
  %_56.0 = extractvalue { i8, i1 } %35, 0
  %_56.1 = extractvalue { i8, i1 } %35, 1
  store i8 %_56.0, ptr %acc, align 1
  %36 = zext i1 %_56.1 to i8
  store i8 %36, ptr %tmp_overflow, align 1
  %37 = load i8, ptr %tmp_overflow, align 1
  %_59 = trunc nuw i8 %37 to i1
  %38 = load i8, ptr %overflow, align 1
  %39 = trunc nuw i8 %38 to i1
  %40 = or i1 %39, %_59
  %41 = zext i1 %40 to i8
  store i8 %41, ptr %overflow, align 1
  %_60 = load i8, ptr %acc, align 1
  %42 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %42 to i1
  store i8 %_60, ptr %_0, align 1
  %43 = getelementptr inbounds i8, ptr %_0, i64 1
  %44 = zext i1 %_61 to i8
  store i8 %44, ptr %43, align 1
  br label %bb39

bb24:                                             ; preds = %bb23
  %_40 = load i32, ptr %exp, align 4
  %_39 = and i32 %_40, 1
  %_38 = icmp eq i32 %_39, 1
  br i1 %_38, label %bb25, label %bb27

bb27:                                             ; preds = %bb25, %bb24
  %45 = load i32, ptr %exp, align 4
  %46 = udiv i32 %45, 2
  store i32 %46, ptr %exp, align 4
  %_51 = load i8, ptr %base, align 1
  %_52 = load i8, ptr %base, align 1
  %47 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_51, i8 %_52)
  %_5.0.i = extractvalue { i8, i1 } %47, 0
  %_5.1.i = extractvalue { i8, i1 } %47, 1
  %_50.0 = extractvalue { i8, i1 } %47, 0
  %_50.1 = extractvalue { i8, i1 } %47, 1
  store i8 %_50.0, ptr %base, align 1
  %48 = zext i1 %_50.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_53 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_53
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  br label %bb23

bb25:                                             ; preds = %bb24
  %_44 = load i8, ptr %acc, align 1
  %_45 = load i8, ptr %base, align 1
  %54 = call { i8, i1 } @llvm.smul.with.overflow.i8(i8 %_44, i8 %_45)
  %_5.0.i2 = extractvalue { i8, i1 } %54, 0
  %_5.1.i3 = extractvalue { i8, i1 } %54, 1
  %_43.0 = extractvalue { i8, i1 } %54, 0
  %_43.1 = extractvalue { i8, i1 } %54, 1
  store i8 %_43.0, ptr %acc, align 1
  %55 = zext i1 %_43.1 to i8
  store i8 %55, ptr %tmp_overflow, align 1
  %56 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %56 to i1
  %57 = load i8, ptr %overflow, align 1
  %58 = trunc nuw i8 %57 to i1
  %59 = or i1 %58, %_46
  %60 = zext i1 %59 to i8
  store i8 %60, ptr %overflow, align 1
  br label %bb27

bb9:                                              ; preds = %bb5
  %61 = getelementptr inbounds i8, ptr %_16, i64 4
  %shift = load i32, ptr %61, align 4
  %_21 = load i8, ptr %base, align 1
  %_20 = icmp slt i8 %_21, 0
  br i1 %_20, label %bb11, label %bb14

bb10:                                             ; preds = %bb5
  store i16 256, ptr %_0, align 1
  br label %bb39

bb14:                                             ; preds = %bb11, %bb9
  store i8 1, ptr %base1, align 1
  br label %bb15

bb11:                                             ; preds = %bb9
  %_24 = load i32, ptr %exp, align 4
  %_23 = urem i32 %_24, 2
  %_22 = icmp ne i32 %_23, 0
  br i1 %_22, label %bb13, label %bb14

bb13:                                             ; preds = %bb11
  store i8 -1, ptr %base1, align 1
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_27 = load i8, ptr %base1, align 1
; call <i8>::unbounded_shl
  %_26 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa13unbounded_shlCs8pRW9QHXPaM_10int_ops_i8(i8 %_27, i32 %shift) #23
  %_31 = load i8, ptr %base1, align 1
; call <i8>::shl_exact
  %62 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa9shl_exactCs8pRW9QHXPaM_10int_ops_i8(i8 %_31, i32 %shift) #23
  %63 = extractvalue { i1, i8 } %62, 0
  %64 = extractvalue { i1, i8 } %62, 1
  %65 = zext i1 %63 to i8
  store i8 %65, ptr %_30, align 1
  %66 = getelementptr inbounds i8, ptr %_30, i64 1
  store i8 %64, ptr %66, align 1
; call <core::option::Option<i8>>::is_none
  %_28 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionaE7is_noneCs8pRW9QHXPaM_10int_ops_i8(ptr %_30) #23
  store i8 %_26, ptr %_0, align 1
  %67 = getelementptr inbounds i8, ptr %_0, i64 1
  %68 = zext i1 %_28 to i8
  store i8 %68, ptr %67, align 1
  br label %bb39

bb40:                                             ; No predecessors!
  unreachable
}

; <i8>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa3powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) unnamed_addr #0 !guid !214 {
start:
  %_0 = alloca [1 x i8], align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <i8>::strict_pow
  %0 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa10strict_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #23
  store i8 %0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; No predecessors!
; call <i8>::wrapping_pow
  %1 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12wrapping_powCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %exp) #23
  store i8 %1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_0, align 1
  ret i8 %2
}

; <i8>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtCsl10jNU3mE6R_4core3numa5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self, ptr align 8 %0) unnamed_addr #0 !guid !215 {
start:
  %_2 = alloca [8 x i8], align 4
; call <i8>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMNtCsl10jNU3mE6R_4core3numa13checked_ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) #23
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #25
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i8>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa5isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self, ptr align 8 %0) unnamed_addr #0 !guid !216 {
start:
  %_2 = alloca [2 x i8], align 1
; call <i8>::checked_isqrt
  %1 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa13checked_isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #23
  %2 = extractvalue { i1, i8 } %1, 0
  %3 = extractvalue { i1, i8 } %1, 1
  %4 = zext i1 %2 to i8
  store i8 %4, ptr %_2, align 1
  %5 = getelementptr inbounds i8, ptr %_2, i64 1
  store i8 %3, ptr %5, align 1
  %6 = load i8, ptr %_2, align 1
  %7 = trunc nuw i8 %6 to i1
  %8 = getelementptr inbounds i8, ptr %_2, i64 1
  %9 = load i8, ptr %8, align 1
  %_3 = zext i1 %7 to i64
  %10 = trunc nuw i64 %_3 to i1
  br i1 %10, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %11 = getelementptr inbounds i8, ptr %_2, i64 1
  %sqrt = load i8, ptr %11, align 1
  ret i8 %sqrt

bb3:                                              ; preds = %start
; call core::num::imp::int_sqrt::panic_for_negative_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8 %0) #25
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i8>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3numa8abs_diffCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i8 %other) unnamed_addr #0 !guid !217 {
start:
  %_0 = alloca [1 x i8], align 1
  %_3 = icmp slt i8 %self, %other
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_0.i1 = sub i8 %self, %other
  store i8 %_0.i1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  %_0.i = sub i8 %other, %self
  store i8 %_0.i, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; <i8>::shl_exact
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa9shl_exactCs8pRW9QHXPaM_10int_ops_i8(i8 %self, i32 %rhs) unnamed_addr #0 !guid !218 {
start:
  %_0 = alloca [2 x i8], align 1
  %0 = call i8 @llvm.ctlz.i8(i8 %self, i1 false)
  %_0.i4 = zext i8 %0 to i32
  %_3 = icmp ult i32 %rhs, %_0.i4
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_2.i = xor i8 %self, -1
  %1 = call i8 @llvm.ctlz.i8(i8 %_2.i, i1 false)
  %_0.i = zext i8 %1 to i32
  %_5 = icmp ult i32 %rhs, %_0.i
  br i1 %_5, label %bb4, label %bb6

bb4:                                              ; preds = %bb2, %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_3.i, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

bb2.i:                                            ; preds = %bb4
; call <i8>::unchecked_shl::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %rhs, ptr align 8 @alloc_67962a1ee7843a18e69bde6432c4d7d7) #27
  br label %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit

_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit: ; preds = %bb4, %bb2.i
  %2 = trunc nuw i32 %rhs to i8
  %_0.i2 = shl i8 %self, %2
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_0.i2, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb2
  store i8 0, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %_RNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl.exit, %bb6
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !219 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <[u8]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !220 {
start:
; call <core::slice::iter::Iter<u8>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) #23
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !221 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <core::option::Option<i8>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionaE7is_noneCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !222 {
start:
; call <core::option::Option<i8>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionaE7is_someCs8pRW9QHXPaM_10int_ops_i8(ptr %self) #23
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::option::Option<i8>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionaE7is_someCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !223 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_2 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %5 = load i8, ptr %_0, align 1
  %6 = trunc nuw i8 %5 to i1
  ret i1 %6

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i8, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultaNtNtNtB4_3num5error13ParseIntErrorE5is_okCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !224 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_2 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %5 = load i8, ptr %_0, align 1
  %6 = trunc nuw i8 %5 to i1
  ret i1 %6

bb4:                                              ; No predecessors!
  unreachable
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !225 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i64 %align, ptr align 8 %0) #27
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs8pRW9QHXPaM_10int_ops_i8(i64 %self) unnamed_addr #0 !guid !226 {
start:
  ret i64 %self
}

; <core::mem::alignment::Alignment>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCs8pRW9QHXPaM_10int_ops_i8(i64 %align) unnamed_addr #0 !guid !227 {
start:
  %_0 = alloca [8 x i8], align 8
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i64 %align, ptr align 8 @alloc_988c380202cc7b7a37ca3d8d5930c44f) #23
  store i64 %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::mem::alignment::Alignment>::as_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCs8pRW9QHXPaM_10int_ops_i8(i64 %self) unnamed_addr #0 !guid !228 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs8pRW9QHXPaM_10int_ops_i8(i64 %self) #23
; call <core::num::nonzero::NonZero<usize>>::get
  %_0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCs8pRW9QHXPaM_10int_ops_i8(i64 %_2) #23
  ret i64 %_0
}

; <*mut u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !229 {
start:
; call <*const u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %origin, ptr align 8 %0) #23
  ret i64 %_0
}

; <*mut u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !230 {
start:
; call <*const u8>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %self) #23
  ret i1 %_0
}

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !231 {
start:
; call <*const ()>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %self) #23
  ret i1 %_0
}

; <*const u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !232 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 1
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %origin, ptr align 8 %0) #27
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #30
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 1, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 1
  ret i64 %_0
}

; <*const u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !233 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %self) #23
  ret i1 %_0
}

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %align) unnamed_addr #0 !guid !234 {
start:
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i1 = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i1, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_fad0cd83b7d1858a846a172eb260e593, i64 42) #23
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 @alloc_7abc4ceda2d1d9be88f00c5dc522bc84) #30
  unreachable

bb2:                                              ; preds = %start
  %_0.i = ptrtoint ptr %self to i64
  %_8 = sub i64 %align, 1
  %_6 = and i64 %_0.i, %_8
  %_0 = icmp eq i64 %_6, 0
  ret i1 %_0
}

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !235 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %self) #23
  ret i1 %_0
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %self) unnamed_addr #0 !guid !236 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %self) #23
  ret i64 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %self, i32 %radix) unnamed_addr #0 !guid !237 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #23
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #30
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !238 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs8pRW9QHXPaM_10int_ops_i8(i64 %_3) #23
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs8pRW9QHXPaM_10int_ops_i8(i64 %_2) #23
  ret ptr %_0
}

; <core::alloc::layout::Layout>::repeat_packed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %n) unnamed_addr #0 !guid !239 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %0, align 8
; call <usize>::checked_mul
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i64 %_4, i64 %n) #23
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %size = load i64, ptr %8, align 8
  %_7 = load i64, ptr %self, align 8
; call <core::alloc::layout::Layout>::from_size_alignment
  %9 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %_7) #23
  %10 = extractvalue { i64, i64 } %9, 0
  %11 = extractvalue { i64, i64 } %9, 1
  store i64 %10, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %13 = load i64, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { i64, i64 } poison, i64 %13, 0
  %17 = insertvalue { i64, i64 } %16, i64 %15, 1
  ret { i64, i64 } %17

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %alignment) unnamed_addr #0 !guid !240 {
start:
  %_0 = alloca [16 x i8], align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 %alignment, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %size, ptr %0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <core::alloc::layout::Layout>::is_size_align_valid
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %align) unnamed_addr #0 !guid !241 {
start:
  %_4 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
; call <core::mem::alignment::Alignment>::new
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCs8pRW9QHXPaM_10int_ops_i8(i64 %align) #23
  store i64 %0, ptr %_4, align 8
  %1 = load i64, ptr %_4, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %alignment = load i64, ptr %_4, align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %4 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_align_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !242 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %align, ptr align 8 %0) #27
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %align, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !243 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::align
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !244 {
start:
  %_2 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_usize
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCs8pRW9QHXPaM_10int_ops_i8(i64 %_2) #23
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !245 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !246 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs8pRW9QHXPaM_10int_ops_i8(i64 %3, i64 %5, i1 zeroext %8) #23
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !247 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %2, i64 %4, i64 %6) #23
  ret void
}

; <alloc::alloc::Global>::grow_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global17grow_impl_runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %ptr, i64 %0, i64 %1, i64 %2, i64 %3, i1 zeroext %zeroed) unnamed_addr #0 !guid !248 {
start:
  %_8.i.i = alloca [1 x i8], align 1
  %_30 = alloca [16 x i8], align 8
  %_21 = alloca [8 x i8], align 8
  %old_size = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %new_layout = alloca [16 x i8], align 8
  %old_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %old_layout, align 8
  %4 = getelementptr inbounds i8, ptr %old_layout, i64 8
  store i64 %1, ptr %4, align 8
  store i64 %2, ptr %new_layout, align 8
  %5 = getelementptr inbounds i8, ptr %new_layout, i64 8
  store i64 %3, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %old_layout) #23
  store i64 %6, ptr %old_size, align 8
  %7 = load i64, ptr %old_size, align 8
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %9 = load i64, ptr %new_layout, align 8
  %10 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %11 = load i64, ptr %10, align 8
; call <alloc::alloc::Global>::alloc_impl
  %12 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %9, i64 %11, i1 zeroext %zeroed) #23
  %13 = extractvalue { ptr, i64 } %12, 0
  %14 = extractvalue { ptr, i64 } %12, 1
  store ptr %13, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %14, ptr %15, align 8
  br label %bb30

bb2:                                              ; preds = %start
; call <core::alloc::layout::Layout>::align
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %old_layout) #23
; call <core::alloc::layout::Layout>::align
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %new_layout) #23
  %_9 = icmp eq i64 %_10, %_12
  br i1 %_9, label %bb6, label %bb7

bb30:                                             ; preds = %bb17, %bb20, %bb25, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs8pRW9QHXPaM_10int_ops_i8.exit, %bb3
  %16 = load ptr, ptr %_0, align 8
  %17 = getelementptr inbounds i8, ptr %_0, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  ret { ptr, i64 } %20

bb7:                                              ; preds = %bb2
  %21 = load i64, ptr %new_layout, align 8
  %22 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %23 = load i64, ptr %22, align 8
; call <alloc::alloc::Global>::alloc_impl
  %24 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %21, i64 %23, i1 zeroext %zeroed) #23
  %_31.0 = extractvalue { ptr, i64 } %24, 0
  %_31.1 = extractvalue { ptr, i64 } %24, 1
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %25 = call { ptr, i64 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr %_31.0, i64 %_31.1) #23
  %26 = extractvalue { ptr, i64 } %25, 0
  %27 = extractvalue { ptr, i64 } %25, 1
  store ptr %26, ptr %_30, align 8
  %28 = getelementptr inbounds i8, ptr %_30, i64 8
  store i64 %27, ptr %28, align 8
  %29 = load ptr, ptr %_30, align 8
  %30 = getelementptr inbounds i8, ptr %_30, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = ptrtoint ptr %29 to i64
  %33 = icmp eq i64 %32, 0
  %_32 = select i1 %33, i64 1, i64 0
  %34 = trunc nuw i64 %_32 to i1
  br i1 %34, label %bb25, label %bb24

bb6:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %new_size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %new_layout) #23
; call <core::alloc::layout::Layout>::size
  %_18 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %old_layout) #23
  %_17 = icmp uge i64 %new_size, %_18
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2.i, label %bb2.i2, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i2:                                           ; preds = %bb6
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_17, ptr align 8 @alloc_9e1ff22d96cae328e0e878f28b86a5f7) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb6, %bb2.i2
  %35 = load i64, ptr %old_layout, align 8
  %36 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %37 = load i64, ptr %36, align 8
; call alloc::alloc::realloc_nonnull
  %raw_ptr = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc15realloc_nonnullCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %35, i64 %37, i64 %new_size) #23
; call <core::ptr::non_null::NonNull<u8>>::new
  %_23 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs8pRW9QHXPaM_10int_ops_i8(ptr %raw_ptr) #23
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_22 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs8pRW9QHXPaM_10int_ops_i8(ptr %_23) #23
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %38 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr %_22) #23
  store ptr %38, ptr %_21, align 8
  %39 = load ptr, ptr %_21, align 8
  %40 = ptrtoint ptr %39 to i64
  %41 = icmp eq i64 %40, 0
  %_24 = select i1 %41, i64 1, i64 0
  %42 = trunc nuw i64 %_24 to i1
  br i1 %42, label %bb17, label %bb16

bb25:                                             ; preds = %bb7
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %43 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 @alloc_6379aaa2812385052216e7dc8e3279fb) #23
  %44 = extractvalue { ptr, i64 } %43, 0
  %45 = extractvalue { ptr, i64 } %43, 1
  store ptr %44, ptr %_0, align 8
  %46 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %45, ptr %46, align 8
  br label %bb30

bb24:                                             ; preds = %bb7
  %new_ptr.0 = load ptr, ptr %_30, align 8
  %47 = getelementptr inbounds i8, ptr %_30, i64 8
  %new_ptr.1 = load i64, ptr %47, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_37 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr %new_ptr.0, i64 %new_ptr.1) #23
  %48 = load i64, ptr %old_size, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs8pRW9QHXPaM_10int_ops_i8.exit

bb2.i:                                            ; preds = %bb24
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, ptr %_37, i64 1, i64 1, i64 %48, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #27
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs8pRW9QHXPaM_10int_ops_i8.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs8pRW9QHXPaM_10int_ops_i8.exit: ; preds = %bb24, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_37, ptr align 1 %ptr, i64 %48, i1 false)
  %49 = load i64, ptr %old_layout, align 8
  %50 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %51 = load i64, ptr %50, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %ptr, i64 %49, i64 %51) #23
  store ptr %new_ptr.0, ptr %_0, align 8
  %52 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %new_ptr.1, ptr %52, align 8
  br label %bb30

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %53 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 @alloc_a699fef46c42b266f9e12652c07a696a) #23
  %54 = extractvalue { ptr, i64 } %53, 0
  %55 = extractvalue { ptr, i64 } %53, 1
  store ptr %54, ptr %_0, align 8
  %56 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %55, ptr %56, align 8
  br label %bb30

bb16:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %ptr1 = load ptr, ptr %_21, align 8
  br i1 %zeroed, label %bb18, label %bb20

bb20:                                             ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCs8pRW9QHXPaM_10int_ops_i8.exit, %bb16
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %57 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr1, i64 %new_size) #23
  %_29.0 = extractvalue { ptr, i64 } %57, 0
  %_29.1 = extractvalue { ptr, i64 } %57, 1
  store ptr %_29.0, ptr %_0, align 8
  %58 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29.1, ptr %58, align 8
  br label %bb30

bb18:                                             ; preds = %bb16
  %59 = load i64, ptr %old_size, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %raw_ptr, i64 %59
  %60 = load i64, ptr %old_size, align 8
  %_28 = sub i64 %new_size, %60
; call core::ub_checks::check_language_ub
  %_4.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_4.i.i, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCs8pRW9QHXPaM_10int_ops_i8.exit

bb2.i.i:                                          ; preds = %bb18
  %61 = icmp eq i64 %_28, 0
  %62 = zext i1 %61 to i8
  store i8 %62, ptr %_8.i.i, align 1
  %63 = load i8, ptr %_8.i.i, align 1
  %64 = trunc nuw i8 %63 to i1
; call core::ptr::write_bytes::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr11write_bytes18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %_0.i, i64 1, i1 zeroext %64, ptr align 8 @alloc_2fc439fdc88563e15d315d43214d38e0) #27
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCs8pRW9QHXPaM_10int_ops_i8.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCs8pRW9QHXPaM_10int_ops_i8.exit: ; preds = %bb18, %bb2.i.i
  call void @llvm.memset.p0.i64(ptr align 1 %_0.i, i8 0, i64 %_28, i1 false)
  br label %bb20

bb15:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs8pRW9QHXPaM_10int_ops_i8(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !249 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr %_6, i64 0) #23
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs8pRW9QHXPaM_10int_ops_i8(i64 %11, i64 %13) #23
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs8pRW9QHXPaM_10int_ops_i8(i64 %15, i64 %17) #23
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs8pRW9QHXPaM_10int_ops_i8(ptr %_12) #23
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs8pRW9QHXPaM_10int_ops_i8(ptr %_11) #23
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr %_10) #23
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #23
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %size) #23
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !250 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %3, i64 %5) #23
  br label %bb3
}

; <alloc::alloc::Global>::grow_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global9grow_implCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !251 {
start:
  %_6 = alloca [56 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %_6, i64 32
  store ptr %self, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_6, i64 40
  store ptr %ptr, ptr %1, align 8
  store i64 %old_layout.0, ptr %_6, align 8
  %2 = getelementptr inbounds i8, ptr %_6, i64 8
  store i64 %old_layout.1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_6, i64 16
  store i64 %new_layout.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %new_layout.1, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_6, i64 48
  %6 = zext i1 %zeroed to i8
  store i8 %6, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %_6, i64 32
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds i8, ptr %_6, i64 40
  %10 = load ptr, ptr %9, align 8
  %11 = load i64, ptr %_6, align 8
  %12 = getelementptr inbounds i8, ptr %_6, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = getelementptr inbounds i8, ptr %_6, i64 16
  %15 = load i64, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = getelementptr inbounds i8, ptr %_6, i64 48
  %19 = load i8, ptr %18, align 8
  %20 = trunc nuw i8 %19 to i1
; call <alloc::alloc::Global>::grow_impl_runtime
  %21 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global17grow_impl_runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %8, ptr %10, i64 %11, i64 %13, i64 %15, i64 %17, i1 zeroext %20) #23
  %_0.0 = extractvalue { ptr, i64 } %21, 0
  %_0.1 = extractvalue { ptr, i64 } %21, 1
  %22 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %_0.1, 1
  ret { ptr, i64 } %23
}

; <alloc::raw_vec::RawVec<u8>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !252 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u8>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u8>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #0 !guid !253 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %len, i64 %additional, i64 1, i64 1) #23
  ret void
}

; <alloc::raw_vec::RawVec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !254 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 1) #23
  ret i64 %_0
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i32 %self) unnamed_addr #0 !guid !255 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs8pRW9QHXPaM_10int_ops_i8(i32 %self) #23
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs8pRW9QHXPaM_10int_ops_i8(i32 %self) unnamed_addr #0 !guid !256 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs8pRW9QHXPaM_10int_ops_i8(i64 %addr) unnamed_addr #0 !guid !257 {
start:
  %_0 = inttoptr i64 %addr to ptr
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::extend_from_slice
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #1 !guid !258 {
start:
; call <[u8]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCs8pRW9QHXPaM_10int_ops_i8(ptr %other.0, i64 %other.1) #23
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
; call <alloc::vec::Vec<u8> as alloc::vec::spec_extend::SpecExtend<&u8, core::slice::iter::Iter<u8>>>::spec_extend
  call void @_RNvXs2_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB7_3VechEINtB5_10SpecExtendRhINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhEE11spec_extendCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %_3.0, ptr %_3.1)
  ret void
}

; <core::ptr::unique::Unique<u8>>::from_non_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %pointer) unnamed_addr #0 !guid !259 {
start:
  ret ptr %pointer
}

; <core::ptr::unique::Unique<u8>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !260 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<i8>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionaEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !261 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultaNtNtNtB9_3num5error13ParseIntErrorEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !262 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr.0, i64 %ptr.1, ptr align 8 %0) unnamed_addr #0 !guid !263 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %ptr.1, 1
  ret { ptr, i64 } %2

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr.0, ptr align 8 %0) #27
  br label %bb3
}

; <core::ptr::non_null::NonNull<[u8]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r.0, i64 %r.1) unnamed_addr #0 !guid !264 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<(i8, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTabEE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !265 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !266 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !267 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %r) unnamed_addr #0 !guid !268 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 4 %r) unnamed_addr #0 !guid !269 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !270 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, ptr align 8 %0) #27
  br label %bb3
}

; <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %subtracted) unnamed_addr #0 !guid !271 {
start:
; call <*mut u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #23
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr) unnamed_addr #0 !guid !272 {
start:
  %_0 = alloca [8 x i8], align 8
; call <*mut u8>::is_null
  %_2 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr) #23
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, ptr align 8 @alloc_e469ef44bf39c45bcb672a4bc963b9cb) #23
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <core::ptr::non_null::NonNull<u8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %r) unnamed_addr #0 !guid !273 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<usize>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %r) unnamed_addr #0 !guid !274 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr align 4 %r) unnamed_addr #0 !guid !275 {
start:
  ret ptr %r
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i64 %val) unnamed_addr #0 !guid !276 {
start:
  ret i64 %val
}

; <core::num::niche_types::UsizeNoHighBit>::as_inner
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs8pRW9QHXPaM_10int_ops_i8(i64 %self) unnamed_addr #0 !guid !277 {
start:
  ret i64 %self
}

; <alloc::raw_vec::RawVecInner>::needs_to_grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #0 !guid !278 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %elem_layout) #23
; call <alloc::raw_vec::RawVecInner>::capacity
  %_6 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %_7) #23
  %_0.i = sub i64 %_6, %len
  %_0 = icmp ugt i64 %additional, %_0.i
  ret i1 %_0
}

; <alloc::raw_vec::RawVecInner>::current_memory
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %0, i64 %1) unnamed_addr #0 !guid !279 {
start:
  %_17 = alloca [24 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %elem_layout) #23
  %_3 = icmp eq i64 %_4, 0
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_7 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs8pRW9QHXPaM_10int_ops_i8(i64 %_8) #23
  %_6 = icmp eq i64 %_7, 0
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb2, %start
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %3, align 8
  br label %bb12

bb5:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %elem_layout) #23
  %_13 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_12 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs8pRW9QHXPaM_10int_ops_i8(i64 %_13) #23
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

bb2.i:                                            ; preds = %bb5
; call <usize>::unchecked_mul::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i64 %_10, i64 %_12, ptr align 8 @alloc_85bcb8feb56634093aba2b8644936af9) #27
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit: ; preds = %bb5, %bb2.i
  %_0.i = mul nuw i64 %_10, %_12
; call <core::alloc::layout::Layout>::align
  %_15 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %elem_layout) #23
; call <core::alloc::layout::Layout>::from_size_align_unchecked
  %4 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i64 %_0.i, i64 %_15, ptr align 8 @alloc_17de00c3327446355700bd7db4b78ded) #23
  %layout.0 = extractvalue { i64, i64 } %4, 0
  %layout.1 = extractvalue { i64, i64 } %4, 1
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_19 = load ptr, ptr %5, align 8
; call <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
  %_18 = call ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCs8pRW9QHXPaM_10int_ops_i8(ptr %_19, ptr align 8 @alloc_b9419d44288097f84422e162822ba96e) #23
  store ptr %_18, ptr %_17, align 8
  %6 = getelementptr inbounds i8, ptr %_17, i64 8
  store i64 %layout.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %layout.1, ptr %7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_17, i64 24, i1 false)
  br label %bb12

bb12:                                             ; preds = %bb4, %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit
  ret void
}

; <alloc::raw_vec::RawVecInner>::set_ptr_and_cap
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15set_ptr_and_capCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %ptr.0, i64 %ptr.1, i64 %cap) unnamed_addr #0 !guid !280 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_5 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs8pRW9QHXPaM_10int_ops_i8(ptr %ptr.0, i64 %ptr.1) #23
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_4 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCs8pRW9QHXPaM_10int_ops_i8(ptr %_5) #23
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_4, ptr %0, align 8
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_6 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i64 %cap) #23
  store i64 %_6, ptr %self, align 8
  ret void
}

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCs8pRW9QHXPaM_10int_ops_i8(i64 %align) unnamed_addr #0 personality ptr @rust_eh_personality !guid !281 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs8pRW9QHXPaM_10int_ops_i8(i64 %align) #23
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_4 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs8pRW9QHXPaM_10int_ops_i8(i64 %_5) #23
  br label %bb2

bb2:                                              ; preds = %bb1
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %ptr = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %_4) #23
  br label %bb3

bb3:                                              ; preds = %bb2
  %0 = insertvalue { i64, ptr } { i64 0, ptr poison }, ptr %ptr, 1
  ret { i64, ptr } %0

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 !guid !282 {
start:
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_5 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) #23
  br i1 %_5, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
  call void @_RINvNvMs2_NtCs7CppTae75M1_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1)
  br label %bb3
}

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %elem_size) unnamed_addr #0 !guid !283 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 %elem_size, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs8pRW9QHXPaM_10int_ops_i8(i64 %_4) #23
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %len) unnamed_addr #0 !guid !284 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
  %0 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %len) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #1 !guid !285 {
start:
  %_3 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #23
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %ptr = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %layout.0 = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %layout.1 = load i64, ptr %5, align 8
  %_9 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs8pRW9QHXPaM_10int_ops_i8(ptr %_9, ptr %ptr, i64 %layout.0, i64 %layout.1) #23
  br label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCs8pRW9QHXPaM_10int_ops_i8(i64 %capacity) unnamed_addr #0 !guid !286 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs8pRW9QHXPaM_10int_ops_i8(i64 %capacity, i64 1, i64 1) #23
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !287 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECs8pRW9QHXPaM_10int_ops_i8(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #23
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr %_7.0, i64 %_7.1) #23
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !288 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs8pRW9QHXPaM_10int_ops_i8(ptr %s.0, i64 %s.1) #23
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u8>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh13checked_ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !289 {
start:
  %_2 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u8>>::new
  %0 = call i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3newCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #23
  store i8 %0, ptr %_2, align 1
  %1 = load i8, ptr %_2, align 1
  %2 = icmp eq i8 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i8, ptr %_2, align 1
; call <core::num::nonzero::NonZero<u8>>::ilog2
  %_5 = call i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %x) #23
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u8>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self, ptr align 8 %0) unnamed_addr #0 !guid !290 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u8>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh13checked_ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) #23
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #25
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u8>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh5isqrtCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !291 {
start:
; call core::num::imp::int_sqrt::u8
  %result = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) #23
  %_3 = icmp ule i8 %result, 15
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_3, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i8 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_3.i, label %bb2.i, label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u8>::unchecked_mul::precondition_check
  call void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i8 %result, i8 %result, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #27
  br label %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit

_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i8 %result, %result
  %_8 = icmp ule i8 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_8, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i8 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_11, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i8 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i8 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_6, ptr align 8 @alloc_1f1d7c1ec8c9041988f7c79d620acc00) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !292 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
  %_2 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) #23
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !293 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_0 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs8pRW9QHXPaM_10int_ops_i8(ptr %self.0, i64 %self.1) #23
  ret ptr %_0
}

; <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %len) unnamed_addr #0 !guid !294 {
start:
; call <*mut u8>::cast_slice
  %0 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %len) #23
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr %_3.0, i64 %_3.1, ptr align 8 @alloc_af3623564924928dd3d563c9d84a8a0e) #23
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::slice::iter::Iter<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCs8pRW9QHXPaM_10int_ops_i8(ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !295 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[u8]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCs8pRW9QHXPaM_10int_ops_i8(ptr %slice.0, i64 %slice.1) #23
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs8pRW9QHXPaM_10int_ops_i8(ptr %_4.0, i64 %_4.1) #23
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i8, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE8as_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !296 {
start:
  %_5.i = alloca [8 x i8], align 8
  %_4.i = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_9.i = load ptr, ptr %0, align 8
  %_10.i = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCs8pRW9QHXPaM_10int_ops_i8(ptr %_9.i, ptr %_10.i) #23
  store i64 %1, ptr %_5.i, align 8
  %2 = load i64, ptr %_5.i, align 8
; call core::slice::raw::from_raw_parts::<u8>
  %3 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECs8pRW9QHXPaM_10int_ops_i8(ptr %_4.i, i64 %2, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #23
  %_0.0.i = extractvalue { ptr, i64 } %3, 0
  %_0.1.i = extractvalue { ptr, i64 } %3, 1
  %_0.0 = extractvalue { ptr, i64 } %3, 0
  %_0.1 = extractvalue { ptr, i64 } %3, 1
  %4 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_0.1, 1
  ret { ptr, i64 } %5
}

; <alloc::raw_vec::RawVecInner>::finish_grow
; Function Attrs: cold nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %cap, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #4 !guid !297 {
start:
  %old_layout = alloca [16 x i8], align 8
  %_11 = alloca [24 x i8], align 8
  %memory = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %new_layout = alloca [16 x i8], align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_6, i64 %cap, i64 %elem_layout.0, i64 %elem_layout.1) #23
; call <core::result::Result<core::alloc::layout::Layout, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtB7_5alloc6layout6LayoutNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %_6) #23
  %_7 = load i64, ptr %_5, align 8
  %0 = trunc nuw i64 %_7 to i1
  br i1 %0, label %bb5, label %bb4

bb5:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_5, i64 8
  %residual.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %residual.1 = load i64, ptr %2, align 8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %residual.0, i64 %residual.1, ptr align 8 @alloc_9c2bc03755f157121052fe1398e358d1) #23
  br label %bb13

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  %val.0 = load i64, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  %val.1 = load i64, ptr %4, align 8
  store i64 %val.0, ptr %new_layout, align 8
  %5 = getelementptr inbounds i8, ptr %new_layout, i64 8
  store i64 %val.1, ptr %5, align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_11, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #23
  %6 = getelementptr inbounds i8, ptr %_11, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = icmp eq i64 %7, 0
  %_12 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_12 to i1
  br i1 %9, label %bb7, label %bb11

bb7:                                              ; preds = %bb4
  %ptr = load ptr, ptr %_11, align 8
  %10 = getelementptr inbounds i8, ptr %_11, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = getelementptr inbounds i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  store i64 %11, ptr %old_layout, align 8
  %14 = getelementptr inbounds i8, ptr %old_layout, i64 8
  store i64 %13, ptr %14, align 8
; call <core::alloc::layout::Layout>::align
  %_17 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %old_layout) #23
; call <core::alloc::layout::Layout>::align
  %_19 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %new_layout) #23
  %_16 = icmp eq i64 %_17, %_19
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb7
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_16, ptr align 8 @alloc_02ed5979549ad728dcb1e213f787b0ae) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb7, %bb2.i
  %_21 = getelementptr inbounds i8, ptr %self, i64 16
  %15 = load i64, ptr %old_layout, align 8
  %16 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = load i64, ptr %new_layout, align 8
  %19 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %20 = load i64, ptr %19, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::grow
  %21 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator4growCs8pRW9QHXPaM_10int_ops_i8(ptr %_21, ptr %ptr, i64 %15, i64 %17, i64 %18, i64 %20) #23
  %22 = extractvalue { ptr, i64 } %21, 0
  %23 = extractvalue { ptr, i64 } %21, 1
  store ptr %22, ptr %memory, align 8
  %24 = getelementptr inbounds i8, ptr %memory, i64 8
  store i64 %23, ptr %24, align 8
  br label %bb12

bb11:                                             ; preds = %bb4
  %_22 = getelementptr inbounds i8, ptr %self, i64 16
  %25 = load i64, ptr %new_layout, align 8
  %26 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %27 = load i64, ptr %26, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %28 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs8pRW9QHXPaM_10int_ops_i8(ptr %_22, i64 %25, i64 %27) #23
  %29 = extractvalue { ptr, i64 } %28, 0
  %30 = extractvalue { ptr, i64 } %28, 1
  store ptr %29, ptr %memory, align 8
  %31 = getelementptr inbounds i8, ptr %memory, i64 8
  store i64 %30, ptr %31, align 8
  br label %bb12

bb12:                                             ; preds = %bb11, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_23.0 = load ptr, ptr %memory, align 8
  %32 = getelementptr inbounds i8, ptr %memory, i64 8
  %_23.1 = load i64, ptr %32, align 8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError>>::map_err::<alloc::collections::TryReserveError, <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtNtB5_3ptr8non_null7NonNullShENtNtB5_5alloc10AllocErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvMs5_NtB1S_7raw_vecNtB2O_11RawVecInner11finish_grow0ECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %_23.0, i64 %_23.1, ptr align 8 %new_layout) #23
  br label %bb13

bb13:                                             ; preds = %bb5, %bb12
  ret void

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::grow_amortized
; Function Attrs: nonlazybind uwtable
define internal { i64, i64 } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #1 !guid !298 {
start:
  %_26 = alloca [24 x i8], align 8
  %_25 = alloca [24 x i8], align 8
  %_11 = alloca [16 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %elem_layout) #23
  %_5 = icmp eq i64 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; call <usize>::checked_add
  %3 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCs8pRW9QHXPaM_10int_ops_i8(i64 %len, i64 %additional) #23
  %_12.0 = extractvalue { i64, i64 } %3, 0
  %_12.1 = extractvalue { i64, i64 } %3, 1
; call <core::option::Option<usize>>::ok_or::<alloc::collections::TryReserveErrorKind>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE5ok_orNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindECs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_11, i64 %_12.0, i64 %_12.1, i64 0, i64 undef) #23
; call <core::result::Result<usize, alloc::collections::TryReserveErrorKind> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultjNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_10, ptr align 8 %_11) #23
  %4 = load i64, ptr %_10, align 8
  %5 = icmp eq i64 %4, -1
  %_14 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_14 to i1
  br i1 %6, label %bb10, label %bb9

bb2:                                              ; preds = %start
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs8pRW9QHXPaM_10int_ops_i8(i64 0, i64 undef, ptr align 8 @alloc_289c68237f406b28ee6ba245eefcd312) #23
  %_8.0 = extractvalue { i64, i64 } %7, 0
  %_8.1 = extractvalue { i64, i64 } %7, 1
  store i64 %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8.1, ptr %8, align 8
  br label %bb21

bb10:                                             ; preds = %bb4
  %residual.02 = load i64, ptr %_10, align 8
  %9 = getelementptr inbounds i8, ptr %_10, i64 8
  %residual.13 = load i64, ptr %9, align 8
; call <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveErrorKind>>>::from_residual
  %10 = call { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtBN_19TryReserveErrorKindEE13from_residualCs8pRW9QHXPaM_10int_ops_i8(i64 %residual.02, i64 %residual.13, ptr align 8 @alloc_91dabd4c1d2514ecf79277c06422ef65) #23
  %11 = extractvalue { i64, i64 } %10, 0
  %12 = extractvalue { i64, i64 } %10, 1
  store i64 %11, ptr %_0, align 8
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %12, ptr %13, align 8
  br label %bb21

bb9:                                              ; preds = %bb4
  %14 = getelementptr inbounds i8, ptr %_10, i64 8
  %required_cap = load i64, ptr %14, align 8
  %_20 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_19 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCs8pRW9QHXPaM_10int_ops_i8(i64 %_20) #23
  %_18 = mul i64 %_19, 2
; call core::cmp::max::<usize>
  %cap = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECs8pRW9QHXPaM_10int_ops_i8(i64 %_18, i64 %required_cap) #23
; call <core::alloc::layout::Layout>::size
  %_23 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %elem_layout) #23
; call alloc::raw_vec::min_non_zero_cap
  %_22 = call i64 @_RNvNtCs7CppTae75M1_5alloc7raw_vec16min_non_zero_cap(i64 %_23)
; call core::cmp::max::<usize>
  %cap1 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECs8pRW9QHXPaM_10int_ops_i8(i64 %_22, i64 %cap) #23
  %15 = load i64, ptr %elem_layout, align 8
  %16 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %17 = load i64, ptr %16, align 8
; call <alloc::raw_vec::RawVecInner>::finish_grow
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_26, ptr align 8 %self, i64 %cap1, i64 %15, i64 %17)
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_25, ptr align 8 %_26) #23
  %_28 = load i64, ptr %_25, align 8
  %18 = trunc nuw i64 %_28 to i1
  br i1 %18, label %bb19, label %bb18

bb19:                                             ; preds = %bb9
  %19 = getelementptr inbounds i8, ptr %_25, i64 8
  %residual.0 = load i64, ptr %19, align 8
  %20 = getelementptr inbounds i8, ptr %19, i64 8
  %residual.1 = load i64, ptr %20, align 8
; call <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
  %21 = call { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCs8pRW9QHXPaM_10int_ops_i8(i64 %residual.0, i64 %residual.1, ptr align 8 @alloc_8b924c2e6c70ef47ed23cadbb79c2da4) #23
  %22 = extractvalue { i64, i64 } %21, 0
  %23 = extractvalue { i64, i64 } %21, 1
  store i64 %22, ptr %_0, align 8
  %24 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %23, ptr %24, align 8
  br label %bb21

bb18:                                             ; preds = %bb9
  %25 = getelementptr inbounds i8, ptr %_25, i64 8
  %ptr.0 = load ptr, ptr %25, align 8
  %26 = getelementptr inbounds i8, ptr %25, i64 8
  %ptr.1 = load i64, ptr %26, align 8
; call <alloc::raw_vec::RawVecInner>::set_ptr_and_cap
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15set_ptr_and_capCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %ptr.0, i64 %ptr.1, i64 %cap1) #23
  store i64 -1, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb2, %bb10, %bb19, %bb18
  %27 = load i64, ptr %_0, align 8
  %28 = getelementptr inbounds i8, ptr %_0, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { i64, i64 } poison, i64 %27, 0
  %31 = insertvalue { i64, i64 } %30, i64 %29, 1
  ret { i64, i64 } %31

bb8:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::try_allocate_in
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %capacity, i1 zeroext %init, i64 %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !299 {
start:
  %_32 = alloca [1 x i8], align 1
  %_31 = alloca [1 x i8], align 1
  %result = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %layout = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  %alloc = alloca [0 x i8], align 1
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_31, align 1
  store i8 0, ptr %_32, align 1
  store i8 1, ptr %_31, align 1
  %3 = load i64, ptr %elem_layout, align 8
  %4 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_6, i64 %capacity, i64 %3, i64 %5) #23
  br label %bb1

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %_6, align 8
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs8pRW9QHXPaM_10int_ops_i8(i64 0, i64 undef, ptr align 8 @alloc_099d793709fa470a3d5e7c79c938e035) #23
  %_9.0 = extractvalue { i64, i64 } %7, 0
  %_9.1 = extractvalue { i64, i64 } %7, 1
  br label %bb5

bb4:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %_6, i64 8
  %layout.0 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %layout.1 = load i64, ptr %9, align 8
  store i64 %layout.0, ptr %layout, align 8
  %10 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %layout.1, ptr %10, align 8
; call <core::alloc::layout::Layout>::size
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
  br label %bb6

bb6:                                              ; preds = %bb4
  %_11 = icmp eq i64 %_12, 0
  br i1 %_11, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  %_19 = zext i1 %init to i64
  %11 = trunc nuw i64 %_19 to i1
  br i1 %11, label %bb11, label %bb12

bb7:                                              ; preds = %bb6
  store i8 0, ptr %_31, align 1
  store i8 1, ptr %_32, align 1
; call <core::alloc::layout::Layout>::alignment
  %_16 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %elem_layout) #23
  br label %bb8

bb11:                                             ; preds = %bb10
  %12 = load i64, ptr %layout, align 8
  %13 = getelementptr inbounds i8, ptr %layout, i64 8
  %14 = load i64, ptr %13, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
  %15 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCs8pRW9QHXPaM_10int_ops_i8(ptr %alloc, i64 %12, i64 %14) #23
  %16 = extractvalue { ptr, i64 } %15, 0
  %17 = extractvalue { ptr, i64 } %15, 1
  store ptr %16, ptr %result, align 8
  %18 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb28

bb12:                                             ; preds = %bb10
  %19 = load i64, ptr %layout, align 8
  %20 = getelementptr inbounds i8, ptr %layout, i64 8
  %21 = load i64, ptr %20, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %22 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs8pRW9QHXPaM_10int_ops_i8(ptr %alloc, i64 %19, i64 %21) #23
  %23 = extractvalue { ptr, i64 } %22, 0
  %24 = extractvalue { ptr, i64 } %22, 1
  store ptr %23, ptr %result, align 8
  %25 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %24, ptr %25, align 8
  br label %bb29

bb29:                                             ; preds = %bb12
  br label %bb13

bb13:                                             ; preds = %bb28, %bb29
  %26 = load ptr, ptr %result, align 8
  %27 = getelementptr inbounds i8, ptr %result, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = ptrtoint ptr %26 to i64
  %30 = icmp eq i64 %29, 0
  %_22 = select i1 %30, i64 1, i64 0
  %31 = trunc nuw i64 %_22 to i1
  br i1 %31, label %bb14, label %bb15

bb28:                                             ; preds = %bb11
  br label %bb13

bb14:                                             ; preds = %bb13
  %_25.0 = load i64, ptr %layout, align 8
  %32 = getelementptr inbounds i8, ptr %layout, i64 8
  %_25.1 = load i64, ptr %32, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %33 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs8pRW9QHXPaM_10int_ops_i8(i64 %_25.0, i64 %_25.1, ptr align 8 @alloc_33dfd402c6ecbe2e6a32e76edf5f31a5) #23
  %_24.0 = extractvalue { i64, i64 } %33, 0
  %_24.1 = extractvalue { i64, i64 } %33, 1
  br label %bb16

bb15:                                             ; preds = %bb13
  %ptr.0 = load ptr, ptr %result, align 8
  %34 = getelementptr inbounds i8, ptr %result, i64 8
  %ptr.1 = load i64, ptr %34, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_28 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECs8pRW9QHXPaM_10int_ops_i8(ptr %ptr.0, i64 %ptr.1) #23
  br label %bb17

bb17:                                             ; preds = %bb15
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_27 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCs8pRW9QHXPaM_10int_ops_i8(ptr %_28) #23
  br label %bb18

bb18:                                             ; preds = %bb17
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_29 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i64 %capacity) #23
  br label %bb19

bb19:                                             ; preds = %bb18
  store i8 0, ptr %_31, align 1
  %35 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29, ptr %35, align 8
  %36 = getelementptr inbounds i8, ptr %35, i64 8
  store ptr %_27, ptr %36, align 8
  store i64 0, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb23, %bb20, %bb19
  ret void

bb16:                                             ; preds = %bb14
  %37 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_24.0, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %37, i64 8
  store i64 %_24.1, ptr %38, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb20:                                             ; preds = %bb5, %bb9, %bb16
  %39 = load i8, ptr %_31, align 1
  %40 = trunc nuw i8 %39 to i1
  br i1 %40, label %bb23, label %bb21

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_32, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %41 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCs8pRW9QHXPaM_10int_ops_i8(i64 %_16) #23
  %_14.0 = extractvalue { i64, ptr } %41, 0
  %_14.1 = extractvalue { i64, ptr } %41, 1
  br label %bb9

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_32, align 1
  %42 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_14.0, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %42, i64 8
  store ptr %_14.1, ptr %43, align 8
  store i64 0, ptr %_0, align 8
  br label %bb20

bb5:                                              ; preds = %bb3
  %44 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_9.0, ptr %44, align 8
  %45 = getelementptr inbounds i8, ptr %44, i64 8
  store i64 %_9.1, ptr %45, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb23:                                             ; preds = %bb20
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable

bb25:                                             ; No predecessors!
  unreachable

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs8pRW9QHXPaM_10int_ops_i8(i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !300 {
start:
  %this = alloca [16 x i8], align 8
  %_4 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::try_allocate_in
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_4, i64 %capacity, i1 zeroext false, i64 %elem_layout.0, i64 %elem_layout.1)
  %_6 = load i64, ptr %_4, align 8
  %0 = trunc nuw i64 %_6 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  %err.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %err.1 = load i64, ptr %2, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #25
  unreachable

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load ptr, ptr %5, align 8
  store i64 %4, ptr %this, align 8
  %7 = getelementptr inbounds i8, ptr %this, i64 8
  store ptr %6, ptr %7, align 8
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_10 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %this, i64 0, i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) #23
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = xor i1 %_10, true
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb5
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %_9, ptr align 8 @alloc_51424262946dd0794fad6132df857999) #27
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb5, %bb2.i
  br label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_0.0 = load i64, ptr %this, align 8
  %8 = getelementptr inbounds i8, ptr %this, i64 8
  %_0.1 = load ptr, ptr %8, align 8
  %9 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %10 = insertvalue { i64, ptr } %9, ptr %_0.1, 1
  ret { i64, ptr } %10

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i32 %self, i32 %rhs) unnamed_addr #0 !guid !301 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs8pRW9QHXPaM_10int_ops_i8(ptr %self) unnamed_addr #0 !guid !302 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCs8pRW9QHXPaM_10int_ops_i8(i64 %self, i64 %rhs) unnamed_addr #0 !guid !303 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5.0 = add i64 %self, %rhs
  %_5.1 = icmp ult i64 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i64 %self, i64 %rhs) unnamed_addr #0 !guid !304 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs8pRW9QHXPaM_10int_ops_i8(i64 %self, i64 %other) unnamed_addr #0 !guid !305 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i32 %_0.i) #23
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <alloc::vec::Vec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !306 {
start:
; call <alloc::raw_vec::RawVec<u8>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCs8pRW9QHXPaM_10int_ops_i8(i64 %capacity) #23
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <core::num::nonzero::NonZero<u8>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE13leading_zerosCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !307 {
start:
; call <core::num::nonzero::NonZero<u8>>::get
  %_2 = call i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3getCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #23
  %0 = call i8 @llvm.ctlz.i8(i8 %_2, i1 true)
  %_0 = zext i8 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u8>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE5ilog2Cs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !308 {
start:
; call <core::num::nonzero::NonZero<u8>>::leading_zeros
  %_3 = call i32 @_RNvMsG_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE13leading_zerosCs8pRW9QHXPaM_10int_ops_i8(i8 %self) #23
  %_0 = sub i32 7, %_3
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs8pRW9QHXPaM_10int_ops_i8(i8 %0) unnamed_addr #0 !guid !309 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs8pRW9QHXPaM_10int_ops_i8(ptr %self) #23
  ret i32 %_0
}

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !310 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::append_elements
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE15append_elementsCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !311 {
start:
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECs8pRW9QHXPaM_10int_ops_i8(ptr %other.0, i64 %other.1) #23
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %_0.i)
; call <alloc::vec::Vec<u8>>::append_elements_unreserved
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE26append_elements_unreservedCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %other.0, i64 %other.1) #23
  ret void
}

; <alloc::vec::Vec<u8>>::append_elements_unreserved
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE26append_elements_unreservedCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !312 {
start:
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECs8pRW9QHXPaM_10int_ops_i8(ptr %other.0, i64 %other.1) #23
; call <alloc::vec::Vec<u8>>::len
  %len = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
  %_6 = icmp ugt i64 %_0.i1, 0
  br i1 %_6, label %bb3, label %bb6

bb6:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs8pRW9QHXPaM_10int_ops_i8.exit, %start
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i64, ptr %1, align 8
  %3 = add i64 %2, %_0.i1
  store i64 %3, ptr %0, align 8
  ret void

bb3:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs8pRW9QHXPaM_10int_ops_i8.exit

bb2.i:                                            ; preds = %bb3
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %other.0, ptr %_0.i, i64 1, i64 1, i64 %_0.i1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #27
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs8pRW9QHXPaM_10int_ops_i8.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECs8pRW9QHXPaM_10int_ops_i8.exit: ; preds = %bb3, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i, ptr align 1 %other.0, i64 %_0.i1, i1 false)
  br label %bb6
}

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !313 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 9223372036854775807
  ret i64 %len
}

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %additional) unnamed_addr #1 !guid !314 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<u8>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE7reserveCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %_5, i64 %additional) #23
  ret void
}

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !315 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #27
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #0 !guid !316 {
start:
; call <alloc::raw_vec::RawVec<u8>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
  ret i64 %_0
}

; <*mut u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %len) unnamed_addr #0 !guid !317 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %len) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::num::nonzero::NonZero<u8>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3getCs8pRW9QHXPaM_10int_ops_i8(i8 %self) unnamed_addr #0 !guid !318 {
start:
  ret i8 %self
}

; <core::num::nonzero::NonZero<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerohE3newCs8pRW9QHXPaM_10int_ops_i8(i8 %n) unnamed_addr #0 !guid !319 {
start:
  ret i8 %n
}

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCs8pRW9QHXPaM_10int_ops_i8(i64 %self) unnamed_addr #0 !guid !320 {
start:
  ret i64 %self
}

; <i8>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa14from_str_radixCs8pRW9QHXPaM_10int_ops_i8(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !321 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <i8>::from_ascii_bytes_radix_impl
  %2 = call { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa27from_ascii_bytes_radix_implCs8pRW9QHXPaM_10int_ops_i8(ptr %_3.0, i64 %_3.1, i32 %radix) #23
  %_0.0 = extractvalue { i1, i8 } %2, 0
  %_0.1 = extractvalue { i1, i8 } %2, 1
  %3 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %4 = insertvalue { i1, i8 } %3, i8 %_0.1, 1
  ret { i1, i8 } %4
}

; <i8>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa27from_ascii_bytes_radix_implCs8pRW9QHXPaM_10int_ops_i8(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !322 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [2 x i8], align 1
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [2 x i8], align 1
  %_74 = alloca [2 x i8], align 1
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [2 x i8], align 1
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [1 x i8], align 1
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [2 x i8], align 1
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #30
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCs8pRW9QHXPaM_10int_ops_i8(ptr %src.0, i64 %src.1) #23
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %_0, i64 1
  %7 = load i8, ptr %6, align 1
  %8 = insertvalue { i1, i8 } poison, i1 %5, 0
  %9 = insertvalue { i1, i8 } %8, i8 %7, 1
  ret { i1, i8 } %9

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %10 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 %src.1, ptr %11, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %12 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %13 = load i8, ptr %12, align 1
  switch i8 %13, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %14, i64 8
  store i64 %rest.1, ptr %15, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %16 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %17 = sub i64 %src.1, 1
  store ptr %16, ptr %rest, align 8
  %18 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %19 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %19 to i1
  %20 = getelementptr inbounds i8, ptr %_12, i64 8
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr inbounds i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  store ptr %21, ptr %digits, align 8, !captures !323
  %24 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %23, ptr %24, align 8
  store i8 0, ptr %result, align 1
  %_24.0 = load ptr, ptr %digits, align 8
  %25 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %25, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit

bb1.i:                                            ; preds = %bb15
  %26 = icmp ule i64 %_24.1, 1
  %27 = zext i1 %26 to i8
  store i8 %27, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit: ; preds = %bb2.i, %bb1.i
  %28 = load i8, ptr %_0.i, align 1
  %29 = trunc nuw i8 %28 to i1
  br i1 %29, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %30 = load ptr, ptr %rest, align 8
  %31 = getelementptr inbounds i8, ptr %rest, i64 8
  %32 = load i64, ptr %31, align 8
  %33 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %30, ptr %33, align 8
  %34 = getelementptr inbounds i8, ptr %33, i64 8
  store i64 %32, ptr %34, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowaECs8pRW9QHXPaM_10int_ops_i8.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %36, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %38, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i8, ptr %result, align 1
  %39 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_105, ptr %39, align 1
  store i8 0, ptr %_0, align 1
  br label %bb53

bb42:                                             ; preds = %bb41
  %40 = load ptr, ptr %digits, align 8
  %41 = getelementptr inbounds i8, ptr %digits, i64 8
  %42 = load i64, ptr %41, align 8
  %c = getelementptr inbounds nuw i8, ptr %40, i64 0
  %43 = load ptr, ptr %digits, align 8
  %44 = getelementptr inbounds i8, ptr %digits, i64 8
  %45 = load i64, ptr %44, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %43, i64 1
  %rest.13 = sub i64 %45, 1
  %_85 = load i8, ptr %result, align 1
  %_86 = trunc i32 %radix to i8
; call <i8>::checked_mul
  %46 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_85, i8 %_86) #23
  %47 = extractvalue { i1, i8 } %46, 0
  %48 = extractvalue { i1, i8 } %46, 1
  %49 = zext i1 %47 to i8
  store i8 %49, ptr %mul1, align 1
  %50 = getelementptr inbounds i8, ptr %mul1, i64 1
  store i8 %48, ptr %50, align 1
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %51 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %_89, i32 %radix) #23
  %52 = extractvalue { i32, i32 } %51, 0
  %53 = extractvalue { i32, i32 } %51, 1
  store i32 %52, ptr %_88, align 4
  %54 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %53, ptr %54, align 4
  %55 = load i32, ptr %_88, align 4
  %56 = getelementptr inbounds i8, ptr %_88, i64 4
  %57 = load i32, ptr %56, align 4
  %_91 = zext i32 %55 to i64
  %58 = trunc nuw i64 %_91 to i1
  br i1 %58, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %59 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %59, align 4
  %x = trunc i32 %value to i8
  %60 = load i8, ptr %mul1, align 1
  %61 = trunc nuw i8 %60 to i1
  %62 = getelementptr inbounds i8, ptr %mul1, i64 1
  %63 = load i8, ptr %62, align 1
  %_95 = zext i1 %61 to i64
  %64 = trunc nuw i64 %_95 to i1
  br i1 %64, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %65 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %65, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb48:                                             ; preds = %bb46
  %66 = getelementptr inbounds i8, ptr %mul1, i64 1
  %value4 = load i8, ptr %66, align 1
  store i8 %value4, ptr %result, align 1
  %_100 = load i8, ptr %result, align 1
; call <i8>::checked_sub
  %67 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_subCs8pRW9QHXPaM_10int_ops_i8(i8 %_100, i8 %x) #23
  %68 = extractvalue { i1, i8 } %67, 0
  %69 = extractvalue { i1, i8 } %67, 1
  %70 = zext i1 %68 to i8
  store i8 %70, ptr %_99, align 1
  %71 = getelementptr inbounds i8, ptr %_99, i64 1
  store i8 %69, ptr %71, align 1
  %72 = load i8, ptr %_99, align 1
  %73 = trunc nuw i8 %72 to i1
  %74 = getelementptr inbounds i8, ptr %_99, i64 1
  %75 = load i8, ptr %74, align 1
  %_101 = zext i1 %73 to i64
  %76 = trunc nuw i64 %_101 to i1
  br i1 %76, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %77 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %77, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb51:                                             ; preds = %bb48
  %78 = getelementptr inbounds i8, ptr %_99, i64 1
  %value5 = load i8, ptr %78, align 1
  store i8 %value5, ptr %result, align 1
  store ptr %rest.02, ptr %digits, align 8, !captures !323
  %79 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %79, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %80 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %80, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb31:                                             ; preds = %bb30
  %81 = load ptr, ptr %digits, align 8
  %82 = getelementptr inbounds i8, ptr %digits, i64 8
  %83 = load i64, ptr %82, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %81, i64 0
  %84 = load ptr, ptr %digits, align 8
  %85 = getelementptr inbounds i8, ptr %digits, i64 8
  %86 = load i64, ptr %85, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %84, i64 1
  %rest.18 = sub i64 %86, 1
  %_60 = load i8, ptr %result, align 1
  %_61 = trunc i32 %radix to i8
; call <i8>::checked_mul
  %87 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i8 %_60, i8 %_61) #23
  %88 = extractvalue { i1, i8 } %87, 0
  %89 = extractvalue { i1, i8 } %87, 1
  %90 = zext i1 %88 to i8
  store i8 %90, ptr %mul, align 1
  %91 = getelementptr inbounds i8, ptr %mul, i64 1
  store i8 %89, ptr %91, align 1
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %92 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %_64, i32 %radix) #23
  %93 = extractvalue { i32, i32 } %92, 0
  %94 = extractvalue { i32, i32 } %92, 1
  store i32 %93, ptr %_63, align 4
  %95 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %94, ptr %95, align 4
  %96 = load i32, ptr %_63, align 4
  %97 = getelementptr inbounds i8, ptr %_63, i64 4
  %98 = load i32, ptr %97, align 4
  %_66 = zext i32 %96 to i64
  %99 = trunc nuw i64 %_66 to i1
  br i1 %99, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %100 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %100, align 4
  %x10 = trunc i32 %value9 to i8
  %101 = load i8, ptr %mul, align 1
  %102 = trunc nuw i8 %101 to i1
  %103 = getelementptr inbounds i8, ptr %mul, i64 1
  %104 = load i8, ptr %103, align 1
  %_70 = zext i1 %102 to i64
  %105 = trunc nuw i64 %_70 to i1
  br i1 %105, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %106 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %106, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb37:                                             ; preds = %bb35
  %107 = getelementptr inbounds i8, ptr %mul, i64 1
  %value11 = load i8, ptr %107, align 1
  store i8 %value11, ptr %result, align 1
  %_75 = load i8, ptr %result, align 1
; call <i8>::checked_add
  %108 = call { i1, i8 } @_RNvMNtCsl10jNU3mE6R_4core3numa11checked_addCs8pRW9QHXPaM_10int_ops_i8(i8 %_75, i8 %x10) #23
  %109 = extractvalue { i1, i8 } %108, 0
  %110 = extractvalue { i1, i8 } %108, 1
  %111 = zext i1 %109 to i8
  store i8 %111, ptr %_74, align 1
  %112 = getelementptr inbounds i8, ptr %_74, i64 1
  store i8 %110, ptr %112, align 1
  %113 = load i8, ptr %_74, align 1
  %114 = trunc nuw i8 %113 to i1
  %115 = getelementptr inbounds i8, ptr %_74, i64 1
  %116 = load i8, ptr %115, align 1
  %_76 = zext i1 %114 to i64
  %117 = trunc nuw i64 %_76 to i1
  br i1 %117, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %118 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %118, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb40:                                             ; preds = %bb37
  %119 = getelementptr inbounds i8, ptr %_74, i64 1
  %value12 = load i8, ptr %119, align 1
  store i8 %value12, ptr %result, align 1
  store ptr %rest.07, ptr %digits, align 8, !captures !323
  %120 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %120, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %121 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %121, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %122 = load ptr, ptr %digits, align 8
  %123 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %123, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %124 = load ptr, ptr %digits, align 8
  %125 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %125, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %126 = load ptr, ptr %digits, align 8
  %127 = getelementptr inbounds i8, ptr %digits, i64 8
  %128 = load i64, ptr %127, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %126, i64 0
  %129 = load ptr, ptr %digits, align 8
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  %131 = load i64, ptr %130, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %129, i64 1
  %rest.115 = sub i64 %131, 1
  %_44 = load i8, ptr %result, align 1
  %_45 = trunc i32 %radix to i8
  %132 = mul i8 %_44, %_45
  store i8 %132, ptr %result, align 1
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %133 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %_47, i32 %radix) #23
  %134 = extractvalue { i32, i32 } %133, 0
  %135 = extractvalue { i32, i32 } %133, 1
  store i32 %134, ptr %_46, align 4
  %136 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %135, ptr %136, align 4
  %137 = load i32, ptr %_46, align 4
  %138 = getelementptr inbounds i8, ptr %_46, i64 4
  %139 = load i32, ptr %138, align 4
  %_49 = zext i32 %137 to i64
  %140 = trunc nuw i64 %_49 to i1
  br i1 %140, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %141 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %141, align 4
  %_53 = load i8, ptr %result, align 1
  %_54 = trunc i32 %x16 to i8
  %142 = sub i8 %_53, %_54
  store i8 %142, ptr %result, align 1
  store ptr %rest.014, ptr %digits, align 8, !captures !323
  %143 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %143, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %144 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %144, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb19:                                             ; preds = %bb18
  %145 = load ptr, ptr %digits, align 8
  %146 = getelementptr inbounds i8, ptr %digits, i64 8
  %147 = load i64, ptr %146, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %145, i64 0
  %148 = load ptr, ptr %digits, align 8
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  %150 = load i64, ptr %149, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %148, i64 1
  %rest.119 = sub i64 %150, 1
  %_29 = load i8, ptr %result, align 1
  %_30 = trunc i32 %radix to i8
  %151 = mul i8 %_29, %_30
  store i8 %151, ptr %result, align 1
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %152 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCs8pRW9QHXPaM_10int_ops_i8(i32 %_32, i32 %radix) #23
  %153 = extractvalue { i32, i32 } %152, 0
  %154 = extractvalue { i32, i32 } %152, 1
  store i32 %153, ptr %_31, align 4
  %155 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %154, ptr %155, align 4
  %156 = load i32, ptr %_31, align 4
  %157 = getelementptr inbounds i8, ptr %_31, i64 4
  %158 = load i32, ptr %157, align 4
  %_34 = zext i32 %156 to i64
  %159 = trunc nuw i64 %_34 to i1
  br i1 %159, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %160 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %160, align 4
  %_38 = load i8, ptr %result, align 1
  %_39 = trunc i32 %x20 to i8
  %161 = add i8 %_38, %_39
  store i8 %161, ptr %result, align 1
  store ptr %rest.018, ptr %digits, align 8, !captures !323
  %162 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %162, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %163 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %163, align 1
  store i8 1, ptr %_0, align 1
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !324 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %args) #23
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #23
  ret void
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs8pRW9QHXPaM_10int_ops_i8(i64 %0, i64 %1) unnamed_addr #0 !guid !325 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !326 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #29
  ret void
}

; alloc::alloc::realloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc15realloc_nonnullCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %0, i64 %1, i64 %new_size) unnamed_addr #0 !guid !327 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
; call <core::alloc::layout::Layout>::alignment
  %_6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
; call __rustc::__rust_realloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc14___rust_realloc(ptr %ptr, i64 %_4, i64 %_6, i64 %new_size) #29
  ret ptr %_0
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs8pRW9QHXPaM_10int_ops_i8(i64 %0, i64 %1) unnamed_addr #0 !guid !328 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %layout) #23
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::raw_vec::layout_array
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %cap, i64 %0, i64 %1) unnamed_addr #0 !guid !329 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::repeat_packed
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %elem_layout, i64 %cap) #23
  %_3.0 = extractvalue { i64, i64 } %3, 0
  %_3.1 = extractvalue { i64, i64 } %3, 1
; call <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %_3.0, i64 %_3.1) #23
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #5 !guid !330 {
start:
  ret void
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %align) unnamed_addr #0 !guid !331 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %align) #23
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #0 !guid !332 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs8pRW9QHXPaM_10int_ops_i8() #23
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs8pRW9QHXPaM_10int_ops_i8(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !333 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %3, ptr %5, i64 %7, i64 %9) #23
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %len) unnamed_addr #0 !guid !334 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #30
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !335 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %align) #23
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr) #23
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !336 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs8pRW9QHXPaM_10int_ops_i8(i32 %code, ptr %dst) unnamed_addr #0 !guid !337 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %code) #23
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs8pRW9QHXPaM_10int_ops_i8(i32 %code) unnamed_addr #0 !guid !338 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8Cs8pRW9QHXPaM_10int_ops_i8(i8 %n) unnamed_addr #0 !guid !339 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.681c060d2bfd6770ec9e5f1a4ed3b4ec.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #30
  unreachable
}

; <i8>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shl18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !340 {
start:
  %_2 = icmp ult i32 %rhs, 8
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_cbcfb4391f0fcdd0dcd48dbe6149ef89, i64 183)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; <i8>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtCsl10jNU3mE6R_4core3numa13unchecked_shr18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i32 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !341 {
start:
  %_2 = icmp ult i32 %rhs, 8
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_66558f7972e7e036e1d4ccb8be86690a, i64 183)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i64 %align, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !342 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !343 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr) unnamed_addr #0 !guid !344 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !345 {
start:
; invoke <core::alloc::layout::Layout>::is_size_align_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %align)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_1be5ea12ba708d9a11b6e93a7d387a75, i64 281)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !346 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; <u8>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs4_NtCsl10jNU3mE6R_4core3numh13unchecked_mul18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i8 %lhs, i8 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !347 {
start:
  %1 = call { i8, i1 } @llvm.umul.with.overflow.i8(i8 %lhs, i8 %rhs)
  %_5.0.i = extractvalue { i8, i1 } %1, 0
  %_5.1.i = extractvalue { i8, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i8, i1 } %1, 0
  %_4.1 = extractvalue { i8, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_eff87de2e562ad9bea1d5ede245212a6, i64 183)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; <usize>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !348 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !349 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; core::ptr::write_bytes::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr11write_bytes18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %addr, i64 %align, i1 zeroext %zero_size, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !350 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_4 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %addr, i64 %align, i1 zeroext %zero_size)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_dd79dfae92e8fdc23813c4c7a1b7cf72, i64 228)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_6.0 = extractvalue { ptr, ptr } %2, 0
  %_6.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !351 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs8pRW9QHXPaM_10int_ops_i8(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !352 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %align) unnamed_addr #0 !guid !353 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCs8pRW9QHXPaM_10int_ops_i8(ptr %ptr, i64 %align) #23
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #0 !guid !354 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs8pRW9QHXPaM_10int_ops_i8(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !355 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %count) #23
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs8pRW9QHXPaM_10int_ops_i8(i64 %_0.i2, i64 %_0.i) #23
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #31
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !356 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #24
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr @alloc_a28e8c8fd5088943a8b5d44af697ff83, i64 279)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs8pRW9QHXPaM_10int_ops_i8(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #31
  unreachable
}

; <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCs8pRW9QHXPaM_10int_ops_i8(i64 %kind.0, i64 %kind.1) unnamed_addr #0 !guid !357 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %kind.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %kind.1, 1
  ret { i64, i64 } %1
}

; <i8 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1G_NtCs7CppTae75M1_5alloc6stringaNtB6_12SpecToString14spec_to_stringCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !358 {
start:
  %0 = alloca [16 x i8], align 8
  %_19 = alloca [1 x i8], align 1
  %_11 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  %out = alloca [24 x i8], align 8
  %buf = alloca [3 x i8], align 1
  store i8 0, ptr %_19, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 3, i1 false)
  %_6 = load i8, ptr %self, align 1
  %_5 = icmp slt i8 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_11, i64 3)
          to label %bb5 unwind label %cleanup

bb2:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_7, i64 4)
          to label %bb3 unwind label %cleanup

bb12:                                             ; preds = %cleanup
  %1 = load i8, ptr %_19, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb11, label %bb10

cleanup:                                          ; preds = %bb8, %bb7, %bb6, %bb3, %bb2, %bb4
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb12

bb5:                                              ; preds = %bb4
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_11, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb13, %bb5
  %_16 = load i8, ptr %self, align 1
; invoke <i8>::unsigned_abs
  %_15 = invoke i8 @_RNvMNtCsl10jNU3mE6R_4core3numa12unsigned_absCs8pRW9QHXPaM_10int_ops_i8(i8 %_16)
          to label %bb7 unwind label %cleanup

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_7, i64 24, i1 false)
; invoke <alloc::string::String>::push
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %out, i32 45)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb3
  br label %bb6

bb7:                                              ; preds = %bb6
; invoke <u8>::_fmt
  %7 = invoke { ptr, i64 } @_RNvMs0_NtNtNtCsl10jNU3mE6R_4core3fmt3num3imph4__fmt(i8 %_15, ptr %buf, i64 3)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %_14.0 = extractvalue { ptr, i64 } %7, 0
  %_14.1 = extractvalue { ptr, i64 } %7, 1
; invoke <alloc::string::String>::push_str
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %out, ptr %_14.0, i64 %_14.1)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %out, i64 24, i1 false)
  store i8 0, ptr %_19, align 1
  ret void

bb10:                                             ; preds = %bb11, %bb12
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb11:                                             ; preds = %bb12
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %out) #26
          to label %bb10 unwind label %terminate

terminate:                                        ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #24
  unreachable
}

; <(i8, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTabENtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #1 !guid !359 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !360 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #23
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !361 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext true) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator4growCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1) unnamed_addr #0 !guid !362 {
start:
; call <alloc::alloc::Global>::grow_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global9grow_implCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1, i1 zeroext false) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !363 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs8pRW9QHXPaM_10int_ops_i8(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #1 !guid !364 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, i64 1, i64 1)
  ret void
}

; <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %0) unnamed_addr #0 !guid !365 {
start:
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_0 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs8pRW9QHXPaM_10int_ops_i8(ptr %self) #23
  ret ptr %_0
}

; <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCs8pRW9QHXPaM_10int_ops_i8(i64 %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !366 {
start:
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCs8pRW9QHXPaM_10int_ops_i8(i64 %self.0, i64 %self.1) #23
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !367 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %_3, ptr align 8 %f) #23
  ret i1 %_0
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !368 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %_3, ptr align 8 %f) #23
  ret i1 %_0
}

; <&i8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !369 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %_3, ptr align 8 %f) #23
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !370 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %_3, ptr align 8 %f) #23
  ret i1 %_0
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !371 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #23
  ret void
}

; <alloc::vec::Vec<u8> as alloc::vec::spec_extend::SpecExtend<&u8, core::slice::iter::Iter<u8>>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs2_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB7_3VechEINtB5_10SpecExtendRhINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhEE11spec_extendCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #1 !guid !372 {
start:
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %2 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %2, align 8
; call <core::slice::iter::Iter<u8>>::as_slice
  %3 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE8as_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %iterator) #23
  %slice.0 = extractvalue { ptr, i64 } %3, 0
  %slice.1 = extractvalue { ptr, i64 } %3, 1
; call <alloc::vec::Vec<u8>>::append_elements
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE15append_elementsCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self, ptr %slice.0, i64 %slice.1) #23
  ret void
}

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !373 {
start:
; call <[u8]>::to_vec
  call void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #23
  ret void
}

; <i8 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringaNtB5_8ToString9to_stringCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self) unnamed_addr #0 !guid !374 {
start:
; call <i8 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1G_NtCs7CppTae75M1_5alloc6stringaNtB6_12SpecToString14spec_to_stringCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %self) #23
  ret void
}

; <i8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !375 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::option::Option<i8> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionaENtNtB7_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !376 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.1)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %8 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %9 = zext i1 %8 to i8
  store i8 %9, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %10 = load i8, ptr %_0, align 1
  %11 = trunc nuw i8 %10 to i1
  ret i1 %11

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs8pRW9QHXPaM_10int_ops_i8() unnamed_addr #0 !guid !377 {
start:
  ret i8 0
}

; <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCs8pRW9QHXPaM_10int_ops_i8(ptr %pointer) unnamed_addr #0 !guid !378 {
start:
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCs8pRW9QHXPaM_10int_ops_i8(ptr %pointer) #23
  ret ptr %_0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !379 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !380 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs8pRW9QHXPaM_10int_ops_i8(ptr %unique) unnamed_addr #0 !guid !381 {
start:
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr %unique) #23
  ret ptr %_0
}

; <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !382 {
start:
  %_3 = alloca [16 x i8], align 8
  %0 = load i8, ptr %self, align 1
  %_4 = zext i8 %0 to i64
  switch i64 %_4, label %bb1 [
    i64 0, label %bb7
    i64 1, label %bb6
    i64 2, label %bb5
    i64 3, label %bb4
    i64 4, label %bb3
    i64 5, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb7:                                              ; preds = %start
  store ptr @alloc_59ba7b9f7211443cd55a366616eef46a, ptr %_3, align 8, !captures !323
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %1, align 8
  br label %bb8

bb6:                                              ; preds = %start
  store ptr @alloc_00315c78e51d29fe6b3102a4c1ecf6ef, ptr %_3, align 8, !captures !323
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 12, ptr %2, align 8
  br label %bb8

bb5:                                              ; preds = %start
  store ptr @alloc_bd3a3f3879e0d5f64554753e977f58d4, ptr %_3, align 8, !captures !323
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %3, align 8
  br label %bb8

bb4:                                              ; preds = %start
  store ptr @alloc_0964bb2a4870637395c77a018495bd5c, ptr %_3, align 8, !captures !323
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %4, align 8
  br label %bb8

bb3:                                              ; preds = %start
  store ptr @alloc_6566120a3a17f930e960a0863fcbd591, ptr %_3, align 8, !captures !323
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %5, align 8
  br label %bb8

bb2:                                              ; preds = %start
  store ptr @alloc_6c17bac0c71cba42380f8445f4dcbd16, ptr %_3, align 8, !captures !323
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 14, ptr %6, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb3, %bb4, %bb5, %bb6, %bb7
  %7 = load ptr, ptr %_3, align 8
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = load i64, ptr %8, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %7, i64 %9)
  ret i1 %_0
}

; <i8 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXsk_NtCsl10jNU3mE6R_4core3numaNtNtNtB7_3str6traits7FromStr8from_strCs8pRW9QHXPaM_10int_ops_i8(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !383 {
start:
; call <i8>::from_str_radix
  %0 = call { i1, i8 } @_RNvMsl_NtCsl10jNU3mE6R_4core3numa14from_str_radixCs8pRW9QHXPaM_10int_ops_i8(ptr %src.0, i64 %src.1, i32 10) #23
  %_0.0 = extractvalue { i1, i8 } %0, 0
  %_0.1 = extractvalue { i1, i8 } %0, 1
  %1 = insertvalue { i1, i8 } poison, i1 %_0.0, 0
  %2 = insertvalue { i1, i8 } %1, i8 %_0.1, 1
  ret { i1, i8 } %2
}

; <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) unnamed_addr #1 !guid !384 {
start:
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %self) #23
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCs8pRW9QHXPaM_10int_ops_i8(ptr %_3, i64 %_4) #23
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr %0, i64 %1) unnamed_addr #0 !guid !385 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_2 = select i1 %7, i64 1, i64 0
  %8 = trunc nuw i64 %_2 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %v.1 = load i64, ptr %9, align 8
  store ptr %v.0, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.1, ptr %10, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !386 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = trunc nuw i64 %_2 to i1
  br i1 %0, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %e.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %e.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %e.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v.0 = load ptr, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %v.1 = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %v.0, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 8
  store i64 %v.1, ptr %8, align 8
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr %0) unnamed_addr #0 !guid !387 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtB7_5alloc6layout6LayoutNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !388 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = trunc nuw i64 %_2 to i1
  br i1 %0, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %e.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %e.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %e.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v.0 = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %v.1 = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.0, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 8
  store i64 %v.1, ptr %8, align 8
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<usize, alloc::collections::TryReserveErrorKind> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultjNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindENtNtNtB7_3ops9try_trait3Try6branchCs8pRW9QHXPaM_10int_ops_i8(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !389 {
start:
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load i64, ptr %3, align 8
  store i64 %e.0, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.1, ptr %4, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %6, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %0) unnamed_addr #0 !guid !390 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { ptr, i64 } { ptr null, i64 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !391 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  %1 = insertvalue { i64, i64 } poison, i64 %residual.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %residual.1, 1
  %_4.0 = extractvalue { i64, i64 } %2, 0
  %_4.1 = extractvalue { i64, i64 } %2, 1
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %_4.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCs8pRW9QHXPaM_10int_ops_i8(i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !392 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  %1 = insertvalue { i64, i64 } poison, i64 %residual.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %residual.1, 1
  %_4.0 = extractvalue { i64, i64 } %2, 0
  %_4.1 = extractvalue { i64, i64 } %2, 1
  %3 = insertvalue { i64, i64 } poison, i64 %_4.0, 0
  %4 = insertvalue { i64, i64 } %3, i64 %_4.1, 1
  ret { i64, i64 } %4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveErrorKind>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtBN_19TryReserveErrorKindEE13from_residualCs8pRW9QHXPaM_10int_ops_i8(i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !393 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCs8pRW9QHXPaM_10int_ops_i8(i64 %residual.0, i64 %residual.1) #23
  %_4.0 = extractvalue { i64, i64 } %1, 0
  %_4.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_4.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_4.1, 1
  ret { i64, i64 } %3

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i8, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultaNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCs8pRW9QHXPaM_10int_ops_i8(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !394 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %8, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr %_1) unnamed_addr #0 !guid !395 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !396 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs8pRW9QHXPaM_10int_ops_i8(ptr align 8 %_1) #23
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<str as alloc::borrow::ToOwned>::to_owned as core::ops::function::FnOnce<(&str,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNvYeNtNtCs7CppTae75M1_5alloc6borrow7ToOwned8to_ownedINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTReEE9call_onceCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1) unnamed_addr #0 !guid !397 {
start:
  %_2 = alloca [16 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %1, ptr %2, align 8
  %3 = load ptr, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load i64, ptr %4, align 8
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCs8pRW9QHXPaM_10int_ops_i8(ptr sret([24 x i8]) align 8 %_0, ptr %3, i64 %5) #23
  ret void
}

; <usize as core::cmp::Ord>::max
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxCs8pRW9QHXPaM_10int_ops_i8(i64 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !398 {
start:
  %_7 = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %other = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store i64 %0, ptr %self, align 8
  store i64 %1, ptr %other, align 8
  store i8 0, ptr %_7, align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_7, align 1
  store i8 1, ptr %_6, align 1
  %_3.i = load i64, ptr %other, align 8
  %_4.i = load i64, ptr %self, align 8
  %_0.i = icmp ult i64 %_3.i, %_4.i
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  %2 = load i64, ptr %other, align 8
  store i64 %2, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %3 = load i64, ptr %self, align 8
  store i64 %3, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %4 = load i8, ptr %_6, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb9, label %bb5

bb5:                                              ; preds = %bb9, %bb4
  %6 = load i8, ptr %_7, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb10, label %bb6

bb9:                                              ; preds = %bb4
  br label %bb5

bb6:                                              ; preds = %bb10, %bb5
  %8 = load i64, ptr %_0, align 8
  ret i64 %8

bb10:                                             ; preds = %bb5
  br label %bb6

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; <i8 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsb_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_6Binary3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; <i8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <usize as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Octal3fmt(ptr, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #8

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshr.i8(i8, i8, i8) #10

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #11

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #8

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64, i64) unnamed_addr #12

; alloc::fmt::format::format_inner
; Function Attrs: nonlazybind uwtable
declare void @_RNvNvNtCs7CppTae75M1_5alloc3fmt6format12format_inner(ptr sret([24 x i8]) align 8, ptr, ptr) unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #9

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #9

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #9

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptosi.sat.i8.f64(double) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.smul.with.overflow.i8(i8, i8) #10

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #9

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #9

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #13

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i8(i8) #14

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #14

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctlz.i8(i8, i1 immarg) #15

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.sadd.sat.i8(i8, i8) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ssub.sat.i8(i8, i8) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.sadd.with.overflow.i8(i8, i8) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.ssub.with.overflow.i8(i8, i8) #10

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #13

; core::num::imp::int_sqrt::panic_for_negative_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8) unnamed_addr #13

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #9

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #9

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.bitreverse.i8(i8) #10

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #15

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.umul.with.overflow.i8(i8, i8) #10

; alloc::raw_vec::min_non_zero_cap
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCs7CppTae75M1_5alloc7raw_vec16min_non_zero_cap(i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #10

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #9

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #2

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #16

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #17

; __rustc::__rust_realloc
; Function Attrs: nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc14___rust_realloc(ptr allocptr, i64, i64 allocalign, i64) unnamed_addr #18

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #19

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #20

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #21

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #21

; <u8>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMs0_NtNtNtCsl10jNU3mE6R_4core3fmt3num3imph4__fmt(i8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #22 !guid !399 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs8pRW9QHXPaM_10int_ops_i8(ptr @_RNvCs8pRW9QHXPaM_10int_ops_i84main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #12 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #15 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #16 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #20 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #21 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #22 = { nonlazybind "target-cpu"="x86-64" }
attributes #23 = { inlinehint }
attributes #24 = { cold noreturn nounwind }
attributes #25 = { noreturn }
attributes #26 = { cold }
attributes #27 = { inlinehint nounwind }
attributes #28 = { noinline }
attributes #29 = { nounwind }
attributes #30 = { noinline noreturn }
attributes #31 = { noinline noreturn nounwind }

!llvm.module.flags = !{!115, !116, !117, !118}
!llvm.ident = !{!119}

!0 = !{i64 -231811119702298589}
!1 = !{i64 1627918097327993552}
!2 = !{i64 -7186227141894428387}
!3 = !{i64 -8462893436423512569}
!4 = !{i64 -8800343999439165818}
!5 = !{i64 8531762944386793634}
!6 = !{i64 -6697911405082407175}
!7 = !{i64 -5854668109723412763}
!8 = !{i64 470188573013611528}
!9 = !{i64 8418260105305744011}
!10 = !{i64 8144528984597583702}
!11 = !{i64 7505288384578794023}
!12 = !{i64 2339777916950468276}
!13 = !{i64 9200414950919056093}
!14 = !{i64 7005753805548094033}
!15 = !{i64 -2482644806863570627}
!16 = !{i64 -8270359268209314662}
!17 = !{i64 985414084263398404}
!18 = !{i64 839883819937048617}
!19 = !{i64 5598952451498884255}
!20 = !{i64 6711613617591893746}
!21 = !{i64 2284079182993286730}
!22 = !{i64 6096617137591710508}
!23 = !{i64 -4979049871268947785}
!24 = !{i64 -3766203042379901973}
!25 = !{i64 -8391964322720101965}
!26 = !{i64 6186363249997158534}
!27 = !{i64 1820177022998017088}
!28 = !{i64 7185607696991017120}
!29 = !{i64 3170344625128639015}
!30 = !{i64 5950960751232096636}
!31 = !{i64 -1292389738209633339}
!32 = !{i64 -1496993316832575839}
!33 = !{i64 -8576966275765146525}
!34 = !{i64 5485733766799181043}
!35 = !{i64 -6479823106141052439}
!36 = !{i64 -5594528194440180245}
!37 = !{i64 2916295738346066369}
!38 = !{i64 8164978157605654846}
!39 = !{i64 -5065788685522228924}
!40 = !{i64 3469734340739607060}
!41 = !{i64 6587673182149693805}
!42 = !{i64 1184349700895717062}
!43 = !{i64 2802624222130006667}
!44 = !{i64 7356151856232247018}
!45 = !{i64 6056680484323242219}
!46 = !{i64 -7906558003888994723}
!47 = !{i64 7841073497419878956}
!48 = !{i64 -1641017380257894402}
!49 = !{i64 -2768680056324341782}
!50 = !{i64 -9197026417273222571}
!51 = !{i64 -8394438581331347426}
!52 = !{i64 -5145758222876679330}
!53 = !{i64 -827604200385919708}
!54 = !{i64 -5403534295561520893}
!55 = !{i64 -4577719721541251331}
!56 = !{i64 -1864887279813365635}
!57 = !{i64 -8013207056352054987}
!58 = !{i64 5375155062528837600}
!59 = !{i64 630402870009472745}
!60 = !{i64 8259399089919715429}
!61 = !{i64 269336219948883046}
!62 = !{i64 -496086815294261008}
!63 = !{i64 6963532272489442908}
!64 = !{i64 7384178473342208474}
!65 = !{i64 -4886049999616336719}
!66 = !{i64 -2794103875600436956}
!67 = !{i64 360319405632665519}
!68 = !{i64 -5305246511456979112}
!69 = !{i64 7949337096164611390}
!70 = !{i64 1232303063052050306}
!71 = !{i64 4634894109810962607}
!72 = !{i64 1125699562285029276}
!73 = !{i64 8952173774811826314}
!74 = !{i64 3802463670269633156}
!75 = !{i64 1625366499750038956}
!76 = !{i64 3613622563516115043}
!77 = !{i64 -1711109261662215044}
!78 = !{i64 -2018257573178347867}
!79 = !{i64 -8866024751411950791}
!80 = !{i64 -6896510811643439653}
!81 = !{i64 6867694494244344612}
!82 = !{i64 1121415654624485592}
!83 = !{i64 -5028488198391436407}
!84 = !{i64 3396443473577093621}
!85 = !{i64 4725918547886087660}
!86 = !{i64 6233688453882552751}
!87 = !{i64 -8521313535087729959}
!88 = !{i64 -4411127373181430157}
!89 = !{i64 8022192359619759903}
!90 = !{i64 7115868404534871529}
!91 = !{i64 -4658513590439525295}
!92 = !{i64 -8058799006701592420}
!93 = !{i64 6902178620925438590}
!94 = !{i64 -524602085250769918}
!95 = !{i64 3486299811387936378}
!96 = !{i64 -4446915978933345016}
!97 = !{i64 -2286574493171479668}
!98 = !{i64 6345925997381864271}
!99 = !{i64 -6551228146769144036}
!100 = !{i64 -6464180414009011217}
!101 = !{i64 -6690027042761200406}
!102 = !{i64 4200867167045553950}
!103 = !{i64 8302928940902348880}
!104 = !{i64 4130859301185652538}
!105 = !{i64 -3684910825114679743}
!106 = !{i64 -6442893056743359539}
!107 = !{i64 8341520933496523343}
!108 = !{i64 2697646321136630130}
!109 = !{i64 2518671150713142056}
!110 = !{i64 -8593581145105875784}
!111 = !{i64 9123345910384790572}
!112 = !{i64 275741863242984816}
!113 = !{i64 6786581519239467311}
!114 = !{i64 3400590130564905192}
!115 = !{i32 8, !"PIC Level", i32 2}
!116 = !{i32 7, !"PIE Level", i32 2}
!117 = !{i32 2, !"RtLibUseGOT", i32 1}
!118 = !{i32 7, !"uwtable", i32 2}
!119 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!120 = !{i64 -2171397961101499022}
!121 = !{i64 -1272639083554690612}
!122 = !{i64 -1459159860621527052}
!123 = !{i64 -6640467579818502269}
!124 = !{i64 3240116972929258259}
!125 = !{i64 -2394182493768132198}
!126 = !{i64 2857663696037111760}
!127 = !{i64 -4309304959152731381}
!128 = !{i64 2943238650568865876}
!129 = !{i64 4225153140278608578}
!130 = !{i64 -3019047442724908341}
!131 = !{i64 2807302442807436542}
!132 = !{i64 2510822593209545547}
!133 = !{i64 -5074090683577570214}
!134 = !{i64 3545954463181987956}
!135 = !{i64 1249863713070727800}
!136 = !{i64 6411712447348415194}
!137 = !{i64 8398074791962234488}
!138 = !{i64 -6621187115060729338}
!139 = !{i64 2829382348910480962}
!140 = !{i64 -1018826032422589531}
!141 = !{i64 5403494602209393194}
!142 = !{i64 -2658274421440932464}
!143 = !{i64 -4000245448264364237}
!144 = !{i64 8853581885191568162}
!145 = !{i64 -1412716456301101491}
!146 = !{i64 -3342763812896783743}
!147 = !{i64 7578392872536609854}
!148 = !{i64 3306754484827253149}
!149 = !{i64 -1397141111031991345}
!150 = !{i64 2505353759612624396}
!151 = !{i64 -5825881212780223690}
!152 = !{i64 -1930856490338058150}
!153 = !{i64 -6255042845477048029}
!154 = !{i64 -3198241045774083071}
!155 = !{i64 4521346576686599454}
!156 = !{i64 -1148107190941012343}
!157 = !{i64 322686200539535245}
!158 = !{i64 -6510834879532432869}
!159 = !{i64 2030507859010221603}
!160 = !{i64 279612597940961569}
!161 = !{i64 -2510845614077365955}
!162 = !{i64 4899027182402096494}
!163 = !{i64 -3788568941359767621}
!164 = !{i64 8075538089374431073}
!165 = !{i64 -6411692031015737204}
!166 = !{i64 3670821828460970046}
!167 = !{i64 -2748263166968954541}
!168 = !{i64 -5254247796238207946}
!169 = !{i64 1602310409691658663}
!170 = !{i64 6255534964512413464}
!171 = !{i64 7403053677931697127}
!172 = !{i64 2245262053181316261}
!173 = !{i64 -5553677124016719164}
!174 = !{i64 1419560702882146867}
!175 = !{i64 1318408931290867}
!176 = !{i64 8388289925956227278}
!177 = !{i64 5767378019705201578}
!178 = !{i64 -9054313574785006218}
!179 = !{i64 8673042614193218345}
!180 = !{i64 -816025647800924406}
!181 = !{i64 5685032068278121890}
!182 = !{i64 1358125619083099474}
!183 = !{i64 4832861211784857852}
!184 = !{i64 -597921551497767964}
!185 = !{i64 -5056217860675115412}
!186 = !{i64 7545019899455347417}
!187 = !{i64 4490923069783088363}
!188 = !{i64 3531868587863529166}
!189 = !{i64 1831462202880676477}
!190 = !{i64 1187024892979646960}
!191 = !{i64 -7918674937762339878}
!192 = !{i64 2320710986171020073}
!193 = !{i64 -2359801233072225849}
!194 = !{i64 9197239541090565855}
!195 = !{i64 -5544128158307555777}
!196 = !{i64 -4197342846181166104}
!197 = !{i64 226624794215944283}
!198 = !{i64 4195243100483847287}
!199 = !{i64 2177476641349198007}
!200 = !{i64 3278903359499034659}
!201 = !{i64 2259868532719024707}
!202 = !{i64 2907029474899853371}
!203 = !{i64 -7915035406328227509}
!204 = !{i64 1488517909097051618}
!205 = !{i64 9048754610404298211}
!206 = !{i64 1116276806529228056}
!207 = !{i64 -4011269015754829179}
!208 = !{i64 8837404120423718869}
!209 = !{i64 3229347956189358893}
!210 = !{i64 2335624965543040710}
!211 = !{i64 -4261402430198146822}
!212 = !{i64 6989986041373324270}
!213 = !{i64 -4671178029838392901}
!214 = !{i64 -7160604710982458421}
!215 = !{i64 -5315576812704648233}
!216 = !{i64 9013287496805006689}
!217 = !{i64 -1138178988895417888}
!218 = !{i64 -1531165787355503763}
!219 = !{i64 -2695100759826215605}
!220 = !{i64 5171590926676293969}
!221 = !{i64 6807452228537415186}
!222 = !{i64 6190138099927234181}
!223 = !{i64 -7504409451498908113}
!224 = !{i64 4211476645378370700}
!225 = !{i64 6377729465286852223}
!226 = !{i64 6440601708825344994}
!227 = !{i64 5148347993520586858}
!228 = !{i64 6402958588178812444}
!229 = !{i64 -7127461208893851640}
!230 = !{i64 8052547678855755609}
!231 = !{i64 7465980955778393729}
!232 = !{i64 8266746065004723440}
!233 = !{i64 -7516938859283677833}
!234 = !{i64 -2622380860769826206}
!235 = !{i64 -4546711635426314026}
!236 = !{i64 -2045898418285042371}
!237 = !{i64 -6692238444980787517}
!238 = !{i64 -7320967696946510712}
!239 = !{i64 -3264188138067559793}
!240 = !{i64 8313182075827599798}
!241 = !{i64 3722284160159332515}
!242 = !{i64 -1321035894948410478}
!243 = !{i64 -3504124251327012932}
!244 = !{i64 -2300458834458803565}
!245 = !{i64 1871293304968560388}
!246 = !{i64 7957698037024026585}
!247 = !{i64 -7893698254078668254}
!248 = !{i64 2762092699941373696}
!249 = !{i64 -6104595647284024882}
!250 = !{i64 -4826078926254449590}
!251 = !{i64 -2704003914082353080}
!252 = !{i64 -8162686062253880312}
!253 = !{i64 -1891293287324743614}
!254 = !{i64 1880893238206893204}
!255 = !{i64 -6814536098414011905}
!256 = !{i64 6338972972097710330}
!257 = !{i64 6886354509706014202}
!258 = !{i64 6515105702389701249}
!259 = !{i64 6065001214935422131}
!260 = !{i64 -8472701522873913783}
!261 = !{i64 -4155004339579993972}
!262 = !{i64 -8706677508718103479}
!263 = !{i64 7291907566127711993}
!264 = !{i64 2858015780575926591}
!265 = !{i64 6480642166745255934}
!266 = !{i64 4822153089850407028}
!267 = !{i64 136500941329156373}
!268 = !{i64 2249466770569311950}
!269 = !{i64 2043987595326608168}
!270 = !{i64 2616658998946617557}
!271 = !{i64 4897324124462618876}
!272 = !{i64 -19777330486054250}
!273 = !{i64 -3017972042020934600}
!274 = !{i64 1162414936853589545}
!275 = !{i64 -281619646653401004}
!276 = !{i64 -4689116834653500994}
!277 = !{i64 7768950449906546534}
!278 = !{i64 8555887967175137478}
!279 = !{i64 6109180814000335359}
!280 = !{i64 -2235864063282844428}
!281 = !{i64 6943129083567198332}
!282 = !{i64 -8128032515911169331}
!283 = !{i64 -2932844573850839413}
!284 = !{i64 -9179048832570785720}
!285 = !{i64 6574984272298166134}
!286 = !{i64 -8194139053015262996}
!287 = !{i64 4508485235837754312}
!288 = !{i64 -2483294033825902577}
!289 = !{i64 260739515263420325}
!290 = !{i64 -1275807116667170554}
!291 = !{i64 -6783209186136442115}
!292 = !{i64 -4963911288579345089}
!293 = !{i64 6229877884846242825}
!294 = !{i64 8544864904927566355}
!295 = !{i64 630544815964399870}
!296 = !{i64 3433221593131246645}
!297 = !{i64 8464840987499702486}
!298 = !{i64 -3492270921206920239}
!299 = !{i64 4385783672195267940}
!300 = !{i64 -6047021281912630942}
!301 = !{i64 8683819143661757692}
!302 = !{i64 -7718625286968355154}
!303 = !{i64 5402872986834558414}
!304 = !{i64 2331917542114449395}
!305 = !{i64 6879008841733958405}
!306 = !{i64 1122377228817029928}
!307 = !{i64 2648270007436411699}
!308 = !{i64 -9050464301050623596}
!309 = !{i64 -4663946249522021254}
!310 = !{i64 -6359524718878828640}
!311 = !{i64 5008011369517738586}
!312 = !{i64 -3085429576920387}
!313 = !{i64 4172095555452159409}
!314 = !{i64 1172811717465447958}
!315 = !{i64 7926457433202375495}
!316 = !{i64 6791415188016683725}
!317 = !{i64 -2889893949658311124}
!318 = !{i64 5303844407798989008}
!319 = !{i64 -6873691512292224556}
!320 = !{i64 8476273667907374506}
!321 = !{i64 -7541739765477939055}
!322 = !{i64 9153567770271161350}
!323 = !{!"address", !"read_provenance"}
!324 = !{i64 245652462807287992}
!325 = !{i64 -3935072970687480874}
!326 = !{i64 9069286700986987411}
!327 = !{i64 9174001663682012663}
!328 = !{i64 -2764185823334645669}
!329 = !{i64 1442610339335519214}
!330 = !{i64 -1008308770781732775}
!331 = !{i64 4549896969320553401}
!332 = !{i64 -4601944371211567393}
!333 = !{i64 -1601254512472714336}
!334 = !{i64 2849688498837778394}
!335 = !{i64 8606052119473162118}
!336 = !{i64 2504595208785849312}
!337 = !{i64 -9220938209089895214}
!338 = !{i64 -7848698329863819841}
!339 = !{i64 3637638400887307096}
!340 = !{i64 -1865683072856102220}
!341 = !{i64 -4989470731684053591}
!342 = !{i64 -2975790002093199271}
!343 = !{i64 5408652881779205373}
!344 = !{i64 1663105432433913715}
!345 = !{i64 -4789138213117580963}
!346 = !{i64 -6804701325720926154}
!347 = !{i64 5008747724183722785}
!348 = !{i64 -6677535867801678647}
!349 = !{i64 1042935298642445623}
!350 = !{i64 8347667416410023443}
!351 = !{i64 1243081536770831016}
!352 = !{i64 -772869830968744197}
!353 = !{i64 8314126804024747783}
!354 = !{i64 -381481221403957222}
!355 = !{i64 8359262535459732484}
!356 = !{i64 9129709378789761095}
!357 = !{i64 1769267389113582600}
!358 = !{i64 -3568928923056826690}
!359 = !{i64 -631471637345165722}
!360 = !{i64 -46708901987740799}
!361 = !{i64 -8539189495985283392}
!362 = !{i64 8911925465533337715}
!363 = !{i64 -2214581443187545472}
!364 = !{i64 6046350589427145627}
!365 = !{i64 -6795124246283778834}
!366 = !{i64 -7090693261616469459}
!367 = !{i64 5686820778823211647}
!368 = !{i64 -2291488004151589649}
!369 = !{i64 68128407672385200}
!370 = !{i64 2127355910086119976}
!371 = !{i64 8827622828650830267}
!372 = !{i64 2525852360232085327}
!373 = !{i64 5621201427921371390}
!374 = !{i64 4926164966366098713}
!375 = !{i64 3562063318605835487}
!376 = !{i64 8209617229793568220}
!377 = !{i64 5467853982495736095}
!378 = !{i64 -8574817604643655918}
!379 = !{i64 5800646367850684976}
!380 = !{i64 -1053406264645486642}
!381 = !{i64 1570775129414440608}
!382 = !{i64 3062405426646626101}
!383 = !{i64 -351312941439062581}
!384 = !{i64 -9210045492078438292}
!385 = !{i64 7782993657431023336}
!386 = !{i64 1112510515337063112}
!387 = !{i64 4620013421217769012}
!388 = !{i64 -4121178364979527299}
!389 = !{i64 4808182018205978965}
!390 = !{i64 -7659456372950048338}
!391 = !{i64 -8476410474935327758}
!392 = !{i64 5366590105745480450}
!393 = !{i64 1212710644131722656}
!394 = !{i64 483868382555017973}
!395 = !{i64 5754977748173972930}
!396 = !{i64 271159050325069440}
!397 = !{i64 2364993668634895976}
!398 = !{i64 -2726036398497685569}
!399 = !{i64 -2624081020897602054}
