; ModuleID = 'panic_unwrap_err.c1e296f5c426109f-cgu.0'
source_filename = "panic_unwrap_err.c1e296f5c426109f-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsgE2QwGohQS1_16panic_unwrap_err, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsgE2QwGohQS1_16panic_unwrap_err, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsgE2QwGohQS1_16panic_unwrap_err }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_e65b6dc6463ce4bf23a4f9f7b2dff5f3 = private unnamed_addr constant [40 x i8] c"test/rust/synthetic/panic-unwrap-err.rs\00", align 1, !guid !2
@alloc_fe1afc5d8ecc17119adb21b06611b46d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e65b6dc6463ce4bf23a4f9f7b2dff5f3, [16 x i8] c"'\00\00\00\00\00\00\00\06\00\00\00*\00\00\00" }>, align 8, !guid !3
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !4
@alloc_0f5d01301fec2b0e071e102b9873766d = private unnamed_addr constant [46 x i8] c"called `Result::unwrap_err()` on an `Ok` value", align 1, !guid !5
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCsgE2QwGohQS1_16panic_unwrap_err }>, align 8, !guid !6

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsgE2QwGohQS1_16panic_unwrap_err(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !12 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<core::result::Result<u8, u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6result6ResulthhEECsgE2QwGohQS1_16panic_unwrap_err(i1 zeroext %dummy.0, i8 %dummy.1) unnamed_addr #1 !guid !13 {
start:
  %_0 = alloca [2 x i8], align 1
  %0 = zext i1 %dummy.0 to i8
  store i8 %0, ptr %_0, align 1
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %dummy.1, ptr %1, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !14
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  %5 = load i8, ptr %4, align 1
  %6 = insertvalue { i1, i8 } poison, i1 %3, 0
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1
  ret { i1, i8 } %7
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgE2QwGohQS1_16panic_unwrap_err(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !15 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsgE2QwGohQS1_16panic_unwrap_err(ptr %f) #6
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #6
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsgE2QwGohQS1_16panic_unwrap_err(ptr align 8 %_1) unnamed_addr #1 !guid !16 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgE2QwGohQS1_16panic_unwrap_err(ptr %_4) #7
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsgE2QwGohQS1_16panic_unwrap_err() #6
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsgE2QwGohQS1_16panic_unwrap_err(i8 %_2) #6
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsgE2QwGohQS1_16panic_unwrap_err(ptr %_1) unnamed_addr #1 !guid !17 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsgE2QwGohQS1_16panic_unwrap_err(ptr %0) #6
  ret i32 %_0
}

; panic_unwrap_err::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsgE2QwGohQS1_16panic_unwrap_err4main() unnamed_addr #0 !guid !18 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsgE2QwGohQS1_16panic_unwrap_err(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #6
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<core::result::Result<u8, u8>>
  %1 = call { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6result6ResulthhEECsgE2QwGohQS1_16panic_unwrap_err(i1 zeroext false, i8 1) #6
  %r.0 = extractvalue { i1, i8 } %1, 0
  %r.1 = extractvalue { i1, i8 } %1, 1
; call <core::result::Result<u8, u8>>::unwrap_err
  %_5 = call i8 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthhE10unwrap_errCsgE2QwGohQS1_16panic_unwrap_err(i1 zeroext %r.0, i8 %r.1, ptr align 8 @alloc_fe1afc5d8ecc17119adb21b06611b46d) #6
; call <core::fmt::Arguments>::from_str
  %2 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsgE2QwGohQS1_16panic_unwrap_err(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #6
  %_7.0 = extractvalue { ptr, ptr } %2, 0
  %_7.1 = extractvalue { ptr, ptr } %2, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_7.0, ptr %_7.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsgE2QwGohQS1_16panic_unwrap_err(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !19 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::result::Result<u8, u8>>::unwrap_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthhE10unwrap_errCsgE2QwGohQS1_16panic_unwrap_err(i1 zeroext %0, i8 %1, ptr align 8 %2) unnamed_addr #1 personality ptr @rust_eh_personality !guid !20 {
start:
  %t = alloca [1 x i8], align 1
  %self = alloca [2 x i8], align 1
  %3 = zext i1 %0 to i8
  store i8 %3, ptr %self, align 1
  %4 = getelementptr inbounds i8, ptr %self, i64 1
  store i8 %1, ptr %4, align 1
  %5 = load i8, ptr %self, align 1
  %6 = trunc nuw i8 %5 to i1
  %7 = getelementptr inbounds i8, ptr %self, i64 1
  %8 = load i8, ptr %7, align 1
  %_2 = zext i1 %6 to i64
  %9 = trunc nuw i64 %_2 to i1
  br i1 %9, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %10 = getelementptr inbounds i8, ptr %self, i64 1
  %e = load i8, ptr %10, align 1
  ret i8 %e

bb3:                                              ; preds = %start
  %11 = getelementptr inbounds i8, ptr %self, i64 1
  %12 = load i8, ptr %11, align 1
  store i8 %12, ptr %t, align 1
; call core::result::unwrap_failed
  call void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr @alloc_0f5d01301fec2b0e071e102b9873766d, i64 46, ptr %t, ptr align 8 @vtable.1, ptr align 8 %2) #8
  unreachable

bb1:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsgE2QwGohQS1_16panic_unwrap_err(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !21 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsgE2QwGohQS1_16panic_unwrap_err(ptr %s.0, i64 %s.1) #6
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsgE2QwGohQS1_16panic_unwrap_err(ptr %self) unnamed_addr #1 !guid !22 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsgE2QwGohQS1_16panic_unwrap_err(i8 %0) unnamed_addr #1 !guid !23 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsgE2QwGohQS1_16panic_unwrap_err(ptr %self) #6
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsgE2QwGohQS1_16panic_unwrap_err() unnamed_addr #1 !guid !24 {
start:
  ret i8 0
}

; <u8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCsgE2QwGohQS1_16panic_unwrap_err(ptr %self, ptr align 8 %f) unnamed_addr #1 !guid !25 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsgE2QwGohQS1_16panic_unwrap_err(ptr %_1) unnamed_addr #1 !guid !26 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsgE2QwGohQS1_16panic_unwrap_err(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !27 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsgE2QwGohQS1_16panic_unwrap_err(ptr align 8 %_1) #6
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #4

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #0

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #0

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #0

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #0

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #0

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #5 !guid !28 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsgE2QwGohQS1_16panic_unwrap_err(ptr @_RNvCsgE2QwGohQS1_16panic_unwrap_err4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nonlazybind "target-cpu"="x86-64" }
attributes #6 = { inlinehint }
attributes #7 = { noinline }
attributes #8 = { noinline noreturn }

!llvm.module.flags = !{!7, !8, !9, !10}
!llvm.ident = !{!11}

!0 = !{i64 -8748400582117598542}
!1 = !{i64 -5761029608799939078}
!2 = !{i64 -3555690223952829096}
!3 = !{i64 5007643665639443893}
!4 = !{i64 -3848904406119306173}
!5 = !{i64 -4912015952178322150}
!6 = !{i64 -7206515510359573299}
!7 = !{i32 8, !"PIC Level", i32 2}
!8 = !{i32 7, !"PIE Level", i32 2}
!9 = !{i32 2, !"RtLibUseGOT", i32 1}
!10 = !{i32 7, !"uwtable", i32 2}
!11 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!12 = !{i64 -8851353903741139734}
!13 = !{i64 -5127361874561936590}
!14 = !{i64 1312812588902876}
!15 = !{i64 1425974995482618680}
!16 = !{i64 -1934894502358790907}
!17 = !{i64 -3082704971848672302}
!18 = !{i64 -2326831826315444043}
!19 = !{i64 4631218365652389884}
!20 = !{i64 -8991793004067739808}
!21 = !{i64 6083175263584250214}
!22 = !{i64 7724116114168579467}
!23 = !{i64 -5405668555393519402}
!24 = !{i64 4971974731386873129}
!25 = !{i64 -188400257755439176}
!26 = !{i64 -7496476086626698519}
!27 = !{i64 -6133085631836879037}
!28 = !{i64 -2624081020897602054}
