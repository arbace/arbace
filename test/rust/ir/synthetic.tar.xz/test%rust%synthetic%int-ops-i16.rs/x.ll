; ModuleID = 'int_ops_i16.fa342ed86476691a-cgu.0'
source_filename = "int_ops_i16.fa342ed86476691a-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsltPpk0pe160_11int_ops_i16, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsltPpk0pe160_11int_ops_i16, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsltPpk0pe160_11int_ops_i16 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !3
@alloc_2a0c668b6eef71bc54eb7bdc85420a17 = private unnamed_addr constant [4 x i8] c"\10\00\00\00", align 4, !guid !4
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !5
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !7
@alloc_b27528dd1d1dc03703c10f3b1b973fb1 = private unnamed_addr constant [35 x i8] c"test/rust/synthetic/int-ops-i16.rs\00", align 1, !guid !8
@alloc_8128986e3d00944dc45ceb03e82071c7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b27528dd1d1dc03703c10f3b1b973fb1, [16 x i8] c"\22\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !9
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !10
@alloc_5c751d0c82277bf41e7c0776ab4ec5f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b27528dd1d1dc03703c10f3b1b973fb1, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !11
@alloc_e71b339731a4e22212fd5857983819f6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b27528dd1d1dc03703c10f3b1b973fb1, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !12
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !13
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !14
@alloc_7b7cc07e20ab20ae0e8bd02d871ba4a6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b27528dd1d1dc03703c10f3b1b973fb1, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\00\1B\00\00\00" }>, align 8, !guid !15
@alloc_04307af443809ae18a3edf079cbe4d42 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b27528dd1d1dc03703c10f3b1b973fb1, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !16
@alloc_8a4e3ec4a754bafdf198788b06de15cf = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b27528dd1d1dc03703c10f3b1b973fb1, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !17
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !18
@alloc_54423fc5084848be87cba9c0c02cc867 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b27528dd1d1dc03703c10f3b1b973fb1, [16 x i8] c"\22\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !19
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !20
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !21
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !22
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !23
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !24
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !25
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !26
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !27
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !28
@alloc_e6bfe4544d0990c68f8aeca813730e73 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\D2\04\00\00\05\00\00\00" }>, align 8, !guid !29
@alloc_49ab7e7c421882b397e0500c1648bb06 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\94\01\00\00\05\00\00\00" }>, align 8, !guid !30
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !31
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !32
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !33
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !34
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !35
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !36
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !37
@anon.421479f5fa7fa7140547dc2779d71c6c.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !38
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !39
@alloc_dd07830ff498a5ad3af27fc9310868e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E5\00\00\00\12\00\00\00" }>, align 8, !guid !40
@alloc_73a63def61abd19c5b285b7e5bba6f74 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E6\00\00\00\05\00\00\00" }>, align 8, !guid !41
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !42
@alloc_d7d2674a3c536086aba62154183f0b5b = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u16::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !43
@alloc_e1a24811cdb375c477cf3d451bcd3796 = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: i16::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !44
@alloc_e65ffe7b88dc1d61e3cfb242ac596984 = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: i16::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !45
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !46
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRsNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !47
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsltPpk0pe160_11int_ops_i16 }>, align 8, !guid !48
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !49
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !50
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !51
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !52
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !53
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !54
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !55
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsltPpk0pe160_11int_ops_i16 }>, align 8, !guid !56

; <str>::parse::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsesECsltPpk0pe160_11int_ops_i16(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !62 {
start:
  %0 = alloca [4 x i8], align 4
  %_0 = alloca [4 x i8], align 2
; call <i16 as core::str::traits::FromStr>::from_str
  %1 = call i32 @_RNvXsm_NtCsl10jNU3mE6R_4core3numsNtNtNtB7_3str6traits7FromStr8from_strCsltPpk0pe160_11int_ops_i16(ptr %self.0, i64 %self.1) #17
  store i32 %1, ptr %0, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %_0, ptr align 4 %0, i64 4, i1 false)
  %2 = load i32, ptr %_0, align 2
  ret i32 %2
}

; <core::fmt::rt::Argument>::new_binary::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !63 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i16>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %x) #17
; call <core::ptr::non_null::NonNull<i16>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsj_NtNtCsl10jNU3mE6R_4core3fmt3numsNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !64 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsltPpk0pe160_11int_ops_i16(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !65 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !66 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 4 %x) #17
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !67 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i16>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %x) #17
; call <core::ptr::non_null::NonNull<i16>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexsECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !68 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i16>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %x) #17
; call <core::ptr::non_null::NonNull<i16>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsn_NtNtCsl10jNU3mE6R_4core3fmt3numsNtB7_8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexsECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !69 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i16>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %x) #17
; call <core::ptr::non_null::NonNull<i16>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsp_NtNtCsl10jNU3mE6R_4core3fmt3numsNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i16>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionsEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !70 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i16>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionsEE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %x) #17
; call <core::ptr::non_null::NonNull<core::option::Option<i16>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionsEE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionsENtNtB7_3fmt5Debug3fmtCsltPpk0pe160_11int_ops_i16, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i16, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultsNtNtNtB7_3num5error13ParseIntErrorEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !71 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i16, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultsNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %x) #17
; call <core::ptr::non_null::NonNull<core::result::Result<i16, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultsNtNtNtBa_3num5error13ParseIntErrorEE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultsNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsltPpk0pe160_11int_ops_i16, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(i16, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTsbEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !72 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(i16, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTsbEE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %x) #17
; call <core::ptr::non_null::NonNull<(i16, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTsbEE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTsbENtB6_5Debug3fmtCsltPpk0pe160_11int_ops_i16, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !73 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsltPpk0pe160_11int_ops_i16(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsltPpk0pe160_11int_ops_i16, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalsECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !74 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i16>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %x) #17
; call <core::ptr::non_null::NonNull<i16>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsltPpk0pe160_11int_ops_i16(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsl_NtNtCsl10jNU3mE6R_4core3fmt3numsNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::option::Option<i16>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionsEE4castuECsltPpk0pe160_11int_ops_i16(ptr %self) unnamed_addr #0 !guid !75 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i16, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultsNtNtNtBa_3num5error13ParseIntErrorEE4castuECsltPpk0pe160_11int_ops_i16(ptr %self) unnamed_addr #0 !guid !76 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<(i16, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTsbEE4castuECsltPpk0pe160_11int_ops_i16(ptr %self) unnamed_addr #0 !guid !77 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsltPpk0pe160_11int_ops_i16(ptr %self) unnamed_addr #0 !guid !78 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsltPpk0pe160_11int_ops_i16(ptr %self) unnamed_addr #0 !guid !79 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsltPpk0pe160_11int_ops_i16(ptr %self) unnamed_addr #0 !guid !80 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i16>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECsltPpk0pe160_11int_ops_i16(ptr %self) unnamed_addr #0 !guid !81 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsltPpk0pe160_11int_ops_i16(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !82 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsltPpk0pe160_11int_ops_i16(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !83 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsltPpk0pe160_11int_ops_i16(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !84 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsltPpk0pe160_11int_ops_i16(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !85 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u16>
; Function Attrs: nounwind nonlazybind uwtable
define internal i16 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefttECsltPpk0pe160_11int_ops_i16(i16 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !86 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 2 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i16
  %_0 = call i16 @llvm.fshl.i16(i16 %x, i16 %x, i16 %1)
  ret i16 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u16>
; Function Attrs: nounwind nonlazybind uwtable
define internal i16 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righttECsltPpk0pe160_11int_ops_i16(i16 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !87 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 2 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i16
  %_0 = call i16 @llvm.fshr.i16(i16 %x, i16 %x, i16 %1)
  ret i16 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsltPpk0pe160_11int_ops_i16(i32 %dummy) unnamed_addr #0 !guid !88 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !89
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsltPpk0pe160_11int_ops_i16(i32 %dummy) unnamed_addr #0 !guid !90 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !89
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxsECsltPpk0pe160_11int_ops_i16(i16 %dummy) unnamed_addr #0 !guid !91 {
start:
  %_0 = alloca [2 x i8], align 2
  store i16 %dummy, ptr %_0, align 2
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !89
  %0 = load i16, ptr %_0, align 2
  ret i16 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsltPpk0pe160_11int_ops_i16(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !92 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsltPpk0pe160_11int_ops_i16(ptr %f) #17
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #17
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsltPpk0pe160_11int_ops_i16(ptr align 8 %_1) unnamed_addr #0 !guid !93 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsltPpk0pe160_11int_ops_i16(ptr %_4) #20
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsltPpk0pe160_11int_ops_i16() #17
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsltPpk0pe160_11int_ops_i16(i8 %_2) #17
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsltPpk0pe160_11int_ops_i16(ptr %_1) unnamed_addr #0 !guid !94 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsltPpk0pe160_11int_ops_i16(ptr %0) #17
  ret i32 %_0
}

; int_ops_i16::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsltPpk0pe160_11int_ops_i164main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !95 {
start:
  %0 = alloca [16 x i8], align 8
  %1 = alloca [4 x i8], align 4
  %2 = alloca [4 x i8], align 4
  %_294 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_284 = alloca [24 x i8], align 8
  %_283 = alloca [24 x i8], align 8
  %_279 = alloca [24 x i8], align 8
  %_276 = alloca [8 x i8], align 8
  %_269 = alloca [16 x i8], align 8
  %_268 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_264 = alloca [4 x i8], align 4
  %_262 = alloca [2 x i8], align 2
  %_255 = alloca [16 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_252 = alloca [4 x i8], align 4
  %_250 = alloca [4 x i8], align 4
  %_243 = alloca [16 x i8], align 8
  %_242 = alloca [16 x i8], align 8
  %_241 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_239 = alloca [8 x i8], align 8
  %_237 = alloca [4 x i8], align 4
  %_233 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_226 = alloca [16 x i8], align 8
  %_225 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_222 = alloca [4 x i8], align 2
  %_220 = alloca [1 x i8], align 1
  %_216 = alloca [4 x i8], align 2
  %_209 = alloca [16 x i8], align 8
  %_208 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_206 = alloca [2 x i8], align 2
  %_203 = alloca [2 x i8], align 2
  %_196 = alloca [16 x i8], align 8
  %_195 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_193 = alloca [4 x i8], align 2
  %_190 = alloca [4 x i8], align 2
  %_183 = alloca [16 x i8], align 8
  %_182 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_176 = alloca [2 x i8], align 2
  %_170 = alloca [2 x i8], align 2
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [2 x i8], align 2
  %_156 = alloca [2 x i8], align 2
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [2 x i8], align 2
  %_144 = alloca [2 x i8], align 2
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [2 x i8], align 2
  %_130 = alloca [2 x i8], align 2
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [4 x i8], align 2
  %_98 = alloca [4 x i8], align 2
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [2 x i8], align 2
  %_86 = alloca [2 x i8], align 2
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [2 x i8], align 2
  %_74 = alloca [2 x i8], align 2
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [2 x i8], align 2
  %_62 = alloca [2 x i8], align 2
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [4 x i8], align 2
  %_50 = alloca [4 x i8], align 2
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [4 x i8], align 2
  %_38 = alloca [4 x i8], align 2
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [2 x i8], align 2
  %min = alloca [2 x i8], align 2
; call core::hint::black_box::<i16>
  %_4 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxsECsltPpk0pe160_11int_ops_i16(i16 -32768) #17
; call core::hint::black_box::<i16>
  %_5 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxsECsltPpk0pe160_11int_ops_i16(i16 32767) #17
  store i16 %_4, ptr %min, align 2
  store i16 %_5, ptr %max, align 2
; call core::hint::black_box::<i16>
  %one = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxsECsltPpk0pe160_11int_ops_i16(i16 1) #17
; call core::hint::black_box::<i16>
  %three = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxsECsltPpk0pe160_11int_ops_i16(i16 3) #17
  store ptr %min, ptr %args, align 8
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_2a0c668b6eef71bc54eb7bdc85420a17, ptr %4, align 8
  %_297 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_15, ptr align 2 %_297) #17
  %5 = getelementptr inbounds i8, ptr %args, i64 8
  %_298 = load ptr, ptr %5, align 8
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_16, ptr align 2 %_298) #17
  %6 = getelementptr inbounds i8, ptr %args, i64 16
  %_299 = load ptr, ptr %6, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_299) #17
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_15, i64 16, i1 false)
  %8 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %8, ptr align 8 %_16, i64 16, i1 false)
  %9 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %10 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsltPpk0pe160_11int_ops_i16(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #17
  %_9.0 = extractvalue { ptr, ptr } %10, 0
  %_9.1 = extractvalue { ptr, ptr } %10, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %13, align 8
  %_300 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexsECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_28, ptr align 2 %_300) #17
  %14 = getelementptr inbounds i8, ptr %args2, i64 8
  %_301 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_binary::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binarysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_29, ptr align 2 %_301) #17
  %15 = getelementptr inbounds i8, ptr %args2, i64 16
  %_302 = load ptr, ptr %15, align 8
; call <core::fmt::rt::Argument>::new_octal::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalsECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_30, ptr align 2 %_302) #17
  %16 = getelementptr inbounds i8, ptr %args2, i64 24
  %_303 = load ptr, ptr %16, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexsECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_31, ptr align 2 %_303) #17
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_28, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_29, i64 16, i1 false)
  %19 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %19, ptr align 8 %_30, i64 16, i1 false)
  %20 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %21 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsltPpk0pe160_11int_ops_i16(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #17
  %_21.0 = extractvalue { ptr, ptr } %21, 0
  %_21.1 = extractvalue { ptr, ptr } %21, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %22 = load i16, ptr %max, align 2
; call <i16>::checked_add
  %23 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_addCsltPpk0pe160_11int_ops_i16(i16 %22, i16 %one) #17
  %24 = extractvalue { i16, i16 } %23, 0
  %25 = extractvalue { i16, i16 } %23, 1
  store i16 %24, ptr %_38, align 2
  %26 = getelementptr inbounds i8, ptr %_38, i64 2
  store i16 %25, ptr %26, align 2
  %27 = load i16, ptr %min, align 2
; call <i16>::checked_add
  %28 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_addCsltPpk0pe160_11int_ops_i16(i16 %27, i16 %one) #17
  %29 = extractvalue { i16, i16 } %28, 0
  %30 = extractvalue { i16, i16 } %28, 1
  store i16 %29, ptr %_40, align 2
  %31 = getelementptr inbounds i8, ptr %_40, i64 2
  store i16 %30, ptr %31, align 2
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i16>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionsEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_42, ptr align 2 %_38) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i16>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionsEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_43, ptr align 2 %_40) #17
  %32 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %_42, i64 16, i1 false)
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %34 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #17
  %_35.0 = extractvalue { ptr, ptr } %34, 0
  %_35.1 = extractvalue { ptr, ptr } %34, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %35 = load i16, ptr %max, align 2
  %36 = call { i16, i1 } @llvm.sadd.with.overflow.i16(i16 %35, i16 %one)
  %_5.0.i = extractvalue { i16, i1 } %36, 0
  %_5.1.i = extractvalue { i16, i1 } %36, 1
  %37 = extractvalue { i16, i1 } %36, 0
  %38 = extractvalue { i16, i1 } %36, 1
  store i16 %37, ptr %_50, align 2
  %39 = getelementptr inbounds i8, ptr %_50, i64 2
  %40 = zext i1 %38 to i8
  store i8 %40, ptr %39, align 2
  %41 = load i16, ptr %min, align 2
  %42 = call { i16, i1 } @llvm.ssub.with.overflow.i16(i16 %41, i16 %one)
  %_5.0.i52 = extractvalue { i16, i1 } %42, 0
  %_5.1.i53 = extractvalue { i16, i1 } %42, 1
  %43 = extractvalue { i16, i1 } %42, 0
  %44 = extractvalue { i16, i1 } %42, 1
  store i16 %43, ptr %_52, align 2
  %45 = getelementptr inbounds i8, ptr %_52, i64 2
  %46 = zext i1 %44 to i8
  store i8 %46, ptr %45, align 2
; call <core::fmt::rt::Argument>::new_debug::<(i16, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTsbEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_54, ptr align 2 %_50) #17
; call <core::fmt::rt::Argument>::new_debug::<(i16, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTsbEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_55, ptr align 2 %_52) #17
  %47 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %47, ptr align 8 %_54, i64 16, i1 false)
  %48 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %48, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %49 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #17
  %_47.0 = extractvalue { ptr, ptr } %49, 0
  %_47.1 = extractvalue { ptr, ptr } %49, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %50 = load i16, ptr %max, align 2
  %_0.i = add i16 %50, %one
  store i16 %_0.i, ptr %_62, align 2
  %51 = load i16, ptr %min, align 2
  %_0.i41 = sub i16 %51, %one
  store i16 %_0.i41, ptr %_64, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_66, ptr align 2 %_62) #17
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_67, ptr align 2 %_64) #17
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_66, i64 16, i1 false)
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %54 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #17
  %_59.0 = extractvalue { ptr, ptr } %54, 0
  %_59.1 = extractvalue { ptr, ptr } %54, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %55 = load i16, ptr %max, align 2
  %_0.i48 = call i16 @llvm.sadd.sat.i16(i16 %55, i16 %three)
  store i16 %_0.i48, ptr %_74, align 2
  %56 = load i16, ptr %min, align 2
  %_0.i49 = call i16 @llvm.ssub.sat.i16(i16 %56, i16 %three)
  store i16 %_0.i49, ptr %_76, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_78, ptr align 2 %_74) #17
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_79, ptr align 2 %_76) #17
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_78, i64 16, i1 false)
  %58 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %58, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %59 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #17
  %_71.0 = extractvalue { ptr, ptr } %59, 0
  %_71.1 = extractvalue { ptr, ptr } %59, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %60 = load i16, ptr %max, align 2
  %_0.i37 = mul i16 %60, %three
  store i16 %_0.i37, ptr %_86, align 2
  %61 = load i16, ptr %max, align 2
  %62 = load i16, ptr %max, align 2
  %_0.i36 = mul i16 %61, %62
  store i16 %_0.i36, ptr %_88, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_90, ptr align 2 %_86) #17
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_91, ptr align 2 %_88) #17
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_90, i64 16, i1 false)
  %64 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %64, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %65 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #17
  %_83.0 = extractvalue { ptr, ptr } %65, 0
  %_83.1 = extractvalue { ptr, ptr } %65, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %66 = load i16, ptr %max, align 2
; call <i16>::checked_mul
  %67 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_mulCsltPpk0pe160_11int_ops_i16(i16 %66, i16 %three) #17
  %68 = extractvalue { i16, i16 } %67, 0
  %69 = extractvalue { i16, i16 } %67, 1
  store i16 %68, ptr %_98, align 2
  %70 = getelementptr inbounds i8, ptr %_98, i64 2
  store i16 %69, ptr %70, align 2
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsltPpk0pe160_11int_ops_i16(i32 5) #17
; call <i16>::checked_pow
  %71 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_powCsltPpk0pe160_11int_ops_i16(i16 %three, i32 %_101) #17
  %72 = extractvalue { i16, i16 } %71, 0
  %73 = extractvalue { i16, i16 } %71, 1
  store i16 %72, ptr %_100, align 2
  %74 = getelementptr inbounds i8, ptr %_100, i64 2
  store i16 %73, ptr %74, align 2
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i16>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionsEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_103, ptr align 2 %_98) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i16>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionsEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_104, ptr align 2 %_100) #17
  %75 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %75, ptr align 8 %_103, i64 16, i1 false)
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %77 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #17
  %_95.0 = extractvalue { ptr, ptr } %77, 0
  %_95.1 = extractvalue { ptr, ptr } %77, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %78 = load i16, ptr %max, align 2
  %79 = call i16 @llvm.ctpop.i16(i16 %78)
  %_0.i.i = zext i16 %79 to i32
  store i32 %_0.i.i, ptr %_111, align 4
  %80 = load i16, ptr %max, align 2
  %81 = call i16 @llvm.ctlz.i16(i16 %80, i1 false)
  %_0.i.i42 = zext i16 %81 to i32
  store i32 %_0.i.i42, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsltPpk0pe160_11int_ops_i16(i32 3) #17
  %_119 = icmp ult i32 %_117, 16
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %82 = and i32 %_117, 15
  %83 = trunc i32 %82 to i16
  %_116 = shl i16 %one, %83
  %84 = call i16 @llvm.cttz.i16(i16 %_116, i1 false)
  %_0.i.i51 = zext i16 %84 to i32
  store i32 %_0.i.i51, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %85 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %85, align 8
  %86 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %86, align 8
  %_316 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_316) #17
  %87 = getelementptr inbounds i8, ptr %args10, i64 8
  %_317 = load ptr, ptr %87, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_317) #17
  %88 = getelementptr inbounds i8, ptr %args10, i64 16
  %_318 = load ptr, ptr %88, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_318) #17
  %89 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %89, ptr align 8 %_121, i64 16, i1 false)
  %90 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %90, ptr align 8 %_122, i64 16, i1 false)
  %91 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %91, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %92 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsltPpk0pe160_11int_ops_i16(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #17
  %_108.0 = extractvalue { ptr, ptr } %92, 0
  %_108.1 = extractvalue { ptr, ptr } %92, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsltPpk0pe160_11int_ops_i16(i32 5) #17
  %93 = load i16, ptr %max, align 2
; call core::intrinsics::rotate_left::<u16>
  %_0.i.i33 = call i16 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefttECsltPpk0pe160_11int_ops_i16(i16 %93, i32 %_131) #21
  store i16 %_0.i.i33, ptr %_130, align 2
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsltPpk0pe160_11int_ops_i16(i32 7) #17
  %94 = load i16, ptr %min, align 2
; call core::intrinsics::rotate_right::<u16>
  %_0.i.i35 = call i16 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righttECsltPpk0pe160_11int_ops_i16(i16 %94, i32 %_134) #21
  store i16 %_0.i.i35, ptr %_133, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_136, ptr align 2 %_130) #17
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_137, ptr align 2 %_133) #17
  %95 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %95, ptr align 8 %_136, i64 16, i1 false)
  %96 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %96, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %97 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #17
  %_127.0 = extractvalue { ptr, ptr } %97, 0
  %_127.1 = extractvalue { ptr, ptr } %97, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %98 = load i16, ptr %max, align 2
  %_0.i.i32 = call i16 @llvm.bswap.i16(i16 %98)
  store i16 %_0.i.i32, ptr %_144, align 2
  %99 = load i16, ptr %max, align 2
  %_0.i.i34 = call i16 @llvm.bitreverse.i16(i16 %99)
  store i16 %_0.i.i34, ptr %_146, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_148, ptr align 2 %_144) #17
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_149, ptr align 2 %_146) #17
  %100 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %100, ptr align 8 %_148, i64 16, i1 false)
  %101 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %101, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %102 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #17
  %_141.0 = extractvalue { ptr, ptr } %102, 0
  %_141.1 = extractvalue { ptr, ptr } %102, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsltPpk0pe160_11int_ops_i16(i32 70) #17
  %103 = load i16, ptr %max, align 2
  %_3.i = and i32 %_157, 15
; call core::ub_checks::check_language_ub
  %_3.i43 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_3.i43, label %bb2.i, label %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <i16>::unchecked_shl::precondition_check
  call void @_RNvNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl18precondition_checkCsltPpk0pe160_11int_ops_i16(i32 %_3.i, ptr align 8 @alloc_49ab7e7c421882b397e0500c1648bb06) #22
  br label %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit

_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %104 = trunc nuw i32 %_3.i to i16
  %_0.i44 = shl i16 %103, %104
  store i16 %_0.i44, ptr %_156, align 2
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsltPpk0pe160_11int_ops_i16(i32 66) #17
  %105 = load i16, ptr %min, align 2
  %_3.i39 = and i32 %_160, 15
; call core::ub_checks::check_language_ub
  %_3.i45 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_3.i45, label %bb2.i47, label %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shr.exit

bb2.i47:                                          ; preds = %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit
; call <i16>::unchecked_shr::precondition_check
  call void @_RNvNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shr18precondition_checkCsltPpk0pe160_11int_ops_i16(i32 %_3.i39, ptr align 8 @alloc_49ab7e7c421882b397e0500c1648bb06) #22
  br label %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shr.exit

_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shr.exit: ; preds = %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit, %bb2.i47
  %106 = trunc nuw i32 %_3.i39 to i16
  %_0.i46 = ashr i16 %105, %106
  store i16 %_0.i46, ptr %_159, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_162, ptr align 2 %_156) #17
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_163, ptr align 2 %_159) #17
  %107 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_162, i64 16, i1 false)
  %108 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %108, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %109 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #17
  %_153.0 = extractvalue { ptr, ptr } %109, 0
  %_153.1 = extractvalue { ptr, ptr } %109, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i16 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_8128986e3d00944dc45ceb03e82071c7) #23
  unreachable

bb85:                                             ; preds = %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shr.exit
  %_172 = icmp eq i16 %three, -1
  %110 = load i16, ptr %max, align 2
  %_173 = icmp eq i16 %110, -32768
  %_174 = and i1 %_172, %_173
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_5c751d0c82277bf41e7c0776ab4ec5f7) #23
  unreachable

bb86:                                             ; preds = %bb85
  %111 = load i16, ptr %max, align 2
  %112 = sdiv i16 %111, %three
  store i16 %112, ptr %_170, align 2
  %_177 = icmp eq i16 %three, 0
  br i1 %_177, label %panic27, label %bb87

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_5c751d0c82277bf41e7c0776ab4ec5f7) #23
  unreachable

bb87:                                             ; preds = %bb86
  %_178 = icmp eq i16 %three, -1
  %113 = load i16, ptr %max, align 2
  %_179 = icmp eq i16 %113, -32768
  %_180 = and i1 %_178, %_179
  br i1 %_180, label %panic28, label %bb88

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_e71b339731a4e22212fd5857983819f6) #23
  unreachable

bb88:                                             ; preds = %bb87
  %114 = load i16, ptr %max, align 2
  %115 = srem i16 %114, %three
  store i16 %115, ptr %_176, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_182, ptr align 2 %_170) #17
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_183, ptr align 2 %_176) #17
  %116 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %116, ptr align 8 %_182, i64 16, i1 false)
  %117 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %117, ptr align 8 %_183, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %118 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #17
  %_167.0 = extractvalue { ptr, ptr } %118, 0
  %_167.1 = extractvalue { ptr, ptr } %118, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<i16>
  %_191 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxsECsltPpk0pe160_11int_ops_i16(i16 0) #17
  %119 = load i16, ptr %max, align 2
; call <i16>::checked_div
  %120 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_divCsltPpk0pe160_11int_ops_i16(i16 %119, i16 %_191) #17
  %121 = extractvalue { i16, i16 } %120, 0
  %122 = extractvalue { i16, i16 } %120, 1
  store i16 %121, ptr %_190, align 2
  %123 = getelementptr inbounds i8, ptr %_190, i64 2
  store i16 %122, ptr %123, align 2
  %124 = load i16, ptr %max, align 2
; call <i16>::checked_rem
  %125 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_remCsltPpk0pe160_11int_ops_i16(i16 %124, i16 %three) #17
  %126 = extractvalue { i16, i16 } %125, 0
  %127 = extractvalue { i16, i16 } %125, 1
  store i16 %126, ptr %_193, align 2
  %128 = getelementptr inbounds i8, ptr %_193, i64 2
  store i16 %127, ptr %128, align 2
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i16>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionsEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_195, ptr align 2 %_190) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i16>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionsEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_196, ptr align 2 %_193) #17
  %129 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %129, ptr align 8 %_195, i64 16, i1 false)
  %130 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %130, ptr align 8 %_196, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %131 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #17
  %_187.0 = extractvalue { ptr, ptr } %131, 0
  %_187.1 = extractvalue { ptr, ptr } %131, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_187.0, ptr %_187.1)
; call core::hint::black_box::<u32>
  %_204 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsltPpk0pe160_11int_ops_i16(i32 4) #17
; call <i16>::pow
  %132 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums3powCsltPpk0pe160_11int_ops_i16(i16 %three, i32 %_204) #17
  store i16 %132, ptr %_203, align 2
  %133 = load i16, ptr %max, align 2
  %134 = load i16, ptr %min, align 2
; call <i16>::abs_diff
  %135 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums8abs_diffCsltPpk0pe160_11int_ops_i16(i16 %133, i16 %134) #17
  store i16 %135, ptr %_206, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_208, ptr align 2 %_203) #17
; call <core::fmt::rt::Argument>::new_display::<u16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaytEB7_(ptr sret([16 x i8]) align 8 %_209, ptr align 2 %_206) #17
  %136 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %136, ptr align 8 %_208, i64 16, i1 false)
  %137 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %137, ptr align 8 %_209, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %138 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #17
  %_200.0 = extractvalue { ptr, ptr } %138, 0
  %_200.1 = extractvalue { ptr, ptr } %138, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_200.0, ptr %_200.1)
; call core::hint::black_box::<u32>
  %_218 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsltPpk0pe160_11int_ops_i16(i32 7) #17
; call <i16>::from_str_radix
  %139 = call i32 @_RNvMsn_NtCsl10jNU3mE6R_4core3nums14from_str_radixCsltPpk0pe160_11int_ops_i16(ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_218) #17
  store i32 %139, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %_216, ptr align 4 %2, i64 4, i1 false)
; call <str>::parse::<i16>
  %140 = call i32 @_RINvMNtCsl10jNU3mE6R_4core3stre5parsesECsltPpk0pe160_11int_ops_i16(ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #17
  store i32 %140, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %_222, ptr align 4 %1, i64 4, i1 false)
; call <core::result::Result<i16, core::num::error::ParseIntError>>::is_ok
  %141 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultsNtNtNtB4_3num5error13ParseIntErrorE5is_okCsltPpk0pe160_11int_ops_i16(ptr align 2 %_222) #17
  %142 = zext i1 %141 to i8
  store i8 %142, ptr %_220, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i16, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultsNtNtNtB7_3num5error13ParseIntErrorEECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_225, ptr align 2 %_216) #17
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_226, ptr %_220) #17
  %143 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %143, ptr align 8 %_225, i64 16, i1 false)
  %144 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %144, ptr align 8 %_226, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %145 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #17
  %_213.0 = extractvalue { ptr, ptr } %145, 0
  %_213.1 = extractvalue { ptr, ptr } %145, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_213.0, ptr %_213.1)
  %146 = load i16, ptr %max, align 2
  %_235 = sitofp i16 %146 to double
  %_234 = call i16 @llvm.fptosi.sat.i16.f64(double %_235)
  %147 = load i16, ptr %max, align 2
  %148 = icmp eq i16 %_234, %147
  %149 = zext i1 %148 to i8
  store i8 %149, ptr %_233, align 1
  %150 = load i16, ptr %max, align 2
  %151 = sitofp i16 %150 to float
  store float %151, ptr %_237, align 4
  %152 = load i16, ptr %min, align 2
  %153 = sitofp i16 %152 to double
  store double %153, ptr %_239, align 8
  store ptr %_233, ptr %args19, align 8
  %154 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_237, ptr %154, align 8
  %155 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_239, ptr %155, align 8
  %_333 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_241, ptr %_333) #17
  %156 = getelementptr inbounds i8, ptr %args19, i64 8
  %_334 = load ptr, ptr %156, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_242, ptr align 4 %_334) #17
  %157 = getelementptr inbounds i8, ptr %args19, i64 16
  %_335 = load ptr, ptr %157, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_243, ptr align 8 %_335) #17
  %158 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %158, ptr align 8 %_241, i64 16, i1 false)
  %159 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %159, ptr align 8 %_242, i64 16, i1 false)
  %160 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %160, ptr align 8 %_243, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %161 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsltPpk0pe160_11int_ops_i16(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #17
  %_230.0 = extractvalue { ptr, ptr } %161, 0
  %_230.1 = extractvalue { ptr, ptr } %161, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_230.0, ptr %_230.1)
  %162 = load i16, ptr %max, align 2
  %_2.i.i = xor i16 %162, -1
  %163 = call i16 @llvm.ctlz.i16(i16 %_2.i.i, i1 false)
  %_0.i1.i = zext i16 %163 to i32
  store i32 %_0.i1.i, ptr %_250, align 4
  %164 = load i16, ptr %min, align 2
  %165 = call i16 @llvm.cttz.i16(i16 %164, i1 false)
  %_0.i.i50 = zext i16 %165 to i32
  store i32 %_0.i.i50, ptr %_252, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_254, ptr align 4 %_250) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_255, ptr align 4 %_252) #17
  %166 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %166, ptr align 8 %_254, i64 16, i1 false)
  %167 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %167, ptr align 8 %_255, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %168 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #17
  %_247.0 = extractvalue { ptr, ptr } %168, 0
  %_247.1 = extractvalue { ptr, ptr } %168, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_247.0, ptr %_247.1)
  %169 = load i16, ptr %max, align 2
; call <i16>::isqrt
  %170 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums5isqrtCsltPpk0pe160_11int_ops_i16(i16 %169, ptr align 8 @alloc_7b7cc07e20ab20ae0e8bd02d871ba4a6) #17
  store i16 %170, ptr %_262, align 2
  %171 = call { i16, i1 } @llvm.smul.with.overflow.i16(i16 %three, i16 %three)
  %_266.0 = extractvalue { i16, i1 } %171, 0
  %_266.1 = extractvalue { i16, i1 } %171, 1
  br i1 %_266.1, label %panic29, label %bb127

panic28:                                          ; preds = %bb87
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_e71b339731a4e22212fd5857983819f6) #23
  unreachable

bb127:                                            ; preds = %bb88
; call <i16>::ilog2
  %172 = call i32 @_RNvMs_NtCsl10jNU3mE6R_4core3nums5ilog2CsltPpk0pe160_11int_ops_i16(i16 %_266.0, ptr align 8 @alloc_8a4e3ec4a754bafdf198788b06de15cf) #17
  store i32 %172, ptr %_264, align 4
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_268, ptr align 2 %_262) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_269, ptr align 4 %_264) #17
  %173 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %173, ptr align 8 %_268, i64 16, i1 false)
  %174 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %174, ptr align 8 %_269, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %175 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #17
  %_259.0 = extractvalue { ptr, ptr } %175, 0
  %_259.1 = extractvalue { ptr, ptr } %175, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_259.0, ptr %_259.1)
; call <i16 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringsNtB5_8ToString9to_stringCsltPpk0pe160_11int_ops_i16(ptr sret([24 x i8]) align 8 %_279, ptr align 2 %max) #17
; invoke <alloc::string::String>::len
  %_277 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsltPpk0pe160_11int_ops_i16(ptr align 8 %_279)
          to label %bb134 unwind label %cleanup

panic29:                                          ; preds = %bb88
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_04307af443809ae18a3edf079cbe4d42) #23
  unreachable

bb147:                                            ; preds = %bb146, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279) #24
          to label %bb148 unwind label %terminate

cleanup:                                          ; preds = %bb143, %bb136, %bb135, %bb134, %bb127
  %176 = landingpad { ptr, i32 }
          cleanup
  %177 = extractvalue { ptr, i32 } %176, 0
  %178 = extractvalue { ptr, i32 } %176, 1
  store ptr %177, ptr %0, align 8
  %179 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %178, ptr %179, align 8
  br label %bb147

bb134:                                            ; preds = %bb127
; invoke <core::fmt::rt::Argument>::new_display::<i16>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECsltPpk0pe160_11int_ops_i16(ptr sret([16 x i8]) align 8 %_289, ptr align 2 %min)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  %180 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %180, ptr align 8 %_289, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %181 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb136 unwind label %cleanup

bb136:                                            ; preds = %bb135
  %_285.0 = extractvalue { ptr, ptr } %181, 0
  %_285.1 = extractvalue { ptr, ptr } %181, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsltPpk0pe160_11int_ops_i16(ptr sret([24 x i8]) align 8 %_284, ptr %_285.0, ptr %_285.1)
          to label %bb137 unwind label %cleanup

bb137:                                            ; preds = %bb136
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_283, ptr align 8 %_284, i64 24, i1 false)
  br label %bb138

bb138:                                            ; preds = %bb137
; invoke <alloc::string::String>::len
  %_281 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsltPpk0pe160_11int_ops_i16(ptr align 8 %_283)
          to label %bb139 unwind label %cleanup30

bb146:                                            ; preds = %cleanup30
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283) #24
          to label %bb147 unwind label %terminate

cleanup30:                                        ; preds = %bb142, %bb141, %bb140, %panic31, %bb138
  %182 = landingpad { ptr, i32 }
          cleanup
  %183 = extractvalue { ptr, i32 } %182, 0
  %184 = extractvalue { ptr, i32 } %182, 1
  store ptr %183, ptr %0, align 8
  %185 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %184, ptr %185, align 8
  br label %bb146

bb139:                                            ; preds = %bb138
  %_292.0 = add i64 %_277, %_281
  %_292.1 = icmp ult i64 %_292.0, %_277
  br i1 %_292.1, label %panic31, label %bb140

bb140:                                            ; preds = %bb139
  store i64 %_292.0, ptr %_276, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_294, ptr align 8 %_276)
          to label %bb141 unwind label %cleanup30

panic31:                                          ; preds = %bb139
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_54423fc5084848be87cba9c0c02cc867) #19
          to label %unreachable unwind label %cleanup30

unreachable:                                      ; preds = %panic31
  unreachable

bb141:                                            ; preds = %bb140
  %186 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %186, ptr align 8 %_294, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %187 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb142 unwind label %cleanup30

bb142:                                            ; preds = %bb141
  %_273.0 = extractvalue { ptr, ptr } %187, 0
  %_273.1 = extractvalue { ptr, ptr } %187, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_273.0, ptr %_273.1)
          to label %bb143 unwind label %cleanup30

bb143:                                            ; preds = %bb142
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_283)
          to label %bb144 unwind label %cleanup

bb144:                                            ; preds = %bb143
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_279)
  ret void

terminate:                                        ; preds = %bb147, %bb146
  %188 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable

bb148:                                            ; preds = %bb147
  %189 = load ptr, ptr %0, align 8
  %190 = getelementptr inbounds i8, ptr %0, i64 8
  %191 = load i32, ptr %190, align 8
  %192 = insertvalue { ptr, i32 } poison, ptr %189, 0
  %193 = insertvalue { ptr, i32 } %192, i32 %191, 1
  resume { ptr, i32 } %193
}

; <alloc::string::String>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCsltPpk0pe160_11int_ops_i16(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !96 {
start:
  %_2 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8 %_2, i64 %capacity) #17
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsltPpk0pe160_11int_ops_i16(ptr align 8 %self) unnamed_addr #0 !guid !97 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #17
  ret i64 %_0
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCsltPpk0pe160_11int_ops_i16(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !98 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsltPpk0pe160_11int_ops_i16(ptr align 8 %self) #17
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8CsltPpk0pe160_11int_ops_i16(i32 %ch) #17
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCsltPpk0pe160_11int_ops_i16(ptr align 8 %self, i64 %ch_len) #17
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8 %self) #17
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCsltPpk0pe160_11int_ops_i16(i32 %ch, ptr %_0.i) #17
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8 %self, i64 %_14) #17
  ret void
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCsltPpk0pe160_11int_ops_i16(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !99 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::string::String>::push_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCsltPpk0pe160_11int_ops_i16(ptr align 8 %self, ptr %string.0, i64 %string.1) unnamed_addr #0 !guid !100 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %string.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %string.1, 1
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; call <alloc::vec::Vec<u8>>::extend_from_slice
  call void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8 %self, ptr %_4.0, i64 %_4.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsltPpk0pe160_11int_ops_i16(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !101 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<i16>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionsE7is_noneCsltPpk0pe160_11int_ops_i16(ptr align 2 %self) unnamed_addr #0 !guid !102 {
start:
; call <core::option::Option<i16>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionsE7is_someCsltPpk0pe160_11int_ops_i16(ptr align 2 %self) #17
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::option::Option<i16>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionsE7is_someCsltPpk0pe160_11int_ops_i16(ptr align 2 %self) unnamed_addr #0 !guid !103 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i16, ptr %self, align 2
  %1 = getelementptr inbounds i8, ptr %self, i64 2
  %2 = load i16, ptr %1, align 2
  %_2 = zext i16 %0 to i64
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i16, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultsNtNtNtB4_3num5error13ParseIntErrorE5is_okCsltPpk0pe160_11int_ops_i16(ptr align 2 %self) unnamed_addr #0 !guid !104 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 2
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8CsltPpk0pe160_11int_ops_i16(i32 %self) unnamed_addr #0 !guid !105 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CsltPpk0pe160_11int_ops_i16(i32 %self) #17
  ret i64 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsltPpk0pe160_11int_ops_i16(i32 %self, i32 %radix) unnamed_addr #0 !guid !106 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsltPpk0pe160_11int_ops_i16(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #17
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #23
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::ptr::non_null::NonNull<core::option::Option<i16>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionsEE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %r) unnamed_addr #0 !guid !107 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i16, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultsNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %r) unnamed_addr #0 !guid !108 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<(i16, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTsbEE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %r) unnamed_addr #0 !guid !109 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsltPpk0pe160_11int_ops_i16(ptr %r) unnamed_addr #0 !guid !110 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 8 %r) unnamed_addr #0 !guid !111 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 4 %r) unnamed_addr #0 !guid !112 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i16>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCsltPpk0pe160_11int_ops_i16(ptr align 2 %r) unnamed_addr #0 !guid !113 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsltPpk0pe160_11int_ops_i16(ptr align 8 %self) unnamed_addr #0 !guid !114 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #17
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsltPpk0pe160_11int_ops_i16(ptr %_7.0, i64 %_7.1) #17
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsltPpk0pe160_11int_ops_i16(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !115 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsltPpk0pe160_11int_ops_i16(ptr %s.0, i64 %s.1) #17
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u16>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs5_NtCsl10jNU3mE6R_4core3numt13checked_ilog2CsltPpk0pe160_11int_ops_i16(i16 %self) unnamed_addr #0 !guid !116 {
start:
  %_2 = alloca [2 x i8], align 2
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u16>>::new
  %0 = call i16 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE3newB9_(i16 %self) #17
  store i16 %0, ptr %_2, align 2
  %1 = load i16, ptr %_2, align 2
  %2 = icmp eq i16 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i16, ptr %_2, align 2
; call <core::num::nonzero::NonZero<u16>>::ilog2
  %_5 = call i32 @_RNvMsN_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE5ilog2CsltPpk0pe160_11int_ops_i16(i16 %x) #17
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u16>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs5_NtCsl10jNU3mE6R_4core3numt5ilog2CsltPpk0pe160_11int_ops_i16(i16 %self, ptr align 8 %0) unnamed_addr #0 !guid !117 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u16>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs5_NtCsl10jNU3mE6R_4core3numt13checked_ilog2CsltPpk0pe160_11int_ops_i16(i16 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u16>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMs5_NtCsl10jNU3mE6R_4core3numt5isqrtCsltPpk0pe160_11int_ops_i16(i16 %self) unnamed_addr #0 !guid !118 {
start:
; call core::num::imp::int_sqrt::u16
  %result = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsltPpk0pe160_11int_ops_i16(i16 %self) #17
  %_3 = icmp ule i16 %result, 255
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsltPpk0pe160_11int_ops_i16(i1 zeroext %_3, ptr align 8 @alloc_e6bfe4544d0990c68f8aeca813730e73) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i16 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs5_NtCsl10jNU3mE6R_4core3numt13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u16>::unchecked_mul::precondition_check
  call void @_RNvNvMs5_NtCsl10jNU3mE6R_4core3numt13unchecked_mul18precondition_checkCsltPpk0pe160_11int_ops_i16(i16 %result, i16 %result, ptr align 8 @alloc_e6bfe4544d0990c68f8aeca813730e73) #22
  br label %_RNvMs5_NtCsl10jNU3mE6R_4core3numt13unchecked_mul.exit

_RNvMs5_NtCsl10jNU3mE6R_4core3numt13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i16 %result, %result
  %_8 = icmp ule i16 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs5_NtCsl10jNU3mE6R_4core3numt13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsltPpk0pe160_11int_ops_i16(i1 zeroext %_8, ptr align 8 @alloc_e6bfe4544d0990c68f8aeca813730e73) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs5_NtCsl10jNU3mE6R_4core3numt13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i16 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsltPpk0pe160_11int_ops_i16(i1 zeroext %_11, ptr align 8 @alloc_e6bfe4544d0990c68f8aeca813730e73) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i16 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i16 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsltPpk0pe160_11int_ops_i16(i1 zeroext %_6, ptr align 8 @alloc_e6bfe4544d0990c68f8aeca813730e73) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsltPpk0pe160_11int_ops_i16(i32 %self, i32 %rhs) unnamed_addr #0 !guid !119 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsltPpk0pe160_11int_ops_i16(ptr %self) unnamed_addr #0 !guid !120 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u16>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsN_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE13leading_zerosCsltPpk0pe160_11int_ops_i16(i16 %self) unnamed_addr #0 !guid !121 {
start:
; call <core::num::nonzero::NonZero<u16>>::get
  %_2 = call i16 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE3getB9_(i16 %self) #17
  %0 = call i16 @llvm.ctlz.i16(i16 %_2, i1 true)
  %_0 = zext i16 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u16>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsN_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE5ilog2CsltPpk0pe160_11int_ops_i16(i16 %self) unnamed_addr #0 !guid !122 {
start:
; call <core::num::nonzero::NonZero<u16>>::leading_zeros
  %_3 = call i32 @_RNvMsN_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE13leading_zerosCsltPpk0pe160_11int_ops_i16(i16 %self) #17
  %_0 = sub i32 15, %_3
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsltPpk0pe160_11int_ops_i16(i8 %0) unnamed_addr #0 !guid !123 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsltPpk0pe160_11int_ops_i16(ptr %self) #17
  ret i32 %_0
}

; <i16>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums10strict_powCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !124 {
start:
  %_3 = alloca [4 x i8], align 2
; call <i16>::checked_pow
  %1 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_powCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %exp) #17
  %2 = extractvalue { i16, i16 } %1, 0
  %3 = extractvalue { i16, i16 } %1, 1
  store i16 %2, ptr %_3, align 2
  %4 = getelementptr inbounds i8, ptr %_3, i64 2
  store i16 %3, ptr %4, align 2
  %5 = load i16, ptr %_3, align 2
  %6 = getelementptr inbounds i8, ptr %_3, i64 2
  %7 = load i16, ptr %6, align 2
  %_4 = zext i16 %5 to i64
  %8 = trunc nuw i64 %_4 to i1
  br i1 %8, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_3, i64 2
  %x = load i16, ptr %9, align 2
  ret i16 %x

bb3:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i16>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_addCsltPpk0pe160_11int_ops_i16(i16 %self, i16 %rhs) unnamed_addr #0 !guid !125 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 2
  %0 = call { i16, i1 } @llvm.sadd.with.overflow.i16(i16 %self, i16 %rhs)
  %_5.0.i = extractvalue { i16, i1 } %0, 0
  %_5.1.i = extractvalue { i16, i1 } %0, 1
  %_5.0 = extractvalue { i16, i1 } %0, 0
  %_5.1 = extractvalue { i16, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %_5.0, ptr %3, align 2
  store i16 1, ptr %_0, align 2
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i16 0, ptr %_0, align 2
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i16, ptr %_0, align 2
  %5 = getelementptr inbounds i8, ptr %_0, i64 2
  %6 = load i16, ptr %5, align 2
  %7 = insertvalue { i16, i16 } poison, i16 %4, 0
  %8 = insertvalue { i16, i16 } %7, i16 %6, 1
  ret { i16, i16 } %8
}

; <i16>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_divCsltPpk0pe160_11int_ops_i16(i16 %self, i16 %rhs) unnamed_addr #0 !guid !126 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 2
  %_5 = icmp eq i16 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i16 %self, -32768
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i16 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = sdiv i16 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %_7, ptr %6, align 2
  store i16 1, ptr %_0, align 2
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i16 0, ptr %_0, align 2
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i16, ptr %_0, align 2
  %8 = getelementptr inbounds i8, ptr %_0, i64 2
  %9 = load i16, ptr %8, align 2
  %10 = insertvalue { i16, i16 } poison, i16 %7, 0
  %11 = insertvalue { i16, i16 } %10, i16 %9, 1
  ret { i16, i16 } %11
}

; <i16>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_mulCsltPpk0pe160_11int_ops_i16(i16 %self, i16 %rhs) unnamed_addr #0 !guid !127 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 2
  %0 = call { i16, i1 } @llvm.smul.with.overflow.i16(i16 %self, i16 %rhs)
  %_5.0.i = extractvalue { i16, i1 } %0, 0
  %_5.1.i = extractvalue { i16, i1 } %0, 1
  %_5.0 = extractvalue { i16, i1 } %0, 0
  %_5.1 = extractvalue { i16, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %_5.0, ptr %3, align 2
  store i16 1, ptr %_0, align 2
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i16 0, ptr %_0, align 2
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i16, ptr %_0, align 2
  %5 = getelementptr inbounds i8, ptr %_0, i64 2
  %6 = load i16, ptr %5, align 2
  %7 = insertvalue { i16, i16 } poison, i16 %4, 0
  %8 = insertvalue { i16, i16 } %7, i16 %6, 1
  ret { i16, i16 } %8
}

; <i16>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_powCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %0) unnamed_addr #0 !guid !128 {
start:
  %_57 = alloca [4 x i8], align 2
  %_48 = alloca [4 x i8], align 2
  %_38 = alloca [4 x i8], align 2
  %_32 = alloca [4 x i8], align 2
  %_13 = alloca [8 x i8], align 4
  %acc = alloca [2 x i8], align 2
  %base = alloca [2 x i8], align 2
  %_0 = alloca [4 x i8], align 2
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i16 %self, ptr %base, align 2
  store i16 1, ptr %acc, align 2
  %_6 = load i16, ptr %base, align 2
  %_5 = call i1 @llvm.is.constant.i16(i16 %_6)
  br i1 %_5, label %bb2, label %bb16

bb16:                                             ; preds = %bb2, %start
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp eq i32 %_24, 0
  br i1 %_23, label %bb17, label %bb18

bb2:                                              ; preds = %start
  %_9 = load i16, ptr %base, align 2
; call <i16>::unsigned_abs
  %_8 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12unsigned_absCsltPpk0pe160_11int_ops_i16(i16 %_9) #17
  %1 = call i16 @llvm.ctpop.i16(i16 %_8)
  %_0.i.i = zext i16 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb16

bb5:                                              ; preds = %bb2
  %_12 = load i16, ptr %base, align 2
; call <i16>::unsigned_abs
  %_11 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12unsigned_absCsltPpk0pe160_11int_ops_i16(i16 %_12) #17
; call <u16>::ilog2
  %k = call i32 @_RNvMs5_NtCsl10jNU3mE6R_4core3numt5ilog2CsltPpk0pe160_11int_ops_i16(i16 %_11, ptr align 8 @alloc_49ab7e7c421882b397e0500c1648bb06) #17
  %_14 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsltPpk0pe160_11int_ops_i16(i32 %k, i32 %_14) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_13, align 4
  %5 = getelementptr inbounds i8, ptr %_13, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_13, align 4
  %7 = getelementptr inbounds i8, ptr %_13, i64 4
  %8 = load i32, ptr %7, align 4
  %_15 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_15 to i1
  br i1 %9, label %bb11, label %bb10

bb18:                                             ; preds = %bb16
  %_26 = load i32, ptr %exp, align 4
  %_25 = call i1 @llvm.is.constant.i32(i32 %_26)
  br i1 %_25, label %bb20, label %bb32

bb17:                                             ; preds = %bb16
  %10 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 1, ptr %10, align 2
  store i16 1, ptr %_0, align 2
  br label %bb43

bb32:                                             ; preds = %bb42, %bb18
  %_47 = load i32, ptr %exp, align 4
  %_46 = and i32 %_47, 1
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb33, label %bb38

bb20:                                             ; preds = %bb30, %bb18
  %_28 = load i32, ptr %exp, align 4
  %_27 = icmp ugt i32 %_28, 1
  br i1 %_27, label %bb21, label %bb31

bb38:                                             ; preds = %bb36, %bb32
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_58 = load i16, ptr %base, align 2
  %_59 = load i16, ptr %base, align 2
; call <i16>::checked_mul
  %13 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_mulCsltPpk0pe160_11int_ops_i16(i16 %_58, i16 %_59) #17
  %14 = extractvalue { i16, i16 } %13, 0
  %15 = extractvalue { i16, i16 } %13, 1
  store i16 %14, ptr %_57, align 2
  %16 = getelementptr inbounds i8, ptr %_57, i64 2
  store i16 %15, ptr %16, align 2
  %17 = load i16, ptr %_57, align 2
  %18 = getelementptr inbounds i8, ptr %_57, i64 2
  %19 = load i16, ptr %18, align 2
  %_60 = zext i16 %17 to i64
  %20 = trunc nuw i64 %_60 to i1
  br i1 %20, label %bb42, label %bb41

bb33:                                             ; preds = %bb32
  %_49 = load i16, ptr %acc, align 2
  %_50 = load i16, ptr %base, align 2
; call <i16>::checked_mul
  %21 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_mulCsltPpk0pe160_11int_ops_i16(i16 %_49, i16 %_50) #17
  %22 = extractvalue { i16, i16 } %21, 0
  %23 = extractvalue { i16, i16 } %21, 1
  store i16 %22, ptr %_48, align 2
  %24 = getelementptr inbounds i8, ptr %_48, i64 2
  store i16 %23, ptr %24, align 2
  %25 = load i16, ptr %_48, align 2
  %26 = getelementptr inbounds i8, ptr %_48, i64 2
  %27 = load i16, ptr %26, align 2
  %_51 = zext i16 %25 to i64
  %28 = trunc nuw i64 %_51 to i1
  br i1 %28, label %bb36, label %bb35

bb36:                                             ; preds = %bb33
  %29 = getelementptr inbounds i8, ptr %_48, i64 2
  %x = load i16, ptr %29, align 2
  store i16 %x, ptr %acc, align 2
  %_54 = load i32, ptr %exp, align 4
  %_53 = icmp eq i32 %_54, 1
  br i1 %_53, label %bb37, label %bb38

bb35:                                             ; preds = %bb33
  store i16 0, ptr %_0, align 2
  br label %bb43

bb43:                                             ; preds = %bb14, %bb15, %bb10, %bb17, %bb29, %bb24, %bb31, %bb37, %bb41, %bb35
  %30 = load i16, ptr %_0, align 2
  %31 = getelementptr inbounds i8, ptr %_0, i64 2
  %32 = load i16, ptr %31, align 2
  %33 = insertvalue { i16, i16 } poison, i16 %30, 0
  %34 = insertvalue { i16, i16 } %33, i16 %32, 1
  ret { i16, i16 } %34

bb37:                                             ; preds = %bb36
  %_55 = load i16, ptr %acc, align 2
  %35 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %_55, ptr %35, align 2
  store i16 1, ptr %_0, align 2
  br label %bb43

bb42:                                             ; preds = %bb38
  %36 = getelementptr inbounds i8, ptr %_57, i64 2
  %x1 = load i16, ptr %36, align 2
  store i16 %x1, ptr %base, align 2
  br label %bb32

bb41:                                             ; preds = %bb38
  store i16 0, ptr %_0, align 2
  br label %bb43

bb31:                                             ; preds = %bb20
  %_43 = load i16, ptr %acc, align 2
  %_44 = load i16, ptr %base, align 2
; call <i16>::checked_mul
  %37 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_mulCsltPpk0pe160_11int_ops_i16(i16 %_43, i16 %_44) #17
  %38 = extractvalue { i16, i16 } %37, 0
  %39 = extractvalue { i16, i16 } %37, 1
  store i16 %38, ptr %_0, align 2
  %40 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %39, ptr %40, align 2
  br label %bb43

bb21:                                             ; preds = %bb20
  %_31 = load i32, ptr %exp, align 4
  %_30 = and i32 %_31, 1
  %_29 = icmp eq i32 %_30, 1
  br i1 %_29, label %bb22, label %bb26

bb26:                                             ; preds = %bb25, %bb21
  %41 = load i32, ptr %exp, align 4
  %42 = udiv i32 %41, 2
  store i32 %42, ptr %exp, align 4
  %_39 = load i16, ptr %base, align 2
  %_40 = load i16, ptr %base, align 2
; call <i16>::checked_mul
  %43 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_mulCsltPpk0pe160_11int_ops_i16(i16 %_39, i16 %_40) #17
  %44 = extractvalue { i16, i16 } %43, 0
  %45 = extractvalue { i16, i16 } %43, 1
  store i16 %44, ptr %_38, align 2
  %46 = getelementptr inbounds i8, ptr %_38, i64 2
  store i16 %45, ptr %46, align 2
  %47 = load i16, ptr %_38, align 2
  %48 = getelementptr inbounds i8, ptr %_38, i64 2
  %49 = load i16, ptr %48, align 2
  %_41 = zext i16 %47 to i64
  %50 = trunc nuw i64 %_41 to i1
  br i1 %50, label %bb30, label %bb29

bb22:                                             ; preds = %bb21
  %_33 = load i16, ptr %acc, align 2
  %_34 = load i16, ptr %base, align 2
; call <i16>::checked_mul
  %51 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_mulCsltPpk0pe160_11int_ops_i16(i16 %_33, i16 %_34) #17
  %52 = extractvalue { i16, i16 } %51, 0
  %53 = extractvalue { i16, i16 } %51, 1
  store i16 %52, ptr %_32, align 2
  %54 = getelementptr inbounds i8, ptr %_32, i64 2
  store i16 %53, ptr %54, align 2
  %55 = load i16, ptr %_32, align 2
  %56 = getelementptr inbounds i8, ptr %_32, i64 2
  %57 = load i16, ptr %56, align 2
  %_35 = zext i16 %55 to i64
  %58 = trunc nuw i64 %_35 to i1
  br i1 %58, label %bb25, label %bb24

bb25:                                             ; preds = %bb22
  %59 = getelementptr inbounds i8, ptr %_32, i64 2
  %x2 = load i16, ptr %59, align 2
  store i16 %x2, ptr %acc, align 2
  br label %bb26

bb24:                                             ; preds = %bb22
  store i16 0, ptr %_0, align 2
  br label %bb43

bb30:                                             ; preds = %bb26
  %60 = getelementptr inbounds i8, ptr %_38, i64 2
  %x3 = load i16, ptr %60, align 2
  store i16 %x3, ptr %base, align 2
  br label %bb20

bb29:                                             ; preds = %bb26
  store i16 0, ptr %_0, align 2
  br label %bb43

bb11:                                             ; preds = %bb5
  %61 = getelementptr inbounds i8, ptr %_13, i64 4
  %shift = load i32, ptr %61, align 4
  %_18 = load i16, ptr %base, align 2
  %_17 = icmp slt i16 %_18, 0
  br i1 %_17, label %bb12, label %bb15

bb10:                                             ; preds = %bb5
  store i16 0, ptr %_0, align 2
  br label %bb43

bb15:                                             ; preds = %bb12, %bb11
; call <i16>::shl_exact
  %62 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums9shl_exactCsltPpk0pe160_11int_ops_i16(i16 1, i32 %shift) #17
  %63 = extractvalue { i16, i16 } %62, 0
  %64 = extractvalue { i16, i16 } %62, 1
  store i16 %63, ptr %_0, align 2
  %65 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %64, ptr %65, align 2
  br label %bb43

bb12:                                             ; preds = %bb11
  %_21 = load i32, ptr %exp, align 4
  %_20 = urem i32 %_21, 2
  %_19 = icmp eq i32 %_20, 1
  br i1 %_19, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
; call <i16>::shl_exact
  %66 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums9shl_exactCsltPpk0pe160_11int_ops_i16(i16 -1, i32 %shift) #17
  %67 = extractvalue { i16, i16 } %66, 0
  %68 = extractvalue { i16, i16 } %66, 1
  store i16 %67, ptr %_0, align 2
  %69 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %68, ptr %69, align 2
  br label %bb43

bb9:                                              ; No predecessors!
  unreachable
}

; <i16>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_remCsltPpk0pe160_11int_ops_i16(i16 %self, i16 %rhs) unnamed_addr #0 !guid !129 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 2
  %_5 = icmp eq i16 %rhs, 0
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i16 %self, -32768
  br i1 %_6, label %bb3, label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_4, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_4, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %0 = icmp eq i16 %rhs, -1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %2 = load i8, ptr %_4, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb5
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb5
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb7, label %bb8

bb8:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_7 = srem i16 %self, %rhs
  %6 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %_7, ptr %6, align 2
  store i16 1, ptr %_0, align 2
  br label %bb9

bb7:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i16 0, ptr %_0, align 2
  br label %bb9

bb9:                                              ; preds = %bb7, %bb8
  %7 = load i16, ptr %_0, align 2
  %8 = getelementptr inbounds i8, ptr %_0, i64 2
  %9 = load i16, ptr %8, align 2
  %10 = insertvalue { i16, i16 } poison, i16 %7, 0
  %11 = insertvalue { i16, i16 } %10, i16 %9, 1
  ret { i16, i16 } %11
}

; <i16>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_subCsltPpk0pe160_11int_ops_i16(i16 %self, i16 %rhs) unnamed_addr #0 !guid !130 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 2
  %0 = call { i16, i1 } @llvm.ssub.with.overflow.i16(i16 %self, i16 %rhs)
  %_5.0.i = extractvalue { i16, i1 } %0, 0
  %_5.1.i = extractvalue { i16, i1 } %0, 1
  %_5.0 = extractvalue { i16, i1 } %0, 0
  %_5.1 = extractvalue { i16, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %_5.0, ptr %3, align 2
  store i16 1, ptr %_0, align 2
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i16 0, ptr %_0, align 2
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i16, ptr %_0, align 2
  %5 = getelementptr inbounds i8, ptr %_0, i64 2
  %6 = load i16, ptr %5, align 2
  %7 = insertvalue { i16, i16 } poison, i16 %4, 0
  %8 = insertvalue { i16, i16 } %7, i16 %6, 1
  ret { i16, i16 } %8
}

; <i16>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12unsigned_absCsltPpk0pe160_11int_ops_i16(i16 %self) unnamed_addr #0 !guid !131 {
start:
; call <i16>::wrapping_abs
  %_2 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12wrapping_absCsltPpk0pe160_11int_ops_i16(i16 %self) #17
  ret i16 %_2
}

; <i16>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12wrapping_absCsltPpk0pe160_11int_ops_i16(i16 %self) unnamed_addr #0 !guid !132 {
start:
  %_0 = alloca [2 x i8], align 2
  %_0.i = icmp slt i16 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i16 %self, ptr %_0, align 2
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i16 0, %self
  store i16 %_0.i2, ptr %_0, align 2
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i16, ptr %_0, align 2
  ret i16 %0
}

; <i16>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12wrapping_powCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %exp) unnamed_addr #0 !guid !133 {
start:
; call <i16>::overflowing_pow
  %0 = call { i16, i1 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums15overflowing_powCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %exp) #17
  %_3.0 = extractvalue { i16, i1 } %0, 0
  %_3.1 = extractvalue { i16, i1 } %0, 1
  ret i16 %_3.0
}

; <i16>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums13checked_ilog2CsltPpk0pe160_11int_ops_i16(i16 %self) unnamed_addr #0 !guid !134 {
start:
  %_0 = alloca [8 x i8], align 4
  %_2 = icmp sle i16 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = call i16 @llvm.ctlz.i16(i16 %self, i1 true)
  %_5 = zext i16 %0 to i32
  %log = sub i32 15, %_5
  %1 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %log, ptr %1, align 4
  store i32 1, ptr %_0, align 4
  br label %bb4

bb1:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  %2 = load i32, ptr %_0, align 4
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  %4 = load i32, ptr %3, align 4
  %5 = insertvalue { i32, i32 } poison, i32 %2, 0
  %6 = insertvalue { i32, i32 } %5, i32 %4, 1
  ret { i32, i32 } %6
}

; <i16>::checked_isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums13checked_isqrtCsltPpk0pe160_11int_ops_i16(i16 %self) unnamed_addr #0 !guid !135 {
start:
  %_0 = alloca [4 x i8], align 2
  %_2 = icmp slt i16 %self, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call <u16>::isqrt
  %_4 = call i16 @_RNvMs5_NtCsl10jNU3mE6R_4core3numt5isqrtCsltPpk0pe160_11int_ops_i16(i16 %self) #17
  %_7 = icmp sle i16 %_4, 181
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb2
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsltPpk0pe160_11int_ops_i16(i1 zeroext %_7, ptr align 8 @alloc_49ab7e7c421882b397e0500c1648bb06) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb2, %bb2.i
  %0 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %_4, ptr %0, align 2
  store i16 1, ptr %_0, align 2
  br label %bb7

bb1:                                              ; preds = %start
  store i16 0, ptr %_0, align 2
  br label %bb7

bb7:                                              ; preds = %bb1, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %1 = load i16, ptr %_0, align 2
  %2 = getelementptr inbounds i8, ptr %_0, i64 2
  %3 = load i16, ptr %2, align 2
  %4 = insertvalue { i16, i16 } poison, i16 %1, 0
  %5 = insertvalue { i16, i16 } %4, i16 %3, 1
  ret { i16, i16 } %5
}

; <i16>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums13unbounded_shlCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %rhs) unnamed_addr #0 !guid !136 {
start:
  %_0 = alloca [2 x i8], align 2
  %_3 = icmp ult i32 %rhs, 16
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i16 0, ptr %_0, align 2
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <i16>::unchecked_shl::precondition_check
  call void @_RNvNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl18precondition_checkCsltPpk0pe160_11int_ops_i16(i32 %rhs, ptr align 8 @alloc_49ab7e7c421882b397e0500c1648bb06) #22
  br label %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit

_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = trunc nuw i32 %rhs to i16
  %_0.i = shl i16 %self, %0
  store i16 %_0.i, ptr %_0, align 2
  br label %bb3

bb3:                                              ; preds = %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit, %bb2
  %1 = load i16, ptr %_0, align 2
  ret i16 %1
}

; <i16>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i16, i1 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums15overflowing_powCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %0) unnamed_addr #0 !guid !137 {
start:
  %_30 = alloca [4 x i8], align 2
  %base1 = alloca [2 x i8], align 2
  %_16 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [2 x i8], align 2
  %base = alloca [2 x i8], align 2
  %_0 = alloca [4 x i8], align 2
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i16 %self, ptr %base, align 2
  store i16 1, ptr %acc, align 2
  store i8 0, ptr %overflow, align 1
  %_8 = load i16, ptr %base, align 2
  %_7 = call i1 @llvm.is.constant.i16(i16 %_8)
  br i1 %_7, label %bb2, label %bb19

bb19:                                             ; preds = %bb2, %start
  %_33 = load i32, ptr %exp, align 4
  %_32 = icmp eq i32 %_33, 0
  br i1 %_32, label %bb20, label %bb21

bb2:                                              ; preds = %start
  %_11 = load i16, ptr %base, align 2
; call <i16>::unsigned_abs
  %_10 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12unsigned_absCsltPpk0pe160_11int_ops_i16(i16 %_11) #17
  %1 = call i16 @llvm.ctpop.i16(i16 %_10)
  %_0.i.i = zext i16 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb19

bb5:                                              ; preds = %bb2
  %_14 = load i16, ptr %base, align 2
; call <i16>::unsigned_abs
  %_13 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12unsigned_absCsltPpk0pe160_11int_ops_i16(i16 %_14) #17
; call <u16>::ilog2
  %k = call i32 @_RNvMs5_NtCsl10jNU3mE6R_4core3numt5ilog2CsltPpk0pe160_11int_ops_i16(i16 %_13, ptr align 8 @alloc_49ab7e7c421882b397e0500c1648bb06) #17
  %_17 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsltPpk0pe160_11int_ops_i16(i32 %k, i32 %_17) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_16, align 4
  %5 = getelementptr inbounds i8, ptr %_16, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_16, align 4
  %7 = getelementptr inbounds i8, ptr %_16, i64 4
  %8 = load i32, ptr %7, align 4
  %_18 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_18 to i1
  br i1 %9, label %bb9, label %bb10

bb21:                                             ; preds = %bb19
  %_35 = load i32, ptr %exp, align 4
  %_34 = call i1 @llvm.is.constant.i32(i32 %_35)
  br i1 %_34, label %bb23, label %bb32

bb20:                                             ; preds = %bb19
  store i32 1, ptr %_0, align 2
  br label %bb39

bb32:                                             ; preds = %bb36, %bb21
  %_64 = load i32, ptr %exp, align 4
  %_63 = and i32 %_64, 1
  %_62 = icmp eq i32 %_63, 1
  br i1 %_62, label %bb33, label %bb36

bb23:                                             ; preds = %bb27, %bb21
  %_37 = load i32, ptr %exp, align 4
  %_36 = icmp ugt i32 %_37, 1
  br i1 %_36, label %bb24, label %bb30

bb36:                                             ; preds = %bb33, %bb32
  %10 = load i32, ptr %exp, align 4
  %11 = udiv i32 %10, 2
  store i32 %11, ptr %exp, align 4
  %_79 = load i16, ptr %base, align 2
  %_80 = load i16, ptr %base, align 2
  %12 = call { i16, i1 } @llvm.smul.with.overflow.i16(i16 %_79, i16 %_80)
  %_5.0.i6 = extractvalue { i16, i1 } %12, 0
  %_5.1.i7 = extractvalue { i16, i1 } %12, 1
  %_78.0 = extractvalue { i16, i1 } %12, 0
  %_78.1 = extractvalue { i16, i1 } %12, 1
  store i16 %_78.0, ptr %base, align 2
  %13 = zext i1 %_78.1 to i8
  store i8 %13, ptr %tmp_overflow, align 1
  %14 = load i8, ptr %tmp_overflow, align 1
  %_81 = trunc nuw i8 %14 to i1
  %15 = load i8, ptr %overflow, align 1
  %16 = trunc nuw i8 %15 to i1
  %17 = or i1 %16, %_81
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %overflow, align 1
  br label %bb32

bb33:                                             ; preds = %bb32
  %_68 = load i16, ptr %acc, align 2
  %_69 = load i16, ptr %base, align 2
  %19 = call { i16, i1 } @llvm.smul.with.overflow.i16(i16 %_68, i16 %_69)
  %_5.0.i8 = extractvalue { i16, i1 } %19, 0
  %_5.1.i9 = extractvalue { i16, i1 } %19, 1
  %_67.0 = extractvalue { i16, i1 } %19, 0
  %_67.1 = extractvalue { i16, i1 } %19, 1
  store i16 %_67.0, ptr %acc, align 2
  %20 = zext i1 %_67.1 to i8
  store i8 %20, ptr %tmp_overflow, align 1
  %21 = load i8, ptr %tmp_overflow, align 1
  %_70 = trunc nuw i8 %21 to i1
  %22 = load i8, ptr %overflow, align 1
  %23 = trunc nuw i8 %22 to i1
  %24 = or i1 %23, %_70
  %25 = zext i1 %24 to i8
  store i8 %25, ptr %overflow, align 1
  %_72 = load i32, ptr %exp, align 4
  %_71 = icmp eq i32 %_72, 1
  br i1 %_71, label %bb35, label %bb36

bb35:                                             ; preds = %bb33
  %_73 = load i16, ptr %acc, align 2
  %26 = load i8, ptr %overflow, align 1
  %_74 = trunc nuw i8 %26 to i1
  store i16 %_73, ptr %_0, align 2
  %27 = getelementptr inbounds i8, ptr %_0, i64 2
  %28 = zext i1 %_74 to i8
  store i8 %28, ptr %27, align 2
  br label %bb39

bb39:                                             ; preds = %bb10, %bb15, %bb20, %bb30, %bb35
  %29 = load i16, ptr %_0, align 2
  %30 = getelementptr inbounds i8, ptr %_0, i64 2
  %31 = load i8, ptr %30, align 2
  %32 = trunc nuw i8 %31 to i1
  %33 = insertvalue { i16, i1 } poison, i16 %29, 0
  %34 = insertvalue { i16, i1 } %33, i1 %32, 1
  ret { i16, i1 } %34

bb30:                                             ; preds = %bb23
  %_57 = load i16, ptr %acc, align 2
  %_58 = load i16, ptr %base, align 2
  %35 = call { i16, i1 } @llvm.smul.with.overflow.i16(i16 %_57, i16 %_58)
  %_5.0.i4 = extractvalue { i16, i1 } %35, 0
  %_5.1.i5 = extractvalue { i16, i1 } %35, 1
  %_56.0 = extractvalue { i16, i1 } %35, 0
  %_56.1 = extractvalue { i16, i1 } %35, 1
  store i16 %_56.0, ptr %acc, align 2
  %36 = zext i1 %_56.1 to i8
  store i8 %36, ptr %tmp_overflow, align 1
  %37 = load i8, ptr %tmp_overflow, align 1
  %_59 = trunc nuw i8 %37 to i1
  %38 = load i8, ptr %overflow, align 1
  %39 = trunc nuw i8 %38 to i1
  %40 = or i1 %39, %_59
  %41 = zext i1 %40 to i8
  store i8 %41, ptr %overflow, align 1
  %_60 = load i16, ptr %acc, align 2
  %42 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %42 to i1
  store i16 %_60, ptr %_0, align 2
  %43 = getelementptr inbounds i8, ptr %_0, i64 2
  %44 = zext i1 %_61 to i8
  store i8 %44, ptr %43, align 2
  br label %bb39

bb24:                                             ; preds = %bb23
  %_40 = load i32, ptr %exp, align 4
  %_39 = and i32 %_40, 1
  %_38 = icmp eq i32 %_39, 1
  br i1 %_38, label %bb25, label %bb27

bb27:                                             ; preds = %bb25, %bb24
  %45 = load i32, ptr %exp, align 4
  %46 = udiv i32 %45, 2
  store i32 %46, ptr %exp, align 4
  %_51 = load i16, ptr %base, align 2
  %_52 = load i16, ptr %base, align 2
  %47 = call { i16, i1 } @llvm.smul.with.overflow.i16(i16 %_51, i16 %_52)
  %_5.0.i = extractvalue { i16, i1 } %47, 0
  %_5.1.i = extractvalue { i16, i1 } %47, 1
  %_50.0 = extractvalue { i16, i1 } %47, 0
  %_50.1 = extractvalue { i16, i1 } %47, 1
  store i16 %_50.0, ptr %base, align 2
  %48 = zext i1 %_50.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_53 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_53
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  br label %bb23

bb25:                                             ; preds = %bb24
  %_44 = load i16, ptr %acc, align 2
  %_45 = load i16, ptr %base, align 2
  %54 = call { i16, i1 } @llvm.smul.with.overflow.i16(i16 %_44, i16 %_45)
  %_5.0.i2 = extractvalue { i16, i1 } %54, 0
  %_5.1.i3 = extractvalue { i16, i1 } %54, 1
  %_43.0 = extractvalue { i16, i1 } %54, 0
  %_43.1 = extractvalue { i16, i1 } %54, 1
  store i16 %_43.0, ptr %acc, align 2
  %55 = zext i1 %_43.1 to i8
  store i8 %55, ptr %tmp_overflow, align 1
  %56 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %56 to i1
  %57 = load i8, ptr %overflow, align 1
  %58 = trunc nuw i8 %57 to i1
  %59 = or i1 %58, %_46
  %60 = zext i1 %59 to i8
  store i8 %60, ptr %overflow, align 1
  br label %bb27

bb9:                                              ; preds = %bb5
  %61 = getelementptr inbounds i8, ptr %_16, i64 4
  %shift = load i32, ptr %61, align 4
  %_21 = load i16, ptr %base, align 2
  %_20 = icmp slt i16 %_21, 0
  br i1 %_20, label %bb11, label %bb14

bb10:                                             ; preds = %bb5
  store i32 65536, ptr %_0, align 2
  br label %bb39

bb14:                                             ; preds = %bb11, %bb9
  store i16 1, ptr %base1, align 2
  br label %bb15

bb11:                                             ; preds = %bb9
  %_24 = load i32, ptr %exp, align 4
  %_23 = urem i32 %_24, 2
  %_22 = icmp ne i32 %_23, 0
  br i1 %_22, label %bb13, label %bb14

bb13:                                             ; preds = %bb11
  store i16 -1, ptr %base1, align 2
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_27 = load i16, ptr %base1, align 2
; call <i16>::unbounded_shl
  %_26 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums13unbounded_shlCsltPpk0pe160_11int_ops_i16(i16 %_27, i32 %shift) #17
  %_31 = load i16, ptr %base1, align 2
; call <i16>::shl_exact
  %62 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums9shl_exactCsltPpk0pe160_11int_ops_i16(i16 %_31, i32 %shift) #17
  %63 = extractvalue { i16, i16 } %62, 0
  %64 = extractvalue { i16, i16 } %62, 1
  store i16 %63, ptr %_30, align 2
  %65 = getelementptr inbounds i8, ptr %_30, i64 2
  store i16 %64, ptr %65, align 2
; call <core::option::Option<i16>>::is_none
  %_28 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionsE7is_noneCsltPpk0pe160_11int_ops_i16(ptr align 2 %_30) #17
  store i16 %_26, ptr %_0, align 2
  %66 = getelementptr inbounds i8, ptr %_0, i64 2
  %67 = zext i1 %_28 to i8
  store i8 %67, ptr %66, align 2
  br label %bb39

bb40:                                             ; No predecessors!
  unreachable
}

; <i16>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums3powCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %exp) unnamed_addr #0 !guid !138 {
start:
  %_0 = alloca [2 x i8], align 2
  br label %bb1

bb1:                                              ; preds = %start
; call <i16>::strict_pow
  %0 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums10strict_powCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %exp, ptr align 8 @alloc_49ab7e7c421882b397e0500c1648bb06) #17
  store i16 %0, ptr %_0, align 2
  br label %bb3

bb2:                                              ; No predecessors!
; call <i16>::wrapping_pow
  %1 = call i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12wrapping_powCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %exp) #17
  store i16 %1, ptr %_0, align 2
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i16, ptr %_0, align 2
  ret i16 %2
}

; <i16>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs_NtCsl10jNU3mE6R_4core3nums5ilog2CsltPpk0pe160_11int_ops_i16(i16 %self, ptr align 8 %0) unnamed_addr #0 !guid !139 {
start:
  %_2 = alloca [8 x i8], align 4
; call <i16>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums13checked_ilog2CsltPpk0pe160_11int_ops_i16(i16 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i16>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums5isqrtCsltPpk0pe160_11int_ops_i16(i16 %self, ptr align 8 %0) unnamed_addr #0 !guid !140 {
start:
  %_2 = alloca [4 x i8], align 2
; call <i16>::checked_isqrt
  %1 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums13checked_isqrtCsltPpk0pe160_11int_ops_i16(i16 %self) #17
  %2 = extractvalue { i16, i16 } %1, 0
  %3 = extractvalue { i16, i16 } %1, 1
  store i16 %2, ptr %_2, align 2
  %4 = getelementptr inbounds i8, ptr %_2, i64 2
  store i16 %3, ptr %4, align 2
  %5 = load i16, ptr %_2, align 2
  %6 = getelementptr inbounds i8, ptr %_2, i64 2
  %7 = load i16, ptr %6, align 2
  %_3 = zext i16 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 2
  %sqrt = load i16, ptr %9, align 2
  ret i16 %sqrt

bb3:                                              ; preds = %start
; call core::num::imp::int_sqrt::panic_for_negative_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i16>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums8abs_diffCsltPpk0pe160_11int_ops_i16(i16 %self, i16 %other) unnamed_addr #0 !guid !141 {
start:
  %_0 = alloca [2 x i8], align 2
  %_3 = icmp slt i16 %self, %other
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_0.i1 = sub i16 %self, %other
  store i16 %_0.i1, ptr %_0, align 2
  br label %bb3

bb1:                                              ; preds = %start
  %_0.i = sub i16 %other, %self
  store i16 %_0.i, ptr %_0, align 2
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load i16, ptr %_0, align 2
  ret i16 %0
}

; <i16>::shl_exact
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums9shl_exactCsltPpk0pe160_11int_ops_i16(i16 %self, i32 %rhs) unnamed_addr #0 !guid !142 {
start:
  %_0 = alloca [4 x i8], align 2
  %0 = call i16 @llvm.ctlz.i16(i16 %self, i1 false)
  %_0.i.i = zext i16 %0 to i32
  %_3 = icmp ult i32 %rhs, %_0.i.i
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_2.i.i = xor i16 %self, -1
  %1 = call i16 @llvm.ctlz.i16(i16 %_2.i.i, i1 false)
  %_0.i1.i = zext i16 %1 to i32
  %_5 = icmp ult i32 %rhs, %_0.i1.i
  br i1 %_5, label %bb4, label %bb6

bb4:                                              ; preds = %bb2, %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit

bb2.i:                                            ; preds = %bb4
; call <i16>::unchecked_shl::precondition_check
  call void @_RNvNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl18precondition_checkCsltPpk0pe160_11int_ops_i16(i32 %rhs, ptr align 8 @alloc_49ab7e7c421882b397e0500c1648bb06) #22
  br label %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit

_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit: ; preds = %bb4, %bb2.i
  %2 = trunc nuw i32 %rhs to i16
  %_0.i = shl i16 %self, %2
  %3 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %_0.i, ptr %3, align 2
  store i16 1, ptr %_0, align 2
  br label %bb7

bb6:                                              ; preds = %bb2
  store i16 0, ptr %_0, align 2
  br label %bb7

bb7:                                              ; preds = %_RNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl.exit, %bb6
  %4 = load i16, ptr %_0, align 2
  %5 = getelementptr inbounds i8, ptr %_0, i64 2
  %6 = load i16, ptr %5, align 2
  %7 = insertvalue { i16, i16 } poison, i16 %4, 0
  %8 = insertvalue { i16, i16 } %7, i16 %6, 1
  ret { i16, i16 } %8
}

; <i16>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsn_NtCsl10jNU3mE6R_4core3nums14from_str_radixCsltPpk0pe160_11int_ops_i16(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !143 {
start:
  %0 = alloca [4 x i8], align 4
  %_0 = alloca [4 x i8], align 2
  %1 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %2, 0
  %_3.1 = extractvalue { ptr, i64 } %2, 1
; call <i16>::from_ascii_bytes_radix_impl
  %3 = call i32 @_RNvMsn_NtCsl10jNU3mE6R_4core3nums27from_ascii_bytes_radix_implCsltPpk0pe160_11int_ops_i16(ptr %_3.0, i64 %_3.1, i32 %radix) #17
  store i32 %3, ptr %0, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %_0, ptr align 4 %0, i64 4, i1 false)
  %4 = load i32, ptr %_0, align 2
  ret i32 %4
}

; <i16>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsn_NtCsl10jNU3mE6R_4core3nums27from_ascii_bytes_radix_implCsltPpk0pe160_11int_ops_i16(ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !144 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [4 x i8], align 2
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [4 x i8], align 2
  %_74 = alloca [4 x i8], align 2
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [4 x i8], align 2
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [2 x i8], align 2
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_0 = alloca [4 x i8], align 2
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #23
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #17
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  %4 = load i32, ptr %_0, align 2
  ret i32 %4

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %5 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  store i64 %src.1, ptr %6, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %7 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %8 = load i8, ptr %7, align 1
  switch i8 %8, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %9 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %rest.1, ptr %10, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %11 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %12 = sub i64 %src.1, 1
  store ptr %11, ptr %rest, align 8
  %13 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %12, ptr %13, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %14 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %14 to i1
  %15 = getelementptr inbounds i8, ptr %_12, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = getelementptr inbounds i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  store ptr %16, ptr %digits, align 8, !captures !145
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %18, ptr %19, align 8
  store i16 0, ptr %result, align 2
  %_24.0 = load ptr, ptr %digits, align 8
  %20 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %20, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowsECsltPpk0pe160_11int_ops_i16.exit

bb1.i:                                            ; preds = %bb15
  %21 = icmp ule i64 %_24.1, 3
  %22 = zext i1 %21 to i8
  store i8 %22, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowsECsltPpk0pe160_11int_ops_i16.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowsECsltPpk0pe160_11int_ops_i16.exit: ; preds = %bb2.i, %bb1.i
  %23 = load i8, ptr %_0.i, align 1
  %24 = trunc nuw i8 %23 to i1
  br i1 %24, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %25 = load ptr, ptr %rest, align 8
  %26 = getelementptr inbounds i8, ptr %rest, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %25, ptr %28, align 8
  %29 = getelementptr inbounds i8, ptr %28, i64 8
  store i64 %27, ptr %29, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowsECsltPpk0pe160_11int_ops_i16.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowsECsltPpk0pe160_11int_ops_i16.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %30 = load ptr, ptr %digits, align 8
  %31 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %31, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %32 = load ptr, ptr %digits, align 8
  %33 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %33, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i16, ptr %result, align 2
  %34 = getelementptr inbounds i8, ptr %_0, i64 2
  store i16 %_105, ptr %34, align 2
  store i8 0, ptr %_0, align 2
  br label %bb53

bb42:                                             ; preds = %bb41
  %35 = load ptr, ptr %digits, align 8
  %36 = getelementptr inbounds i8, ptr %digits, i64 8
  %37 = load i64, ptr %36, align 8
  %c = getelementptr inbounds nuw i8, ptr %35, i64 0
  %38 = load ptr, ptr %digits, align 8
  %39 = getelementptr inbounds i8, ptr %digits, i64 8
  %40 = load i64, ptr %39, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %38, i64 1
  %rest.13 = sub i64 %40, 1
  %_85 = load i16, ptr %result, align 2
  %_86 = trunc i32 %radix to i16
; call <i16>::checked_mul
  %41 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_mulCsltPpk0pe160_11int_ops_i16(i16 %_85, i16 %_86) #17
  %42 = extractvalue { i16, i16 } %41, 0
  %43 = extractvalue { i16, i16 } %41, 1
  store i16 %42, ptr %mul1, align 2
  %44 = getelementptr inbounds i8, ptr %mul1, i64 2
  store i16 %43, ptr %44, align 2
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %45 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsltPpk0pe160_11int_ops_i16(i32 %_89, i32 %radix) #17
  %46 = extractvalue { i32, i32 } %45, 0
  %47 = extractvalue { i32, i32 } %45, 1
  store i32 %46, ptr %_88, align 4
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %47, ptr %48, align 4
  %49 = load i32, ptr %_88, align 4
  %50 = getelementptr inbounds i8, ptr %_88, i64 4
  %51 = load i32, ptr %50, align 4
  %_91 = zext i32 %49 to i64
  %52 = trunc nuw i64 %_91 to i1
  br i1 %52, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %53, align 4
  %x = trunc i32 %value to i16
  %54 = load i16, ptr %mul1, align 2
  %55 = getelementptr inbounds i8, ptr %mul1, i64 2
  %56 = load i16, ptr %55, align 2
  %_95 = zext i16 %54 to i64
  %57 = trunc nuw i64 %_95 to i1
  br i1 %57, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %58 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %58, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb48:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %mul1, i64 2
  %value4 = load i16, ptr %59, align 2
  store i16 %value4, ptr %result, align 2
  %_100 = load i16, ptr %result, align 2
; call <i16>::checked_sub
  %60 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_subCsltPpk0pe160_11int_ops_i16(i16 %_100, i16 %x) #17
  %61 = extractvalue { i16, i16 } %60, 0
  %62 = extractvalue { i16, i16 } %60, 1
  store i16 %61, ptr %_99, align 2
  %63 = getelementptr inbounds i8, ptr %_99, i64 2
  store i16 %62, ptr %63, align 2
  %64 = load i16, ptr %_99, align 2
  %65 = getelementptr inbounds i8, ptr %_99, i64 2
  %66 = load i16, ptr %65, align 2
  %_101 = zext i16 %64 to i64
  %67 = trunc nuw i64 %_101 to i1
  br i1 %67, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %68 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %68, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb51:                                             ; preds = %bb48
  %69 = getelementptr inbounds i8, ptr %_99, i64 2
  %value5 = load i16, ptr %69, align 2
  store i16 %value5, ptr %result, align 2
  store ptr %rest.02, ptr %digits, align 8, !captures !145
  %70 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %70, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %71 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %71, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb31:                                             ; preds = %bb30
  %72 = load ptr, ptr %digits, align 8
  %73 = getelementptr inbounds i8, ptr %digits, i64 8
  %74 = load i64, ptr %73, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %72, i64 0
  %75 = load ptr, ptr %digits, align 8
  %76 = getelementptr inbounds i8, ptr %digits, i64 8
  %77 = load i64, ptr %76, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %75, i64 1
  %rest.18 = sub i64 %77, 1
  %_60 = load i16, ptr %result, align 2
  %_61 = trunc i32 %radix to i16
; call <i16>::checked_mul
  %78 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_mulCsltPpk0pe160_11int_ops_i16(i16 %_60, i16 %_61) #17
  %79 = extractvalue { i16, i16 } %78, 0
  %80 = extractvalue { i16, i16 } %78, 1
  store i16 %79, ptr %mul, align 2
  %81 = getelementptr inbounds i8, ptr %mul, i64 2
  store i16 %80, ptr %81, align 2
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %82 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsltPpk0pe160_11int_ops_i16(i32 %_64, i32 %radix) #17
  %83 = extractvalue { i32, i32 } %82, 0
  %84 = extractvalue { i32, i32 } %82, 1
  store i32 %83, ptr %_63, align 4
  %85 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %84, ptr %85, align 4
  %86 = load i32, ptr %_63, align 4
  %87 = getelementptr inbounds i8, ptr %_63, i64 4
  %88 = load i32, ptr %87, align 4
  %_66 = zext i32 %86 to i64
  %89 = trunc nuw i64 %_66 to i1
  br i1 %89, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %90 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %90, align 4
  %x10 = trunc i32 %value9 to i16
  %91 = load i16, ptr %mul, align 2
  %92 = getelementptr inbounds i8, ptr %mul, i64 2
  %93 = load i16, ptr %92, align 2
  %_70 = zext i16 %91 to i64
  %94 = trunc nuw i64 %_70 to i1
  br i1 %94, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %95 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %95, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb37:                                             ; preds = %bb35
  %96 = getelementptr inbounds i8, ptr %mul, i64 2
  %value11 = load i16, ptr %96, align 2
  store i16 %value11, ptr %result, align 2
  %_75 = load i16, ptr %result, align 2
; call <i16>::checked_add
  %97 = call { i16, i16 } @_RNvMs_NtCsl10jNU3mE6R_4core3nums11checked_addCsltPpk0pe160_11int_ops_i16(i16 %_75, i16 %x10) #17
  %98 = extractvalue { i16, i16 } %97, 0
  %99 = extractvalue { i16, i16 } %97, 1
  store i16 %98, ptr %_74, align 2
  %100 = getelementptr inbounds i8, ptr %_74, i64 2
  store i16 %99, ptr %100, align 2
  %101 = load i16, ptr %_74, align 2
  %102 = getelementptr inbounds i8, ptr %_74, i64 2
  %103 = load i16, ptr %102, align 2
  %_76 = zext i16 %101 to i64
  %104 = trunc nuw i64 %_76 to i1
  br i1 %104, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %105 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %105, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb40:                                             ; preds = %bb37
  %106 = getelementptr inbounds i8, ptr %_74, i64 2
  %value12 = load i16, ptr %106, align 2
  store i16 %value12, ptr %result, align 2
  store ptr %rest.07, ptr %digits, align 8, !captures !145
  %107 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %107, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %108 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %108, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %109 = load ptr, ptr %digits, align 8
  %110 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %110, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %111 = load ptr, ptr %digits, align 8
  %112 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %112, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %113 = load ptr, ptr %digits, align 8
  %114 = getelementptr inbounds i8, ptr %digits, i64 8
  %115 = load i64, ptr %114, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %113, i64 0
  %116 = load ptr, ptr %digits, align 8
  %117 = getelementptr inbounds i8, ptr %digits, i64 8
  %118 = load i64, ptr %117, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %116, i64 1
  %rest.115 = sub i64 %118, 1
  %_44 = load i16, ptr %result, align 2
  %_45 = trunc i32 %radix to i16
  %119 = mul i16 %_44, %_45
  store i16 %119, ptr %result, align 2
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %120 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsltPpk0pe160_11int_ops_i16(i32 %_47, i32 %radix) #17
  %121 = extractvalue { i32, i32 } %120, 0
  %122 = extractvalue { i32, i32 } %120, 1
  store i32 %121, ptr %_46, align 4
  %123 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %122, ptr %123, align 4
  %124 = load i32, ptr %_46, align 4
  %125 = getelementptr inbounds i8, ptr %_46, i64 4
  %126 = load i32, ptr %125, align 4
  %_49 = zext i32 %124 to i64
  %127 = trunc nuw i64 %_49 to i1
  br i1 %127, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %128 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %128, align 4
  %_53 = load i16, ptr %result, align 2
  %_54 = trunc i32 %x16 to i16
  %129 = sub i16 %_53, %_54
  store i16 %129, ptr %result, align 2
  store ptr %rest.014, ptr %digits, align 8, !captures !145
  %130 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %130, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %131 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %131, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb19:                                             ; preds = %bb18
  %132 = load ptr, ptr %digits, align 8
  %133 = getelementptr inbounds i8, ptr %digits, i64 8
  %134 = load i64, ptr %133, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %132, i64 0
  %135 = load ptr, ptr %digits, align 8
  %136 = getelementptr inbounds i8, ptr %digits, i64 8
  %137 = load i64, ptr %136, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %135, i64 1
  %rest.119 = sub i64 %137, 1
  %_29 = load i16, ptr %result, align 2
  %_30 = trunc i32 %radix to i16
  %138 = mul i16 %_29, %_30
  store i16 %138, ptr %result, align 2
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %139 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsltPpk0pe160_11int_ops_i16(i32 %_32, i32 %radix) #17
  %140 = extractvalue { i32, i32 } %139, 0
  %141 = extractvalue { i32, i32 } %139, 1
  store i32 %140, ptr %_31, align 4
  %142 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %141, ptr %142, align 4
  %143 = load i32, ptr %_31, align 4
  %144 = getelementptr inbounds i8, ptr %_31, i64 4
  %145 = load i32, ptr %144, align 4
  %_34 = zext i32 %143 to i64
  %146 = trunc nuw i64 %_34 to i1
  br i1 %146, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %147 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %147, align 4
  %_38 = load i16, ptr %result, align 2
  %_39 = trunc i32 %x20 to i16
  %148 = add i16 %_38, %_39
  store i16 %148, ptr %result, align 2
  store ptr %rest.018, ptr %digits, align 8, !captures !145
  %149 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %149, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %150 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %150, align 1
  store i8 1, ptr %_0, align 2
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsltPpk0pe160_11int_ops_i16(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !146 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsltPpk0pe160_11int_ops_i16(ptr align 8 %args) #17
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #17
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsltPpk0pe160_11int_ops_i16() unnamed_addr #4 !guid !147 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() unnamed_addr #0 !guid !148 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsltPpk0pe160_11int_ops_i16(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !149 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCsltPpk0pe160_11int_ops_i16(i32 %code, ptr %dst) unnamed_addr #0 !guid !150 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CsltPpk0pe160_11int_ops_i16(i32 %code) #17
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8CsltPpk0pe160_11int_ops_i16(i32 %code) unnamed_addr #0 !guid !151 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::num::imp::int_sqrt::u16_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsltPpk0pe160_11int_ops_i16(i16 %n) unnamed_addr #0 !guid !152 {
start:
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n1 = lshr i16 %n, 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.421479f5fa7fa7140547dc2779d71c6c.0, i64 512, i1 false)
  %_9 = zext i16 %n1 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s2 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s2, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsltPpk0pe160_11int_ops_i16() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsltPpk0pe160_11int_ops_i16(i1 zeroext %_12, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb1, %bb2.i
  %lo = and i16 %n, 255
  %_16 = zext i8 %r to i16
  %_15 = shl i16 %_16, 4
  %_17 = lshr i16 %lo, 4
  %numerator = or i16 %_15, %_17
  %_19 = zext i8 %s2 to i16
  %denominator = shl i16 %_19, 1
  %_21 = icmp eq i16 %denominator, 0
  br i1 %_21, label %panic3, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q = udiv i16 %numerator, %denominator
  %_24 = shl i8 %s2, 4
  %_23 = zext i8 %_24 to i16
  %3 = add i16 %_23, %q
  store i16 %3, ptr %s, align 2
  %_28 = load i16, ptr %s, align 2
  %_29 = load i16, ptr %s, align 2
  %4 = call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %_28, i16 %_29)
  %_5.0.i = extractvalue { i16, i1 } %4, 0
  %_5.1.i = extractvalue { i16, i1 } %4, 1
  %_27.0 = extractvalue { i16, i1 } %4, 0
  %_27.1 = extractvalue { i16, i1 } %4, 1
  br i1 %_27.1, label %bb6, label %bb5

panic3:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_73a63def61abd19c5b285b7e5bba6f74) #23
  unreachable

bb5:                                              ; preds = %bb3
  %_30 = icmp ugt i16 %_27.0, %n
  br i1 %_30, label %bb6, label %bb7

bb6:                                              ; preds = %bb5, %bb3
  %5 = load i16, ptr %s, align 2
  %6 = sub i16 %5, 1
  store i16 %6, ptr %s, align 2
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5
  %_0 = load i16, ptr %s, align 2
  ret i16 %_0
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsltPpk0pe160_11int_ops_i16(i8 %n) unnamed_addr #0 !guid !153 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.421479f5fa7fa7140547dc2779d71c6c.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #23
  unreachable
}

; core::num::imp::int_sqrt::u16
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsltPpk0pe160_11int_ops_i16(i16 %0) unnamed_addr #0 !guid !154 {
start:
  %_0 = alloca [2 x i8], align 2
  %n = alloca [2 x i8], align 2
  store i16 %0, ptr %n, align 2
  %_3 = load i16, ptr %n, align 2
  %_2 = icmp ule i16 %_3, 255
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i16, ptr %n, align 2
  %1 = call i16 @llvm.ctlz.i16(i16 %_10, i1 false)
  %_0.i = zext i16 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i16, ptr %n, align 2
  %3 = and i32 %normalization_shift, 15
  %4 = trunc i32 %3 to i16
  %5 = shl i16 %2, %4
  store i16 %5, ptr %n, align 2
  %_12 = load i16, ptr %n, align 2
; call core::num::imp::int_sqrt::u16_stages
  %s = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsltPpk0pe160_11int_ops_i16(i16 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 15
  %7 = trunc i32 %6 to i16
  %8 = lshr i16 %s, %7
  store i16 %8, ptr %_0, align 2
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i16, ptr %n, align 2
  %_6 = trunc i16 %_7 to i8
; call core::num::imp::int_sqrt::u8
  %_5 = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsltPpk0pe160_11int_ops_i16(i8 %_6) #17
  %9 = zext i8 %_5 to i16
  store i16 %9, ptr %_0, align 2
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i16, ptr %_0, align 2
  ret i16 %10
}

; <u16>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs5_NtCsl10jNU3mE6R_4core3numt13unchecked_mul18precondition_checkCsltPpk0pe160_11int_ops_i16(i16 %lhs, i16 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !155 {
start:
  %1 = call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %lhs, i16 %rhs)
  %_5.0.i = extractvalue { i16, i1 } %1, 0
  %_5.1.i = extractvalue { i16, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i16, i1 } %1, 0
  %_4.1 = extractvalue { i16, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsltPpk0pe160_11int_ops_i16(ptr @alloc_d7d2674a3c536086aba62154183f0b5b, i64 184)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <i16>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shl18precondition_checkCsltPpk0pe160_11int_ops_i16(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !156 {
start:
  %_2 = icmp ult i32 %rhs, 16
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsltPpk0pe160_11int_ops_i16(ptr @alloc_e1a24811cdb375c477cf3d451bcd3796, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <i16>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCsl10jNU3mE6R_4core3nums13unchecked_shr18precondition_checkCsltPpk0pe160_11int_ops_i16(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !157 {
start:
  %_2 = icmp ult i32 %rhs, 16
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsltPpk0pe160_11int_ops_i16(ptr @alloc_e65ffe7b88dc1d61e3cfb242ac596984, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsltPpk0pe160_11int_ops_i16(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !158 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsltPpk0pe160_11int_ops_i16(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsltPpk0pe160_11int_ops_i16() unnamed_addr #0 !guid !159 {
start:
  ret i1 true
}

; <(i16, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTsbENtB6_5Debug3fmtCsltPpk0pe160_11int_ops_i16(ptr align 2 %self, ptr align 8 %f) unnamed_addr #1 !guid !160 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 2
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <i16 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1I_NtCs7CppTae75M1_5alloc6stringsNtB6_12SpecToString14spec_to_stringCsltPpk0pe160_11int_ops_i16(ptr sret([24 x i8]) align 8 %_0, ptr align 2 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !161 {
start:
  %0 = alloca [16 x i8], align 8
  %_19 = alloca [1 x i8], align 1
  %_11 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  %out = alloca [24 x i8], align 8
  %buf = alloca [5 x i8], align 1
  store i8 0, ptr %_19, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 5, i1 false)
  %_6 = load i16, ptr %self, align 2
  %_5 = icmp slt i16 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCsltPpk0pe160_11int_ops_i16(ptr sret([24 x i8]) align 8 %_11, i64 5)
          to label %bb5 unwind label %cleanup

bb2:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCsltPpk0pe160_11int_ops_i16(ptr sret([24 x i8]) align 8 %_7, i64 6)
          to label %bb3 unwind label %cleanup

bb12:                                             ; preds = %cleanup
  %1 = load i8, ptr %_19, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb11, label %bb10

cleanup:                                          ; preds = %bb8, %bb7, %bb6, %bb3, %bb2, %bb4
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb12

bb5:                                              ; preds = %bb4
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_11, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb13, %bb5
  %_16 = load i16, ptr %self, align 2
; invoke <i16>::unsigned_abs
  %_15 = invoke i16 @_RNvMs_NtCsl10jNU3mE6R_4core3nums12unsigned_absCsltPpk0pe160_11int_ops_i16(i16 %_16)
          to label %bb7 unwind label %cleanup

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_7, i64 24, i1 false)
; invoke <alloc::string::String>::push
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCsltPpk0pe160_11int_ops_i16(ptr align 8 %out, i32 45)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb3
  br label %bb6

bb7:                                              ; preds = %bb6
; invoke <u16>::_fmt
  %7 = invoke { ptr, i64 } @_RNvMs5_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impt4__fmt(i16 %_15, ptr %buf, i64 5)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %_14.0 = extractvalue { ptr, i64 } %7, 0
  %_14.1 = extractvalue { ptr, i64 } %7, 1
; invoke <alloc::string::String>::push_str
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCsltPpk0pe160_11int_ops_i16(ptr align 8 %out, ptr %_14.0, i64 %_14.1)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %out, i64 24, i1 false)
  store i8 0, ptr %_19, align 1
  ret void

bb10:                                             ; preds = %bb11, %bb12
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb11:                                             ; preds = %bb12
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %out) #24
          to label %bb10 unwind label %terminate

terminate:                                        ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsltPpk0pe160_11int_ops_i16(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !162 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsltPpk0pe160_11int_ops_i16(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsltPpk0pe160_11int_ops_i16(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !163 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsltPpk0pe160_11int_ops_i16(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <i16 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringsNtB5_8ToString9to_stringCsltPpk0pe160_11int_ops_i16(ptr sret([24 x i8]) align 8 %_0, ptr align 2 %self) unnamed_addr #0 !guid !164 {
start:
; call <i16 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1I_NtCs7CppTae75M1_5alloc6stringsNtB6_12SpecToString14spec_to_stringCsltPpk0pe160_11int_ops_i16(ptr sret([24 x i8]) align 8 %_0, ptr align 2 %self) #17
  ret void
}

; <core::option::Option<i16> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionsENtNtB7_3fmt5Debug3fmtCsltPpk0pe160_11int_ops_i16(ptr align 2 %self, ptr align 8 %f) unnamed_addr #0 !guid !165 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i16, ptr %self, align 2
  %1 = getelementptr inbounds i8, ptr %self, i64 2
  %2 = load i16, ptr %1, align 2
  %_3 = zext i16 %0 to i64
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 2
  store ptr %4, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.1)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsltPpk0pe160_11int_ops_i16() unnamed_addr #0 !guid !166 {
start:
  ret i8 0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsltPpk0pe160_11int_ops_i16(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !167 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsltPpk0pe160_11int_ops_i16(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !168 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <i16 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXsm_NtCsl10jNU3mE6R_4core3numsNtNtNtB7_3str6traits7FromStr8from_strCsltPpk0pe160_11int_ops_i16(ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !169 {
start:
  %0 = alloca [4 x i8], align 4
  %_0 = alloca [4 x i8], align 2
; call <i16>::from_str_radix
  %1 = call i32 @_RNvMsn_NtCsl10jNU3mE6R_4core3nums14from_str_radixCsltPpk0pe160_11int_ops_i16(ptr %src.0, i64 %src.1, i32 10) #17
  store i32 %1, ptr %0, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %_0, ptr align 4 %0, i64 4, i1 false)
  %2 = load i32, ptr %_0, align 2
  ret i32 %2
}

; <core::result::Result<i16, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultsNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsltPpk0pe160_11int_ops_i16(ptr align 2 %self, ptr align 8 %f) unnamed_addr #0 !guid !170 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 2
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 2
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsltPpk0pe160_11int_ops_i16(ptr %_1) unnamed_addr #0 !guid !171 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsltPpk0pe160_11int_ops_i16(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !172 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsltPpk0pe160_11int_ops_i16(ptr align 8 %_1) #17
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <i16 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsj_NtNtCsl10jNU3mE6R_4core3fmt3numsNtB7_6Binary3fmt(ptr align 2, ptr align 8) unnamed_addr #1

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i16 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt(ptr align 2, ptr align 8) unnamed_addr #1

; <i16 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsn_NtNtCsl10jNU3mE6R_4core3fmt3numsNtB7_8LowerHex3fmt(ptr align 2, ptr align 8) unnamed_addr #1

; <i16 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsp_NtNtCsl10jNU3mE6R_4core3fmt3numsNtB7_8UpperHex3fmt(ptr align 2, ptr align 8) unnamed_addr #1

; <i16 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsl_NtNtCsl10jNU3mE6R_4core3fmt3numsNtB7_5Octal3fmt(ptr align 2, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshr.i16(i16, i16, i16) #9

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<u16>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaytEB7_(ptr sret([16 x i8]) align 8, ptr align 2) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fptosi.sat.i16.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.smul.with.overflow.i16(i16, i16) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <alloc::vec::Vec<u8>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8, i64) unnamed_addr #1

; <alloc::vec::Vec<u8>>::extend_from_slice
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8, ptr, i64) unnamed_addr #1

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctpop.i16(i16) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bitreverse.i16(i16) #9

; <core::num::nonzero::NonZero<u16>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i16 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE3newB9_(i16) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctlz.i16(i16, i1 immarg) #10

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.cttz.i16(i16, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.umul.with.overflow.i16(i16, i16) #9

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; <core::num::nonzero::NonZero<u16>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i16 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerotE3getB9_(i16) unnamed_addr #0

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #11

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i16(i16) #12

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.sadd.sat.i16(i16, i16) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ssub.sat.i16(i16, i16) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.sadd.with.overflow.i16(i16, i16) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.ssub.with.overflow.i16(i16, i16) #9

; core::num::imp::int_sqrt::panic_for_negative_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt27panic_for_negative_argument(ptr align 8) unnamed_addr #11

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #13

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #14

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <&i16 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRsNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #15

; <u16>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMs5_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impt4__fmt(i16, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #16 !guid !173 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsltPpk0pe160_11int_ops_i16(ptr @_RNvCsltPpk0pe160_11int_ops_i164main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #13 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #16 = { nonlazybind "target-cpu"="x86-64" }
attributes #17 = { inlinehint }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noreturn }
attributes #20 = { noinline }
attributes #21 = { nounwind }
attributes #22 = { inlinehint nounwind }
attributes #23 = { noinline noreturn }
attributes #24 = { cold }
attributes #25 = { noinline noreturn nounwind }

!llvm.module.flags = !{!57, !58, !59, !60}
!llvm.ident = !{!61}

!0 = !{i64 -5637388563590928101}
!1 = !{i64 2430623177492588027}
!2 = !{i64 -659379387744328141}
!3 = !{i64 7461390380137873186}
!4 = !{i64 -3951744542246813373}
!5 = !{i64 -9165373206615201350}
!6 = !{i64 -90891566105136963}
!7 = !{i64 475812658989614176}
!8 = !{i64 -7896049184310716191}
!9 = !{i64 -5954819436208798038}
!10 = !{i64 3683434523018090655}
!11 = !{i64 4289670787595317832}
!12 = !{i64 5769915186068249771}
!13 = !{i64 -53777636300098172}
!14 = !{i64 7833255755317681712}
!15 = !{i64 -4121755057492930052}
!16 = !{i64 8963775347160206745}
!17 = !{i64 -5782370445005327398}
!18 = !{i64 6736027821172045020}
!19 = !{i64 -3024555304831652183}
!20 = !{i64 3831010800954638325}
!21 = !{i64 783242364635249072}
!22 = !{i64 6477348178063039006}
!23 = !{i64 -8885404782942550028}
!24 = !{i64 2786268213045469653}
!25 = !{i64 -4750661813368130357}
!26 = !{i64 -8559092232092113032}
!27 = !{i64 -1301695162559740468}
!28 = !{i64 3752126468515826367}
!29 = !{i64 8825141555795171120}
!30 = !{i64 626127568824213616}
!31 = !{i64 2098463914998743413}
!32 = !{i64 7116447695444320715}
!33 = !{i64 -1891853304622669126}
!34 = !{i64 -8276022678305671213}
!35 = !{i64 5195548123588981206}
!36 = !{i64 7290096798945957336}
!37 = !{i64 8118354063482960450}
!38 = !{i64 -4122838188301270159}
!39 = !{i64 5966594246698131022}
!40 = !{i64 5214330410196589015}
!41 = !{i64 -4063141679055992491}
!42 = !{i64 -3912143489970575971}
!43 = !{i64 1357616160684637843}
!44 = !{i64 4280196114561223706}
!45 = !{i64 179329291307659978}
!46 = !{i64 -7969822321255135778}
!47 = !{i64 8193961899745377160}
!48 = !{i64 3901653904438318586}
!49 = !{i64 -9033122780337630714}
!50 = !{i64 -7651292425592638717}
!51 = !{i64 -5069897037787063994}
!52 = !{i64 6343430411326030847}
!53 = !{i64 2041248530170144662}
!54 = !{i64 635723138658984739}
!55 = !{i64 4837358007606272282}
!56 = !{i64 3775700589219167520}
!57 = !{i32 8, !"PIC Level", i32 2}
!58 = !{i32 7, !"PIE Level", i32 2}
!59 = !{i32 2, !"RtLibUseGOT", i32 1}
!60 = !{i32 7, !"uwtable", i32 2}
!61 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!62 = !{i64 -3339272641124102925}
!63 = !{i64 -1323772931666144244}
!64 = !{i64 -321081484275953859}
!65 = !{i64 -8772594112090398904}
!66 = !{i64 -4745309380035972799}
!67 = !{i64 -3106661572712882920}
!68 = !{i64 3628307473947873034}
!69 = !{i64 6501188601331843032}
!70 = !{i64 8301806102985375022}
!71 = !{i64 2474251895314547972}
!72 = !{i64 -6610343617588762917}
!73 = !{i64 -4962904063084017623}
!74 = !{i64 -7554004072388172133}
!75 = !{i64 8705554419093856474}
!76 = !{i64 -1268316928277029223}
!77 = !{i64 8855153931752253642}
!78 = !{i64 -5935617369205600226}
!79 = !{i64 -6286923264786648805}
!80 = !{i64 -2437548260452225828}
!81 = !{i64 -3709674993751500145}
!82 = !{i64 -7601219018198418619}
!83 = !{i64 828731099964859631}
!84 = !{i64 3723323105159901742}
!85 = !{i64 -7235879462907176650}
!86 = !{i64 8975852668013349073}
!87 = !{i64 2879313691064052923}
!88 = !{i64 -1872576212981173321}
!89 = !{i64 1318421816192758}
!90 = !{i64 3277386315263743855}
!91 = !{i64 8272143097465163402}
!92 = !{i64 447853910519443287}
!93 = !{i64 678818767009385014}
!94 = !{i64 4295905415914329611}
!95 = !{i64 3101490053705543325}
!96 = !{i64 -8197241728076780494}
!97 = !{i64 -7397496341751789174}
!98 = !{i64 -990965010527376999}
!99 = !{i64 7872568223441357227}
!100 = !{i64 -3180471387524892302}
!101 = !{i64 1769388263463162396}
!102 = !{i64 -8201788702860432926}
!103 = !{i64 -2299224251994717079}
!104 = !{i64 6632063509403290256}
!105 = !{i64 -5522854439712338709}
!106 = !{i64 -3464464973255466648}
!107 = !{i64 6599406731901920303}
!108 = !{i64 -799802967667447246}
!109 = !{i64 3172281107788980703}
!110 = !{i64 -2280213608384347632}
!111 = !{i64 7368746034301732867}
!112 = !{i64 -5883293266275289635}
!113 = !{i64 7806456553217878815}
!114 = !{i64 -4547119643921716541}
!115 = !{i64 -4229286893898125718}
!116 = !{i64 -8308126377654229913}
!117 = !{i64 4214749531842732629}
!118 = !{i64 -7195770761210580286}
!119 = !{i64 -4495812346614412448}
!120 = !{i64 5591132705163665716}
!121 = !{i64 3512235095995448634}
!122 = !{i64 -1264147812502108211}
!123 = !{i64 -1961659792833810866}
!124 = !{i64 -4784784881868884465}
!125 = !{i64 -1225293976872716920}
!126 = !{i64 -1639756535604809019}
!127 = !{i64 -955145286574330288}
!128 = !{i64 8206922303075182931}
!129 = !{i64 -8581156114990435150}
!130 = !{i64 7923863176088584493}
!131 = !{i64 5862676786309381340}
!132 = !{i64 1908007490614416220}
!133 = !{i64 38721189199941344}
!134 = !{i64 1603215282839877216}
!135 = !{i64 5402857142921745933}
!136 = !{i64 1954227521508366767}
!137 = !{i64 7000441828448710946}
!138 = !{i64 -7390624934827047452}
!139 = !{i64 -1695662787210728913}
!140 = !{i64 6940197458413183341}
!141 = !{i64 -5096948237401074030}
!142 = !{i64 -7769716892404977961}
!143 = !{i64 3060971310120043273}
!144 = !{i64 2418965560124697819}
!145 = !{!"address", !"read_provenance"}
!146 = !{i64 -5326528375107888323}
!147 = !{i64 -1866003354478751450}
!148 = !{i64 -567053237258837794}
!149 = !{i64 2200177924694629464}
!150 = !{i64 -4870918287647788362}
!151 = !{i64 -5327643284869254411}
!152 = !{i64 -7355341216114868397}
!153 = !{i64 3959708407305436076}
!154 = !{i64 -4852830474082328721}
!155 = !{i64 6167867360527115140}
!156 = !{i64 3590796985832815411}
!157 = !{i64 4755331464758495447}
!158 = !{i64 -4310912478150755018}
!159 = !{i64 -4607328414076043505}
!160 = !{i64 3792923249425590065}
!161 = !{i64 2145081006640310499}
!162 = !{i64 -1603189006942827137}
!163 = !{i64 7699361445139103752}
!164 = !{i64 3855570933024776317}
!165 = !{i64 -5019901587435295244}
!166 = !{i64 -7345846209242222955}
!167 = !{i64 -7498288064408766841}
!168 = !{i64 -5539882561404713021}
!169 = !{i64 9016579663745983223}
!170 = !{i64 6505307757853919645}
!171 = !{i64 -8034547579349085590}
!172 = !{i64 -4954755854604199541}
!173 = !{i64 -2624081020897602054}
