; ModuleID = 'panic_str_boundary.b24f40bc931b1828-cgu.0'
source_filename = "panic_str_boundary.b24f40bc931b1828-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsfj8xobPFoQC_18panic_str_boundary, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csfj8xobPFoQC_18panic_str_boundary, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csfj8xobPFoQC_18panic_str_boundary }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_dfa4a33a3c5680c5e1c3c89a28cb1d58 = private unnamed_addr constant [6 x i8] c"h\C3\A9llo", align 1, !guid !2
@alloc_4a293e754d48414adb29f4d171cc43c7 = private unnamed_addr constant [42 x i8] c"test/rust/synthetic/panic-str-boundary.rs\00", align 1, !guid !3
@alloc_3c3435af2da7348fbe8bf5f239a554b9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4a293e754d48414adb29f4d171cc43c7, [16 x i8] c")\00\00\00\00\00\00\00\06\00\00\00,\00\00\00" }>, align 8, !guid !4
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !5
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !6

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsfj8xobPFoQC_18panic_str_boundary(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !12 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECsfj8xobPFoQC_18panic_str_boundary(i64 %dummy) unnamed_addr #1 !guid !13 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !14
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsfj8xobPFoQC_18panic_str_boundary(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !15 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfj8xobPFoQC_18panic_str_boundary(ptr %f) #6
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #6
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csfj8xobPFoQC_18panic_str_boundary(ptr align 8 %_1) unnamed_addr #1 !guid !16 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsfj8xobPFoQC_18panic_str_boundary(ptr %_4) #7
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsfj8xobPFoQC_18panic_str_boundary() #6
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csfj8xobPFoQC_18panic_str_boundary(i8 %_2) #6
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsfj8xobPFoQC_18panic_str_boundary(ptr %_1) unnamed_addr #1 !guid !17 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfj8xobPFoQC_18panic_str_boundary(ptr %0) #6
  ret i32 %_0
}

; panic_str_boundary::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsfj8xobPFoQC_18panic_str_boundary4main() unnamed_addr #0 !guid !18 {
start:
  %_13 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_7 = alloca [16 x i8], align 8
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfj8xobPFoQC_18panic_str_boundary(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #6
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<usize>
  %_11 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECsfj8xobPFoQC_18panic_str_boundary(i64 2) #6
; call <str as core::ops::index::Index<core::ops::range::Range<usize>>>::index
  %1 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core3str6traitseINtNtNtB9_3ops5index5IndexINtNtBJ_5range5RangejEE5indexB9_(ptr @alloc_dfa4a33a3c5680c5e1c3c89a28cb1d58, i64 6, i64 0, i64 %_11, ptr align 8 @alloc_3c3435af2da7348fbe8bf5f239a554b9) #6
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  store ptr %_8.0, ptr %_7, align 8, !captures !19
  %2 = getelementptr inbounds i8, ptr %_7, i64 8
  store i64 %_8.1, ptr %2, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_13, ptr align 8 %_7) #6
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_13, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %4 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args) #6
  %_4.0 = extractvalue { ptr, ptr } %4, 0
  %_4.1 = extractvalue { ptr, ptr } %4, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_4.0, ptr %_4.1)
; call <core::fmt::Arguments>::from_str
  %5 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfj8xobPFoQC_18panic_str_boundary(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #6
  %_17.0 = extractvalue { ptr, ptr } %5, 0
  %_17.1 = extractvalue { ptr, ptr } %5, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_17.0, ptr %_17.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsfj8xobPFoQC_18panic_str_boundary(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !20 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfj8xobPFoQC_18panic_str_boundary(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !21 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsfj8xobPFoQC_18panic_str_boundary(ptr %s.0, i64 %s.1) #6
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csfj8xobPFoQC_18panic_str_boundary(ptr %self) unnamed_addr #1 !guid !22 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csfj8xobPFoQC_18panic_str_boundary(i8 %0) unnamed_addr #1 !guid !23 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csfj8xobPFoQC_18panic_str_boundary(ptr %self) #6
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsfj8xobPFoQC_18panic_str_boundary() unnamed_addr #1 !guid !24 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfj8xobPFoQC_18panic_str_boundary(ptr %_1) unnamed_addr #1 !guid !25 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfj8xobPFoQC_18panic_str_boundary(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !26 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csfj8xobPFoQC_18panic_str_boundary(ptr align 8 %_1) #6
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; <str as core::ops::index::Index<core::ops::range::Range<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core3str6traitseINtNtNtB9_3ops5index5IndexINtNtBJ_5range5RangejEE5indexB9_(ptr, i64, i64, i64, ptr align 8) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #5 !guid !27 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsfj8xobPFoQC_18panic_str_boundary(ptr @_RNvCsfj8xobPFoQC_18panic_str_boundary4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nonlazybind "target-cpu"="x86-64" }
attributes #6 = { inlinehint }
attributes #7 = { noinline }

!llvm.module.flags = !{!7, !8, !9, !10}
!llvm.ident = !{!11}

!0 = !{i64 -4579715499168396356}
!1 = !{i64 1442731414103840830}
!2 = !{i64 6946698069719270463}
!3 = !{i64 2639468803493784365}
!4 = !{i64 3490479376018350116}
!5 = !{i64 547362849133659624}
!6 = !{i64 6600424783968649197}
!7 = !{i32 8, !"PIC Level", i32 2}
!8 = !{i32 7, !"PIE Level", i32 2}
!9 = !{i32 2, !"RtLibUseGOT", i32 1}
!10 = !{i32 7, !"uwtable", i32 2}
!11 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!12 = !{i64 2141201588675247495}
!13 = !{i64 535440163459698611}
!14 = !{i64 1312851243608549}
!15 = !{i64 6900948717997511901}
!16 = !{i64 -6254340410986285064}
!17 = !{i64 5625697916640561860}
!18 = !{i64 2441232595965431814}
!19 = !{!"address", !"read_provenance"}
!20 = !{i64 -4408456068794156902}
!21 = !{i64 5482768850477321394}
!22 = !{i64 -1518381316337569419}
!23 = !{i64 2590599425027018730}
!24 = !{i64 6722148986777853049}
!25 = !{i64 445160579366379771}
!26 = !{i64 -5721775608375999474}
!27 = !{i64 -2624081020897602054}
