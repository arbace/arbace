; ModuleID = 'panic_str_boundary.b24f40bc931b1828-cgu.0'
source_filename = "panic_str_boundary.b24f40bc931b1828-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsfj8xobPFoQC_18panic_str_boundary, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csfj8xobPFoQC_18panic_str_boundary, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csfj8xobPFoQC_18panic_str_boundary }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_dfa4a33a3c5680c5e1c3c89a28cb1d58 = private unnamed_addr constant [6 x i8] c"h\C3\A9llo", align 1, !guid !2
@alloc_4a293e754d48414adb29f4d171cc43c7 = private unnamed_addr constant [42 x i8] c"test/rust/synthetic/panic-str-boundary.rs\00", align 1, !guid !3
@alloc_3c3435af2da7348fbe8bf5f239a554b9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4a293e754d48414adb29f4d171cc43c7, [16 x i8] c")\00\00\00\00\00\00\00\06\00\00\00,\00\00\00" }>, align 8, !guid !4
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !5
@alloc_7a21961256201792dd1bf82f2d8e6106 = private unnamed_addr constant [12 x i8] c"unreachable\0A", align 1, !guid !6
@alloc_ba36178d1927b1fd4e4d55688fcb3a85 = private unnamed_addr constant [23 x i8] c"core/src/str/traits.rs\00", align 1, !guid !7
@alloc_c9c77fb8302a991f111e158b4397f3ba = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba36178d1927b1fd4e4d55688fcb3a85, [16 x i8] c"\16\00\00\00\00\00\00\00\91\00\00\00'\00\00\00" }>, align 8, !guid !8
@alloc_6fc7f2fc23ff13b05be8f1dbacdceba5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba36178d1927b1fd4e4d55688fcb3a85, [16 x i8] c"\16\00\00\00\00\00\00\00\91\00\00\002\00\00\00" }>, align 8, !guid !9
@alloc_5bd2ae079a0ef89f8ce32de84418140a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba36178d1927b1fd4e4d55688fcb3a85, [16 x i8] c"\16\00\00\00\00\00\00\00\92\00\00\006\00\00\00" }>, align 8, !guid !10
@alloc_4d5f88b40b9f0400eb21d66cd0b8e085 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba36178d1927b1fd4e4d55688fcb3a85, [16 x i8] c"\16\00\00\00\00\00\00\00\92\00\00\00?\00\00\00" }>, align 8, !guid !11
@alloc_91f2a00ff2cd9cdc4bb205a66832e2bb = private unnamed_addr constant [219 x i8] c"unsafe precondition(s) violated: str::get_unchecked requires that the range is within the string slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !12
@alloc_9fa66abd1e8793df6d4778d0370e954f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ba36178d1927b1fd4e4d55688fcb3a85, [16 x i8] c"\16\00\00\00\00\00\00\00\0A\01\00\00\22\00\00\00" }>, align 8, !guid !13

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECsfj8xobPFoQC_18panic_str_boundary(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !19 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&str>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullReE8from_refCsfj8xobPFoQC_18panic_str_boundary(ptr align 8 %x) #10
; call <core::ptr::non_null::NonNull<&str>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullReE4castuECsfj8xobPFoQC_18panic_str_boundary(ptr %_4) #10
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtReNtB6_7Display3fmtCsfj8xobPFoQC_18panic_str_boundary, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<&str>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullReE4castuECsfj8xobPFoQC_18panic_str_boundary(ptr %self) unnamed_addr #0 !guid !20 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsfj8xobPFoQC_18panic_str_boundary(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !21 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsfj8xobPFoQC_18panic_str_boundary(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !22 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::ptr::slice_from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECsfj8xobPFoQC_18panic_str_boundary(ptr %data, i64 %len) unnamed_addr #0 !guid !23 {
start:
; call core::ptr::metadata::from_raw_parts::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECsfj8xobPFoQC_18panic_str_boundary(ptr %data, i64 %len) #10
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECsfj8xobPFoQC_18panic_str_boundary(i64 %dummy) unnamed_addr #0 !guid !24 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !25
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsfj8xobPFoQC_18panic_str_boundary() unnamed_addr #0 !guid !26 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !25
  ret void
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsfj8xobPFoQC_18panic_str_boundary(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !27 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfj8xobPFoQC_18panic_str_boundary(ptr %f) #10
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsfj8xobPFoQC_18panic_str_boundary() #10
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECsfj8xobPFoQC_18panic_str_boundary(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !28 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECsfj8xobPFoQC_18panic_str_boundary(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !29 {
start:
  ret i64 %ptr.1
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csfj8xobPFoQC_18panic_str_boundary(ptr align 8 %_1) unnamed_addr #0 !guid !30 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsfj8xobPFoQC_18panic_str_boundary(ptr %_4) #11
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsfj8xobPFoQC_18panic_str_boundary() #10
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csfj8xobPFoQC_18panic_str_boundary(i8 %_2) #10
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsfj8xobPFoQC_18panic_str_boundary(ptr %_1) unnamed_addr #0 !guid !31 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfj8xobPFoQC_18panic_str_boundary(ptr %0) #10
  ret i32 %_0
}

; panic_str_boundary::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsfj8xobPFoQC_18panic_str_boundary4main() unnamed_addr #1 !guid !32 {
start:
  %_13 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_7 = alloca [16 x i8], align 8
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfj8xobPFoQC_18panic_str_boundary(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #10
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<usize>
  %_11 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECsfj8xobPFoQC_18panic_str_boundary(i64 2) #10
; call <str as core::ops::index::Index<core::ops::range::Range<usize>>>::index
  %1 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core3str6traitseINtNtNtB9_3ops5index5IndexINtNtBJ_5range5RangejEE5indexCsfj8xobPFoQC_18panic_str_boundary(ptr @alloc_dfa4a33a3c5680c5e1c3c89a28cb1d58, i64 6, i64 0, i64 %_11, ptr align 8 @alloc_3c3435af2da7348fbe8bf5f239a554b9) #10
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  store ptr %_8.0, ptr %_7, align 8, !captures !33
  %2 = getelementptr inbounds i8, ptr %_7, i64 8
  store i64 %_8.1, ptr %2, align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReECsfj8xobPFoQC_18panic_str_boundary(ptr sret([16 x i8]) align 8 %_13, ptr align 8 %_7) #10
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_13, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %4 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsfj8xobPFoQC_18panic_str_boundary(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args) #10
  %_4.0 = extractvalue { ptr, ptr } %4, 0
  %_4.1 = extractvalue { ptr, ptr } %4, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_4.0, ptr %_4.1)
; call <core::fmt::Arguments>::from_str
  %5 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfj8xobPFoQC_18panic_str_boundary(ptr @alloc_7a21961256201792dd1bf82f2d8e6106, i64 12) #10
  %_17.0 = extractvalue { ptr, ptr } %5, 0
  %_17.1 = extractvalue { ptr, ptr } %5, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_17.0, ptr %_17.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsfj8xobPFoQC_18panic_str_boundary(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !34 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::ptr::non_null::NonNull<&str>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullReE8from_refCsfj8xobPFoQC_18panic_str_boundary(ptr align 8 %r) unnamed_addr #0 !guid !35 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfj8xobPFoQC_18panic_str_boundary(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !36 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsfj8xobPFoQC_18panic_str_boundary(ptr %s.0, i64 %s.1) #10
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u8>::is_utf8_char_boundary
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh21is_utf8_char_boundaryCsfj8xobPFoQC_18panic_str_boundary(i8 %self) unnamed_addr #0 !guid !37 {
start:
  %_0 = icmp sge i8 %self, -64
  ret i1 %_0
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csfj8xobPFoQC_18panic_str_boundary(ptr %self) unnamed_addr #0 !guid !38 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csfj8xobPFoQC_18panic_str_boundary(i8 %0) unnamed_addr #0 !guid !39 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csfj8xobPFoQC_18panic_str_boundary(ptr %self) #10
  ret i32 %_0
}

; <*const u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh10cast_sliceCsfj8xobPFoQC_18panic_str_boundary(ptr %self, i64 %len) unnamed_addr #0 !guid !40 {
start:
; call core::ptr::slice_from_raw_parts::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECsfj8xobPFoQC_18panic_str_boundary(ptr %self, i64 %len) #10
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs6_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtBb_5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCsfj8xobPFoQC_18panic_str_boundary(i64 %start1, i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !41 {
start:
  %_4 = icmp uge i64 %end, %start1
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsfj8xobPFoQC_18panic_str_boundary(ptr @alloc_91f2a00ff2cd9cdc4bb205a66832e2bb, i64 219)
          to label %bb4 unwind label %terminate

bb1:                                              ; preds = %start
  %_5 = icmp ule i64 %end, %len
  br i1 %_5, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  ret void

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #12
  unreachable

bb4:                                              ; preds = %bb3
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_7.0, ptr %_7.1, i1 zeroext false, ptr align 8 %0) #13
  unreachable
}

; <&str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1i_NtCsl10jNU3mE6R_4core3fmtReNtB6_7Display3fmtCsfj8xobPFoQC_18panic_str_boundary(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !42 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <str as core::ops::index::Index<core::ops::range::Range<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core3str6traitseINtNtNtB9_3ops5index5IndexINtNtBJ_5range5RangejEE5indexCsfj8xobPFoQC_18panic_str_boundary(ptr %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !43 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::index
  %1 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE5indexCsfj8xobPFoQC_18panic_str_boundary(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #10
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::range::Range<usize> as core::convert::From<core::ops::range::Range<usize>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs5_NtCsl10jNU3mE6R_4core5rangeINtB5_5RangejEINtNtB7_7convert4FromINtNtNtB7_3ops5range5RangejEE4fromCsfj8xobPFoQC_18panic_str_boundary(i64 %value.0, i64 %value.1) unnamed_addr #0 !guid !44 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %value.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %value.1, 1
  ret { i64, i64 } %1
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<str>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtNtB9_3ops5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE5indexCsfj8xobPFoQC_18panic_str_boundary(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !45 {
start:
; call <core::range::Range<usize> as core::convert::From<core::ops::range::Range<usize>>>::from
  %1 = call { i64, i64 } @_RNvXs5_NtCsl10jNU3mE6R_4core5rangeINtB5_5RangejEINtNtB7_7convert4FromINtNtNtB7_3ops5range5RangejEE4fromCsfj8xobPFoQC_18panic_str_boundary(i64 %self.0, i64 %self.1) #10
  %_3.0 = extractvalue { i64, i64 } %1, 0
  %_3.1 = extractvalue { i64, i64 } %1, 1
; call <core::range::Range<usize> as core::slice::index::SliceIndex<str>>::index
  %2 = call { ptr, i64 } @_RNvXs6_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtB9_5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE5indexCsfj8xobPFoQC_18panic_str_boundary(i64 %_3.0, i64 %_3.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) #10
  %_0.0 = extractvalue { ptr, i64 } %2, 0
  %_0.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1, 1
  ret { ptr, i64 } %4
}

; <core::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs6_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtB9_5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsfj8xobPFoQC_18panic_str_boundary(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !46 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECsfj8xobPFoQC_18panic_str_boundary(ptr %slice.0, i64 %slice.1) #10
; call <core::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked::precondition_check
  call void @_RNvNvXs6_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtBb_5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_checkCsfj8xobPFoQC_18panic_str_boundary(i64 %self.0, i64 %self.1, i64 %_0.i1, ptr align 8 %0) #14
  br label %bb3

bb3:                                              ; preds = %bb1
  %new_len = sub nuw i64 %self.1, %self.0
  %_0.i = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self.0
; call <*const u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh10cast_sliceCsfj8xobPFoQC_18panic_str_boundary(ptr %_0.i, i64 %new_len) #10
  %_12.0 = extractvalue { ptr, i64 } %1, 0
  %_12.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_12.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_12.1, 1
  ret { ptr, i64 } %3
}

; <core::range::Range<usize> as core::slice::index::SliceIndex<str>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs6_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtB9_5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE3getCsfj8xobPFoQC_18panic_str_boundary(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !47 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %slice.1, 1
  %_6.i = icmp ugt i64 %self.0, %self.1
  br i1 %_6.i, label %bb4.i, label %bb2.i

bb2.i:                                            ; preds = %start
; call <str>::len
  %_8.i = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsfj8xobPFoQC_18panic_str_boundary(ptr %slice.0, i64 %slice.1) #10
  %_7.i = icmp ugt i64 %self.1, %_8.i
  br i1 %_7.i, label %bb4.i, label %bb5.i

bb4.i:                                            ; preds = %bb2.i, %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtNtCsl10jNU3mE6R_4core3str6traits11check_range.exit

bb5.i:                                            ; preds = %bb2.i
; call <str>::len
  %_10.i = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsfj8xobPFoQC_18panic_str_boundary(ptr %slice.0, i64 %slice.1) #10
  %_9.i = icmp eq i64 %self.0, %_10.i
  br i1 %_9.i, label %bb7.i, label %bb8.i

bb8.i:                                            ; preds = %bb5.i
  %_11.i = icmp eq i64 %self.0, 0
  br i1 %_11.i, label %bb14.i, label %bb9.i

bb7.i:                                            ; preds = %bb5.i
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtNtCsl10jNU3mE6R_4core3str6traits11check_range.exit

bb9.i:                                            ; preds = %bb8.i
  %_0.i1.i = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self.0
  %_0.i.i2.i = load i8, ptr %_0.i1.i, align 1
; call <u8>::is_utf8_char_boundary
  %_12.i = call zeroext i1 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh21is_utf8_char_boundaryCsfj8xobPFoQC_18panic_str_boundary(i8 %_0.i.i2.i) #10
  br i1 %_12.i, label %bb14.i, label %bb15.i

bb14.i:                                           ; preds = %bb9.i, %bb8.i
; call <str>::len
  %_17.i = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsfj8xobPFoQC_18panic_str_boundary(ptr %slice.0, i64 %slice.1) #10
  %_16.i = icmp eq i64 %self.1, %_17.i
  br i1 %_16.i, label %bb17.i, label %bb18.i

bb15.i:                                           ; preds = %bb9.i
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtNtCsl10jNU3mE6R_4core3str6traits11check_range.exit

bb18.i:                                           ; preds = %bb14.i
  %_0.i.i = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self.1
  %_0.i.i.i = load i8, ptr %_0.i.i, align 1
; call <u8>::is_utf8_char_boundary
  %2 = call zeroext i1 @_RNvMs4_NtCsl10jNU3mE6R_4core3numh21is_utf8_char_boundaryCsfj8xobPFoQC_18panic_str_boundary(i8 %_0.i.i.i) #10
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0.i, align 1
  br label %_RNvNtNtCsl10jNU3mE6R_4core3str6traits11check_range.exit

bb17.i:                                           ; preds = %bb14.i
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtNtCsl10jNU3mE6R_4core3str6traits11check_range.exit

_RNvNtNtCsl10jNU3mE6R_4core3str6traits11check_range.exit: ; preds = %bb4.i, %bb7.i, %bb15.i, %bb18.i, %bb17.i
  %4 = load i8, ptr %_0.i, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb2, label %bb4

bb4:                                              ; preds = %_RNvNtNtCsl10jNU3mE6R_4core3str6traits11check_range.exit
  store ptr null, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %_RNvNtNtCsl10jNU3mE6R_4core3str6traits11check_range.exit
; call <core::range::Range<usize> as core::slice::index::SliceIndex<str>>::get_unchecked
  %6 = call { ptr, i64 } @_RNvXs6_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtB9_5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE13get_uncheckedCsfj8xobPFoQC_18panic_str_boundary(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 @alloc_9fa66abd1e8793df6d4778d0370e954f) #10
  %_5.0 = extractvalue { ptr, i64 } %6, 0
  %_5.1 = extractvalue { ptr, i64 } %6, 1
  store ptr %_5.0, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %7, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %8 = load ptr, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  %10 = load i64, ptr %9, align 8
  %11 = insertvalue { ptr, i64 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %10, 1
  ret { ptr, i64 } %12
}

; <core::range::Range<usize> as core::slice::index::SliceIndex<str>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs6_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtB9_5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE5indexCsfj8xobPFoQC_18panic_str_boundary(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !48 {
start:
  %_8 = alloca [16 x i8], align 8
; call <core::range::Range<usize> as core::slice::index::SliceIndex<str>>::get
  %1 = call { ptr, i64 } @_RNvXs6_NtNtCsl10jNU3mE6R_4core3str6traitsINtNtB9_5range5RangejEINtNtNtB9_5slice5index10SliceIndexeE3getCsfj8xobPFoQC_18panic_str_boundary(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1) #10
  %2 = extractvalue { ptr, i64 } %1, 0
  %3 = extractvalue { ptr, i64 } %1, 1
  store ptr %2, ptr %_8, align 8
  %4 = getelementptr inbounds i8, ptr %_8, i64 8
  store i64 %3, ptr %4, align 8
  %5 = load ptr, ptr %_8, align 8
  %6 = getelementptr inbounds i8, ptr %_8, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = ptrtoint ptr %5 to i64
  %9 = icmp eq i64 %8, 0
  %_9 = select i1 %9, i64 0, i64 1
  %10 = trunc nuw i64 %_9 to i1
  br i1 %10, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %s.0 = load ptr, ptr %_8, align 8
  %11 = getelementptr inbounds i8, ptr %_8, i64 8
  %s.1 = load i64, ptr %11, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %s.0, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %s.1, 1
  ret { ptr, i64 } %13

bb3:                                              ; preds = %start
; call core::str::slice_error_fail
  call void @_RNvNtCsl10jNU3mE6R_4core3str16slice_error_fail(ptr %slice.0, i64 %slice.1, i64 %self.0, i64 %self.1, ptr align 8 %0) #15
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsfj8xobPFoQC_18panic_str_boundary() unnamed_addr #0 !guid !49 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfj8xobPFoQC_18panic_str_boundary(ptr %_1) unnamed_addr #0 !guid !50 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsfj8xobPFoQC_18panic_str_boundary(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !51 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csfj8xobPFoQC_18panic_str_boundary(ptr align 8 %_1) #10
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #5

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #6

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #7

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; core::str::slice_error_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3str16slice_error_fail(ptr, i64, i64, i64, ptr align 8) unnamed_addr #8

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #9 !guid !52 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsfj8xobPFoQC_18panic_str_boundary(ptr @_RNvCsfj8xobPFoQC_18panic_str_boundary4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nonlazybind "target-cpu"="x86-64" }
attributes #10 = { inlinehint }
attributes #11 = { noinline }
attributes #12 = { cold noreturn nounwind }
attributes #13 = { noinline noreturn nounwind }
attributes #14 = { inlinehint nounwind }
attributes #15 = { noinline noreturn }

!llvm.module.flags = !{!14, !15, !16, !17}
!llvm.ident = !{!18}

!0 = !{i64 -4579715499168396356}
!1 = !{i64 1442731414103840830}
!2 = !{i64 6946698069719270463}
!3 = !{i64 2639468803493784365}
!4 = !{i64 3490479376018350116}
!5 = !{i64 547362849133659624}
!6 = !{i64 6600424783968649197}
!7 = !{i64 -5508744149956814666}
!8 = !{i64 -6630316130760276621}
!9 = !{i64 1998123987473724469}
!10 = !{i64 -4169863888149918666}
!11 = !{i64 -403128762977528768}
!12 = !{i64 224975726608725361}
!13 = !{i64 6794563325331836495}
!14 = !{i32 8, !"PIC Level", i32 2}
!15 = !{i32 7, !"PIE Level", i32 2}
!16 = !{i32 2, !"RtLibUseGOT", i32 1}
!17 = !{i32 7, !"uwtable", i32 2}
!18 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!19 = !{i64 -4839620582762707682}
!20 = !{i64 5881452603007973822}
!21 = !{i64 -1149686678670198381}
!22 = !{i64 2141201588675247495}
!23 = !{i64 -715320116325060711}
!24 = !{i64 535440163459698611}
!25 = !{i64 1312851243608549}
!26 = !{i64 -6777130969363104660}
!27 = !{i64 6900948717997511901}
!28 = !{i64 -3923899563952720024}
!29 = !{i64 4292637542791054458}
!30 = !{i64 -6254340410986285064}
!31 = !{i64 5625697916640561860}
!32 = !{i64 2441232595965431814}
!33 = !{!"address", !"read_provenance"}
!34 = !{i64 -4408456068794156902}
!35 = !{i64 1150261450358028207}
!36 = !{i64 5482768850477321394}
!37 = !{i64 -8122477175969973454}
!38 = !{i64 -1518381316337569419}
!39 = !{i64 2590599425027018730}
!40 = !{i64 5979704475405632202}
!41 = !{i64 2482620676287785364}
!42 = !{i64 1396141744536609878}
!43 = !{i64 -235507981671027739}
!44 = !{i64 5742439554029174855}
!45 = !{i64 -6827289237611925041}
!46 = !{i64 -2791439109369426042}
!47 = !{i64 3795880716098522443}
!48 = !{i64 1519023003104781074}
!49 = !{i64 6722148986777853049}
!50 = !{i64 445160579366379771}
!51 = !{i64 -5721775608375999474}
!52 = !{i64 -2624081020897602054}
