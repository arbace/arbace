; ModuleID = 'casts.d3164f7a67cfd47-cgu.0'
source_filename = "casts.d3164f7a67cfd47-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@alloc_e115666fc0a413d6b872330050c6deeb = private unnamed_addr constant [24 x i8] c"core/src/array/drain.rs\00", align 1, !guid !0
@alloc_582da9e16b076f40df8aebfbc37e843c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e115666fc0a413d6b872330050c6deeb, [16 x i8] c"\17\00\00\00\00\00\00\00\1D\00\00\00P\00\00\00" }>, align 8, !guid !1
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs18dZLLqCRHT_5casts, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs18dZLLqCRHT_5casts, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs18dZLLqCRHT_5casts }>, align 8, !guid !2
@alloc_0d0353b85363a9d264096e7bdbfe6900 = private unnamed_addr constant [22 x i8] c"core/src/array/mod.rs\00", align 1, !guid !3
@alloc_3657a61a2bcaad7ae22c9f0d4037a229 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d0353b85363a9d264096e7bdbfe6900, [16 x i8] c"\15\00\00\00\00\00\00\00\9F\00\00\00\1C\00\00\00" }>, align 8, !guid !4
@alloc_1b8da18ba9175148bb2e455ee98c556c = private unnamed_addr constant [4 x i8] c"\C0\01 \00", align 1, !guid !5
@alloc_49a1e817e911805af64bbc7efb390101 = private unnamed_addr constant [1 x i8] c"\0A", align 1, !guid !6
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !7
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !8
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !9
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !10
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !11
@alloc_fb8434897fc981b244a3f03509e5b63a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\A7\03\00\00\12\00\00\00" }>, align 8, !guid !12
@alloc_0e5e743f11811ed52c409dafae27227d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d0353b85363a9d264096e7bdbfe6900, [16 x i8] c"\15\00\00\00\00\00\00\00\BA\03\00\00\1C\00\00\00" }>, align 8, !guid !13
@alloc_67b02d4cc7f876dde0fea3bed8b9b42f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d0353b85363a9d264096e7bdbfe6900, [16 x i8] c"\15\00\00\00\00\00\00\00\BB\03\00\001\00\00\00" }>, align 8, !guid !14
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !15
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !16
@alloc_5a8fdd84b3281310cbf6b74bb6bf0065 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !17
@alloc_18d73aa062d524e9620b9e3b55bd9eb1 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the range is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !18
@alloc_54bdda806a54ef5a1da114112d5dae1a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e115666fc0a413d6b872330050c6deeb, [16 x i8] c"\17\00\00\00\00\00\00\00{\00\00\00%\00\00\00" }>, align 8, !guid !19
@alloc_2d2c5b2cb4a79facdd223316003bbbd0 = private unnamed_addr constant [24 x i8] c"core/src/slice/index.rs\00", align 1, !guid !20
@alloc_1b39eec3adbd903e3f9ab4ac43144a38 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2d2c5b2cb4a79facdd223316003bbbd0, [16 x i8] c"\17\00\00\00\00\00\00\00\F2\01\00\00 \00\00\00" }>, align 8, !guid !21
@alloc_5cb263f26a5d50117adfcc5c7225745e = private unnamed_addr constant [15 x i8] c"TryFromIntError", align 1, !guid !22
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !23
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !24
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !25
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRcNtB6_5Debug3fmtCs18dZLLqCRHT_5casts }>, align 8, !guid !26
@alloc_bb689cb4c05c0bf38d31dd7cd71b8150 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d0353b85363a9d264096e7bdbfe6900, [16 x i8] c"\15\00\00\00\00\00\00\00e\01\00\00\1F\00\00\00" }>, align 8, !guid !27
@alloc_305abab612895a7382c95f94a11d3600 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d0353b85363a9d264096e7bdbfe6900, [16 x i8] c"\15\00\00\00\00\00\00\00\C7\03\00\00\1C\00\00\00" }>, align 8, !guid !28
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !29
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCs18dZLLqCRHT_5casts }>, align 8, !guid !30
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !31
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error15TryFromIntErrorNtB6_5Debug3fmtCs18dZLLqCRHT_5casts }>, align 8, !guid !32

; <[core::mem::maybe_uninit::MaybeUninit<u32>]>::get_unchecked_mut::<core::ops::range::RangeTo<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitmE17get_unchecked_mutINtNtNtB5_3ops5range7RangeTojEECs18dZLLqCRHT_5casts(ptr align 4 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !38 {
start:
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<u32>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitmEE17get_unchecked_mutCs18dZLLqCRHT_5casts(i64 %index, ptr %self.0, i64 %self.1) #13
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <[core::mem::maybe_uninit::MaybeUninit<u32>]>::get_unchecked_mut::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitmE17get_unchecked_mutjECs18dZLLqCRHT_5casts(ptr align 4 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !39 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<u32>]>>::get_unchecked_mut
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitmEE17get_unchecked_mutCs18dZLLqCRHT_5casts(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #13
  ret ptr %_3
}

; <core::fmt::rt::Argument>::new_display::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !40 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs18dZLLqCRHT_5casts(ptr %x) #13
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !41 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs18dZLLqCRHT_5casts(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !42 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs18dZLLqCRHT_5casts(ptr align 4 %x) #13
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<isize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayiECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !43 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<isize>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulliE8from_refCs18dZLLqCRHT_5casts(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<isize>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulliE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsj_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impiNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !44 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCs18dZLLqCRHT_5casts(ptr align 16 %x) #13
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !45 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #13
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !46 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i16>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCs18dZLLqCRHT_5casts(ptr align 2 %x) #13
; call <core::ptr::non_null::NonNull<i16>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !47 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs18dZLLqCRHT_5casts(ptr align 8 %x) #13
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<[u32; 2]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAmj2_ECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !48 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<[u32; 2]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAmj2_E8from_refCs18dZLLqCRHT_5casts(ptr align 4 %x) #13
; call <core::ptr::non_null::NonNull<[u32; 2]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAmj2_E4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAmj2_NtNtB7_3fmt5Debug3fmtCs18dZLLqCRHT_5casts, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<char>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptioncEECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !49 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<char>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptioncEE8from_refCs18dZLLqCRHT_5casts(ptr align 4 %x) #13
; call <core::ptr::non_null::NonNull<core::option::Option<char>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptioncEE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptioncENtNtB7_3fmt5Debug3fmtCs18dZLLqCRHT_5casts, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i8, core::num::error::TryFromIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultaNtNtNtB7_3num5error15TryFromIntErrorEECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !50 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::TryFromIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultaNtNtNtB9_3num5error15TryFromIntErrorEE8from_refCs18dZLLqCRHT_5casts(ptr %x) #13
; call <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::TryFromIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultaNtNtNtBa_3num5error15TryFromIntErrorEE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultaNtNtNtB7_3num5error15TryFromIntErrorENtNtB7_3fmt5Debug3fmtCs18dZLLqCRHT_5casts, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !51 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs18dZLLqCRHT_5casts(ptr %x) #13
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs18dZLLqCRHT_5casts(ptr %_4) #13
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs18dZLLqCRHT_5casts, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1::<f32, casts::main::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0EB1m_() unnamed_addr #0 !guid !52 {
start:
  ret void
}

; <core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>>::new::<2>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core5array5drainINtB3_5DrainfNCINvMNtNtB7_3ops9try_traitINtBV_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0E3newKj2_EB1Y_(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %array, ptr %f) unnamed_addr #1 !guid !53 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<core::mem::manually_drop::ManuallyDrop<[f32; 2]>>>::from_mut
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtNtB9_3mem13manually_drop12ManuallyDropAfj2_EE8from_mutCs18dZLLqCRHT_5casts(ptr align 4 %array) #13
; call <core::ptr::non_null::NonNull<core::mem::manually_drop::ManuallyDrop<[f32; 2]>>>::cast::<f32>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtNtBa_3mem13manually_drop12ManuallyDropAfj2_EE4castfECs18dZLLqCRHT_5casts(ptr %_4) #13
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw float, ptr %ptr, i64 2
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb6

bb6:                                              ; preds = %bb4
  %_7 = load ptr, ptr %end_or_len, align 8
  store ptr %ptr, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store ptr %_7, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %f, ptr %1, align 8
  ret void

bb3:                                              ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<[u32; 2]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAmj2_E4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !54 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<char>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptioncEE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !55 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::TryFromIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultaNtNtNtBa_3num5error15TryFromIntErrorEE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !56 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::mem::manually_drop::ManuallyDrop<[f32; 2]>>>::cast::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtNtBa_3mem13manually_drop12ManuallyDropAfj2_EE4castfECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !57 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !58 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !59 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !60 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !61 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<isize>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulliE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !62 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !63 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i16>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !64 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !65 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs18dZLLqCRHT_5casts(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !66 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <[f32; 2]>::map::<casts::main::{closure#0}, u32>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvMsm_NtCsl10jNU3mE6R_4core5arrayAfj2_3mapNCNvCs18dZLLqCRHT_5casts4main0mEBK_(i64 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !67 {
start:
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %_6 = alloca [1 x i8], align 1
  %_4 = alloca [8 x i8], align 4
  %_3 = alloca [8 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %3 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 4
  store i64 %0, ptr %3, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %self, ptr align 8 %3, i64 8, i1 false)
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_4, ptr align 4 %self, i64 8, i1 false)
; call <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1::<f32, casts::main::{closure#0}>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0EB1m_() #13
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 4 %_4, i64 8, i1 false)
  %4 = load i64, ptr %2, align 8
; call <[f32; 2]>::try_map::<core::ops::try_trait::NeverShortCircuit<u32>, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>
  %5 = call i64 @_RINvMsm_NtCsl10jNU3mE6R_4core5arrayAfj2_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitmENCINvMBN_BK_10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EB1W_(i64 %4)
  store i64 %5, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_3, ptr align 8 %1, i64 8, i1 false)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 4 %_3, i64 8, i1 false)
  %6 = load i64, ptr %_0, align 4
  ret i64 %6

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <[f32; 2]>::try_map::<core::ops::try_trait::NeverShortCircuit<u32>, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvMsm_NtCsl10jNU3mE6R_4core5arrayAfj2_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitmENCINvMBN_BK_10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EB1W_(i64 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !68 {
start:
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %_2.i = alloca [8 x i8], align 4
  %_0.i = alloca [8 x i8], align 4
  %3 = alloca [8 x i8], align 8
  %value.i = alloca [8 x i8], align 4
  %4 = alloca [8 x i8], align 8
  %5 = alloca [16 x i8], align 8
  %6 = alloca [8 x i8], align 8
  %7 = alloca [8 x i8], align 8
  %f1 = alloca [24 x i8], align 8
  %me = alloca [8 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %f = alloca [0 x i8], align 1
  %8 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 4
  store i64 %0, ptr %8, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %self, ptr align 8 %8, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 4 %self, i64 8, i1 false)
  %9 = load i64, ptr %7, align 8
  store i64 %9, ptr %3, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %value.i, ptr align 8 %3, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 4 %value.i, i64 8, i1 false)
  %10 = load i64, ptr %2, align 8
; call <core::mem::maybe_dangling::MaybeDangling<[f32; 2]>>::new
  %11 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingAfj2_E3newCs18dZLLqCRHT_5casts(i64 %10)
  store i64 %11, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_2.i, ptr align 8 %1, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i, ptr align 4 %_2.i, i64 8, i1 false)
  %12 = load i64, ptr %_0.i, align 4
  store i64 %12, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %me, ptr align 8 %6, i64 8, i1 false)
  br label %bb1

bb1:                                              ; preds = %start
; call <core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>>::new::<2>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core5array5drainINtB3_5DrainfNCINvMNtNtB7_3ops9try_traitINtBV_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0E3newKj2_EB1Y_(ptr sret([24 x i8]) align 8 %f1, ptr align 4 %me, ptr %f)
  br label %bb2

bb2:                                              ; preds = %bb1
; invoke core::array::try_from_fn::<core::ops::try_trait::NeverShortCircuit<u32>, 2, &mut core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>>
  %13 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core5array11try_from_fnINtNtNtB4_3ops9try_trait17NeverShortCircuitmEKj2_QINtNtB2_5drain5DrainfNCINvMBJ_BG_10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EEB2i_(ptr align 8 %f1)
          to label %bb3 unwind label %cleanup

bb6:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array5drain5DrainfNCINvMNtNtB4_3ops9try_traitINtB1a_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EEB2e_(ptr align 8 %f1) #14
          to label %bb7 unwind label %terminate

cleanup:                                          ; preds = %bb2
  %14 = landingpad { ptr, i32 }
          cleanup
  %15 = extractvalue { ptr, i32 } %14, 0
  %16 = extractvalue { ptr, i32 } %14, 1
  store ptr %15, ptr %5, align 8
  %17 = getelementptr inbounds i8, ptr %5, i64 8
  store i32 %16, ptr %17, align 8
  br label %bb6

bb3:                                              ; preds = %bb2
  store i64 %13, ptr %4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %4, i64 8, i1 false)
; call core::ptr::drop_glue::<core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array5drain5DrainfNCINvMNtNtB4_3ops9try_traitINtB1a_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EEB2e_(ptr align 8 %f1)
  br label %bb4

bb4:                                              ; preds = %bb3
  %18 = load i64, ptr %_0, align 4
  ret i64 %18

terminate:                                        ; preds = %bb6
  %19 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #15
  unreachable

bb7:                                              ; preds = %bb6
  %20 = load ptr, ptr %5, align 8
  %21 = getelementptr inbounds i8, ptr %5, i64 8
  %22 = load i32, ptr %21, align 8
  %23 = insertvalue { ptr, i32 } poison, ptr %20, 0
  %24 = insertvalue { ptr, i32 } %23, i32 %22, 1
  resume { ptr, i32 } %24
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs18dZLLqCRHT_5casts(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !69 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::mem::forget::<core::array::Guard<u32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNtB4_5array5GuardmEECs18dZLLqCRHT_5casts(ptr align 8 %t) unnamed_addr #0 !guid !70 {
start:
  %0 = alloca [24 x i8], align 8
  %_2.i = alloca [24 x i8], align 8
  %1 = alloca [24 x i8], align 8
  %_2 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %t, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 24, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::Guard<u32>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtB6_5array5GuardmEE3newCs18dZLLqCRHT_5casts(ptr sret([24 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_2, ptr align 8 %_2.i, i64 24, i1 false)
  ret void
}

; core::ptr::drop_glue::<core::array::Guard<u32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_5array5GuardmEECs18dZLLqCRHT_5casts(ptr align 8 %_1) unnamed_addr #1 !guid !71 {
start:
; call <core::array::Guard<u32> as core::ops::drop::Drop>::drop
  call void @_RNvXso_NtCsl10jNU3mE6R_4core5arrayINtB5_5GuardmENtNtNtB7_3ops4drop4Drop4dropCs18dZLLqCRHT_5casts(ptr align 8 %_1) #13
  ret void
}

; core::ptr::drop_glue::<core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array5drain5DrainfNCINvMNtNtB4_3ops9try_traitINtB1a_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EEB2e_(ptr align 8 %_1) unnamed_addr #1 !guid !72 {
start:
; call <core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtCsl10jNU3mE6R_4core5array5drainINtB5_5DrainfNCINvMNtNtB9_3ops9try_traitINtBX_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0ENtNtBZ_4drop4Drop4dropB20_(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<[f32; 2]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxAfj2_ECs18dZLLqCRHT_5casts(i64 %0) unnamed_addr #0 !guid !73 {
start:
  %_0 = alloca [8 x i8], align 4
  %1 = alloca [8 x i8], align 8
  %dummy = alloca [8 x i8], align 4
  store i64 %0, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %dummy, ptr align 8 %1, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 4 %dummy, i64 8, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; core::hint::black_box::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs18dZLLqCRHT_5casts(i8 %dummy) unnamed_addr #0 !guid !75 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECs18dZLLqCRHT_5casts(i1 zeroext %dummy) unnamed_addr #0 !guid !76 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = zext i1 %dummy to i8
  store i8 %0, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %1 = load i8, ptr %_0, align 1
  %2 = trunc nuw i8 %1 to i1
  ret i1 %2
}

; core::hint::black_box::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxcECs18dZLLqCRHT_5casts(i32 %dummy) unnamed_addr #0 !guid !77 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double %dummy) unnamed_addr #0 !guid !78 {
start:
  %_0 = alloca [8 x i8], align 8
  store double %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load double, ptr %_0, align 8
  ret double %0
}

; core::hint::black_box::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs18dZLLqCRHT_5casts(float %dummy) unnamed_addr #0 !guid !79 {
start:
  %_0 = alloca [4 x i8], align 4
  store float %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load float, ptr %_0, align 4
  ret float %0
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 %dummy) unnamed_addr #0 !guid !80 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 %dummy) unnamed_addr #0 !guid !81 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs18dZLLqCRHT_5casts(i32 %dummy) unnamed_addr #0 !guid !82 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs18dZLLqCRHT_5casts(i128 %dummy) unnamed_addr #0 !guid !83 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; core::hint::black_box::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs18dZLLqCRHT_5casts(i128 %dummy) unnamed_addr #0 !guid !84 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; core::hint::black_box::<u16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs18dZLLqCRHT_5casts(i16 %dummy) unnamed_addr #0 !guid !85 {
start:
  %_0 = alloca [2 x i8], align 2
  store i16 %dummy, ptr %_0, align 2
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i16, ptr %_0, align 2
  ret i16 %0
}

; core::hint::black_box::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 %dummy) unnamed_addr #0 !guid !86 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 %dummy) unnamed_addr #0 !guid !87 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !74
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::array::try_from_fn::<core::ops::try_trait::NeverShortCircuit<u32>, 2, &mut core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core5array11try_from_fnINtNtNtB4_3ops9try_trait17NeverShortCircuitmEKj2_QINtNtB2_5drain5DrainfNCINvMBJ_BG_10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EEB2i_(ptr align 8 %cb) unnamed_addr #0 !guid !88 {
start:
  %_0.i = alloca [8 x i8], align 4
  %0 = alloca [8 x i8], align 8
  %array.i = alloca [8 x i8], align 4
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %3 = alloca [8 x i8], align 8
  %4 = alloca [8 x i8], align 8
  %5 = alloca [8 x i8], align 8
  %_9 = alloca [8 x i8], align 4
  %_8 = alloca [8 x i8], align 4
  %_3 = alloca [0 x i8], align 1
  %array = alloca [8 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  call void @llvm.memset.p0.i64(ptr align 4 %array, i8 undef, i64 8, i1 false)
; call core::array::try_from_fn_erased::<core::ops::try_trait::NeverShortCircuit<u32>, &mut core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>>
  call void @_RINvNtCsl10jNU3mE6R_4core5array18try_from_fn_erasedINtNtNtB4_3ops9try_trait17NeverShortCircuitmEQINtNtB2_5drain5DrainfNCINvMBQ_BN_10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EEB2l_(ptr align 4 %array, i64 2, ptr align 8 %cb) #13
  br label %bb3

bb3:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_9, ptr align 4 %array, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 4 %_9, i64 8, i1 false)
  %6 = load i64, ptr %5, align 8
  store i64 %6, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %array.i, ptr align 8 %0, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i, ptr align 4 %array.i, i64 8, i1 false)
  %7 = load i64, ptr %_0.i, align 4
  store i64 %7, ptr %4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_8, ptr align 8 %4, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 4 %_8, i64 8, i1 false)
  %8 = load i64, ptr %3, align 8
; call <core::ops::try_trait::NeverShortCircuit<[u32; 2]> as core::ops::try_trait::Try>::from_output
  %9 = call i64 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitAmj2_ENtB4_3Try11from_outputCs18dZLLqCRHT_5casts(i64 %8) #13
  store i64 %9, ptr %2, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %2, i64 8, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %10 = load i64, ptr %_0, align 4
  ret i64 %10

bb4:                                              ; No predecessors!
; call <core::ops::try_trait::NeverShortCircuit<[u32; 2]> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
  %11 = call i64 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitAmj2_EINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCs18dZLLqCRHT_5casts() #13
  store i64 %11, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 8 %1, i64 8, i1 false)
  br label %bb6

bb2:                                              ; No predecessors!
  unreachable
}

; core::array::try_from_fn_erased::<core::ops::try_trait::NeverShortCircuit<u32>, &mut core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core5array18try_from_fn_erasedINtNtNtB4_3ops9try_trait17NeverShortCircuitmEQINtNtB2_5drain5DrainfNCINvMBQ_BN_10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EEB2l_(ptr align 4 %buffer.0, i64 %buffer.1, ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !89 {
start:
  %1 = alloca [16 x i8], align 8
  %_22 = alloca [1 x i8], align 1
  %_20 = alloca [24 x i8], align 8
  %_8 = alloca [4 x i8], align 4
  %guard = alloca [24 x i8], align 8
  %generator = alloca [8 x i8], align 8
  store ptr %0, ptr %generator, align 8
  store i8 0, ptr %_22, align 1
  store i8 1, ptr %_22, align 1
  store ptr %buffer.0, ptr %guard, align 8
  %2 = getelementptr inbounds i8, ptr %guard, i64 8
  store i64 %buffer.1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %guard, i64 16
  store i64 0, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %bb18, %start
  %4 = getelementptr inbounds i8, ptr %guard, i64 16
  %_5 = load i64, ptr %4, align 8
  %_21.0 = load ptr, ptr %guard, align 8
  %5 = getelementptr inbounds i8, ptr %guard, i64 8
  %_21.1 = load i64, ptr %5, align 8
  %_4 = icmp ult i64 %_5, %_21.1
  br i1 %_4, label %bb2, label %bb10

bb10:                                             ; preds = %bb1
  store i8 0, ptr %_22, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_20, ptr align 8 %guard, i64 24, i1 false)
; invoke core::mem::forget::<core::array::Guard<u32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNtB4_5array5GuardmEECs18dZLLqCRHT_5casts(ptr align 8 %_20)
          to label %bb11 unwind label %cleanup

bb2:                                              ; preds = %bb1
  %6 = getelementptr inbounds i8, ptr %guard, i64 16
  %_13 = load i64, ptr %6, align 8
; invoke <&mut core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}> as core::ops::function::FnMut<(usize,)>>::call_mut
  %_10 = invoke i32 @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array5drainQINtB5_5DrainfNCINvMNtNtB9_3ops9try_traitINtBY_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EINtNtB10_8function5FnMutTjEE8call_mutB21_(ptr align 8 %generator, i64 %_13)
          to label %bb3 unwind label %cleanup

bb17:                                             ; preds = %cleanup
  %7 = load i8, ptr %_22, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb16, label %bb14

cleanup:                                          ; preds = %bb8, %bb7, %bb4, %bb3, %bb2, %bb10
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %1, align 8
  %12 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb17

bb11:                                             ; preds = %bb10
  store i8 0, ptr %_22, align 1
  br label %bb13

bb13:                                             ; preds = %bb12, %bb11
  ret void

bb3:                                              ; preds = %bb2
; invoke <core::ops::try_trait::NeverShortCircuit<u32> as core::ops::try_trait::Try>::branch
  %_9 = invoke i32 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitmENtB4_3Try6branchCs18dZLLqCRHT_5casts(i32 %_10)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke <core::ops::control_flow::ControlFlow<core::ops::try_trait::NeverShortCircuitResidual, u32> as core::ops::try_trait::Try>::branch
  %13 = invoke i32 @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowNtNtB4_9try_trait25NeverShortCircuitResidualmENtB12_3Try6branchCs18dZLLqCRHT_5casts(i32 %_9)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  store i32 %13, ptr %_8, align 4
  %14 = load i32, ptr %_8, align 4
  br label %bb7

bb7:                                              ; preds = %bb5
  %item = load i32, ptr %_8, align 4
; invoke <core::array::Guard<u32>>::push_unchecked
  invoke void @_RNvMsn_NtCsl10jNU3mE6R_4core5arrayINtB5_5GuardmE14push_uncheckedCs18dZLLqCRHT_5casts(ptr align 8 %guard, i32 %item)
          to label %bb18 unwind label %cleanup

bb18:                                             ; preds = %bb7
  br label %bb1

bb8:                                              ; No predecessors!
; invoke <core::ops::control_flow::ControlFlow<core::ops::try_trait::NeverShortCircuitResidual> as core::ops::try_trait::FromResidual<core::ops::control_flow::ControlFlow<core::ops::try_trait::NeverShortCircuitResidual, core::convert::Infallible>>>::from_residual
  invoke void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB4_11ControlFlowNtNtB6_9try_trait25NeverShortCircuitResidualEINtB14_12FromResidualIBK_B12_NtNtB8_7convert10InfallibleEE13from_residualB8_()
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
; call core::ptr::drop_glue::<core::array::Guard<u32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_5array5GuardmEECs18dZLLqCRHT_5casts(ptr align 8 %guard)
  br label %bb12

bb12:                                             ; preds = %bb9
  store i8 0, ptr %_22, align 1
  br label %bb13

bb6:                                              ; No predecessors!
  unreachable

bb14:                                             ; preds = %bb16, %bb17
  %15 = load ptr, ptr %1, align 8
  %16 = getelementptr inbounds i8, ptr %1, i64 8
  %17 = load i32, ptr %16, align 8
  %18 = insertvalue { ptr, i32 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i32 } %18, i32 %17, 1
  resume { ptr, i32 } %19

bb16:                                             ; preds = %bb17
; invoke core::ptr::drop_glue::<core::array::Guard<u32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_5array5GuardmEECs18dZLLqCRHT_5casts(ptr align 8 %guard) #14
          to label %bb14 unwind label %terminate

terminate:                                        ; preds = %bb16
  %20 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #15
  unreachable
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs18dZLLqCRHT_5casts(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !90 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs18dZLLqCRHT_5casts(ptr %f) #13
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #13
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts_mut::<[f32], f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSffECs18dZLLqCRHT_5casts(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !91 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<u32>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitmEECs18dZLLqCRHT_5casts(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !92 {
start:
  ret i64 %ptr.1
}

; <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1::<f32, casts::main::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0B1o_(ptr %_1, float %a) unnamed_addr #0 !guid !93 {
start:
; call casts::main::{closure#0}
  %_3 = call i32 @_RNCNvCs18dZLLqCRHT_5casts4main0B3_(ptr %_1, float %a) #13
  ret i32 %_3
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs18dZLLqCRHT_5casts(ptr align 8 %_1) unnamed_addr #0 !guid !94 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs18dZLLqCRHT_5casts(ptr %_4) #16
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs18dZLLqCRHT_5casts() #13
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs18dZLLqCRHT_5casts(i8 %_2) #13
  ret i32 %_0
}

; casts::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCs18dZLLqCRHT_5casts4main0B3_(ptr %_1, float %x) unnamed_addr #0 !guid !95 {
start:
; call <f32>::to_bits
  %_0 = call i32 @_RNvMNtCsl10jNU3mE6R_4core3f32f7to_bitsCs18dZLLqCRHT_5casts(float %x) #13
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs18dZLLqCRHT_5casts(ptr %_1) unnamed_addr #0 !guid !96 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs18dZLLqCRHT_5casts(ptr %0) #13
  ret i32 %_0
}

; casts::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs18dZLLqCRHT_5casts4main() unnamed_addr #1 !guid !97 {
start:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %3 = alloca [8 x i8], align 8
  %4 = alloca [8 x i8], align 8
  %_1267 = alloca [16 x i8], align 8
  %args120 = alloca [16 x i8], align 8
  %_1265 = alloca [8 x i8], align 4
  %_1264 = alloca [8 x i8], align 4
  %_1263 = alloca [8 x i8], align 4
  %_1256 = alloca [16 x i8], align 8
  %_1255 = alloca [16 x i8], align 8
  %args119 = alloca [32 x i8], align 8
  %_1251 = alloca [4 x i8], align 4
  %_1247 = alloca [4 x i8], align 4
  %_1240 = alloca [16 x i8], align 8
  %_1239 = alloca [16 x i8], align 8
  %args118 = alloca [32 x i8], align 8
  %_1235 = alloca [8 x i8], align 8
  %_1231 = alloca [8 x i8], align 8
  %_1224 = alloca [16 x i8], align 8
  %args117 = alloca [16 x i8], align 8
  %p = alloca [8 x i8], align 8
  %_1213 = alloca [16 x i8], align 8
  %_1212 = alloca [16 x i8], align 8
  %args116 = alloca [32 x i8], align 8
  %_1209 = alloca [8 x i8], align 4
  %_1207 = alloca [1 x i8], align 1
  %_1204 = alloca [2 x i8], align 1
  %_1197 = alloca [16 x i8], align 8
  %_1196 = alloca [16 x i8], align 8
  %_1195 = alloca [16 x i8], align 8
  %args115 = alloca [48 x i8], align 8
  %_1192 = alloca [2 x i8], align 1
  %_1190 = alloca [1 x i8], align 1
  %_1187 = alloca [4 x i8], align 4
  %_1184 = alloca [4 x i8], align 4
  %args114 = alloca [24 x i8], align 8
  %_1177 = alloca [16 x i8], align 8
  %args113 = alloca [16 x i8], align 8
  %_1173 = alloca [4 x i8], align 4
  %_1164 = alloca [16 x i8], align 8
  %args112 = alloca [16 x i8], align 8
  %_1161 = alloca [2 x i8], align 2
  %_1154 = alloca [16 x i8], align 8
  %args111 = alloca [16 x i8], align 8
  %_1151 = alloca [4 x i8], align 4
  %_1144 = alloca [16 x i8], align 8
  %args110 = alloca [16 x i8], align 8
  %_1141 = alloca [1 x i8], align 1
  %_1132 = alloca [16 x i8], align 8
  %args109 = alloca [16 x i8], align 8
  %_1129 = alloca [16 x i8], align 16
  %_1122 = alloca [16 x i8], align 8
  %args108 = alloca [16 x i8], align 8
  %_1119 = alloca [1 x i8], align 1
  %_1112 = alloca [16 x i8], align 8
  %args107 = alloca [16 x i8], align 8
  %_1109 = alloca [4 x i8], align 4
  %_1100 = alloca [16 x i8], align 8
  %args106 = alloca [16 x i8], align 8
  %_1097 = alloca [8 x i8], align 8
  %_1090 = alloca [16 x i8], align 8
  %args105 = alloca [16 x i8], align 8
  %_1087 = alloca [4 x i8], align 4
  %_1078 = alloca [16 x i8], align 8
  %args104 = alloca [16 x i8], align 8
  %_1075 = alloca [8 x i8], align 8
  %_1068 = alloca [16 x i8], align 8
  %args103 = alloca [16 x i8], align 8
  %_1065 = alloca [1 x i8], align 1
  %_1058 = alloca [16 x i8], align 8
  %args102 = alloca [16 x i8], align 8
  %_1055 = alloca [4 x i8], align 4
  %_1048 = alloca [16 x i8], align 8
  %args101 = alloca [16 x i8], align 8
  %_1045 = alloca [8 x i8], align 8
  %_1036 = alloca [16 x i8], align 8
  %args100 = alloca [16 x i8], align 8
  %_1033 = alloca [8 x i8], align 8
  %_1026 = alloca [16 x i8], align 8
  %args99 = alloca [16 x i8], align 8
  %_1023 = alloca [8 x i8], align 8
  %_1016 = alloca [16 x i8], align 8
  %args98 = alloca [16 x i8], align 8
  %_1013 = alloca [4 x i8], align 4
  %_1004 = alloca [16 x i8], align 8
  %args97 = alloca [16 x i8], align 8
  %_1001 = alloca [8 x i8], align 8
  %_994 = alloca [16 x i8], align 8
  %args96 = alloca [16 x i8], align 8
  %_991 = alloca [4 x i8], align 4
  %_982 = alloca [16 x i8], align 8
  %args95 = alloca [16 x i8], align 8
  %_979 = alloca [4 x i8], align 4
  %_972 = alloca [16 x i8], align 8
  %args94 = alloca [16 x i8], align 8
  %_969 = alloca [16 x i8], align 16
  %_962 = alloca [16 x i8], align 8
  %args93 = alloca [16 x i8], align 8
  %_959 = alloca [8 x i8], align 8
  %_952 = alloca [16 x i8], align 8
  %args92 = alloca [16 x i8], align 8
  %_949 = alloca [4 x i8], align 4
  %_942 = alloca [16 x i8], align 8
  %args91 = alloca [16 x i8], align 8
  %_939 = alloca [4 x i8], align 4
  %_930 = alloca [16 x i8], align 8
  %args90 = alloca [16 x i8], align 8
  %_927 = alloca [4 x i8], align 4
  %_920 = alloca [16 x i8], align 8
  %args89 = alloca [16 x i8], align 8
  %_917 = alloca [16 x i8], align 16
  %_910 = alloca [16 x i8], align 8
  %args88 = alloca [16 x i8], align 8
  %_907 = alloca [8 x i8], align 8
  %_900 = alloca [16 x i8], align 8
  %args87 = alloca [16 x i8], align 8
  %_897 = alloca [4 x i8], align 4
  %_890 = alloca [16 x i8], align 8
  %args86 = alloca [16 x i8], align 8
  %_887 = alloca [1 x i8], align 1
  %_880 = alloca [16 x i8], align 8
  %args85 = alloca [16 x i8], align 8
  %_877 = alloca [1 x i8], align 1
  %_868 = alloca [16 x i8], align 8
  %args84 = alloca [16 x i8], align 8
  %_865 = alloca [4 x i8], align 4
  %_858 = alloca [16 x i8], align 8
  %args83 = alloca [16 x i8], align 8
  %_855 = alloca [16 x i8], align 16
  %_848 = alloca [16 x i8], align 8
  %args82 = alloca [16 x i8], align 8
  %_845 = alloca [8 x i8], align 8
  %_838 = alloca [16 x i8], align 8
  %args81 = alloca [16 x i8], align 8
  %_835 = alloca [4 x i8], align 4
  %_828 = alloca [16 x i8], align 8
  %args80 = alloca [16 x i8], align 8
  %_825 = alloca [1 x i8], align 1
  %_818 = alloca [16 x i8], align 8
  %args79 = alloca [16 x i8], align 8
  %_815 = alloca [1 x i8], align 1
  %_806 = alloca [16 x i8], align 8
  %args78 = alloca [16 x i8], align 8
  %_803 = alloca [4 x i8], align 4
  %_796 = alloca [16 x i8], align 8
  %args77 = alloca [16 x i8], align 8
  %_793 = alloca [16 x i8], align 16
  %_786 = alloca [16 x i8], align 8
  %args76 = alloca [16 x i8], align 8
  %_783 = alloca [16 x i8], align 16
  %_776 = alloca [16 x i8], align 8
  %args75 = alloca [16 x i8], align 8
  %_773 = alloca [8 x i8], align 8
  %_766 = alloca [16 x i8], align 8
  %args74 = alloca [16 x i8], align 8
  %_763 = alloca [8 x i8], align 8
  %_754 = alloca [16 x i8], align 8
  %args73 = alloca [16 x i8], align 8
  %_751 = alloca [4 x i8], align 4
  %_744 = alloca [16 x i8], align 8
  %args72 = alloca [16 x i8], align 8
  %_741 = alloca [16 x i8], align 16
  %_734 = alloca [16 x i8], align 8
  %args71 = alloca [16 x i8], align 8
  %_731 = alloca [16 x i8], align 16
  %_724 = alloca [16 x i8], align 8
  %args70 = alloca [16 x i8], align 8
  %_721 = alloca [8 x i8], align 8
  %_714 = alloca [16 x i8], align 8
  %args69 = alloca [16 x i8], align 8
  %_711 = alloca [8 x i8], align 8
  %_704 = alloca [16 x i8], align 8
  %args68 = alloca [16 x i8], align 8
  %_701 = alloca [4 x i8], align 4
  %_694 = alloca [16 x i8], align 8
  %args67 = alloca [16 x i8], align 8
  %_691 = alloca [4 x i8], align 4
  %_684 = alloca [16 x i8], align 8
  %args66 = alloca [16 x i8], align 8
  %_681 = alloca [1 x i8], align 1
  %_674 = alloca [16 x i8], align 8
  %args65 = alloca [16 x i8], align 8
  %_671 = alloca [1 x i8], align 1
  %_662 = alloca [16 x i8], align 8
  %args64 = alloca [16 x i8], align 8
  %_659 = alloca [4 x i8], align 4
  %_652 = alloca [16 x i8], align 8
  %args63 = alloca [16 x i8], align 8
  %_649 = alloca [16 x i8], align 16
  %_642 = alloca [16 x i8], align 8
  %args62 = alloca [16 x i8], align 8
  %_639 = alloca [16 x i8], align 16
  %_632 = alloca [16 x i8], align 8
  %args61 = alloca [16 x i8], align 8
  %_629 = alloca [8 x i8], align 8
  %_622 = alloca [16 x i8], align 8
  %args60 = alloca [16 x i8], align 8
  %_619 = alloca [8 x i8], align 8
  %_612 = alloca [16 x i8], align 8
  %args59 = alloca [16 x i8], align 8
  %_609 = alloca [4 x i8], align 4
  %_602 = alloca [16 x i8], align 8
  %args58 = alloca [16 x i8], align 8
  %_599 = alloca [4 x i8], align 4
  %_592 = alloca [16 x i8], align 8
  %args57 = alloca [16 x i8], align 8
  %_589 = alloca [1 x i8], align 1
  %_582 = alloca [16 x i8], align 8
  %args56 = alloca [16 x i8], align 8
  %_579 = alloca [1 x i8], align 1
  %_570 = alloca [16 x i8], align 8
  %args55 = alloca [16 x i8], align 8
  %_567 = alloca [4 x i8], align 4
  %_560 = alloca [16 x i8], align 8
  %args54 = alloca [16 x i8], align 8
  %_557 = alloca [8 x i8], align 8
  %_550 = alloca [16 x i8], align 8
  %args53 = alloca [16 x i8], align 8
  %_547 = alloca [2 x i8], align 2
  %_540 = alloca [16 x i8], align 8
  %args52 = alloca [16 x i8], align 8
  %_537 = alloca [2 x i8], align 2
  %_530 = alloca [16 x i8], align 8
  %args51 = alloca [16 x i8], align 8
  %_527 = alloca [1 x i8], align 1
  %_520 = alloca [16 x i8], align 8
  %args50 = alloca [16 x i8], align 8
  %_517 = alloca [1 x i8], align 1
  %_508 = alloca [16 x i8], align 8
  %args49 = alloca [16 x i8], align 8
  %_505 = alloca [8 x i8], align 8
  %_498 = alloca [16 x i8], align 8
  %args48 = alloca [16 x i8], align 8
  %_495 = alloca [4 x i8], align 4
  %_488 = alloca [16 x i8], align 8
  %args47 = alloca [16 x i8], align 8
  %_485 = alloca [8 x i8], align 8
  %_478 = alloca [16 x i8], align 8
  %args46 = alloca [16 x i8], align 8
  %_475 = alloca [16 x i8], align 16
  %_468 = alloca [16 x i8], align 8
  %args45 = alloca [16 x i8], align 8
  %_465 = alloca [8 x i8], align 8
  %_458 = alloca [16 x i8], align 8
  %args44 = alloca [16 x i8], align 8
  %_455 = alloca [1 x i8], align 1
  %_446 = alloca [16 x i8], align 8
  %args43 = alloca [16 x i8], align 8
  %_443 = alloca [8 x i8], align 8
  %_436 = alloca [16 x i8], align 8
  %args42 = alloca [16 x i8], align 8
  %_433 = alloca [4 x i8], align 4
  %_426 = alloca [16 x i8], align 8
  %args41 = alloca [16 x i8], align 8
  %_423 = alloca [16 x i8], align 16
  %_416 = alloca [16 x i8], align 8
  %args40 = alloca [16 x i8], align 8
  %_413 = alloca [8 x i8], align 8
  %_406 = alloca [16 x i8], align 8
  %args39 = alloca [16 x i8], align 8
  %_403 = alloca [8 x i8], align 8
  %_396 = alloca [16 x i8], align 8
  %args38 = alloca [16 x i8], align 8
  %_393 = alloca [1 x i8], align 1
  %_384 = alloca [16 x i8], align 8
  %args37 = alloca [16 x i8], align 8
  %_381 = alloca [8 x i8], align 8
  %_374 = alloca [16 x i8], align 8
  %args36 = alloca [16 x i8], align 8
  %_371 = alloca [4 x i8], align 4
  %_364 = alloca [16 x i8], align 8
  %args35 = alloca [16 x i8], align 8
  %_361 = alloca [4 x i8], align 4
  %_354 = alloca [16 x i8], align 8
  %args34 = alloca [16 x i8], align 8
  %_351 = alloca [2 x i8], align 2
  %_344 = alloca [16 x i8], align 8
  %args33 = alloca [16 x i8], align 8
  %_341 = alloca [1 x i8], align 1
  %_334 = alloca [16 x i8], align 8
  %args32 = alloca [16 x i8], align 8
  %_331 = alloca [4 x i8], align 4
  %_324 = alloca [16 x i8], align 8
  %args31 = alloca [16 x i8], align 8
  %_321 = alloca [2 x i8], align 2
  %_314 = alloca [16 x i8], align 8
  %args30 = alloca [16 x i8], align 8
  %_311 = alloca [1 x i8], align 1
  %_304 = alloca [16 x i8], align 8
  %args29 = alloca [16 x i8], align 8
  %_299 = alloca [4 x i8], align 4
  %_290 = alloca [16 x i8], align 8
  %args28 = alloca [16 x i8], align 8
  %_287 = alloca [4 x i8], align 4
  %_280 = alloca [16 x i8], align 8
  %args27 = alloca [16 x i8], align 8
  %_277 = alloca [4 x i8], align 4
  %_270 = alloca [16 x i8], align 8
  %args26 = alloca [16 x i8], align 8
  %_267 = alloca [1 x i8], align 1
  %_260 = alloca [16 x i8], align 8
  %args25 = alloca [16 x i8], align 8
  %_257 = alloca [2 x i8], align 2
  %_250 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_247 = alloca [1 x i8], align 1
  %_238 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_235 = alloca [8 x i8], align 8
  %_228 = alloca [16 x i8], align 8
  %args22 = alloca [16 x i8], align 8
  %_225 = alloca [4 x i8], align 4
  %_218 = alloca [16 x i8], align 8
  %args21 = alloca [16 x i8], align 8
  %_215 = alloca [16 x i8], align 16
  %_208 = alloca [16 x i8], align 8
  %args20 = alloca [16 x i8], align 8
  %_205 = alloca [8 x i8], align 8
  %_198 = alloca [16 x i8], align 8
  %args19 = alloca [16 x i8], align 8
  %_195 = alloca [4 x i8], align 4
  %_188 = alloca [16 x i8], align 8
  %args18 = alloca [16 x i8], align 8
  %_185 = alloca [2 x i8], align 2
  %_178 = alloca [16 x i8], align 8
  %args17 = alloca [16 x i8], align 8
  %_176 = alloca [1 x i8], align 1
  %_169 = alloca [16 x i8], align 8
  %args16 = alloca [16 x i8], align 8
  %_166 = alloca [16 x i8], align 16
  %_159 = alloca [16 x i8], align 8
  %args15 = alloca [16 x i8], align 8
  %_156 = alloca [8 x i8], align 8
  %_149 = alloca [16 x i8], align 8
  %args14 = alloca [16 x i8], align 8
  %_146 = alloca [4 x i8], align 4
  %_139 = alloca [16 x i8], align 8
  %args13 = alloca [16 x i8], align 8
  %_136 = alloca [2 x i8], align 2
  %_129 = alloca [16 x i8], align 8
  %args12 = alloca [16 x i8], align 8
  %_126 = alloca [1 x i8], align 1
  %_117 = alloca [16 x i8], align 8
  %args11 = alloca [16 x i8], align 8
  %_114 = alloca [8 x i8], align 8
  %_107 = alloca [16 x i8], align 8
  %args10 = alloca [16 x i8], align 8
  %_104 = alloca [16 x i8], align 16
  %_97 = alloca [16 x i8], align 8
  %args9 = alloca [16 x i8], align 8
  %_94 = alloca [8 x i8], align 8
  %_87 = alloca [16 x i8], align 8
  %args8 = alloca [16 x i8], align 8
  %_84 = alloca [4 x i8], align 4
  %_77 = alloca [16 x i8], align 8
  %args7 = alloca [16 x i8], align 8
  %_74 = alloca [2 x i8], align 2
  %_67 = alloca [16 x i8], align 8
  %args6 = alloca [16 x i8], align 8
  %_64 = alloca [1 x i8], align 1
  %_57 = alloca [16 x i8], align 8
  %args5 = alloca [16 x i8], align 8
  %_54 = alloca [8 x i8], align 8
  %_47 = alloca [16 x i8], align 8
  %args4 = alloca [16 x i8], align 8
  %_44 = alloca [16 x i8], align 16
  %_37 = alloca [16 x i8], align 8
  %args3 = alloca [16 x i8], align 8
  %_35 = alloca [8 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args2 = alloca [16 x i8], align 8
  %_25 = alloca [4 x i8], align 4
  %_18 = alloca [16 x i8], align 8
  %args1 = alloca [16 x i8], align 8
  %_15 = alloca [2 x i8], align 2
  %_8 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_5 = alloca [1 x i8], align 1
; call core::hint::black_box::<i64>
  %_6 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  %5 = trunc i64 %_6 to i8
  store i8 %5, ptr %_5, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_8, ptr %_5) #13
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_8, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %7 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args) #13
  %_2.0 = extractvalue { ptr, ptr } %7, 0
  %_2.1 = extractvalue { ptr, ptr } %7, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<i64>
  %_16 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  %8 = trunc i64 %_16 to i16
  store i16 %8, ptr %_15, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_18, ptr align 2 %_15) #13
  %9 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %_18, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %10 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args1) #13
  %_12.0 = extractvalue { ptr, ptr } %10, 0
  %_12.1 = extractvalue { ptr, ptr } %10, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_12.0, ptr %_12.1)
; call core::hint::black_box::<i64>
  %_26 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  %11 = trunc i64 %_26 to i32
  store i32 %11, ptr %_25, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_28, ptr align 4 %_25) #13
  %12 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %12, ptr align 8 %_28, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %13 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args2) #13
  %_22.0 = extractvalue { ptr, ptr } %13, 0
  %_22.1 = extractvalue { ptr, ptr } %13, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_22.0, ptr %_22.1)
; call core::hint::black_box::<i64>
  %14 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  store i64 %14, ptr %_35, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_37, ptr align 8 %_35) #13
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_37, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %16 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args3) #13
  %_32.0 = extractvalue { ptr, ptr } %16, 0
  %_32.1 = extractvalue { ptr, ptr } %16, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_32.0, ptr %_32.1)
; call core::hint::black_box::<i64>
  %_45 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  %17 = sext i64 %_45 to i128
  store i128 %17, ptr %_44, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_47, ptr align 16 %_44) #13
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_47, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args4) #13
  %_41.0 = extractvalue { ptr, ptr } %19, 0
  %_41.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_41.0, ptr %_41.1)
; call core::hint::black_box::<i64>
  %_55 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  store i64 %_55, ptr %_54, align 8
; call <core::fmt::rt::Argument>::new_display::<isize>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayiECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_57, ptr align 8 %_54) #13
  %20 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %_57, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %21 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args5) #13
  %_51.0 = extractvalue { ptr, ptr } %21, 0
  %_51.1 = extractvalue { ptr, ptr } %21, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_51.0, ptr %_51.1)
; call core::hint::black_box::<i64>
  %_65 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  %22 = trunc i64 %_65 to i8
  store i8 %22, ptr %_64, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_67, ptr %_64) #13
  %23 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %23, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %24 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args6) #13
  %_61.0 = extractvalue { ptr, ptr } %24, 0
  %_61.1 = extractvalue { ptr, ptr } %24, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_61.0, ptr %_61.1)
; call core::hint::black_box::<i64>
  %_75 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  %25 = trunc i64 %_75 to i16
  store i16 %25, ptr %_74, align 2
; call <core::fmt::rt::Argument>::new_display::<u16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaytEB7_(ptr sret([16 x i8]) align 8 %_77, ptr align 2 %_74) #13
  %26 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %26, ptr align 8 %_77, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %27 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args7) #13
  %_71.0 = extractvalue { ptr, ptr } %27, 0
  %_71.1 = extractvalue { ptr, ptr } %27, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
; call core::hint::black_box::<i64>
  %_85 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  %28 = trunc i64 %_85 to i32
  store i32 %28, ptr %_84, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_87, ptr align 4 %_84) #13
  %29 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %29, ptr align 8 %_87, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %30 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args8) #13
  %_81.0 = extractvalue { ptr, ptr } %30, 0
  %_81.1 = extractvalue { ptr, ptr } %30, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_81.0, ptr %_81.1)
; call core::hint::black_box::<i64>
  %_95 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  store i64 %_95, ptr %_94, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_97, ptr align 8 %_94) #13
  %31 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %31, ptr align 8 %_97, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %32 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args9) #13
  %_91.0 = extractvalue { ptr, ptr } %32, 0
  %_91.1 = extractvalue { ptr, ptr } %32, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_91.0, ptr %_91.1)
; call core::hint::black_box::<i64>
  %_105 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  %33 = sext i64 %_105 to i128
  store i128 %33, ptr %_104, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_107, ptr align 16 %_104) #13
  %34 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %34, ptr align 8 %_107, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %35 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args10) #13
  %_101.0 = extractvalue { ptr, ptr } %35, 0
  %_101.1 = extractvalue { ptr, ptr } %35, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_101.0, ptr %_101.1)
; call core::hint::black_box::<i64>
  %_115 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -1) #13
  store i64 %_115, ptr %_114, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_117, ptr align 8 %_114) #13
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_117, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %37 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args11) #13
  %_111.0 = extractvalue { ptr, ptr } %37, 0
  %_111.1 = extractvalue { ptr, ptr } %37, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_111.0, ptr %_111.1)
; call <core::fmt::Arguments>::from_str
  %38 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_121.0 = extractvalue { ptr, ptr } %38, 0
  %_121.1 = extractvalue { ptr, ptr } %38, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_121.0, ptr %_121.1)
; call core::hint::black_box::<u8>
  %_127 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  store i8 %_127, ptr %_126, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_129, ptr %_126) #13
  %39 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %39, ptr align 8 %_129, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %40 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args12) #13
  %_123.0 = extractvalue { ptr, ptr } %40, 0
  %_123.1 = extractvalue { ptr, ptr } %40, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_123.0, ptr %_123.1)
; call core::hint::black_box::<u8>
  %_137 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %41 = zext i8 %_137 to i16
  store i16 %41, ptr %_136, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_139, ptr align 2 %_136) #13
  %42 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %42, ptr align 8 %_139, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %43 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args13) #13
  %_133.0 = extractvalue { ptr, ptr } %43, 0
  %_133.1 = extractvalue { ptr, ptr } %43, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_133.0, ptr %_133.1)
; call core::hint::black_box::<u8>
  %_147 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %44 = zext i8 %_147 to i32
  store i32 %44, ptr %_146, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_149, ptr align 4 %_146) #13
  %45 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %45, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %46 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args14) #13
  %_143.0 = extractvalue { ptr, ptr } %46, 0
  %_143.1 = extractvalue { ptr, ptr } %46, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_143.0, ptr %_143.1)
; call core::hint::black_box::<u8>
  %_157 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %47 = zext i8 %_157 to i64
  store i64 %47, ptr %_156, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_159, ptr align 8 %_156) #13
  %48 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %48, ptr align 8 %_159, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %49 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args15) #13
  %_153.0 = extractvalue { ptr, ptr } %49, 0
  %_153.1 = extractvalue { ptr, ptr } %49, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
; call core::hint::black_box::<u8>
  %_167 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %50 = zext i8 %_167 to i128
  store i128 %50, ptr %_166, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_169, ptr align 16 %_166) #13
  %51 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %_169, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %52 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args16) #13
  %_163.0 = extractvalue { ptr, ptr } %52, 0
  %_163.1 = extractvalue { ptr, ptr } %52, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_163.0, ptr %_163.1)
; call core::hint::black_box::<u8>
  %53 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  store i8 %53, ptr %_176, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_178, ptr %_176) #13
  %54 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %54, ptr align 8 %_178, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %55 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args17) #13
  %_173.0 = extractvalue { ptr, ptr } %55, 0
  %_173.1 = extractvalue { ptr, ptr } %55, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_173.0, ptr %_173.1)
; call core::hint::black_box::<u8>
  %_186 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %56 = zext i8 %_186 to i16
  store i16 %56, ptr %_185, align 2
; call <core::fmt::rt::Argument>::new_display::<u16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaytEB7_(ptr sret([16 x i8]) align 8 %_188, ptr align 2 %_185) #13
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_188, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %58 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args18) #13
  %_182.0 = extractvalue { ptr, ptr } %58, 0
  %_182.1 = extractvalue { ptr, ptr } %58, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_182.0, ptr %_182.1)
; call core::hint::black_box::<u8>
  %_196 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %59 = zext i8 %_196 to i32
  store i32 %59, ptr %_195, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_198, ptr align 4 %_195) #13
  %60 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args19, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %60, ptr align 8 %_198, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %61 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args19) #13
  %_192.0 = extractvalue { ptr, ptr } %61, 0
  %_192.1 = extractvalue { ptr, ptr } %61, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_192.0, ptr %_192.1)
; call core::hint::black_box::<u8>
  %_206 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %62 = zext i8 %_206 to i64
  store i64 %62, ptr %_205, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_208, ptr align 8 %_205) #13
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_208, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %64 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args20) #13
  %_202.0 = extractvalue { ptr, ptr } %64, 0
  %_202.1 = extractvalue { ptr, ptr } %64, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_202.0, ptr %_202.1)
; call core::hint::black_box::<u8>
  %_216 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %65 = zext i8 %_216 to i128
  store i128 %65, ptr %_215, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_218, ptr align 16 %_215) #13
  %66 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %66, ptr align 8 %_218, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %67 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args21) #13
  %_212.0 = extractvalue { ptr, ptr } %67, 0
  %_212.1 = extractvalue { ptr, ptr } %67, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_212.0, ptr %_212.1)
; call core::hint::black_box::<u8>
  %_226 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %68 = uitofp i8 %_226 to float
  store float %68, ptr %_225, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_228, ptr align 4 %_225) #13
  %69 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %69, ptr align 8 %_228, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %70 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args22) #13
  %_222.0 = extractvalue { ptr, ptr } %70, 0
  %_222.1 = extractvalue { ptr, ptr } %70, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_222.0, ptr %_222.1)
; call core::hint::black_box::<u8>
  %_236 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -1) #13
  %71 = uitofp i8 %_236 to double
  store double %71, ptr %_235, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_238, ptr align 8 %_235) #13
  %72 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %72, ptr align 8 %_238, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %73 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args23) #13
  %_232.0 = extractvalue { ptr, ptr } %73, 0
  %_232.1 = extractvalue { ptr, ptr } %73, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_232.0, ptr %_232.1)
; call <core::fmt::Arguments>::from_str
  %74 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_242.0 = extractvalue { ptr, ptr } %74, 0
  %_242.1 = extractvalue { ptr, ptr } %74, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_242.0, ptr %_242.1)
; call core::hint::black_box::<u16>
  %_248 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs18dZLLqCRHT_5casts(i16 -1) #13
  %75 = trunc i16 %_248 to i8
  store i8 %75, ptr %_247, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_250, ptr %_247) #13
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_250, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %77 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args24) #13
  %_244.0 = extractvalue { ptr, ptr } %77, 0
  %_244.1 = extractvalue { ptr, ptr } %77, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_244.0, ptr %_244.1)
; call core::hint::black_box::<u16>
  %_258 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs18dZLLqCRHT_5casts(i16 -1) #13
  store i16 %_258, ptr %_257, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_260, ptr align 2 %_257) #13
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args25, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_260, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %79 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args25) #13
  %_254.0 = extractvalue { ptr, ptr } %79, 0
  %_254.1 = extractvalue { ptr, ptr } %79, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_254.0, ptr %_254.1)
; call core::hint::black_box::<u16>
  %_268 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs18dZLLqCRHT_5casts(i16 -1) #13
  %80 = trunc i16 %_268 to i8
  store i8 %80, ptr %_267, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_270, ptr %_267) #13
  %81 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %81, ptr align 8 %_270, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %82 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args26) #13
  %_264.0 = extractvalue { ptr, ptr } %82, 0
  %_264.1 = extractvalue { ptr, ptr } %82, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_264.0, ptr %_264.1)
; call core::hint::black_box::<u16>
  %_278 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs18dZLLqCRHT_5casts(i16 -1) #13
  %83 = zext i16 %_278 to i32
  store i32 %83, ptr %_277, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_280, ptr align 4 %_277) #13
  %84 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args27, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %84, ptr align 8 %_280, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %85 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args27) #13
  %_274.0 = extractvalue { ptr, ptr } %85, 0
  %_274.1 = extractvalue { ptr, ptr } %85, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_274.0, ptr %_274.1)
; call core::hint::black_box::<u16>
  %_288 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs18dZLLqCRHT_5casts(i16 -1) #13
  %86 = uitofp i16 %_288 to float
  store float %86, ptr %_287, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_290, ptr align 4 %_287) #13
  %87 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args28, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %87, ptr align 8 %_290, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %88 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args28) #13
  %_284.0 = extractvalue { ptr, ptr } %88, 0
  %_284.1 = extractvalue { ptr, ptr } %88, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_284.0, ptr %_284.1)
; call <core::fmt::Arguments>::from_str
  %89 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_294.0 = extractvalue { ptr, ptr } %89, 0
  %_294.1 = extractvalue { ptr, ptr } %89, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_294.0, ptr %_294.1)
; call core::hint::black_box::<u16>
  %_302 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs18dZLLqCRHT_5casts(i16 -1) #13
  %_301 = zext i16 %_302 to i32
  %_300 = trunc i32 %_301 to i8
  %90 = zext i8 %_300 to i32
  store i32 %90, ptr %_299, align 4
; call <core::fmt::rt::Argument>::new_display::<char>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaycECshGsV4pNJ6ra_6object(ptr sret([16 x i8]) align 8 %_304, ptr align 4 %_299) #13
  %91 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args29, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %91, ptr align 8 %_304, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %92 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args29) #13
  %_296.0 = extractvalue { ptr, ptr } %92, 0
  %_296.1 = extractvalue { ptr, ptr } %92, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_296.0, ptr %_296.1)
; call core::hint::black_box::<u64>
  %_312 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 4294967297) #13
  %93 = trunc i64 %_312 to i8
  store i8 %93, ptr %_311, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_314, ptr %_311) #13
  %94 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args30, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %94, ptr align 8 %_314, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %95 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args30) #13
  %_308.0 = extractvalue { ptr, ptr } %95, 0
  %_308.1 = extractvalue { ptr, ptr } %95, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_308.0, ptr %_308.1)
; call core::hint::black_box::<u64>
  %_322 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 4294967297) #13
  %96 = trunc i64 %_322 to i16
  store i16 %96, ptr %_321, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_324, ptr align 2 %_321) #13
  %97 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args31, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %97, ptr align 8 %_324, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %98 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args31) #13
  %_318.0 = extractvalue { ptr, ptr } %98, 0
  %_318.1 = extractvalue { ptr, ptr } %98, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_318.0, ptr %_318.1)
; call core::hint::black_box::<u64>
  %_332 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 4294967297) #13
  %99 = trunc i64 %_332 to i32
  store i32 %99, ptr %_331, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_334, ptr align 4 %_331) #13
  %100 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args32, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %100, ptr align 8 %_334, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %101 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args32) #13
  %_328.0 = extractvalue { ptr, ptr } %101, 0
  %_328.1 = extractvalue { ptr, ptr } %101, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_328.0, ptr %_328.1)
; call core::hint::black_box::<u64>
  %_342 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 4294967297) #13
  %102 = trunc i64 %_342 to i8
  store i8 %102, ptr %_341, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_344, ptr %_341) #13
  %103 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args33, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %103, ptr align 8 %_344, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %104 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args33) #13
  %_338.0 = extractvalue { ptr, ptr } %104, 0
  %_338.1 = extractvalue { ptr, ptr } %104, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_338.0, ptr %_338.1)
; call core::hint::black_box::<u64>
  %_352 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 4294967297) #13
  %105 = trunc i64 %_352 to i16
  store i16 %105, ptr %_351, align 2
; call <core::fmt::rt::Argument>::new_display::<u16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaytEB7_(ptr sret([16 x i8]) align 8 %_354, ptr align 2 %_351) #13
  %106 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args34, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %106, ptr align 8 %_354, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %107 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args34) #13
  %_348.0 = extractvalue { ptr, ptr } %107, 0
  %_348.1 = extractvalue { ptr, ptr } %107, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_348.0, ptr %_348.1)
; call core::hint::black_box::<u64>
  %_362 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 4294967297) #13
  %108 = trunc i64 %_362 to i32
  store i32 %108, ptr %_361, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_364, ptr align 4 %_361) #13
  %109 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args35, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %109, ptr align 8 %_364, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %110 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args35) #13
  %_358.0 = extractvalue { ptr, ptr } %110, 0
  %_358.1 = extractvalue { ptr, ptr } %110, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_358.0, ptr %_358.1)
; call core::hint::black_box::<u64>
  %_372 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 4294967297) #13
  %111 = uitofp i64 %_372 to float
  store float %111, ptr %_371, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_374, ptr align 4 %_371) #13
  %112 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args36, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %112, ptr align 8 %_374, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %113 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args36) #13
  %_368.0 = extractvalue { ptr, ptr } %113, 0
  %_368.1 = extractvalue { ptr, ptr } %113, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_368.0, ptr %_368.1)
; call core::hint::black_box::<u64>
  %_382 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 4294967297) #13
  %114 = uitofp i64 %_382 to double
  store double %114, ptr %_381, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_384, ptr align 8 %_381) #13
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args37, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_384, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %116 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args37) #13
  %_378.0 = extractvalue { ptr, ptr } %116, 0
  %_378.1 = extractvalue { ptr, ptr } %116, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_378.0, ptr %_378.1)
; call <core::fmt::Arguments>::from_str
  %117 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_388.0 = extractvalue { ptr, ptr } %117, 0
  %_388.1 = extractvalue { ptr, ptr } %117, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_388.0, ptr %_388.1)
; call core::hint::black_box::<i128>
  %_394 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs18dZLLqCRHT_5casts(i128 -170141183460469231731687303715884105728) #13
  %118 = trunc i128 %_394 to i8
  store i8 %118, ptr %_393, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_396, ptr %_393) #13
  %119 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args38, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %119, ptr align 8 %_396, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %120 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args38) #13
  %_390.0 = extractvalue { ptr, ptr } %120, 0
  %_390.1 = extractvalue { ptr, ptr } %120, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_390.0, ptr %_390.1)
; call core::hint::black_box::<i128>
  %_404 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs18dZLLqCRHT_5casts(i128 -170141183460469231731687303715884105728) #13
  %121 = trunc i128 %_404 to i64
  store i64 %121, ptr %_403, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_406, ptr align 8 %_403) #13
  %122 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args39, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %122, ptr align 8 %_406, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %123 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args39) #13
  %_400.0 = extractvalue { ptr, ptr } %123, 0
  %_400.1 = extractvalue { ptr, ptr } %123, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_400.0, ptr %_400.1)
; call core::hint::black_box::<i128>
  %_414 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs18dZLLqCRHT_5casts(i128 -170141183460469231731687303715884105728) #13
  %124 = trunc i128 %_414 to i64
  store i64 %124, ptr %_413, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_416, ptr align 8 %_413) #13
  %125 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args40, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %125, ptr align 8 %_416, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %126 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args40) #13
  %_410.0 = extractvalue { ptr, ptr } %126, 0
  %_410.1 = extractvalue { ptr, ptr } %126, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_410.0, ptr %_410.1)
; call core::hint::black_box::<i128>
  %_424 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs18dZLLqCRHT_5casts(i128 -170141183460469231731687303715884105728) #13
  store i128 %_424, ptr %_423, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_426, ptr align 16 %_423) #13
  %127 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args41, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %127, ptr align 8 %_426, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %128 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args41) #13
  %_420.0 = extractvalue { ptr, ptr } %128, 0
  %_420.1 = extractvalue { ptr, ptr } %128, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_420.0, ptr %_420.1)
; call core::hint::black_box::<i128>
  %_434 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs18dZLLqCRHT_5casts(i128 -170141183460469231731687303715884105728) #13
  %129 = sitofp i128 %_434 to float
  store float %129, ptr %_433, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_436, ptr align 4 %_433) #13
  %130 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args42, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %130, ptr align 8 %_436, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %131 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args42) #13
  %_430.0 = extractvalue { ptr, ptr } %131, 0
  %_430.1 = extractvalue { ptr, ptr } %131, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_430.0, ptr %_430.1)
; call core::hint::black_box::<i128>
  %_444 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs18dZLLqCRHT_5casts(i128 -170141183460469231731687303715884105728) #13
  %132 = sitofp i128 %_444 to double
  store double %132, ptr %_443, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_446, ptr align 8 %_443) #13
  %133 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args43, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %133, ptr align 8 %_446, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %134 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args43) #13
  %_440.0 = extractvalue { ptr, ptr } %134, 0
  %_440.1 = extractvalue { ptr, ptr } %134, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_440.0, ptr %_440.1)
; call <core::fmt::Arguments>::from_str
  %135 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_450.0 = extractvalue { ptr, ptr } %135, 0
  %_450.1 = extractvalue { ptr, ptr } %135, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_450.0, ptr %_450.1)
; call core::hint::black_box::<u128>
  %_456 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs18dZLLqCRHT_5casts(i128 -1) #13
  %136 = trunc i128 %_456 to i8
  store i8 %136, ptr %_455, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_458, ptr %_455) #13
  %137 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args44, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %137, ptr align 8 %_458, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %138 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args44) #13
  %_452.0 = extractvalue { ptr, ptr } %138, 0
  %_452.1 = extractvalue { ptr, ptr } %138, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_452.0, ptr %_452.1)
; call core::hint::black_box::<u128>
  %_466 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs18dZLLqCRHT_5casts(i128 -1) #13
  %139 = trunc i128 %_466 to i64
  store i64 %139, ptr %_465, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_468, ptr align 8 %_465) #13
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args45, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_468, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %141 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args45) #13
  %_462.0 = extractvalue { ptr, ptr } %141, 0
  %_462.1 = extractvalue { ptr, ptr } %141, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_462.0, ptr %_462.1)
; call core::hint::black_box::<u128>
  %_476 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs18dZLLqCRHT_5casts(i128 -1) #13
  store i128 %_476, ptr %_475, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_478, ptr align 16 %_475) #13
  %142 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args46, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %142, ptr align 8 %_478, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %143 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args46) #13
  %_472.0 = extractvalue { ptr, ptr } %143, 0
  %_472.1 = extractvalue { ptr, ptr } %143, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_472.0, ptr %_472.1)
; call core::hint::black_box::<u128>
  %_486 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs18dZLLqCRHT_5casts(i128 -1) #13
  %144 = trunc i128 %_486 to i64
  store i64 %144, ptr %_485, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_488, ptr align 8 %_485) #13
  %145 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args47, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %145, ptr align 8 %_488, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %146 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args47) #13
  %_482.0 = extractvalue { ptr, ptr } %146, 0
  %_482.1 = extractvalue { ptr, ptr } %146, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_482.0, ptr %_482.1)
; call core::hint::black_box::<u128>
  %_496 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs18dZLLqCRHT_5casts(i128 -1) #13
  %147 = uitofp i128 %_496 to float
  store float %147, ptr %_495, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_498, ptr align 4 %_495) #13
  %148 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args48, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %148, ptr align 8 %_498, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %149 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args48) #13
  %_492.0 = extractvalue { ptr, ptr } %149, 0
  %_492.1 = extractvalue { ptr, ptr } %149, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_492.0, ptr %_492.1)
; call core::hint::black_box::<u128>
  %_506 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs18dZLLqCRHT_5casts(i128 -1) #13
  %150 = uitofp i128 %_506 to double
  store double %150, ptr %_505, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_508, ptr align 8 %_505) #13
  %151 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args49, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %151, ptr align 8 %_508, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %152 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args49) #13
  %_502.0 = extractvalue { ptr, ptr } %152, 0
  %_502.1 = extractvalue { ptr, ptr } %152, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_502.0, ptr %_502.1)
; call <core::fmt::Arguments>::from_str
  %153 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_512.0 = extractvalue { ptr, ptr } %153, 0
  %_512.1 = extractvalue { ptr, ptr } %153, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_512.0, ptr %_512.1)
; call core::hint::black_box::<i32>
  %_518 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 -129) #13
  %154 = trunc i32 %_518 to i8
  store i8 %154, ptr %_517, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_520, ptr %_517) #13
  %155 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args50, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %155, ptr align 8 %_520, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %156 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args50) #13
  %_514.0 = extractvalue { ptr, ptr } %156, 0
  %_514.1 = extractvalue { ptr, ptr } %156, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_514.0, ptr %_514.1)
; call core::hint::black_box::<i32>
  %_528 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 -129) #13
  %157 = trunc i32 %_528 to i8
  store i8 %157, ptr %_527, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_530, ptr %_527) #13
  %158 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args51, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %158, ptr align 8 %_530, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %159 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args51) #13
  %_524.0 = extractvalue { ptr, ptr } %159, 0
  %_524.1 = extractvalue { ptr, ptr } %159, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_524.0, ptr %_524.1)
; call core::hint::black_box::<i32>
  %_538 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 -129) #13
  %160 = trunc i32 %_538 to i16
  store i16 %160, ptr %_537, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_540, ptr align 2 %_537) #13
  %161 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args52, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %161, ptr align 8 %_540, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %162 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args52) #13
  %_534.0 = extractvalue { ptr, ptr } %162, 0
  %_534.1 = extractvalue { ptr, ptr } %162, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_534.0, ptr %_534.1)
; call core::hint::black_box::<i32>
  %_548 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 -129) #13
  %163 = trunc i32 %_548 to i16
  store i16 %163, ptr %_547, align 2
; call <core::fmt::rt::Argument>::new_display::<u16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaytEB7_(ptr sret([16 x i8]) align 8 %_550, ptr align 2 %_547) #13
  %164 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args53, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %164, ptr align 8 %_550, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %165 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args53) #13
  %_544.0 = extractvalue { ptr, ptr } %165, 0
  %_544.1 = extractvalue { ptr, ptr } %165, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_544.0, ptr %_544.1)
; call core::hint::black_box::<i32>
  %_558 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 -129) #13
  %166 = sext i32 %_558 to i64
  store i64 %166, ptr %_557, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_560, ptr align 8 %_557) #13
  %167 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args54, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %167, ptr align 8 %_560, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %168 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args54) #13
  %_554.0 = extractvalue { ptr, ptr } %168, 0
  %_554.1 = extractvalue { ptr, ptr } %168, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_554.0, ptr %_554.1)
; call core::hint::black_box::<i32>
  %_568 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 -129) #13
  %169 = sitofp i32 %_568 to float
  store float %169, ptr %_567, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_570, ptr align 4 %_567) #13
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args55, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_570, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %171 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args55) #13
  %_564.0 = extractvalue { ptr, ptr } %171, 0
  %_564.1 = extractvalue { ptr, ptr } %171, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_564.0, ptr %_564.1)
; call <core::fmt::Arguments>::from_str
  %172 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_574.0 = extractvalue { ptr, ptr } %172, 0
  %_574.1 = extractvalue { ptr, ptr } %172, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_574.0, ptr %_574.1)
; call core::hint::black_box::<f64>
  %_580 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 3.990000e+00) #13
  %173 = call i8 @llvm.fptosi.sat.i8.f64(double %_580)
  store i8 %173, ptr %_579, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_582, ptr %_579) #13
  %174 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args56, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %174, ptr align 8 %_582, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %175 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args56) #13
  %_576.0 = extractvalue { ptr, ptr } %175, 0
  %_576.1 = extractvalue { ptr, ptr } %175, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_576.0, ptr %_576.1)
; call core::hint::black_box::<f64>
  %_590 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 3.990000e+00) #13
  %176 = call i8 @llvm.fptoui.sat.i8.f64(double %_590)
  store i8 %176, ptr %_589, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_592, ptr %_589) #13
  %177 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args57, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %177, ptr align 8 %_592, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %178 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args57) #13
  %_586.0 = extractvalue { ptr, ptr } %178, 0
  %_586.1 = extractvalue { ptr, ptr } %178, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_586.0, ptr %_586.1)
; call core::hint::black_box::<f64>
  %_600 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 3.990000e+00) #13
  %179 = call i32 @llvm.fptosi.sat.i32.f64(double %_600)
  store i32 %179, ptr %_599, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_602, ptr align 4 %_599) #13
  %180 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args58, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %180, ptr align 8 %_602, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %181 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args58) #13
  %_596.0 = extractvalue { ptr, ptr } %181, 0
  %_596.1 = extractvalue { ptr, ptr } %181, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_596.0, ptr %_596.1)
; call core::hint::black_box::<f64>
  %_610 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 3.990000e+00) #13
  %182 = call i32 @llvm.fptoui.sat.i32.f64(double %_610)
  store i32 %182, ptr %_609, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_612, ptr align 4 %_609) #13
  %183 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args59, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %183, ptr align 8 %_612, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %184 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args59) #13
  %_606.0 = extractvalue { ptr, ptr } %184, 0
  %_606.1 = extractvalue { ptr, ptr } %184, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_606.0, ptr %_606.1)
; call core::hint::black_box::<f64>
  %_620 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 3.990000e+00) #13
  %185 = call i64 @llvm.fptosi.sat.i64.f64(double %_620)
  store i64 %185, ptr %_619, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_622, ptr align 8 %_619) #13
  %186 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args60, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %186, ptr align 8 %_622, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %187 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args60) #13
  %_616.0 = extractvalue { ptr, ptr } %187, 0
  %_616.1 = extractvalue { ptr, ptr } %187, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_616.0, ptr %_616.1)
; call core::hint::black_box::<f64>
  %_630 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 3.990000e+00) #13
  %188 = call i64 @llvm.fptoui.sat.i64.f64(double %_630)
  store i64 %188, ptr %_629, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_632, ptr align 8 %_629) #13
  %189 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args61, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %189, ptr align 8 %_632, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %190 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args61) #13
  %_626.0 = extractvalue { ptr, ptr } %190, 0
  %_626.1 = extractvalue { ptr, ptr } %190, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_626.0, ptr %_626.1)
; call core::hint::black_box::<f64>
  %_640 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 3.990000e+00) #13
  %191 = call i128 @llvm.fptosi.sat.i128.f64(double %_640)
  store i128 %191, ptr %_639, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_642, ptr align 16 %_639) #13
  %192 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args62, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %192, ptr align 8 %_642, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %193 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args62) #13
  %_636.0 = extractvalue { ptr, ptr } %193, 0
  %_636.1 = extractvalue { ptr, ptr } %193, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_636.0, ptr %_636.1)
; call core::hint::black_box::<f64>
  %_650 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 3.990000e+00) #13
  %194 = call i128 @llvm.fptoui.sat.i128.f64(double %_650)
  store i128 %194, ptr %_649, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_652, ptr align 16 %_649) #13
  %195 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args63, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %195, ptr align 8 %_652, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %196 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args63) #13
  %_646.0 = extractvalue { ptr, ptr } %196, 0
  %_646.1 = extractvalue { ptr, ptr } %196, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_646.0, ptr %_646.1)
; call core::hint::black_box::<f64>
  %_660 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 3.990000e+00) #13
  %197 = fptrunc double %_660 to float
  store float %197, ptr %_659, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_662, ptr align 4 %_659) #13
  %198 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args64, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %198, ptr align 8 %_662, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %199 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args64) #13
  %_656.0 = extractvalue { ptr, ptr } %199, 0
  %_656.1 = extractvalue { ptr, ptr } %199, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_656.0, ptr %_656.1)
; call <core::fmt::Arguments>::from_str
  %200 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_666.0 = extractvalue { ptr, ptr } %200, 0
  %_666.1 = extractvalue { ptr, ptr } %200, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_666.0, ptr %_666.1)
; call core::hint::black_box::<f64>
  %_672 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -3.990000e+00) #13
  %201 = call i8 @llvm.fptosi.sat.i8.f64(double %_672)
  store i8 %201, ptr %_671, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_674, ptr %_671) #13
  %202 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args65, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %202, ptr align 8 %_674, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %203 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args65) #13
  %_668.0 = extractvalue { ptr, ptr } %203, 0
  %_668.1 = extractvalue { ptr, ptr } %203, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_668.0, ptr %_668.1)
; call core::hint::black_box::<f64>
  %_682 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -3.990000e+00) #13
  %204 = call i8 @llvm.fptoui.sat.i8.f64(double %_682)
  store i8 %204, ptr %_681, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_684, ptr %_681) #13
  %205 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args66, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %205, ptr align 8 %_684, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %206 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args66) #13
  %_678.0 = extractvalue { ptr, ptr } %206, 0
  %_678.1 = extractvalue { ptr, ptr } %206, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_678.0, ptr %_678.1)
; call core::hint::black_box::<f64>
  %_692 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -3.990000e+00) #13
  %207 = call i32 @llvm.fptosi.sat.i32.f64(double %_692)
  store i32 %207, ptr %_691, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_694, ptr align 4 %_691) #13
  %208 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args67, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %208, ptr align 8 %_694, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %209 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args67) #13
  %_688.0 = extractvalue { ptr, ptr } %209, 0
  %_688.1 = extractvalue { ptr, ptr } %209, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_688.0, ptr %_688.1)
; call core::hint::black_box::<f64>
  %_702 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -3.990000e+00) #13
  %210 = call i32 @llvm.fptoui.sat.i32.f64(double %_702)
  store i32 %210, ptr %_701, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_704, ptr align 4 %_701) #13
  %211 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args68, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %211, ptr align 8 %_704, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %212 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args68) #13
  %_698.0 = extractvalue { ptr, ptr } %212, 0
  %_698.1 = extractvalue { ptr, ptr } %212, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_698.0, ptr %_698.1)
; call core::hint::black_box::<f64>
  %_712 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -3.990000e+00) #13
  %213 = call i64 @llvm.fptosi.sat.i64.f64(double %_712)
  store i64 %213, ptr %_711, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_714, ptr align 8 %_711) #13
  %214 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args69, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %214, ptr align 8 %_714, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %215 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args69) #13
  %_708.0 = extractvalue { ptr, ptr } %215, 0
  %_708.1 = extractvalue { ptr, ptr } %215, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_708.0, ptr %_708.1)
; call core::hint::black_box::<f64>
  %_722 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -3.990000e+00) #13
  %216 = call i64 @llvm.fptoui.sat.i64.f64(double %_722)
  store i64 %216, ptr %_721, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_724, ptr align 8 %_721) #13
  %217 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args70, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %217, ptr align 8 %_724, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %218 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args70) #13
  %_718.0 = extractvalue { ptr, ptr } %218, 0
  %_718.1 = extractvalue { ptr, ptr } %218, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_718.0, ptr %_718.1)
; call core::hint::black_box::<f64>
  %_732 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -3.990000e+00) #13
  %219 = call i128 @llvm.fptosi.sat.i128.f64(double %_732)
  store i128 %219, ptr %_731, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_734, ptr align 16 %_731) #13
  %220 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args71, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %220, ptr align 8 %_734, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %221 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args71) #13
  %_728.0 = extractvalue { ptr, ptr } %221, 0
  %_728.1 = extractvalue { ptr, ptr } %221, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_728.0, ptr %_728.1)
; call core::hint::black_box::<f64>
  %_742 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -3.990000e+00) #13
  %222 = call i128 @llvm.fptoui.sat.i128.f64(double %_742)
  store i128 %222, ptr %_741, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_744, ptr align 16 %_741) #13
  %223 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args72, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %223, ptr align 8 %_744, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %224 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args72) #13
  %_738.0 = extractvalue { ptr, ptr } %224, 0
  %_738.1 = extractvalue { ptr, ptr } %224, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_738.0, ptr %_738.1)
; call core::hint::black_box::<f64>
  %_752 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -3.990000e+00) #13
  %225 = fptrunc double %_752 to float
  store float %225, ptr %_751, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_754, ptr align 4 %_751) #13
  %226 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args73, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %226, ptr align 8 %_754, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %227 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args73) #13
  %_748.0 = extractvalue { ptr, ptr } %227, 0
  %_748.1 = extractvalue { ptr, ptr } %227, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_748.0, ptr %_748.1)
; call <core::fmt::Arguments>::from_str
  %228 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_758.0 = extractvalue { ptr, ptr } %228, 0
  %_758.1 = extractvalue { ptr, ptr } %228, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_758.0, ptr %_758.1)
; call core::hint::black_box::<f64>
  %_764 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 1.000000e+19) #13
  %229 = call i64 @llvm.fptosi.sat.i64.f64(double %_764)
  store i64 %229, ptr %_763, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_766, ptr align 8 %_763) #13
  %230 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args74, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %230, ptr align 8 %_766, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %231 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args74) #13
  %_760.0 = extractvalue { ptr, ptr } %231, 0
  %_760.1 = extractvalue { ptr, ptr } %231, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_760.0, ptr %_760.1)
; call core::hint::black_box::<f64>
  %_774 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 1.000000e+19) #13
  %232 = call i64 @llvm.fptoui.sat.i64.f64(double %_774)
  store i64 %232, ptr %_773, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_776, ptr align 8 %_773) #13
  %233 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args75, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %233, ptr align 8 %_776, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %234 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args75) #13
  %_770.0 = extractvalue { ptr, ptr } %234, 0
  %_770.1 = extractvalue { ptr, ptr } %234, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_770.0, ptr %_770.1)
; call core::hint::black_box::<f64>
  %_784 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 1.000000e+19) #13
  %235 = call i128 @llvm.fptosi.sat.i128.f64(double %_784)
  store i128 %235, ptr %_783, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_786, ptr align 16 %_783) #13
  %236 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args76, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %236, ptr align 8 %_786, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %237 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args76) #13
  %_780.0 = extractvalue { ptr, ptr } %237, 0
  %_780.1 = extractvalue { ptr, ptr } %237, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_780.0, ptr %_780.1)
; call core::hint::black_box::<f64>
  %_794 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 1.000000e+19) #13
  %238 = call i128 @llvm.fptoui.sat.i128.f64(double %_794)
  store i128 %238, ptr %_793, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_796, ptr align 16 %_793) #13
  %239 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args77, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %239, ptr align 8 %_796, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %240 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args77) #13
  %_790.0 = extractvalue { ptr, ptr } %240, 0
  %_790.1 = extractvalue { ptr, ptr } %240, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_790.0, ptr %_790.1)
; call core::hint::black_box::<f64>
  %_804 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 1.000000e+19) #13
  %241 = fptrunc double %_804 to float
  store float %241, ptr %_803, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_806, ptr align 4 %_803) #13
  %242 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args78, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %242, ptr align 8 %_806, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %243 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args78) #13
  %_800.0 = extractvalue { ptr, ptr } %243, 0
  %_800.1 = extractvalue { ptr, ptr } %243, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_800.0, ptr %_800.1)
; call <core::fmt::Arguments>::from_str
  %244 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_810.0 = extractvalue { ptr, ptr } %244, 0
  %_810.1 = extractvalue { ptr, ptr } %244, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_810.0, ptr %_810.1)
; call core::hint::black_box::<f64>
  %_816 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +qnan) #13
  %245 = call i8 @llvm.fptosi.sat.i8.f64(double %_816)
  store i8 %245, ptr %_815, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_818, ptr %_815) #13
  %246 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args79, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %246, ptr align 8 %_818, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %247 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args79) #13
  %_812.0 = extractvalue { ptr, ptr } %247, 0
  %_812.1 = extractvalue { ptr, ptr } %247, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_812.0, ptr %_812.1)
; call core::hint::black_box::<f64>
  %_826 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +qnan) #13
  %248 = call i8 @llvm.fptoui.sat.i8.f64(double %_826)
  store i8 %248, ptr %_825, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_828, ptr %_825) #13
  %249 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args80, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %249, ptr align 8 %_828, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %250 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args80) #13
  %_822.0 = extractvalue { ptr, ptr } %250, 0
  %_822.1 = extractvalue { ptr, ptr } %250, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_822.0, ptr %_822.1)
; call core::hint::black_box::<f64>
  %_836 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +qnan) #13
  %251 = call i32 @llvm.fptosi.sat.i32.f64(double %_836)
  store i32 %251, ptr %_835, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_838, ptr align 4 %_835) #13
  %252 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args81, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %252, ptr align 8 %_838, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %253 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args81) #13
  %_832.0 = extractvalue { ptr, ptr } %253, 0
  %_832.1 = extractvalue { ptr, ptr } %253, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_832.0, ptr %_832.1)
; call core::hint::black_box::<f64>
  %_846 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +qnan) #13
  %254 = call i64 @llvm.fptoui.sat.i64.f64(double %_846)
  store i64 %254, ptr %_845, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_848, ptr align 8 %_845) #13
  %255 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args82, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %255, ptr align 8 %_848, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %256 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args82) #13
  %_842.0 = extractvalue { ptr, ptr } %256, 0
  %_842.1 = extractvalue { ptr, ptr } %256, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_842.0, ptr %_842.1)
; call core::hint::black_box::<f64>
  %_856 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +qnan) #13
  %257 = call i128 @llvm.fptosi.sat.i128.f64(double %_856)
  store i128 %257, ptr %_855, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_858, ptr align 16 %_855) #13
  %258 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args83, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %258, ptr align 8 %_858, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %259 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args83) #13
  %_852.0 = extractvalue { ptr, ptr } %259, 0
  %_852.1 = extractvalue { ptr, ptr } %259, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_852.0, ptr %_852.1)
; call core::hint::black_box::<f64>
  %_866 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +qnan) #13
  %260 = fptrunc double %_866 to float
  store float %260, ptr %_865, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_868, ptr align 4 %_865) #13
  %261 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args84, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %261, ptr align 8 %_868, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %262 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args84) #13
  %_862.0 = extractvalue { ptr, ptr } %262, 0
  %_862.1 = extractvalue { ptr, ptr } %262, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_862.0, ptr %_862.1)
; call <core::fmt::Arguments>::from_str
  %263 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_872.0 = extractvalue { ptr, ptr } %263, 0
  %_872.1 = extractvalue { ptr, ptr } %263, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_872.0, ptr %_872.1)
; call core::hint::black_box::<f64>
  %_878 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +inf) #13
  %264 = call i8 @llvm.fptosi.sat.i8.f64(double %_878)
  store i8 %264, ptr %_877, align 1
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_880, ptr %_877) #13
  %265 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args85, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %265, ptr align 8 %_880, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %266 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args85) #13
  %_874.0 = extractvalue { ptr, ptr } %266, 0
  %_874.1 = extractvalue { ptr, ptr } %266, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_874.0, ptr %_874.1)
; call core::hint::black_box::<f64>
  %_888 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +inf) #13
  %267 = call i8 @llvm.fptoui.sat.i8.f64(double %_888)
  store i8 %267, ptr %_887, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_890, ptr %_887) #13
  %268 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args86, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %268, ptr align 8 %_890, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %269 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args86) #13
  %_884.0 = extractvalue { ptr, ptr } %269, 0
  %_884.1 = extractvalue { ptr, ptr } %269, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_884.0, ptr %_884.1)
; call core::hint::black_box::<f64>
  %_898 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +inf) #13
  %270 = call i32 @llvm.fptosi.sat.i32.f64(double %_898)
  store i32 %270, ptr %_897, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_900, ptr align 4 %_897) #13
  %271 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args87, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %271, ptr align 8 %_900, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %272 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args87) #13
  %_894.0 = extractvalue { ptr, ptr } %272, 0
  %_894.1 = extractvalue { ptr, ptr } %272, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_894.0, ptr %_894.1)
; call core::hint::black_box::<f64>
  %_908 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +inf) #13
  %273 = call i64 @llvm.fptoui.sat.i64.f64(double %_908)
  store i64 %273, ptr %_907, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_910, ptr align 8 %_907) #13
  %274 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args88, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %274, ptr align 8 %_910, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %275 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args88) #13
  %_904.0 = extractvalue { ptr, ptr } %275, 0
  %_904.1 = extractvalue { ptr, ptr } %275, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_904.0, ptr %_904.1)
; call core::hint::black_box::<f64>
  %_918 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +inf) #13
  %276 = call i128 @llvm.fptoui.sat.i128.f64(double %_918)
  store i128 %276, ptr %_917, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_920, ptr align 16 %_917) #13
  %277 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args89, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %277, ptr align 8 %_920, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %278 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args89) #13
  %_914.0 = extractvalue { ptr, ptr } %278, 0
  %_914.1 = extractvalue { ptr, ptr } %278, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_914.0, ptr %_914.1)
; call core::hint::black_box::<f64>
  %_928 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double +inf) #13
  %279 = fptrunc double %_928 to float
  store float %279, ptr %_927, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_930, ptr align 4 %_927) #13
  %280 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args90, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %280, ptr align 8 %_930, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %281 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args90) #13
  %_924.0 = extractvalue { ptr, ptr } %281, 0
  %_924.1 = extractvalue { ptr, ptr } %281, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_924.0, ptr %_924.1)
; call <core::fmt::Arguments>::from_str
  %282 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_934.0 = extractvalue { ptr, ptr } %282, 0
  %_934.1 = extractvalue { ptr, ptr } %282, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_934.0, ptr %_934.1)
; call core::hint::black_box::<f64>
  %_940 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -1.000000e+300) #13
  %283 = call i32 @llvm.fptosi.sat.i32.f64(double %_940)
  store i32 %283, ptr %_939, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_942, ptr align 4 %_939) #13
  %284 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args91, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %284, ptr align 8 %_942, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %285 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args91) #13
  %_936.0 = extractvalue { ptr, ptr } %285, 0
  %_936.1 = extractvalue { ptr, ptr } %285, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_936.0, ptr %_936.1)
; call core::hint::black_box::<f64>
  %_950 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -1.000000e+300) #13
  %286 = call i32 @llvm.fptoui.sat.i32.f64(double %_950)
  store i32 %286, ptr %_949, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_952, ptr align 4 %_949) #13
  %287 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args92, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %287, ptr align 8 %_952, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %288 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args92) #13
  %_946.0 = extractvalue { ptr, ptr } %288, 0
  %_946.1 = extractvalue { ptr, ptr } %288, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_946.0, ptr %_946.1)
; call core::hint::black_box::<f64>
  %_960 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -1.000000e+300) #13
  %289 = call i64 @llvm.fptosi.sat.i64.f64(double %_960)
  store i64 %289, ptr %_959, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_962, ptr align 8 %_959) #13
  %290 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args93, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %290, ptr align 8 %_962, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %291 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args93) #13
  %_956.0 = extractvalue { ptr, ptr } %291, 0
  %_956.1 = extractvalue { ptr, ptr } %291, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_956.0, ptr %_956.1)
; call core::hint::black_box::<f64>
  %_970 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -1.000000e+300) #13
  %292 = call i128 @llvm.fptosi.sat.i128.f64(double %_970)
  store i128 %292, ptr %_969, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_972, ptr align 16 %_969) #13
  %293 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args94, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %293, ptr align 8 %_972, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %294 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args94) #13
  %_966.0 = extractvalue { ptr, ptr } %294, 0
  %_966.1 = extractvalue { ptr, ptr } %294, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_966.0, ptr %_966.1)
; call core::hint::black_box::<f64>
  %_980 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double -1.000000e+300) #13
  %295 = fptrunc double %_980 to float
  store float %295, ptr %_979, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_982, ptr align 4 %_979) #13
  %296 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args95, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %296, ptr align 8 %_982, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %297 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args95) #13
  %_976.0 = extractvalue { ptr, ptr } %297, 0
  %_976.1 = extractvalue { ptr, ptr } %297, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_976.0, ptr %_976.1)
; call <core::fmt::Arguments>::from_str
  %298 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_986.0 = extractvalue { ptr, ptr } %298, 0
  %_986.1 = extractvalue { ptr, ptr } %298, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_986.0, ptr %_986.1)
; call core::hint::black_box::<i32>
  %_992 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 16777217) #13
  %299 = sitofp i32 %_992 to float
  store float %299, ptr %_991, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_994, ptr align 4 %_991) #13
  %300 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args96, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %300, ptr align 8 %_994, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %301 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args96) #13
  %_988.0 = extractvalue { ptr, ptr } %301, 0
  %_988.1 = extractvalue { ptr, ptr } %301, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_988.0, ptr %_988.1)
; call core::hint::black_box::<i32>
  %_1002 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 16777217) #13
  %302 = sitofp i32 %_1002 to double
  store double %302, ptr %_1001, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1004, ptr align 8 %_1001) #13
  %303 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args97, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %303, ptr align 8 %_1004, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %304 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args97) #13
  %_998.0 = extractvalue { ptr, ptr } %304, 0
  %_998.1 = extractvalue { ptr, ptr } %304, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_998.0, ptr %_998.1)
; call <core::fmt::Arguments>::from_str
  %305 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_1008.0 = extractvalue { ptr, ptr } %305, 0
  %_1008.1 = extractvalue { ptr, ptr } %305, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1008.0, ptr %_1008.1)
; call core::hint::black_box::<u64>
  %_1014 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 -1) #13
  %306 = uitofp i64 %_1014 to float
  store float %306, ptr %_1013, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1016, ptr align 4 %_1013) #13
  %307 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args98, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %307, ptr align 8 %_1016, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %308 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args98) #13
  %_1010.0 = extractvalue { ptr, ptr } %308, 0
  %_1010.1 = extractvalue { ptr, ptr } %308, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1010.0, ptr %_1010.1)
; call core::hint::black_box::<u64>
  %_1024 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 -1) #13
  %309 = uitofp i64 %_1024 to double
  store double %309, ptr %_1023, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1026, ptr align 8 %_1023) #13
  %310 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args99, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %310, ptr align 8 %_1026, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %311 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args99) #13
  %_1020.0 = extractvalue { ptr, ptr } %311, 0
  %_1020.1 = extractvalue { ptr, ptr } %311, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1020.0, ptr %_1020.1)
; call core::hint::black_box::<u64>
  %_1034 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs18dZLLqCRHT_5casts(i64 -1) #13
  store i64 %_1034, ptr %_1033, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1036, ptr align 8 %_1033) #13
  %312 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args100, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %312, ptr align 8 %_1036, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %313 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args100) #13
  %_1030.0 = extractvalue { ptr, ptr } %313, 0
  %_1030.1 = extractvalue { ptr, ptr } %313, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1030.0, ptr %_1030.1)
; call <core::fmt::Arguments>::from_str
  %314 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_1040.0 = extractvalue { ptr, ptr } %314, 0
  %_1040.1 = extractvalue { ptr, ptr } %314, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1040.0, ptr %_1040.1)
; call core::hint::black_box::<f32>
  %_1046 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs18dZLLqCRHT_5casts(float 1.500000e+00) #13
  %315 = fpext float %_1046 to double
  store double %315, ptr %_1045, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1048, ptr align 8 %_1045) #13
  %316 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args101, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %316, ptr align 8 %_1048, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %317 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args101) #13
  %_1042.0 = extractvalue { ptr, ptr } %317, 0
  %_1042.1 = extractvalue { ptr, ptr } %317, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1042.0, ptr %_1042.1)
; call core::hint::black_box::<f32>
  %_1056 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs18dZLLqCRHT_5casts(float 1.500000e+00) #13
  %318 = call i32 @llvm.fptosi.sat.i32.f32(float %_1056)
  store i32 %318, ptr %_1055, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_1058, ptr align 4 %_1055) #13
  %319 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args102, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %319, ptr align 8 %_1058, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %320 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args102) #13
  %_1052.0 = extractvalue { ptr, ptr } %320, 0
  %_1052.1 = extractvalue { ptr, ptr } %320, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1052.0, ptr %_1052.1)
; call core::hint::black_box::<f32>
  %_1066 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs18dZLLqCRHT_5casts(float 1.500000e+00) #13
  %321 = call i8 @llvm.fptoui.sat.i8.f32(float %_1066)
  store i8 %321, ptr %_1065, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_1068, ptr %_1065) #13
  %322 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args103, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %322, ptr align 8 %_1068, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %323 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args103) #13
  %_1062.0 = extractvalue { ptr, ptr } %323, 0
  %_1062.1 = extractvalue { ptr, ptr } %323, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1062.0, ptr %_1062.1)
; call core::hint::black_box::<f32>
  %_1076 = call float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs18dZLLqCRHT_5casts(float 1.500000e+00) #13
  %324 = call i64 @llvm.fptoui.sat.i64.f32(float %_1076)
  store i64 %324, ptr %_1075, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_1078, ptr align 8 %_1075) #13
  %325 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args104, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %325, ptr align 8 %_1078, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %326 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args104) #13
  %_1072.0 = extractvalue { ptr, ptr } %326, 0
  %_1072.1 = extractvalue { ptr, ptr } %326, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1072.0, ptr %_1072.1)
; call <core::fmt::Arguments>::from_str
  %327 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_1082.0 = extractvalue { ptr, ptr } %327, 0
  %_1082.1 = extractvalue { ptr, ptr } %327, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1082.0, ptr %_1082.1)
; call core::hint::black_box::<f64>
  %_1088 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 1.000000e+40) #13
  %328 = fptrunc double %_1088 to float
  store float %328, ptr %_1087, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1090, ptr align 4 %_1087) #13
  %329 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args105, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %329, ptr align 8 %_1090, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %330 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args105) #13
  %_1084.0 = extractvalue { ptr, ptr } %330, 0
  %_1084.1 = extractvalue { ptr, ptr } %330, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1084.0, ptr %_1084.1)
; call core::hint::black_box::<f64>
  %_1098 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs18dZLLqCRHT_5casts(double 1.000000e+40) #13
  %331 = call i64 @llvm.fptosi.sat.i64.f64(double %_1098)
  store i64 %331, ptr %_1097, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1100, ptr align 8 %_1097) #13
  %332 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args106, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %332, ptr align 8 %_1100, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %333 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args106) #13
  %_1094.0 = extractvalue { ptr, ptr } %333, 0
  %_1094.1 = extractvalue { ptr, ptr } %333, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1094.0, ptr %_1094.1)
; call <core::fmt::Arguments>::from_str
  %334 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_1104.0 = extractvalue { ptr, ptr } %334, 0
  %_1104.1 = extractvalue { ptr, ptr } %334, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1104.0, ptr %_1104.1)
; call core::hint::black_box::<bool>
  %_1110 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECs18dZLLqCRHT_5casts(i1 zeroext true) #13
  %335 = zext i1 %_1110 to i32
  store i32 %335, ptr %_1109, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_1112, ptr align 4 %_1109) #13
  %336 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args107, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %336, ptr align 8 %_1112, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %337 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args107) #13
  %_1106.0 = extractvalue { ptr, ptr } %337, 0
  %_1106.1 = extractvalue { ptr, ptr } %337, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1106.0, ptr %_1106.1)
; call core::hint::black_box::<bool>
  %_1120 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECs18dZLLqCRHT_5casts(i1 zeroext true) #13
  %338 = zext i1 %_1120 to i8
  store i8 %338, ptr %_1119, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_1122, ptr %_1119) #13
  %339 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args108, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %339, ptr align 8 %_1122, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %340 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args108) #13
  %_1116.0 = extractvalue { ptr, ptr } %340, 0
  %_1116.1 = extractvalue { ptr, ptr } %340, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1116.0, ptr %_1116.1)
; call core::hint::black_box::<bool>
  %_1130 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxbECs18dZLLqCRHT_5casts(i1 zeroext true) #13
  %341 = zext i1 %_1130 to i128
  store i128 %341, ptr %_1129, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1132, ptr align 16 %_1129) #13
  %342 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args109, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %342, ptr align 8 %_1132, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %343 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args109) #13
  %_1126.0 = extractvalue { ptr, ptr } %343, 0
  %_1126.1 = extractvalue { ptr, ptr } %343, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1126.0, ptr %_1126.1)
; call <core::fmt::Arguments>::from_str
  %344 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_1136.0 = extractvalue { ptr, ptr } %344, 0
  %_1136.1 = extractvalue { ptr, ptr } %344, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1136.0, ptr %_1136.1)
; call core::hint::black_box::<char>
  %_1142 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxcECs18dZLLqCRHT_5casts(i32 233) #13
  %345 = trunc i32 %_1142 to i8
  store i8 %345, ptr %_1141, align 1
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_1144, ptr %_1141) #13
  %346 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args110, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %346, ptr align 8 %_1144, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %347 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args110) #13
  %_1138.0 = extractvalue { ptr, ptr } %347, 0
  %_1138.1 = extractvalue { ptr, ptr } %347, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1138.0, ptr %_1138.1)
; call core::hint::black_box::<char>
  %_1152 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxcECs18dZLLqCRHT_5casts(i32 233) #13
  store i32 %_1152, ptr %_1151, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_1154, ptr align 4 %_1151) #13
  %348 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args111, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %348, ptr align 8 %_1154, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %349 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args111) #13
  %_1148.0 = extractvalue { ptr, ptr } %349, 0
  %_1148.1 = extractvalue { ptr, ptr } %349, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1148.0, ptr %_1148.1)
; call core::hint::black_box::<char>
  %_1162 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxcECs18dZLLqCRHT_5casts(i32 233) #13
  %350 = trunc i32 %_1162 to i16
  store i16 %350, ptr %_1161, align 2
; call <core::fmt::rt::Argument>::new_display::<i16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1164, ptr align 2 %_1161) #13
  %351 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args112, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %351, ptr align 8 %_1164, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %352 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_1b8da18ba9175148bb2e455ee98c556c, ptr align 8 %args112) #13
  %_1158.0 = extractvalue { ptr, ptr } %352, 0
  %_1158.1 = extractvalue { ptr, ptr } %352, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1158.0, ptr %_1158.1)
; call <core::fmt::Arguments>::from_str
  %353 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1) #13
  %_1168.0 = extractvalue { ptr, ptr } %353, 0
  %_1168.1 = extractvalue { ptr, ptr } %353, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1168.0, ptr %_1168.1)
; call core::hint::black_box::<u8>
  %_1175 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 97) #13
  %_1174 = zext i8 %_1175 to i32
  store i32 %_1174, ptr %_1173, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_1177, ptr align 4 %_1173) #13
  %354 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args113, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %354, ptr align 8 %_1177, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %355 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args113) #13
  %_1170.0 = extractvalue { ptr, ptr } %355, 0
  %_1170.1 = extractvalue { ptr, ptr } %355, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1170.0, ptr %_1170.1)
; call core::hint::black_box::<u32>
  %_1185 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs18dZLLqCRHT_5casts(i32 55296) #13
; call <char>::from_u32
  %356 = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8from_u32Cs18dZLLqCRHT_5casts(i32 %_1185) #13
  store i32 %356, ptr %_1184, align 4
; call core::hint::black_box::<u8>
  %_1188 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 65) #13
; call <char as core::convert::From<u8>>::from
  %357 = call i32 @_RNvXs4_NtNtCsl10jNU3mE6R_4core4char7convertcINtNtB9_7convert4FromhE4fromCs18dZLLqCRHT_5casts(i8 %_1188) #13
  store i32 %357, ptr %_1187, align 4
; call core::hint::black_box::<i32>
  %_1193 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 300) #13
; call <u8 as core::convert::TryFrom<i32>>::try_from
  %358 = call { i1, i8 } @_RNvXs2S_NtNtCsl10jNU3mE6R_4core7convert3numhINtB8_7TryFromlE8try_fromCs18dZLLqCRHT_5casts(i32 %_1193) #13
  %359 = extractvalue { i1, i8 } %358, 0
  %360 = extractvalue { i1, i8 } %358, 1
  %361 = zext i1 %359 to i8
  store i8 %361, ptr %_1192, align 1
  %362 = getelementptr inbounds i8, ptr %_1192, i64 1
  store i8 %360, ptr %362, align 1
; call <core::result::Result<u8, core::num::error::TryFromIntError>>::is_err
  %363 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtNtB4_3num5error15TryFromIntErrorE6is_errCs18dZLLqCRHT_5casts(ptr %_1192) #13
  %364 = zext i1 %363 to i8
  store i8 %364, ptr %_1190, align 1
  store ptr %_1184, ptr %args114, align 8
  %365 = getelementptr inbounds i8, ptr %args114, i64 8
  store ptr %_1187, ptr %365, align 8
  %366 = getelementptr inbounds i8, ptr %args114, i64 16
  store ptr %_1190, ptr %366, align 8
  %_1384 = load ptr, ptr %args114, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<char>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptioncEECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1195, ptr align 4 %_1384) #13
  %367 = getelementptr inbounds i8, ptr %args114, i64 8
  %_1385 = load ptr, ptr %367, align 8
; call <core::fmt::rt::Argument>::new_debug::<char>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugcEB7_(ptr sret([16 x i8]) align 8 %_1196, ptr align 4 %_1385) #13
  %368 = getelementptr inbounds i8, ptr %args114, i64 16
  %_1386 = load ptr, ptr %368, align 8
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1197, ptr %_1386) #13
  %369 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args115, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %369, ptr align 8 %_1195, i64 16, i1 false)
  %370 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args115, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %370, ptr align 8 %_1196, i64 16, i1 false)
  %371 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args115, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %371, ptr align 8 %_1197, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %372 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs18dZLLqCRHT_5casts(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args115) #13
  %_1181.0 = extractvalue { ptr, ptr } %372, 0
  %_1181.1 = extractvalue { ptr, ptr } %372, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1181.0, ptr %_1181.1)
; call core::hint::black_box::<i64>
  %_1205 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs18dZLLqCRHT_5casts(i64 -128) #13
; call <i8 as core::convert::TryFrom<i64>>::try_from
  %373 = call { i1, i8 } @_RNvXs2m_NtNtCsl10jNU3mE6R_4core7convert3numaINtB8_7TryFromxE8try_fromCs18dZLLqCRHT_5casts(i64 %_1205) #13
  %374 = extractvalue { i1, i8 } %373, 0
  %375 = extractvalue { i1, i8 } %373, 1
  %376 = zext i1 %374 to i8
  store i8 %376, ptr %_1204, align 1
  %377 = getelementptr inbounds i8, ptr %_1204, i64 1
  store i8 %375, ptr %377, align 1
; call core::hint::black_box::<i8>
  %_1210 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs18dZLLqCRHT_5casts(i8 -1) #13
; call <u32 as core::convert::TryFrom<i8>>::try_from
  %378 = call i64 @_RNvXs2K_NtNtCsl10jNU3mE6R_4core7convert3nummINtB8_7TryFromaE8try_fromCs18dZLLqCRHT_5casts(i8 %_1210) #13
  store i64 %378, ptr %4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_1209, ptr align 8 %4, i64 8, i1 false)
; call <core::result::Result<u32, core::num::error::TryFromIntError>>::is_err
  %379 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmNtNtNtB4_3num5error15TryFromIntErrorE6is_errCs18dZLLqCRHT_5casts(ptr align 4 %_1209) #13
  %380 = zext i1 %379 to i8
  store i8 %380, ptr %_1207, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i8, core::num::error::TryFromIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultaNtNtNtB7_3num5error15TryFromIntErrorEECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1212, ptr %_1204) #13
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1213, ptr %_1207) #13
  %381 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args116, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %381, ptr align 8 %_1212, i64 16, i1 false)
  %382 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args116, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %382, ptr align 8 %_1213, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %383 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args116) #13
  %_1201.0 = extractvalue { ptr, ptr } %383, 0
  %_1201.1 = extractvalue { ptr, ptr } %383, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1201.0, ptr %_1201.1)
; call core::hint::black_box::<u16>
  %_1218 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs18dZLLqCRHT_5casts(i16 4660) #13
  %384 = zext i16 %_1218 to i64
  %_1217 = inttoptr i64 %384 to ptr
  %385 = ptrtoint ptr %_1217 to i64
  store i64 %385, ptr %p, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_1224, ptr align 8 %p) #13
  %386 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args117, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %386, ptr align 8 %_1224, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %387 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args117) #13
  %_1220.0 = extractvalue { ptr, ptr } %387, 0
  %_1220.1 = extractvalue { ptr, ptr } %387, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1220.0, ptr %_1220.1)
; call core::hint::black_box::<i32>
  %_1233 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 -1) #13
  %388 = zext i32 %_1233 to i64
  store i64 %388, ptr %_1231, align 8
; call core::hint::black_box::<i32>
  %_1237 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs18dZLLqCRHT_5casts(i32 -1) #13
  %_1236 = sext i32 %_1237 to i64
  store i64 %_1236, ptr %_1235, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_1239, ptr align 8 %_1231) #13
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_1240, ptr align 8 %_1235) #13
  %389 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args118, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %389, ptr align 8 %_1239, i64 16, i1 false)
  %390 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args118, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %390, ptr align 8 %_1240, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %391 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args118) #13
  %_1228.0 = extractvalue { ptr, ptr } %391, 0
  %_1228.1 = extractvalue { ptr, ptr } %391, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1228.0, ptr %_1228.1)
; call core::hint::black_box::<u8>
  %_1249 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs18dZLLqCRHT_5casts(i8 -56) #13
  %392 = sext i8 %_1249 to i32
  store i32 %392, ptr %_1247, align 4
; call core::hint::black_box::<i8>
  %_1253 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs18dZLLqCRHT_5casts(i8 -56) #13
  %393 = zext i8 %_1253 to i32
  store i32 %393, ptr %_1251, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_1255, ptr align 4 %_1247) #13
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_1256, ptr align 4 %_1251) #13
  %394 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args119, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %394, ptr align 8 %_1255, i64 16, i1 false)
  %395 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args119, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %395, ptr align 8 %_1256, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %396 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args119) #13
  %_1244.0 = extractvalue { ptr, ptr } %396, 0
  %_1244.1 = extractvalue { ptr, ptr } %396, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1244.0, ptr %_1244.1)
  %397 = getelementptr inbounds nuw float, ptr %_1265, i64 0
  store float 1.500000e+00, ptr %397, align 4
  %398 = getelementptr inbounds nuw float, ptr %_1265, i64 1
  store float -0.000000e+00, ptr %398, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 4 %_1265, i64 8, i1 false)
  %399 = load i64, ptr %3, align 8
; call core::hint::black_box::<[f32; 2]>
  %400 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxAfj2_ECs18dZLLqCRHT_5casts(i64 %399) #13
  store i64 %400, ptr %2, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_1264, ptr align 8 %2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 4 %_1264, i64 8, i1 false)
  %401 = load i64, ptr %1, align 8
; call <[f32; 2]>::map::<casts::main::{closure#0}, u32>
  %402 = call i64 @_RINvMsm_NtCsl10jNU3mE6R_4core5arrayAfj2_3mapNCNvCs18dZLLqCRHT_5casts4main0mEBK_(i64 %401)
  store i64 %402, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_1263, ptr align 8 %0, i64 8, i1 false)
; call <core::fmt::rt::Argument>::new_debug::<[u32; 2]>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAmj2_ECs18dZLLqCRHT_5casts(ptr sret([16 x i8]) align 8 %_1267, ptr align 4 %_1263) #13
  %403 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args120, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %403, ptr align 8 %_1267, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %404 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args120) #13
  %_1260.0 = extractvalue { ptr, ptr } %404, 0
  %_1260.1 = extractvalue { ptr, ptr } %404, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_1260.0, ptr %_1260.1)
  ret void
}

; <f32>::to_bits
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtCsl10jNU3mE6R_4core3f32f7to_bitsCs18dZLLqCRHT_5casts(float %self) unnamed_addr #0 !guid !98 {
start:
  %_0 = bitcast float %self to i32
  ret i32 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs18dZLLqCRHT_5casts(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !99 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <[core::mem::maybe_uninit::MaybeUninit<u32>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitmE8is_emptyCs18dZLLqCRHT_5casts(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !100 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <core::result::Result<u8, core::num::error::TryFromIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtNtB4_3num5error15TryFromIntErrorE5is_okCs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !101 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_2 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %5 = load i8, ptr %_0, align 1
  %6 = trunc nuw i8 %5 to i1
  ret i1 %6

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, core::num::error::TryFromIntError>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtNtB4_3num5error15TryFromIntErrorE6is_errCs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !102 {
start:
; call <core::result::Result<u8, core::num::error::TryFromIntError>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthNtNtNtB4_3num5error15TryFromIntErrorE5is_okCs18dZLLqCRHT_5casts(ptr %self) #13
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::result::Result<u32, core::num::error::TryFromIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmNtNtNtB4_3num5error15TryFromIntErrorE5is_okCs18dZLLqCRHT_5casts(ptr align 4 %self) unnamed_addr #0 !guid !103 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 4
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u32, core::num::error::TryFromIntError>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmNtNtNtB4_3num5error15TryFromIntErrorE6is_errCs18dZLLqCRHT_5casts(ptr align 4 %self) unnamed_addr #0 !guid !104 {
start:
; call <core::result::Result<u32, core::num::error::TryFromIntError>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmNtNtNtB4_3num5error15TryFromIntErrorE5is_okCs18dZLLqCRHT_5casts(ptr align 4 %self) #13
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::mem::maybe_dangling::MaybeDangling<[f32; 2]>>::new
; Function Attrs: nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingAfj2_E3newCs18dZLLqCRHT_5casts(i64 %0) unnamed_addr #1 !guid !105 {
start:
  %_0 = alloca [8 x i8], align 4
  %1 = alloca [8 x i8], align 8
  %x = alloca [8 x i8], align 4
  store i64 %0, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %x, ptr align 8 %1, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 4 %x, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::Guard<u32>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtB6_5array5GuardmEE3newCs18dZLLqCRHT_5casts(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !106 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<u32>>::new
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCs18dZLLqCRHT_5casts(i32 %x) unnamed_addr #1 !guid !107 {
start:
  ret i32 %x
}

; <*mut f32>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOf20offset_from_unsignedCs18dZLLqCRHT_5casts(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !108 {
start:
; call <*const f32>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPf20offset_from_unsignedCs18dZLLqCRHT_5casts(ptr %self, ptr %origin, ptr align 8 %0) #13
  ret i64 %_0
}

; <*const f32>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPf20offset_from_unsignedCs18dZLLqCRHT_5casts(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !109 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs18dZLLqCRHT_5casts() #13
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 4
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs18dZLLqCRHT_5casts(ptr %self, ptr %origin, ptr align 8 %0) #17
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #18
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 4, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 4
  ret i64 %_0
}

; <char>::from_u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8from_u32Cs18dZLLqCRHT_5casts(i32 %i) unnamed_addr #0 !guid !110 {
start:
; call core::char::convert::from_u32
  %_0 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert8from_u32Cs18dZLLqCRHT_5casts(i32 %i) #13
  ret i32 %_0
}

; <core::ptr::non_null::NonNull<[u32; 2]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAmj2_E8from_refCs18dZLLqCRHT_5casts(ptr align 4 %r) unnamed_addr #0 !guid !111 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::option::Option<char>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptioncEE8from_refCs18dZLLqCRHT_5casts(ptr align 4 %r) unnamed_addr #0 !guid !112 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i8, core::num::error::TryFromIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultaNtNtNtB9_3num5error15TryFromIntErrorEE8from_refCs18dZLLqCRHT_5casts(ptr %r) unnamed_addr #0 !guid !113 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::mem::manually_drop::ManuallyDrop<[f32; 2]>>>::from_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtNtB9_3mem13manually_drop12ManuallyDropAfj2_EE8from_mutCs18dZLLqCRHT_5casts(ptr align 4 %r) unnamed_addr #0 !guid !114 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs18dZLLqCRHT_5casts(ptr %r) unnamed_addr #0 !guid !115 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs18dZLLqCRHT_5casts(ptr %r) unnamed_addr #0 !guid !116 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs18dZLLqCRHT_5casts(ptr align 8 %r) unnamed_addr #0 !guid !117 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::read
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE4readCs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !118 {
start:
  %_0.i = load float, ptr %self, align 4
  ret float %_0.i
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs18dZLLqCRHT_5casts(ptr align 4 %r) unnamed_addr #0 !guid !119 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<isize>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulliE8from_refCs18dZLLqCRHT_5casts(ptr align 8 %r) unnamed_addr #0 !guid !120 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCs18dZLLqCRHT_5casts(ptr align 16 %r) unnamed_addr #0 !guid !121 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i16>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCs18dZLLqCRHT_5casts(ptr align 2 %r) unnamed_addr #0 !guid !122 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs18dZLLqCRHT_5casts(ptr align 8 %r) unnamed_addr #0 !guid !123 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !124 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs18dZLLqCRHT_5casts(ptr %s.0, i64 %s.1) #13
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs18dZLLqCRHT_5casts(ptr %self) unnamed_addr #0 !guid !125 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs18dZLLqCRHT_5casts(i8 %0) unnamed_addr #0 !guid !126 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs18dZLLqCRHT_5casts(ptr %self) #13
  ret i32 %_0
}

; <core::array::Guard<u32>>::push_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsn_NtCsl10jNU3mE6R_4core5arrayINtB5_5GuardmE14push_uncheckedCs18dZLLqCRHT_5casts(ptr align 8 %self, i32 %item) unnamed_addr #0 personality ptr @rust_eh_personality !guid !127 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
  %_9.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_9.1 = load i64, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %1, align 8
; call <[core::mem::maybe_uninit::MaybeUninit<u32>]>::get_unchecked_mut::<usize>
  %_4 = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitmE17get_unchecked_mutjECs18dZLLqCRHT_5casts(ptr align 4 %_9.0, i64 %_9.1, i64 %_5, ptr align 8 @alloc_0e5e743f11811ed52c409dafae27227d) #13
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call <core::mem::maybe_dangling::MaybeDangling<u32>>::new
  %_2.i.i.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCs18dZLLqCRHT_5casts(i32 %item)
  store i32 %_2.i.i.i, ptr %_4, align 4
  br label %bb2

bb2:                                              ; preds = %bb1
  %2 = getelementptr inbounds i8, ptr %self, i64 16
  %_8 = load i64, ptr %2, align 8
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs18dZLLqCRHT_5casts() #13
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb2
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs18dZLLqCRHT_5casts(i64 %_8, i64 1, ptr align 8 @alloc_67b02d4cc7f876dde0fea3bed8b9b42f) #17
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb2, %bb2.i
  %_0.i = add nuw i64 %_8, 1
  br label %bb3

bb3:                                              ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  %3 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %_0.i, ptr %3, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs18dZLLqCRHT_5casts() unnamed_addr #0 !guid !128 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs18dZLLqCRHT_5casts() #13
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::char::convert::char_try_from_u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert17char_try_from_u32Cs18dZLLqCRHT_5casts(i32 %i) unnamed_addr #0 !guid !129 {
start:
  %_0 = alloca [4 x i8], align 4
  %_4 = xor i32 %i, 55296
  %_0.i = sub i32 %_4, 2048
  %_2 = icmp uge i32 %_0.i, 1112064
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %i, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  store i32 -1, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::char::convert::from_u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert8from_u32Cs18dZLLqCRHT_5casts(i32 %i) unnamed_addr #0 !guid !130 {
start:
  %_2 = alloca [4 x i8], align 4
  %_0 = alloca [4 x i8], align 4
; call core::char::convert::char_try_from_u32
  %0 = call i32 @_RNvNtNtCsl10jNU3mE6R_4core4char7convert17char_try_from_u32Cs18dZLLqCRHT_5casts(i32 %i) #13
  store i32 %0, ptr %_2, align 4
  %1 = load i32, ptr %_2, align 4
  %2 = icmp eq i32 %1, -1
  %_3 = select i1 %2, i64 1, i64 0
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb3, label %bb4

bb3:                                              ; preds = %start
  store i32 -1, ptr %_0, align 4
  br label %bb5

bb4:                                              ; preds = %start
  %c = load i32, ptr %_2, align 4
  store i32 %c, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  ret i32 %4

bb2:                                              ; No predecessors!
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs18dZLLqCRHT_5casts(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !131 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #15
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs18dZLLqCRHT_5casts(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !132 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #15
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs18dZLLqCRHT_5casts() unnamed_addr #0 !guid !133 {
start:
  ret i1 true
}

; <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs18dZLLqCRHT_5casts(i64 %this, i64 %len, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !134 {
start:
  %_3 = icmp ult i64 %this, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_5a8fdd84b3281310cbf6b74bb6bf0065, i64 218)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #15
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtBb_3ops5range5RangejEINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs18dZLLqCRHT_5casts(i64 %start1, i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !135 {
start:
  %_4 = icmp uge i64 %end, %start1
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs18dZLLqCRHT_5casts(ptr @alloc_18d73aa062d524e9620b9e3b55bd9eb1, i64 218)
          to label %bb4 unwind label %terminate

bb1:                                              ; preds = %start
  %_5 = icmp ule i64 %end, %len
  br i1 %_5, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  ret void

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #15
  unreachable

bb4:                                              ; preds = %bb3
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_7.0, ptr %_7.1, i1 zeroext false, ptr align 8 %0) #19
  unreachable
}

; <core::ops::control_flow::ControlFlow<core::ops::try_trait::NeverShortCircuitResidual, u32> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowNtNtB4_9try_trait25NeverShortCircuitResidualmENtB12_3Try6branchCs18dZLLqCRHT_5casts(i32 %0) unnamed_addr #0 !guid !136 {
start:
  %_0 = alloca [4 x i8], align 4
  %self = alloca [4 x i8], align 4
  store i32 %0, ptr %self, align 4
  %1 = load i32, ptr %self, align 4
  br label %bb3

bb3:                                              ; preds = %start
  %c = load i32, ptr %self, align 4
  store i32 %c, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %2 = load i32, ptr %_0, align 4
  ret i32 %2

bb2:                                              ; No predecessors!
  call void @llvm.trap()
  call void @llvm.trap()
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::ops::try_trait::NeverShortCircuit<[u32; 2]> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitAmj2_EINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCs18dZLLqCRHT_5casts() unnamed_addr #0 !guid !137 {
start:
  %_0 = alloca [8 x i8], align 4
  unreachable
}

; <&mut core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}> as core::ops::function::FnMut<(usize,)>>::call_mut
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array5drainQINtB5_5DrainfNCINvMNtNtB9_3ops9try_traitINtBY_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0EINtNtB10_8function5FnMutTjEE8call_mutB21_(ptr align 8 %self, i64 %0) unnamed_addr #1 !guid !138 {
start:
  %_0 = alloca [4 x i8], align 4
  %_2 = alloca [8 x i8], align 8
  store i64 %0, ptr %_2, align 8
  br label %bb5

bb5:                                              ; preds = %start
  %_18 = load ptr, ptr %self, align 8
  %p = load ptr, ptr %_18, align 8
  %_19 = load ptr, ptr %self, align 8
  %_11 = load ptr, ptr %_19, align 8
  %_3.i = getelementptr inbounds nuw float, ptr %_11, i64 1
  %_20 = load ptr, ptr %self, align 8
  store ptr %_3.i, ptr %_20, align 8
  %_21 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %_21, i64 8
  %_22 = load ptr, ptr %1, align 8
; call <core::ptr::non_null::NonNull<f32>>::read
  %_13 = call float @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE4readCs18dZLLqCRHT_5casts(ptr %p) #13
; call <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1::<f32, casts::main::{closure#0}>::{closure#0}
  %2 = call i32 @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0B1o_(ptr %_22, float %_13) #13
  store i32 %2, ptr %_0, align 4
  br label %bb8

bb8:                                              ; preds = %bb5
  %3 = load i32, ptr %_0, align 4
  ret i32 %3

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<u32>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitmEE17get_unchecked_mutCs18dZLLqCRHT_5casts(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !139 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<u32>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitmEECs18dZLLqCRHT_5casts(ptr %slice.0, i64 %slice.1) #13
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs18dZLLqCRHT_5casts(i64 %self, i64 %_0.i, ptr align 8 %0) #17
  br label %bb3

bb3:                                              ; preds = %bb1
  %_0 = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  ret ptr %_0
}

; <core::array::drain::Drain<f32, <core::ops::try_trait::NeverShortCircuit<u32>>::wrap_mut_1<f32, casts::main::{closure#0}>::{closure#0}> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtNtCsl10jNU3mE6R_4core5array5drainINtB5_5DrainfNCINvMNtNtB9_3ops9try_traitINtBX_17NeverShortCircuitmE10wrap_mut_1fNCNvCs18dZLLqCRHT_5casts4main0E0ENtNtBZ_4drop4Drop4dropB20_(ptr align 8 %self) unnamed_addr #1 !guid !140 {
start:
  %slice = alloca [16 x i8], align 8
  br label %bb3

bb3:                                              ; preds = %start
  %_8 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_10 = load ptr, ptr %0, align 8
  %_13 = load ptr, ptr %self, align 8
; call <*mut f32>::offset_from_unsigned
  %_9 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOf20offset_from_unsignedCs18dZLLqCRHT_5casts(ptr %_10, ptr %_13, ptr align 8 @alloc_54bdda806a54ef5a1da114112d5dae1a) #13
; call core::ptr::metadata::from_raw_parts_mut::<[f32], f32>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSffECs18dZLLqCRHT_5casts(ptr %_8, i64 %_9) #13
  %2 = extractvalue { ptr, i64 } %1, 0
  %3 = extractvalue { ptr, i64 } %1, 1
  store ptr %2, ptr %slice, align 8
  %4 = getelementptr inbounds i8, ptr %slice, i64 8
  store i64 %3, ptr %4, align 8
  br label %bb7

bb7:                                              ; preds = %bb3
  %_14.0 = load ptr, ptr %slice, align 8
  %5 = getelementptr inbounds i8, ptr %slice, i64 8
  %_14.1 = load i64, ptr %5, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <&core::num::error::TryFromIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error15TryFromIntErrorNtB6_5Debug3fmtCs18dZLLqCRHT_5casts(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !141 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::TryFromIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_15TryFromIntErrorNtNtB9_3fmt5Debug3fmtCs18dZLLqCRHT_5casts(ptr %_3, ptr align 8 %f) #13
  ret i1 %_0
}

; <&[u32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSmNtB6_5Debug3fmtCs18dZLLqCRHT_5casts(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !142 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[u32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSmNtB5_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&i8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRaNtB6_5Debug3fmtCs18dZLLqCRHT_5casts(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !143 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCs18dZLLqCRHT_5casts(ptr %_3, ptr align 8 %f) #13
  ret i1 %_0
}

; <&char as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRcNtB6_5Debug3fmtCs18dZLLqCRHT_5casts(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !144 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <char as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsj_NtCsl10jNU3mE6R_4core3fmtcNtB5_5Debug3fmt(ptr align 4 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <u32 as core::convert::TryFrom<i8>>::try_from
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs2K_NtNtCsl10jNU3mE6R_4core7convert3nummINtB8_7TryFromaE8try_fromCs18dZLLqCRHT_5casts(i8 %u) unnamed_addr #0 !guid !145 {
start:
  %_0 = alloca [8 x i8], align 4
  %_2 = icmp sge i8 %u, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %0, align 1
  store i8 1, ptr %_0, align 4
  br label %bb3

bb1:                                              ; preds = %start
  %_3 = sext i8 %u to i32
  %1 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_3, ptr %1, align 4
  store i8 0, ptr %_0, align 4
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <u8 as core::convert::TryFrom<i32>>::try_from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXs2S_NtNtCsl10jNU3mE6R_4core7convert3numhINtB8_7TryFromlE8try_fromCs18dZLLqCRHT_5casts(i32 %u) unnamed_addr #0 !guid !146 {
start:
  %_0 = alloca [2 x i8], align 1
  %_4 = icmp slt i32 %u, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_7 = icmp sgt i32 %u, 255
  br i1 %_7, label %bb3, label %bb4

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  %_10 = trunc i32 %u to i8
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_10, ptr %1, align 1
  store i8 0, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %2, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  %5 = getelementptr inbounds i8, ptr %_0, i64 1
  %6 = load i8, ptr %5, align 1
  %7 = insertvalue { i1, i8 } poison, i1 %4, 0
  %8 = insertvalue { i1, i8 } %7, i8 %6, 1
  ret { i1, i8 } %8
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<u32>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitmEE17get_unchecked_mutCs18dZLLqCRHT_5casts(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !147 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<u32>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitmEECs18dZLLqCRHT_5casts(ptr %slice.0, i64 %slice.1) #13
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtBb_3ops5range5RangejEINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs18dZLLqCRHT_5casts(i64 %self.0, i64 %self.1, i64 %_0.i, ptr align 8 %0) #17
  br label %bb3

bb3:                                              ; preds = %bb1
  %new_len = sub nuw i64 %self.1, %self.0
  %ptr.i = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self.0
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %new_len, 1
  %_0.0 = extractvalue { ptr, i64 } %2, 0
  %_0.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1, 1
  ret { ptr, i64 } %4
}

; <i8 as core::convert::TryFrom<i64>>::try_from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvXs2m_NtNtCsl10jNU3mE6R_4core7convert3numaINtB8_7TryFromxE8try_fromCs18dZLLqCRHT_5casts(i64 %u) unnamed_addr #0 !guid !148 {
start:
  %_0 = alloca [2 x i8], align 1
  %_4 = icmp slt i64 %u, -128
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_7 = icmp sgt i64 %u, 127
  br i1 %_7, label %bb3, label %bb4

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %0, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb4:                                              ; preds = %bb2
  %_10 = trunc i64 %u to i8
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_10, ptr %1, align 1
  store i8 0, ptr %_0, align 1
  br label %bb5

bb3:                                              ; preds = %bb2
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %2, align 1
  store i8 1, ptr %_0, align 1
  br label %bb5

bb5:                                              ; preds = %bb1, %bb3, %bb4
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  %5 = getelementptr inbounds i8, ptr %_0, i64 1
  %6 = load i8, ptr %5, align 1
  %7 = insertvalue { i1, i8 } poison, i1 %4, 0
  %8 = insertvalue { i1, i8 } %7, i8 %6, 1
  ret { i1, i8 } %8
}

; <char as core::convert::From<u8>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs4_NtNtCsl10jNU3mE6R_4core4char7convertcINtNtB9_7convert4FromhE4fromCs18dZLLqCRHT_5casts(i8 %i) unnamed_addr #0 !guid !149 {
start:
  %_0 = zext i8 %i to i32
  ret i32 %_0
}

; <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<u32>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitmEE17get_unchecked_mutCs18dZLLqCRHT_5casts(i64 %self, ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !150 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<u32>]>>::get_unchecked_mut
  %0 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitmEE17get_unchecked_mutCs18dZLLqCRHT_5casts(i64 0, i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 @alloc_1b39eec3adbd903e3f9ab4ac43144a38) #13
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::num::error::TryFromIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_15TryFromIntErrorNtNtB9_3fmt5Debug3fmtCs18dZLLqCRHT_5casts(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !151 {
start:
  %_6 = alloca [8 x i8], align 8
  store ptr %self, ptr %_6, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_5cb263f26a5d50117adfcc5c7225745e, i64 15, ptr %_6, ptr align 8 @vtable.1)
  ret i1 %_0
}

; <i8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsO_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_5Debug3fmtCs18dZLLqCRHT_5casts(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !152 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::option::Option<char> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptioncENtNtB7_3fmt5Debug3fmtCs18dZLLqCRHT_5casts(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !153 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i32, ptr %self, align 4
  %1 = icmp eq i32 %0, -1
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.2)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  ret i1 %8

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs18dZLLqCRHT_5casts() unnamed_addr #0 !guid !154 {
start:
  ret i8 0
}

; <core::ops::try_trait::NeverShortCircuit<[u32; 2]> as core::ops::try_trait::Try>::from_output
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitAmj2_ENtB4_3Try11from_outputCs18dZLLqCRHT_5casts(i64 %0) unnamed_addr #0 !guid !155 {
start:
  %_0 = alloca [8 x i8], align 4
  %1 = alloca [8 x i8], align 8
  %x = alloca [8 x i8], align 4
  store i64 %0, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %x, ptr align 8 %1, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 4 %x, i64 8, i1 false)
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <core::ops::try_trait::NeverShortCircuit<u32> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitmENtB4_3Try6branchCs18dZLLqCRHT_5casts(i32 %self) unnamed_addr #0 !guid !156 {
start:
  ret i32 %self
}

; <[u32; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAmj2_NtNtB7_3fmt5Debug3fmtCs18dZLLqCRHT_5casts(ptr align 4 %self, ptr align 8 %f) unnamed_addr #1 !guid !157 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[u32; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAmj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCs18dZLLqCRHT_5casts(ptr align 4 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #13
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !158
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[u32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSmNtB6_5Debug3fmtCs18dZLLqCRHT_5casts(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[u32; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAmj2_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCs18dZLLqCRHT_5casts(ptr align 4 %self, ptr align 8 %0) unnamed_addr #0 !guid !159 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[u32]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSmE5indexB9_(ptr align 4 %self, i64 2, ptr align 8 %0) #13
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCs18dZLLqCRHT_5casts(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !160 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::array::Guard<u32> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXso_NtCsl10jNU3mE6R_4core5arrayINtB5_5GuardmENtNtNtB7_3ops4drop4Drop4dropCs18dZLLqCRHT_5casts(ptr align 8 %self) unnamed_addr #0 !guid !161 {
start:
  %_6.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_6.1 = load i64, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %1, align 8
; call <[core::mem::maybe_uninit::MaybeUninit<u32>]>::get_unchecked_mut::<core::ops::range::RangeTo<usize>>
  %2 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitmE17get_unchecked_mutINtNtNtB5_3ops5range7RangeTojEECs18dZLLqCRHT_5casts(ptr align 4 %_6.0, i64 %_6.1, i64 %_5, ptr align 8 @alloc_305abab612895a7382c95f94a11d3600) #13
  %_3.0 = extractvalue { ptr, i64 } %2, 0
  %_3.1 = extractvalue { ptr, i64 } %2, 1
; call <[core::mem::maybe_uninit::MaybeUninit<u32>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitmE8is_emptyCs18dZLLqCRHT_5casts(ptr align 4 %_3.0, i64 %_3.1) #13
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitmE16assume_init_dropCs18dZLLqCRHT_5casts.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitmE16assume_init_dropCs18dZLLqCRHT_5casts.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitmE16assume_init_dropCs18dZLLqCRHT_5casts.exit: ; preds = %start, %bb2.i
  ret void
}

; <core::result::Result<i8, core::num::error::TryFromIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultaNtNtNtB7_3num5error15TryFromIntErrorENtNtB7_3fmt5Debug3fmtCs18dZLLqCRHT_5casts(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !162 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %2 = getelementptr inbounds i8, ptr %self, i64 1
  %3 = load i8, ptr %2, align 1
  %_3 = zext i1 %1 to i64
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %5, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %8, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.3)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs18dZLLqCRHT_5casts(ptr %_1) unnamed_addr #0 !guid !163 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs18dZLLqCRHT_5casts(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !164 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs18dZLLqCRHT_5casts(ptr align 8 %_1) #13
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <i8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <isize as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsj_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impiNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16) unnamed_addr #0

; <core::ptr::non_null::NonNull<u128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr) unnamed_addr #0

; <u128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i16 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt(ptr align 2, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #5

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #6

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #7

; <core::ops::control_flow::ControlFlow<core::ops::try_trait::NeverShortCircuitResidual> as core::ops::try_trait::FromResidual<core::ops::control_flow::ControlFlow<core::ops::try_trait::NeverShortCircuitResidual, core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB4_11ControlFlowNtNtB6_9try_trait25NeverShortCircuitResidualEINtB14_12FromResidualIBK_B12_NtNtB8_7convert10InfallibleEE13from_residualB8_() unnamed_addr #0

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u16>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaytEB7_(ptr sret([16 x i8]) align 8, ptr align 2) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<char>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaycECshGsV4pNJ6ra_6object(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptosi.sat.i8.f64(double) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptoui.sat.i8.f64(double) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptosi.sat.i32.f64(double) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptoui.sat.i32.f64(double) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptosi.sat.i64.f64(double) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptoui.sat.i64.f64(double) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptosi.sat.i128.f64(double) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptoui.sat.i128.f64(double) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptosi.sat.i32.f32(float) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptoui.sat.i8.f32(float) #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptoui.sat.i64.f32(float) #8

; <core::fmt::rt::Argument>::new_debug::<char>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugcEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #9

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #6

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #10

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #11

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[u32]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSmE5indexB9_(ptr align 4, i64, ptr align 8) unnamed_addr #0

; <[u32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSmNtB5_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 4, i64, ptr align 8) unnamed_addr #1

; <char as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsj_NtCsl10jNU3mE6R_4core3fmtcNtB5_5Debug3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <i8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <i8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsf_NtNtCsl10jNU3mE6R_4core3fmt3numaNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #12 !guid !165 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs18dZLLqCRHT_5casts(ptr @_RNvCs18dZLLqCRHT_5casts4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #8 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #12 = { nonlazybind "target-cpu"="x86-64" }
attributes #13 = { inlinehint }
attributes #14 = { cold }
attributes #15 = { cold noreturn nounwind }
attributes #16 = { noinline }
attributes #17 = { inlinehint nounwind }
attributes #18 = { noinline noreturn }
attributes #19 = { noinline noreturn nounwind }

!llvm.module.flags = !{!33, !34, !35, !36}
!llvm.ident = !{!37}

!0 = !{i64 1250710929205695424}
!1 = !{i64 -4352407351265055805}
!2 = !{i64 4414378300378493947}
!3 = !{i64 -4102245017928768666}
!4 = !{i64 -8600670814550737539}
!5 = !{i64 -6049742410240181802}
!6 = !{i64 6290422976304376762}
!7 = !{i64 8280178146419865990}
!8 = !{i64 4484946479683762186}
!9 = !{i64 -1577522250091519357}
!10 = !{i64 5822698984579835355}
!11 = !{i64 8189348619574626970}
!12 = !{i64 6422294594768298345}
!13 = !{i64 3731056085395240988}
!14 = !{i64 1196911974917914838}
!15 = !{i64 302310954886487552}
!16 = !{i64 -4655105123702743492}
!17 = !{i64 -1287251333430543194}
!18 = !{i64 1383906370500182674}
!19 = !{i64 7465496829981154091}
!20 = !{i64 2966746273801706261}
!21 = !{i64 -4697421293774984087}
!22 = !{i64 6998232645087314531}
!23 = !{i64 -7490531833336286781}
!24 = !{i64 220234863514784770}
!25 = !{i64 3201739111008359187}
!26 = !{i64 1372943021357586008}
!27 = !{i64 442737848752751133}
!28 = !{i64 1076092382032374321}
!29 = !{i64 7106628206865902039}
!30 = !{i64 3251374618738988665}
!31 = !{i64 -6862623093000235501}
!32 = !{i64 368058179234842243}
!33 = !{i32 8, !"PIC Level", i32 2}
!34 = !{i32 7, !"PIE Level", i32 2}
!35 = !{i32 2, !"RtLibUseGOT", i32 1}
!36 = !{i32 7, !"uwtable", i32 2}
!37 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!38 = !{i64 -3957674458885829009}
!39 = !{i64 -403822313910555357}
!40 = !{i64 -7269431704430920715}
!41 = !{i64 5684665676455590131}
!42 = !{i64 3411403366634108032}
!43 = !{i64 -8730665232020335969}
!44 = !{i64 -7750715161202815890}
!45 = !{i64 -8036414692933184700}
!46 = !{i64 -4460772613979928266}
!47 = !{i64 -8612147126968335152}
!48 = !{i64 -4943072754478007719}
!49 = !{i64 8445437945558082246}
!50 = !{i64 -7540069603692790764}
!51 = !{i64 -3988263095063820268}
!52 = !{i64 -8348914812331986469}
!53 = !{i64 8831000182196743148}
!54 = !{i64 -3543791318963609932}
!55 = !{i64 1658945812453278066}
!56 = !{i64 8368697687266581946}
!57 = !{i64 4640124731279227605}
!58 = !{i64 1672351032704907042}
!59 = !{i64 -1521586349034067080}
!60 = !{i64 -6266848697002993769}
!61 = !{i64 -9128817641172577870}
!62 = !{i64 4848004942441733297}
!63 = !{i64 371013671742415884}
!64 = !{i64 -8938152244896125311}
!65 = !{i64 5788938451412856627}
!66 = !{i64 -4888008966049365602}
!67 = !{i64 5668588605242750736}
!68 = !{i64 -9078501339713488033}
!69 = !{i64 5071225406213942253}
!70 = !{i64 3116843965989450797}
!71 = !{i64 -2057049999807618998}
!72 = !{i64 -8673356815373023085}
!73 = !{i64 7653692155549912417}
!74 = !{i64 1319087536123793}
!75 = !{i64 -8227573174089207898}
!76 = !{i64 4351856627164175043}
!77 = !{i64 7397049040724264735}
!78 = !{i64 6239732276023040433}
!79 = !{i64 3141958681874802246}
!80 = !{i64 4089470559458154017}
!81 = !{i64 8504605680945379025}
!82 = !{i64 2921978535982211662}
!83 = !{i64 -3224574762696690106}
!84 = !{i64 -2229579513440183359}
!85 = !{i64 -3968325809100762549}
!86 = !{i64 7869286333344408216}
!87 = !{i64 8317504744067994525}
!88 = !{i64 8643670943596865798}
!89 = !{i64 -6785001103404701601}
!90 = !{i64 5871508606863190261}
!91 = !{i64 476324331000130007}
!92 = !{i64 -2765512268563046646}
!93 = !{i64 -6487612177420477575}
!94 = !{i64 -327927869401759801}
!95 = !{i64 -6871045007065962101}
!96 = !{i64 -2545693145993188906}
!97 = !{i64 -7041595189061397082}
!98 = !{i64 -9011729966857840736}
!99 = !{i64 2937393290249075508}
!100 = !{i64 -2374283042483395032}
!101 = !{i64 -4111320705835316976}
!102 = !{i64 1832428160847824664}
!103 = !{i64 -2890930200058157055}
!104 = !{i64 -6846635164756289465}
!105 = !{i64 4736122924492910093}
!106 = !{i64 7769438609085566131}
!107 = !{i64 -2957016779774886634}
!108 = !{i64 -5899271833559004172}
!109 = !{i64 5930389439747555408}
!110 = !{i64 -4855856034218810394}
!111 = !{i64 2057442301806935722}
!112 = !{i64 1331424690200180074}
!113 = !{i64 -7367327474830240657}
!114 = !{i64 -2150961289006362339}
!115 = !{i64 8657723997833615852}
!116 = !{i64 -1978725318386396449}
!117 = !{i64 -7352854676011891335}
!118 = !{i64 1779663569729526102}
!119 = !{i64 -7091796863173770151}
!120 = !{i64 8511940603561189813}
!121 = !{i64 2881835778823186362}
!122 = !{i64 -3203568791552650308}
!123 = !{i64 7499776968861296049}
!124 = !{i64 8491350062054953667}
!125 = !{i64 -8924978704812532491}
!126 = !{i64 2219961229679710375}
!127 = !{i64 6066949021440892645}
!128 = !{i64 7550308125105319096}
!129 = !{i64 6366579235283881908}
!130 = !{i64 -8843928359575420308}
!131 = !{i64 5793574450722373511}
!132 = !{i64 -4147981760362673507}
!133 = !{i64 6025210656758862948}
!134 = !{i64 9170117450257110587}
!135 = !{i64 -6806749583002237914}
!136 = !{i64 7216193196036509746}
!137 = !{i64 4826962942442526613}
!138 = !{i64 5701796421180821174}
!139 = !{i64 -640009177036710583}
!140 = !{i64 -7416030414909546053}
!141 = !{i64 8802107066062969356}
!142 = !{i64 -7419336658973955050}
!143 = !{i64 5560755405304145949}
!144 = !{i64 -4316585773743536021}
!145 = !{i64 4907740886054712480}
!146 = !{i64 4499436974836553002}
!147 = !{i64 3464287394559544389}
!148 = !{i64 8831109312325715129}
!149 = !{i64 4322146396562194088}
!150 = !{i64 4652832493482128138}
!151 = !{i64 541590460535034619}
!152 = !{i64 -4581582598699941012}
!153 = !{i64 4882171345673945846}
!154 = !{i64 -1167175252906167731}
!155 = !{i64 -180450376610297972}
!156 = !{i64 -1624627906566850157}
!157 = !{i64 -8405202557443847247}
!158 = !{!"address", !"read_provenance"}
!159 = !{i64 -5885653952185407548}
!160 = !{i64 4840490566609733714}
!161 = !{i64 3238679252933525906}
!162 = !{i64 -1952620906434292050}
!163 = !{i64 -4901617371002690702}
!164 = !{i64 8081969745044493286}
!165 = !{i64 -2624081020897602054}
