; ModuleID = 'i128.f6b1c69dd40f4262-cgu.0'
source_filename = "i128.f6b1c69dd40f4262-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCslb9dB7bEmfm_4i128, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cslb9dB7bEmfm_4i128, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cslb9dB7bEmfm_4i128 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !3
@alloc_2fc439fdc88563e15d315d43214d38e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\D6\02\00\00\09\00\00\00" }>, align 8, !guid !4
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !5
@alloc_8df3287b4fbc190437d91041421e919b = private unnamed_addr constant [30 x i8] c"core/src/iter/traits/accum.rs\00", align 1, !guid !6
@alloc_a840ce68d073c0ef52d40243c1f57585 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8df3287b4fbc190437d91041421e919b, [16 x i8] c"\1D\00\00\00\00\00\00\00\CE\00\00\00\01\00\00\00" }>, align 8, !guid !7
@alloc_16d8701a704195662253a9809cf298d1 = private unnamed_addr constant [25 x i8] c"alloc/src/raw_vec/mod.rs\00", align 1, !guid !8
@alloc_c53d1dc14d9dfd00f89649d83c62a8b7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\003\02\00\00X\00\00\00" }>, align 8, !guid !9
@alloc_84e24ad25dfa3f90d9808e22947b437c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\85\03\00\00G\00\00\00" }>, align 8, !guid !10
@alloc_8fd7bd399161f6597fd9f4d41ee5911e = private unnamed_addr constant [28 x i8] c"test/rust/synthetic/i128.rs\00", align 1, !guid !11
@alloc_eef5a6daeaf4f66c4683c7d969887037 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\04\00\00\00W\00\00\00" }>, align 8, !guid !12
@alloc_a54b5d523418f9a473b9707e1bf3abdd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\06\00\00\00B\00\00\00" }>, align 8, !guid !13
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !14
@alloc_cde706cbfa574f07c7f055fef22170fe = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0C\00\00\00\1A\00\00\00" }>, align 8, !guid !15
@alloc_d8b1051dca4ca82a457e3b6bfe42d861 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0C\00\00\00!\00\00\00" }>, align 8, !guid !16
@alloc_98b2cc77e91e94d24c695c6a061c28c0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0C\00\00\00*\00\00\00" }>, align 8, !guid !17
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !18
@alloc_5fa04f97916bd874a7a88690ee4d2c7f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0D\00\00\00\17\00\00\00" }>, align 8, !guid !19
@alloc_d4d899166b4141918c2da3e256b7165b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0F\00\00\00\1C\00\00\00" }>, align 8, !guid !20
@alloc_59b8058f47772d03e6bfab57ce0a41ae = private unnamed_addr constant [11 x i8] c"\C0\01 \C1 \00\80`\01\0A\00", align 1, !guid !21
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !22
@alloc_ce0acdd4a4f94c66b265f4ef543b4ab6 = private unnamed_addr constant [39 x i8] c"340282366920938463463374607431768211455", align 1, !guid !23
@alloc_941090dbc54b31f562723ae1638c2086 = private unnamed_addr constant [39 x i8] c"340282366920938463463374607431768211456", align 1, !guid !24
@alloc_860d53ce49325a3fa4c8ce10cb01a0c4 = private unnamed_addr constant [3 x i8] c"-zz", align 1, !guid !25
@alloc_b7cbb96fa2fbc2c33cfdce3b367921a6 = private unnamed_addr constant [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\80", align 16, !guid !26
@alloc_0407da499bd3b5ae40bf7d4f7ff05b0b = private unnamed_addr constant [16 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\7F", align 16, !guid !27
@alloc_e4959e06482677e63dd48c2a86fcf0e7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00!\00\00\00\16\00\00\00" }>, align 8, !guid !28
@alloc_744d897956c077d5b9b7148f78bfe5aa = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\1D\00\00\00m\00\00\00" }>, align 8, !guid !29
@alloc_b14d820ee55f823d3aefb1afa0d7eac6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\05\00\00\008\00\00\00" }>, align 8, !guid !30
@alloc_a7299c6c6510c3de3e014799b32a1fb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\05\00\00\00c\00\00\00" }>, align 8, !guid !31
@alloc_83736e0ed8986abd3fb627960735e4af = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\05\00\00\00^\00\00\00" }>, align 8, !guid !32
@alloc_68c3021501d9c8f06b4083bb56ba3908 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\07\00\00\00G\00\00\00" }>, align 8, !guid !33
@alloc_c27fb0410a6c5898f903969645269014 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\07\00\00\00q\00\00\00" }>, align 8, !guid !34
@alloc_b711721f7bfa298d55b2bdbe61d56fe1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\07\00\00\00\82\00\00\00" }>, align 8, !guid !35
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !36
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !37
@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !38
@alloc_988c380202cc7b7a37ca3d8d5930c44f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\AD\00\00\00\1B\00\00\00" }>, align 8, !guid !39
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !40
@alloc_fad0cd83b7d1858a846a172eb260e593 = private unnamed_addr constant [42 x i8] c"is_aligned_to: align is not a power-of-two", align 1, !guid !41
@alloc_3a97cab01964e354cab63e4d72a95bbc = private unnamed_addr constant [26 x i8] c"core/src/ptr/const_ptr.rs\00", align 1, !guid !42
@alloc_7abc4ceda2d1d9be88f00c5dc522bc84 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3a97cab01964e354cab63e4d72a95bbc, [16 x i8] c"\19\00\00\00\00\00\00\00M\05\00\00\0D\00\00\00" }>, align 8, !guid !43
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !44
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !45
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !46
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !47
@alloc_6379aaa2812385052216e7dc8e3279fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00m\01\00\00\1F\00\00\00" }>, align 8, !guid !48
@alloc_9e1ff22d96cae328e0e878f28b86a5f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00]\01\00\00\11\00\00\00" }>, align 8, !guid !49
@alloc_dc3b17f8cb85ad2cd97bd426be5b5da4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00b\01\00\00\1D\00\00\00" }>, align 8, !guid !50
@alloc_4a0c97dbbf49263ee47df53bd3d86fcc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00b\01\00\00+\00\00\00" }>, align 8, !guid !51
@alloc_a699fef46c42b266f9e12652c07a696a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00`\01\00\00\1B\00\00\00" }>, align 8, !guid !52
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !53
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !54
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !55
@alloc_e469ef44bf39c45bcb672a4bc963b9cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\1A\01\00\00\1B\00\00\00" }>, align 8, !guid !56
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !57
@alloc_5bb642ca6df5ad9ba078972a9d3a5201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !58
@alloc_85bcb8feb56634093aba2b8644936af9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\7F\02\00\005\00\00\00" }>, align 8, !guid !59
@alloc_17de00c3327446355700bd7db4b78ded = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\80\02\00\00\1E\00\00\00" }>, align 8, !guid !60
@alloc_b9419d44288097f84422e162822ba96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\81\02\00\00 \00\00\00" }>, align 8, !guid !61
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !62
@alloc_d60754359a0b1c5bd37a3b37b82a8a1d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\DF\01\00\00\05\00\00\00" }>, align 8, !guid !63
@alloc_af3623564924928dd3d563c9d84a8a0e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00s\05\00\00\12\00\00\00" }>, align 8, !guid !64
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !65
@alloc_02ed5979549ad728dcb1e213f787b0ae = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00,\02\00\00\11\00\00\00" }>, align 8, !guid !66
@alloc_9c2bc03755f157121052fe1398e358d1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00%\02\00\00\1A\00\00\00" }>, align 8, !guid !67
@alloc_8b924c2e6c70ef47ed23cadbb79c2da4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\11\02\00\00\1C\00\00\00" }>, align 8, !guid !68
@alloc_91dabd4c1d2514ecf79277c06422ef65 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\07\02\00\00\1C\00\00\00" }>, align 8, !guid !69
@alloc_289c68237f406b28ee6ba245eefcd312 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\03\02\00\00)\00\00\00" }>, align 8, !guid !70
@alloc_33dfd402c6ecbe2e6a32e76edf5f31a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\D8\01\00\00L\00\00\00" }>, align 8, !guid !71
@alloc_099d793709fa470a3d5e7c79c938e035 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\C9\01\00\003\00\00\00" }>, align 8, !guid !72
@alloc_51424262946dd0794fad6132df857999 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\B7\01\00\00\15\00\00\00" }>, align 8, !guid !73
@alloc_c2df0f2eed0ee910e76dda7517cc7a45 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\05\00\00\05\00\00\00" }>, align 8, !guid !74
@alloc_5aa1d1250638a5285856df0c8e3018a3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00K\07\00\00\01\00\00\00" }>, align 8, !guid !75
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !76
@alloc_5ea8f0c52284eef1a8a88866fb554c40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\0B\00\00O\00\00\00" }>, align 8, !guid !77
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !78
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !79
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !80
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !81
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !82
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !83
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !84
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !85
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !86
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !87
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !88
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !89
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !90
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !91
@alloc_a61ecf1bbb59a9a75a6a223b3f565d28 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: i128::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !92
@alloc_a6a0cc8156fe455996de64a9d05b1dfe = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u32::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !93
@alloc_0a7ace845dda78b0b3e088b89fa358fb = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: u128::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !94
@alloc_8efb6cb47e437ad05e23651986f609b7 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: u128::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !95
@alloc_db07ae5a9ce650d9b7cc970d048e6f0c = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !96
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !97
@alloc_dd79dfae92e8fdc23813c4c7a1b7cf72 = private unnamed_addr constant [228 x i8] c"unsafe precondition(s) violated: ptr::write_bytes requires that the destination pointer is aligned and non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !98
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !99
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !100
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !101
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !102
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRoNtB6_5Debug3fmtCslb9dB7bEmfm_4i128 }>, align 8, !guid !103
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCslb9dB7bEmfm_4i128 }>, align 8, !guid !104
@alloc_f764952b50ffad1fb52cf6916450b6b7 = private unnamed_addr constant [23 x i8] c"core/src/iter/range.rs\00", align 1, !guid !105
@alloc_33c781d4b73231c4b72218e776044e11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f764952b50ffad1fb52cf6916450b6b7, [16 x i8] c"\16\00\00\00\00\00\00\00$\02\00\00\01\00\00\00" }>, align 8, !guid !106
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !107
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !108
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRnNtB6_5Debug3fmtCslb9dB7bEmfm_4i128 }>, align 8, !guid !109
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !110
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !111
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCslb9dB7bEmfm_4i128 }>, align 8, !guid !112
@alloc_59ba7b9f7211443cd55a366616eef46a = private unnamed_addr constant [5 x i8] c"Empty", align 1, !guid !113
@alloc_00315c78e51d29fe6b3102a4c1ecf6ef = private unnamed_addr constant [12 x i8] c"InvalidDigit", align 1, !guid !114
@alloc_bd3a3f3879e0d5f64554753e977f58d4 = private unnamed_addr constant [11 x i8] c"PosOverflow", align 1, !guid !115
@alloc_0964bb2a4870637395c77a018495bd5c = private unnamed_addr constant [11 x i8] c"NegOverflow", align 1, !guid !116
@alloc_6566120a3a17f930e960a0863fcbd591 = private unnamed_addr constant [4 x i8] c"Zero", align 1, !guid !117
@alloc_6c17bac0c71cba42380f8445f4dcbd16 = private unnamed_addr constant [14 x i8] c"NotAPowerOfTwo", align 1, !guid !118
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !119
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !120
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCslb9dB7bEmfm_4i128 }>, align 8, !guid !121

; <str>::parse::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseoECslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !127 {
start:
; call <u128 as core::str::traits::FromStr>::from_str
  call void @_RNvXsE_NtCsl10jNU3mE6R_4core3numoNtNtNtB7_3str6traits7FromStr8from_strCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %self.0, i64 %self.1) #22
  ret void
}

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECslb9dB7bEmfm_4i128(ptr %0) unnamed_addr #0 !guid !128 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_6, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %7 = load ptr, ptr %_0, align 8
  ret ptr %7

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<usize>>::ok_or::<alloc::collections::TryReserveErrorKind>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE5ok_orNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, i64 %0, i64 %1, i64 %err.0, i64 %err.1) unnamed_addr #0 !guid !129 {
start:
  %_6 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %7, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store i64 %err.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %err.1, ptr %8, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %9 = load i8, ptr %_6, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError>>::map_err::<alloc::collections::TryReserveError, <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtNtB5_3ptr8non_null7NonNullShENtNtB5_5alloc10AllocErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvMs5_NtB1S_7raw_vecNtB2O_11RawVecInner11finish_grow0ECslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1, ptr align 8 %op) unnamed_addr #0 !guid !130 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_3 = select i1 %7, i64 1, i64 0
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}
  %9 = call { i64, i64 } @_RNCNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB7_11RawVecInner11finish_grow0Cslb9dB7bEmfm_4i128(ptr align 8 %op) #22
  %_6.0 = extractvalue { i64, i64 } %9, 0
  %_6.1 = extractvalue { i64, i64 } %9, 1
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store i64 %_6.1, ptr %11, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load ptr, ptr %self, align 8
  %12 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %t.0, ptr %13, align 8
  %14 = getelementptr inbounds i8, ptr %13, i64 8
  store i64 %t.1, ptr %14, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %15 = load i8, ptr %_9, align 1
  %16 = trunc nuw i8 %15 to i1
  br i1 %16, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %0, i64 %1) unnamed_addr #0 !guid !131 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load i64, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = icmp eq i64 %3, 0
  %_3 = select i1 %6, i64 1, i64 0
  %7 = trunc nuw i64 %_3 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call alloc::raw_vec::layout_array::{closure#0}
  %8 = call { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0Cslb9dB7bEmfm_4i128() #22
  %_6.0 = extractvalue { i64, i64 } %8, 0
  %_6.1 = extractvalue { i64, i64 } %8, 1
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %_6.1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load i64, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %t.0, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 8
  store i64 %t.1, ptr %13, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %14 = load i8, ptr %_9, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_binary::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !132 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsG_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !133 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCslb9dB7bEmfm_4i128(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !134 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCslb9dB7bEmfm_4i128(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !135 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<usize>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCslb9dB7bEmfm_4i128(ptr align 8 %x) #22
; call <core::ptr::non_null::NonNull<usize>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !136 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCslb9dB7bEmfm_4i128(ptr align 4 %x) #22
; call <core::ptr::non_null::NonNull<u32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !137 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !138 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !139 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !140 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i128>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionnEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<core::option::Option<i128>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionnEE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionnENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i128, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultnNtNtNtB7_3num5error13ParseIntErrorEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !141 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultnNtNtNtB9_3num5error13ParseIntErrorEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultnNtNtNtBa_3num5error13ParseIntErrorEE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultnNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<u128, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultoNtNtNtB7_3num5error13ParseIntErrorEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !142 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultoNtNtNtB9_3num5error13ParseIntErrorEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultoNtNtNtBa_3num5error13ParseIntErrorEE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultoNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(u128, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTobEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !143 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(u128, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTobEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #22
; call <core::ptr::non_null::NonNull<(u128, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTobEE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTobENtB6_5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !144 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCslb9dB7bEmfm_4i128(ptr %x) #22
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECslb9dB7bEmfm_4i128(ptr %_4) #22
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB7_4iter6traits5accumoNtB1s_7Product7productINtNtB5_5range14RangeInclusiveoEE0ECslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !145 {
start:
  ret void
}

; <core::ptr::unique::Unique<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !146 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECslb9dB7bEmfm_4i128(ptr %self) #22
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<core::option::Option<i128>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionnEE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !147 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultnNtNtNtBa_3num5error13ParseIntErrorEE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !148 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultoNtNtNtBa_3num5error13ParseIntErrorEE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !149 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !150 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<(u128, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTobEE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !151 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !152 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !153 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !154 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !155 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<usize>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !156 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !157 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !158 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !159 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !160 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u8>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECslb9dB7bEmfm_4i128(ptr align 8 %self) #22
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !161 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECslb9dB7bEmfm_4i128(ptr %_3) #22
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCslb9dB7bEmfm_4i128(ptr %_2) #22
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECslb9dB7bEmfm_4i128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !162 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !163 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECslb9dB7bEmfm_4i128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !164 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<11, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj2_ECslb9dB7bEmfm_4i128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !165 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECslb9dB7bEmfm_4i128(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !166 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u128>
; Function Attrs: nounwind nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftoECslb9dB7bEmfm_4i128(i128 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !167 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 16 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i128
  %_0 = call i128 @llvm.fshl.i128(i128 %x, i128 %x, i128 %1)
  ret i128 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #24
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::is_val_statically_known::<u32>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownmECslb9dB7bEmfm_4i128(i32 %_arg) unnamed_addr #2 !guid !168 {
start:
  ret i1 false
}

; core::intrinsics::is_val_statically_known::<i128>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownnECslb9dB7bEmfm_4i128(i128 %_arg) unnamed_addr #2 !guid !169 {
start:
  ret i1 false
}

; core::intrinsics::is_val_statically_known::<u128>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownoECslb9dB7bEmfm_4i128(i128 %_arg) unnamed_addr #2 !guid !170 {
start:
  ret i1 false
}

; core::cmp::max::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECslb9dB7bEmfm_4i128(i64 %v1, i64 %v2) unnamed_addr #0 !guid !171 {
start:
; call <usize as core::cmp::Ord>::max
  %_0 = call i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxCslb9dB7bEmfm_4i128(i64 %v1, i64 %v2) #22
  ret i64 %_0
}

; core::mem::replace::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core3mem7replaceoECslb9dB7bEmfm_4i128(ptr align 16 %dest, i128 %src) unnamed_addr #0 !guid !172 {
start:
  %result = load i128, ptr %dest, align 16
  store i128 %src, ptr %dest, align 16
  ret i128 %result
}

; core::ptr::slice_from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECslb9dB7bEmfm_4i128(ptr %data, i64 %len) unnamed_addr #0 !guid !173 {
start:
; call core::ptr::metadata::from_raw_parts::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECslb9dB7bEmfm_4i128(ptr %data, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECslb9dB7bEmfm_4i128(ptr %data, i64 %len) unnamed_addr #0 !guid !174 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECslb9dB7bEmfm_4i128(ptr %data, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECslb9dB7bEmfm_4i128(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !175 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCslb9dB7bEmfm_4i128(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECslb9dB7bEmfm_4i128(ptr align 8 %_1) #25
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECslb9dB7bEmfm_4i128(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECslb9dB7bEmfm_4i128(ptr align 8 %_1) unnamed_addr #1 !guid !176 {
start:
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCslb9dB7bEmfm_4i128(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECslb9dB7bEmfm_4i128(ptr align 8 %_1) unnamed_addr #1 !guid !177 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECslb9dB7bEmfm_4i128(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECslb9dB7bEmfm_4i128(double %dummy) unnamed_addr #0 !guid !178 {
start:
  %_0 = alloca [8 x i8], align 8
  store double %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !179
  %0 = load double, ptr %_0, align 8
  ret double %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECslb9dB7bEmfm_4i128(i32 %dummy) unnamed_addr #0 !guid !180 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !179
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 %dummy) unnamed_addr #0 !guid !181 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !179
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; core::hint::black_box::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 %dummy) unnamed_addr #0 !guid !182 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !179
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !183 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !179
  ret void
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECslb9dB7bEmfm_4i128(i64 %dummy) unnamed_addr #0 !guid !184 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !179
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECslb9dB7bEmfm_4i128(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !185 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCslb9dB7bEmfm_4i128(ptr %f) #22
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECslb9dB7bEmfm_4i128() #22
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECslb9dB7bEmfm_4i128(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !186 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECslb9dB7bEmfm_4i128(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !187 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[u8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECslb9dB7bEmfm_4i128(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !188 {
start:
  ret i64 %ptr.1
}

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECslb9dB7bEmfm_4i128(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !189 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECslb9dB7bEmfm_4i128(ptr %data, i64 %len) #22
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCslb9dB7bEmfm_4i128(ptr %data, i64 1, i64 1, i64 %len, ptr align 8 %0) #26
  br label %bb5
}

; <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
; Function Attrs: cold nonlazybind uwtable
define internal void @_RINvNvMs2_NtCs7CppTae75M1_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECslb9dB7bEmfm_4i128(ptr align 8 %slf, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #4 !guid !190 {
start:
  %_5 = alloca [16 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::grow_amortized
  %0 = call { i64, i64 } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCslb9dB7bEmfm_4i128(ptr align 8 %slf, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1)
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_5, align 8
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load i64, ptr %_5, align 8
  %5 = getelementptr inbounds i8, ptr %_5, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = icmp eq i64 %4, -1
  %_6 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_6 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %err.0 = load i64, ptr %_5, align 8
  %9 = getelementptr inbounds i8, ptr %_5, i64 8
  %err.1 = load i64, ptr %9, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #24
  unreachable

bb3:                                              ; preds = %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <u128 as core::iter::traits::accum::Product>::product::<core::ops::range::RangeInclusive<u128>>
; Function Attrs: nonlazybind uwtable
define internal i128 @_RINvXsH_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumoNtB6_7Product7productINtNtNtBc_3ops5range14RangeInclusiveoEECslb9dB7bEmfm_4i128(ptr align 16 %iter) unnamed_addr #1 !guid !191 {
start:
  %0 = alloca [48 x i8], align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %iter, i64 48, i1 false)
; call <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::fold::<u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>
  %_0 = call i128 @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtNtNtB8_6traits8iterator8Iterator4foldoNCINvXsH_NtB1k_5accumoNtB23_7Product7productBE_E0ECslb9dB7bEmfm_4i128(ptr align 16 %0, i128 1) #22
  ret i128 %_0
}

; <core::ops::range::RangeInclusive<u128> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<u128, <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<u128>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtB6_26RangeInclusiveIteratorImpl13spec_try_foldoNCINvMNtBJ_9try_traitINtB29_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtB8_6traits5accumoNtB3d_7Product7productBE_E0E0B2o_ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !192 {
start:
  %_37 = alloca [1 x i8], align 1
  %_36 = alloca [1 x i8], align 1
  %_26 = alloca [16 x i8], align 16
  %_15 = alloca [16 x i8], align 16
  %accum = alloca [16 x i8], align 16
  %_0 = alloca [16 x i8], align 16
  %f = alloca [0 x i8], align 1
  store i8 0, ptr %_37, align 1
  store i8 0, ptr %_36, align 1
  store i8 1, ptr %_37, align 1
; call <core::ops::range::RangeInclusive<u128>>::is_empty
  %_4 = call zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusiveoE8is_emptyCslb9dB7bEmfm_4i128(ptr align 16 %self) #22
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
  store i8 1, ptr %_36, align 1
  store i128 %init, ptr %accum, align 16
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::from_output
  %0 = call i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try11from_outputCslb9dB7bEmfm_4i128(i128 %init) #22
  store i128 %0, ptr %_0, align 16
  br label %bb32

bb4:                                              ; preds = %bb12, %bb3
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
  %_3.i = load i128, ptr %self, align 16
  %_4.i = load i128, ptr %_10, align 16
  %_0.i = icmp ult i128 %_3.i, %_4.i
  br label %bb5

bb5:                                              ; preds = %bb4
  br i1 %_0.i, label %bb6, label %bb14

bb14:                                             ; preds = %bb5
  %1 = getelementptr inbounds i8, ptr %self, i64 32
  store i8 1, ptr %1, align 16
  %_25 = getelementptr inbounds i8, ptr %self, i64 16
; call <u128 as core::cmp::PartialEq>::eq
  %_23 = call zeroext i1 @_RNvXso_NtNtCsl10jNU3mE6R_4core3cmp5implsoNtB7_9PartialEq2eqCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 16 %_25) #22
  br label %bb15

bb6:                                              ; preds = %bb5
  %_12 = load i128, ptr %self, align 16
; call <u128 as core::iter::range::Step>::forward_unchecked
  %n = call i128 @_RNvXsN_NtNtCsl10jNU3mE6R_4core4iter5rangeoNtB5_4Step17forward_uncheckedCslb9dB7bEmfm_4i128(i128 %_12, i64 1) #22
  br label %bb7

bb15:                                             ; preds = %bb14
  br i1 %_23, label %bb16, label %bb21

bb21:                                             ; preds = %bb19, %bb15
  store i8 0, ptr %_36, align 1
  %_35 = load i128, ptr %accum, align 16
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::from_output
  %2 = call i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try11from_outputCslb9dB7bEmfm_4i128(i128 %_35) #22
  store i128 %2, ptr %_0, align 16
  br label %bb22

bb16:                                             ; preds = %bb15
  store i8 0, ptr %_36, align 1
  %_30 = load i128, ptr %accum, align 16
  %_31 = load i128, ptr %self, align 16
; call <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}
  %_27 = call i128 @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB9_4iter6traits5accumoNtB1u_7Product7productINtNtB7_5range14RangeInclusiveoEE0E0Cslb9dB7bEmfm_4i128(ptr %f, i128 %_30, i128 %_31) #22
  br label %bb17

bb17:                                             ; preds = %bb16
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::branch
  %3 = call i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try6branchCslb9dB7bEmfm_4i128(i128 %_27) #22
  store i128 %3, ptr %_26, align 16
  br label %bb18

bb18:                                             ; preds = %bb17
  %4 = load i128, ptr %_26, align 16
  br label %bb19

bb19:                                             ; preds = %bb18
  %val = load i128, ptr %_26, align 16
  store i8 1, ptr %_36, align 1
  store i128 %val, ptr %accum, align 16
  br label %bb21

bb22:                                             ; preds = %bb21
  store i8 0, ptr %_36, align 1
  br label %bb25

bb25:                                             ; preds = %bb24, %bb22
  %5 = load i128, ptr %_0, align 16
  ret i128 %5

bb20:                                             ; No predecessors!
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
  %6 = call i128 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCslb9dB7bEmfm_4i128() #22
  store i128 %6, ptr %_0, align 16
  br label %bb34

bb34:                                             ; preds = %bb20
  br label %bb23

bb23:                                             ; preds = %bb33, %bb34
  store i8 0, ptr %_36, align 1
  br label %bb24

bb7:                                              ; preds = %bb6
; call core::mem::replace::<u128>
  %n1 = call i128 @_RINvNtCsl10jNU3mE6R_4core3mem7replaceoECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %n) #22
  br label %bb8

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_36, align 1
  %_19 = load i128, ptr %accum, align 16
; call <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}
  %_16 = call i128 @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB9_4iter6traits5accumoNtB1u_7Product7productINtNtB7_5range14RangeInclusiveoEE0E0Cslb9dB7bEmfm_4i128(ptr %f, i128 %_19, i128 %n1) #22
  br label %bb9

bb9:                                              ; preds = %bb8
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::branch
  %7 = call i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try6branchCslb9dB7bEmfm_4i128(i128 %_16) #22
  store i128 %7, ptr %_15, align 16
  br label %bb10

bb10:                                             ; preds = %bb9
  %8 = load i128, ptr %_15, align 16
  br label %bb12

bb12:                                             ; preds = %bb10
  %val2 = load i128, ptr %_15, align 16
  store i8 1, ptr %_36, align 1
  store i128 %val2, ptr %accum, align 16
  br label %bb4

bb13:                                             ; No predecessors!
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
  %9 = call i128 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCslb9dB7bEmfm_4i128() #22
  store i128 %9, ptr %_0, align 16
  br label %bb33

bb33:                                             ; preds = %bb13
  br label %bb23

bb24:                                             ; preds = %bb32, %bb23
  br label %bb25

bb11:                                             ; No predecessors!
  unreachable

bb32:                                             ; preds = %bb2
  br label %bb24

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable

bb28:                                             ; No predecessors!
  unreachable

bb29:                                             ; No predecessors!
  unreachable

bb30:                                             ; No predecessors!
  unreachable

bb31:                                             ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::fold::<u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtNtNtB8_6traits8iterator8Iterator4foldoNCINvXsH_NtB1k_5accumoNtB23_7Product7productBE_E0ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !193 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
; call <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB7_4iter6traits5accumoNtB1s_7Product7productINtNtB5_5range14RangeInclusiveoEE0ECslb9dB7bEmfm_4i128() #22
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_8, align 1
; call <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::try_fold::<u128, <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<u128>>
  %_4 = call i128 @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtNtNtB8_6traits8iterator8Iterator8try_foldoNCINvMNtBJ_9try_traitINtB24_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtB1k_5accumoNtB38_7Product7productBE_E0E0B2j_ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) #22
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  ret i128 %_4

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::try_fold::<u128, <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<u128>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtNtNtB8_6traits8iterator8Iterator8try_foldoNCINvMNtBJ_9try_traitINtB24_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtB1k_5accumoNtB38_7Product7productBE_E0E0B2j_ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) unnamed_addr #0 !guid !194 {
start:
; call <core::ops::range::RangeInclusive<u128> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<u128, <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<u128>>
  %_0 = call i128 @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtB6_26RangeInclusiveIteratorImpl13spec_try_foldoNCINvMNtBJ_9try_traitINtB29_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtB8_6traits5accumoNtB3d_7Product7productBE_E0E0B2o_ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) #22
  ret i128 %_0
}

; <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::product::<u128>
; Function Attrs: nonlazybind uwtable
define internal i128 @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusiveoENtNtNtNtBa_4iter6traits8iterator8Iterator7productoECslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #1 !guid !195 {
start:
  %0 = alloca [48 x i8], align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %self, i64 48, i1 false)
; call <u128 as core::iter::traits::accum::Product>::product::<core::ops::range::RangeInclusive<u128>>
  %_0 = call i128 @_RINvXsH_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumoNtB6_7Product7productINtNtNtBc_3ops5range14RangeInclusiveoEECslb9dB7bEmfm_4i128(ptr align 16 %0)
  ret i128 %_0
}

; <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB9_4iter6traits5accumoNtB1u_7Product7productINtNtB7_5range14RangeInclusiveoEE0E0Cslb9dB7bEmfm_4i128(ptr %_1, i128 %a, i128 %b) unnamed_addr #0 !guid !196 {
start:
; call <u128 as core::iter::traits::accum::Product>::product::<core::ops::range::RangeInclusive<u128>>::{closure#0}
  %_4 = call i128 @_RNCINvXsH_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumoNtB8_7Product7productINtNtNtBe_3ops5range14RangeInclusiveoEE0Cslb9dB7bEmfm_4i128(ptr %_1, i128 %a, i128 %b) #22
  ret i128 %_4
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cslb9dB7bEmfm_4i128(ptr align 8 %_1) unnamed_addr #0 !guid !197 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECslb9dB7bEmfm_4i128(ptr %_4) #27
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCslb9dB7bEmfm_4i128() #22
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cslb9dB7bEmfm_4i128(i8 %_2) #22
  ret i32 %_0
}

; <u128 as core::iter::traits::accum::Product>::product::<core::ops::range::RangeInclusive<u128>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNCINvXsH_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumoNtB8_7Product7productINtNtNtBe_3ops5range14RangeInclusiveoEE0Cslb9dB7bEmfm_4i128(ptr %_1, i128 %a, i128 %b) unnamed_addr #0 !guid !198 {
start:
  %0 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %a, i128 %b)
  %_4.0 = extractvalue { i128, i1 } %0, 0
  %_4.1 = extractvalue { i128, i1 } %0, 1
  br i1 %_4.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i128 %_4.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_a840ce68d073c0ef52d40243c1f57585) #28
  unreachable
}

; <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB7_11RawVecInner11finish_grow0Cslb9dB7bEmfm_4i128(ptr align 8 %_1) unnamed_addr #0 !guid !199 {
start:
  %_4.0 = load i64, ptr %_1, align 8
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_4.1 = load i64, ptr %0, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %1 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCslb9dB7bEmfm_4i128(i64 %_4.0, i64 %_4.1, ptr align 8 @alloc_c53d1dc14d9dfd00f89649d83c62a8b7) #22
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; alloc::raw_vec::layout_array::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0Cslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !200 {
start:
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %0 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCslb9dB7bEmfm_4i128(i64 0, i64 undef, ptr align 8 @alloc_84e24ad25dfa3f90d9808e22947b437c) #22
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCslb9dB7bEmfm_4i128(ptr %_1) unnamed_addr #0 !guid !201 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCslb9dB7bEmfm_4i128(ptr %0) #22
  ret i32 %_0
}

; i128::fib
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1283fib(i32 %n) unnamed_addr #1 !guid !202 {
start:
  %iter = alloca [8 x i8], align 4
  %b = alloca [16 x i8], align 16
  %a = alloca [16 x i8], align 16
  store i128 0, ptr %a, align 16
  store i128 1, ptr %b, align 16
; call <core::ops::range::Range<u32> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { i32, i32 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangemENtB2_12IntoIterator9into_iterCslb9dB7bEmfm_4i128(i32 0, i32 %n) #22
  %_5.0 = extractvalue { i32, i32 } %0, 0
  %_5.1 = extractvalue { i32, i32 } %0, 1
  store i32 %_5.0, ptr %iter, align 4
  %1 = getelementptr inbounds i8, ptr %iter, i64 4
  store i32 %_5.1, ptr %1, align 4
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::ops::range::Range<u32> as core::iter::traits::iterator::Iterator>::next
  %2 = call { i32, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangemENtNtNtB7_6traits8iterator8Iterator4nextCslb9dB7bEmfm_4i128(ptr align 4 %iter) #22
  %_8.0 = extractvalue { i32, i32 } %2, 0
  %_8.1 = extractvalue { i32, i32 } %2, 1
  %_10 = zext i32 %_8.0 to i64
  %3 = trunc nuw i64 %_10 to i1
  br i1 %3, label %bb5, label %bb6

bb5:                                              ; preds = %bb2
  %_12 = load i128, ptr %a, align 16
  %_13 = load i128, ptr %b, align 16
  %_14.0 = add i128 %_12, %_13
  %_14.1 = icmp ult i128 %_14.0, %_12
  br i1 %_14.1, label %panic, label %bb7

bb6:                                              ; preds = %bb2
  %_0 = load i128, ptr %a, align 16
  ret i128 %_0

bb7:                                              ; preds = %bb5
  %_15 = load i128, ptr %b, align 16
  store i128 %_15, ptr %a, align 16
  store i128 %_14.0, ptr %b, align 16
  br label %bb2

panic:                                            ; preds = %bb5
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_eef5a6daeaf4f66c4683c7d969887037) #28
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; i128::gcd
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1283gcd(i128 %a, i128 %b) unnamed_addr #1 !guid !203 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp eq i128 %b, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_5 = icmp eq i128 %b, 0
  br i1 %_5, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i128 %a, ptr %_0, align 16
  br label %bb4

bb3:                                              ; preds = %bb2
  %_4 = urem i128 %a, %b
; call i128::gcd
  %0 = call i128 @_RNvCslb9dB7bEmfm_4i1283gcd(i128 %b, i128 %_4)
  store i128 %0, ptr %_0, align 16
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_a54b5d523418f9a473b9707e1bf3abdd) #28
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; i128::fact
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1284fact(i32 %n) unnamed_addr #1 !guid !204 {
start:
  %_2 = alloca [48 x i8], align 16
  %_3 = zext i32 %n to i128
; call <core::ops::range::RangeInclusive<u128>>::new
  call void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusiveoE3newCslb9dB7bEmfm_4i128(ptr sret([48 x i8]) align 16 %_2, i128 1, i128 %_3) #22
; call <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::product::<u128>
  %_0 = call i128 @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusiveoENtNtNtNtBa_4iter6traits8iterator8Iterator7productoECslb9dB7bEmfm_4i128(ptr align 16 %_2)
  ret i128 %_0
}

; i128::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCslb9dB7bEmfm_4i1284main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !205 {
start:
  %0 = alloca [32 x i8], align 16
  %1 = alloca [16 x i8], align 8
  %_319 = alloca [16 x i8], align 8
  %args21 = alloca [16 x i8], align 8
  %_310 = alloca [32 x i8], align 16
  %_303 = alloca [16 x i8], align 8
  %_302 = alloca [16 x i8], align 8
  %args20 = alloca [32 x i8], align 8
  %_300 = alloca [16 x i8], align 16
  %_298 = alloca [4 x i8], align 4
  %_291 = alloca [16 x i8], align 8
  %args19 = alloca [16 x i8], align 8
  %_285 = alloca [4 x i8], align 4
  %_278 = alloca [16 x i8], align 8
  %args18 = alloca [16 x i8], align 8
  %_264 = alloca [32 x i8], align 16
  %iter = alloca [32 x i8], align 16
  %acc = alloca [16 x i8], align 16
  %_256 = alloca [16 x i8], align 8
  %_255 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_252 = alloca [16 x i8], align 16
  %x = alloca [16 x i8], align 16
  %_231 = alloca [16 x i8], align 8
  %_230 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_227 = alloca [16 x i8], align 16
  %_224 = alloca [16 x i8], align 16
  %_217 = alloca [16 x i8], align 8
  %_216 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_213 = alloca [16 x i8], align 16
  %_210 = alloca [16 x i8], align 16
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_199 = alloca [24 x i8], align 8
  %_197 = alloca [8 x i8], align 8
  %_189 = alloca [16 x i8], align 8
  %args13 = alloca [16 x i8], align 8
  %_186 = alloca [32 x i8], align 16
  %_179 = alloca [16 x i8], align 8
  %_178 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_175 = alloca [32 x i8], align 16
  %_173 = alloca [1 x i8], align 1
  %_170 = alloca [32 x i8], align 16
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args11 = alloca [32 x i8], align 8
  %_156 = alloca [16 x i8], align 16
  %_150 = alloca [16 x i8], align 16
  %_143 = alloca [16 x i8], align 8
  %_142 = alloca [16 x i8], align 8
  %args10 = alloca [32 x i8], align 8
  %_139 = alloca [16 x i8], align 16
  %_136 = alloca [8 x i8], align 8
  %_129 = alloca [16 x i8], align 8
  %_128 = alloca [16 x i8], align 8
  %_127 = alloca [16 x i8], align 8
  %args9 = alloca [48 x i8], align 8
  %_124 = alloca [4 x i8], align 4
  %_118 = alloca [4 x i8], align 4
  %_116 = alloca [4 x i8], align 4
  %args8 = alloca [24 x i8], align 8
  %_109 = alloca [16 x i8], align 8
  %args7 = alloca [16 x i8], align 8
  %_104 = alloca [16 x i8], align 16
  %_97 = alloca [16 x i8], align 8
  %_96 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_92 = alloca [16 x i8], align 16
  %_88 = alloca [16 x i8], align 16
  %_81 = alloca [16 x i8], align 8
  %_80 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_75 = alloca [16 x i8], align 16
  %_71 = alloca [16 x i8], align 16
  %_64 = alloca [16 x i8], align 8
  %_63 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_60 = alloca [32 x i8], align 16
  %_58 = alloca [32 x i8], align 16
  %_51 = alloca [16 x i8], align 8
  %_50 = alloca [16 x i8], align 8
  %args3 = alloca [32 x i8], align 8
  %_48 = alloca [16 x i8], align 16
  %_44 = alloca [16 x i8], align 16
  %_37 = alloca [16 x i8], align 8
  %_36 = alloca [16 x i8], align 8
  %_35 = alloca [16 x i8], align 8
  %args2 = alloca [48 x i8], align 8
  %_33 = alloca [16 x i8], align 16
  %_27 = alloca [16 x i8], align 16
  %_21 = alloca [16 x i8], align 16
  %args1 = alloca [24 x i8], align 8
  %_12 = alloca [16 x i8], align 8
  %_11 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_8 = alloca [16 x i8], align 16
  %_5 = alloca [16 x i8], align 16
; call core::hint::black_box::<u32>
  %_6 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECslb9dB7bEmfm_4i128(i32 34) #22
; call i128::fact
  %2 = call i128 @_RNvCslb9dB7bEmfm_4i1284fact(i32 %_6)
  store i128 %2, ptr %_5, align 16
; call core::hint::black_box::<u32>
  %_9 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECslb9dB7bEmfm_4i128(i32 180) #22
; call i128::fib
  %3 = call i128 @_RNvCslb9dB7bEmfm_4i1283fib(i32 %_9)
  store i128 %3, ptr %_8, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_11, ptr align 16 %_5) #22
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_12, ptr align 16 %_8) #22
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_11, i64 16, i1 false)
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_12, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %6 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args) #22
  %_2.0 = extractvalue { ptr, ptr } %6, 0
  %_2.1 = extractvalue { ptr, ptr } %6, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<i128>
  %a = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 -170141183460469231731687303715884105727) #22
; call core::hint::black_box::<i128>
  %b = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 1234567890123456789012345678) #22
  %_22 = icmp eq i128 %b, 0
  br i1 %_22, label %panic, label %bb11

bb11:                                             ; preds = %start
  %_23 = icmp eq i128 %b, -1
  %_24 = icmp eq i128 %a, -170141183460469231731687303715884105728
  %_25 = and i1 %_23, %_24
  br i1 %_25, label %panic22, label %bb12

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cde706cbfa574f07c7f055fef22170fe) #28
  unreachable

bb12:                                             ; preds = %bb11
  %7 = sdiv i128 %a, %b
  store i128 %7, ptr %_21, align 16
  %_28 = icmp eq i128 %b, 0
  br i1 %_28, label %panic23, label %bb13

panic22:                                          ; preds = %bb11
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_cde706cbfa574f07c7f055fef22170fe) #28
  unreachable

bb13:                                             ; preds = %bb12
  %_29 = icmp eq i128 %b, -1
  %_30 = icmp eq i128 %a, -170141183460469231731687303715884105728
  %_31 = and i1 %_29, %_30
  br i1 %_31, label %panic24, label %bb14

panic23:                                          ; preds = %bb12
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_d8b1051dca4ca82a457e3b6bfe42d861) #28
  unreachable

bb14:                                             ; preds = %bb13
  %8 = srem i128 %a, %b
  store i128 %8, ptr %_27, align 16
; call <i128>::rem_euclid
  %9 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10rem_euclidCslb9dB7bEmfm_4i128(i128 %a, i128 %b, ptr align 8 @alloc_98b2cc77e91e94d24c695c6a061c28c0) #22
  store i128 %9, ptr %_33, align 16
  store ptr %_21, ptr %args1, align 8
  %10 = getelementptr inbounds i8, ptr %args1, i64 8
  store ptr %_27, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args1, i64 16
  store ptr %_33, ptr %11, align 8
  %_324 = load ptr, ptr %args1, align 8
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_35, ptr align 16 %_324) #22
  %12 = getelementptr inbounds i8, ptr %args1, i64 8
  %_325 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_36, ptr align 16 %_325) #22
  %13 = getelementptr inbounds i8, ptr %args1, i64 16
  %_326 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_37, ptr align 16 %_326) #22
  %14 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %14, ptr align 8 %_35, i64 16, i1 false)
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_36, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_37, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %17 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECslb9dB7bEmfm_4i128(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args2) #22
  %_18.0 = extractvalue { ptr, ptr } %17, 0
  %_18.1 = extractvalue { ptr, ptr } %17, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_18.0, ptr %_18.1)
; call core::hint::black_box::<i128>
  %_45 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 100000000) #22
  %18 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %b, i128 %_45)
  %_46.0 = extractvalue { i128, i1 } %18, 0
  %_46.1 = extractvalue { i128, i1 } %18, 1
  br i1 %_46.1, label %panic25, label %bb22

panic24:                                          ; preds = %bb13
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_d8b1051dca4ca82a457e3b6bfe42d861) #28
  unreachable

bb22:                                             ; preds = %bb14
  store i128 %_46.0, ptr %_44, align 16
  %_0.i = mul i128 %b, %b
  store i128 %_0.i, ptr %_48, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_50, ptr align 16 %_44) #22
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_51, ptr align 16 %_48) #22
  %19 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %19, ptr align 8 %_50, i64 16, i1 false)
  %20 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %_51, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %21 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args3) #22
  %_41.0 = extractvalue { ptr, ptr } %21, 0
  %_41.1 = extractvalue { ptr, ptr } %21, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_41.0, ptr %_41.1)
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_58, i128 %b, i128 %b) #22
; call core::hint::black_box::<i128>
  %_61 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 2) #22
; call <i128>::checked_sub
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_60, i128 %a, i128 %_61) #22
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_63, ptr align 16 %_58) #22
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_64, ptr align 16 %_60) #22
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_63, i64 16, i1 false)
  %23 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %23, ptr align 8 %_64, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %24 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #22
  %_55.0 = extractvalue { ptr, ptr } %24, 0
  %_55.1 = extractvalue { ptr, ptr } %24, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_55.0, ptr %_55.1)
; call core::hint::black_box::<u128>
  %_72 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 3) #22
  %_73 = icmp eq i128 %_72, 0
  br i1 %_73, label %panic26, label %bb36

panic25:                                          ; preds = %bb14
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_5fa04f97916bd874a7a88690ee4d2c7f) #28
  unreachable

bb36:                                             ; preds = %bb22
  %25 = udiv i128 -1, %_72
  store i128 %25, ptr %_71, align 16
; call core::hint::black_box::<u128>
  %_76 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 1) #22
  %26 = shl i128 %_76, 100
  store i128 %26, ptr %_75, align 16
; call <core::fmt::rt::Argument>::new_lower_hex::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_80, ptr align 16 %_71) #22
; call <core::fmt::rt::Argument>::new_binary::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_81, ptr align 16 %_75) #22
  %27 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %27, ptr align 8 %_80, i64 16, i1 false)
  %28 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %28, ptr align 8 %_81, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<11, 2>
  %29 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_59b8058f47772d03e6bfab57ce0a41ae, ptr align 8 %args5) #22
  %_68.0 = extractvalue { ptr, ptr } %29, 0
  %_68.1 = extractvalue { ptr, ptr } %29, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_68.0, ptr %_68.1)
; call <u128>::pow
  %_90 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCslb9dB7bEmfm_4i128(i128 10, i32 36) #22
; call core::hint::black_box::<u128>
  %_89 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 %_90) #22
; call i128::isqrt
  %30 = call i128 @_RNvCslb9dB7bEmfm_4i1285isqrt(i128 %_89)
  store i128 %30, ptr %_88, align 16
; call i128::fact
  %_93 = call i128 @_RNvCslb9dB7bEmfm_4i1284fact(i32 20)
; call i128::fib
  %_94 = call i128 @_RNvCslb9dB7bEmfm_4i1283fib(i32 90)
; call i128::gcd
  %31 = call i128 @_RNvCslb9dB7bEmfm_4i1283gcd(i128 %_93, i128 %_94)
  store i128 %31, ptr %_92, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_96, ptr align 16 %_88) #22
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_97, ptr align 16 %_92) #22
  %32 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %_96, i64 16, i1 false)
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_97, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %34 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #22
  %_85.0 = extractvalue { ptr, ptr } %34, 0
  %_85.1 = extractvalue { ptr, ptr } %34, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_85.0, ptr %_85.1)
; call core::hint::black_box::<u128>
  %_105 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 3) #22
; call <u128>::pow
  %_107 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCslb9dB7bEmfm_4i128(i128 10, i32 30) #22
; call core::hint::black_box::<u128>
  %_106 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 %_107) #22
; call i128::modpow
  %35 = call i128 @_RNvCslb9dB7bEmfm_4i1286modpow(i128 %_105, i128 %_106, i128 1000000007)
  store i128 %35, ptr %_104, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_109, ptr align 16 %_104) #22
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_109, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %37 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECslb9dB7bEmfm_4i128(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args7) #22
  %_101.0 = extractvalue { ptr, ptr } %37, 0
  %_101.1 = extractvalue { ptr, ptr } %37, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_101.0, ptr %_101.1)
  store i32 128, ptr %_116, align 4
; call core::hint::black_box::<u128>
  %_120 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 1) #22
  %_119 = shl i128 %_120, 77
  %38 = call i128 @llvm.cttz.i128(i128 %_119, i1 false)
  %_0.i35 = trunc i128 %38 to i32
  store i32 %_0.i35, ptr %_118, align 4
; call core::hint::black_box::<u128>
  %_125 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 5) #22
  %39 = call i128 @llvm.ctlz.i128(i128 %_125, i1 false)
  %_0.i34 = trunc i128 %39 to i32
  store i32 %_0.i34, ptr %_124, align 4
  store ptr %_116, ptr %args8, align 8
  %40 = getelementptr inbounds i8, ptr %args8, i64 8
  store ptr %_118, ptr %40, align 8
  %41 = getelementptr inbounds i8, ptr %args8, i64 16
  store ptr %_124, ptr %41, align 8
  %_336 = load ptr, ptr %args8, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_127, ptr align 4 %_336) #22
  %42 = getelementptr inbounds i8, ptr %args8, i64 8
  %_337 = load ptr, ptr %42, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_128, ptr align 4 %_337) #22
  %43 = getelementptr inbounds i8, ptr %args8, i64 16
  %_338 = load ptr, ptr %43, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_129, ptr align 4 %_338) #22
  %44 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %44, ptr align 8 %_127, i64 16, i1 false)
  %45 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %45, ptr align 8 %_128, i64 16, i1 false)
  %46 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %46, ptr align 8 %_129, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %47 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECslb9dB7bEmfm_4i128(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args9) #22
  %_113.0 = extractvalue { ptr, ptr } %47, 0
  %_113.1 = extractvalue { ptr, ptr } %47, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_113.0, ptr %_113.1)
; call core::hint::black_box::<u128>
  %_137 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 12345678901234567890123) #22
  %48 = uitofp i128 %_137 to double
  store double %48, ptr %_136, align 8
; call core::hint::black_box::<f64>
  %_140 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECslb9dB7bEmfm_4i128(double 1.000000e+30) #22
  %49 = call i128 @llvm.fptoui.sat.i128.f64(double %_140)
  store i128 %49, ptr %_139, align 16
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_142, ptr align 8 %_136) #22
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_143, ptr align 16 %_139) #22
  %50 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %50, ptr align 8 %_142, i64 16, i1 false)
  %51 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %_143, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %52 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args10) #22
  %_133.0 = extractvalue { ptr, ptr } %52, 0
  %_133.1 = extractvalue { ptr, ptr } %52, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_133.0, ptr %_133.1)
; call core::hint::black_box::<i128>
  %_152 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 -1) #22
  %53 = lshr i128 %_152, 64
  store i128 %53, ptr %_150, align 16
; call core::hint::black_box::<u128>
  %_158 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 -1) #22
  %54 = ashr i128 %_158, 120
  store i128 %54, ptr %_156, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_162, ptr align 16 %_150) #22
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_163, ptr align 16 %_156) #22
  %55 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %55, ptr align 8 %_162, i64 16, i1 false)
  %56 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %57 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args11) #22
  %_147.0 = extractvalue { ptr, ptr } %57, 0
  %_147.1 = extractvalue { ptr, ptr } %57, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_147.0, ptr %_147.1)
; call <str>::parse::<u128>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseoECslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_170, ptr @alloc_ce0acdd4a4f94c66b265f4ef543b4ab6, i64 39) #22
; call <str>::parse::<u128>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseoECslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_175, ptr @alloc_941090dbc54b31f562723ae1638c2086, i64 39) #22
; call <core::result::Result<u128, core::num::error::ParseIntError>>::is_err
  %58 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE6is_errCslb9dB7bEmfm_4i128(ptr align 16 %_175) #22
  %59 = zext i1 %58 to i8
  store i8 %59, ptr %_173, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<u128, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultoNtNtNtB7_3num5error13ParseIntErrorEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_178, ptr align 16 %_170) #22
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_179, ptr %_173) #22
  %60 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %60, ptr align 8 %_178, i64 16, i1 false)
  %61 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %61, ptr align 8 %_179, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %62 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #22
  %_167.0 = extractvalue { ptr, ptr } %62, 0
  %_167.1 = extractvalue { ptr, ptr } %62, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call <i128>::from_str_radix
  call void @_RNvMst_NtCsl10jNU3mE6R_4core3numn14from_str_radixCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_186, ptr @alloc_860d53ce49325a3fa4c8ce10cb01a0c4, i64 3, i32 36) #22
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i128, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultnNtNtNtB7_3num5error13ParseIntErrorEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_189, ptr align 16 %_186) #22
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_189, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %64 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECslb9dB7bEmfm_4i128(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args13) #22
  %_183.0 = extractvalue { ptr, ptr } %64, 0
  %_183.1 = extractvalue { ptr, ptr } %64, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_183.0, ptr %_183.1)
; call <i128 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringnNtB5_8ToString9to_stringCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_199, ptr align 16 @alloc_0407da499bd3b5ae40bf7d4f7ff05b0b) #22
; invoke <alloc::string::String>::len
  %65 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCslb9dB7bEmfm_4i128(ptr align 8 %_199)
          to label %bb97 unwind label %cleanup

panic26:                                          ; preds = %bb22
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_d4d899166b4141918c2da3e256b7165b) #28
  unreachable

bb161:                                            ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECslb9dB7bEmfm_4i128(ptr align 8 %_199) #25
          to label %bb162 unwind label %terminate

cleanup:                                          ; preds = %bb100, %bb99, %bb98, %bb97, %bb36
  %66 = landingpad { ptr, i32 }
          cleanup
  %67 = extractvalue { ptr, i32 } %66, 0
  %68 = extractvalue { ptr, i32 } %66, 1
  store ptr %67, ptr %1, align 8
  %69 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %68, ptr %69, align 8
  br label %bb161

bb97:                                             ; preds = %bb36
  store i64 %65, ptr %_197, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_202, ptr align 16 @alloc_b7cbb96fa2fbc2c33cfdce3b367921a6)
          to label %bb98 unwind label %cleanup

bb98:                                             ; preds = %bb97
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_203, ptr align 8 %_197)
          to label %bb99 unwind label %cleanup

bb99:                                             ; preds = %bb98
  %70 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %70, ptr align 8 %_202, i64 16, i1 false)
  %71 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %71, ptr align 8 %_203, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %72 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14)
          to label %bb100 unwind label %cleanup

bb100:                                            ; preds = %bb99
  %_193.0 = extractvalue { ptr, ptr } %72, 0
  %_193.1 = extractvalue { ptr, ptr } %72, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_193.0, ptr %_193.1)
          to label %bb101 unwind label %cleanup

bb101:                                            ; preds = %bb100
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECslb9dB7bEmfm_4i128(ptr align 8 %_199)
; call core::hint::black_box::<i128>
  %_211 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 7) #22
; call <i128>::pow
  %73 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn3powCslb9dB7bEmfm_4i128(i128 %_211, i32 40) #22
  store i128 %73, ptr %_210, align 16
; call core::hint::black_box::<u128>
  %_214 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 2) #22
; call <u128>::pow
  %74 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCslb9dB7bEmfm_4i128(i128 %_214, i32 127) #22
  store i128 %74, ptr %_213, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_216, ptr align 16 %_210) #22
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_217, ptr align 16 %_213) #22
  %75 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %75, ptr align 8 %_216, i64 16, i1 false)
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_217, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %77 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #22
  %_207.0 = extractvalue { ptr, ptr } %77, 0
  %_207.1 = extractvalue { ptr, ptr } %77, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_207.0, ptr %_207.1)
; call core::hint::black_box::<i128>
  %_225 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 -170141183460469231731687303715884105728) #22
; call <i128>::wrapping_abs
  %78 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCslb9dB7bEmfm_4i128(i128 %_225) #22
  store i128 %78, ptr %_224, align 16
; call core::hint::black_box::<i128>
  %_228 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 -170141183460469231731687303715884105728) #22
; call <i128>::unsigned_abs
  %79 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_228) #22
  store i128 %79, ptr %_227, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_230, ptr align 16 %_224) #22
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_231, ptr align 16 %_227) #22
  %80 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %80, ptr align 8 %_230, i64 16, i1 false)
  %81 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %81, ptr align 8 %_231, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %82 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #22
  %_221.0 = extractvalue { ptr, ptr } %82, 0
  %_221.1 = extractvalue { ptr, ptr } %82, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_221.0, ptr %_221.1)
; call core::hint::black_box::<u128>
  %83 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 24197857203266734864793317670504947440) #22
  store i128 %83, ptr %x, align 16
  %_237 = load i128, ptr %x, align 16
; call core::hint::black_box::<u32>
  %_238 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECslb9dB7bEmfm_4i128(i32 33) #22
; call core::intrinsics::rotate_left::<u128>
  %_0.i30 = call i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftoECslb9dB7bEmfm_4i128(i128 %_237, i32 %_238) #29
  %_240 = load i128, ptr %x, align 16
  %_239 = lshr i128 %_240, 5
  %_235 = xor i128 %_0.i30, %_239
  %_244 = load i128, ptr %x, align 16
  %_243 = shl i128 %_244, 9
  %84 = or i128 %_235, %_243
  store i128 %84, ptr %x, align 16
  %_253 = load i128, ptr %x, align 16
  %_0.i29 = call i128 @llvm.bswap.i128(i128 %_253)
  store i128 %_0.i29, ptr %_252, align 16
; call <core::fmt::rt::Argument>::new_lower_hex::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_255, ptr align 16 %x) #22
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_256, ptr align 16 %_252) #22
  %85 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %85, ptr align 8 %_255, i64 16, i1 false)
  %86 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %86, ptr align 8 %_256, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %87 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #22
  %_248.0 = extractvalue { ptr, ptr } %87, 0
  %_248.1 = extractvalue { ptr, ptr } %87, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_248.0, ptr %_248.1)
  store i128 0, ptr %acc, align 16
; call core::hint::black_box::<u128>
  %_262 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 100) #22
; call <core::ops::range::Range<u128> as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangeoENtB2_12IntoIterator9into_iterCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %0, i128 0, i128 %_262) #22
  %_260.0 = load i128, ptr %0, align 16
  %88 = getelementptr inbounds i8, ptr %0, i64 16
  %_260.1 = load i128, ptr %88, align 16
  store i128 %_260.0, ptr %iter, align 16
  %89 = getelementptr inbounds i8, ptr %iter, i64 16
  store i128 %_260.1, ptr %89, align 16
  br label %bb131

bb131:                                            ; preds = %bb137, %bb101
; call <core::ops::range::Range<u128> as core::iter::traits::iterator::Iterator>::next
  call void @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeoENtNtNtB7_6traits8iterator8Iterator4nextCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_264, ptr align 16 %iter) #22
  %90 = load i128, ptr %_264, align 16
  %91 = getelementptr inbounds i8, ptr %_264, i64 16
  %92 = load i128, ptr %91, align 16
  %_266 = trunc i128 %90 to i64
  %93 = trunc nuw i64 %_266 to i1
  br i1 %93, label %bb134, label %bb135

bb134:                                            ; preds = %bb131
  %94 = getelementptr inbounds i8, ptr %_264, i64 16
  %i = load i128, ptr %94, align 16
  %_270 = load i128, ptr %acc, align 16
  %_0.i33 = mul i128 %_270, 6364136223846793005
  %95 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %i, i128 1442695040888963407)
  %_272.0 = extractvalue { i128, i1 } %95, 0
  %_272.1 = extractvalue { i128, i1 } %95, 1
  br i1 %_272.1, label %panic28, label %bb137

bb135:                                            ; preds = %bb131
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_278, ptr align 16 %acc) #22
  %96 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %96, ptr align 8 %_278, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %97 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECslb9dB7bEmfm_4i128(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args18) #22
  %_274.0 = extractvalue { ptr, ptr } %97, 0
  %_274.1 = extractvalue { ptr, ptr } %97, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_274.0, ptr %_274.1)
; call core::hint::black_box::<u128>
  %_286 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 1267650600228229401496703205376) #22
  %98 = uitofp i128 %_286 to float
  store float %98, ptr %_285, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_291, ptr align 4 %_285) #22
  %99 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args19, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %99, ptr align 8 %_291, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %100 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECslb9dB7bEmfm_4i128(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args19) #22
  %_282.0 = extractvalue { ptr, ptr } %100, 0
  %_282.1 = extractvalue { ptr, ptr } %100, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_282.0, ptr %_282.1)
  store i32 128, ptr %_298, align 4
  store i128 -1, ptr %_300, align 16
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_302, ptr align 4 %_298) #22
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_303, ptr align 16 %_300) #22
  %101 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %101, ptr align 8 %_302, i64 16, i1 false)
  %102 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %102, ptr align 8 %_303, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %103 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args20) #22
  %_295.0 = extractvalue { ptr, ptr } %103, 0
  %_295.1 = extractvalue { ptr, ptr } %103, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_295.0, ptr %_295.1)
; call core::hint::black_box::<u64>
  %_313 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECslb9dB7bEmfm_4i128(i64 -1) #22
  %_312 = zext i64 %_313 to i128
; call core::hint::black_box::<u64>
  %_315 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECslb9dB7bEmfm_4i128(i64 -1) #22
  %_314 = zext i64 %_315 to i128
  %104 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_312, i128 %_314)
  %_316.0 = extractvalue { i128, i1 } %104, 0
  %_316.1 = extractvalue { i128, i1 } %104, 1
  br i1 %_316.1, label %panic27, label %bb155

bb155:                                            ; preds = %bb135
; call core::hint::black_box::<u128>
  %_317 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 -1) #22
  %_5.0.i = add i128 %_316.0, %_317
  %_5.1.i = icmp ult i128 %_5.0.i, %_316.0
  store i128 %_5.0.i, ptr %_310, align 16
  %105 = getelementptr inbounds i8, ptr %_310, i64 16
  %106 = zext i1 %_5.1.i to i8
  store i8 %106, ptr %105, align 16
; call <core::fmt::rt::Argument>::new_debug::<(u128, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTobEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_319, ptr align 16 %_310) #22
  %107 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_319, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %108 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECslb9dB7bEmfm_4i128(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args21) #22
  %_307.0 = extractvalue { ptr, ptr } %108, 0
  %_307.1 = extractvalue { ptr, ptr } %108, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_307.0, ptr %_307.1)
  ret void

panic27:                                          ; preds = %bb135
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_e4959e06482677e63dd48c2a86fcf0e7) #28
  unreachable

bb137:                                            ; preds = %bb134
  %_0.i32 = add i128 %_0.i33, %_272.0
  store i128 %_0.i32, ptr %acc, align 16
  br label %bb131

panic28:                                          ; preds = %bb134
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_744d897956c077d5b9b7148f78bfe5aa) #28
  unreachable

bb133:                                            ; No predecessors!
  unreachable

terminate:                                        ; preds = %bb161
  %109 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable

bb162:                                            ; preds = %bb161
  %110 = load ptr, ptr %1, align 8
  %111 = getelementptr inbounds i8, ptr %1, i64 8
  %112 = load i32, ptr %111, align 8
  %113 = insertvalue { ptr, i32 } poison, ptr %110, 0
  %114 = insertvalue { ptr, i32 } %113, i32 %112, 1
  resume { ptr, i32 } %114
}

; i128::isqrt
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1285isqrt(i128 %n) unnamed_addr #1 !guid !206 {
start:
  %y = alloca [16 x i8], align 16
  %x = alloca [16 x i8], align 16
  store i128 %n, ptr %x, align 16
  %_5 = load i128, ptr %x, align 16
  %_6.0 = add i128 %_5, 1
  %_6.1 = icmp ult i128 %_6.0, %_5
  br i1 %_6.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  %0 = udiv i128 %_6.0, 2
  store i128 %0, ptr %y, align 16
  br label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_b14d820ee55f823d3aefb1afa0d7eac6) #28
  unreachable

bb3:                                              ; preds = %bb6, %bb1
  %_9 = load i128, ptr %y, align 16
  %_10 = load i128, ptr %x, align 16
  %_8 = icmp ult i128 %_9, %_10
  br i1 %_8, label %bb4, label %bb8

bb8:                                              ; preds = %bb3
  %_0 = load i128, ptr %x, align 16
  ret i128 %_0

bb4:                                              ; preds = %bb3
  %_11 = load i128, ptr %y, align 16
  store i128 %_11, ptr %x, align 16
  %_13 = load i128, ptr %x, align 16
  %_15 = load i128, ptr %x, align 16
  %_16 = icmp eq i128 %_15, 0
  br i1 %_16, label %panic1, label %bb5

bb5:                                              ; preds = %bb4
  %_14 = udiv i128 %n, %_15
  %_17.0 = add i128 %_13, %_14
  %_17.1 = icmp ult i128 %_17.0, %_13
  br i1 %_17.1, label %panic2, label %bb6

panic1:                                           ; preds = %bb4
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_a7299c6c6510c3de3e014799b32a1fb6) #28
  unreachable

bb6:                                              ; preds = %bb5
  %1 = udiv i128 %_17.0, 2
  store i128 %1, ptr %y, align 16
  br label %bb3

panic2:                                           ; preds = %bb5
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_83736e0ed8986abd3fb627960735e4af) #28
  unreachable
}

; i128::modpow
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1286modpow(i128 %0, i128 %1, i128 %m) unnamed_addr #1 !guid !207 {
start:
  %r = alloca [16 x i8], align 16
  %e = alloca [16 x i8], align 16
  %b = alloca [16 x i8], align 16
  store i128 %0, ptr %b, align 16
  store i128 %1, ptr %e, align 16
  store i128 1, ptr %r, align 16
  %_5 = icmp eq i128 %m, 0
  br i1 %_5, label %panic, label %bb1

bb1:                                              ; preds = %start
  %2 = load i128, ptr %b, align 16
  %3 = urem i128 %2, %m
  store i128 %3, ptr %b, align 16
  br label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_68c3021501d9c8f06b4083bb56ba3908) #28
  unreachable

bb2:                                              ; preds = %bb9, %bb1
  %_7 = load i128, ptr %e, align 16
  %_6 = icmp ugt i128 %_7, 0
  br i1 %_6, label %bb3, label %bb11

bb11:                                             ; preds = %bb2
  %_0 = load i128, ptr %r, align 16
  ret i128 %_0

bb3:                                              ; preds = %bb2
  %_10 = load i128, ptr %e, align 16
  %_9 = and i128 %_10, 1
  %_8 = icmp eq i128 %_9, 1
  br i1 %_8, label %bb4, label %bb7

bb7:                                              ; preds = %bb6, %bb3
  %_17 = load i128, ptr %b, align 16
  %_18 = load i128, ptr %b, align 16
  %4 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_17, i128 %_18)
  %_19.0 = extractvalue { i128, i1 } %4, 0
  %_19.1 = extractvalue { i128, i1 } %4, 1
  br i1 %_19.1, label %panic3, label %bb8

bb4:                                              ; preds = %bb3
  %_12 = load i128, ptr %r, align 16
  %_13 = load i128, ptr %b, align 16
  %5 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_12, i128 %_13)
  %_14.0 = extractvalue { i128, i1 } %5, 0
  %_14.1 = extractvalue { i128, i1 } %5, 1
  br i1 %_14.1, label %panic1, label %bb5

bb5:                                              ; preds = %bb4
  %_15 = icmp eq i128 %m, 0
  br i1 %_15, label %panic2, label %bb6

panic1:                                           ; preds = %bb4
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_c27fb0410a6c5898f903969645269014) #28
  unreachable

bb6:                                              ; preds = %bb5
  %6 = urem i128 %_14.0, %m
  store i128 %6, ptr %r, align 16
  br label %bb7

panic2:                                           ; preds = %bb5
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_c27fb0410a6c5898f903969645269014) #28
  unreachable

bb8:                                              ; preds = %bb7
  %_20 = icmp eq i128 %m, 0
  br i1 %_20, label %panic4, label %bb9

panic3:                                           ; preds = %bb7
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_b711721f7bfa298d55b2bdbe61d56fe1) #28
  unreachable

bb9:                                              ; preds = %bb8
  %7 = urem i128 %_19.0, %m
  store i128 %7, ptr %b, align 16
  %8 = load i128, ptr %e, align 16
  %9 = lshr i128 %8, 1
  store i128 %9, ptr %e, align 16
  br label %bb2

panic4:                                           ; preds = %bb8
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_b711721f7bfa298d55b2bdbe61d56fe1) #28
  unreachable
}

; <alloc::vec::Vec<u8>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !208 {
start:
; call <alloc::vec::Vec<u8>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #22
  ret void
}

; <alloc::string::String>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !209 {
start:
  %_2 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_2, i64 %capacity) #22
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !210 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCslb9dB7bEmfm_4i128(ptr align 8 %self) #22
  ret i64 %_0
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCslb9dB7bEmfm_4i128(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !211 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCslb9dB7bEmfm_4i128(ptr align 8 %self) #22
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cslb9dB7bEmfm_4i128(i32 %ch) #22
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %ch_len) #22
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCslb9dB7bEmfm_4i128(ptr align 8 %self) #22
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCslb9dB7bEmfm_4i128(i32 %ch, ptr %_0.i) #22
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %_14) #22
  ret void
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !212 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::string::String>::push_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %string.0, i64 %string.1) unnamed_addr #0 !guid !213 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %string.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %string.1, 1
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; call <alloc::vec::Vec<u8>>::extend_from_slice
  call void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %_4.0, i64 %_4.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !214 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <[u8]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !215 {
start:
; call <core::slice::iter::Iter<u8>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !216 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <core::option::Option<i128>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_noneCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !217 {
start:
; call <core::option::Option<i128>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_someCslb9dB7bEmfm_4i128(ptr align 16 %self) #22
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::option::Option<i128>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_someCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !218 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i128, ptr %self, align 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i128, ptr %1, align 16
  %_2 = trunc i128 %0 to i64
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u128, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE5is_okCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !219 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u128, core::num::error::ParseIntError>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE6is_errCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !220 {
start:
; call <core::result::Result<u128, core::num::error::ParseIntError>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE5is_okCslb9dB7bEmfm_4i128(ptr align 16 %self) #22
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCslb9dB7bEmfm_4i128(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !221 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCslb9dB7bEmfm_4i128(i64 %align, ptr align 8 %0) #26
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCslb9dB7bEmfm_4i128(i64 %self) unnamed_addr #0 !guid !222 {
start:
  ret i64 %self
}

; <core::mem::alignment::Alignment>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCslb9dB7bEmfm_4i128(i64 %align) unnamed_addr #0 !guid !223 {
start:
  %_0 = alloca [8 x i8], align 8
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCslb9dB7bEmfm_4i128(i64 %align, ptr align 8 @alloc_988c380202cc7b7a37ca3d8d5930c44f) #22
  store i64 %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::mem::alignment::Alignment>::as_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCslb9dB7bEmfm_4i128(i64 %self) unnamed_addr #0 !guid !224 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCslb9dB7bEmfm_4i128(i64 %self) #22
; call <core::num::nonzero::NonZero<usize>>::get
  %_0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCslb9dB7bEmfm_4i128(i64 %_2) #22
  ret i64 %_0
}

; <*mut u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCslb9dB7bEmfm_4i128(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !225 {
start:
; call <*const u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCslb9dB7bEmfm_4i128(ptr %self, ptr %origin, ptr align 8 %0) #22
  ret i64 %_0
}

; <*mut u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !226 {
start:
; call <*const u8>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCslb9dB7bEmfm_4i128(ptr %self) #22
  ret i1 %_0
}

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !227 {
start:
; call <*const ()>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCslb9dB7bEmfm_4i128(ptr %self) #22
  ret i1 %_0
}

; <*const u8>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh20offset_from_unsignedCslb9dB7bEmfm_4i128(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !228 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 1
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCslb9dB7bEmfm_4i128(ptr %self, ptr %origin, ptr align 8 %0) #26
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #28
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 1, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 1
  ret i64 %_0
}

; <*const u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !229 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCslb9dB7bEmfm_4i128(ptr %self) #22
  ret i1 %_0
}

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCslb9dB7bEmfm_4i128(ptr %self, i64 %align) unnamed_addr #0 !guid !230 {
start:
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i1 = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i1, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_fad0cd83b7d1858a846a172eb260e593, i64 42) #22
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 @alloc_7abc4ceda2d1d9be88f00c5dc522bc84) #28
  unreachable

bb2:                                              ; preds = %start
  %_0.i = ptrtoint ptr %self to i64
  %_8 = sub i64 %align, 1
  %_6 = and i64 %_0.i, %_8
  %_0 = icmp eq i64 %_6, 0
  ret i1 %_0
}

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !231 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCslb9dB7bEmfm_4i128(ptr %self) #22
  ret i1 %_0
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cslb9dB7bEmfm_4i128(i32 %self) unnamed_addr #0 !guid !232 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cslb9dB7bEmfm_4i128(i32 %self) #22
  ret i64 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %self, i32 %radix) unnamed_addr #0 !guid !233 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #22
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #28
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !234 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCslb9dB7bEmfm_4i128(i64 %_3) #22
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCslb9dB7bEmfm_4i128(i64 %_2) #22
  ret ptr %_0
}

; <core::alloc::layout::Layout>::repeat_packed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %n) unnamed_addr #0 !guid !235 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %0, align 8
; call <usize>::checked_mul
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCslb9dB7bEmfm_4i128(i64 %_4, i64 %n) #22
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %size = load i64, ptr %8, align 8
  %_7 = load i64, ptr %self, align 8
; call <core::alloc::layout::Layout>::from_size_alignment
  %9 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCslb9dB7bEmfm_4i128(i64 %size, i64 %_7) #22
  %10 = extractvalue { i64, i64 } %9, 0
  %11 = extractvalue { i64, i64 } %9, 1
  store i64 %10, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %13 = load i64, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { i64, i64 } poison, i64 %13, 0
  %17 = insertvalue { i64, i64 } %16, i64 %15, 1
  ret { i64, i64 } %17

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCslb9dB7bEmfm_4i128(i64 %size, i64 %alignment) unnamed_addr #0 !guid !236 {
start:
  %_0 = alloca [16 x i8], align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 %alignment, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %size, ptr %0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <core::alloc::layout::Layout>::is_size_align_valid
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCslb9dB7bEmfm_4i128(i64 %size, i64 %align) unnamed_addr #0 !guid !237 {
start:
  %_4 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
; call <core::mem::alignment::Alignment>::new
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCslb9dB7bEmfm_4i128(i64 %align) #22
  store i64 %0, ptr %_4, align 8
  %1 = load i64, ptr %_4, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %alignment = load i64, ptr %_4, align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %4 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_align_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCslb9dB7bEmfm_4i128(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !238 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCslb9dB7bEmfm_4i128(i64 %size, i64 %align, ptr align 8 %0) #26
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %align, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !239 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::align
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !240 {
start:
  %_2 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_usize
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCslb9dB7bEmfm_4i128(i64 %_2) #22
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !241 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCslb9dB7bEmfm_4i128(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !242 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCslb9dB7bEmfm_4i128(i64 %3, i64 %5, i1 zeroext %8) #22
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCslb9dB7bEmfm_4i128(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !243 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCslb9dB7bEmfm_4i128(ptr %2, i64 %4, i64 %6) #22
  ret void
}

; <alloc::alloc::Global>::grow_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global17grow_impl_runtimeCslb9dB7bEmfm_4i128(ptr %self, ptr %ptr, i64 %0, i64 %1, i64 %2, i64 %3, i1 zeroext %zeroed) unnamed_addr #0 !guid !244 {
start:
  %_8.i.i = alloca [1 x i8], align 1
  %_30 = alloca [16 x i8], align 8
  %_21 = alloca [8 x i8], align 8
  %old_size = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %new_layout = alloca [16 x i8], align 8
  %old_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %old_layout, align 8
  %4 = getelementptr inbounds i8, ptr %old_layout, i64 8
  store i64 %1, ptr %4, align 8
  store i64 %2, ptr %new_layout, align 8
  %5 = getelementptr inbounds i8, ptr %new_layout, i64 8
  store i64 %3, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %old_layout) #22
  store i64 %6, ptr %old_size, align 8
  %7 = load i64, ptr %old_size, align 8
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %9 = load i64, ptr %new_layout, align 8
  %10 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %11 = load i64, ptr %10, align 8
; call <alloc::alloc::Global>::alloc_impl
  %12 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCslb9dB7bEmfm_4i128(ptr %self, i64 %9, i64 %11, i1 zeroext %zeroed) #22
  %13 = extractvalue { ptr, i64 } %12, 0
  %14 = extractvalue { ptr, i64 } %12, 1
  store ptr %13, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %14, ptr %15, align 8
  br label %bb30

bb2:                                              ; preds = %start
; call <core::alloc::layout::Layout>::align
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCslb9dB7bEmfm_4i128(ptr align 8 %old_layout) #22
; call <core::alloc::layout::Layout>::align
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCslb9dB7bEmfm_4i128(ptr align 8 %new_layout) #22
  %_9 = icmp eq i64 %_10, %_12
  br i1 %_9, label %bb6, label %bb7

bb30:                                             ; preds = %bb17, %bb20, %bb25, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECslb9dB7bEmfm_4i128.exit, %bb3
  %16 = load ptr, ptr %_0, align 8
  %17 = getelementptr inbounds i8, ptr %_0, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  ret { ptr, i64 } %20

bb7:                                              ; preds = %bb2
  %21 = load i64, ptr %new_layout, align 8
  %22 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %23 = load i64, ptr %22, align 8
; call <alloc::alloc::Global>::alloc_impl
  %24 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCslb9dB7bEmfm_4i128(ptr %self, i64 %21, i64 %23, i1 zeroext %zeroed) #22
  %_31.0 = extractvalue { ptr, i64 } %24, 0
  %_31.1 = extractvalue { ptr, i64 } %24, 1
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %25 = call { ptr, i64 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr %_31.0, i64 %_31.1) #22
  %26 = extractvalue { ptr, i64 } %25, 0
  %27 = extractvalue { ptr, i64 } %25, 1
  store ptr %26, ptr %_30, align 8
  %28 = getelementptr inbounds i8, ptr %_30, i64 8
  store i64 %27, ptr %28, align 8
  %29 = load ptr, ptr %_30, align 8
  %30 = getelementptr inbounds i8, ptr %_30, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = ptrtoint ptr %29 to i64
  %33 = icmp eq i64 %32, 0
  %_32 = select i1 %33, i64 1, i64 0
  %34 = trunc nuw i64 %_32 to i1
  br i1 %34, label %bb25, label %bb24

bb6:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %new_size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %new_layout) #22
; call <core::alloc::layout::Layout>::size
  %_18 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %old_layout) #22
  %_17 = icmp uge i64 %new_size, %_18
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_2.i, label %bb2.i2, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i2:                                           ; preds = %bb6
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCslb9dB7bEmfm_4i128(i1 zeroext %_17, ptr align 8 @alloc_9e1ff22d96cae328e0e878f28b86a5f7) #26
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb6, %bb2.i2
  %35 = load i64, ptr %old_layout, align 8
  %36 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %37 = load i64, ptr %36, align 8
; call alloc::alloc::realloc_nonnull
  %raw_ptr = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc15realloc_nonnullCslb9dB7bEmfm_4i128(ptr %ptr, i64 %35, i64 %37, i64 %new_size) #22
; call <core::ptr::non_null::NonNull<u8>>::new
  %_23 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCslb9dB7bEmfm_4i128(ptr %raw_ptr) #22
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_22 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECslb9dB7bEmfm_4i128(ptr %_23) #22
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %38 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr %_22) #22
  store ptr %38, ptr %_21, align 8
  %39 = load ptr, ptr %_21, align 8
  %40 = ptrtoint ptr %39 to i64
  %41 = icmp eq i64 %40, 0
  %_24 = select i1 %41, i64 1, i64 0
  %42 = trunc nuw i64 %_24 to i1
  br i1 %42, label %bb17, label %bb16

bb25:                                             ; preds = %bb7
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %43 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCslb9dB7bEmfm_4i128(ptr align 8 @alloc_6379aaa2812385052216e7dc8e3279fb) #22
  %44 = extractvalue { ptr, i64 } %43, 0
  %45 = extractvalue { ptr, i64 } %43, 1
  store ptr %44, ptr %_0, align 8
  %46 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %45, ptr %46, align 8
  br label %bb30

bb24:                                             ; preds = %bb7
  %new_ptr.0 = load ptr, ptr %_30, align 8
  %47 = getelementptr inbounds i8, ptr %_30, i64 8
  %new_ptr.1 = load i64, ptr %47, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_37 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCslb9dB7bEmfm_4i128(ptr %new_ptr.0, i64 %new_ptr.1) #22
  %48 = load i64, ptr %old_size, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECslb9dB7bEmfm_4i128.exit

bb2.i:                                            ; preds = %bb24
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCslb9dB7bEmfm_4i128(ptr %ptr, ptr %_37, i64 1, i64 1, i64 %48, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #26
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECslb9dB7bEmfm_4i128.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECslb9dB7bEmfm_4i128.exit: ; preds = %bb24, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_37, ptr align 1 %ptr, i64 %48, i1 false)
  %49 = load i64, ptr %old_layout, align 8
  %50 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %51 = load i64, ptr %50, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCslb9dB7bEmfm_4i128(ptr %self, ptr %ptr, i64 %49, i64 %51) #22
  store ptr %new_ptr.0, ptr %_0, align 8
  %52 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %new_ptr.1, ptr %52, align 8
  br label %bb30

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %53 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCslb9dB7bEmfm_4i128(ptr align 8 @alloc_a699fef46c42b266f9e12652c07a696a) #22
  %54 = extractvalue { ptr, i64 } %53, 0
  %55 = extractvalue { ptr, i64 } %53, 1
  store ptr %54, ptr %_0, align 8
  %56 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %55, ptr %56, align 8
  br label %bb30

bb16:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %ptr1 = load ptr, ptr %_21, align 8
  br i1 %zeroed, label %bb18, label %bb20

bb20:                                             ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCslb9dB7bEmfm_4i128.exit, %bb16
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %57 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCslb9dB7bEmfm_4i128(ptr %ptr1, i64 %new_size) #22
  %_29.0 = extractvalue { ptr, i64 } %57, 0
  %_29.1 = extractvalue { ptr, i64 } %57, 1
  store ptr %_29.0, ptr %_0, align 8
  %58 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29.1, ptr %58, align 8
  br label %bb30

bb18:                                             ; preds = %bb16
  %59 = load i64, ptr %old_size, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %raw_ptr, i64 %59
  %60 = load i64, ptr %old_size, align 8
  %_28 = sub i64 %new_size, %60
; call core::ub_checks::check_language_ub
  %_4.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_4.i.i, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCslb9dB7bEmfm_4i128.exit

bb2.i.i:                                          ; preds = %bb18
  %61 = icmp eq i64 %_28, 0
  %62 = zext i1 %61 to i8
  store i8 %62, ptr %_8.i.i, align 1
  %63 = load i8, ptr %_8.i.i, align 1
  %64 = trunc nuw i8 %63 to i1
; call core::ptr::write_bytes::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr11write_bytes18precondition_checkCslb9dB7bEmfm_4i128(ptr %_0.i, i64 1, i1 zeroext %64, ptr align 8 @alloc_2fc439fdc88563e15d315d43214d38e0) #26
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCslb9dB7bEmfm_4i128.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh11write_bytesCslb9dB7bEmfm_4i128.exit: ; preds = %bb18, %bb2.i.i
  call void @llvm.memset.p0.i64(ptr align 1 %_0.i, i8 0, i64 %_28, i1 false)
  br label %bb20

bb15:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCslb9dB7bEmfm_4i128(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !245 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCslb9dB7bEmfm_4i128(ptr %_6, i64 0) #22
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCslb9dB7bEmfm_4i128(i64 %11, i64 %13) #22
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCslb9dB7bEmfm_4i128(i64 %15, i64 %17) #22
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCslb9dB7bEmfm_4i128(ptr %_12) #22
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECslb9dB7bEmfm_4i128(ptr %_11) #22
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr %_10) #22
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCslb9dB7bEmfm_4i128(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #22
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCslb9dB7bEmfm_4i128(ptr %ptr, i64 %size) #22
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCslb9dB7bEmfm_4i128(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !246 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCslb9dB7bEmfm_4i128(ptr %ptr, i64 %3, i64 %5) #22
  br label %bb3
}

; <alloc::alloc::Global>::grow_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global9grow_implCslb9dB7bEmfm_4i128(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !247 {
start:
  %_6 = alloca [56 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %_6, i64 32
  store ptr %self, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_6, i64 40
  store ptr %ptr, ptr %1, align 8
  store i64 %old_layout.0, ptr %_6, align 8
  %2 = getelementptr inbounds i8, ptr %_6, i64 8
  store i64 %old_layout.1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_6, i64 16
  store i64 %new_layout.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %new_layout.1, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_6, i64 48
  %6 = zext i1 %zeroed to i8
  store i8 %6, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %_6, i64 32
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds i8, ptr %_6, i64 40
  %10 = load ptr, ptr %9, align 8
  %11 = load i64, ptr %_6, align 8
  %12 = getelementptr inbounds i8, ptr %_6, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = getelementptr inbounds i8, ptr %_6, i64 16
  %15 = load i64, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = getelementptr inbounds i8, ptr %_6, i64 48
  %19 = load i8, ptr %18, align 8
  %20 = trunc nuw i8 %19 to i1
; call <alloc::alloc::Global>::grow_impl_runtime
  %21 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global17grow_impl_runtimeCslb9dB7bEmfm_4i128(ptr %8, ptr %10, i64 %11, i64 %13, i64 %15, i64 %17, i1 zeroext %20) #22
  %_0.0 = extractvalue { ptr, i64 } %21, 0
  %_0.1 = extractvalue { ptr, i64 } %21, 1
  %22 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %_0.1, 1
  ret { ptr, i64 } %23
}

; <alloc::raw_vec::RawVec<u8>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !248 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u8>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECslb9dB7bEmfm_4i128(ptr align 8 %self) #22
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u8>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #0 !guid !249 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %len, i64 %additional, i64 1, i64 1) #22
  ret void
}

; <alloc::raw_vec::RawVec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !250 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 1) #22
  ret i64 %_0
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCslb9dB7bEmfm_4i128(i32 %self) unnamed_addr #0 !guid !251 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCslb9dB7bEmfm_4i128(i32 %self) #22
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCslb9dB7bEmfm_4i128(i32 %self) unnamed_addr #0 !guid !252 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCslb9dB7bEmfm_4i128(i64 %addr) unnamed_addr #0 !guid !253 {
start:
  %_0 = inttoptr i64 %addr to ptr
  ret ptr %_0
}

; <core::num::nonzero::NonZero<u128>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE13leading_zerosCslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !254 {
start:
; call <core::num::nonzero::NonZero<u128>>::get
  %_2 = call i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3getCslb9dB7bEmfm_4i128(i128 %self) #22
  %0 = call i128 @llvm.ctlz.i128(i128 %_2, i1 true)
  %_0 = trunc i128 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u128>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE5ilog2Cslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !255 {
start:
; call <core::num::nonzero::NonZero<u128>>::leading_zeros
  %_3 = call i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE13leading_zerosCslb9dB7bEmfm_4i128(i128 %self) #22
  %_0 = sub i32 127, %_3
  ret i32 %_0
}

; <alloc::vec::Vec<u8>>::extend_from_slice
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #1 !guid !256 {
start:
; call <[u8]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterCslb9dB7bEmfm_4i128(ptr %other.0, i64 %other.1) #22
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
; call <alloc::vec::Vec<u8> as alloc::vec::spec_extend::SpecExtend<&u8, core::slice::iter::Iter<u8>>>::spec_extend
  call void @_RNvXs2_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB7_3VechEINtB5_10SpecExtendRhINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhEE11spec_extendCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %_3.0, ptr %_3.1)
  ret void
}

; <core::ptr::unique::Unique<u8>>::from_non_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCslb9dB7bEmfm_4i128(ptr %pointer) unnamed_addr #0 !guid !257 {
start:
  ret ptr %pointer
}

; <core::ptr::unique::Unique<u8>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !258 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<i128>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionnEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !259 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultnNtNtNtB9_3num5error13ParseIntErrorEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !260 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultoNtNtNtB9_3num5error13ParseIntErrorEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !261 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCslb9dB7bEmfm_4i128(ptr %ptr.0, i64 %ptr.1, ptr align 8 %0) unnamed_addr #0 !guid !262 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %ptr.1, 1
  ret { ptr, i64 } %2

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCslb9dB7bEmfm_4i128(ptr %ptr.0, ptr align 8 %0) #26
  br label %bb3
}

; <core::ptr::non_null::NonNull<[u8]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCslb9dB7bEmfm_4i128(ptr %r.0, i64 %r.1) unnamed_addr #0 !guid !263 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<(u128, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTobEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !264 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCslb9dB7bEmfm_4i128(ptr %r) unnamed_addr #0 !guid !265 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCslb9dB7bEmfm_4i128(ptr align 8 %r) unnamed_addr #0 !guid !266 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCslb9dB7bEmfm_4i128(ptr align 4 %r) unnamed_addr #0 !guid !267 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCslb9dB7bEmfm_4i128(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !268 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCslb9dB7bEmfm_4i128(ptr %ptr, ptr align 8 %0) #26
  br label %bb3
}

; <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCslb9dB7bEmfm_4i128(ptr %self, ptr %subtracted) unnamed_addr #0 !guid !269 {
start:
; call <*mut u8>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh20offset_from_unsignedCslb9dB7bEmfm_4i128(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #22
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCslb9dB7bEmfm_4i128(ptr %ptr) unnamed_addr #0 !guid !270 {
start:
  %_0 = alloca [8 x i8], align 8
; call <*mut u8>::is_null
  %_2 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCslb9dB7bEmfm_4i128(ptr %ptr) #22
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCslb9dB7bEmfm_4i128(ptr %ptr, ptr align 8 @alloc_e469ef44bf39c45bcb672a4bc963b9cb) #22
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <core::ptr::non_null::NonNull<usize>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCslb9dB7bEmfm_4i128(ptr align 8 %r) unnamed_addr #0 !guid !271 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCslb9dB7bEmfm_4i128(ptr align 4 %r) unnamed_addr #0 !guid !272 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !273 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !274 {
start:
  ret ptr %r
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCslb9dB7bEmfm_4i128(i64 %val) unnamed_addr #0 !guid !275 {
start:
  ret i64 %val
}

; <core::num::niche_types::UsizeNoHighBit>::as_inner
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCslb9dB7bEmfm_4i128(i64 %self) unnamed_addr #0 !guid !276 {
start:
  ret i64 %self
}

; <alloc::raw_vec::RawVecInner>::needs_to_grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #0 !guid !277 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %elem_layout) #22
; call <alloc::raw_vec::RawVecInner>::capacity
  %_6 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %_7) #22
  %_0.i = sub i64 %_6, %len
  %_0 = icmp ugt i64 %additional, %_0.i
  ret i1 %_0
}

; <alloc::raw_vec::RawVecInner>::current_memory
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %0, i64 %1) unnamed_addr #0 !guid !278 {
start:
  %_17 = alloca [24 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %elem_layout) #22
  %_3 = icmp eq i64 %_4, 0
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_7 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCslb9dB7bEmfm_4i128(i64 %_8) #22
  %_6 = icmp eq i64 %_7, 0
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb2, %start
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %3, align 8
  br label %bb12

bb5:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %elem_layout) #22
  %_13 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_12 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCslb9dB7bEmfm_4i128(i64 %_13) #22
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

bb2.i:                                            ; preds = %bb5
; call <usize>::unchecked_mul::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCslb9dB7bEmfm_4i128(i64 %_10, i64 %_12, ptr align 8 @alloc_85bcb8feb56634093aba2b8644936af9) #26
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit: ; preds = %bb5, %bb2.i
  %_0.i = mul nuw i64 %_10, %_12
; call <core::alloc::layout::Layout>::align
  %_15 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCslb9dB7bEmfm_4i128(ptr align 8 %elem_layout) #22
; call <core::alloc::layout::Layout>::from_size_align_unchecked
  %4 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCslb9dB7bEmfm_4i128(i64 %_0.i, i64 %_15, ptr align 8 @alloc_17de00c3327446355700bd7db4b78ded) #22
  %layout.0 = extractvalue { i64, i64 } %4, 0
  %layout.1 = extractvalue { i64, i64 } %4, 1
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_19 = load ptr, ptr %5, align 8
; call <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
  %_18 = call ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCslb9dB7bEmfm_4i128(ptr %_19, ptr align 8 @alloc_b9419d44288097f84422e162822ba96e) #22
  store ptr %_18, ptr %_17, align 8
  %6 = getelementptr inbounds i8, ptr %_17, i64 8
  store i64 %layout.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %layout.1, ptr %7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_17, i64 24, i1 false)
  br label %bb12

bb12:                                             ; preds = %bb4, %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit
  ret void
}

; <alloc::raw_vec::RawVecInner>::set_ptr_and_cap
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15set_ptr_and_capCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %ptr.0, i64 %ptr.1, i64 %cap) unnamed_addr #0 !guid !279 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_5 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECslb9dB7bEmfm_4i128(ptr %ptr.0, i64 %ptr.1) #22
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_4 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCslb9dB7bEmfm_4i128(ptr %_5) #22
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_4, ptr %0, align 8
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_6 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCslb9dB7bEmfm_4i128(i64 %cap) #22
  store i64 %_6, ptr %self, align 8
  ret void
}

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCslb9dB7bEmfm_4i128(i64 %align) unnamed_addr #0 personality ptr @rust_eh_personality !guid !280 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCslb9dB7bEmfm_4i128(i64 %align) #22
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_4 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCslb9dB7bEmfm_4i128(i64 %_5) #22
  br label %bb2

bb2:                                              ; preds = %bb1
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %ptr = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCslb9dB7bEmfm_4i128(ptr %_4) #22
  br label %bb3

bb3:                                              ; preds = %bb2
  %0 = insertvalue { i64, ptr } { i64 0, ptr poison }, ptr %ptr, 1
  ret { i64, ptr } %0

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 !guid !281 {
start:
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_5 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1) #22
  br i1 %_5, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
  call void @_RINvNvMs2_NtCs7CppTae75M1_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %len, i64 %additional, i64 %elem_layout.0, i64 %elem_layout.1)
  br label %bb3
}

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %elem_size) unnamed_addr #0 !guid !282 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 %elem_size, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCslb9dB7bEmfm_4i128(i64 %_4) #22
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <i128>::rem_euclid
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10rem_euclidCslb9dB7bEmfm_4i128(i128 %self, i128 %rhs, ptr align 8 %0) unnamed_addr #0 !guid !283 {
start:
  %_0 = alloca [16 x i8], align 16
  %_4 = icmp eq i128 %rhs, 0
  br i1 %_4, label %panic, label %bb1

bb1:                                              ; preds = %start
  %_5 = icmp eq i128 %rhs, -1
  %_6 = icmp eq i128 %self, -170141183460469231731687303715884105728
  %_7 = and i1 %_5, %_6
  br i1 %_7, label %panic1, label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 %0) #28
  unreachable

bb2:                                              ; preds = %bb1
  %r = srem i128 %self, %rhs
  %_8 = icmp slt i128 %r, 0
  br i1 %_8, label %bb3, label %bb5

panic1:                                           ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 %0) #28
  unreachable

bb5:                                              ; preds = %bb2
  store i128 %r, ptr %_0, align 16
  br label %bb6

bb3:                                              ; preds = %bb2
; call <i128>::wrapping_abs
  %_9 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCslb9dB7bEmfm_4i128(i128 %rhs) #22
  %_0.i = add i128 %r, %_9
  store i128 %_0.i, ptr %_0, align 16
  br label %bb6

bb6:                                              ; preds = %bb3, %bb5
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; <i128>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10strict_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !284 {
start:
  %_3 = alloca [32 x i8], align 16
; call <i128>::checked_pow
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_3, i128 %self, i32 %exp) #22
  %1 = load i128, ptr %_3, align 16
  %2 = getelementptr inbounds i8, ptr %_3, i64 16
  %3 = load i128, ptr %2, align 16
  %_4 = trunc i128 %1 to i64
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %_3, i64 16
  %x = load i128, ptr %5, align 16
  ret i128 %x

bb3:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #24
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i128>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_addCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !285 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.sadd.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <i128>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !286 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <i128>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !287 {
start:
  %_57 = alloca [32 x i8], align 16
  %_48 = alloca [32 x i8], align 16
  %_38 = alloca [32 x i8], align 16
  %_32 = alloca [32 x i8], align 16
  %_13 = alloca [8 x i8], align 4
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  %_6 = load i128, ptr %base, align 16
  %_5 = call i1 @llvm.is.constant.i128(i128 %_6)
  br i1 %_5, label %bb2, label %bb16

bb16:                                             ; preds = %bb2, %start
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp eq i32 %_24, 0
  br i1 %_23, label %bb17, label %bb18

bb2:                                              ; preds = %start
  %_9 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_8 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_9) #22
  %1 = call i128 @llvm.ctpop.i128(i128 %_8)
  %_0.i.i = trunc i128 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb16

bb5:                                              ; preds = %bb2
  %_12 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_11 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_12) #22
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %_11, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #22
  %_14 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %k, i32 %_14) #22
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_13, align 4
  %5 = getelementptr inbounds i8, ptr %_13, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_13, align 4
  %7 = getelementptr inbounds i8, ptr %_13, i64 4
  %8 = load i32, ptr %7, align 4
  %_15 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_15 to i1
  br i1 %9, label %bb11, label %bb10

bb18:                                             ; preds = %bb16
  %_26 = load i32, ptr %exp, align 4
  %_25 = call i1 @llvm.is.constant.i32(i32 %_26)
  br i1 %_25, label %bb20, label %bb32

bb17:                                             ; preds = %bb16
  %10 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 1, ptr %10, align 16
  store i128 1, ptr %_0, align 16
  br label %bb43

bb32:                                             ; preds = %bb42, %bb18
  %_47 = load i32, ptr %exp, align 4
  %_46 = and i32 %_47, 1
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb33, label %bb38

bb20:                                             ; preds = %bb30, %bb18
  %_28 = load i32, ptr %exp, align 4
  %_27 = icmp ugt i32 %_28, 1
  br i1 %_27, label %bb21, label %bb31

bb38:                                             ; preds = %bb36, %bb32
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_58 = load i128, ptr %base, align 16
  %_59 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_57, i128 %_58, i128 %_59) #22
  %13 = load i128, ptr %_57, align 16
  %14 = getelementptr inbounds i8, ptr %_57, i64 16
  %15 = load i128, ptr %14, align 16
  %_60 = trunc i128 %13 to i64
  %16 = trunc nuw i64 %_60 to i1
  br i1 %16, label %bb42, label %bb41

bb33:                                             ; preds = %bb32
  %_49 = load i128, ptr %acc, align 16
  %_50 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_48, i128 %_49, i128 %_50) #22
  %17 = load i128, ptr %_48, align 16
  %18 = getelementptr inbounds i8, ptr %_48, i64 16
  %19 = load i128, ptr %18, align 16
  %_51 = trunc i128 %17 to i64
  %20 = trunc nuw i64 %_51 to i1
  br i1 %20, label %bb36, label %bb35

bb36:                                             ; preds = %bb33
  %21 = getelementptr inbounds i8, ptr %_48, i64 16
  %x = load i128, ptr %21, align 16
  store i128 %x, ptr %acc, align 16
  %_54 = load i32, ptr %exp, align 4
  %_53 = icmp eq i32 %_54, 1
  br i1 %_53, label %bb37, label %bb38

bb35:                                             ; preds = %bb33
  store i128 0, ptr %_0, align 16
  br label %bb43

bb43:                                             ; preds = %bb14, %bb15, %bb10, %bb17, %bb29, %bb24, %bb31, %bb37, %bb41, %bb35
  ret void

bb37:                                             ; preds = %bb36
  %_55 = load i128, ptr %acc, align 16
  %22 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_55, ptr %22, align 16
  store i128 1, ptr %_0, align 16
  br label %bb43

bb42:                                             ; preds = %bb38
  %23 = getelementptr inbounds i8, ptr %_57, i64 16
  %x1 = load i128, ptr %23, align 16
  store i128 %x1, ptr %base, align 16
  br label %bb32

bb41:                                             ; preds = %bb38
  store i128 0, ptr %_0, align 16
  br label %bb43

bb31:                                             ; preds = %bb20
  %_43 = load i128, ptr %acc, align 16
  %_44 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %_43, i128 %_44) #22
  br label %bb43

bb21:                                             ; preds = %bb20
  %_31 = load i32, ptr %exp, align 4
  %_30 = and i32 %_31, 1
  %_29 = icmp eq i32 %_30, 1
  br i1 %_29, label %bb22, label %bb26

bb26:                                             ; preds = %bb25, %bb21
  %24 = load i32, ptr %exp, align 4
  %25 = udiv i32 %24, 2
  store i32 %25, ptr %exp, align 4
  %_39 = load i128, ptr %base, align 16
  %_40 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_38, i128 %_39, i128 %_40) #22
  %26 = load i128, ptr %_38, align 16
  %27 = getelementptr inbounds i8, ptr %_38, i64 16
  %28 = load i128, ptr %27, align 16
  %_41 = trunc i128 %26 to i64
  %29 = trunc nuw i64 %_41 to i1
  br i1 %29, label %bb30, label %bb29

bb22:                                             ; preds = %bb21
  %_33 = load i128, ptr %acc, align 16
  %_34 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_32, i128 %_33, i128 %_34) #22
  %30 = load i128, ptr %_32, align 16
  %31 = getelementptr inbounds i8, ptr %_32, i64 16
  %32 = load i128, ptr %31, align 16
  %_35 = trunc i128 %30 to i64
  %33 = trunc nuw i64 %_35 to i1
  br i1 %33, label %bb25, label %bb24

bb25:                                             ; preds = %bb22
  %34 = getelementptr inbounds i8, ptr %_32, i64 16
  %x2 = load i128, ptr %34, align 16
  store i128 %x2, ptr %acc, align 16
  br label %bb26

bb24:                                             ; preds = %bb22
  store i128 0, ptr %_0, align 16
  br label %bb43

bb30:                                             ; preds = %bb26
  %35 = getelementptr inbounds i8, ptr %_38, i64 16
  %x3 = load i128, ptr %35, align 16
  store i128 %x3, ptr %base, align 16
  br label %bb20

bb29:                                             ; preds = %bb26
  store i128 0, ptr %_0, align 16
  br label %bb43

bb11:                                             ; preds = %bb5
  %36 = getelementptr inbounds i8, ptr %_13, i64 4
  %shift = load i32, ptr %36, align 4
  %_18 = load i128, ptr %base, align 16
  %_17 = icmp slt i128 %_18, 0
  br i1 %_17, label %bb12, label %bb15

bb10:                                             ; preds = %bb5
  store i128 0, ptr %_0, align 16
  br label %bb43

bb15:                                             ; preds = %bb12, %bb11
; call <i128>::shl_exact
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 1, i32 %shift) #22
  br label %bb43

bb12:                                             ; preds = %bb11
  %_21 = load i32, ptr %exp, align 4
  %_20 = urem i32 %_21, 2
  %_19 = icmp eq i32 %_20, 1
  br i1 %_19, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
; call <i128>::shl_exact
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 -1, i32 %shift) #22
  br label %bb43

bb9:                                              ; No predecessors!
  unreachable
}

; <i128>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !288 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.ssub.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <i128>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !289 {
start:
; call <i128>::wrapping_abs
  %_2 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCslb9dB7bEmfm_4i128(i128 %self) #22
  ret i128 %_2
}

; <i128>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !290 {
start:
  %_0 = alloca [16 x i8], align 16
  %_0.i = icmp slt i128 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i128 %self, ptr %_0, align 16
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i128 0, %self
  store i128 %_0.i2, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; <i128>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !291 {
start:
  %0 = alloca [32 x i8], align 16
; call <i128>::overflowing_pow
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn15overflowing_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %0, i128 %self, i32 %exp) #22
  %_3.0 = load i128, ptr %0, align 16
  %1 = getelementptr inbounds i8, ptr %0, i64 16
  %2 = load i8, ptr %1, align 16
  %_3.1 = trunc nuw i8 %2 to i1
  ret i128 %_3.0
}

; <i128>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unbounded_shlCslb9dB7bEmfm_4i128(i128 %self, i32 %rhs) unnamed_addr #0 !guid !292 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp ult i32 %rhs, 128
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <i128>::unchecked_shl::precondition_check
  call void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #26
  br label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i128
  %_0.i = shl i128 %self, %0
  store i128 %_0.i, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit, %bb2
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; <i128>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn15overflowing_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !293 {
start:
  %1 = alloca [32 x i8], align 16
  %2 = alloca [32 x i8], align 16
  %3 = alloca [32 x i8], align 16
  %4 = alloca [32 x i8], align 16
  %5 = alloca [32 x i8], align 16
  %_30 = alloca [32 x i8], align 16
  %base1 = alloca [16 x i8], align 16
  %_16 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  store i8 0, ptr %overflow, align 1
  %_8 = load i128, ptr %base, align 16
  %_7 = call i1 @llvm.is.constant.i128(i128 %_8)
  br i1 %_7, label %bb2, label %bb19

bb19:                                             ; preds = %bb2, %start
  %_33 = load i32, ptr %exp, align 4
  %_32 = icmp eq i32 %_33, 0
  br i1 %_32, label %bb20, label %bb21

bb2:                                              ; preds = %start
  %_11 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_10 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_11) #22
  %6 = call i128 @llvm.ctpop.i128(i128 %_10)
  %_0.i.i = trunc i128 %6 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb19

bb5:                                              ; preds = %bb2
  %_14 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_13 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_14) #22
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %_13, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #22
  %_17 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %7 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %k, i32 %_17) #22
  %8 = extractvalue { i32, i32 } %7, 0
  %9 = extractvalue { i32, i32 } %7, 1
  store i32 %8, ptr %_16, align 4
  %10 = getelementptr inbounds i8, ptr %_16, i64 4
  store i32 %9, ptr %10, align 4
  %11 = load i32, ptr %_16, align 4
  %12 = getelementptr inbounds i8, ptr %_16, i64 4
  %13 = load i32, ptr %12, align 4
  %_18 = zext i32 %11 to i64
  %14 = trunc nuw i64 %_18 to i1
  br i1 %14, label %bb9, label %bb10

bb21:                                             ; preds = %bb19
  %_35 = load i32, ptr %exp, align 4
  %_34 = call i1 @llvm.is.constant.i32(i32 %_35)
  br i1 %_34, label %bb23, label %bb32

bb20:                                             ; preds = %bb19
  store i128 1, ptr %_0, align 16
  %15 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 0, ptr %15, align 16
  br label %bb39

bb32:                                             ; preds = %bb36, %bb21
  %_64 = load i32, ptr %exp, align 4
  %_63 = and i32 %_64, 1
  %_62 = icmp eq i32 %_63, 1
  br i1 %_62, label %bb33, label %bb36

bb23:                                             ; preds = %bb27, %bb21
  %_37 = load i32, ptr %exp, align 4
  %_36 = icmp ugt i32 %_37, 1
  br i1 %_36, label %bb24, label %bb30

bb36:                                             ; preds = %bb33, %bb32
  %16 = load i32, ptr %exp, align 4
  %17 = udiv i32 %16, 2
  store i32 %17, ptr %exp, align 4
  %_79 = load i128, ptr %base, align 16
  %_80 = load i128, ptr %base, align 16
  %18 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_79, i128 %_80)
  %_5.0.i6 = extractvalue { i128, i1 } %18, 0
  %_5.1.i7 = extractvalue { i128, i1 } %18, 1
  store i128 %_5.0.i6, ptr %4, align 16
  %19 = getelementptr inbounds i8, ptr %4, i64 16
  %20 = zext i1 %_5.1.i7 to i8
  store i8 %20, ptr %19, align 16
  %_78.0 = load i128, ptr %4, align 16
  %21 = getelementptr inbounds i8, ptr %4, i64 16
  %22 = load i8, ptr %21, align 16
  %_78.1 = trunc nuw i8 %22 to i1
  store i128 %_78.0, ptr %base, align 16
  %23 = zext i1 %_78.1 to i8
  store i8 %23, ptr %tmp_overflow, align 1
  %24 = load i8, ptr %tmp_overflow, align 1
  %_81 = trunc nuw i8 %24 to i1
  %25 = load i8, ptr %overflow, align 1
  %26 = trunc nuw i8 %25 to i1
  %27 = or i1 %26, %_81
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %overflow, align 1
  br label %bb32

bb33:                                             ; preds = %bb32
  %_68 = load i128, ptr %acc, align 16
  %_69 = load i128, ptr %base, align 16
  %29 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_68, i128 %_69)
  %_5.0.i8 = extractvalue { i128, i1 } %29, 0
  %_5.1.i9 = extractvalue { i128, i1 } %29, 1
  store i128 %_5.0.i8, ptr %5, align 16
  %30 = getelementptr inbounds i8, ptr %5, i64 16
  %31 = zext i1 %_5.1.i9 to i8
  store i8 %31, ptr %30, align 16
  %_67.0 = load i128, ptr %5, align 16
  %32 = getelementptr inbounds i8, ptr %5, i64 16
  %33 = load i8, ptr %32, align 16
  %_67.1 = trunc nuw i8 %33 to i1
  store i128 %_67.0, ptr %acc, align 16
  %34 = zext i1 %_67.1 to i8
  store i8 %34, ptr %tmp_overflow, align 1
  %35 = load i8, ptr %tmp_overflow, align 1
  %_70 = trunc nuw i8 %35 to i1
  %36 = load i8, ptr %overflow, align 1
  %37 = trunc nuw i8 %36 to i1
  %38 = or i1 %37, %_70
  %39 = zext i1 %38 to i8
  store i8 %39, ptr %overflow, align 1
  %_72 = load i32, ptr %exp, align 4
  %_71 = icmp eq i32 %_72, 1
  br i1 %_71, label %bb35, label %bb36

bb35:                                             ; preds = %bb33
  %_73 = load i128, ptr %acc, align 16
  %40 = load i8, ptr %overflow, align 1
  %_74 = trunc nuw i8 %40 to i1
  store i128 %_73, ptr %_0, align 16
  %41 = getelementptr inbounds i8, ptr %_0, i64 16
  %42 = zext i1 %_74 to i8
  store i8 %42, ptr %41, align 16
  br label %bb39

bb39:                                             ; preds = %bb10, %bb15, %bb20, %bb30, %bb35
  ret void

bb30:                                             ; preds = %bb23
  %_57 = load i128, ptr %acc, align 16
  %_58 = load i128, ptr %base, align 16
  %43 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_57, i128 %_58)
  %_5.0.i4 = extractvalue { i128, i1 } %43, 0
  %_5.1.i5 = extractvalue { i128, i1 } %43, 1
  store i128 %_5.0.i4, ptr %3, align 16
  %44 = getelementptr inbounds i8, ptr %3, i64 16
  %45 = zext i1 %_5.1.i5 to i8
  store i8 %45, ptr %44, align 16
  %_56.0 = load i128, ptr %3, align 16
  %46 = getelementptr inbounds i8, ptr %3, i64 16
  %47 = load i8, ptr %46, align 16
  %_56.1 = trunc nuw i8 %47 to i1
  store i128 %_56.0, ptr %acc, align 16
  %48 = zext i1 %_56.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_59 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_59
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  %_60 = load i128, ptr %acc, align 16
  %54 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %54 to i1
  store i128 %_60, ptr %_0, align 16
  %55 = getelementptr inbounds i8, ptr %_0, i64 16
  %56 = zext i1 %_61 to i8
  store i8 %56, ptr %55, align 16
  br label %bb39

bb24:                                             ; preds = %bb23
  %_40 = load i32, ptr %exp, align 4
  %_39 = and i32 %_40, 1
  %_38 = icmp eq i32 %_39, 1
  br i1 %_38, label %bb25, label %bb27

bb27:                                             ; preds = %bb25, %bb24
  %57 = load i32, ptr %exp, align 4
  %58 = udiv i32 %57, 2
  store i32 %58, ptr %exp, align 4
  %_51 = load i128, ptr %base, align 16
  %_52 = load i128, ptr %base, align 16
  %59 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_51, i128 %_52)
  %_5.0.i = extractvalue { i128, i1 } %59, 0
  %_5.1.i = extractvalue { i128, i1 } %59, 1
  store i128 %_5.0.i, ptr %1, align 16
  %60 = getelementptr inbounds i8, ptr %1, i64 16
  %61 = zext i1 %_5.1.i to i8
  store i8 %61, ptr %60, align 16
  %_50.0 = load i128, ptr %1, align 16
  %62 = getelementptr inbounds i8, ptr %1, i64 16
  %63 = load i8, ptr %62, align 16
  %_50.1 = trunc nuw i8 %63 to i1
  store i128 %_50.0, ptr %base, align 16
  %64 = zext i1 %_50.1 to i8
  store i8 %64, ptr %tmp_overflow, align 1
  %65 = load i8, ptr %tmp_overflow, align 1
  %_53 = trunc nuw i8 %65 to i1
  %66 = load i8, ptr %overflow, align 1
  %67 = trunc nuw i8 %66 to i1
  %68 = or i1 %67, %_53
  %69 = zext i1 %68 to i8
  store i8 %69, ptr %overflow, align 1
  br label %bb23

bb25:                                             ; preds = %bb24
  %_44 = load i128, ptr %acc, align 16
  %_45 = load i128, ptr %base, align 16
  %70 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_44, i128 %_45)
  %_5.0.i2 = extractvalue { i128, i1 } %70, 0
  %_5.1.i3 = extractvalue { i128, i1 } %70, 1
  store i128 %_5.0.i2, ptr %2, align 16
  %71 = getelementptr inbounds i8, ptr %2, i64 16
  %72 = zext i1 %_5.1.i3 to i8
  store i8 %72, ptr %71, align 16
  %_43.0 = load i128, ptr %2, align 16
  %73 = getelementptr inbounds i8, ptr %2, i64 16
  %74 = load i8, ptr %73, align 16
  %_43.1 = trunc nuw i8 %74 to i1
  store i128 %_43.0, ptr %acc, align 16
  %75 = zext i1 %_43.1 to i8
  store i8 %75, ptr %tmp_overflow, align 1
  %76 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %76 to i1
  %77 = load i8, ptr %overflow, align 1
  %78 = trunc nuw i8 %77 to i1
  %79 = or i1 %78, %_46
  %80 = zext i1 %79 to i8
  store i8 %80, ptr %overflow, align 1
  br label %bb27

bb9:                                              ; preds = %bb5
  %81 = getelementptr inbounds i8, ptr %_16, i64 4
  %shift = load i32, ptr %81, align 4
  %_21 = load i128, ptr %base, align 16
  %_20 = icmp slt i128 %_21, 0
  br i1 %_20, label %bb11, label %bb14

bb10:                                             ; preds = %bb5
  store i128 0, ptr %_0, align 16
  %82 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 1, ptr %82, align 16
  br label %bb39

bb14:                                             ; preds = %bb11, %bb9
  store i128 1, ptr %base1, align 16
  br label %bb15

bb11:                                             ; preds = %bb9
  %_24 = load i32, ptr %exp, align 4
  %_23 = urem i32 %_24, 2
  %_22 = icmp ne i32 %_23, 0
  br i1 %_22, label %bb13, label %bb14

bb13:                                             ; preds = %bb11
  store i128 -1, ptr %base1, align 16
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_27 = load i128, ptr %base1, align 16
; call <i128>::unbounded_shl
  %_26 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unbounded_shlCslb9dB7bEmfm_4i128(i128 %_27, i32 %shift) #22
  %_31 = load i128, ptr %base1, align 16
; call <i128>::shl_exact
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_30, i128 %_31, i32 %shift) #22
; call <core::option::Option<i128>>::is_none
  %_28 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_noneCslb9dB7bEmfm_4i128(ptr align 16 %_30) #22
  store i128 %_26, ptr %_0, align 16
  %83 = getelementptr inbounds i8, ptr %_0, i64 16
  %84 = zext i1 %_28 to i8
  store i8 %84, ptr %83, align 16
  br label %bb39

bb40:                                             ; No predecessors!
  unreachable
}

; <i128>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn3powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !294 {
start:
  %_0 = alloca [16 x i8], align 16
  br label %bb1

bb1:                                              ; preds = %start
; call <i128>::strict_pow
  %0 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10strict_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #22
  store i128 %0, ptr %_0, align 16
  br label %bb3

bb2:                                              ; No predecessors!
; call <i128>::wrapping_pow
  %1 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) #22
  store i128 %1, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i128, ptr %_0, align 16
  ret i128 %2
}

; <i128>::shl_exact
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %rhs) unnamed_addr #0 !guid !295 {
start:
  %0 = call i128 @llvm.ctlz.i128(i128 %self, i1 false)
  %_0.i4 = trunc i128 %0 to i32
  %_3 = icmp ult i32 %rhs, %_0.i4
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_2.i = xor i128 %self, -1
  %1 = call i128 @llvm.ctlz.i128(i128 %_2.i, i1 false)
  %_0.i = trunc i128 %1 to i32
  %_5 = icmp ult i32 %rhs, %_0.i
  br i1 %_5, label %bb4, label %bb6

bb4:                                              ; preds = %bb2, %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

bb2.i:                                            ; preds = %bb4
; call <i128>::unchecked_shl::precondition_check
  call void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #26
  br label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit: ; preds = %bb4, %bb2.i
  %2 = zext i32 %rhs to i128
  %_0.i2 = shl i128 %self, %2
  %3 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_0.i2, ptr %3, align 16
  store i128 1, ptr %_0, align 16
  br label %bb7

bb6:                                              ; preds = %bb2
  store i128 0, ptr %_0, align 16
  br label %bb7

bb7:                                              ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit, %bb6
  ret void
}

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCslb9dB7bEmfm_4i128(ptr %self, i64 %len) unnamed_addr #0 !guid !296 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
  %0 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCslb9dB7bEmfm_4i128(ptr %self, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #1 !guid !297 {
start:
  %_3 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #22
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %ptr = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %layout.0 = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %layout.1 = load i64, ptr %5, align 8
  %_9 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCslb9dB7bEmfm_4i128(ptr %_9, ptr %ptr, i64 %layout.0, i64 %layout.1) #22
  br label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCslb9dB7bEmfm_4i128(i64 %capacity) unnamed_addr #0 !guid !298 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCslb9dB7bEmfm_4i128(i64 %capacity, i64 1, i64 1) #22
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !299 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCslb9dB7bEmfm_4i128(ptr %s.0, i64 %s.1) #22
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !300 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
  %_2 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) #22
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !301 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_0 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) #22
  ret ptr %_0
}

; <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCslb9dB7bEmfm_4i128(ptr %data, i64 %len) unnamed_addr #0 !guid !302 {
start:
; call <*mut u8>::cast_slice
  %0 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCslb9dB7bEmfm_4i128(ptr %data, i64 %len) #22
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCslb9dB7bEmfm_4i128(ptr %_3.0, i64 %_3.1, ptr align 8 @alloc_af3623564924928dd3d563c9d84a8a0e) #22
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::slice::iter::Iter<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE3newCslb9dB7bEmfm_4i128(ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !303 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[u8]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE8from_refCslb9dB7bEmfm_4i128(ptr %slice.0, i64 %slice.1) #22
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECslb9dB7bEmfm_4i128(ptr %_4.0, i64 %_4.1) #22
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i8, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE8as_sliceCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !304 {
start:
  %_5.i = alloca [8 x i8], align 8
  %_4.i = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_9.i = load ptr, ptr %0, align 8
  %_10.i = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedCslb9dB7bEmfm_4i128(ptr %_9.i, ptr %_10.i) #22
  store i64 %1, ptr %_5.i, align 8
  %2 = load i64, ptr %_5.i, align 8
; call core::slice::raw::from_raw_parts::<u8>
  %3 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECslb9dB7bEmfm_4i128(ptr %_4.i, i64 %2, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #22
  %_0.0.i = extractvalue { ptr, i64 } %3, 0
  %_0.1.i = extractvalue { ptr, i64 } %3, 1
  %_0.0 = extractvalue { ptr, i64 } %3, 0
  %_0.1 = extractvalue { ptr, i64 } %3, 1
  %4 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_0.1, 1
  ret { ptr, i64 } %5
}

; <alloc::raw_vec::RawVecInner>::finish_grow
; Function Attrs: cold nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner11finish_growCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %cap, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #4 !guid !305 {
start:
  %old_layout = alloca [16 x i8], align 8
  %_11 = alloca [24 x i8], align 8
  %memory = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %new_layout = alloca [16 x i8], align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_6, i64 %cap, i64 %elem_layout.0, i64 %elem_layout.1) #22
; call <core::result::Result<core::alloc::layout::Layout, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtB7_5alloc6layout6LayoutNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %_6) #22
  %_7 = load i64, ptr %_5, align 8
  %0 = trunc nuw i64 %_7 to i1
  br i1 %0, label %bb5, label %bb4

bb5:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_5, i64 8
  %residual.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %residual.1 = load i64, ptr %2, align 8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
  call void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %residual.0, i64 %residual.1, ptr align 8 @alloc_9c2bc03755f157121052fe1398e358d1) #22
  br label %bb13

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  %val.0 = load i64, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  %val.1 = load i64, ptr %4, align 8
  store i64 %val.0, ptr %new_layout, align 8
  %5 = getelementptr inbounds i8, ptr %new_layout, i64 8
  store i64 %val.1, ptr %5, align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_11, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #22
  %6 = getelementptr inbounds i8, ptr %_11, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = icmp eq i64 %7, 0
  %_12 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_12 to i1
  br i1 %9, label %bb7, label %bb11

bb7:                                              ; preds = %bb4
  %ptr = load ptr, ptr %_11, align 8
  %10 = getelementptr inbounds i8, ptr %_11, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = getelementptr inbounds i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  store i64 %11, ptr %old_layout, align 8
  %14 = getelementptr inbounds i8, ptr %old_layout, i64 8
  store i64 %13, ptr %14, align 8
; call <core::alloc::layout::Layout>::align
  %_17 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCslb9dB7bEmfm_4i128(ptr align 8 %old_layout) #22
; call <core::alloc::layout::Layout>::align
  %_19 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCslb9dB7bEmfm_4i128(ptr align 8 %new_layout) #22
  %_16 = icmp eq i64 %_17, %_19
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb7
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCslb9dB7bEmfm_4i128(i1 zeroext %_16, ptr align 8 @alloc_02ed5979549ad728dcb1e213f787b0ae) #26
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb7, %bb2.i
  %_21 = getelementptr inbounds i8, ptr %self, i64 16
  %15 = load i64, ptr %old_layout, align 8
  %16 = getelementptr inbounds i8, ptr %old_layout, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = load i64, ptr %new_layout, align 8
  %19 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %20 = load i64, ptr %19, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::grow
  %21 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator4growCslb9dB7bEmfm_4i128(ptr %_21, ptr %ptr, i64 %15, i64 %17, i64 %18, i64 %20) #22
  %22 = extractvalue { ptr, i64 } %21, 0
  %23 = extractvalue { ptr, i64 } %21, 1
  store ptr %22, ptr %memory, align 8
  %24 = getelementptr inbounds i8, ptr %memory, i64 8
  store i64 %23, ptr %24, align 8
  br label %bb12

bb11:                                             ; preds = %bb4
  %_22 = getelementptr inbounds i8, ptr %self, i64 16
  %25 = load i64, ptr %new_layout, align 8
  %26 = getelementptr inbounds i8, ptr %new_layout, i64 8
  %27 = load i64, ptr %26, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %28 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCslb9dB7bEmfm_4i128(ptr %_22, i64 %25, i64 %27) #22
  %29 = extractvalue { ptr, i64 } %28, 0
  %30 = extractvalue { ptr, i64 } %28, 1
  store ptr %29, ptr %memory, align 8
  %31 = getelementptr inbounds i8, ptr %memory, i64 8
  store i64 %30, ptr %31, align 8
  br label %bb12

bb12:                                             ; preds = %bb11, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_23.0 = load ptr, ptr %memory, align 8
  %32 = getelementptr inbounds i8, ptr %memory, i64 8
  %_23.1 = load i64, ptr %32, align 8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError>>::map_err::<alloc::collections::TryReserveError, <alloc::raw_vec::RawVecInner>::finish_grow::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtNtB5_3ptr8non_null7NonNullShENtNtB5_5alloc10AllocErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvMs5_NtB1S_7raw_vecNtB2O_11RawVecInner11finish_grow0ECslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr %_23.0, i64 %_23.1, ptr align 8 %new_layout) #22
  br label %bb13

bb13:                                             ; preds = %bb5, %bb12
  ret void

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::grow_amortized
; Function Attrs: nonlazybind uwtable
define internal { i64, i64 } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #1 !guid !306 {
start:
  %_26 = alloca [24 x i8], align 8
  %_25 = alloca [24 x i8], align 8
  %_11 = alloca [16 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %elem_layout) #22
  %_5 = icmp eq i64 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; call <usize>::checked_add
  %3 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCslb9dB7bEmfm_4i128(i64 %len, i64 %additional) #22
  %_12.0 = extractvalue { i64, i64 } %3, 0
  %_12.1 = extractvalue { i64, i64 } %3, 1
; call <core::option::Option<usize>>::ok_or::<alloc::collections::TryReserveErrorKind>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE5ok_orNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_11, i64 %_12.0, i64 %_12.1, i64 0, i64 undef) #22
; call <core::result::Result<usize, alloc::collections::TryReserveErrorKind> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultjNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_10, ptr align 8 %_11) #22
  %4 = load i64, ptr %_10, align 8
  %5 = icmp eq i64 %4, -1
  %_14 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_14 to i1
  br i1 %6, label %bb10, label %bb9

bb2:                                              ; preds = %start
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCslb9dB7bEmfm_4i128(i64 0, i64 undef, ptr align 8 @alloc_289c68237f406b28ee6ba245eefcd312) #22
  %_8.0 = extractvalue { i64, i64 } %7, 0
  %_8.1 = extractvalue { i64, i64 } %7, 1
  store i64 %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8.1, ptr %8, align 8
  br label %bb21

bb10:                                             ; preds = %bb4
  %residual.02 = load i64, ptr %_10, align 8
  %9 = getelementptr inbounds i8, ptr %_10, i64 8
  %residual.13 = load i64, ptr %9, align 8
; call <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveErrorKind>>>::from_residual
  %10 = call { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtBN_19TryReserveErrorKindEE13from_residualCslb9dB7bEmfm_4i128(i64 %residual.02, i64 %residual.13, ptr align 8 @alloc_91dabd4c1d2514ecf79277c06422ef65) #22
  %11 = extractvalue { i64, i64 } %10, 0
  %12 = extractvalue { i64, i64 } %10, 1
  store i64 %11, ptr %_0, align 8
  %13 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %12, ptr %13, align 8
  br label %bb21

bb9:                                              ; preds = %bb4
  %14 = getelementptr inbounds i8, ptr %_10, i64 8
  %required_cap = load i64, ptr %14, align 8
  %_20 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_19 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCslb9dB7bEmfm_4i128(i64 %_20) #22
  %_18 = mul i64 %_19, 2
; call core::cmp::max::<usize>
  %cap = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECslb9dB7bEmfm_4i128(i64 %_18, i64 %required_cap) #22
; call <core::alloc::layout::Layout>::size
  %_23 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %elem_layout) #22
; call alloc::raw_vec::min_non_zero_cap
  %_22 = call i64 @_RNvNtCs7CppTae75M1_5alloc7raw_vec16min_non_zero_cap(i64 %_23)
; call core::cmp::max::<usize>
  %cap1 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjECslb9dB7bEmfm_4i128(i64 %_22, i64 %cap) #22
  %15 = load i64, ptr %elem_layout, align 8
  %16 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %17 = load i64, ptr %16, align 8
; call <alloc::raw_vec::RawVecInner>::finish_grow
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner11finish_growCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_26, ptr align 8 %self, i64 %cap1, i64 %15, i64 %17)
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
  call void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_25, ptr align 8 %_26) #22
  %_28 = load i64, ptr %_25, align 8
  %18 = trunc nuw i64 %_28 to i1
  br i1 %18, label %bb19, label %bb18

bb19:                                             ; preds = %bb9
  %19 = getelementptr inbounds i8, ptr %_25, i64 8
  %residual.0 = load i64, ptr %19, align 8
  %20 = getelementptr inbounds i8, ptr %19, i64 8
  %residual.1 = load i64, ptr %20, align 8
; call <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
  %21 = call { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslb9dB7bEmfm_4i128(i64 %residual.0, i64 %residual.1, ptr align 8 @alloc_8b924c2e6c70ef47ed23cadbb79c2da4) #22
  %22 = extractvalue { i64, i64 } %21, 0
  %23 = extractvalue { i64, i64 } %21, 1
  store i64 %22, ptr %_0, align 8
  %24 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %23, ptr %24, align 8
  br label %bb21

bb18:                                             ; preds = %bb9
  %25 = getelementptr inbounds i8, ptr %_25, i64 8
  %ptr.0 = load ptr, ptr %25, align 8
  %26 = getelementptr inbounds i8, ptr %25, i64 8
  %ptr.1 = load i64, ptr %26, align 8
; call <alloc::raw_vec::RawVecInner>::set_ptr_and_cap
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15set_ptr_and_capCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %ptr.0, i64 %ptr.1, i64 %cap1) #22
  store i64 -1, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb2, %bb10, %bb19, %bb18
  %27 = load i64, ptr %_0, align 8
  %28 = getelementptr inbounds i8, ptr %_0, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { i64, i64 } poison, i64 %27, 0
  %31 = insertvalue { i64, i64 } %30, i64 %29, 1
  ret { i64, i64 } %31

bb8:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::try_allocate_in
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %capacity, i1 zeroext %init, i64 %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !307 {
start:
  %_32 = alloca [1 x i8], align 1
  %_31 = alloca [1 x i8], align 1
  %result = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %layout = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  %alloc = alloca [0 x i8], align 1
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_31, align 1
  store i8 0, ptr %_32, align 1
  store i8 1, ptr %_31, align 1
  %3 = load i64, ptr %elem_layout, align 8
  %4 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_6, i64 %capacity, i64 %3, i64 %5) #22
  br label %bb1

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %_6, align 8
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCslb9dB7bEmfm_4i128(i64 0, i64 undef, ptr align 8 @alloc_099d793709fa470a3d5e7c79c938e035) #22
  %_9.0 = extractvalue { i64, i64 } %7, 0
  %_9.1 = extractvalue { i64, i64 } %7, 1
  br label %bb5

bb4:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %_6, i64 8
  %layout.0 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %layout.1 = load i64, ptr %9, align 8
  store i64 %layout.0, ptr %layout, align 8
  %10 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %layout.1, ptr %10, align 8
; call <core::alloc::layout::Layout>::size
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
  br label %bb6

bb6:                                              ; preds = %bb4
  %_11 = icmp eq i64 %_12, 0
  br i1 %_11, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  %_19 = zext i1 %init to i64
  %11 = trunc nuw i64 %_19 to i1
  br i1 %11, label %bb11, label %bb12

bb7:                                              ; preds = %bb6
  store i8 0, ptr %_31, align 1
  store i8 1, ptr %_32, align 1
; call <core::alloc::layout::Layout>::alignment
  %_16 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCslb9dB7bEmfm_4i128(ptr align 8 %elem_layout) #22
  br label %bb8

bb11:                                             ; preds = %bb10
  %12 = load i64, ptr %layout, align 8
  %13 = getelementptr inbounds i8, ptr %layout, i64 8
  %14 = load i64, ptr %13, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
  %15 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCslb9dB7bEmfm_4i128(ptr %alloc, i64 %12, i64 %14) #22
  %16 = extractvalue { ptr, i64 } %15, 0
  %17 = extractvalue { ptr, i64 } %15, 1
  store ptr %16, ptr %result, align 8
  %18 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb28

bb12:                                             ; preds = %bb10
  %19 = load i64, ptr %layout, align 8
  %20 = getelementptr inbounds i8, ptr %layout, i64 8
  %21 = load i64, ptr %20, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %22 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCslb9dB7bEmfm_4i128(ptr %alloc, i64 %19, i64 %21) #22
  %23 = extractvalue { ptr, i64 } %22, 0
  %24 = extractvalue { ptr, i64 } %22, 1
  store ptr %23, ptr %result, align 8
  %25 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %24, ptr %25, align 8
  br label %bb29

bb29:                                             ; preds = %bb12
  br label %bb13

bb13:                                             ; preds = %bb28, %bb29
  %26 = load ptr, ptr %result, align 8
  %27 = getelementptr inbounds i8, ptr %result, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = ptrtoint ptr %26 to i64
  %30 = icmp eq i64 %29, 0
  %_22 = select i1 %30, i64 1, i64 0
  %31 = trunc nuw i64 %_22 to i1
  br i1 %31, label %bb14, label %bb15

bb28:                                             ; preds = %bb11
  br label %bb13

bb14:                                             ; preds = %bb13
  %_25.0 = load i64, ptr %layout, align 8
  %32 = getelementptr inbounds i8, ptr %layout, i64 8
  %_25.1 = load i64, ptr %32, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %33 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCslb9dB7bEmfm_4i128(i64 %_25.0, i64 %_25.1, ptr align 8 @alloc_33dfd402c6ecbe2e6a32e76edf5f31a5) #22
  %_24.0 = extractvalue { i64, i64 } %33, 0
  %_24.1 = extractvalue { i64, i64 } %33, 1
  br label %bb16

bb15:                                             ; preds = %bb13
  %ptr.0 = load ptr, ptr %result, align 8
  %34 = getelementptr inbounds i8, ptr %result, i64 8
  %ptr.1 = load i64, ptr %34, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_28 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECslb9dB7bEmfm_4i128(ptr %ptr.0, i64 %ptr.1) #22
  br label %bb17

bb17:                                             ; preds = %bb15
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_27 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCslb9dB7bEmfm_4i128(ptr %_28) #22
  br label %bb18

bb18:                                             ; preds = %bb17
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_29 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCslb9dB7bEmfm_4i128(i64 %capacity) #22
  br label %bb19

bb19:                                             ; preds = %bb18
  store i8 0, ptr %_31, align 1
  %35 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29, ptr %35, align 8
  %36 = getelementptr inbounds i8, ptr %35, i64 8
  store ptr %_27, ptr %36, align 8
  store i64 0, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb23, %bb20, %bb19
  ret void

bb16:                                             ; preds = %bb14
  %37 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_24.0, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %37, i64 8
  store i64 %_24.1, ptr %38, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb20:                                             ; preds = %bb5, %bb9, %bb16
  %39 = load i8, ptr %_31, align 1
  %40 = trunc nuw i8 %39 to i1
  br i1 %40, label %bb23, label %bb21

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_32, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %41 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCslb9dB7bEmfm_4i128(i64 %_16) #22
  %_14.0 = extractvalue { i64, ptr } %41, 0
  %_14.1 = extractvalue { i64, ptr } %41, 1
  br label %bb9

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_32, align 1
  %42 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_14.0, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %42, i64 8
  store ptr %_14.1, ptr %43, align 8
  store i64 0, ptr %_0, align 8
  br label %bb20

bb5:                                              ; preds = %bb3
  %44 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_9.0, ptr %44, align 8
  %45 = getelementptr inbounds i8, ptr %44, i64 8
  store i64 %_9.1, ptr %45, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb23:                                             ; preds = %bb20
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable

bb25:                                             ; No predecessors!
  unreachable

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCslb9dB7bEmfm_4i128(i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !308 {
start:
  %this = alloca [16 x i8], align 8
  %_4 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::try_allocate_in
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_4, i64 %capacity, i1 zeroext false, i64 %elem_layout.0, i64 %elem_layout.1)
  %_6 = load i64, ptr %_4, align 8
  %0 = trunc nuw i64 %_6 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  %err.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %err.1 = load i64, ptr %2, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #24
  unreachable

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load ptr, ptr %5, align 8
  store i64 %4, ptr %this, align 8
  %7 = getelementptr inbounds i8, ptr %this, i64 8
  store ptr %6, ptr %7, align 8
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_10 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCslb9dB7bEmfm_4i128(ptr align 8 %this, i64 0, i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) #22
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = xor i1 %_10, true
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb5
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCslb9dB7bEmfm_4i128(i1 zeroext %_9, ptr align 8 @alloc_51424262946dd0794fad6132df857999) #26
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb5, %bb2.i
  br label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_0.0 = load i64, ptr %this, align 8
  %8 = getelementptr inbounds i8, ptr %this, i64 8
  %_0.1 = load ptr, ptr %8, align 8
  %9 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %10 = insertvalue { i64, ptr } %9, ptr %_0.1, 1
  ret { i64, ptr } %10

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<u128>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusiveoE3newCslb9dB7bEmfm_4i128(ptr sret([48 x i8]) align 16 %_0, i128 %start1, i128 %end) unnamed_addr #0 !guid !309 {
start:
  store i128 %start1, ptr %_0, align 16
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %end, ptr %0, align 16
  %1 = getelementptr inbounds i8, ptr %_0, i64 32
  store i8 0, ptr %1, align 16
  ret void
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %self, i32 %rhs) unnamed_addr #0 !guid !310 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u128>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo10strict_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !311 {
start:
  %_3 = alloca [32 x i8], align 16
; call <u128>::checked_pow
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_3, i128 %self, i32 %exp) #22
  %1 = load i128, ptr %_3, align 16
  %2 = getelementptr inbounds i8, ptr %_3, i64 16
  %3 = load i128, ptr %2, align 16
  %_4 = trunc i128 %1 to i64
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %_3, i64 16
  %a = load i128, ptr %5, align 16
  ret i128 %a

bb4:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #24
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <u128>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !312 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_5.0 = add i128 %self, %rhs
  %_5.1 = icmp ult i128 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i128 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_6, ptr %2, align 16
  store i128 1, ptr %_0, align 16
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void
}

; <u128>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !313 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <u128>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !314 {
start:
  %_49 = alloca [32 x i8], align 16
  %_40 = alloca [32 x i8], align 16
  %_30 = alloca [32 x i8], align 16
  %_24 = alloca [32 x i8], align 16
  %_11 = alloca [8 x i8], align 4
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  %_6 = load i128, ptr %base, align 16
  %_5 = call i1 @llvm.is.constant.i128(i128 %_6)
  br i1 %_5, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_16 = load i32, ptr %exp, align 4
  %_15 = icmp eq i32 %_16, 0
  br i1 %_15, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_8 = load i128, ptr %base, align 16
  %1 = call i128 @llvm.ctpop.i128(i128 %_8)
  %_0.i.i = trunc i128 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_10 = load i128, ptr %base, align 16
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %_10, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  %_12 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %k, i32 %_12) #22
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_11, align 4
  %5 = getelementptr inbounds i8, ptr %_11, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_11, align 4
  %7 = getelementptr inbounds i8, ptr %_11, i64 4
  %8 = load i32, ptr %7, align 4
  %_13 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_13 to i1
  br i1 %9, label %bb9, label %bb8

bb12:                                             ; preds = %bb10
  %_18 = load i32, ptr %exp, align 4
  %_17 = call i1 @llvm.is.constant.i32(i32 %_18)
  br i1 %_17, label %bb14, label %bb26

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 1, ptr %10, align 16
  store i128 1, ptr %_0, align 16
  br label %bb37

bb26:                                             ; preds = %bb36, %bb12
  %_39 = load i32, ptr %exp, align 4
  %_38 = and i32 %_39, 1
  %_37 = icmp eq i32 %_38, 1
  br i1 %_37, label %bb27, label %bb32

bb14:                                             ; preds = %bb24, %bb12
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp ugt i32 %_20, 1
  br i1 %_19, label %bb15, label %bb25

bb32:                                             ; preds = %bb30, %bb26
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_50 = load i128, ptr %base, align 16
  %_51 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_49, i128 %_50, i128 %_51) #22
  %13 = load i128, ptr %_49, align 16
  %14 = getelementptr inbounds i8, ptr %_49, i64 16
  %15 = load i128, ptr %14, align 16
  %_52 = trunc i128 %13 to i64
  %16 = trunc nuw i64 %_52 to i1
  br i1 %16, label %bb36, label %bb35

bb27:                                             ; preds = %bb26
  %_41 = load i128, ptr %acc, align 16
  %_42 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_40, i128 %_41, i128 %_42) #22
  %17 = load i128, ptr %_40, align 16
  %18 = getelementptr inbounds i8, ptr %_40, i64 16
  %19 = load i128, ptr %18, align 16
  %_43 = trunc i128 %17 to i64
  %20 = trunc nuw i64 %_43 to i1
  br i1 %20, label %bb30, label %bb29

bb30:                                             ; preds = %bb27
  %21 = getelementptr inbounds i8, ptr %_40, i64 16
  %x = load i128, ptr %21, align 16
  store i128 %x, ptr %acc, align 16
  %_46 = load i32, ptr %exp, align 4
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb31, label %bb32

bb29:                                             ; preds = %bb27
  store i128 0, ptr %_0, align 16
  br label %bb37

bb37:                                             ; preds = %bb9, %bb8, %bb11, %bb23, %bb18, %bb25, %bb31, %bb35, %bb29
  ret void

bb31:                                             ; preds = %bb30
  %_47 = load i128, ptr %acc, align 16
  %22 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_47, ptr %22, align 16
  store i128 1, ptr %_0, align 16
  br label %bb37

bb36:                                             ; preds = %bb32
  %23 = getelementptr inbounds i8, ptr %_49, i64 16
  %x1 = load i128, ptr %23, align 16
  store i128 %x1, ptr %base, align 16
  br label %bb26

bb35:                                             ; preds = %bb32
  store i128 0, ptr %_0, align 16
  br label %bb37

bb25:                                             ; preds = %bb14
  %_35 = load i128, ptr %acc, align 16
  %_36 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %_35, i128 %_36) #22
  br label %bb37

bb15:                                             ; preds = %bb14
  %_23 = load i32, ptr %exp, align 4
  %_22 = and i32 %_23, 1
  %_21 = icmp eq i32 %_22, 1
  br i1 %_21, label %bb16, label %bb20

bb20:                                             ; preds = %bb19, %bb15
  %24 = load i32, ptr %exp, align 4
  %25 = udiv i32 %24, 2
  store i32 %25, ptr %exp, align 4
  %_31 = load i128, ptr %base, align 16
  %_32 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_30, i128 %_31, i128 %_32) #22
  %26 = load i128, ptr %_30, align 16
  %27 = getelementptr inbounds i8, ptr %_30, i64 16
  %28 = load i128, ptr %27, align 16
  %_33 = trunc i128 %26 to i64
  %29 = trunc nuw i64 %_33 to i1
  br i1 %29, label %bb24, label %bb23

bb16:                                             ; preds = %bb15
  %_25 = load i128, ptr %acc, align 16
  %_26 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_24, i128 %_25, i128 %_26) #22
  %30 = load i128, ptr %_24, align 16
  %31 = getelementptr inbounds i8, ptr %_24, i64 16
  %32 = load i128, ptr %31, align 16
  %_27 = trunc i128 %30 to i64
  %33 = trunc nuw i64 %_27 to i1
  br i1 %33, label %bb19, label %bb18

bb19:                                             ; preds = %bb16
  %34 = getelementptr inbounds i8, ptr %_24, i64 16
  %x2 = load i128, ptr %34, align 16
  store i128 %x2, ptr %acc, align 16
  br label %bb20

bb18:                                             ; preds = %bb16
  store i128 0, ptr %_0, align 16
  br label %bb37

bb24:                                             ; preds = %bb20
  %35 = getelementptr inbounds i8, ptr %_30, i64 16
  %x3 = load i128, ptr %35, align 16
  store i128 %x3, ptr %base, align 16
  br label %bb14

bb23:                                             ; preds = %bb20
  store i128 0, ptr %_0, align 16
  br label %bb37

bb9:                                              ; preds = %bb4
  %36 = getelementptr inbounds i8, ptr %_11, i64 4
  %shift = load i32, ptr %36, align 4
; call <u128>::checked_shl
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_shlCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 1, i32 %shift) #22
  br label %bb37

bb8:                                              ; preds = %bb4
  store i128 0, ptr %_0, align 16
  br label %bb37

bb7:                                              ; No predecessors!
  unreachable
}

; <u128>::checked_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_shlCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %rhs) unnamed_addr #0 !guid !315 {
start:
  %_3 = icmp ult i32 %rhs, 128
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb4

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u128>::unchecked_shl::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #26
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i128
  %_0.i = shl i128 %self, %0
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_0.i, ptr %1, align 16
  store i128 1, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit, %bb3
  ret void
}

; <u128>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !316 {
start:
  %_3 = icmp ult i128 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i128 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_4, ptr %0, align 16
  store i128 1, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  ret void
}

; <u128>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo12wrapping_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !317 {
start:
  %0 = alloca [32 x i8], align 16
; call <u128>::overflowing_pow
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo15overflowing_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %0, i128 %self, i32 %exp) #22
  %_3.0 = load i128, ptr %0, align 16
  %1 = getelementptr inbounds i8, ptr %0, i64 16
  %2 = load i8, ptr %1, align 16
  %_3.1 = trunc nuw i8 %2 to i1
  ret i128 %_3.0
}

; <u128>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13checked_ilog2Cslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !318 {
start:
  %_2 = alloca [16 x i8], align 16
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u128>>::new
  %0 = call i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3newCslb9dB7bEmfm_4i128(i128 %self) #22
  store i128 %0, ptr %_2, align 16
  %1 = load i128, ptr %_2, align 16
  %2 = icmp eq i128 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i128, ptr %_2, align 16
; call <core::num::nonzero::NonZero<u128>>::ilog2
  %_5 = call i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE5ilog2Cslb9dB7bEmfm_4i128(i128 %x) #22
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u128>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unbounded_shlCslb9dB7bEmfm_4i128(i128 %self, i32 %rhs) unnamed_addr #0 !guid !319 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp ult i32 %rhs, 128
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u128>::unchecked_shl::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #26
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i128
  %_0.i = shl i128 %self, %0
  store i128 %_0.i, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit, %bb2
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; <u128>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo15overflowing_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !320 {
start:
  %1 = alloca [32 x i8], align 16
  %2 = alloca [32 x i8], align 16
  %3 = alloca [32 x i8], align 16
  %4 = alloca [32 x i8], align 16
  %5 = alloca [32 x i8], align 16
  %_14 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  store i8 0, ptr %overflow, align 1
  %_8 = load i128, ptr %base, align 16
  %_7 = call i1 @llvm.is.constant.i128(i128 %_8)
  br i1 %_7, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp eq i32 %_20, 0
  br i1 %_19, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_10 = load i128, ptr %base, align 16
  %6 = call i128 @llvm.ctpop.i128(i128 %_10)
  %_0.i.i = trunc i128 %6 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_12 = load i128, ptr %base, align 16
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %_12, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  %_15 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %7 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %k, i32 %_15) #22
  %8 = extractvalue { i32, i32 } %7, 0
  %9 = extractvalue { i32, i32 } %7, 1
  store i32 %8, ptr %_14, align 4
  %10 = getelementptr inbounds i8, ptr %_14, i64 4
  store i32 %9, ptr %10, align 4
  %11 = load i32, ptr %_14, align 4
  %12 = getelementptr inbounds i8, ptr %_14, i64 4
  %13 = load i32, ptr %12, align 4
  %_16 = zext i32 %11 to i64
  %14 = trunc nuw i64 %_16 to i1
  br i1 %14, label %bb7, label %bb8

bb12:                                             ; preds = %bb10
  %_22 = load i32, ptr %exp, align 4
  %_21 = call i1 @llvm.is.constant.i32(i32 %_22)
  br i1 %_21, label %bb14, label %bb23

bb11:                                             ; preds = %bb10
  store i128 1, ptr %_0, align 16
  %15 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 0, ptr %15, align 16
  br label %bb30

bb23:                                             ; preds = %bb27, %bb12
  %_51 = load i32, ptr %exp, align 4
  %_50 = and i32 %_51, 1
  %_49 = icmp eq i32 %_50, 1
  br i1 %_49, label %bb24, label %bb27

bb14:                                             ; preds = %bb18, %bb12
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp ugt i32 %_24, 1
  br i1 %_23, label %bb15, label %bb21

bb27:                                             ; preds = %bb24, %bb23
  %16 = load i32, ptr %exp, align 4
  %17 = udiv i32 %16, 2
  store i32 %17, ptr %exp, align 4
  %_66 = load i128, ptr %base, align 16
  %_67 = load i128, ptr %base, align 16
  %18 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_66, i128 %_67)
  %_5.0.i5 = extractvalue { i128, i1 } %18, 0
  %_5.1.i6 = extractvalue { i128, i1 } %18, 1
  store i128 %_5.0.i5, ptr %4, align 16
  %19 = getelementptr inbounds i8, ptr %4, i64 16
  %20 = zext i1 %_5.1.i6 to i8
  store i8 %20, ptr %19, align 16
  %_65.0 = load i128, ptr %4, align 16
  %21 = getelementptr inbounds i8, ptr %4, i64 16
  %22 = load i8, ptr %21, align 16
  %_65.1 = trunc nuw i8 %22 to i1
  store i128 %_65.0, ptr %base, align 16
  %23 = zext i1 %_65.1 to i8
  store i8 %23, ptr %tmp_overflow, align 1
  %24 = load i8, ptr %tmp_overflow, align 1
  %_68 = trunc nuw i8 %24 to i1
  %25 = load i8, ptr %overflow, align 1
  %26 = trunc nuw i8 %25 to i1
  %27 = or i1 %26, %_68
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %overflow, align 1
  br label %bb23

bb24:                                             ; preds = %bb23
  %_55 = load i128, ptr %acc, align 16
  %_56 = load i128, ptr %base, align 16
  %29 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_55, i128 %_56)
  %_5.0.i7 = extractvalue { i128, i1 } %29, 0
  %_5.1.i8 = extractvalue { i128, i1 } %29, 1
  store i128 %_5.0.i7, ptr %5, align 16
  %30 = getelementptr inbounds i8, ptr %5, i64 16
  %31 = zext i1 %_5.1.i8 to i8
  store i8 %31, ptr %30, align 16
  %_54.0 = load i128, ptr %5, align 16
  %32 = getelementptr inbounds i8, ptr %5, i64 16
  %33 = load i8, ptr %32, align 16
  %_54.1 = trunc nuw i8 %33 to i1
  store i128 %_54.0, ptr %acc, align 16
  %34 = zext i1 %_54.1 to i8
  store i8 %34, ptr %tmp_overflow, align 1
  %35 = load i8, ptr %tmp_overflow, align 1
  %_57 = trunc nuw i8 %35 to i1
  %36 = load i8, ptr %overflow, align 1
  %37 = trunc nuw i8 %36 to i1
  %38 = or i1 %37, %_57
  %39 = zext i1 %38 to i8
  store i8 %39, ptr %overflow, align 1
  %_59 = load i32, ptr %exp, align 4
  %_58 = icmp eq i32 %_59, 1
  br i1 %_58, label %bb26, label %bb27

bb26:                                             ; preds = %bb24
  %_60 = load i128, ptr %acc, align 16
  %40 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %40 to i1
  store i128 %_60, ptr %_0, align 16
  %41 = getelementptr inbounds i8, ptr %_0, i64 16
  %42 = zext i1 %_61 to i8
  store i8 %42, ptr %41, align 16
  br label %bb30

bb30:                                             ; preds = %bb8, %bb7, %bb11, %bb21, %bb26
  ret void

bb21:                                             ; preds = %bb14
  %_44 = load i128, ptr %acc, align 16
  %_45 = load i128, ptr %base, align 16
  %43 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_44, i128 %_45)
  %_5.0.i3 = extractvalue { i128, i1 } %43, 0
  %_5.1.i4 = extractvalue { i128, i1 } %43, 1
  store i128 %_5.0.i3, ptr %3, align 16
  %44 = getelementptr inbounds i8, ptr %3, i64 16
  %45 = zext i1 %_5.1.i4 to i8
  store i8 %45, ptr %44, align 16
  %_43.0 = load i128, ptr %3, align 16
  %46 = getelementptr inbounds i8, ptr %3, i64 16
  %47 = load i8, ptr %46, align 16
  %_43.1 = trunc nuw i8 %47 to i1
  store i128 %_43.0, ptr %acc, align 16
  %48 = zext i1 %_43.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_46
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  %_47 = load i128, ptr %acc, align 16
  %54 = load i8, ptr %overflow, align 1
  %_48 = trunc nuw i8 %54 to i1
  store i128 %_47, ptr %_0, align 16
  %55 = getelementptr inbounds i8, ptr %_0, i64 16
  %56 = zext i1 %_48 to i8
  store i8 %56, ptr %55, align 16
  br label %bb30

bb15:                                             ; preds = %bb14
  %_27 = load i32, ptr %exp, align 4
  %_26 = and i32 %_27, 1
  %_25 = icmp eq i32 %_26, 1
  br i1 %_25, label %bb16, label %bb18

bb18:                                             ; preds = %bb16, %bb15
  %57 = load i32, ptr %exp, align 4
  %58 = udiv i32 %57, 2
  store i32 %58, ptr %exp, align 4
  %_38 = load i128, ptr %base, align 16
  %_39 = load i128, ptr %base, align 16
  %59 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_38, i128 %_39)
  %_5.0.i = extractvalue { i128, i1 } %59, 0
  %_5.1.i = extractvalue { i128, i1 } %59, 1
  store i128 %_5.0.i, ptr %1, align 16
  %60 = getelementptr inbounds i8, ptr %1, i64 16
  %61 = zext i1 %_5.1.i to i8
  store i8 %61, ptr %60, align 16
  %_37.0 = load i128, ptr %1, align 16
  %62 = getelementptr inbounds i8, ptr %1, i64 16
  %63 = load i8, ptr %62, align 16
  %_37.1 = trunc nuw i8 %63 to i1
  store i128 %_37.0, ptr %base, align 16
  %64 = zext i1 %_37.1 to i8
  store i8 %64, ptr %tmp_overflow, align 1
  %65 = load i8, ptr %tmp_overflow, align 1
  %_40 = trunc nuw i8 %65 to i1
  %66 = load i8, ptr %overflow, align 1
  %67 = trunc nuw i8 %66 to i1
  %68 = or i1 %67, %_40
  %69 = zext i1 %68 to i8
  store i8 %69, ptr %overflow, align 1
  br label %bb14

bb16:                                             ; preds = %bb15
  %_31 = load i128, ptr %acc, align 16
  %_32 = load i128, ptr %base, align 16
  %70 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_31, i128 %_32)
  %_5.0.i1 = extractvalue { i128, i1 } %70, 0
  %_5.1.i2 = extractvalue { i128, i1 } %70, 1
  store i128 %_5.0.i1, ptr %2, align 16
  %71 = getelementptr inbounds i8, ptr %2, i64 16
  %72 = zext i1 %_5.1.i2 to i8
  store i8 %72, ptr %71, align 16
  %_30.0 = load i128, ptr %2, align 16
  %73 = getelementptr inbounds i8, ptr %2, i64 16
  %74 = load i8, ptr %73, align 16
  %_30.1 = trunc nuw i8 %74 to i1
  store i128 %_30.0, ptr %acc, align 16
  %75 = zext i1 %_30.1 to i8
  store i8 %75, ptr %tmp_overflow, align 1
  %76 = load i8, ptr %tmp_overflow, align 1
  %_33 = trunc nuw i8 %76 to i1
  %77 = load i8, ptr %overflow, align 1
  %78 = trunc nuw i8 %77 to i1
  %79 = or i1 %78, %_33
  %80 = zext i1 %79 to i8
  store i8 %80, ptr %overflow, align 1
  br label %bb18

bb7:                                              ; preds = %bb4
  %81 = getelementptr inbounds i8, ptr %_14, i64 4
  %shift = load i32, ptr %81, align 4
; call <u128>::unbounded_shl
  %_17 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unbounded_shlCslb9dB7bEmfm_4i128(i128 1, i32 %shift) #22
  %_18 = icmp uge i32 %shift, 128
  store i128 %_17, ptr %_0, align 16
  %82 = getelementptr inbounds i8, ptr %_0, i64 16
  %83 = zext i1 %_18 to i8
  store i8 %83, ptr %82, align 16
  br label %bb30

bb8:                                              ; preds = %bb4
  store i128 0, ptr %_0, align 16
  %84 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 1, ptr %84, align 16
  br label %bb30

bb31:                                             ; No predecessors!
  unreachable
}

; <u128>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !321 {
start:
  %_0 = alloca [16 x i8], align 16
  br label %bb1

bb1:                                              ; preds = %start
; call <u128>::strict_pow
  %0 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo10strict_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #22
  store i128 %0, ptr %_0, align 16
  br label %bb3

bb2:                                              ; No predecessors!
; call <u128>::wrapping_pow
  %1 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo12wrapping_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) #22
  store i128 %1, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i128, ptr %_0, align 16
  ret i128 %2
}

; <u128>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %self, ptr align 8 %0) unnamed_addr #0 !guid !322 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u128>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13checked_ilog2Cslb9dB7bEmfm_4i128(i128 %self) #22
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #24
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<u128>>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusiveoE8is_emptyCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !323 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = getelementptr inbounds i8, ptr %self, i64 32
  %1 = load i8, ptr %0, align 16
  %_2 = trunc nuw i8 %1 to i1
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_5 = getelementptr inbounds i8, ptr %self, i64 16
  %_3.i = load i128, ptr %self, align 16
  %_4.i = load i128, ptr %_5, align 16
  %_0.i = icmp ule i128 %_3.i, %_4.i
  %2 = xor i1 %_0.i, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !324 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCslb9dB7bEmfm_4i128(i64 %self, i64 %rhs) unnamed_addr #0 !guid !325 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5.0 = add i64 %self, %rhs
  %_5.1 = icmp ult i64 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCslb9dB7bEmfm_4i128(i64 %self, i64 %rhs) unnamed_addr #0 !guid !326 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCslb9dB7bEmfm_4i128(i64 %self, i64 %other) unnamed_addr #0 !guid !327 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCslb9dB7bEmfm_4i128(i32 %_0.i) #22
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <u128>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo14from_str_radixCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !328 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <u128>::from_ascii_bytes_radix_impl
  call void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo27from_ascii_bytes_radix_implCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #22
  ret void
}

; <u128>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo27from_ascii_bytes_radix_implCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !329 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [32 x i8], align 16
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [32 x i8], align 16
  %_74 = alloca [32 x i8], align 16
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [32 x i8], align 16
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [16 x i8], align 16
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_5aa1d1250638a5285856df0c8e3018a3) #28
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCslb9dB7bEmfm_4i128(ptr %src.0, i64 %src.1) #22
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb11, %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb9

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !330
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i128 0, ptr %result, align 16
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 32
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; No predecessors!
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i128, ptr %result, align 16
  %33 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_105, ptr %33, align 16
  store i8 0, ptr %_0, align 16
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i128, ptr %result, align 16
  %_86 = zext i32 %radix to i128
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %mul1, i128 %_85, i128 %_86) #22
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %40 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_89, i32 %radix) #22
  %41 = extractvalue { i32, i32 } %40, 0
  %42 = extractvalue { i32, i32 } %40, 1
  store i32 %41, ptr %_88, align 4
  %43 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %42, ptr %43, align 4
  %44 = load i32, ptr %_88, align 4
  %45 = getelementptr inbounds i8, ptr %_88, i64 4
  %46 = load i32, ptr %45, align 4
  %_91 = zext i32 %44 to i64
  %47 = trunc nuw i64 %_91 to i1
  br i1 %47, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %48, align 4
  %x = zext i32 %value to i128
  %49 = load i128, ptr %mul1, align 16
  %50 = getelementptr inbounds i8, ptr %mul1, i64 16
  %51 = load i128, ptr %50, align 16
  %_95 = trunc i128 %49 to i64
  %52 = trunc nuw i64 %_95 to i1
  br i1 %52, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %53, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb48:                                             ; preds = %bb46
  %54 = getelementptr inbounds i8, ptr %mul1, i64 16
  %value4 = load i128, ptr %54, align 16
  store i128 %value4, ptr %result, align 16
  %_100 = load i128, ptr %result, align 16
; call <u128>::checked_sub
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_99, i128 %_100, i128 %x) #22
  %55 = load i128, ptr %_99, align 16
  %56 = getelementptr inbounds i8, ptr %_99, i64 16
  %57 = load i128, ptr %56, align 16
  %_101 = trunc i128 %55 to i64
  %58 = trunc nuw i64 %_101 to i1
  br i1 %58, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %59, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb51:                                             ; preds = %bb48
  %60 = getelementptr inbounds i8, ptr %_99, i64 16
  %value5 = load i128, ptr %60, align 16
  store i128 %value5, ptr %result, align 16
  store ptr %rest.02, ptr %digits, align 8, !captures !330
  %61 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %61, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %62 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %62, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb31:                                             ; preds = %bb30
  %63 = load ptr, ptr %digits, align 8
  %64 = getelementptr inbounds i8, ptr %digits, i64 8
  %65 = load i64, ptr %64, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %63, i64 0
  %66 = load ptr, ptr %digits, align 8
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  %68 = load i64, ptr %67, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %66, i64 1
  %rest.18 = sub i64 %68, 1
  %_60 = load i128, ptr %result, align 16
  %_61 = zext i32 %radix to i128
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %mul, i128 %_60, i128 %_61) #22
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %69 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_64, i32 %radix) #22
  %70 = extractvalue { i32, i32 } %69, 0
  %71 = extractvalue { i32, i32 } %69, 1
  store i32 %70, ptr %_63, align 4
  %72 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %71, ptr %72, align 4
  %73 = load i32, ptr %_63, align 4
  %74 = getelementptr inbounds i8, ptr %_63, i64 4
  %75 = load i32, ptr %74, align 4
  %_66 = zext i32 %73 to i64
  %76 = trunc nuw i64 %_66 to i1
  br i1 %76, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %77 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %77, align 4
  %x10 = zext i32 %value9 to i128
  %78 = load i128, ptr %mul, align 16
  %79 = getelementptr inbounds i8, ptr %mul, i64 16
  %80 = load i128, ptr %79, align 16
  %_70 = trunc i128 %78 to i64
  %81 = trunc nuw i64 %_70 to i1
  br i1 %81, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %82 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %82, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb37:                                             ; preds = %bb35
  %83 = getelementptr inbounds i8, ptr %mul, i64 16
  %value11 = load i128, ptr %83, align 16
  store i128 %value11, ptr %result, align 16
  %_75 = load i128, ptr %result, align 16
; call <u128>::checked_add
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_74, i128 %_75, i128 %x10) #22
  %84 = load i128, ptr %_74, align 16
  %85 = getelementptr inbounds i8, ptr %_74, i64 16
  %86 = load i128, ptr %85, align 16
  %_76 = trunc i128 %84 to i64
  %87 = trunc nuw i64 %_76 to i1
  br i1 %87, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %88 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %88, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb40:                                             ; preds = %bb37
  %89 = getelementptr inbounds i8, ptr %_74, i64 16
  %value12 = load i128, ptr %89, align 16
  store i128 %value12, ptr %result, align 16
  store ptr %rest.07, ptr %digits, align 8, !captures !330
  %90 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %90, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %91, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %92 = load ptr, ptr %digits, align 8
  %93 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %93, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %94 = load ptr, ptr %digits, align 8
  %95 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %95, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %96 = load ptr, ptr %digits, align 8
  %97 = getelementptr inbounds i8, ptr %digits, i64 8
  %98 = load i64, ptr %97, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %96, i64 0
  %99 = load ptr, ptr %digits, align 8
  %100 = getelementptr inbounds i8, ptr %digits, i64 8
  %101 = load i64, ptr %100, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %99, i64 1
  %rest.115 = sub i64 %101, 1
  %_44 = load i128, ptr %result, align 16
  %_45 = zext i32 %radix to i128
  %102 = mul i128 %_44, %_45
  store i128 %102, ptr %result, align 16
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %103 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_47, i32 %radix) #22
  %104 = extractvalue { i32, i32 } %103, 0
  %105 = extractvalue { i32, i32 } %103, 1
  store i32 %104, ptr %_46, align 4
  %106 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %105, ptr %106, align 4
  %107 = load i32, ptr %_46, align 4
  %108 = getelementptr inbounds i8, ptr %_46, i64 4
  %109 = load i32, ptr %108, align 4
  %_49 = zext i32 %107 to i64
  %110 = trunc nuw i64 %_49 to i1
  br i1 %110, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %111 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %111, align 4
  %_53 = load i128, ptr %result, align 16
  %_54 = zext i32 %x16 to i128
  %112 = sub i128 %_53, %_54
  store i128 %112, ptr %result, align 16
  store ptr %rest.014, ptr %digits, align 8, !captures !330
  %113 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %113, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %114 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %114, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb19:                                             ; preds = %bb18
  %115 = load ptr, ptr %digits, align 8
  %116 = getelementptr inbounds i8, ptr %digits, i64 8
  %117 = load i64, ptr %116, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %115, i64 0
  %118 = load ptr, ptr %digits, align 8
  %119 = getelementptr inbounds i8, ptr %digits, i64 8
  %120 = load i64, ptr %119, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %118, i64 1
  %rest.119 = sub i64 %120, 1
  %_29 = load i128, ptr %result, align 16
  %_30 = zext i32 %radix to i128
  %121 = mul i128 %_29, %_30
  store i128 %121, ptr %result, align 16
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %122 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_32, i32 %radix) #22
  %123 = extractvalue { i32, i32 } %122, 0
  %124 = extractvalue { i32, i32 } %122, 1
  store i32 %123, ptr %_31, align 4
  %125 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %124, ptr %125, align 4
  %126 = load i32, ptr %_31, align 4
  %127 = getelementptr inbounds i8, ptr %_31, i64 4
  %128 = load i32, ptr %127, align 4
  %_34 = zext i32 %126 to i64
  %129 = trunc nuw i64 %_34 to i1
  br i1 %129, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %130 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %130, align 4
  %_38 = load i128, ptr %result, align 16
  %_39 = zext i32 %x20 to i128
  %131 = add i128 %_38, %_39
  store i128 %131, ptr %result, align 16
  store ptr %rest.018, ptr %digits, align 8, !captures !330
  %132 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %132, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %133 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %133, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !331 {
start:
; call <alloc::raw_vec::RawVec<u8>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCslb9dB7bEmfm_4i128(i64 %capacity) #22
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cslb9dB7bEmfm_4i128(i8 %0) unnamed_addr #0 !guid !332 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cslb9dB7bEmfm_4i128(ptr %self) #22
  ret i32 %_0
}

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !333 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCslb9dB7bEmfm_4i128(ptr align 8 %self) #22
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::append_elements
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE15append_elementsCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !334 {
start:
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECslb9dB7bEmfm_4i128(ptr %other.0, i64 %other.1) #22
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %_0.i)
; call <alloc::vec::Vec<u8>>::append_elements_unreserved
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE26append_elements_unreservedCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %other.0, i64 %other.1) #22
  ret void
}

; <alloc::vec::Vec<u8>>::append_elements_unreserved
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE26append_elements_unreservedCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %other.0, i64 %other.1) unnamed_addr #0 !guid !335 {
start:
; call core::ptr::metadata::metadata::<[u8]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataShECslb9dB7bEmfm_4i128(ptr %other.0, i64 %other.1) #22
; call <alloc::vec::Vec<u8>>::len
  %len = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCslb9dB7bEmfm_4i128(ptr align 8 %self) #22
  %_6 = icmp ugt i64 %_0.i1, 0
  br i1 %_6, label %bb3, label %bb6

bb6:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECslb9dB7bEmfm_4i128.exit, %start
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i64, ptr %1, align 8
  %3 = add i64 %2, %_0.i1
  store i64 %3, ptr %0, align 8
  ret void

bb3:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCslb9dB7bEmfm_4i128(ptr align 8 %self) #22
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECslb9dB7bEmfm_4i128.exit

bb2.i:                                            ; preds = %bb3
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCslb9dB7bEmfm_4i128(ptr %other.0, ptr %_0.i, i64 1, i64 1, i64 %_0.i1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #26
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECslb9dB7bEmfm_4i128.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinghECslb9dB7bEmfm_4i128.exit: ; preds = %bb3, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i, ptr align 1 %other.0, i64 %_0.i1, i1 false)
  br label %bb6
}

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !336 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 9223372036854775807
  ret i64 %len
}

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %additional) unnamed_addr #1 !guid !337 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<u8>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %_5, i64 %additional) #22
  ret void
}

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !338 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCslb9dB7bEmfm_4i128(ptr align 8 %self) #22
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCslb9dB7bEmfm_4i128(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #26
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !339 {
start:
; call <alloc::raw_vec::RawVec<u8>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCslb9dB7bEmfm_4i128(ptr align 8 %self) #22
  ret i64 %_0
}

; <*mut u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCslb9dB7bEmfm_4i128(ptr %self, i64 %len) unnamed_addr #0 !guid !340 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECslb9dB7bEmfm_4i128(ptr %self, i64 %len) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCslb9dB7bEmfm_4i128(i64 %self) unnamed_addr #0 !guid !341 {
start:
  ret i64 %self
}

; <core::num::nonzero::NonZero<u128>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3getCslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !342 {
start:
  ret i128 %self
}

; <core::num::nonzero::NonZero<u128>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3newCslb9dB7bEmfm_4i128(i128 %n) unnamed_addr #0 !guid !343 {
start:
  ret i128 %n
}

; <i128>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMst_NtCsl10jNU3mE6R_4core3numn14from_str_radixCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !344 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <i128>::from_ascii_bytes_radix_impl
  call void @_RNvMst_NtCsl10jNU3mE6R_4core3numn27from_ascii_bytes_radix_implCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #22
  ret void
}

; <i128>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMst_NtCsl10jNU3mE6R_4core3numn27from_ascii_bytes_radix_implCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !345 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [32 x i8], align 16
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [32 x i8], align 16
  %_74 = alloca [32 x i8], align 16
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [32 x i8], align 16
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [16 x i8], align 16
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #28
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCslb9dB7bEmfm_4i128(ptr %src.0, i64 %src.1) #22
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !330
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i128 0, ptr %result, align 16
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 31
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i128, ptr %result, align 16
  %33 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_105, ptr %33, align 16
  store i8 0, ptr %_0, align 16
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i128, ptr %result, align 16
  %_86 = zext i32 %radix to i128
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %mul1, i128 %_85, i128 %_86) #22
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %40 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_89, i32 %radix) #22
  %41 = extractvalue { i32, i32 } %40, 0
  %42 = extractvalue { i32, i32 } %40, 1
  store i32 %41, ptr %_88, align 4
  %43 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %42, ptr %43, align 4
  %44 = load i32, ptr %_88, align 4
  %45 = getelementptr inbounds i8, ptr %_88, i64 4
  %46 = load i32, ptr %45, align 4
  %_91 = zext i32 %44 to i64
  %47 = trunc nuw i64 %_91 to i1
  br i1 %47, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %48, align 4
  %x = zext i32 %value to i128
  %49 = load i128, ptr %mul1, align 16
  %50 = getelementptr inbounds i8, ptr %mul1, i64 16
  %51 = load i128, ptr %50, align 16
  %_95 = trunc i128 %49 to i64
  %52 = trunc nuw i64 %_95 to i1
  br i1 %52, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %53, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb48:                                             ; preds = %bb46
  %54 = getelementptr inbounds i8, ptr %mul1, i64 16
  %value4 = load i128, ptr %54, align 16
  store i128 %value4, ptr %result, align 16
  %_100 = load i128, ptr %result, align 16
; call <i128>::checked_sub
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_99, i128 %_100, i128 %x) #22
  %55 = load i128, ptr %_99, align 16
  %56 = getelementptr inbounds i8, ptr %_99, i64 16
  %57 = load i128, ptr %56, align 16
  %_101 = trunc i128 %55 to i64
  %58 = trunc nuw i64 %_101 to i1
  br i1 %58, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %59, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb51:                                             ; preds = %bb48
  %60 = getelementptr inbounds i8, ptr %_99, i64 16
  %value5 = load i128, ptr %60, align 16
  store i128 %value5, ptr %result, align 16
  store ptr %rest.02, ptr %digits, align 8, !captures !330
  %61 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %61, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %62 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %62, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb31:                                             ; preds = %bb30
  %63 = load ptr, ptr %digits, align 8
  %64 = getelementptr inbounds i8, ptr %digits, i64 8
  %65 = load i64, ptr %64, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %63, i64 0
  %66 = load ptr, ptr %digits, align 8
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  %68 = load i64, ptr %67, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %66, i64 1
  %rest.18 = sub i64 %68, 1
  %_60 = load i128, ptr %result, align 16
  %_61 = zext i32 %radix to i128
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %mul, i128 %_60, i128 %_61) #22
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %69 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_64, i32 %radix) #22
  %70 = extractvalue { i32, i32 } %69, 0
  %71 = extractvalue { i32, i32 } %69, 1
  store i32 %70, ptr %_63, align 4
  %72 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %71, ptr %72, align 4
  %73 = load i32, ptr %_63, align 4
  %74 = getelementptr inbounds i8, ptr %_63, i64 4
  %75 = load i32, ptr %74, align 4
  %_66 = zext i32 %73 to i64
  %76 = trunc nuw i64 %_66 to i1
  br i1 %76, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %77 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %77, align 4
  %x10 = zext i32 %value9 to i128
  %78 = load i128, ptr %mul, align 16
  %79 = getelementptr inbounds i8, ptr %mul, i64 16
  %80 = load i128, ptr %79, align 16
  %_70 = trunc i128 %78 to i64
  %81 = trunc nuw i64 %_70 to i1
  br i1 %81, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %82 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %82, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb37:                                             ; preds = %bb35
  %83 = getelementptr inbounds i8, ptr %mul, i64 16
  %value11 = load i128, ptr %83, align 16
  store i128 %value11, ptr %result, align 16
  %_75 = load i128, ptr %result, align 16
; call <i128>::checked_add
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_addCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_74, i128 %_75, i128 %x10) #22
  %84 = load i128, ptr %_74, align 16
  %85 = getelementptr inbounds i8, ptr %_74, i64 16
  %86 = load i128, ptr %85, align 16
  %_76 = trunc i128 %84 to i64
  %87 = trunc nuw i64 %_76 to i1
  br i1 %87, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %88 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %88, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb40:                                             ; preds = %bb37
  %89 = getelementptr inbounds i8, ptr %_74, i64 16
  %value12 = load i128, ptr %89, align 16
  store i128 %value12, ptr %result, align 16
  store ptr %rest.07, ptr %digits, align 8, !captures !330
  %90 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %90, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %91, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %92 = load ptr, ptr %digits, align 8
  %93 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %93, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %94 = load ptr, ptr %digits, align 8
  %95 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %95, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %96 = load ptr, ptr %digits, align 8
  %97 = getelementptr inbounds i8, ptr %digits, i64 8
  %98 = load i64, ptr %97, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %96, i64 0
  %99 = load ptr, ptr %digits, align 8
  %100 = getelementptr inbounds i8, ptr %digits, i64 8
  %101 = load i64, ptr %100, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %99, i64 1
  %rest.115 = sub i64 %101, 1
  %_44 = load i128, ptr %result, align 16
  %_45 = zext i32 %radix to i128
  %102 = mul i128 %_44, %_45
  store i128 %102, ptr %result, align 16
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %103 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_47, i32 %radix) #22
  %104 = extractvalue { i32, i32 } %103, 0
  %105 = extractvalue { i32, i32 } %103, 1
  store i32 %104, ptr %_46, align 4
  %106 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %105, ptr %106, align 4
  %107 = load i32, ptr %_46, align 4
  %108 = getelementptr inbounds i8, ptr %_46, i64 4
  %109 = load i32, ptr %108, align 4
  %_49 = zext i32 %107 to i64
  %110 = trunc nuw i64 %_49 to i1
  br i1 %110, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %111 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %111, align 4
  %_53 = load i128, ptr %result, align 16
  %_54 = zext i32 %x16 to i128
  %112 = sub i128 %_53, %_54
  store i128 %112, ptr %result, align 16
  store ptr %rest.014, ptr %digits, align 8, !captures !330
  %113 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %113, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %114 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %114, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb19:                                             ; preds = %bb18
  %115 = load ptr, ptr %digits, align 8
  %116 = getelementptr inbounds i8, ptr %digits, i64 8
  %117 = load i64, ptr %116, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %115, i64 0
  %118 = load ptr, ptr %digits, align 8
  %119 = getelementptr inbounds i8, ptr %digits, i64 8
  %120 = load i64, ptr %119, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %118, i64 1
  %rest.119 = sub i64 %120, 1
  %_29 = load i128, ptr %result, align 16
  %_30 = zext i32 %radix to i128
  %121 = mul i128 %_29, %_30
  store i128 %121, ptr %result, align 16
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %122 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_32, i32 %radix) #22
  %123 = extractvalue { i32, i32 } %122, 0
  %124 = extractvalue { i32, i32 } %122, 1
  store i32 %123, ptr %_31, align 4
  %125 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %124, ptr %125, align 4
  %126 = load i32, ptr %_31, align 4
  %127 = getelementptr inbounds i8, ptr %_31, i64 4
  %128 = load i32, ptr %127, align 4
  %_34 = zext i32 %126 to i64
  %129 = trunc nuw i64 %_34 to i1
  br i1 %129, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %130 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %130, align 4
  %_38 = load i128, ptr %result, align 16
  %_39 = zext i32 %x20 to i128
  %131 = add i128 %_38, %_39
  store i128 %131, ptr %result, align 16
  store ptr %rest.018, ptr %digits, align 8, !captures !330
  %132 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %132, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %133 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %133, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCslb9dB7bEmfm_4i128(i64 %0, i64 %1) unnamed_addr #0 !guid !346 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCslb9dB7bEmfm_4i128(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !347 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #29
  ret void
}

; alloc::alloc::realloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc15realloc_nonnullCslb9dB7bEmfm_4i128(ptr %ptr, i64 %0, i64 %1, i64 %new_size) unnamed_addr #0 !guid !348 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_6 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
; call __rustc::__rust_realloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc14___rust_realloc(ptr %ptr, i64 %_4, i64 %_6, i64 %new_size) #29
  ret ptr %_0
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCslb9dB7bEmfm_4i128(i64 %0, i64 %1) unnamed_addr #0 !guid !349 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCslb9dB7bEmfm_4i128(ptr align 8 %layout) #22
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::raw_vec::layout_array
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %cap, i64 %0, i64 %1) unnamed_addr #0 !guid !350 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::repeat_packed
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCslb9dB7bEmfm_4i128(ptr align 8 %elem_layout, i64 %cap) #22
  %_3.0 = extractvalue { i64, i64 } %3, 0
  %_3.1 = extractvalue { i64, i64 } %3, 1
; call <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %_3.0, i64 %_3.1) #22
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCslb9dB7bEmfm_4i128() unnamed_addr #5 !guid !351 {
start:
  ret void
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCslb9dB7bEmfm_4i128(ptr %ptr, i64 %align) unnamed_addr #0 !guid !352 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCslb9dB7bEmfm_4i128(ptr %ptr, i64 %align) #22
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !353 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCslb9dB7bEmfm_4i128() #22
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCslb9dB7bEmfm_4i128(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !354 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCslb9dB7bEmfm_4i128(ptr %3, ptr %5, i64 %7, i64 %9) #22
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCslb9dB7bEmfm_4i128(i64 %size, i64 %len) unnamed_addr #0 !guid !355 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #28
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCslb9dB7bEmfm_4i128(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !356 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCslb9dB7bEmfm_4i128(ptr %ptr, i64 %align) #22
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCslb9dB7bEmfm_4i128(ptr %ptr) #22
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCslb9dB7bEmfm_4i128(i32 %code, ptr %dst) unnamed_addr #0 !guid !357 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cslb9dB7bEmfm_4i128(i32 %code) #22
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cslb9dB7bEmfm_4i128(i32 %code) unnamed_addr #0 !guid !358 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCslb9dB7bEmfm_4i128(i64 %align, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !359 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCslb9dB7bEmfm_4i128(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !360 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCslb9dB7bEmfm_4i128(ptr %ptr) unnamed_addr #0 !guid !361 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCslb9dB7bEmfm_4i128(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !362 {
start:
; invoke <core::alloc::layout::Layout>::is_size_align_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCslb9dB7bEmfm_4i128(i64 %size, i64 %align)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_1be5ea12ba708d9a11b6e93a7d387a75, i64 281)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCslb9dB7bEmfm_4i128(ptr %ptr, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !363 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCslb9dB7bEmfm_4i128(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <i128>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !364 {
start:
  %_2 = icmp ult i32 %rhs, 128
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_a61ecf1bbb59a9a75a6a223b3f565d28, i64 185)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <u32>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_add18precondition_checkCslb9dB7bEmfm_4i128(i32 %lhs, i32 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !365 {
start:
  %_5.0.i = add i32 %lhs, %rhs
  %_5.1.i = icmp ult i32 %_5.0.i, %lhs
  %1 = insertvalue { i32, i1 } poison, i32 %_5.0.i, 0
  %2 = insertvalue { i32, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i32, i1 } %2, 0
  %_4.1 = extractvalue { i32, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_a6a0cc8156fe455996de64a9d05b1dfe, i64 184)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <u128>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add18precondition_checkCslb9dB7bEmfm_4i128(i128 %lhs, i128 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !366 {
start:
  %1 = alloca [32 x i8], align 16
  %_5.0.i = add i128 %lhs, %rhs
  %_5.1.i = icmp ult i128 %_5.0.i, %lhs
  store i128 %_5.0.i, ptr %1, align 16
  %2 = getelementptr inbounds i8, ptr %1, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  br label %bb1

terminate:                                        ; preds = %bb2
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = load i128, ptr %1, align 16
  %5 = getelementptr inbounds i8, ptr %1, i64 16
  %6 = load i8, ptr %5, align 16
  %_4.1 = trunc nuw i8 %6 to i1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %7 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_0a7ace845dda78b0b3e088b89fa358fb, i64 185)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %7, 0
  %_6.1 = extractvalue { ptr, ptr } %7, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <u128>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !367 {
start:
  %_2 = icmp ult i32 %rhs, 128
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_8efb6cb47e437ad05e23651986f609b7, i64 185)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <usize>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCslb9dB7bEmfm_4i128(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !368 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCslb9dB7bEmfm_4i128(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !369 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::ptr::write_bytes::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr11write_bytes18precondition_checkCslb9dB7bEmfm_4i128(ptr %addr, i64 %align, i1 zeroext %zero_size, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !370 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_4 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCslb9dB7bEmfm_4i128(ptr %addr, i64 %align, i1 zeroext %zero_size)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_dd79dfae92e8fdc23813c4c7a1b7cf72, i64 228)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_6.0 = extractvalue { ptr, ptr } %2, 0
  %_6.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCslb9dB7bEmfm_4i128(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !371 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCslb9dB7bEmfm_4i128(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCslb9dB7bEmfm_4i128(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCslb9dB7bEmfm_4i128(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCslb9dB7bEmfm_4i128(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !372 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCslb9dB7bEmfm_4i128(ptr %ptr, i64 %align) unnamed_addr #0 !guid !373 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCslb9dB7bEmfm_4i128(ptr %ptr, i64 %align) #22
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !374 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCslb9dB7bEmfm_4i128(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !375 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCslb9dB7bEmfm_4i128(i64 %size, i64 %count) #22
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCslb9dB7bEmfm_4i128(i64 %_0.i2, i64 %_0.i) #22
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #30
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCslb9dB7bEmfm_4i128(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !376 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCslb9dB7bEmfm_4i128(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #23
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_a28e8c8fd5088943a8b5d44af697ff83, i64 279)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCslb9dB7bEmfm_4i128(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #30
  unreachable
}

; <core::ops::range::Range<u32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangemENtB2_12IntoIterator9into_iterCslb9dB7bEmfm_4i128(i32 %self.0, i32 %self.1) unnamed_addr #0 !guid !377 {
start:
  %0 = insertvalue { i32, i32 } poison, i32 %self.0, 0
  %1 = insertvalue { i32, i32 } %0, i32 %self.1, 1
  ret { i32, i32 } %1
}

; <core::ops::range::Range<u128> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangeoENtB2_12IntoIterator9into_iterCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self.0, i128 %self.1) unnamed_addr #0 !guid !378 {
start:
  store i128 %self.0, ptr %_0, align 16
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %self.1, ptr %0, align 16
  ret void
}

; <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCslb9dB7bEmfm_4i128(i64 %kind.0, i64 %kind.1) unnamed_addr #0 !guid !379 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %kind.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %kind.1, 1
  ret { i64, i64 } %1
}

; <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !380 {
start:
  unreachable
}

; <(u128, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTobENtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #1 !guid !381 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <i128 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1Q_NtCs7CppTae75M1_5alloc6stringnNtB6_12SpecToString14spec_to_stringCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !382 {
start:
  %0 = alloca [16 x i8], align 8
  %_19 = alloca [1 x i8], align 1
  %_11 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  %out = alloca [24 x i8], align 8
  %buf = alloca [39 x i8], align 1
  store i8 0, ptr %_19, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 39, i1 false)
  %_6 = load i128, ptr %self, align 16
  %_5 = icmp slt i128 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_11, i64 39)
          to label %bb5 unwind label %cleanup

bb2:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_7, i64 40)
          to label %bb3 unwind label %cleanup

bb12:                                             ; preds = %cleanup
  %1 = load i8, ptr %_19, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb11, label %bb10

cleanup:                                          ; preds = %bb8, %bb7, %bb6, %bb3, %bb2, %bb4
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb12

bb5:                                              ; preds = %bb4
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_11, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb13, %bb5
  %_16 = load i128, ptr %self, align 16
; invoke <i128>::unsigned_abs
  %_15 = invoke i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_16)
          to label %bb7 unwind label %cleanup

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_7, i64 24, i1 false)
; invoke <alloc::string::String>::push
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCslb9dB7bEmfm_4i128(ptr align 8 %out, i32 45)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb3
  br label %bb6

bb7:                                              ; preds = %bb6
; invoke <u128>::_fmt
  %7 = invoke { ptr, i64 } @_RNvMs0_NtNtCsl10jNU3mE6R_4core3fmt3numo4__fmt(i128 %_15, ptr %buf, i64 39)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %_14.0 = extractvalue { ptr, i64 } %7, 0
  %_14.1 = extractvalue { ptr, i64 } %7, 1
; invoke <alloc::string::String>::push_str
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCslb9dB7bEmfm_4i128(ptr align 8 %out, ptr %_14.0, i64 %_14.1)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %out, i64 24, i1 false)
  store i8 0, ptr %_19, align 1
  ret void

bb10:                                             ; preds = %bb11, %bb12
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb11:                                             ; preds = %bb12
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECslb9dB7bEmfm_4i128(ptr align 8 %out) #25
          to label %bb10 unwind label %terminate

terminate:                                        ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #23
  unreachable
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCslb9dB7bEmfm_4i128(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !383 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCslb9dB7bEmfm_4i128(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #22
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCslb9dB7bEmfm_4i128(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !384 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCslb9dB7bEmfm_4i128(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext true) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator4growCslb9dB7bEmfm_4i128(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1) unnamed_addr #0 !guid !385 {
start:
; call <alloc::alloc::Global>::grow_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global9grow_implCslb9dB7bEmfm_4i128(ptr %self, ptr %ptr, i64 %old_layout.0, i64 %old_layout.1, i64 %new_layout.0, i64 %new_layout.1, i1 zeroext false) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCslb9dB7bEmfm_4i128(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !386 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCslb9dB7bEmfm_4i128(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #22
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #1 !guid !387 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 1, i64 1)
  ret void
}

; <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCslb9dB7bEmfm_4i128(ptr %self, ptr align 8 %0) unnamed_addr #0 !guid !388 {
start:
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_0 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCslb9dB7bEmfm_4i128(ptr %self) #22
  ret ptr %_0
}

; <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCslb9dB7bEmfm_4i128(i64 %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !389 {
start:
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCslb9dB7bEmfm_4i128(i64 %self.0, i64 %self.1) #22
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !390 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !391 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !392 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCslb9dB7bEmfm_4i128(ptr %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&i128 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRnNtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !393 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i128 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <&u128 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRoNtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !394 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u128 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %_3, ptr align 8 %f) #22
  ret i1 %_0
}

; <alloc::vec::Vec<u8> as alloc::vec::spec_extend::SpecExtend<&u8, core::slice::iter::Iter<u8>>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs2_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB7_3VechEINtB5_10SpecExtendRhINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhEE11spec_extendCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #1 !guid !395 {
start:
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %2 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %2, align 8
; call <core::slice::iter::Iter<u8>>::as_slice
  %3 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterhE8as_sliceCslb9dB7bEmfm_4i128(ptr align 8 %iterator) #22
  %slice.0 = extractvalue { ptr, i64 } %3, 0
  %slice.1 = extractvalue { ptr, i64 } %3, 1
; call <alloc::vec::Vec<u8>>::append_elements
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE15append_elementsCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %slice.0, i64 %slice.1) #22
  ret void
}

; <core::ops::range::Range<u32> as core::iter::range::RangeIteratorImpl>::spec_next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangemENtB5_17RangeIteratorImpl9spec_nextCslb9dB7bEmfm_4i128(ptr align 4 %self) unnamed_addr #0 !guid !396 {
start:
  %_0 = alloca [8 x i8], align 4
  %_4 = getelementptr inbounds i8, ptr %self, i64 4
  %_3.i = load i32, ptr %self, align 4
  %_4.i = load i32, ptr %_4, align 4
  %_0.i = icmp ult i32 %_3.i, %_4.i
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb5

bb2:                                              ; preds = %start
  %old = load i32, ptr %self, align 4
; call <u32 as core::iter::range::Step>::forward_unchecked
  %_6 = call i32 @_RNvXsH_NtNtCsl10jNU3mE6R_4core4iter5rangemNtB5_4Step17forward_uncheckedCslb9dB7bEmfm_4i128(i32 %old, i64 1) #22
  store i32 %_6, ptr %self, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %old, ptr %0, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %1 = load i32, ptr %_0, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  %3 = load i32, ptr %2, align 4
  %4 = insertvalue { i32, i32 } poison, i32 %1, 0
  %5 = insertvalue { i32, i32 } %4, i32 %3, 1
  ret { i32, i32 } %5
}

; <core::ops::range::Range<u128> as core::iter::range::RangeIteratorImpl>::spec_next
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs3_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeoENtB5_17RangeIteratorImpl9spec_nextCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr align 16 %self) unnamed_addr #0 !guid !397 {
start:
  %_4 = getelementptr inbounds i8, ptr %self, i64 16
  %_3.i = load i128, ptr %self, align 16
  %_4.i = load i128, ptr %_4, align 16
  %_0.i = icmp ult i128 %_3.i, %_4.i
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb5

bb2:                                              ; preds = %start
  %old = load i128, ptr %self, align 16
; call <u128 as core::iter::range::Step>::forward_unchecked
  %_6 = call i128 @_RNvXsN_NtNtCsl10jNU3mE6R_4core4iter5rangeoNtB5_4Step17forward_uncheckedCslb9dB7bEmfm_4i128(i128 %old, i64 1) #22
  store i128 %_6, ptr %self, align 16
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %old, ptr %0, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  ret void
}

; <core::ops::range::Range<u32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangemENtNtNtB7_6traits8iterator8Iterator4nextCslb9dB7bEmfm_4i128(ptr align 4 %self) unnamed_addr #0 !guid !398 {
start:
; call <core::ops::range::Range<u32> as core::iter::range::RangeIteratorImpl>::spec_next
  %0 = call { i32, i32 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangemENtB5_17RangeIteratorImpl9spec_nextCslb9dB7bEmfm_4i128(ptr align 4 %self) #22
  %_0.0 = extractvalue { i32, i32 } %0, 0
  %_0.1 = extractvalue { i32, i32 } %0, 1
  %1 = insertvalue { i32, i32 } poison, i32 %_0.0, 0
  %2 = insertvalue { i32, i32 } %1, i32 %_0.1, 1
  ret { i32, i32 } %2
}

; <core::ops::range::Range<u128> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeoENtNtNtB7_6traits8iterator8Iterator4nextCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr align 16 %self) unnamed_addr #0 !guid !399 {
start:
; call <core::ops::range::Range<u128> as core::iter::range::RangeIteratorImpl>::spec_next
  call void @_RNvXs3_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeoENtB5_17RangeIteratorImpl9spec_nextCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr align 16 %self) #22
  ret void
}

; <i128 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringnNtB5_8ToString9to_stringCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) unnamed_addr #0 !guid !400 {
start:
; call <i128 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1Q_NtCs7CppTae75M1_5alloc6stringnNtB6_12SpecToString14spec_to_stringCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) #22
  ret void
}

; <u128 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsE_NtCsl10jNU3mE6R_4core3numoNtNtNtB7_3str6traits7FromStr8from_strCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !401 {
start:
; call <u128>::from_str_radix
  call void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo14from_str_radixCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 10) #22
  ret void
}

; <u32 as core::iter::range::Step>::forward_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXsH_NtNtCsl10jNU3mE6R_4core4iter5rangemNtB5_4Step17forward_uncheckedCslb9dB7bEmfm_4i128(i32 %start1, i64 %n) unnamed_addr #0 !guid !402 {
start:
  %_3 = trunc i64 %n to i32
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <u32>::unchecked_add::precondition_check
  call void @_RNvNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_add18precondition_checkCslb9dB7bEmfm_4i128(i32 %start1, i32 %_3, ptr align 8 @alloc_33c781d4b73231c4b72218e776044e11) #26
  br label %_RNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_add.exit

_RNvMs6_NtCsl10jNU3mE6R_4core3numm13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i32 %start1, %_3
  ret i32 %_0.i
}

; <u128 as core::iter::range::Step>::forward_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvXsN_NtNtCsl10jNU3mE6R_4core4iter5rangeoNtB5_4Step17forward_uncheckedCslb9dB7bEmfm_4i128(i128 %start1, i64 %n) unnamed_addr #0 !guid !403 {
start:
  %_3 = zext i64 %n to i128
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #22
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <u128>::unchecked_add::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add18precondition_checkCslb9dB7bEmfm_4i128(i128 %start1, i128 %_3, ptr align 8 @alloc_33c781d4b73231c4b72218e776044e11) #26
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i128 %start1, %_3
  ret i128 %_0.i
}

; <core::option::Option<i128> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionnENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !404 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i128, ptr %self, align 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i128, ptr %1, align 16
  %_3 = trunc i128 %0 to i64
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %4, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.3)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <i128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !405 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !406 {
start:
  ret i8 0
}

; <u128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !407 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::from_output
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try11from_outputCslb9dB7bEmfm_4i128(i128 %x) unnamed_addr #0 !guid !408 {
start:
  ret i128 %x
}

; <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try6branchCslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !409 {
start:
  ret i128 %self
}

; <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCslb9dB7bEmfm_4i128(ptr %pointer) unnamed_addr #0 !guid !410 {
start:
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCslb9dB7bEmfm_4i128(ptr %pointer) #22
  ret ptr %_0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !411 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.4)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCslb9dB7bEmfm_4i128(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !412 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCslb9dB7bEmfm_4i128(ptr %unique) unnamed_addr #0 !guid !413 {
start:
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCslb9dB7bEmfm_4i128(ptr %unique) #22
  ret ptr %_0
}

; <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !414 {
start:
  %_3 = alloca [16 x i8], align 8
  %0 = load i8, ptr %self, align 1
  %_4 = zext i8 %0 to i64
  switch i64 %_4, label %bb1 [
    i64 0, label %bb7
    i64 1, label %bb6
    i64 2, label %bb5
    i64 3, label %bb4
    i64 4, label %bb3
    i64 5, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb7:                                              ; preds = %start
  store ptr @alloc_59ba7b9f7211443cd55a366616eef46a, ptr %_3, align 8, !captures !330
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %1, align 8
  br label %bb8

bb6:                                              ; preds = %start
  store ptr @alloc_00315c78e51d29fe6b3102a4c1ecf6ef, ptr %_3, align 8, !captures !330
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 12, ptr %2, align 8
  br label %bb8

bb5:                                              ; preds = %start
  store ptr @alloc_bd3a3f3879e0d5f64554753e977f58d4, ptr %_3, align 8, !captures !330
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %3, align 8
  br label %bb8

bb4:                                              ; preds = %start
  store ptr @alloc_0964bb2a4870637395c77a018495bd5c, ptr %_3, align 8, !captures !330
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %4, align 8
  br label %bb8

bb3:                                              ; preds = %start
  store ptr @alloc_6566120a3a17f930e960a0863fcbd591, ptr %_3, align 8, !captures !330
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %5, align 8
  br label %bb8

bb2:                                              ; preds = %start
  store ptr @alloc_6c17bac0c71cba42380f8445f4dcbd16, ptr %_3, align 8, !captures !330
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 14, ptr %6, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb3, %bb4, %bb5, %bb6, %bb7
  %7 = load ptr, ptr %_3, align 8
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = load i64, ptr %8, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %7, i64 %9)
  ret i1 %_0
}

; <u128 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXso_NtNtCsl10jNU3mE6R_4core3cmp5implsoNtB7_9PartialEq2eqCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 16 %other) unnamed_addr #0 !guid !415 {
start:
  %_3 = load i128, ptr %self, align 16
  %_4 = load i128, ptr %other, align 16
  %_0 = icmp eq i128 %_3, %_4
  ret i1 %_0
}

; <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #1 !guid !416 {
start:
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCslb9dB7bEmfm_4i128(ptr align 8 %self) #22
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCslb9dB7bEmfm_4i128(ptr %_3, i64 %_4) #22
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr %0, i64 %1) unnamed_addr #0 !guid !417 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_2 = select i1 %7, i64 1, i64 0
  %8 = trunc nuw i64 %_2 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %v.1 = load i64, ptr %9, align 8
  store ptr %v.0, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.1, ptr %10, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !418 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = trunc nuw i64 %_2 to i1
  br i1 %0, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %e.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %e.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %e.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v.0 = load ptr, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %v.1 = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %v.0, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 8
  store i64 %v.1, ptr %8, align 8
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr %0) unnamed_addr #0 !guid !419 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, alloc::collections::TryReserveError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultNtNtNtB7_5alloc6layout6LayoutNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !420 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = trunc nuw i64 %_2 to i1
  br i1 %0, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %e.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %e.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %e.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v.0 = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %v.1 = load i64, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v.0, ptr %7, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 8
  store i64 %v.1, ptr %8, align 8
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<usize, alloc::collections::TryReserveErrorKind> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultjNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindENtNtNtB7_3ops9try_trait3Try6branchCslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !421 {
start:
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load i64, ptr %3, align 8
  store i64 %e.0, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %e.1, ptr %4, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %v = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %6, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCslb9dB7bEmfm_4i128(ptr align 8 %0) unnamed_addr #0 !guid !422 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { ptr, i64 } { ptr null, i64 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !423 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  %1 = insertvalue { i64, i64 } poison, i64 %residual.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %residual.1, 1
  %_4.0 = extractvalue { i64, i64 } %2, 0
  %_4.1 = extractvalue { i64, i64 } %2, 1
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %_4.1, ptr %4, align 8
  store i64 1, ptr %_0, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualCslb9dB7bEmfm_4i128(i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !424 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  %1 = insertvalue { i64, i64 } poison, i64 %residual.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %residual.1, 1
  %_4.0 = extractvalue { i64, i64 } %2, 0
  %_4.1 = extractvalue { i64, i64 } %2, 1
  %3 = insertvalue { i64, i64 } poison, i64 %_4.0, 0
  %4 = insertvalue { i64, i64 } %3, i64 %_4.1, 1
  ret { i64, i64 } %4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::collections::TryReserveError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, alloc::collections::TryReserveErrorKind>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleNtBN_19TryReserveErrorKindEE13from_residualCslb9dB7bEmfm_4i128(i64 %residual.0, i64 %residual.1, ptr align 8 %0) unnamed_addr #0 !guid !425 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCslb9dB7bEmfm_4i128(i64 %residual.0, i64 %residual.1) #22
  %_4.0 = extractvalue { i64, i64 } %1, 0
  %_4.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_4.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_4.1, 1
  ret { i64, i64 } %3

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i128, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultnNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !426 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.5)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.3)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u128, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultoNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !427 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.5)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCslb9dB7bEmfm_4i128(ptr %_1) unnamed_addr #0 !guid !428 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCslb9dB7bEmfm_4i128(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !429 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cslb9dB7bEmfm_4i128(ptr align 8 %_1) #22
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <usize as core::cmp::Ord>::max
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxCslb9dB7bEmfm_4i128(i64 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !430 {
start:
  %_7 = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %other = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store i64 %0, ptr %self, align 8
  store i64 %1, ptr %other, align 8
  store i8 0, ptr %_7, align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_7, align 1
  store i8 1, ptr %_6, align 1
  %_3.i = load i64, ptr %other, align 8
  %_4.i = load i64, ptr %self, align 8
  %_0.i = icmp ult i64 %_3.i, %_4.i
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  %2 = load i64, ptr %other, align 8
  store i64 %2, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %3 = load i64, ptr %self, align 8
  store i64 %3, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %4 = load i8, ptr %_6, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb9, label %bb5

bb5:                                              ; preds = %bb9, %bb4
  %6 = load i8, ptr %_7, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb10, label %bb6

bb9:                                              ; preds = %bb4
  br label %bb5

bb6:                                              ; preds = %bb10, %bb5
  %8 = load i64, ptr %_0, align 8
  ret i64 %8

bb10:                                             ; preds = %bb5
  br label %bb6

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable
}

; <u128 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsG_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_6Binary3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <usize as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #8

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fshl.i128(i128, i128, i128) #10

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #11

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #8

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64, i64) unnamed_addr #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.umul.with.overflow.i128(i128, i128) #10

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #9

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #9

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #9

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #9

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.smul.with.overflow.i128(i128, i128) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptoui.sat.i128.f64(double) #10

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #9

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #9

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctlz.i128(i128, i1 immarg) #13

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #14

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i128(i128) #15

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #15

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.sadd.with.overflow.i128(i128, i128) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.ssub.with.overflow.i128(i128, i128) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.scmp.i8.i128(i128, i128) #10

; alloc::raw_vec::min_non_zero_cap
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCs7CppTae75M1_5alloc7raw_vec16min_non_zero_cap(i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctpop.i128(i128) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.bswap.i128(i128) #10

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.cttz.i128(i128, i1 immarg) #13

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #14

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #10

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #9

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #2

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #16

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #17

; __rustc::__rust_realloc
; Function Attrs: nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc14___rust_realloc(ptr allocptr, i64, i64 allocalign, i64) unnamed_addr #18

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #19

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #20

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #20

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; <u128>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMs0_NtNtCsl10jNU3mE6R_4core3fmt3numo4__fmt(i128, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <i128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #21 !guid !431 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECslb9dB7bEmfm_4i128(ptr @_RNvCslb9dB7bEmfm_4i1284main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #12 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #14 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #16 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #20 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #21 = { nonlazybind "target-cpu"="x86-64" }
attributes #22 = { inlinehint }
attributes #23 = { cold noreturn nounwind }
attributes #24 = { noreturn }
attributes #25 = { cold }
attributes #26 = { inlinehint nounwind }
attributes #27 = { noinline }
attributes #28 = { noinline noreturn }
attributes #29 = { nounwind }
attributes #30 = { noinline noreturn nounwind }

!llvm.module.flags = !{!122, !123, !124, !125}
!llvm.ident = !{!126}

!0 = !{i64 -5504693897185574227}
!1 = !{i64 6752566917541923232}
!2 = !{i64 7847232629089198816}
!3 = !{i64 125937071085065347}
!4 = !{i64 -8638602614924110649}
!5 = !{i64 -7886318423027894818}
!6 = !{i64 7630217150995860364}
!7 = !{i64 1020680681060563780}
!8 = !{i64 2213537651376554134}
!9 = !{i64 -1354938837574046042}
!10 = !{i64 -4247277369431281572}
!11 = !{i64 5466972635669489271}
!12 = !{i64 -1603777224916230544}
!13 = !{i64 -5318720045756851679}
!14 = !{i64 -1223774367015685877}
!15 = !{i64 -7804457772303051037}
!16 = !{i64 7736776545110476329}
!17 = !{i64 8814352253862276746}
!18 = !{i64 -711576951763271182}
!19 = !{i64 1655077548292016247}
!20 = !{i64 -8019968541310062606}
!21 = !{i64 -6671237027540693338}
!22 = !{i64 9141949013091343782}
!23 = !{i64 -102289616897861015}
!24 = !{i64 -4561311732411537725}
!25 = !{i64 4320267917774362211}
!26 = !{i64 4029192780990706030}
!27 = !{i64 4313470063300800488}
!28 = !{i64 -5904292005820464313}
!29 = !{i64 9182592716985847358}
!30 = !{i64 2621139890761912644}
!31 = !{i64 1164472438472999170}
!32 = !{i64 -6775695221895673146}
!33 = !{i64 -5783937569863468405}
!34 = !{i64 6324804995804271065}
!35 = !{i64 381663104455277784}
!36 = !{i64 5294425701984717739}
!37 = !{i64 6016094893395919676}
!38 = !{i64 1156484980504262487}
!39 = !{i64 2741173949608124718}
!40 = !{i64 5823623196161258838}
!41 = !{i64 -7038674602849191874}
!42 = !{i64 -3541236836230967418}
!43 = !{i64 5666103740960142760}
!44 = !{i64 3524325048052811794}
!45 = !{i64 -5443235764592138097}
!46 = !{i64 -7485225284348130659}
!47 = !{i64 -4874362705040308837}
!48 = !{i64 2742038786377397272}
!49 = !{i64 -8856903544814310078}
!50 = !{i64 4389298149047569244}
!51 = !{i64 -1696977061269714170}
!52 = !{i64 2896003813323068782}
!53 = !{i64 2617739013973170553}
!54 = !{i64 -734873990354616290}
!55 = !{i64 8083405798114603386}
!56 = !{i64 6431035652692163098}
!57 = !{i64 5461848096832508133}
!58 = !{i64 8498335066726945570}
!59 = !{i64 7499524784096672744}
!60 = !{i64 3381231479958041819}
!61 = !{i64 4914309827034416590}
!62 = !{i64 8789638200438548937}
!63 = !{i64 -3352847084774899118}
!64 = !{i64 -6368638773696634515}
!65 = !{i64 -3711640899804282496}
!66 = !{i64 6213796462077021821}
!67 = !{i64 2220140130186418304}
!68 = !{i64 -3497637513111938047}
!69 = !{i64 -6496656943393408572}
!70 = !{i64 4933240372002936109}
!71 = !{i64 2827035695710576269}
!72 = !{i64 6347535657384496578}
!73 = !{i64 -7788358913356250322}
!74 = !{i64 5820140113242579464}
!75 = !{i64 2153018311637797844}
!76 = !{i64 4194024590783851471}
!77 = !{i64 3909895086837711295}
!78 = !{i64 5793100086949913833}
!79 = !{i64 -6331533952870487899}
!80 = !{i64 6216902367197747878}
!81 = !{i64 7019944722228416005}
!82 = !{i64 978208654807939347}
!83 = !{i64 -2106040979431644288}
!84 = !{i64 3968122229295321819}
!85 = !{i64 169637462205761434}
!86 = !{i64 -2418670075217944104}
!87 = !{i64 -2676022159366810638}
!88 = !{i64 -255212478650594683}
!89 = !{i64 7238908997666299656}
!90 = !{i64 8649964467832584199}
!91 = !{i64 -8813953821391440040}
!92 = !{i64 -9051252685141791954}
!93 = !{i64 5231502563371885863}
!94 = !{i64 2018242790289851655}
!95 = !{i64 1383717064235074445}
!96 = !{i64 -8915881436601370661}
!97 = !{i64 -6052692538964347500}
!98 = !{i64 -44709400525586768}
!99 = !{i64 -1882264863922989975}
!100 = !{i64 2453619741872530016}
!101 = !{i64 -5630447775636923483}
!102 = !{i64 -4530439534836617547}
!103 = !{i64 -673729340857531339}
!104 = !{i64 -4338423467705606211}
!105 = !{i64 -3149269750772788059}
!106 = !{i64 -6412307801867740627}
!107 = !{i64 -4129257768837388422}
!108 = !{i64 6861954640173613936}
!109 = !{i64 -4125794123188860915}
!110 = !{i64 3303391139385051624}
!111 = !{i64 1532877386217578682}
!112 = !{i64 -350047851946602143}
!113 = !{i64 178530759724027648}
!114 = !{i64 2377040853097325163}
!115 = !{i64 6955328587174946077}
!116 = !{i64 -6376924656925392183}
!117 = !{i64 -9222684135370008792}
!118 = !{i64 8961300673733217444}
!119 = !{i64 -8225965804835979707}
!120 = !{i64 1466255506623189355}
!121 = !{i64 7143505685684016317}
!122 = !{i32 8, !"PIC Level", i32 2}
!123 = !{i32 7, !"PIE Level", i32 2}
!124 = !{i32 2, !"RtLibUseGOT", i32 1}
!125 = !{i32 7, !"uwtable", i32 2}
!126 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!127 = !{i64 -2991922311042110960}
!128 = !{i64 585311135357725558}
!129 = !{i64 -8870103787620194846}
!130 = !{i64 1323356795890958499}
!131 = !{i64 3828837081389482855}
!132 = !{i64 -4882793336336601282}
!133 = !{i64 969844502574687892}
!134 = !{i64 -2528439721320769821}
!135 = !{i64 1953160867878260456}
!136 = !{i64 7331280271857156628}
!137 = !{i64 -901166237010469562}
!138 = !{i64 1611489904889652125}
!139 = !{i64 1090468851588085383}
!140 = !{i64 -7272344199612585495}
!141 = !{i64 9015360776967343414}
!142 = !{i64 -1350338428696841391}
!143 = !{i64 -3042105124150388672}
!144 = !{i64 4421413679223968237}
!145 = !{i64 4692999918664995619}
!146 = !{i64 186760246293790864}
!147 = !{i64 -2178109646149567018}
!148 = !{i64 2725014548163139257}
!149 = !{i64 4158979729893124610}
!150 = !{i64 3374895279012775579}
!151 = !{i64 -6988999524817056993}
!152 = !{i64 8973047744386860681}
!153 = !{i64 -3092674888136446552}
!154 = !{i64 7573544871237015895}
!155 = !{i64 -3404906966565972928}
!156 = !{i64 6548037135677237056}
!157 = !{i64 -6315112795102890983}
!158 = !{i64 3752185764298195771}
!159 = !{i64 -2673148661828253913}
!160 = !{i64 6196364295072633550}
!161 = !{i64 1807092796163230982}
!162 = !{i64 -8258632049209629973}
!163 = !{i64 3579778875022924769}
!164 = !{i64 3080402152468764012}
!165 = !{i64 6916609482075893846}
!166 = !{i64 -6576830451758063193}
!167 = !{i64 7059196380874794888}
!168 = !{i64 1530774099763198639}
!169 = !{i64 5869777084600054588}
!170 = !{i64 9086094926634438059}
!171 = !{i64 -8392694924406615876}
!172 = !{i64 -1512061699151555852}
!173 = !{i64 -2889673728819534296}
!174 = !{i64 8450481708298575261}
!175 = !{i64 4435710001202477104}
!176 = !{i64 2142812589377718986}
!177 = !{i64 -9001284311249023809}
!178 = !{i64 -7288406837322929345}
!179 = !{i64 1321776185651715}
!180 = !{i64 -1434127206302617491}
!181 = !{i64 7722803374290433029}
!182 = !{i64 6330846467900472708}
!183 = !{i64 -7113522232649280429}
!184 = !{i64 6007201566191019413}
!185 = !{i64 106330428343651768}
!186 = !{i64 -1448557179587438354}
!187 = !{i64 -3216043656745227351}
!188 = !{i64 5749347204560013462}
!189 = !{i64 2030154868554862188}
!190 = !{i64 -8214304295343543608}
!191 = !{i64 8395763167902274750}
!192 = !{i64 7051847956661925544}
!193 = !{i64 3425455538182589460}
!194 = !{i64 -5606435753056509808}
!195 = !{i64 -1987608644671707466}
!196 = !{i64 -6751104438259772443}
!197 = !{i64 -7121960573821425818}
!198 = !{i64 455873936820647984}
!199 = !{i64 -1557367644103851620}
!200 = !{i64 -2239100070853427947}
!201 = !{i64 1628106762800104931}
!202 = !{i64 -9207548364177370796}
!203 = !{i64 328800606439207697}
!204 = !{i64 2003184415650660797}
!205 = !{i64 5358566147489511842}
!206 = !{i64 8330084808239917428}
!207 = !{i64 -8541027477092686323}
!208 = !{i64 6395502107592908680}
!209 = !{i64 48114793529133271}
!210 = !{i64 5263469266882668322}
!211 = !{i64 -6880113238942567523}
!212 = !{i64 -6796629583038610375}
!213 = !{i64 -8486700951829503781}
!214 = !{i64 5981772414110969816}
!215 = !{i64 7126805462135927585}
!216 = !{i64 -5733983537845537126}
!217 = !{i64 6687607179319565374}
!218 = !{i64 -3848605664371700503}
!219 = !{i64 -4475107560599991547}
!220 = !{i64 -6352878599930857752}
!221 = !{i64 3351973973926221406}
!222 = !{i64 -6340067191565900455}
!223 = !{i64 -8112849642922891872}
!224 = !{i64 -4997358689630128888}
!225 = !{i64 -1232401612173843496}
!226 = !{i64 1056083184233947210}
!227 = !{i64 8062028070597683262}
!228 = !{i64 8195999542980894475}
!229 = !{i64 -709770969861364437}
!230 = !{i64 -8093024213438022319}
!231 = !{i64 -4499177875000173825}
!232 = !{i64 4784035891537617364}
!233 = !{i64 1275211415580900949}
!234 = !{i64 -8276697029822544629}
!235 = !{i64 8136779421557579619}
!236 = !{i64 6163103156740984639}
!237 = !{i64 -5708152116883623265}
!238 = !{i64 -2050072904624349143}
!239 = !{i64 320957407498881098}
!240 = !{i64 -7816960670250185478}
!241 = !{i64 2584415077395198753}
!242 = !{i64 -6822964318315421311}
!243 = !{i64 -8669818880338080774}
!244 = !{i64 1249938117387614303}
!245 = !{i64 7023958939097285806}
!246 = !{i64 -5878306358064578595}
!247 = !{i64 -9056094388462203878}
!248 = !{i64 -4593032220451769039}
!249 = !{i64 -372412289339096955}
!250 = !{i64 -531284906966506500}
!251 = !{i64 7077480617778372224}
!252 = !{i64 6561710376786441409}
!253 = !{i64 -1878455871560344647}
!254 = !{i64 6151374798656605670}
!255 = !{i64 -6590435938624901381}
!256 = !{i64 -4973773027223566406}
!257 = !{i64 -6926280184076139406}
!258 = !{i64 3204721017260000939}
!259 = !{i64 -6679411355634689292}
!260 = !{i64 -1944585673585489819}
!261 = !{i64 5204632748568558884}
!262 = !{i64 5383353606073473255}
!263 = !{i64 -8434647121086863441}
!264 = !{i64 -239316847128127948}
!265 = !{i64 3530215624846591827}
!266 = !{i64 -1818608093644890482}
!267 = !{i64 -4973568810596850101}
!268 = !{i64 -1586224070611798225}
!269 = !{i64 5223092371004582194}
!270 = !{i64 -5376970516548650675}
!271 = !{i64 4041221715795211915}
!272 = !{i64 3402047986858214953}
!273 = !{i64 -4603308381507937192}
!274 = !{i64 1732262408393089001}
!275 = !{i64 -7502245149195895878}
!276 = !{i64 -111639495340608765}
!277 = !{i64 6311831465778937067}
!278 = !{i64 -3349207328239978334}
!279 = !{i64 -1962220828758079087}
!280 = !{i64 -4966491725462652815}
!281 = !{i64 -7507336023622571204}
!282 = !{i64 -243250026281964294}
!283 = !{i64 3309770453553324033}
!284 = !{i64 -8490550726926834086}
!285 = !{i64 -8773037305889849284}
!286 = !{i64 -6350536078702542174}
!287 = !{i64 -5293429588112912913}
!288 = !{i64 2354479160373909326}
!289 = !{i64 -9109130415284255480}
!290 = !{i64 -5435475631469033718}
!291 = !{i64 -209617849812936162}
!292 = !{i64 -1024768595243897889}
!293 = !{i64 -3909316003954290851}
!294 = !{i64 -3143360498099782013}
!295 = !{i64 6124554463058890679}
!296 = !{i64 6539916978496966581}
!297 = !{i64 2500814760873526606}
!298 = !{i64 -7164899003841707335}
!299 = !{i64 3362243549846705247}
!300 = !{i64 -4829202079141374528}
!301 = !{i64 8394700700522411731}
!302 = !{i64 -5407545295518691955}
!303 = !{i64 6612747044267193571}
!304 = !{i64 5951746671579909824}
!305 = !{i64 4293960430958432498}
!306 = !{i64 -136722870231102117}
!307 = !{i64 -4741017253340684770}
!308 = !{i64 81856571184526443}
!309 = !{i64 4556795124238671478}
!310 = !{i64 1961180970265101562}
!311 = !{i64 -8792607597251850711}
!312 = !{i64 3737003848858681062}
!313 = !{i64 -485992297852732083}
!314 = !{i64 -6864493140658332725}
!315 = !{i64 -8903409137812743645}
!316 = !{i64 -3134047189049861460}
!317 = !{i64 -2020584228562833288}
!318 = !{i64 1218575074543699017}
!319 = !{i64 4949777936541987610}
!320 = !{i64 590690473530643635}
!321 = !{i64 8648875566536733220}
!322 = !{i64 -6273046274682549452}
!323 = !{i64 7980362367074631991}
!324 = !{i64 -2274897278884099444}
!325 = !{i64 -1650509777500679757}
!326 = !{i64 -1882286531262582714}
!327 = !{i64 2774434022011205449}
!328 = !{i64 6468128081434734209}
!329 = !{i64 -7568976404740568073}
!330 = !{!"address", !"read_provenance"}
!331 = !{i64 -5651147833129662141}
!332 = !{i64 8898414684201759927}
!333 = !{i64 -2285121713773439624}
!334 = !{i64 3527239212556196050}
!335 = !{i64 6488505228987946827}
!336 = !{i64 -1862243179803704144}
!337 = !{i64 -3144924324497036011}
!338 = !{i64 -5325371034440708726}
!339 = !{i64 2285654900120358291}
!340 = !{i64 2125690859240722083}
!341 = !{i64 4096538876309327107}
!342 = !{i64 8519012007285547918}
!343 = !{i64 -3324026715539142511}
!344 = !{i64 458424633268215440}
!345 = !{i64 -1094465159319220672}
!346 = !{i64 885417762371061603}
!347 = !{i64 4563420228895993441}
!348 = !{i64 -5247383498413440841}
!349 = !{i64 -5224998623768612654}
!350 = !{i64 -2873522919608725279}
!351 = !{i64 2773850350876936276}
!352 = !{i64 7595259296949687461}
!353 = !{i64 -1802583778875648401}
!354 = !{i64 1007806758848636314}
!355 = !{i64 2588722639748621595}
!356 = !{i64 3765271484182261815}
!357 = !{i64 8819985125627084430}
!358 = !{i64 4227012187807247923}
!359 = !{i64 8866682881120574728}
!360 = !{i64 3248272663969836671}
!361 = !{i64 3133194369944357539}
!362 = !{i64 1676347423090413172}
!363 = !{i64 -4659452391694595671}
!364 = !{i64 -385091251504674648}
!365 = !{i64 -2721519049052113641}
!366 = !{i64 5841215528547501717}
!367 = !{i64 5532653616918875265}
!368 = !{i64 6985434325592613156}
!369 = !{i64 916446719708989976}
!370 = !{i64 -8550005910615132998}
!371 = !{i64 -7503029430204093795}
!372 = !{i64 2871571824572466875}
!373 = !{i64 5613854993393659907}
!374 = !{i64 -6564508401863674970}
!375 = !{i64 3873921205992667812}
!376 = !{i64 5391477751927308542}
!377 = !{i64 6972917599524438876}
!378 = !{i64 5601890870797923404}
!379 = !{i64 8287056593250608333}
!380 = !{i64 -2800470948186194984}
!381 = !{i64 -7530225640381037273}
!382 = !{i64 826193452808930088}
!383 = !{i64 -7416024777224754263}
!384 = !{i64 -8144940809170705026}
!385 = !{i64 6083676768253259582}
!386 = !{i64 7034946238154543456}
!387 = !{i64 6758357032049403828}
!388 = !{i64 220231776416442515}
!389 = !{i64 7418211837038245376}
!390 = !{i64 2988527435387182856}
!391 = !{i64 -150055213117969312}
!392 = !{i64 5968845039794563281}
!393 = !{i64 -2537770289531586439}
!394 = !{i64 -6707128592085258761}
!395 = !{i64 6074688574330298089}
!396 = !{i64 -7500049611423592977}
!397 = !{i64 -8224941131115502490}
!398 = !{i64 -7309056878835733229}
!399 = !{i64 7015310900092167666}
!400 = !{i64 -6684146104695323418}
!401 = !{i64 6702109726542682835}
!402 = !{i64 -7649390195942130191}
!403 = !{i64 1994678390763558876}
!404 = !{i64 7197725865025501073}
!405 = !{i64 -2541587727500646533}
!406 = !{i64 3514845597960991514}
!407 = !{i64 165798559502701585}
!408 = !{i64 7312570849407532261}
!409 = !{i64 2002459514283861933}
!410 = !{i64 -7963601549874304668}
!411 = !{i64 -3749985272951862212}
!412 = !{i64 4436775270683418286}
!413 = !{i64 1416531709050485260}
!414 = !{i64 -7288961631277087920}
!415 = !{i64 7273480327350717666}
!416 = !{i64 850072237623598676}
!417 = !{i64 -961922870207194432}
!418 = !{i64 3357189306162020144}
!419 = !{i64 -166126716185814333}
!420 = !{i64 -196623396617924060}
!421 = !{i64 -5077131151151993172}
!422 = !{i64 -470594574829387089}
!423 = !{i64 8494347710711398693}
!424 = !{i64 -1298725808339220270}
!425 = !{i64 -3441074504989051985}
!426 = !{i64 -2934153529646918790}
!427 = !{i64 -6821244322942678763}
!428 = !{i64 5366874049115495346}
!429 = !{i64 311657846183830845}
!430 = !{i64 -4353832274686317741}
!431 = !{i64 -2624081020897602054}
