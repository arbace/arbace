; ModuleID = 'i128.f6b1c69dd40f4262-cgu.0'
source_filename = "i128.f6b1c69dd40f4262-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCslb9dB7bEmfm_4i128, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cslb9dB7bEmfm_4i128, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cslb9dB7bEmfm_4i128 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_8df3287b4fbc190437d91041421e919b = private unnamed_addr constant [30 x i8] c"core/src/iter/traits/accum.rs\00", align 1, !guid !3
@alloc_a840ce68d073c0ef52d40243c1f57585 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8df3287b4fbc190437d91041421e919b, [16 x i8] c"\1D\00\00\00\00\00\00\00\CE\00\00\00\01\00\00\00" }>, align 8, !guid !4
@alloc_8fd7bd399161f6597fd9f4d41ee5911e = private unnamed_addr constant [28 x i8] c"test/rust/synthetic/i128.rs\00", align 1, !guid !5
@alloc_eef5a6daeaf4f66c4683c7d969887037 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\04\00\00\00W\00\00\00" }>, align 8, !guid !6
@alloc_a54b5d523418f9a473b9707e1bf3abdd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\06\00\00\00B\00\00\00" }>, align 8, !guid !7
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !8
@alloc_cde706cbfa574f07c7f055fef22170fe = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0C\00\00\00\1A\00\00\00" }>, align 8, !guid !9
@alloc_d8b1051dca4ca82a457e3b6bfe42d861 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0C\00\00\00!\00\00\00" }>, align 8, !guid !10
@alloc_98b2cc77e91e94d24c695c6a061c28c0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0C\00\00\00*\00\00\00" }>, align 8, !guid !11
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !12
@alloc_5fa04f97916bd874a7a88690ee4d2c7f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0D\00\00\00\17\00\00\00" }>, align 8, !guid !13
@alloc_d4d899166b4141918c2da3e256b7165b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\0F\00\00\00\1C\00\00\00" }>, align 8, !guid !14
@alloc_59b8058f47772d03e6bfab57ce0a41ae = private unnamed_addr constant [11 x i8] c"\C0\01 \C1 \00\80`\01\0A\00", align 1, !guid !15
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !16
@alloc_ce0acdd4a4f94c66b265f4ef543b4ab6 = private unnamed_addr constant [39 x i8] c"340282366920938463463374607431768211455", align 1, !guid !17
@alloc_941090dbc54b31f562723ae1638c2086 = private unnamed_addr constant [39 x i8] c"340282366920938463463374607431768211456", align 1, !guid !18
@alloc_860d53ce49325a3fa4c8ce10cb01a0c4 = private unnamed_addr constant [3 x i8] c"-zz", align 1, !guid !19
@alloc_b7cbb96fa2fbc2c33cfdce3b367921a6 = private unnamed_addr constant [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\80", align 16, !guid !20
@alloc_0407da499bd3b5ae40bf7d4f7ff05b0b = private unnamed_addr constant [16 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\7F", align 16, !guid !21
@alloc_e4959e06482677e63dd48c2a86fcf0e7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00!\00\00\00\16\00\00\00" }>, align 8, !guid !22
@alloc_744d897956c077d5b9b7148f78bfe5aa = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\1D\00\00\00m\00\00\00" }>, align 8, !guid !23
@alloc_b14d820ee55f823d3aefb1afa0d7eac6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\05\00\00\008\00\00\00" }>, align 8, !guid !24
@alloc_a7299c6c6510c3de3e014799b32a1fb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\05\00\00\00c\00\00\00" }>, align 8, !guid !25
@alloc_83736e0ed8986abd3fb627960735e4af = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\05\00\00\00^\00\00\00" }>, align 8, !guid !26
@alloc_68c3021501d9c8f06b4083bb56ba3908 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\07\00\00\00G\00\00\00" }>, align 8, !guid !27
@alloc_c27fb0410a6c5898f903969645269014 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\07\00\00\00q\00\00\00" }>, align 8, !guid !28
@alloc_b711721f7bfa298d55b2bdbe61d56fe1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fd7bd399161f6597fd9f4d41ee5911e, [16 x i8] c"\1B\00\00\00\00\00\00\00\07\00\00\00\82\00\00\00" }>, align 8, !guid !29
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !30
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !31
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !32
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !33
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !34
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !35
@alloc_d60754359a0b1c5bd37a3b37b82a8a1d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\DF\01\00\00\05\00\00\00" }>, align 8, !guid !36
@alloc_c2df0f2eed0ee910e76dda7517cc7a45 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\05\00\00\05\00\00\00" }>, align 8, !guid !37
@alloc_5aa1d1250638a5285856df0c8e3018a3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00K\07\00\00\01\00\00\00" }>, align 8, !guid !38
@alloc_95d8d5f2b11616ba93f9dc409471c349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00J\07\00\00\01\00\00\00" }>, align 8, !guid !39
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !40
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !41
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !42
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !43
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !44
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !45
@alloc_a61ecf1bbb59a9a75a6a223b3f565d28 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: i128::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !46
@alloc_0a7ace845dda78b0b3e088b89fa358fb = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: u128::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !47
@alloc_8efb6cb47e437ad05e23651986f609b7 = private unnamed_addr constant [185 x i8] c"unsafe precondition(s) violated: u128::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !48
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRoNtB6_5Debug3fmtCslb9dB7bEmfm_4i128 }>, align 8, !guid !49
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCslb9dB7bEmfm_4i128 }>, align 8, !guid !50
@alloc_f764952b50ffad1fb52cf6916450b6b7 = private unnamed_addr constant [23 x i8] c"core/src/iter/range.rs\00", align 1, !guid !51
@alloc_33c781d4b73231c4b72218e776044e11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f764952b50ffad1fb52cf6916450b6b7, [16 x i8] c"\16\00\00\00\00\00\00\00$\02\00\00\01\00\00\00" }>, align 8, !guid !52
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !53
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !54
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRnNtB6_5Debug3fmtCslb9dB7bEmfm_4i128 }>, align 8, !guid !55
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !56
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !57
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !58
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !59
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !60
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCslb9dB7bEmfm_4i128 }>, align 8, !guid !61

; <str>::parse::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseoECslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !67 {
start:
; call <u128 as core::str::traits::FromStr>::from_str
  call void @_RNvXsE_NtCsl10jNU3mE6R_4core3numoNtNtNtB7_3str6traits7FromStr8from_strCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %self.0, i64 %self.1) #16
  ret void
}

; <core::fmt::rt::Argument>::new_binary::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !68 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #16
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsG_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !69 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCslb9dB7bEmfm_4i128(ptr align 8 %x) #16
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECslb9dB7bEmfm_4i128(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !70 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCslb9dB7bEmfm_4i128(ptr align 4 %x) #16
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECslb9dB7bEmfm_4i128(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !71 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #16
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECslb9dB7bEmfm_4i128(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !72 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #16
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !73 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<i128>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionnEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #16
; call <core::ptr::non_null::NonNull<core::option::Option<i128>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionnEE4castuECslb9dB7bEmfm_4i128(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionnENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i128, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultnNtNtNtB7_3num5error13ParseIntErrorEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !74 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultnNtNtNtB9_3num5error13ParseIntErrorEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #16
; call <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultnNtNtNtBa_3num5error13ParseIntErrorEE4castuECslb9dB7bEmfm_4i128(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultnNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<u128, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultoNtNtNtB7_3num5error13ParseIntErrorEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !75 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultoNtNtNtB9_3num5error13ParseIntErrorEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #16
; call <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultoNtNtNtBa_3num5error13ParseIntErrorEE4castuECslb9dB7bEmfm_4i128(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultoNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(u128, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTobEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !76 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(u128, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTobEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %x) #16
; call <core::ptr::non_null::NonNull<(u128, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTobEE4castuECslb9dB7bEmfm_4i128(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTobENtB6_5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !77 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCslb9dB7bEmfm_4i128(ptr %x) #16
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECslb9dB7bEmfm_4i128(ptr %_4) #16
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCslb9dB7bEmfm_4i128, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB7_4iter6traits5accumoNtB1s_7Product7productINtNtB5_5range14RangeInclusiveoEE0ECslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !78 {
start:
  ret void
}

; <core::ptr::non_null::NonNull<core::option::Option<i128>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionnEE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !79 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultnNtNtNtBa_3num5error13ParseIntErrorEE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !80 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultoNtNtNtBa_3num5error13ParseIntErrorEE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !81 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<(u128, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTobEE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !82 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !83 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !84 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !85 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !86 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECslb9dB7bEmfm_4i128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !87 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<11, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj2_ECslb9dB7bEmfm_4i128(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !88 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECslb9dB7bEmfm_4i128(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !89 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u128>
; Function Attrs: nounwind nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftoECslb9dB7bEmfm_4i128(i128 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !90 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 16 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i128
  %_0 = call i128 @llvm.fshl.i128(i128 %x, i128 %x, i128 %1)
  ret i128 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #18
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::is_val_statically_known::<i128>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownnECslb9dB7bEmfm_4i128(i128 %_arg) unnamed_addr #2 !guid !91 {
start:
  ret i1 false
}

; core::mem::replace::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core3mem7replaceoECslb9dB7bEmfm_4i128(ptr align 16 %dest, i128 %src) unnamed_addr #0 !guid !92 {
start:
  %result = load i128, ptr %dest, align 16
  store i128 %src, ptr %dest, align 16
  ret i128 %result
}

; core::hint::black_box::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECslb9dB7bEmfm_4i128(double %dummy) unnamed_addr #0 !guid !93 {
start:
  %_0 = alloca [8 x i8], align 8
  store double %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !94
  %0 = load double, ptr %_0, align 8
  ret double %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECslb9dB7bEmfm_4i128(i32 %dummy) unnamed_addr #0 !guid !95 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !94
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 %dummy) unnamed_addr #0 !guid !96 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !94
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; core::hint::black_box::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 %dummy) unnamed_addr #0 !guid !97 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !94
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECslb9dB7bEmfm_4i128(i64 %dummy) unnamed_addr #0 !guid !98 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !94
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECslb9dB7bEmfm_4i128(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !99 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCslb9dB7bEmfm_4i128(ptr %f) #16
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #16
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u128 as core::iter::traits::accum::Product>::product::<core::ops::range::RangeInclusive<u128>>
; Function Attrs: nonlazybind uwtable
define internal i128 @_RINvXsH_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumoNtB6_7Product7productINtNtNtBc_3ops5range14RangeInclusiveoEECslb9dB7bEmfm_4i128(ptr align 16 %iter) unnamed_addr #1 !guid !100 {
start:
  %0 = alloca [48 x i8], align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %iter, i64 48, i1 false)
; call <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::fold::<u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>
  %_0 = call i128 @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtNtNtB8_6traits8iterator8Iterator4foldoNCINvXsH_NtB1k_5accumoNtB23_7Product7productBE_E0ECslb9dB7bEmfm_4i128(ptr align 16 %0, i128 1) #16
  ret i128 %_0
}

; <core::ops::range::RangeInclusive<u128> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<u128, <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<u128>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtB6_26RangeInclusiveIteratorImpl13spec_try_foldoNCINvMNtBJ_9try_traitINtB29_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtB8_6traits5accumoNtB3d_7Product7productBE_E0E0B2o_ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !101 {
start:
  %_37 = alloca [1 x i8], align 1
  %_36 = alloca [1 x i8], align 1
  %_26 = alloca [16 x i8], align 16
  %_15 = alloca [16 x i8], align 16
  %accum = alloca [16 x i8], align 16
  %_0 = alloca [16 x i8], align 16
  %f = alloca [0 x i8], align 1
  store i8 0, ptr %_37, align 1
  store i8 0, ptr %_36, align 1
  store i8 1, ptr %_37, align 1
; call <core::ops::range::RangeInclusive<u128>>::is_empty
  %_4 = call zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusiveoE8is_emptyCslb9dB7bEmfm_4i128(ptr align 16 %self) #16
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
  store i8 1, ptr %_36, align 1
  store i128 %init, ptr %accum, align 16
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::from_output
  %0 = call i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try11from_outputCslb9dB7bEmfm_4i128(i128 %init) #16
  store i128 %0, ptr %_0, align 16
  br label %bb32

bb4:                                              ; preds = %bb12, %bb3
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
  %_3.i = load i128, ptr %self, align 16
  %_4.i = load i128, ptr %_10, align 16
  %_0.i = icmp ult i128 %_3.i, %_4.i
  br label %bb5

bb5:                                              ; preds = %bb4
  br i1 %_0.i, label %bb6, label %bb14

bb14:                                             ; preds = %bb5
  %1 = getelementptr inbounds i8, ptr %self, i64 32
  store i8 1, ptr %1, align 16
  %_25 = getelementptr inbounds i8, ptr %self, i64 16
; call <u128 as core::cmp::PartialEq>::eq
  %_23 = call zeroext i1 @_RNvXso_NtNtCsl10jNU3mE6R_4core3cmp5implsoNtB7_9PartialEq2eqCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 16 %_25) #16
  br label %bb15

bb6:                                              ; preds = %bb5
  %_12 = load i128, ptr %self, align 16
; call <u128 as core::iter::range::Step>::forward_unchecked
  %n = call i128 @_RNvXsN_NtNtCsl10jNU3mE6R_4core4iter5rangeoNtB5_4Step17forward_uncheckedCslb9dB7bEmfm_4i128(i128 %_12, i64 1) #16
  br label %bb7

bb15:                                             ; preds = %bb14
  br i1 %_23, label %bb16, label %bb21

bb21:                                             ; preds = %bb19, %bb15
  store i8 0, ptr %_36, align 1
  %_35 = load i128, ptr %accum, align 16
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::from_output
  %2 = call i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try11from_outputCslb9dB7bEmfm_4i128(i128 %_35) #16
  store i128 %2, ptr %_0, align 16
  br label %bb22

bb16:                                             ; preds = %bb15
  store i8 0, ptr %_36, align 1
  %_30 = load i128, ptr %accum, align 16
  %_31 = load i128, ptr %self, align 16
; call <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}
  %_27 = call i128 @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB9_4iter6traits5accumoNtB1u_7Product7productINtNtB7_5range14RangeInclusiveoEE0E0Cslb9dB7bEmfm_4i128(ptr %f, i128 %_30, i128 %_31) #16
  br label %bb17

bb17:                                             ; preds = %bb16
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::branch
  %3 = call i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try6branchCslb9dB7bEmfm_4i128(i128 %_27) #16
  store i128 %3, ptr %_26, align 16
  br label %bb18

bb18:                                             ; preds = %bb17
  %4 = load i128, ptr %_26, align 16
  br label %bb19

bb19:                                             ; preds = %bb18
  %val = load i128, ptr %_26, align 16
  store i8 1, ptr %_36, align 1
  store i128 %val, ptr %accum, align 16
  br label %bb21

bb22:                                             ; preds = %bb21
  store i8 0, ptr %_36, align 1
  br label %bb25

bb25:                                             ; preds = %bb24, %bb22
  %5 = load i128, ptr %_0, align 16
  ret i128 %5

bb20:                                             ; No predecessors!
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
  %6 = call i128 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCslb9dB7bEmfm_4i128() #16
  store i128 %6, ptr %_0, align 16
  br label %bb34

bb34:                                             ; preds = %bb20
  br label %bb23

bb23:                                             ; preds = %bb33, %bb34
  store i8 0, ptr %_36, align 1
  br label %bb24

bb7:                                              ; preds = %bb6
; call core::mem::replace::<u128>
  %n1 = call i128 @_RINvNtCsl10jNU3mE6R_4core3mem7replaceoECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %n) #16
  br label %bb8

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_36, align 1
  %_19 = load i128, ptr %accum, align 16
; call <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}
  %_16 = call i128 @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB9_4iter6traits5accumoNtB1u_7Product7productINtNtB7_5range14RangeInclusiveoEE0E0Cslb9dB7bEmfm_4i128(ptr %f, i128 %_19, i128 %n1) #16
  br label %bb9

bb9:                                              ; preds = %bb8
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::branch
  %7 = call i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try6branchCslb9dB7bEmfm_4i128(i128 %_16) #16
  store i128 %7, ptr %_15, align 16
  br label %bb10

bb10:                                             ; preds = %bb9
  %8 = load i128, ptr %_15, align 16
  br label %bb12

bb12:                                             ; preds = %bb10
  %val2 = load i128, ptr %_15, align 16
  store i8 1, ptr %_36, align 1
  store i128 %val2, ptr %accum, align 16
  br label %bb4

bb13:                                             ; No predecessors!
; call <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
  %9 = call i128 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCslb9dB7bEmfm_4i128() #16
  store i128 %9, ptr %_0, align 16
  br label %bb33

bb33:                                             ; preds = %bb13
  br label %bb23

bb24:                                             ; preds = %bb32, %bb23
  br label %bb25

bb11:                                             ; No predecessors!
  unreachable

bb32:                                             ; preds = %bb2
  br label %bb24

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable

bb28:                                             ; No predecessors!
  unreachable

bb29:                                             ; No predecessors!
  unreachable

bb30:                                             ; No predecessors!
  unreachable

bb31:                                             ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::fold::<u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtNtNtB8_6traits8iterator8Iterator4foldoNCINvXsH_NtB1k_5accumoNtB23_7Product7productBE_E0ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !102 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
; call <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB7_4iter6traits5accumoNtB1s_7Product7productINtNtB5_5range14RangeInclusiveoEE0ECslb9dB7bEmfm_4i128() #16
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_8, align 1
; call <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::try_fold::<u128, <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<u128>>
  %_4 = call i128 @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtNtNtB8_6traits8iterator8Iterator8try_foldoNCINvMNtBJ_9try_traitINtB24_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtB1k_5accumoNtB38_7Product7productBE_E0E0B2j_ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) #16
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  ret i128 %_4

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::try_fold::<u128, <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<u128>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtNtNtB8_6traits8iterator8Iterator8try_foldoNCINvMNtBJ_9try_traitINtB24_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtB1k_5accumoNtB38_7Product7productBE_E0E0B2j_ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) unnamed_addr #0 !guid !103 {
start:
; call <core::ops::range::RangeInclusive<u128> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<u128, <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<u128>>
  %_0 = call i128 @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusiveoENtB6_26RangeInclusiveIteratorImpl13spec_try_foldoNCINvMNtBJ_9try_traitINtB29_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtB8_6traits5accumoNtB3d_7Product7productBE_E0E0B2o_ECslb9dB7bEmfm_4i128(ptr align 16 %self, i128 %init) #16
  ret i128 %_0
}

; <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::product::<u128>
; Function Attrs: nonlazybind uwtable
define internal i128 @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusiveoENtNtNtNtBa_4iter6traits8iterator8Iterator7productoECslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #1 !guid !104 {
start:
  %0 = alloca [48 x i8], align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %self, i64 48, i1 false)
; call <u128 as core::iter::traits::accum::Product>::product::<core::ops::range::RangeInclusive<u128>>
  %_0 = call i128 @_RINvXsH_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumoNtB6_7Product7productINtNtNtBc_3ops5range14RangeInclusiveoEECslb9dB7bEmfm_4i128(ptr align 16 %0)
  ret i128 %_0
}

; <core::ops::try_trait::NeverShortCircuit<u128>>::wrap_mut_2::<u128, u128, <u128 as core::iter::traits::accum::Product>::product<core::ops::range::RangeInclusive<u128>>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoE10wrap_mut_2ooNCINvXsH_NtNtNtB9_4iter6traits5accumoNtB1u_7Product7productINtNtB7_5range14RangeInclusiveoEE0E0Cslb9dB7bEmfm_4i128(ptr %_1, i128 %a, i128 %b) unnamed_addr #0 !guid !105 {
start:
; call <u128 as core::iter::traits::accum::Product>::product::<core::ops::range::RangeInclusive<u128>>::{closure#0}
  %_4 = call i128 @_RNCINvXsH_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumoNtB8_7Product7productINtNtNtBe_3ops5range14RangeInclusiveoEE0Cslb9dB7bEmfm_4i128(ptr %_1, i128 %a, i128 %b) #16
  ret i128 %_4
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cslb9dB7bEmfm_4i128(ptr align 8 %_1) unnamed_addr #0 !guid !106 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECslb9dB7bEmfm_4i128(ptr %_4) #19
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCslb9dB7bEmfm_4i128() #16
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cslb9dB7bEmfm_4i128(i8 %_2) #16
  ret i32 %_0
}

; <u128 as core::iter::traits::accum::Product>::product::<core::ops::range::RangeInclusive<u128>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNCINvXsH_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumoNtB8_7Product7productINtNtNtBe_3ops5range14RangeInclusiveoEE0Cslb9dB7bEmfm_4i128(ptr %_1, i128 %a, i128 %b) unnamed_addr #0 !guid !107 {
start:
  %0 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %a, i128 %b)
  %_4.0 = extractvalue { i128, i1 } %0, 0
  %_4.1 = extractvalue { i128, i1 } %0, 1
  br i1 %_4.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i128 %_4.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_a840ce68d073c0ef52d40243c1f57585) #20
  unreachable
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCslb9dB7bEmfm_4i128(ptr %_1) unnamed_addr #0 !guid !108 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCslb9dB7bEmfm_4i128(ptr %0) #16
  ret i32 %_0
}

; i128::fib
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1283fib(i32 %n) unnamed_addr #1 !guid !109 {
start:
  %iter = alloca [8 x i8], align 4
  %b = alloca [16 x i8], align 16
  %a = alloca [16 x i8], align 16
  store i128 0, ptr %a, align 16
  store i128 1, ptr %b, align 16
; call <core::ops::range::Range<u32> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { i32, i32 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangemENtB2_12IntoIterator9into_iterCsddYV2PBJW9h_3std(i32 0, i32 %n) #16
  %_5.0 = extractvalue { i32, i32 } %0, 0
  %_5.1 = extractvalue { i32, i32 } %0, 1
  store i32 %_5.0, ptr %iter, align 4
  %1 = getelementptr inbounds i8, ptr %iter, i64 4
  store i32 %_5.1, ptr %1, align 4
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::ops::range::Range<u32> as core::iter::traits::iterator::Iterator>::next
  %2 = call { i32, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangemENtNtNtB7_6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 4 %iter) #16
  %_8.0 = extractvalue { i32, i32 } %2, 0
  %_8.1 = extractvalue { i32, i32 } %2, 1
  %_10 = zext i32 %_8.0 to i64
  %3 = trunc nuw i64 %_10 to i1
  br i1 %3, label %bb5, label %bb6

bb5:                                              ; preds = %bb2
  %_12 = load i128, ptr %a, align 16
  %_13 = load i128, ptr %b, align 16
  %_14.0 = add i128 %_12, %_13
  %_14.1 = icmp ult i128 %_14.0, %_12
  br i1 %_14.1, label %panic, label %bb7

bb6:                                              ; preds = %bb2
  %_0 = load i128, ptr %a, align 16
  ret i128 %_0

bb7:                                              ; preds = %bb5
  %_15 = load i128, ptr %b, align 16
  store i128 %_15, ptr %a, align 16
  store i128 %_14.0, ptr %b, align 16
  br label %bb2

panic:                                            ; preds = %bb5
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_eef5a6daeaf4f66c4683c7d969887037) #20
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; i128::gcd
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1283gcd(i128 %a, i128 %b) unnamed_addr #1 !guid !110 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp eq i128 %b, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_5 = icmp eq i128 %b, 0
  br i1 %_5, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i128 %a, ptr %_0, align 16
  br label %bb4

bb3:                                              ; preds = %bb2
  %_4 = urem i128 %a, %b
; call i128::gcd
  %0 = call i128 @_RNvCslb9dB7bEmfm_4i1283gcd(i128 %b, i128 %_4)
  store i128 %0, ptr %_0, align 16
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_a54b5d523418f9a473b9707e1bf3abdd) #20
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; i128::fact
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1284fact(i32 %n) unnamed_addr #1 !guid !111 {
start:
  %_2 = alloca [48 x i8], align 16
  %_3 = zext i32 %n to i128
; call <core::ops::range::RangeInclusive<u128>>::new
  call void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusiveoE3newCslb9dB7bEmfm_4i128(ptr sret([48 x i8]) align 16 %_2, i128 1, i128 %_3) #16
; call <core::ops::range::RangeInclusive<u128> as core::iter::traits::iterator::Iterator>::product::<u128>
  %_0 = call i128 @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusiveoENtNtNtNtBa_4iter6traits8iterator8Iterator7productoECslb9dB7bEmfm_4i128(ptr align 16 %_2)
  ret i128 %_0
}

; i128::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCslb9dB7bEmfm_4i1284main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !112 {
start:
  %0 = alloca [32 x i8], align 16
  %1 = alloca [16 x i8], align 8
  %_319 = alloca [16 x i8], align 8
  %args21 = alloca [16 x i8], align 8
  %_310 = alloca [32 x i8], align 16
  %_303 = alloca [16 x i8], align 8
  %_302 = alloca [16 x i8], align 8
  %args20 = alloca [32 x i8], align 8
  %_300 = alloca [16 x i8], align 16
  %_298 = alloca [4 x i8], align 4
  %_291 = alloca [16 x i8], align 8
  %args19 = alloca [16 x i8], align 8
  %_285 = alloca [4 x i8], align 4
  %_278 = alloca [16 x i8], align 8
  %args18 = alloca [16 x i8], align 8
  %_264 = alloca [32 x i8], align 16
  %iter = alloca [32 x i8], align 16
  %acc = alloca [16 x i8], align 16
  %_256 = alloca [16 x i8], align 8
  %_255 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_252 = alloca [16 x i8], align 16
  %x = alloca [16 x i8], align 16
  %_231 = alloca [16 x i8], align 8
  %_230 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_227 = alloca [16 x i8], align 16
  %_224 = alloca [16 x i8], align 16
  %_217 = alloca [16 x i8], align 8
  %_216 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_213 = alloca [16 x i8], align 16
  %_210 = alloca [16 x i8], align 16
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_199 = alloca [24 x i8], align 8
  %_197 = alloca [8 x i8], align 8
  %_189 = alloca [16 x i8], align 8
  %args13 = alloca [16 x i8], align 8
  %_186 = alloca [32 x i8], align 16
  %_179 = alloca [16 x i8], align 8
  %_178 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_175 = alloca [32 x i8], align 16
  %_173 = alloca [1 x i8], align 1
  %_170 = alloca [32 x i8], align 16
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args11 = alloca [32 x i8], align 8
  %_156 = alloca [16 x i8], align 16
  %_150 = alloca [16 x i8], align 16
  %_143 = alloca [16 x i8], align 8
  %_142 = alloca [16 x i8], align 8
  %args10 = alloca [32 x i8], align 8
  %_139 = alloca [16 x i8], align 16
  %_136 = alloca [8 x i8], align 8
  %_129 = alloca [16 x i8], align 8
  %_128 = alloca [16 x i8], align 8
  %_127 = alloca [16 x i8], align 8
  %args9 = alloca [48 x i8], align 8
  %_124 = alloca [4 x i8], align 4
  %_118 = alloca [4 x i8], align 4
  %_116 = alloca [4 x i8], align 4
  %args8 = alloca [24 x i8], align 8
  %_109 = alloca [16 x i8], align 8
  %args7 = alloca [16 x i8], align 8
  %_104 = alloca [16 x i8], align 16
  %_97 = alloca [16 x i8], align 8
  %_96 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_92 = alloca [16 x i8], align 16
  %_88 = alloca [16 x i8], align 16
  %_81 = alloca [16 x i8], align 8
  %_80 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_75 = alloca [16 x i8], align 16
  %_71 = alloca [16 x i8], align 16
  %_64 = alloca [16 x i8], align 8
  %_63 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_60 = alloca [32 x i8], align 16
  %_58 = alloca [32 x i8], align 16
  %_51 = alloca [16 x i8], align 8
  %_50 = alloca [16 x i8], align 8
  %args3 = alloca [32 x i8], align 8
  %_48 = alloca [16 x i8], align 16
  %_44 = alloca [16 x i8], align 16
  %_37 = alloca [16 x i8], align 8
  %_36 = alloca [16 x i8], align 8
  %_35 = alloca [16 x i8], align 8
  %args2 = alloca [48 x i8], align 8
  %_33 = alloca [16 x i8], align 16
  %_27 = alloca [16 x i8], align 16
  %_21 = alloca [16 x i8], align 16
  %args1 = alloca [24 x i8], align 8
  %_12 = alloca [16 x i8], align 8
  %_11 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_8 = alloca [16 x i8], align 16
  %_5 = alloca [16 x i8], align 16
; call core::hint::black_box::<u32>
  %_6 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECslb9dB7bEmfm_4i128(i32 34) #16
; call i128::fact
  %2 = call i128 @_RNvCslb9dB7bEmfm_4i1284fact(i32 %_6)
  store i128 %2, ptr %_5, align 16
; call core::hint::black_box::<u32>
  %_9 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECslb9dB7bEmfm_4i128(i32 180) #16
; call i128::fib
  %3 = call i128 @_RNvCslb9dB7bEmfm_4i1283fib(i32 %_9)
  store i128 %3, ptr %_8, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_11, ptr align 16 %_5) #16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_12, ptr align 16 %_8) #16
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_11, i64 16, i1 false)
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_12, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %6 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args) #16
  %_2.0 = extractvalue { ptr, ptr } %6, 0
  %_2.1 = extractvalue { ptr, ptr } %6, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<i128>
  %a = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 -170141183460469231731687303715884105727) #16
; call core::hint::black_box::<i128>
  %b = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 1234567890123456789012345678) #16
  %_22 = icmp eq i128 %b, 0
  br i1 %_22, label %panic, label %bb11

bb11:                                             ; preds = %start
  %_23 = icmp eq i128 %b, -1
  %_24 = icmp eq i128 %a, -170141183460469231731687303715884105728
  %_25 = and i1 %_23, %_24
  br i1 %_25, label %panic22, label %bb12

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cde706cbfa574f07c7f055fef22170fe) #20
  unreachable

bb12:                                             ; preds = %bb11
  %7 = sdiv i128 %a, %b
  store i128 %7, ptr %_21, align 16
  %_28 = icmp eq i128 %b, 0
  br i1 %_28, label %panic23, label %bb13

panic22:                                          ; preds = %bb11
; call core::panicking::panic_const::panic_const_div_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_cde706cbfa574f07c7f055fef22170fe) #20
  unreachable

bb13:                                             ; preds = %bb12
  %_29 = icmp eq i128 %b, -1
  %_30 = icmp eq i128 %a, -170141183460469231731687303715884105728
  %_31 = and i1 %_29, %_30
  br i1 %_31, label %panic24, label %bb14

panic23:                                          ; preds = %bb12
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_d8b1051dca4ca82a457e3b6bfe42d861) #20
  unreachable

bb14:                                             ; preds = %bb13
  %8 = srem i128 %a, %b
  store i128 %8, ptr %_27, align 16
; call <i128>::rem_euclid
  %9 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10rem_euclidCslb9dB7bEmfm_4i128(i128 %a, i128 %b, ptr align 8 @alloc_98b2cc77e91e94d24c695c6a061c28c0) #16
  store i128 %9, ptr %_33, align 16
  store ptr %_21, ptr %args1, align 8
  %10 = getelementptr inbounds i8, ptr %args1, i64 8
  store ptr %_27, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args1, i64 16
  store ptr %_33, ptr %11, align 8
  %_324 = load ptr, ptr %args1, align 8
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_35, ptr align 16 %_324) #16
  %12 = getelementptr inbounds i8, ptr %args1, i64 8
  %_325 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_36, ptr align 16 %_325) #16
  %13 = getelementptr inbounds i8, ptr %args1, i64 16
  %_326 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_37, ptr align 16 %_326) #16
  %14 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %14, ptr align 8 %_35, i64 16, i1 false)
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_36, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_37, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %17 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECslb9dB7bEmfm_4i128(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args2) #16
  %_18.0 = extractvalue { ptr, ptr } %17, 0
  %_18.1 = extractvalue { ptr, ptr } %17, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_18.0, ptr %_18.1)
; call core::hint::black_box::<i128>
  %_45 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 100000000) #16
  %18 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %b, i128 %_45)
  %_46.0 = extractvalue { i128, i1 } %18, 0
  %_46.1 = extractvalue { i128, i1 } %18, 1
  br i1 %_46.1, label %panic25, label %bb22

panic24:                                          ; preds = %bb13
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_d8b1051dca4ca82a457e3b6bfe42d861) #20
  unreachable

bb22:                                             ; preds = %bb14
  store i128 %_46.0, ptr %_44, align 16
  %_0.i = mul i128 %b, %b
  store i128 %_0.i, ptr %_48, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_50, ptr align 16 %_44) #16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_51, ptr align 16 %_48) #16
  %19 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %19, ptr align 8 %_50, i64 16, i1 false)
  %20 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %_51, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %21 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args3) #16
  %_41.0 = extractvalue { ptr, ptr } %21, 0
  %_41.1 = extractvalue { ptr, ptr } %21, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_41.0, ptr %_41.1)
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_58, i128 %b, i128 %b) #16
; call core::hint::black_box::<i128>
  %_61 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 2) #16
; call <i128>::checked_sub
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_60, i128 %a, i128 %_61) #16
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_63, ptr align 16 %_58) #16
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<i128>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionnEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_64, ptr align 16 %_60) #16
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_63, i64 16, i1 false)
  %23 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %23, ptr align 8 %_64, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %24 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #16
  %_55.0 = extractvalue { ptr, ptr } %24, 0
  %_55.1 = extractvalue { ptr, ptr } %24, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_55.0, ptr %_55.1)
; call core::hint::black_box::<u128>
  %_72 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 3) #16
  %_73 = icmp eq i128 %_72, 0
  br i1 %_73, label %panic26, label %bb36

panic25:                                          ; preds = %bb14
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_5fa04f97916bd874a7a88690ee4d2c7f) #20
  unreachable

bb36:                                             ; preds = %bb22
  %25 = udiv i128 -1, %_72
  store i128 %25, ptr %_71, align 16
; call core::hint::black_box::<u128>
  %_76 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 1) #16
  %26 = shl i128 %_76, 100
  store i128 %26, ptr %_75, align 16
; call <core::fmt::rt::Argument>::new_lower_hex::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoEB7_(ptr sret([16 x i8]) align 8 %_80, ptr align 16 %_71) #16
; call <core::fmt::rt::Argument>::new_binary::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_81, ptr align 16 %_75) #16
  %27 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %27, ptr align 8 %_80, i64 16, i1 false)
  %28 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %28, ptr align 8 %_81, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<11, 2>
  %29 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj2_ECslb9dB7bEmfm_4i128(ptr @alloc_59b8058f47772d03e6bfab57ce0a41ae, ptr align 8 %args5) #16
  %_68.0 = extractvalue { ptr, ptr } %29, 0
  %_68.1 = extractvalue { ptr, ptr } %29, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_68.0, ptr %_68.1)
; call <u128>::pow
  %_90 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCslb9dB7bEmfm_4i128(i128 10, i32 36) #16
; call core::hint::black_box::<u128>
  %_89 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 %_90) #16
; call i128::isqrt
  %30 = call i128 @_RNvCslb9dB7bEmfm_4i1285isqrt(i128 %_89)
  store i128 %30, ptr %_88, align 16
; call i128::fact
  %_93 = call i128 @_RNvCslb9dB7bEmfm_4i1284fact(i32 20)
; call i128::fib
  %_94 = call i128 @_RNvCslb9dB7bEmfm_4i1283fib(i32 90)
; call i128::gcd
  %31 = call i128 @_RNvCslb9dB7bEmfm_4i1283gcd(i128 %_93, i128 %_94)
  store i128 %31, ptr %_92, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_96, ptr align 16 %_88) #16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_97, ptr align 16 %_92) #16
  %32 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %_96, i64 16, i1 false)
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_97, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %34 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #16
  %_85.0 = extractvalue { ptr, ptr } %34, 0
  %_85.1 = extractvalue { ptr, ptr } %34, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_85.0, ptr %_85.1)
; call core::hint::black_box::<u128>
  %_105 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 3) #16
; call <u128>::pow
  %_107 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCslb9dB7bEmfm_4i128(i128 10, i32 30) #16
; call core::hint::black_box::<u128>
  %_106 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 %_107) #16
; call i128::modpow
  %35 = call i128 @_RNvCslb9dB7bEmfm_4i1286modpow(i128 %_105, i128 %_106, i128 1000000007)
  store i128 %35, ptr %_104, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_109, ptr align 16 %_104) #16
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_109, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %37 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args7) #16
  %_101.0 = extractvalue { ptr, ptr } %37, 0
  %_101.1 = extractvalue { ptr, ptr } %37, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_101.0, ptr %_101.1)
  store i32 128, ptr %_116, align 4
; call core::hint::black_box::<u128>
  %_120 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 1) #16
  %_119 = shl i128 %_120, 77
  %38 = call i128 @llvm.cttz.i128(i128 %_119, i1 false)
  %_0.i35 = trunc i128 %38 to i32
  store i32 %_0.i35, ptr %_118, align 4
; call core::hint::black_box::<u128>
  %_125 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 5) #16
  %39 = call i128 @llvm.ctlz.i128(i128 %_125, i1 false)
  %_0.i34 = trunc i128 %39 to i32
  store i32 %_0.i34, ptr %_124, align 4
  store ptr %_116, ptr %args8, align 8
  %40 = getelementptr inbounds i8, ptr %args8, i64 8
  store ptr %_118, ptr %40, align 8
  %41 = getelementptr inbounds i8, ptr %args8, i64 16
  store ptr %_124, ptr %41, align 8
  %_336 = load ptr, ptr %args8, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_127, ptr align 4 %_336) #16
  %42 = getelementptr inbounds i8, ptr %args8, i64 8
  %_337 = load ptr, ptr %42, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_128, ptr align 4 %_337) #16
  %43 = getelementptr inbounds i8, ptr %args8, i64 16
  %_338 = load ptr, ptr %43, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_129, ptr align 4 %_338) #16
  %44 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %44, ptr align 8 %_127, i64 16, i1 false)
  %45 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %45, ptr align 8 %_128, i64 16, i1 false)
  %46 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %46, ptr align 8 %_129, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %47 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECslb9dB7bEmfm_4i128(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args9) #16
  %_113.0 = extractvalue { ptr, ptr } %47, 0
  %_113.1 = extractvalue { ptr, ptr } %47, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_113.0, ptr %_113.1)
; call core::hint::black_box::<u128>
  %_137 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 12345678901234567890123) #16
  %48 = uitofp i128 %_137 to double
  store double %48, ptr %_136, align 8
; call core::hint::black_box::<f64>
  %_140 = call double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECslb9dB7bEmfm_4i128(double 1.000000e+30) #16
  %49 = call i128 @llvm.fptoui.sat.i128.f64(double %_140)
  store i128 %49, ptr %_139, align 16
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_142, ptr align 8 %_136) #16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_143, ptr align 16 %_139) #16
  %50 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %50, ptr align 8 %_142, i64 16, i1 false)
  %51 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %_143, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %52 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args10) #16
  %_133.0 = extractvalue { ptr, ptr } %52, 0
  %_133.1 = extractvalue { ptr, ptr } %52, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_133.0, ptr %_133.1)
; call core::hint::black_box::<i128>
  %_152 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 -1) #16
  %53 = lshr i128 %_152, 64
  store i128 %53, ptr %_150, align 16
; call core::hint::black_box::<u128>
  %_158 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 -1) #16
  %54 = ashr i128 %_158, 120
  store i128 %54, ptr %_156, align 16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_162, ptr align 16 %_150) #16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_163, ptr align 16 %_156) #16
  %55 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %55, ptr align 8 %_162, i64 16, i1 false)
  %56 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %57 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args11) #16
  %_147.0 = extractvalue { ptr, ptr } %57, 0
  %_147.1 = extractvalue { ptr, ptr } %57, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_147.0, ptr %_147.1)
; call <str>::parse::<u128>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseoECslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_170, ptr @alloc_ce0acdd4a4f94c66b265f4ef543b4ab6, i64 39) #16
; call <str>::parse::<u128>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseoECslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_175, ptr @alloc_941090dbc54b31f562723ae1638c2086, i64 39) #16
; call <core::result::Result<u128, core::num::error::ParseIntError>>::is_err
  %58 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE6is_errCslb9dB7bEmfm_4i128(ptr align 16 %_175) #16
  %59 = zext i1 %58 to i8
  store i8 %59, ptr %_173, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<u128, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultoNtNtNtB7_3num5error13ParseIntErrorEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_178, ptr align 16 %_170) #16
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_179, ptr %_173) #16
  %60 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %60, ptr align 8 %_178, i64 16, i1 false)
  %61 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %61, ptr align 8 %_179, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %62 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #16
  %_167.0 = extractvalue { ptr, ptr } %62, 0
  %_167.1 = extractvalue { ptr, ptr } %62, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call <i128>::from_str_radix
  call void @_RNvMst_NtCsl10jNU3mE6R_4core3numn14from_str_radixCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_186, ptr @alloc_860d53ce49325a3fa4c8ce10cb01a0c4, i64 3, i32 36) #16
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<i128, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultnNtNtNtB7_3num5error13ParseIntErrorEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_189, ptr align 16 %_186) #16
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_189, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %64 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args13) #16
  %_183.0 = extractvalue { ptr, ptr } %64, 0
  %_183.1 = extractvalue { ptr, ptr } %64, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_183.0, ptr %_183.1)
; call <i128 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringnNtB5_8ToString9to_stringCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_199, ptr align 16 @alloc_0407da499bd3b5ae40bf7d4f7ff05b0b) #16
; invoke <alloc::string::String>::len
  %65 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCslb9dB7bEmfm_4i128(ptr align 8 %_199)
          to label %bb97 unwind label %cleanup

panic26:                                          ; preds = %bb22
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_d4d899166b4141918c2da3e256b7165b) #20
  unreachable

bb161:                                            ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_199) #21
          to label %bb162 unwind label %terminate

cleanup:                                          ; preds = %bb100, %bb99, %bb98, %bb97, %bb36
  %66 = landingpad { ptr, i32 }
          cleanup
  %67 = extractvalue { ptr, i32 } %66, 0
  %68 = extractvalue { ptr, i32 } %66, 1
  store ptr %67, ptr %1, align 8
  %69 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %68, ptr %69, align 8
  br label %bb161

bb97:                                             ; preds = %bb36
  store i64 %65, ptr %_197, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_202, ptr align 16 @alloc_b7cbb96fa2fbc2c33cfdce3b367921a6)
          to label %bb98 unwind label %cleanup

bb98:                                             ; preds = %bb97
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_203, ptr align 8 %_197)
          to label %bb99 unwind label %cleanup

bb99:                                             ; preds = %bb98
  %70 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %70, ptr align 8 %_202, i64 16, i1 false)
  %71 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %71, ptr align 8 %_203, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %72 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14)
          to label %bb100 unwind label %cleanup

bb100:                                            ; preds = %bb99
  %_193.0 = extractvalue { ptr, ptr } %72, 0
  %_193.1 = extractvalue { ptr, ptr } %72, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_193.0, ptr %_193.1)
          to label %bb101 unwind label %cleanup

bb101:                                            ; preds = %bb100
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_199)
; call core::hint::black_box::<i128>
  %_211 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 7) #16
; call <i128>::pow
  %73 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn3powCslb9dB7bEmfm_4i128(i128 %_211, i32 40) #16
  store i128 %73, ptr %_210, align 16
; call core::hint::black_box::<u128>
  %_214 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 2) #16
; call <u128>::pow
  %74 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCslb9dB7bEmfm_4i128(i128 %_214, i32 127) #16
  store i128 %74, ptr %_213, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_216, ptr align 16 %_210) #16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_217, ptr align 16 %_213) #16
  %75 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %75, ptr align 8 %_216, i64 16, i1 false)
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_217, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %77 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #16
  %_207.0 = extractvalue { ptr, ptr } %77, 0
  %_207.1 = extractvalue { ptr, ptr } %77, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_207.0, ptr %_207.1)
; call core::hint::black_box::<i128>
  %_225 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 -170141183460469231731687303715884105728) #16
; call <i128>::wrapping_abs
  %78 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCslb9dB7bEmfm_4i128(i128 %_225) #16
  store i128 %78, ptr %_224, align 16
; call core::hint::black_box::<i128>
  %_228 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECslb9dB7bEmfm_4i128(i128 -170141183460469231731687303715884105728) #16
; call <i128>::unsigned_abs
  %79 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_228) #16
  store i128 %79, ptr %_227, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_230, ptr align 16 %_224) #16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_231, ptr align 16 %_227) #16
  %80 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %80, ptr align 8 %_230, i64 16, i1 false)
  %81 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %81, ptr align 8 %_231, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %82 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #16
  %_221.0 = extractvalue { ptr, ptr } %82, 0
  %_221.1 = extractvalue { ptr, ptr } %82, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_221.0, ptr %_221.1)
; call core::hint::black_box::<u128>
  %83 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 24197857203266734864793317670504947440) #16
  store i128 %83, ptr %x, align 16
  %_237 = load i128, ptr %x, align 16
; call core::hint::black_box::<u32>
  %_238 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECslb9dB7bEmfm_4i128(i32 33) #16
; call core::intrinsics::rotate_left::<u128>
  %_0.i30 = call i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftoECslb9dB7bEmfm_4i128(i128 %_237, i32 %_238) #22
  %_240 = load i128, ptr %x, align 16
  %_239 = lshr i128 %_240, 5
  %_235 = xor i128 %_0.i30, %_239
  %_244 = load i128, ptr %x, align 16
  %_243 = shl i128 %_244, 9
  %84 = or i128 %_235, %_243
  store i128 %84, ptr %x, align 16
  %_253 = load i128, ptr %x, align 16
  %_0.i29 = call i128 @llvm.bswap.i128(i128 %_253)
  store i128 %_0.i29, ptr %_252, align 16
; call <core::fmt::rt::Argument>::new_lower_hex::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoEB7_(ptr sret([16 x i8]) align 8 %_255, ptr align 16 %x) #16
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_256, ptr align 16 %_252) #16
  %85 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %85, ptr align 8 %_255, i64 16, i1 false)
  %86 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %86, ptr align 8 %_256, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %87 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #16
  %_248.0 = extractvalue { ptr, ptr } %87, 0
  %_248.1 = extractvalue { ptr, ptr } %87, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_248.0, ptr %_248.1)
  store i128 0, ptr %acc, align 16
; call core::hint::black_box::<u128>
  %_262 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 100) #16
; call <core::ops::range::Range<u128> as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangeoENtB2_12IntoIterator9into_iterCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %0, i128 0, i128 %_262) #16
  %_260.0 = load i128, ptr %0, align 16
  %88 = getelementptr inbounds i8, ptr %0, i64 16
  %_260.1 = load i128, ptr %88, align 16
  store i128 %_260.0, ptr %iter, align 16
  %89 = getelementptr inbounds i8, ptr %iter, i64 16
  store i128 %_260.1, ptr %89, align 16
  br label %bb131

bb131:                                            ; preds = %bb137, %bb101
; call <core::ops::range::Range<u128> as core::iter::traits::iterator::Iterator>::next
  call void @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeoENtNtNtB7_6traits8iterator8Iterator4nextCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_264, ptr align 16 %iter) #16
  %90 = load i128, ptr %_264, align 16
  %91 = getelementptr inbounds i8, ptr %_264, i64 16
  %92 = load i128, ptr %91, align 16
  %_266 = trunc i128 %90 to i64
  %93 = trunc nuw i64 %_266 to i1
  br i1 %93, label %bb134, label %bb135

bb134:                                            ; preds = %bb131
  %94 = getelementptr inbounds i8, ptr %_264, i64 16
  %i = load i128, ptr %94, align 16
  %_270 = load i128, ptr %acc, align 16
  %_0.i33 = mul i128 %_270, 6364136223846793005
  %95 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %i, i128 1442695040888963407)
  %_272.0 = extractvalue { i128, i1 } %95, 0
  %_272.1 = extractvalue { i128, i1 } %95, 1
  br i1 %_272.1, label %panic28, label %bb137

bb135:                                            ; preds = %bb131
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_278, ptr align 16 %acc) #16
  %96 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %96, ptr align 8 %_278, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %97 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args18) #16
  %_274.0 = extractvalue { ptr, ptr } %97, 0
  %_274.1 = extractvalue { ptr, ptr } %97, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_274.0, ptr %_274.1)
; call core::hint::black_box::<u128>
  %_286 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 1267650600228229401496703205376) #16
  %98 = uitofp i128 %_286 to float
  store float %98, ptr %_285, align 4
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_291, ptr align 4 %_285) #16
  %99 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args19, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %99, ptr align 8 %_291, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %100 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args19) #16
  %_282.0 = extractvalue { ptr, ptr } %100, 0
  %_282.1 = extractvalue { ptr, ptr } %100, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_282.0, ptr %_282.1)
  store i32 128, ptr %_298, align 4
  store i128 -1, ptr %_300, align 16
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_302, ptr align 4 %_298) #16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_303, ptr align 16 %_300) #16
  %101 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %101, ptr align 8 %_302, i64 16, i1 false)
  %102 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %102, ptr align 8 %_303, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %103 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args20) #16
  %_295.0 = extractvalue { ptr, ptr } %103, 0
  %_295.1 = extractvalue { ptr, ptr } %103, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_295.0, ptr %_295.1)
; call core::hint::black_box::<u64>
  %_313 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECslb9dB7bEmfm_4i128(i64 -1) #16
  %_312 = zext i64 %_313 to i128
; call core::hint::black_box::<u64>
  %_315 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECslb9dB7bEmfm_4i128(i64 -1) #16
  %_314 = zext i64 %_315 to i128
  %104 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_312, i128 %_314)
  %_316.0 = extractvalue { i128, i1 } %104, 0
  %_316.1 = extractvalue { i128, i1 } %104, 1
  br i1 %_316.1, label %panic27, label %bb155

bb155:                                            ; preds = %bb135
; call core::hint::black_box::<u128>
  %_317 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECslb9dB7bEmfm_4i128(i128 -1) #16
  %_5.0.i = add i128 %_316.0, %_317
  %_5.1.i = icmp ult i128 %_5.0.i, %_316.0
  store i128 %_5.0.i, ptr %_310, align 16
  %105 = getelementptr inbounds i8, ptr %_310, i64 16
  %106 = zext i1 %_5.1.i to i8
  store i8 %106, ptr %105, align 16
; call <core::fmt::rt::Argument>::new_debug::<(u128, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTobEECslb9dB7bEmfm_4i128(ptr sret([16 x i8]) align 8 %_319, ptr align 16 %_310) #16
  %107 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_319, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<4, 1>
  %108 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args21) #16
  %_307.0 = extractvalue { ptr, ptr } %108, 0
  %_307.1 = extractvalue { ptr, ptr } %108, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_307.0, ptr %_307.1)
  ret void

panic27:                                          ; preds = %bb135
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_e4959e06482677e63dd48c2a86fcf0e7) #20
  unreachable

bb137:                                            ; preds = %bb134
  %_0.i32 = add i128 %_0.i33, %_272.0
  store i128 %_0.i32, ptr %acc, align 16
  br label %bb131

panic28:                                          ; preds = %bb134
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_744d897956c077d5b9b7148f78bfe5aa) #20
  unreachable

bb133:                                            ; No predecessors!
  unreachable

terminate:                                        ; preds = %bb161
  %109 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb162:                                            ; preds = %bb161
  %110 = load ptr, ptr %1, align 8
  %111 = getelementptr inbounds i8, ptr %1, i64 8
  %112 = load i32, ptr %111, align 8
  %113 = insertvalue { ptr, i32 } poison, ptr %110, 0
  %114 = insertvalue { ptr, i32 } %113, i32 %112, 1
  resume { ptr, i32 } %114
}

; i128::isqrt
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1285isqrt(i128 %n) unnamed_addr #1 !guid !113 {
start:
  %y = alloca [16 x i8], align 16
  %x = alloca [16 x i8], align 16
  store i128 %n, ptr %x, align 16
  %_5 = load i128, ptr %x, align 16
  %_6.0 = add i128 %_5, 1
  %_6.1 = icmp ult i128 %_6.0, %_5
  br i1 %_6.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  %0 = udiv i128 %_6.0, 2
  store i128 %0, ptr %y, align 16
  br label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_b14d820ee55f823d3aefb1afa0d7eac6) #20
  unreachable

bb3:                                              ; preds = %bb6, %bb1
  %_9 = load i128, ptr %y, align 16
  %_10 = load i128, ptr %x, align 16
  %_8 = icmp ult i128 %_9, %_10
  br i1 %_8, label %bb4, label %bb8

bb8:                                              ; preds = %bb3
  %_0 = load i128, ptr %x, align 16
  ret i128 %_0

bb4:                                              ; preds = %bb3
  %_11 = load i128, ptr %y, align 16
  store i128 %_11, ptr %x, align 16
  %_13 = load i128, ptr %x, align 16
  %_15 = load i128, ptr %x, align 16
  %_16 = icmp eq i128 %_15, 0
  br i1 %_16, label %panic1, label %bb5

bb5:                                              ; preds = %bb4
  %_14 = udiv i128 %n, %_15
  %_17.0 = add i128 %_13, %_14
  %_17.1 = icmp ult i128 %_17.0, %_13
  br i1 %_17.1, label %panic2, label %bb6

panic1:                                           ; preds = %bb4
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_a7299c6c6510c3de3e014799b32a1fb6) #20
  unreachable

bb6:                                              ; preds = %bb5
  %1 = udiv i128 %_17.0, 2
  store i128 %1, ptr %y, align 16
  br label %bb3

panic2:                                           ; preds = %bb5
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_83736e0ed8986abd3fb627960735e4af) #20
  unreachable
}

; i128::modpow
; Function Attrs: nonlazybind uwtable
define internal i128 @_RNvCslb9dB7bEmfm_4i1286modpow(i128 %0, i128 %1, i128 %m) unnamed_addr #1 !guid !114 {
start:
  %r = alloca [16 x i8], align 16
  %e = alloca [16 x i8], align 16
  %b = alloca [16 x i8], align 16
  store i128 %0, ptr %b, align 16
  store i128 %1, ptr %e, align 16
  store i128 1, ptr %r, align 16
  %_5 = icmp eq i128 %m, 0
  br i1 %_5, label %panic, label %bb1

bb1:                                              ; preds = %start
  %2 = load i128, ptr %b, align 16
  %3 = urem i128 %2, %m
  store i128 %3, ptr %b, align 16
  br label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_68c3021501d9c8f06b4083bb56ba3908) #20
  unreachable

bb2:                                              ; preds = %bb9, %bb1
  %_7 = load i128, ptr %e, align 16
  %_6 = icmp ugt i128 %_7, 0
  br i1 %_6, label %bb3, label %bb11

bb11:                                             ; preds = %bb2
  %_0 = load i128, ptr %r, align 16
  ret i128 %_0

bb3:                                              ; preds = %bb2
  %_10 = load i128, ptr %e, align 16
  %_9 = and i128 %_10, 1
  %_8 = icmp eq i128 %_9, 1
  br i1 %_8, label %bb4, label %bb7

bb7:                                              ; preds = %bb6, %bb3
  %_17 = load i128, ptr %b, align 16
  %_18 = load i128, ptr %b, align 16
  %4 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_17, i128 %_18)
  %_19.0 = extractvalue { i128, i1 } %4, 0
  %_19.1 = extractvalue { i128, i1 } %4, 1
  br i1 %_19.1, label %panic3, label %bb8

bb4:                                              ; preds = %bb3
  %_12 = load i128, ptr %r, align 16
  %_13 = load i128, ptr %b, align 16
  %5 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_12, i128 %_13)
  %_14.0 = extractvalue { i128, i1 } %5, 0
  %_14.1 = extractvalue { i128, i1 } %5, 1
  br i1 %_14.1, label %panic1, label %bb5

bb5:                                              ; preds = %bb4
  %_15 = icmp eq i128 %m, 0
  br i1 %_15, label %panic2, label %bb6

panic1:                                           ; preds = %bb4
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_c27fb0410a6c5898f903969645269014) #20
  unreachable

bb6:                                              ; preds = %bb5
  %6 = urem i128 %_14.0, %m
  store i128 %6, ptr %r, align 16
  br label %bb7

panic2:                                           ; preds = %bb5
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_c27fb0410a6c5898f903969645269014) #20
  unreachable

bb8:                                              ; preds = %bb7
  %_20 = icmp eq i128 %m, 0
  br i1 %_20, label %panic4, label %bb9

panic3:                                           ; preds = %bb7
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_b711721f7bfa298d55b2bdbe61d56fe1) #20
  unreachable

bb9:                                              ; preds = %bb8
  %7 = urem i128 %_19.0, %m
  store i128 %7, ptr %b, align 16
  %8 = load i128, ptr %e, align 16
  %9 = lshr i128 %8, 1
  store i128 %9, ptr %e, align 16
  br label %bb2

panic4:                                           ; preds = %bb8
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_b711721f7bfa298d55b2bdbe61d56fe1) #20
  unreachable
}

; <alloc::string::String>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !115 {
start:
  %_2 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8 %_2, i64 %capacity) #16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCslb9dB7bEmfm_4i128(ptr align 8 %self) unnamed_addr #0 !guid !116 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #16
  ret i64 %_0
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCslb9dB7bEmfm_4i128(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !117 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCslb9dB7bEmfm_4i128(ptr align 8 %self) #16
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cslb9dB7bEmfm_4i128(i32 %ch) #16
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %ch_len) #16
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8 %self) #16
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCslb9dB7bEmfm_4i128(i32 %ch, ptr %_0.i) #16
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8 %self, i64 %_14) #16
  ret void
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCslb9dB7bEmfm_4i128(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !118 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::string::String>::push_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr %string.0, i64 %string.1) unnamed_addr #0 !guid !119 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %string.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %string.1, 1
  %_4.0 = extractvalue { ptr, i64 } %1, 0
  %_4.1 = extractvalue { ptr, i64 } %1, 1
; call <alloc::vec::Vec<u8>>::extend_from_slice
  call void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8 %self, ptr %_4.0, i64 %_4.1)
  ret void
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCslb9dB7bEmfm_4i128(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !120 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<i128>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_noneCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !121 {
start:
; call <core::option::Option<i128>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_someCslb9dB7bEmfm_4i128(ptr align 16 %self) #16
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::option::Option<i128>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_someCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !122 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i128, ptr %self, align 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i128, ptr %1, align 16
  %_2 = trunc i128 %0 to i64
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u128, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE5is_okCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !123 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u128, core::num::error::ParseIntError>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE6is_errCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !124 {
start:
; call <core::result::Result<u128, core::num::error::ParseIntError>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultoNtNtNtB4_3num5error13ParseIntErrorE5is_okCslb9dB7bEmfm_4i128(ptr align 16 %self) #16
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cslb9dB7bEmfm_4i128(i32 %self) unnamed_addr #0 !guid !125 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cslb9dB7bEmfm_4i128(i32 %self) #16
  ret i64 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %self, i32 %radix) unnamed_addr #0 !guid !126 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #16
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #20
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::num::nonzero::NonZero<u128>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE13leading_zerosCslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !127 {
start:
; call <core::num::nonzero::NonZero<u128>>::get
  %_2 = call i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3getB9_(i128 %self) #16
  %0 = call i128 @llvm.ctlz.i128(i128 %_2, i1 true)
  %_0 = trunc i128 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u128>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE5ilog2Cslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !128 {
start:
; call <core::num::nonzero::NonZero<u128>>::leading_zeros
  %_3 = call i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE13leading_zerosCslb9dB7bEmfm_4i128(i128 %self) #16
  %_0 = sub i32 127, %_3
  ret i32 %_0
}

; <core::ptr::non_null::NonNull<core::option::Option<i128>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionnEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !129 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i128, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultnNtNtNtB9_3num5error13ParseIntErrorEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !130 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<u128, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultoNtNtNtB9_3num5error13ParseIntErrorEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !131 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<(u128, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTobEE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !132 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCslb9dB7bEmfm_4i128(ptr %r) unnamed_addr #0 !guid !133 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCslb9dB7bEmfm_4i128(ptr align 8 %r) unnamed_addr #0 !guid !134 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCslb9dB7bEmfm_4i128(ptr align 4 %r) unnamed_addr #0 !guid !135 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCslb9dB7bEmfm_4i128(ptr align 16 %r) unnamed_addr #0 !guid !136 {
start:
  ret ptr %r
}

; <i128>::rem_euclid
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10rem_euclidCslb9dB7bEmfm_4i128(i128 %self, i128 %rhs, ptr align 8 %0) unnamed_addr #0 !guid !137 {
start:
  %_0 = alloca [16 x i8], align 16
  %_4 = icmp eq i128 %rhs, 0
  br i1 %_4, label %panic, label %bb1

bb1:                                              ; preds = %start
  %_5 = icmp eq i128 %rhs, -1
  %_6 = icmp eq i128 %self, -170141183460469231731687303715884105728
  %_7 = and i1 %_5, %_6
  br i1 %_7, label %panic1, label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 %0) #20
  unreachable

bb2:                                              ; preds = %bb1
  %r = srem i128 %self, %rhs
  %_8 = icmp slt i128 %r, 0
  br i1 %_8, label %bb3, label %bb5

panic1:                                           ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 %0) #20
  unreachable

bb5:                                              ; preds = %bb2
  store i128 %r, ptr %_0, align 16
  br label %bb6

bb3:                                              ; preds = %bb2
; call <i128>::wrapping_abs
  %_9 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCslb9dB7bEmfm_4i128(i128 %rhs) #16
  %_0.i = add i128 %r, %_9
  store i128 %_0.i, ptr %_0, align 16
  br label %bb6

bb6:                                              ; preds = %bb3, %bb5
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; <i128>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10strict_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !138 {
start:
  %_3 = alloca [32 x i8], align 16
; call <i128>::checked_pow
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_3, i128 %self, i32 %exp) #16
  %1 = load i128, ptr %_3, align 16
  %2 = getelementptr inbounds i8, ptr %_3, i64 16
  %3 = load i128, ptr %2, align 16
  %_4 = trunc i128 %1 to i64
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %_3, i64 16
  %x = load i128, ptr %5, align 16
  ret i128 %x

bb3:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #18
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <i128>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_addCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !139 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.sadd.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <i128>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !140 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <i128>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !141 {
start:
  %_57 = alloca [32 x i8], align 16
  %_48 = alloca [32 x i8], align 16
  %_38 = alloca [32 x i8], align 16
  %_32 = alloca [32 x i8], align 16
  %_13 = alloca [8 x i8], align 4
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  %_6 = load i128, ptr %base, align 16
  %_5 = call i1 @llvm.is.constant.i128(i128 %_6)
  br i1 %_5, label %bb2, label %bb16

bb16:                                             ; preds = %bb2, %start
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp eq i32 %_24, 0
  br i1 %_23, label %bb17, label %bb18

bb2:                                              ; preds = %start
  %_9 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_8 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_9) #16
  %1 = call i128 @llvm.ctpop.i128(i128 %_8)
  %_0.i.i = trunc i128 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb16

bb5:                                              ; preds = %bb2
  %_12 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_11 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_12) #16
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %_11, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #16
  %_14 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %k, i32 %_14) #16
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_13, align 4
  %5 = getelementptr inbounds i8, ptr %_13, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_13, align 4
  %7 = getelementptr inbounds i8, ptr %_13, i64 4
  %8 = load i32, ptr %7, align 4
  %_15 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_15 to i1
  br i1 %9, label %bb11, label %bb10

bb18:                                             ; preds = %bb16
  %_26 = load i32, ptr %exp, align 4
  %_25 = call i1 @llvm.is.constant.i32(i32 %_26)
  br i1 %_25, label %bb20, label %bb32

bb17:                                             ; preds = %bb16
  %10 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 1, ptr %10, align 16
  store i128 1, ptr %_0, align 16
  br label %bb43

bb32:                                             ; preds = %bb42, %bb18
  %_47 = load i32, ptr %exp, align 4
  %_46 = and i32 %_47, 1
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb33, label %bb38

bb20:                                             ; preds = %bb30, %bb18
  %_28 = load i32, ptr %exp, align 4
  %_27 = icmp ugt i32 %_28, 1
  br i1 %_27, label %bb21, label %bb31

bb38:                                             ; preds = %bb36, %bb32
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_58 = load i128, ptr %base, align 16
  %_59 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_57, i128 %_58, i128 %_59) #16
  %13 = load i128, ptr %_57, align 16
  %14 = getelementptr inbounds i8, ptr %_57, i64 16
  %15 = load i128, ptr %14, align 16
  %_60 = trunc i128 %13 to i64
  %16 = trunc nuw i64 %_60 to i1
  br i1 %16, label %bb42, label %bb41

bb33:                                             ; preds = %bb32
  %_49 = load i128, ptr %acc, align 16
  %_50 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_48, i128 %_49, i128 %_50) #16
  %17 = load i128, ptr %_48, align 16
  %18 = getelementptr inbounds i8, ptr %_48, i64 16
  %19 = load i128, ptr %18, align 16
  %_51 = trunc i128 %17 to i64
  %20 = trunc nuw i64 %_51 to i1
  br i1 %20, label %bb36, label %bb35

bb36:                                             ; preds = %bb33
  %21 = getelementptr inbounds i8, ptr %_48, i64 16
  %x = load i128, ptr %21, align 16
  store i128 %x, ptr %acc, align 16
  %_54 = load i32, ptr %exp, align 4
  %_53 = icmp eq i32 %_54, 1
  br i1 %_53, label %bb37, label %bb38

bb35:                                             ; preds = %bb33
  store i128 0, ptr %_0, align 16
  br label %bb43

bb43:                                             ; preds = %bb14, %bb15, %bb10, %bb17, %bb29, %bb24, %bb31, %bb37, %bb41, %bb35
  ret void

bb37:                                             ; preds = %bb36
  %_55 = load i128, ptr %acc, align 16
  %22 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_55, ptr %22, align 16
  store i128 1, ptr %_0, align 16
  br label %bb43

bb42:                                             ; preds = %bb38
  %23 = getelementptr inbounds i8, ptr %_57, i64 16
  %x1 = load i128, ptr %23, align 16
  store i128 %x1, ptr %base, align 16
  br label %bb32

bb41:                                             ; preds = %bb38
  store i128 0, ptr %_0, align 16
  br label %bb43

bb31:                                             ; preds = %bb20
  %_43 = load i128, ptr %acc, align 16
  %_44 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %_43, i128 %_44) #16
  br label %bb43

bb21:                                             ; preds = %bb20
  %_31 = load i32, ptr %exp, align 4
  %_30 = and i32 %_31, 1
  %_29 = icmp eq i32 %_30, 1
  br i1 %_29, label %bb22, label %bb26

bb26:                                             ; preds = %bb25, %bb21
  %24 = load i32, ptr %exp, align 4
  %25 = udiv i32 %24, 2
  store i32 %25, ptr %exp, align 4
  %_39 = load i128, ptr %base, align 16
  %_40 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_38, i128 %_39, i128 %_40) #16
  %26 = load i128, ptr %_38, align 16
  %27 = getelementptr inbounds i8, ptr %_38, i64 16
  %28 = load i128, ptr %27, align 16
  %_41 = trunc i128 %26 to i64
  %29 = trunc nuw i64 %_41 to i1
  br i1 %29, label %bb30, label %bb29

bb22:                                             ; preds = %bb21
  %_33 = load i128, ptr %acc, align 16
  %_34 = load i128, ptr %base, align 16
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_32, i128 %_33, i128 %_34) #16
  %30 = load i128, ptr %_32, align 16
  %31 = getelementptr inbounds i8, ptr %_32, i64 16
  %32 = load i128, ptr %31, align 16
  %_35 = trunc i128 %30 to i64
  %33 = trunc nuw i64 %_35 to i1
  br i1 %33, label %bb25, label %bb24

bb25:                                             ; preds = %bb22
  %34 = getelementptr inbounds i8, ptr %_32, i64 16
  %x2 = load i128, ptr %34, align 16
  store i128 %x2, ptr %acc, align 16
  br label %bb26

bb24:                                             ; preds = %bb22
  store i128 0, ptr %_0, align 16
  br label %bb43

bb30:                                             ; preds = %bb26
  %35 = getelementptr inbounds i8, ptr %_38, i64 16
  %x3 = load i128, ptr %35, align 16
  store i128 %x3, ptr %base, align 16
  br label %bb20

bb29:                                             ; preds = %bb26
  store i128 0, ptr %_0, align 16
  br label %bb43

bb11:                                             ; preds = %bb5
  %36 = getelementptr inbounds i8, ptr %_13, i64 4
  %shift = load i32, ptr %36, align 4
  %_18 = load i128, ptr %base, align 16
  %_17 = icmp slt i128 %_18, 0
  br i1 %_17, label %bb12, label %bb15

bb10:                                             ; preds = %bb5
  store i128 0, ptr %_0, align 16
  br label %bb43

bb15:                                             ; preds = %bb12, %bb11
; call <i128>::shl_exact
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 1, i32 %shift) #16
  br label %bb43

bb12:                                             ; preds = %bb11
  %_21 = load i32, ptr %exp, align 4
  %_20 = urem i32 %_21, 2
  %_19 = icmp eq i32 %_20, 1
  br i1 %_19, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
; call <i128>::shl_exact
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 -1, i32 %shift) #16
  br label %bb43

bb9:                                              ; No predecessors!
  unreachable
}

; <i128>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !142 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.ssub.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <i128>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !143 {
start:
; call <i128>::wrapping_abs
  %_2 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCslb9dB7bEmfm_4i128(i128 %self) #16
  ret i128 %_2
}

; <i128>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_absCslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !144 {
start:
  %_0 = alloca [16 x i8], align 16
  %_0.i = icmp slt i128 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i128 %self, ptr %_0, align 16
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i128 0, %self
  store i128 %_0.i2, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; <i128>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !145 {
start:
  %0 = alloca [32 x i8], align 16
; call <i128>::overflowing_pow
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn15overflowing_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %0, i128 %self, i32 %exp) #16
  %_3.0 = load i128, ptr %0, align 16
  %1 = getelementptr inbounds i8, ptr %0, i64 16
  %2 = load i8, ptr %1, align 16
  %_3.1 = trunc nuw i8 %2 to i1
  ret i128 %_3.0
}

; <i128>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unbounded_shlCslb9dB7bEmfm_4i128(i128 %self, i32 %rhs) unnamed_addr #0 !guid !146 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp ult i32 %rhs, 128
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #16
  br i1 %_3.i, label %bb2.i, label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <i128>::unchecked_shl::precondition_check
  call void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #23
  br label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i128
  %_0.i = shl i128 %self, %0
  store i128 %_0.i, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit, %bb2
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; <i128>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn15overflowing_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !147 {
start:
  %1 = alloca [32 x i8], align 16
  %2 = alloca [32 x i8], align 16
  %3 = alloca [32 x i8], align 16
  %4 = alloca [32 x i8], align 16
  %5 = alloca [32 x i8], align 16
  %_30 = alloca [32 x i8], align 16
  %base1 = alloca [16 x i8], align 16
  %_16 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  store i8 0, ptr %overflow, align 1
  %_8 = load i128, ptr %base, align 16
  %_7 = call i1 @llvm.is.constant.i128(i128 %_8)
  br i1 %_7, label %bb2, label %bb19

bb19:                                             ; preds = %bb2, %start
  %_33 = load i32, ptr %exp, align 4
  %_32 = icmp eq i32 %_33, 0
  br i1 %_32, label %bb20, label %bb21

bb2:                                              ; preds = %start
  %_11 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_10 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_11) #16
  %6 = call i128 @llvm.ctpop.i128(i128 %_10)
  %_0.i.i = trunc i128 %6 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb5, label %bb19

bb5:                                              ; preds = %bb2
  %_14 = load i128, ptr %base, align 16
; call <i128>::unsigned_abs
  %_13 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_14) #16
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %_13, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #16
  %_17 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %7 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %k, i32 %_17) #16
  %8 = extractvalue { i32, i32 } %7, 0
  %9 = extractvalue { i32, i32 } %7, 1
  store i32 %8, ptr %_16, align 4
  %10 = getelementptr inbounds i8, ptr %_16, i64 4
  store i32 %9, ptr %10, align 4
  %11 = load i32, ptr %_16, align 4
  %12 = getelementptr inbounds i8, ptr %_16, i64 4
  %13 = load i32, ptr %12, align 4
  %_18 = zext i32 %11 to i64
  %14 = trunc nuw i64 %_18 to i1
  br i1 %14, label %bb9, label %bb10

bb21:                                             ; preds = %bb19
  %_35 = load i32, ptr %exp, align 4
  %_34 = call i1 @llvm.is.constant.i32(i32 %_35)
  br i1 %_34, label %bb23, label %bb32

bb20:                                             ; preds = %bb19
  store i128 1, ptr %_0, align 16
  %15 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 0, ptr %15, align 16
  br label %bb39

bb32:                                             ; preds = %bb36, %bb21
  %_64 = load i32, ptr %exp, align 4
  %_63 = and i32 %_64, 1
  %_62 = icmp eq i32 %_63, 1
  br i1 %_62, label %bb33, label %bb36

bb23:                                             ; preds = %bb27, %bb21
  %_37 = load i32, ptr %exp, align 4
  %_36 = icmp ugt i32 %_37, 1
  br i1 %_36, label %bb24, label %bb30

bb36:                                             ; preds = %bb33, %bb32
  %16 = load i32, ptr %exp, align 4
  %17 = udiv i32 %16, 2
  store i32 %17, ptr %exp, align 4
  %_79 = load i128, ptr %base, align 16
  %_80 = load i128, ptr %base, align 16
  %18 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_79, i128 %_80)
  %_5.0.i6 = extractvalue { i128, i1 } %18, 0
  %_5.1.i7 = extractvalue { i128, i1 } %18, 1
  store i128 %_5.0.i6, ptr %4, align 16
  %19 = getelementptr inbounds i8, ptr %4, i64 16
  %20 = zext i1 %_5.1.i7 to i8
  store i8 %20, ptr %19, align 16
  %_78.0 = load i128, ptr %4, align 16
  %21 = getelementptr inbounds i8, ptr %4, i64 16
  %22 = load i8, ptr %21, align 16
  %_78.1 = trunc nuw i8 %22 to i1
  store i128 %_78.0, ptr %base, align 16
  %23 = zext i1 %_78.1 to i8
  store i8 %23, ptr %tmp_overflow, align 1
  %24 = load i8, ptr %tmp_overflow, align 1
  %_81 = trunc nuw i8 %24 to i1
  %25 = load i8, ptr %overflow, align 1
  %26 = trunc nuw i8 %25 to i1
  %27 = or i1 %26, %_81
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %overflow, align 1
  br label %bb32

bb33:                                             ; preds = %bb32
  %_68 = load i128, ptr %acc, align 16
  %_69 = load i128, ptr %base, align 16
  %29 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_68, i128 %_69)
  %_5.0.i8 = extractvalue { i128, i1 } %29, 0
  %_5.1.i9 = extractvalue { i128, i1 } %29, 1
  store i128 %_5.0.i8, ptr %5, align 16
  %30 = getelementptr inbounds i8, ptr %5, i64 16
  %31 = zext i1 %_5.1.i9 to i8
  store i8 %31, ptr %30, align 16
  %_67.0 = load i128, ptr %5, align 16
  %32 = getelementptr inbounds i8, ptr %5, i64 16
  %33 = load i8, ptr %32, align 16
  %_67.1 = trunc nuw i8 %33 to i1
  store i128 %_67.0, ptr %acc, align 16
  %34 = zext i1 %_67.1 to i8
  store i8 %34, ptr %tmp_overflow, align 1
  %35 = load i8, ptr %tmp_overflow, align 1
  %_70 = trunc nuw i8 %35 to i1
  %36 = load i8, ptr %overflow, align 1
  %37 = trunc nuw i8 %36 to i1
  %38 = or i1 %37, %_70
  %39 = zext i1 %38 to i8
  store i8 %39, ptr %overflow, align 1
  %_72 = load i32, ptr %exp, align 4
  %_71 = icmp eq i32 %_72, 1
  br i1 %_71, label %bb35, label %bb36

bb35:                                             ; preds = %bb33
  %_73 = load i128, ptr %acc, align 16
  %40 = load i8, ptr %overflow, align 1
  %_74 = trunc nuw i8 %40 to i1
  store i128 %_73, ptr %_0, align 16
  %41 = getelementptr inbounds i8, ptr %_0, i64 16
  %42 = zext i1 %_74 to i8
  store i8 %42, ptr %41, align 16
  br label %bb39

bb39:                                             ; preds = %bb10, %bb15, %bb20, %bb30, %bb35
  ret void

bb30:                                             ; preds = %bb23
  %_57 = load i128, ptr %acc, align 16
  %_58 = load i128, ptr %base, align 16
  %43 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_57, i128 %_58)
  %_5.0.i4 = extractvalue { i128, i1 } %43, 0
  %_5.1.i5 = extractvalue { i128, i1 } %43, 1
  store i128 %_5.0.i4, ptr %3, align 16
  %44 = getelementptr inbounds i8, ptr %3, i64 16
  %45 = zext i1 %_5.1.i5 to i8
  store i8 %45, ptr %44, align 16
  %_56.0 = load i128, ptr %3, align 16
  %46 = getelementptr inbounds i8, ptr %3, i64 16
  %47 = load i8, ptr %46, align 16
  %_56.1 = trunc nuw i8 %47 to i1
  store i128 %_56.0, ptr %acc, align 16
  %48 = zext i1 %_56.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_59 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_59
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  %_60 = load i128, ptr %acc, align 16
  %54 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %54 to i1
  store i128 %_60, ptr %_0, align 16
  %55 = getelementptr inbounds i8, ptr %_0, i64 16
  %56 = zext i1 %_61 to i8
  store i8 %56, ptr %55, align 16
  br label %bb39

bb24:                                             ; preds = %bb23
  %_40 = load i32, ptr %exp, align 4
  %_39 = and i32 %_40, 1
  %_38 = icmp eq i32 %_39, 1
  br i1 %_38, label %bb25, label %bb27

bb27:                                             ; preds = %bb25, %bb24
  %57 = load i32, ptr %exp, align 4
  %58 = udiv i32 %57, 2
  store i32 %58, ptr %exp, align 4
  %_51 = load i128, ptr %base, align 16
  %_52 = load i128, ptr %base, align 16
  %59 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_51, i128 %_52)
  %_5.0.i = extractvalue { i128, i1 } %59, 0
  %_5.1.i = extractvalue { i128, i1 } %59, 1
  store i128 %_5.0.i, ptr %1, align 16
  %60 = getelementptr inbounds i8, ptr %1, i64 16
  %61 = zext i1 %_5.1.i to i8
  store i8 %61, ptr %60, align 16
  %_50.0 = load i128, ptr %1, align 16
  %62 = getelementptr inbounds i8, ptr %1, i64 16
  %63 = load i8, ptr %62, align 16
  %_50.1 = trunc nuw i8 %63 to i1
  store i128 %_50.0, ptr %base, align 16
  %64 = zext i1 %_50.1 to i8
  store i8 %64, ptr %tmp_overflow, align 1
  %65 = load i8, ptr %tmp_overflow, align 1
  %_53 = trunc nuw i8 %65 to i1
  %66 = load i8, ptr %overflow, align 1
  %67 = trunc nuw i8 %66 to i1
  %68 = or i1 %67, %_53
  %69 = zext i1 %68 to i8
  store i8 %69, ptr %overflow, align 1
  br label %bb23

bb25:                                             ; preds = %bb24
  %_44 = load i128, ptr %acc, align 16
  %_45 = load i128, ptr %base, align 16
  %70 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %_44, i128 %_45)
  %_5.0.i2 = extractvalue { i128, i1 } %70, 0
  %_5.1.i3 = extractvalue { i128, i1 } %70, 1
  store i128 %_5.0.i2, ptr %2, align 16
  %71 = getelementptr inbounds i8, ptr %2, i64 16
  %72 = zext i1 %_5.1.i3 to i8
  store i8 %72, ptr %71, align 16
  %_43.0 = load i128, ptr %2, align 16
  %73 = getelementptr inbounds i8, ptr %2, i64 16
  %74 = load i8, ptr %73, align 16
  %_43.1 = trunc nuw i8 %74 to i1
  store i128 %_43.0, ptr %acc, align 16
  %75 = zext i1 %_43.1 to i8
  store i8 %75, ptr %tmp_overflow, align 1
  %76 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %76 to i1
  %77 = load i8, ptr %overflow, align 1
  %78 = trunc nuw i8 %77 to i1
  %79 = or i1 %78, %_46
  %80 = zext i1 %79 to i8
  store i8 %80, ptr %overflow, align 1
  br label %bb27

bb9:                                              ; preds = %bb5
  %81 = getelementptr inbounds i8, ptr %_16, i64 4
  %shift = load i32, ptr %81, align 4
  %_21 = load i128, ptr %base, align 16
  %_20 = icmp slt i128 %_21, 0
  br i1 %_20, label %bb11, label %bb14

bb10:                                             ; preds = %bb5
  store i128 0, ptr %_0, align 16
  %82 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 1, ptr %82, align 16
  br label %bb39

bb14:                                             ; preds = %bb11, %bb9
  store i128 1, ptr %base1, align 16
  br label %bb15

bb11:                                             ; preds = %bb9
  %_24 = load i32, ptr %exp, align 4
  %_23 = urem i32 %_24, 2
  %_22 = icmp ne i32 %_23, 0
  br i1 %_22, label %bb13, label %bb14

bb13:                                             ; preds = %bb11
  store i128 -1, ptr %base1, align 16
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_27 = load i128, ptr %base1, align 16
; call <i128>::unbounded_shl
  %_26 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unbounded_shlCslb9dB7bEmfm_4i128(i128 %_27, i32 %shift) #16
  %_31 = load i128, ptr %base1, align 16
; call <i128>::shl_exact
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_30, i128 %_31, i32 %shift) #16
; call <core::option::Option<i128>>::is_none
  %_28 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_noneCslb9dB7bEmfm_4i128(ptr align 16 %_30) #16
  store i128 %_26, ptr %_0, align 16
  %83 = getelementptr inbounds i8, ptr %_0, i64 16
  %84 = zext i1 %_28 to i8
  store i8 %84, ptr %83, align 16
  br label %bb39

bb40:                                             ; No predecessors!
  unreachable
}

; <i128>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn3powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !148 {
start:
  %_0 = alloca [16 x i8], align 16
  br label %bb1

bb1:                                              ; preds = %start
; call <i128>::strict_pow
  %0 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn10strict_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #16
  store i128 %0, ptr %_0, align 16
  br label %bb3

bb2:                                              ; No predecessors!
; call <i128>::wrapping_pow
  %1 = call i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12wrapping_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) #16
  store i128 %1, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i128, ptr %_0, align 16
  ret i128 %2
}

; <i128>::shl_exact
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn9shl_exactCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %rhs) unnamed_addr #0 !guid !149 {
start:
  %0 = call i128 @llvm.ctlz.i128(i128 %self, i1 false)
  %_0.i4 = trunc i128 %0 to i32
  %_3 = icmp ult i32 %rhs, %_0.i4
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_2.i = xor i128 %self, -1
  %1 = call i128 @llvm.ctlz.i128(i128 %_2.i, i1 false)
  %_0.i = trunc i128 %1 to i32
  %_5 = icmp ult i32 %rhs, %_0.i
  br i1 %_5, label %bb4, label %bb6

bb4:                                              ; preds = %bb2, %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #16
  br i1 %_3.i, label %bb2.i, label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

bb2.i:                                            ; preds = %bb4
; call <i128>::unchecked_shl::precondition_check
  call void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 @alloc_d60754359a0b1c5bd37a3b37b82a8a1d) #23
  br label %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit

_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit: ; preds = %bb4, %bb2.i
  %2 = zext i32 %rhs to i128
  %_0.i2 = shl i128 %self, %2
  %3 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_0.i2, ptr %3, align 16
  store i128 1, ptr %_0, align 16
  br label %bb7

bb6:                                              ; preds = %bb2
  store i128 0, ptr %_0, align 16
  br label %bb7

bb7:                                              ; preds = %_RNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl.exit, %bb6
  ret void
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !150 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCslb9dB7bEmfm_4i128(ptr %s.0, i64 %s.1) #16
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::ops::range::RangeInclusive<u128>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusiveoE3newCslb9dB7bEmfm_4i128(ptr sret([48 x i8]) align 16 %_0, i128 %start1, i128 %end) unnamed_addr #0 !guid !151 {
start:
  store i128 %start1, ptr %_0, align 16
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %end, ptr %0, align 16
  %1 = getelementptr inbounds i8, ptr %_0, i64 32
  store i8 0, ptr %1, align 16
  ret void
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %self, i32 %rhs) unnamed_addr #0 !guid !152 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u128>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo10strict_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !153 {
start:
  %_3 = alloca [32 x i8], align 16
; call <u128>::checked_pow
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_3, i128 %self, i32 %exp) #16
  %1 = load i128, ptr %_3, align 16
  %2 = getelementptr inbounds i8, ptr %_3, i64 16
  %3 = load i128, ptr %2, align 16
  %_4 = trunc i128 %1 to i64
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %_3, i64 16
  %a = load i128, ptr %5, align 16
  ret i128 %a

bb4:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #18
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <u128>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !154 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_5.0 = add i128 %self, %rhs
  %_5.1 = icmp ult i128 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i128 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_6, ptr %2, align 16
  store i128 1, ptr %_0, align 16
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void
}

; <u128>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !155 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <u128>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !156 {
start:
  %_49 = alloca [32 x i8], align 16
  %_40 = alloca [32 x i8], align 16
  %_30 = alloca [32 x i8], align 16
  %_24 = alloca [32 x i8], align 16
  %_11 = alloca [8 x i8], align 4
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  %_6 = load i128, ptr %base, align 16
  %_5 = call i1 @llvm.is.constant.i128(i128 %_6)
  br i1 %_5, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_16 = load i32, ptr %exp, align 4
  %_15 = icmp eq i32 %_16, 0
  br i1 %_15, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_8 = load i128, ptr %base, align 16
  %1 = call i128 @llvm.ctpop.i128(i128 %_8)
  %_0.i.i = trunc i128 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_10 = load i128, ptr %base, align 16
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %_10, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #16
  %_12 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %k, i32 %_12) #16
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_11, align 4
  %5 = getelementptr inbounds i8, ptr %_11, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_11, align 4
  %7 = getelementptr inbounds i8, ptr %_11, i64 4
  %8 = load i32, ptr %7, align 4
  %_13 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_13 to i1
  br i1 %9, label %bb9, label %bb8

bb12:                                             ; preds = %bb10
  %_18 = load i32, ptr %exp, align 4
  %_17 = call i1 @llvm.is.constant.i32(i32 %_18)
  br i1 %_17, label %bb14, label %bb26

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 1, ptr %10, align 16
  store i128 1, ptr %_0, align 16
  br label %bb37

bb26:                                             ; preds = %bb36, %bb12
  %_39 = load i32, ptr %exp, align 4
  %_38 = and i32 %_39, 1
  %_37 = icmp eq i32 %_38, 1
  br i1 %_37, label %bb27, label %bb32

bb14:                                             ; preds = %bb24, %bb12
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp ugt i32 %_20, 1
  br i1 %_19, label %bb15, label %bb25

bb32:                                             ; preds = %bb30, %bb26
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_50 = load i128, ptr %base, align 16
  %_51 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_49, i128 %_50, i128 %_51) #16
  %13 = load i128, ptr %_49, align 16
  %14 = getelementptr inbounds i8, ptr %_49, i64 16
  %15 = load i128, ptr %14, align 16
  %_52 = trunc i128 %13 to i64
  %16 = trunc nuw i64 %_52 to i1
  br i1 %16, label %bb36, label %bb35

bb27:                                             ; preds = %bb26
  %_41 = load i128, ptr %acc, align 16
  %_42 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_40, i128 %_41, i128 %_42) #16
  %17 = load i128, ptr %_40, align 16
  %18 = getelementptr inbounds i8, ptr %_40, i64 16
  %19 = load i128, ptr %18, align 16
  %_43 = trunc i128 %17 to i64
  %20 = trunc nuw i64 %_43 to i1
  br i1 %20, label %bb30, label %bb29

bb30:                                             ; preds = %bb27
  %21 = getelementptr inbounds i8, ptr %_40, i64 16
  %x = load i128, ptr %21, align 16
  store i128 %x, ptr %acc, align 16
  %_46 = load i32, ptr %exp, align 4
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb31, label %bb32

bb29:                                             ; preds = %bb27
  store i128 0, ptr %_0, align 16
  br label %bb37

bb37:                                             ; preds = %bb9, %bb8, %bb11, %bb23, %bb18, %bb25, %bb31, %bb35, %bb29
  ret void

bb31:                                             ; preds = %bb30
  %_47 = load i128, ptr %acc, align 16
  %22 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_47, ptr %22, align 16
  store i128 1, ptr %_0, align 16
  br label %bb37

bb36:                                             ; preds = %bb32
  %23 = getelementptr inbounds i8, ptr %_49, i64 16
  %x1 = load i128, ptr %23, align 16
  store i128 %x1, ptr %base, align 16
  br label %bb26

bb35:                                             ; preds = %bb32
  store i128 0, ptr %_0, align 16
  br label %bb37

bb25:                                             ; preds = %bb14
  %_35 = load i128, ptr %acc, align 16
  %_36 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %_35, i128 %_36) #16
  br label %bb37

bb15:                                             ; preds = %bb14
  %_23 = load i32, ptr %exp, align 4
  %_22 = and i32 %_23, 1
  %_21 = icmp eq i32 %_22, 1
  br i1 %_21, label %bb16, label %bb20

bb20:                                             ; preds = %bb19, %bb15
  %24 = load i32, ptr %exp, align 4
  %25 = udiv i32 %24, 2
  store i32 %25, ptr %exp, align 4
  %_31 = load i128, ptr %base, align 16
  %_32 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_30, i128 %_31, i128 %_32) #16
  %26 = load i128, ptr %_30, align 16
  %27 = getelementptr inbounds i8, ptr %_30, i64 16
  %28 = load i128, ptr %27, align 16
  %_33 = trunc i128 %26 to i64
  %29 = trunc nuw i64 %_33 to i1
  br i1 %29, label %bb24, label %bb23

bb16:                                             ; preds = %bb15
  %_25 = load i128, ptr %acc, align 16
  %_26 = load i128, ptr %base, align 16
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_24, i128 %_25, i128 %_26) #16
  %30 = load i128, ptr %_24, align 16
  %31 = getelementptr inbounds i8, ptr %_24, i64 16
  %32 = load i128, ptr %31, align 16
  %_27 = trunc i128 %30 to i64
  %33 = trunc nuw i64 %_27 to i1
  br i1 %33, label %bb19, label %bb18

bb19:                                             ; preds = %bb16
  %34 = getelementptr inbounds i8, ptr %_24, i64 16
  %x2 = load i128, ptr %34, align 16
  store i128 %x2, ptr %acc, align 16
  br label %bb20

bb18:                                             ; preds = %bb16
  store i128 0, ptr %_0, align 16
  br label %bb37

bb24:                                             ; preds = %bb20
  %35 = getelementptr inbounds i8, ptr %_30, i64 16
  %x3 = load i128, ptr %35, align 16
  store i128 %x3, ptr %base, align 16
  br label %bb14

bb23:                                             ; preds = %bb20
  store i128 0, ptr %_0, align 16
  br label %bb37

bb9:                                              ; preds = %bb4
  %36 = getelementptr inbounds i8, ptr %_11, i64 4
  %shift = load i32, ptr %36, align 4
; call <u128>::checked_shl
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_shlCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 1, i32 %shift) #16
  br label %bb37

bb8:                                              ; preds = %bb4
  store i128 0, ptr %_0, align 16
  br label %bb37

bb7:                                              ; No predecessors!
  unreachable
}

; <u128>::checked_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_shlCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %rhs) unnamed_addr #0 !guid !157 {
start:
  %_3 = icmp ult i32 %rhs, 128
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb4

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #16
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u128>::unchecked_shl::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #23
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i128
  %_0.i = shl i128 %self, %0
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_0.i, ptr %1, align 16
  store i128 1, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit, %bb3
  ret void
}

; <u128>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !158 {
start:
  %_3 = icmp ult i128 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i128 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_4, ptr %0, align 16
  store i128 1, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  ret void
}

; <u128>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo12wrapping_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !159 {
start:
  %0 = alloca [32 x i8], align 16
; call <u128>::overflowing_pow
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo15overflowing_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %0, i128 %self, i32 %exp) #16
  %_3.0 = load i128, ptr %0, align 16
  %1 = getelementptr inbounds i8, ptr %0, i64 16
  %2 = load i8, ptr %1, align 16
  %_3.1 = trunc nuw i8 %2 to i1
  ret i128 %_3.0
}

; <u128>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13checked_ilog2Cslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !160 {
start:
  %_2 = alloca [16 x i8], align 16
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u128>>::new
  %0 = call i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3newB9_(i128 %self) #16
  store i128 %0, ptr %_2, align 16
  %1 = load i128, ptr %_2, align 16
  %2 = icmp eq i128 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i128, ptr %_2, align 16
; call <core::num::nonzero::NonZero<u128>>::ilog2
  %_5 = call i32 @_RNvMs18_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerooE5ilog2Cslb9dB7bEmfm_4i128(i128 %x) #16
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u128>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unbounded_shlCslb9dB7bEmfm_4i128(i128 %self, i32 %rhs) unnamed_addr #0 !guid !161 {
start:
  %_0 = alloca [16 x i8], align 16
  %_3 = icmp ult i32 %rhs, 128
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #16
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u128>::unchecked_shl::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #23
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i128
  %_0.i = shl i128 %self, %0
  store i128 %_0.i, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl.exit, %bb2
  %1 = load i128, ptr %_0, align 16
  ret i128 %1
}

; <u128>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo15overflowing_powCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self, i32 %0) unnamed_addr #0 !guid !162 {
start:
  %1 = alloca [32 x i8], align 16
  %2 = alloca [32 x i8], align 16
  %3 = alloca [32 x i8], align 16
  %4 = alloca [32 x i8], align 16
  %5 = alloca [32 x i8], align 16
  %_14 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [16 x i8], align 16
  %base = alloca [16 x i8], align 16
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i128 %self, ptr %base, align 16
  store i128 1, ptr %acc, align 16
  store i8 0, ptr %overflow, align 1
  %_8 = load i128, ptr %base, align 16
  %_7 = call i1 @llvm.is.constant.i128(i128 %_8)
  br i1 %_7, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp eq i32 %_20, 0
  br i1 %_19, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_10 = load i128, ptr %base, align 16
  %6 = call i128 @llvm.ctpop.i128(i128 %_10)
  %_0.i.i = trunc i128 %6 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_12 = load i128, ptr %base, align 16
; call <u128>::ilog2
  %k = call i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %_12, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #16
  %_15 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %7 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCslb9dB7bEmfm_4i128(i32 %k, i32 %_15) #16
  %8 = extractvalue { i32, i32 } %7, 0
  %9 = extractvalue { i32, i32 } %7, 1
  store i32 %8, ptr %_14, align 4
  %10 = getelementptr inbounds i8, ptr %_14, i64 4
  store i32 %9, ptr %10, align 4
  %11 = load i32, ptr %_14, align 4
  %12 = getelementptr inbounds i8, ptr %_14, i64 4
  %13 = load i32, ptr %12, align 4
  %_16 = zext i32 %11 to i64
  %14 = trunc nuw i64 %_16 to i1
  br i1 %14, label %bb7, label %bb8

bb12:                                             ; preds = %bb10
  %_22 = load i32, ptr %exp, align 4
  %_21 = call i1 @llvm.is.constant.i32(i32 %_22)
  br i1 %_21, label %bb14, label %bb23

bb11:                                             ; preds = %bb10
  store i128 1, ptr %_0, align 16
  %15 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 0, ptr %15, align 16
  br label %bb30

bb23:                                             ; preds = %bb27, %bb12
  %_51 = load i32, ptr %exp, align 4
  %_50 = and i32 %_51, 1
  %_49 = icmp eq i32 %_50, 1
  br i1 %_49, label %bb24, label %bb27

bb14:                                             ; preds = %bb18, %bb12
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp ugt i32 %_24, 1
  br i1 %_23, label %bb15, label %bb21

bb27:                                             ; preds = %bb24, %bb23
  %16 = load i32, ptr %exp, align 4
  %17 = udiv i32 %16, 2
  store i32 %17, ptr %exp, align 4
  %_66 = load i128, ptr %base, align 16
  %_67 = load i128, ptr %base, align 16
  %18 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_66, i128 %_67)
  %_5.0.i5 = extractvalue { i128, i1 } %18, 0
  %_5.1.i6 = extractvalue { i128, i1 } %18, 1
  store i128 %_5.0.i5, ptr %4, align 16
  %19 = getelementptr inbounds i8, ptr %4, i64 16
  %20 = zext i1 %_5.1.i6 to i8
  store i8 %20, ptr %19, align 16
  %_65.0 = load i128, ptr %4, align 16
  %21 = getelementptr inbounds i8, ptr %4, i64 16
  %22 = load i8, ptr %21, align 16
  %_65.1 = trunc nuw i8 %22 to i1
  store i128 %_65.0, ptr %base, align 16
  %23 = zext i1 %_65.1 to i8
  store i8 %23, ptr %tmp_overflow, align 1
  %24 = load i8, ptr %tmp_overflow, align 1
  %_68 = trunc nuw i8 %24 to i1
  %25 = load i8, ptr %overflow, align 1
  %26 = trunc nuw i8 %25 to i1
  %27 = or i1 %26, %_68
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %overflow, align 1
  br label %bb23

bb24:                                             ; preds = %bb23
  %_55 = load i128, ptr %acc, align 16
  %_56 = load i128, ptr %base, align 16
  %29 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_55, i128 %_56)
  %_5.0.i7 = extractvalue { i128, i1 } %29, 0
  %_5.1.i8 = extractvalue { i128, i1 } %29, 1
  store i128 %_5.0.i7, ptr %5, align 16
  %30 = getelementptr inbounds i8, ptr %5, i64 16
  %31 = zext i1 %_5.1.i8 to i8
  store i8 %31, ptr %30, align 16
  %_54.0 = load i128, ptr %5, align 16
  %32 = getelementptr inbounds i8, ptr %5, i64 16
  %33 = load i8, ptr %32, align 16
  %_54.1 = trunc nuw i8 %33 to i1
  store i128 %_54.0, ptr %acc, align 16
  %34 = zext i1 %_54.1 to i8
  store i8 %34, ptr %tmp_overflow, align 1
  %35 = load i8, ptr %tmp_overflow, align 1
  %_57 = trunc nuw i8 %35 to i1
  %36 = load i8, ptr %overflow, align 1
  %37 = trunc nuw i8 %36 to i1
  %38 = or i1 %37, %_57
  %39 = zext i1 %38 to i8
  store i8 %39, ptr %overflow, align 1
  %_59 = load i32, ptr %exp, align 4
  %_58 = icmp eq i32 %_59, 1
  br i1 %_58, label %bb26, label %bb27

bb26:                                             ; preds = %bb24
  %_60 = load i128, ptr %acc, align 16
  %40 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %40 to i1
  store i128 %_60, ptr %_0, align 16
  %41 = getelementptr inbounds i8, ptr %_0, i64 16
  %42 = zext i1 %_61 to i8
  store i8 %42, ptr %41, align 16
  br label %bb30

bb30:                                             ; preds = %bb8, %bb7, %bb11, %bb21, %bb26
  ret void

bb21:                                             ; preds = %bb14
  %_44 = load i128, ptr %acc, align 16
  %_45 = load i128, ptr %base, align 16
  %43 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_44, i128 %_45)
  %_5.0.i3 = extractvalue { i128, i1 } %43, 0
  %_5.1.i4 = extractvalue { i128, i1 } %43, 1
  store i128 %_5.0.i3, ptr %3, align 16
  %44 = getelementptr inbounds i8, ptr %3, i64 16
  %45 = zext i1 %_5.1.i4 to i8
  store i8 %45, ptr %44, align 16
  %_43.0 = load i128, ptr %3, align 16
  %46 = getelementptr inbounds i8, ptr %3, i64 16
  %47 = load i8, ptr %46, align 16
  %_43.1 = trunc nuw i8 %47 to i1
  store i128 %_43.0, ptr %acc, align 16
  %48 = zext i1 %_43.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_46
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  %_47 = load i128, ptr %acc, align 16
  %54 = load i8, ptr %overflow, align 1
  %_48 = trunc nuw i8 %54 to i1
  store i128 %_47, ptr %_0, align 16
  %55 = getelementptr inbounds i8, ptr %_0, i64 16
  %56 = zext i1 %_48 to i8
  store i8 %56, ptr %55, align 16
  br label %bb30

bb15:                                             ; preds = %bb14
  %_27 = load i32, ptr %exp, align 4
  %_26 = and i32 %_27, 1
  %_25 = icmp eq i32 %_26, 1
  br i1 %_25, label %bb16, label %bb18

bb18:                                             ; preds = %bb16, %bb15
  %57 = load i32, ptr %exp, align 4
  %58 = udiv i32 %57, 2
  store i32 %58, ptr %exp, align 4
  %_38 = load i128, ptr %base, align 16
  %_39 = load i128, ptr %base, align 16
  %59 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_38, i128 %_39)
  %_5.0.i = extractvalue { i128, i1 } %59, 0
  %_5.1.i = extractvalue { i128, i1 } %59, 1
  store i128 %_5.0.i, ptr %1, align 16
  %60 = getelementptr inbounds i8, ptr %1, i64 16
  %61 = zext i1 %_5.1.i to i8
  store i8 %61, ptr %60, align 16
  %_37.0 = load i128, ptr %1, align 16
  %62 = getelementptr inbounds i8, ptr %1, i64 16
  %63 = load i8, ptr %62, align 16
  %_37.1 = trunc nuw i8 %63 to i1
  store i128 %_37.0, ptr %base, align 16
  %64 = zext i1 %_37.1 to i8
  store i8 %64, ptr %tmp_overflow, align 1
  %65 = load i8, ptr %tmp_overflow, align 1
  %_40 = trunc nuw i8 %65 to i1
  %66 = load i8, ptr %overflow, align 1
  %67 = trunc nuw i8 %66 to i1
  %68 = or i1 %67, %_40
  %69 = zext i1 %68 to i8
  store i8 %69, ptr %overflow, align 1
  br label %bb14

bb16:                                             ; preds = %bb15
  %_31 = load i128, ptr %acc, align 16
  %_32 = load i128, ptr %base, align 16
  %70 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %_31, i128 %_32)
  %_5.0.i1 = extractvalue { i128, i1 } %70, 0
  %_5.1.i2 = extractvalue { i128, i1 } %70, 1
  store i128 %_5.0.i1, ptr %2, align 16
  %71 = getelementptr inbounds i8, ptr %2, i64 16
  %72 = zext i1 %_5.1.i2 to i8
  store i8 %72, ptr %71, align 16
  %_30.0 = load i128, ptr %2, align 16
  %73 = getelementptr inbounds i8, ptr %2, i64 16
  %74 = load i8, ptr %73, align 16
  %_30.1 = trunc nuw i8 %74 to i1
  store i128 %_30.0, ptr %acc, align 16
  %75 = zext i1 %_30.1 to i8
  store i8 %75, ptr %tmp_overflow, align 1
  %76 = load i8, ptr %tmp_overflow, align 1
  %_33 = trunc nuw i8 %76 to i1
  %77 = load i8, ptr %overflow, align 1
  %78 = trunc nuw i8 %77 to i1
  %79 = or i1 %78, %_33
  %80 = zext i1 %79 to i8
  store i8 %80, ptr %overflow, align 1
  br label %bb18

bb7:                                              ; preds = %bb4
  %81 = getelementptr inbounds i8, ptr %_14, i64 4
  %shift = load i32, ptr %81, align 4
; call <u128>::unbounded_shl
  %_17 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unbounded_shlCslb9dB7bEmfm_4i128(i128 1, i32 %shift) #16
  %_18 = icmp uge i32 %shift, 128
  store i128 %_17, ptr %_0, align 16
  %82 = getelementptr inbounds i8, ptr %_0, i64 16
  %83 = zext i1 %_18 to i8
  store i8 %83, ptr %82, align 16
  br label %bb30

bb8:                                              ; preds = %bb4
  store i128 0, ptr %_0, align 16
  %84 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 1, ptr %84, align 16
  br label %bb30

bb31:                                             ; No predecessors!
  unreachable
}

; <u128>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo3powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) unnamed_addr #0 !guid !163 {
start:
  %_0 = alloca [16 x i8], align 16
  br label %bb1

bb1:                                              ; preds = %start
; call <u128>::strict_pow
  %0 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo10strict_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp, ptr align 8 @alloc_c2df0f2eed0ee910e76dda7517cc7a45) #16
  store i128 %0, ptr %_0, align 16
  br label %bb3

bb2:                                              ; No predecessors!
; call <u128>::wrapping_pow
  %1 = call i128 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo12wrapping_powCslb9dB7bEmfm_4i128(i128 %self, i32 %exp) #16
  store i128 %1, ptr %_0, align 16
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i128, ptr %_0, align 16
  ret i128 %2
}

; <u128>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtCsl10jNU3mE6R_4core3numo5ilog2Cslb9dB7bEmfm_4i128(i128 %self, ptr align 8 %0) unnamed_addr #0 !guid !164 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u128>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs8_NtCsl10jNU3mE6R_4core3numo13checked_ilog2Cslb9dB7bEmfm_4i128(i128 %self) #16
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #18
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<u128>>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusiveoE8is_emptyCslb9dB7bEmfm_4i128(ptr align 16 %self) unnamed_addr #0 !guid !165 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = getelementptr inbounds i8, ptr %self, i64 32
  %1 = load i8, ptr %0, align 16
  %_2 = trunc nuw i8 %1 to i1
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_5 = getelementptr inbounds i8, ptr %self, i64 16
  %_3.i = load i128, ptr %self, align 16
  %_4.i = load i128, ptr %_5, align 16
  %_0.i = icmp ule i128 %_3.i, %_4.i
  %2 = xor i1 %_0.i, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb4

bb1:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cslb9dB7bEmfm_4i128(ptr %self) unnamed_addr #0 !guid !166 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <u128>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo14from_str_radixCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !167 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <u128>::from_ascii_bytes_radix_impl
  call void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo27from_ascii_bytes_radix_implCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #16
  ret void
}

; <u128>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo27from_ascii_bytes_radix_implCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !168 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [32 x i8], align 16
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [32 x i8], align 16
  %_74 = alloca [32 x i8], align 16
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [32 x i8], align 16
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [16 x i8], align 16
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_5aa1d1250638a5285856df0c8e3018a3) #20
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #16
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb11, %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb9

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !169
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i128 0, ptr %result, align 16
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 32
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; No predecessors!
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowoECslb9dB7bEmfm_4i128.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i128, ptr %result, align 16
  %33 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_105, ptr %33, align 16
  store i8 0, ptr %_0, align 16
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i128, ptr %result, align 16
  %_86 = zext i32 %radix to i128
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %mul1, i128 %_85, i128 %_86) #16
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %40 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_89, i32 %radix) #16
  %41 = extractvalue { i32, i32 } %40, 0
  %42 = extractvalue { i32, i32 } %40, 1
  store i32 %41, ptr %_88, align 4
  %43 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %42, ptr %43, align 4
  %44 = load i32, ptr %_88, align 4
  %45 = getelementptr inbounds i8, ptr %_88, i64 4
  %46 = load i32, ptr %45, align 4
  %_91 = zext i32 %44 to i64
  %47 = trunc nuw i64 %_91 to i1
  br i1 %47, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %48, align 4
  %x = zext i32 %value to i128
  %49 = load i128, ptr %mul1, align 16
  %50 = getelementptr inbounds i8, ptr %mul1, i64 16
  %51 = load i128, ptr %50, align 16
  %_95 = trunc i128 %49 to i64
  %52 = trunc nuw i64 %_95 to i1
  br i1 %52, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %53, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb48:                                             ; preds = %bb46
  %54 = getelementptr inbounds i8, ptr %mul1, i64 16
  %value4 = load i128, ptr %54, align 16
  store i128 %value4, ptr %result, align 16
  %_100 = load i128, ptr %result, align 16
; call <u128>::checked_sub
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_99, i128 %_100, i128 %x) #16
  %55 = load i128, ptr %_99, align 16
  %56 = getelementptr inbounds i8, ptr %_99, i64 16
  %57 = load i128, ptr %56, align 16
  %_101 = trunc i128 %55 to i64
  %58 = trunc nuw i64 %_101 to i1
  br i1 %58, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %59, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb51:                                             ; preds = %bb48
  %60 = getelementptr inbounds i8, ptr %_99, i64 16
  %value5 = load i128, ptr %60, align 16
  store i128 %value5, ptr %result, align 16
  store ptr %rest.02, ptr %digits, align 8, !captures !169
  %61 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %61, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %62 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %62, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb31:                                             ; preds = %bb30
  %63 = load ptr, ptr %digits, align 8
  %64 = getelementptr inbounds i8, ptr %digits, i64 8
  %65 = load i64, ptr %64, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %63, i64 0
  %66 = load ptr, ptr %digits, align 8
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  %68 = load i64, ptr %67, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %66, i64 1
  %rest.18 = sub i64 %68, 1
  %_60 = load i128, ptr %result, align 16
  %_61 = zext i32 %radix to i128
; call <u128>::checked_mul
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %mul, i128 %_60, i128 %_61) #16
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %69 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_64, i32 %radix) #16
  %70 = extractvalue { i32, i32 } %69, 0
  %71 = extractvalue { i32, i32 } %69, 1
  store i32 %70, ptr %_63, align 4
  %72 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %71, ptr %72, align 4
  %73 = load i32, ptr %_63, align 4
  %74 = getelementptr inbounds i8, ptr %_63, i64 4
  %75 = load i32, ptr %74, align 4
  %_66 = zext i32 %73 to i64
  %76 = trunc nuw i64 %_66 to i1
  br i1 %76, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %77 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %77, align 4
  %x10 = zext i32 %value9 to i128
  %78 = load i128, ptr %mul, align 16
  %79 = getelementptr inbounds i8, ptr %mul, i64 16
  %80 = load i128, ptr %79, align 16
  %_70 = trunc i128 %78 to i64
  %81 = trunc nuw i64 %_70 to i1
  br i1 %81, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %82 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %82, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb37:                                             ; preds = %bb35
  %83 = getelementptr inbounds i8, ptr %mul, i64 16
  %value11 = load i128, ptr %83, align 16
  store i128 %value11, ptr %result, align 16
  %_75 = load i128, ptr %result, align 16
; call <u128>::checked_add
  call void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_74, i128 %_75, i128 %x10) #16
  %84 = load i128, ptr %_74, align 16
  %85 = getelementptr inbounds i8, ptr %_74, i64 16
  %86 = load i128, ptr %85, align 16
  %_76 = trunc i128 %84 to i64
  %87 = trunc nuw i64 %_76 to i1
  br i1 %87, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %88 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %88, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb40:                                             ; preds = %bb37
  %89 = getelementptr inbounds i8, ptr %_74, i64 16
  %value12 = load i128, ptr %89, align 16
  store i128 %value12, ptr %result, align 16
  store ptr %rest.07, ptr %digits, align 8, !captures !169
  %90 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %90, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %91, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %92 = load ptr, ptr %digits, align 8
  %93 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %93, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %94 = load ptr, ptr %digits, align 8
  %95 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %95, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %96 = load ptr, ptr %digits, align 8
  %97 = getelementptr inbounds i8, ptr %digits, i64 8
  %98 = load i64, ptr %97, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %96, i64 0
  %99 = load ptr, ptr %digits, align 8
  %100 = getelementptr inbounds i8, ptr %digits, i64 8
  %101 = load i64, ptr %100, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %99, i64 1
  %rest.115 = sub i64 %101, 1
  %_44 = load i128, ptr %result, align 16
  %_45 = zext i32 %radix to i128
  %102 = mul i128 %_44, %_45
  store i128 %102, ptr %result, align 16
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %103 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_47, i32 %radix) #16
  %104 = extractvalue { i32, i32 } %103, 0
  %105 = extractvalue { i32, i32 } %103, 1
  store i32 %104, ptr %_46, align 4
  %106 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %105, ptr %106, align 4
  %107 = load i32, ptr %_46, align 4
  %108 = getelementptr inbounds i8, ptr %_46, i64 4
  %109 = load i32, ptr %108, align 4
  %_49 = zext i32 %107 to i64
  %110 = trunc nuw i64 %_49 to i1
  br i1 %110, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %111 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %111, align 4
  %_53 = load i128, ptr %result, align 16
  %_54 = zext i32 %x16 to i128
  %112 = sub i128 %_53, %_54
  store i128 %112, ptr %result, align 16
  store ptr %rest.014, ptr %digits, align 8, !captures !169
  %113 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %113, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %114 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %114, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb19:                                             ; preds = %bb18
  %115 = load ptr, ptr %digits, align 8
  %116 = getelementptr inbounds i8, ptr %digits, i64 8
  %117 = load i64, ptr %116, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %115, i64 0
  %118 = load ptr, ptr %digits, align 8
  %119 = getelementptr inbounds i8, ptr %digits, i64 8
  %120 = load i64, ptr %119, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %118, i64 1
  %rest.119 = sub i64 %120, 1
  %_29 = load i128, ptr %result, align 16
  %_30 = zext i32 %radix to i128
  %121 = mul i128 %_29, %_30
  store i128 %121, ptr %result, align 16
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %122 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_32, i32 %radix) #16
  %123 = extractvalue { i32, i32 } %122, 0
  %124 = extractvalue { i32, i32 } %122, 1
  store i32 %123, ptr %_31, align 4
  %125 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %124, ptr %125, align 4
  %126 = load i32, ptr %_31, align 4
  %127 = getelementptr inbounds i8, ptr %_31, i64 4
  %128 = load i32, ptr %127, align 4
  %_34 = zext i32 %126 to i64
  %129 = trunc nuw i64 %_34 to i1
  br i1 %129, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %130 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %130, align 4
  %_38 = load i128, ptr %result, align 16
  %_39 = zext i32 %x20 to i128
  %131 = add i128 %_38, %_39
  store i128 %131, ptr %result, align 16
  store ptr %rest.018, ptr %digits, align 8, !captures !169
  %132 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %132, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %133 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %133, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cslb9dB7bEmfm_4i128(i8 %0) unnamed_addr #0 !guid !170 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cslb9dB7bEmfm_4i128(ptr %self) #16
  ret i32 %_0
}

; <i128>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMst_NtCsl10jNU3mE6R_4core3numn14from_str_radixCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !171 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <i128>::from_ascii_bytes_radix_impl
  call void @_RNvMst_NtCsl10jNU3mE6R_4core3numn27from_ascii_bytes_radix_implCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #16
  ret void
}

; <i128>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMst_NtCsl10jNU3mE6R_4core3numn27from_ascii_bytes_radix_implCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !172 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [32 x i8], align 16
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [32 x i8], align 16
  %_74 = alloca [32 x i8], align 16
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [32 x i8], align 16
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [16 x i8], align 16
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_95d8d5f2b11616ba93f9dc409471c349) #20
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #16
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb14

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !169
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i128 0, ptr %result, align 16
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 31
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; preds = %bb11
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflownECslb9dB7bEmfm_4i128.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i128, ptr %result, align 16
  %33 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_105, ptr %33, align 16
  store i8 0, ptr %_0, align 16
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i128, ptr %result, align 16
  %_86 = zext i32 %radix to i128
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %mul1, i128 %_85, i128 %_86) #16
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %40 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_89, i32 %radix) #16
  %41 = extractvalue { i32, i32 } %40, 0
  %42 = extractvalue { i32, i32 } %40, 1
  store i32 %41, ptr %_88, align 4
  %43 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %42, ptr %43, align 4
  %44 = load i32, ptr %_88, align 4
  %45 = getelementptr inbounds i8, ptr %_88, i64 4
  %46 = load i32, ptr %45, align 4
  %_91 = zext i32 %44 to i64
  %47 = trunc nuw i64 %_91 to i1
  br i1 %47, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %48 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %48, align 4
  %x = zext i32 %value to i128
  %49 = load i128, ptr %mul1, align 16
  %50 = getelementptr inbounds i8, ptr %mul1, i64 16
  %51 = load i128, ptr %50, align 16
  %_95 = trunc i128 %49 to i64
  %52 = trunc nuw i64 %_95 to i1
  br i1 %52, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %53 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %53, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb48:                                             ; preds = %bb46
  %54 = getelementptr inbounds i8, ptr %mul1, i64 16
  %value4 = load i128, ptr %54, align 16
  store i128 %value4, ptr %result, align 16
  %_100 = load i128, ptr %result, align 16
; call <i128>::checked_sub
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_subCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_99, i128 %_100, i128 %x) #16
  %55 = load i128, ptr %_99, align 16
  %56 = getelementptr inbounds i8, ptr %_99, i64 16
  %57 = load i128, ptr %56, align 16
  %_101 = trunc i128 %55 to i64
  %58 = trunc nuw i64 %_101 to i1
  br i1 %58, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %59 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %59, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb51:                                             ; preds = %bb48
  %60 = getelementptr inbounds i8, ptr %_99, i64 16
  %value5 = load i128, ptr %60, align 16
  store i128 %value5, ptr %result, align 16
  store ptr %rest.02, ptr %digits, align 8, !captures !169
  %61 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %61, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %62 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %62, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb31:                                             ; preds = %bb30
  %63 = load ptr, ptr %digits, align 8
  %64 = getelementptr inbounds i8, ptr %digits, i64 8
  %65 = load i64, ptr %64, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %63, i64 0
  %66 = load ptr, ptr %digits, align 8
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  %68 = load i64, ptr %67, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %66, i64 1
  %rest.18 = sub i64 %68, 1
  %_60 = load i128, ptr %result, align 16
  %_61 = zext i32 %radix to i128
; call <i128>::checked_mul
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %mul, i128 %_60, i128 %_61) #16
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %69 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_64, i32 %radix) #16
  %70 = extractvalue { i32, i32 } %69, 0
  %71 = extractvalue { i32, i32 } %69, 1
  store i32 %70, ptr %_63, align 4
  %72 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %71, ptr %72, align 4
  %73 = load i32, ptr %_63, align 4
  %74 = getelementptr inbounds i8, ptr %_63, i64 4
  %75 = load i32, ptr %74, align 4
  %_66 = zext i32 %73 to i64
  %76 = trunc nuw i64 %_66 to i1
  br i1 %76, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %77 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %77, align 4
  %x10 = zext i32 %value9 to i128
  %78 = load i128, ptr %mul, align 16
  %79 = getelementptr inbounds i8, ptr %mul, i64 16
  %80 = load i128, ptr %79, align 16
  %_70 = trunc i128 %78 to i64
  %81 = trunc nuw i64 %_70 to i1
  br i1 %81, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %82 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %82, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb37:                                             ; preds = %bb35
  %83 = getelementptr inbounds i8, ptr %mul, i64 16
  %value11 = load i128, ptr %83, align 16
  store i128 %value11, ptr %result, align 16
  %_75 = load i128, ptr %result, align 16
; call <i128>::checked_add
  call void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_addCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_74, i128 %_75, i128 %x10) #16
  %84 = load i128, ptr %_74, align 16
  %85 = getelementptr inbounds i8, ptr %_74, i64 16
  %86 = load i128, ptr %85, align 16
  %_76 = trunc i128 %84 to i64
  %87 = trunc nuw i64 %_76 to i1
  br i1 %87, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %88 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %88, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb40:                                             ; preds = %bb37
  %89 = getelementptr inbounds i8, ptr %_74, i64 16
  %value12 = load i128, ptr %89, align 16
  store i128 %value12, ptr %result, align 16
  store ptr %rest.07, ptr %digits, align 8, !captures !169
  %90 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %90, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %91, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %92 = load ptr, ptr %digits, align 8
  %93 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %93, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %94 = load ptr, ptr %digits, align 8
  %95 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %95, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %96 = load ptr, ptr %digits, align 8
  %97 = getelementptr inbounds i8, ptr %digits, i64 8
  %98 = load i64, ptr %97, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %96, i64 0
  %99 = load ptr, ptr %digits, align 8
  %100 = getelementptr inbounds i8, ptr %digits, i64 8
  %101 = load i64, ptr %100, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %99, i64 1
  %rest.115 = sub i64 %101, 1
  %_44 = load i128, ptr %result, align 16
  %_45 = zext i32 %radix to i128
  %102 = mul i128 %_44, %_45
  store i128 %102, ptr %result, align 16
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %103 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_47, i32 %radix) #16
  %104 = extractvalue { i32, i32 } %103, 0
  %105 = extractvalue { i32, i32 } %103, 1
  store i32 %104, ptr %_46, align 4
  %106 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %105, ptr %106, align 4
  %107 = load i32, ptr %_46, align 4
  %108 = getelementptr inbounds i8, ptr %_46, i64 4
  %109 = load i32, ptr %108, align 4
  %_49 = zext i32 %107 to i64
  %110 = trunc nuw i64 %_49 to i1
  br i1 %110, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %111 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %111, align 4
  %_53 = load i128, ptr %result, align 16
  %_54 = zext i32 %x16 to i128
  %112 = sub i128 %_53, %_54
  store i128 %112, ptr %result, align 16
  store ptr %rest.014, ptr %digits, align 8, !captures !169
  %113 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %113, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %114 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %114, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb19:                                             ; preds = %bb18
  %115 = load ptr, ptr %digits, align 8
  %116 = getelementptr inbounds i8, ptr %digits, i64 8
  %117 = load i64, ptr %116, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %115, i64 0
  %118 = load ptr, ptr %digits, align 8
  %119 = getelementptr inbounds i8, ptr %digits, i64 8
  %120 = load i64, ptr %119, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %118, i64 1
  %rest.119 = sub i64 %120, 1
  %_29 = load i128, ptr %result, align 16
  %_30 = zext i32 %radix to i128
  %121 = mul i128 %_29, %_30
  store i128 %121, ptr %result, align 16
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %122 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCslb9dB7bEmfm_4i128(i32 %_32, i32 %radix) #16
  %123 = extractvalue { i32, i32 } %122, 0
  %124 = extractvalue { i32, i32 } %122, 1
  store i32 %123, ptr %_31, align 4
  %125 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %124, ptr %125, align 4
  %126 = load i32, ptr %_31, align 4
  %127 = getelementptr inbounds i8, ptr %_31, i64 4
  %128 = load i32, ptr %127, align 4
  %_34 = zext i32 %126 to i64
  %129 = trunc nuw i64 %_34 to i1
  br i1 %129, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %130 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %130, align 4
  %_38 = load i128, ptr %result, align 16
  %_39 = zext i32 %x20 to i128
  %131 = add i128 %_38, %_39
  store i128 %131, ptr %result, align 16
  store ptr %rest.018, ptr %digits, align 8, !captures !169
  %132 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %132, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %133 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %133, align 1
  store i8 1, ptr %_0, align 16
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCslb9dB7bEmfm_4i128() unnamed_addr #4 !guid !173 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !174 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCslb9dB7bEmfm_4i128() #16
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCslb9dB7bEmfm_4i128(i32 %code, ptr %dst) unnamed_addr #0 !guid !175 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cslb9dB7bEmfm_4i128(i32 %code) #16
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cslb9dB7bEmfm_4i128(i32 %code) unnamed_addr #0 !guid !176 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; <i128>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs2_NtCsl10jNU3mE6R_4core3numn13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !177 {
start:
  %_2 = icmp ult i32 %rhs, 128
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_a61ecf1bbb59a9a75a6a223b3f565d28, i64 185)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; <u128>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add18precondition_checkCslb9dB7bEmfm_4i128(i128 %lhs, i128 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !178 {
start:
  %1 = alloca [32 x i8], align 16
  %_5.0.i = add i128 %lhs, %rhs
  %_5.1.i = icmp ult i128 %_5.0.i, %lhs
  store i128 %_5.0.i, ptr %1, align 16
  %2 = getelementptr inbounds i8, ptr %1, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  br label %bb1

terminate:                                        ; preds = %bb2
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = load i128, ptr %1, align 16
  %5 = getelementptr inbounds i8, ptr %1, i64 16
  %6 = load i8, ptr %5, align 16
  %_4.1 = trunc nuw i8 %6 to i1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %7 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_0a7ace845dda78b0b3e088b89fa358fb, i64 185)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %7, 0
  %_6.1 = extractvalue { ptr, ptr } %7, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; <u128>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_shl18precondition_checkCslb9dB7bEmfm_4i128(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !179 {
start:
  %_2 = icmp ult i32 %rhs, 128
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCslb9dB7bEmfm_4i128(ptr @alloc_8efb6cb47e437ad05e23651986f609b7, i64 185)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #24
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !180 {
start:
  ret i1 true
}

; <core::ops::range::Range<u128> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangeoENtB2_12IntoIterator9into_iterCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, i128 %self.0, i128 %self.1) unnamed_addr #0 !guid !181 {
start:
  store i128 %self.0, ptr %_0, align 16
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %self.1, ptr %0, align 16
  ret void
}

; <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuitoEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !182 {
start:
  unreachable
}

; <(u128, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTobENtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #1 !guid !183 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <i128 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1Q_NtCs7CppTae75M1_5alloc6stringnNtB6_12SpecToString14spec_to_stringCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) unnamed_addr #0 personality ptr @rust_eh_personality !guid !184 {
start:
  %0 = alloca [16 x i8], align 8
  %_19 = alloca [1 x i8], align 1
  %_11 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  %out = alloca [24 x i8], align 8
  %buf = alloca [39 x i8], align 1
  store i8 0, ptr %_19, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 39, i1 false)
  %_6 = load i128, ptr %self, align 16
  %_5 = icmp slt i128 %_6, 0
  br i1 %_5, label %bb2, label %bb4

bb4:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_11, i64 39)
          to label %bb5 unwind label %cleanup

bb2:                                              ; preds = %start
; invoke <alloc::string::String>::with_capacity
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String13with_capacityCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_7, i64 40)
          to label %bb3 unwind label %cleanup

bb12:                                             ; preds = %cleanup
  %1 = load i8, ptr %_19, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb11, label %bb10

cleanup:                                          ; preds = %bb8, %bb7, %bb6, %bb3, %bb2, %bb4
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb12

bb5:                                              ; preds = %bb4
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_11, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb13, %bb5
  %_16 = load i128, ptr %self, align 16
; invoke <i128>::unsigned_abs
  %_15 = invoke i128 @_RNvMs2_NtCsl10jNU3mE6R_4core3numn12unsigned_absCslb9dB7bEmfm_4i128(i128 %_16)
          to label %bb7 unwind label %cleanup

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %out, ptr align 8 %_7, i64 24, i1 false)
; invoke <alloc::string::String>::push
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCslb9dB7bEmfm_4i128(ptr align 8 %out, i32 45)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb3
  br label %bb6

bb7:                                              ; preds = %bb6
; invoke <u128>::_fmt
  %7 = invoke { ptr, i64 } @_RNvMs0_NtNtCsl10jNU3mE6R_4core3fmt3numo4__fmt(i128 %_15, ptr %buf, i64 39)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %_14.0 = extractvalue { ptr, i64 } %7, 0
  %_14.1 = extractvalue { ptr, i64 } %7, 1
; invoke <alloc::string::String>::push_str
  invoke void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String8push_strCslb9dB7bEmfm_4i128(ptr align 8 %out, ptr %_14.0, i64 %_14.1)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_19, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %out, i64 24, i1 false)
  store i8 0, ptr %_19, align 1
  ret void

bb10:                                             ; preds = %bb11, %bb12
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb11:                                             ; preds = %bb12
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %out) #21
          to label %bb10 unwind label %terminate

terminate:                                        ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !185 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr %_3, ptr align 8 %f) #16
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !186 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCslb9dB7bEmfm_4i128(ptr %_3, ptr align 8 %f) #16
  ret i1 %_0
}

; <&i128 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRnNtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !187 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i128 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %_3, ptr align 8 %f) #16
  ret i1 %_0
}

; <&u128 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRoNtB6_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !188 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u128 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %_3, ptr align 8 %f) #16
  ret i1 %_0
}

; <core::ops::range::Range<u128> as core::iter::range::RangeIteratorImpl>::spec_next
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs3_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeoENtB5_17RangeIteratorImpl9spec_nextCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr align 16 %self) unnamed_addr #0 !guid !189 {
start:
  %_4 = getelementptr inbounds i8, ptr %self, i64 16
  %_3.i = load i128, ptr %self, align 16
  %_4.i = load i128, ptr %_4, align 16
  %_0.i = icmp ult i128 %_3.i, %_4.i
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i128 0, ptr %_0, align 16
  br label %bb5

bb2:                                              ; preds = %start
  %old = load i128, ptr %self, align 16
; call <u128 as core::iter::range::Step>::forward_unchecked
  %_6 = call i128 @_RNvXsN_NtNtCsl10jNU3mE6R_4core4iter5rangeoNtB5_4Step17forward_uncheckedCslb9dB7bEmfm_4i128(i128 %old, i64 1) #16
  store i128 %_6, ptr %self, align 16
  %0 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %old, ptr %0, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  ret void
}

; <core::ops::range::Range<u128> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeoENtNtNtB7_6traits8iterator8Iterator4nextCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr align 16 %self) unnamed_addr #0 !guid !190 {
start:
; call <core::ops::range::Range<u128> as core::iter::range::RangeIteratorImpl>::spec_next
  call void @_RNvXs3_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeoENtB5_17RangeIteratorImpl9spec_nextCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr align 16 %self) #16
  ret void
}

; <i128 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringnNtB5_8ToString9to_stringCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) unnamed_addr #0 !guid !191 {
start:
; call <i128 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1Q_NtCs7CppTae75M1_5alloc6stringnNtB6_12SpecToString14spec_to_stringCslb9dB7bEmfm_4i128(ptr sret([24 x i8]) align 8 %_0, ptr align 16 %self) #16
  ret void
}

; <u128 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsE_NtCsl10jNU3mE6R_4core3numoNtNtNtB7_3str6traits7FromStr8from_strCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !192 {
start:
; call <u128>::from_str_radix
  call void @_RNvMsF_NtCsl10jNU3mE6R_4core3numo14from_str_radixCslb9dB7bEmfm_4i128(ptr sret([32 x i8]) align 16 %_0, ptr %src.0, i64 %src.1, i32 10) #16
  ret void
}

; <u128 as core::iter::range::Step>::forward_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvXsN_NtNtCsl10jNU3mE6R_4core4iter5rangeoNtB5_4Step17forward_uncheckedCslb9dB7bEmfm_4i128(i128 %start1, i64 %n) unnamed_addr #0 !guid !193 {
start:
  %_3 = zext i64 %n to i128
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCslb9dB7bEmfm_4i128() #16
  br i1 %_3.i, label %bb2.i, label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <u128>::unchecked_add::precondition_check
  call void @_RNvNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add18precondition_checkCslb9dB7bEmfm_4i128(i128 %start1, i128 %_3, ptr align 8 @alloc_33c781d4b73231c4b72218e776044e11) #23
  br label %_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add.exit

_RNvMs8_NtCsl10jNU3mE6R_4core3numo13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i128 %start1, %_3
  ret i128 %_0.i
}

; <core::option::Option<i128> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionnENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !194 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i128, ptr %self, align 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i128, ptr %1, align 16
  %_3 = trunc i128 %0 to i64
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %4, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.3)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <i128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsS_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !195 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCslb9dB7bEmfm_4i128() unnamed_addr #0 !guid !196 {
start:
  ret i8 0
}

; <u128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !197 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::from_output
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try11from_outputCslb9dB7bEmfm_4i128(i128 %x) unnamed_addr #0 !guid !198 {
start:
  ret i128 %x
}

; <core::ops::try_trait::NeverShortCircuit<u128> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuitoENtB4_3Try6branchCslb9dB7bEmfm_4i128(i128 %self) unnamed_addr #0 !guid !199 {
start:
  ret i128 %self
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !200 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.4)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCslb9dB7bEmfm_4i128(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !201 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <u128 as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXso_NtNtCsl10jNU3mE6R_4core3cmp5implsoNtB7_9PartialEq2eqCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 16 %other) unnamed_addr #0 !guid !202 {
start:
  %_3 = load i128, ptr %self, align 16
  %_4 = load i128, ptr %other, align 16
  %_0 = icmp eq i128 %_3, %_4
  ret i1 %_0
}

; <core::result::Result<i128, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultnNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !203 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.5)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.3)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u128, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultoNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCslb9dB7bEmfm_4i128(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !204 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 16
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.5)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCslb9dB7bEmfm_4i128(ptr %_1) unnamed_addr #0 !guid !205 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCslb9dB7bEmfm_4i128(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !206 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cslb9dB7bEmfm_4i128(ptr align 8 %_1) #16
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<u128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16) unnamed_addr #0

; <core::ptr::non_null::NonNull<u128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr) unnamed_addr #0

; <u128 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsG_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_6Binary3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fshl.i128(i128, i128, i128) #9

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.umul.with.overflow.i128(i128, i128) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <core::ops::range::Range<u32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { i32, i32 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangemENtB2_12IntoIterator9into_iterCsddYV2PBJW9h_3std(i32, i32) unnamed_addr #0

; <core::ops::range::Range<u32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i32, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangemENtNtNtB7_6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 4) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.smul.with.overflow.i128(i128, i128) #9

; <core::fmt::rt::Argument>::new_lower_hex::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoEB7_(ptr sret([16 x i8]) align 8, ptr align 16) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptoui.sat.i128.f64(double) #9

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <alloc::vec::Vec<u8>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE13with_capacityB4_(ptr sret([24 x i8]) align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8, i64) unnamed_addr #1

; <alloc::vec::Vec<u8>>::extend_from_slice
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs1_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE17extend_from_sliceB7_(ptr align 8, ptr, i64) unnamed_addr #1

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; <core::num::nonzero::NonZero<u128>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3getB9_(i128) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctlz.i128(i128, i1 immarg) #10

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #11

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i128(i128) #12

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.sadd.with.overflow.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.ssub.with.overflow.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.scmp.i8.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctpop.i128(i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.bswap.i128(i128) #9

; <core::num::nonzero::NonZero<u128>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i128 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerooE3newB9_(i128) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.cttz.i128(i128, i1 immarg) #10

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #11

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #13

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #14

; <u128>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMs0_NtNtCsl10jNU3mE6R_4core3fmt3numo4__fmt(i128, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <i128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsN_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsL_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #15 !guid !207 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECslb9dB7bEmfm_4i128(ptr @_RNvCslb9dB7bEmfm_4i1284main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #13 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #15 = { nonlazybind "target-cpu"="x86-64" }
attributes #16 = { inlinehint }
attributes #17 = { cold noreturn nounwind }
attributes #18 = { noreturn }
attributes #19 = { noinline }
attributes #20 = { noinline noreturn }
attributes #21 = { cold }
attributes #22 = { nounwind }
attributes #23 = { inlinehint nounwind }
attributes #24 = { noinline noreturn nounwind }

!llvm.module.flags = !{!62, !63, !64, !65}
!llvm.ident = !{!66}

!0 = !{i64 -5504693897185574227}
!1 = !{i64 6752566917541923232}
!2 = !{i64 7847232629089198816}
!3 = !{i64 7630217150995860364}
!4 = !{i64 1020680681060563780}
!5 = !{i64 5466972635669489271}
!6 = !{i64 -1603777224916230544}
!7 = !{i64 -5318720045756851679}
!8 = !{i64 -1223774367015685877}
!9 = !{i64 -7804457772303051037}
!10 = !{i64 7736776545110476329}
!11 = !{i64 8814352253862276746}
!12 = !{i64 -711576951763271182}
!13 = !{i64 1655077548292016247}
!14 = !{i64 -8019968541310062606}
!15 = !{i64 -6671237027540693338}
!16 = !{i64 9141949013091343782}
!17 = !{i64 -102289616897861015}
!18 = !{i64 -4561311732411537725}
!19 = !{i64 4320267917774362211}
!20 = !{i64 4029192780990706030}
!21 = !{i64 4313470063300800488}
!22 = !{i64 -5904292005820464313}
!23 = !{i64 9182592716985847358}
!24 = !{i64 2621139890761912644}
!25 = !{i64 1164472438472999170}
!26 = !{i64 -6775695221895673146}
!27 = !{i64 -5783937569863468405}
!28 = !{i64 6324804995804271065}
!29 = !{i64 381663104455277784}
!30 = !{i64 5294425701984717739}
!31 = !{i64 6016094893395919676}
!32 = !{i64 3524325048052811794}
!33 = !{i64 -5443235764592138097}
!34 = !{i64 -7485225284348130659}
!35 = !{i64 8789638200438548937}
!36 = !{i64 -3352847084774899118}
!37 = !{i64 5820140113242579464}
!38 = !{i64 2153018311637797844}
!39 = !{i64 -6331533952870487899}
!40 = !{i64 978208654807939347}
!41 = !{i64 -2106040979431644288}
!42 = !{i64 3968122229295321819}
!43 = !{i64 169637462205761434}
!44 = !{i64 -2418670075217944104}
!45 = !{i64 -2676022159366810638}
!46 = !{i64 -9051252685141791954}
!47 = !{i64 2018242790289851655}
!48 = !{i64 1383717064235074445}
!49 = !{i64 -673729340857531339}
!50 = !{i64 -4338423467705606211}
!51 = !{i64 -3149269750772788059}
!52 = !{i64 -6412307801867740627}
!53 = !{i64 -4129257768837388422}
!54 = !{i64 6861954640173613936}
!55 = !{i64 -4125794123188860915}
!56 = !{i64 3303391139385051624}
!57 = !{i64 1532877386217578682}
!58 = !{i64 -350047851946602143}
!59 = !{i64 -8225965804835979707}
!60 = !{i64 1466255506623189355}
!61 = !{i64 7143505685684016317}
!62 = !{i32 8, !"PIC Level", i32 2}
!63 = !{i32 7, !"PIE Level", i32 2}
!64 = !{i32 2, !"RtLibUseGOT", i32 1}
!65 = !{i32 7, !"uwtable", i32 2}
!66 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!67 = !{i64 -2991922311042110960}
!68 = !{i64 -4882793336336601282}
!69 = !{i64 969844502574687892}
!70 = !{i64 -2528439721320769821}
!71 = !{i64 -901166237010469562}
!72 = !{i64 1611489904889652125}
!73 = !{i64 -7272344199612585495}
!74 = !{i64 9015360776967343414}
!75 = !{i64 -1350338428696841391}
!76 = !{i64 -3042105124150388672}
!77 = !{i64 4421413679223968237}
!78 = !{i64 4692999918664995619}
!79 = !{i64 -2178109646149567018}
!80 = !{i64 2725014548163139257}
!81 = !{i64 4158979729893124610}
!82 = !{i64 -6988999524817056993}
!83 = !{i64 8973047744386860681}
!84 = !{i64 -3092674888136446552}
!85 = !{i64 7573544871237015895}
!86 = !{i64 3752185764298195771}
!87 = !{i64 3080402152468764012}
!88 = !{i64 6916609482075893846}
!89 = !{i64 -6576830451758063193}
!90 = !{i64 7059196380874794888}
!91 = !{i64 5869777084600054588}
!92 = !{i64 -1512061699151555852}
!93 = !{i64 -7288406837322929345}
!94 = !{i64 1321776185651715}
!95 = !{i64 -1434127206302617491}
!96 = !{i64 7722803374290433029}
!97 = !{i64 6330846467900472708}
!98 = !{i64 6007201566191019413}
!99 = !{i64 106330428343651768}
!100 = !{i64 8395763167902274750}
!101 = !{i64 7051847956661925544}
!102 = !{i64 3425455538182589460}
!103 = !{i64 -5606435753056509808}
!104 = !{i64 -1987608644671707466}
!105 = !{i64 -6751104438259772443}
!106 = !{i64 -7121960573821425818}
!107 = !{i64 455873936820647984}
!108 = !{i64 1628106762800104931}
!109 = !{i64 -9207548364177370796}
!110 = !{i64 328800606439207697}
!111 = !{i64 2003184415650660797}
!112 = !{i64 5358566147489511842}
!113 = !{i64 8330084808239917428}
!114 = !{i64 -8541027477092686323}
!115 = !{i64 48114793529133271}
!116 = !{i64 5263469266882668322}
!117 = !{i64 -6880113238942567523}
!118 = !{i64 -6796629583038610375}
!119 = !{i64 -8486700951829503781}
!120 = !{i64 5981772414110969816}
!121 = !{i64 6687607179319565374}
!122 = !{i64 -3848605664371700503}
!123 = !{i64 -4475107560599991547}
!124 = !{i64 -6352878599930857752}
!125 = !{i64 4784035891537617364}
!126 = !{i64 1275211415580900949}
!127 = !{i64 6151374798656605670}
!128 = !{i64 -6590435938624901381}
!129 = !{i64 -6679411355634689292}
!130 = !{i64 -1944585673585489819}
!131 = !{i64 5204632748568558884}
!132 = !{i64 -239316847128127948}
!133 = !{i64 3530215624846591827}
!134 = !{i64 -1818608093644890482}
!135 = !{i64 -4973568810596850101}
!136 = !{i64 -4603308381507937192}
!137 = !{i64 3309770453553324033}
!138 = !{i64 -8490550726926834086}
!139 = !{i64 -8773037305889849284}
!140 = !{i64 -6350536078702542174}
!141 = !{i64 -5293429588112912913}
!142 = !{i64 2354479160373909326}
!143 = !{i64 -9109130415284255480}
!144 = !{i64 -5435475631469033718}
!145 = !{i64 -209617849812936162}
!146 = !{i64 -1024768595243897889}
!147 = !{i64 -3909316003954290851}
!148 = !{i64 -3143360498099782013}
!149 = !{i64 6124554463058890679}
!150 = !{i64 3362243549846705247}
!151 = !{i64 4556795124238671478}
!152 = !{i64 1961180970265101562}
!153 = !{i64 -8792607597251850711}
!154 = !{i64 3737003848858681062}
!155 = !{i64 -485992297852732083}
!156 = !{i64 -6864493140658332725}
!157 = !{i64 -8903409137812743645}
!158 = !{i64 -3134047189049861460}
!159 = !{i64 -2020584228562833288}
!160 = !{i64 1218575074543699017}
!161 = !{i64 4949777936541987610}
!162 = !{i64 590690473530643635}
!163 = !{i64 8648875566536733220}
!164 = !{i64 -6273046274682549452}
!165 = !{i64 7980362367074631991}
!166 = !{i64 -2274897278884099444}
!167 = !{i64 6468128081434734209}
!168 = !{i64 -7568976404740568073}
!169 = !{!"address", !"read_provenance"}
!170 = !{i64 8898414684201759927}
!171 = !{i64 458424633268215440}
!172 = !{i64 -1094465159319220672}
!173 = !{i64 2773850350876936276}
!174 = !{i64 -1802583778875648401}
!175 = !{i64 8819985125627084430}
!176 = !{i64 4227012187807247923}
!177 = !{i64 -385091251504674648}
!178 = !{i64 5841215528547501717}
!179 = !{i64 5532653616918875265}
!180 = !{i64 -6564508401863674970}
!181 = !{i64 5601890870797923404}
!182 = !{i64 -2800470948186194984}
!183 = !{i64 -7530225640381037273}
!184 = !{i64 826193452808930088}
!185 = !{i64 -150055213117969312}
!186 = !{i64 5968845039794563281}
!187 = !{i64 -2537770289531586439}
!188 = !{i64 -6707128592085258761}
!189 = !{i64 -8224941131115502490}
!190 = !{i64 7015310900092167666}
!191 = !{i64 -6684146104695323418}
!192 = !{i64 6702109726542682835}
!193 = !{i64 1994678390763558876}
!194 = !{i64 7197725865025501073}
!195 = !{i64 -2541587727500646533}
!196 = !{i64 3514845597960991514}
!197 = !{i64 165798559502701585}
!198 = !{i64 7312570849407532261}
!199 = !{i64 2002459514283861933}
!200 = !{i64 -3749985272951862212}
!201 = !{i64 4436775270683418286}
!202 = !{i64 7273480327350717666}
!203 = !{i64 -2934153529646918790}
!204 = !{i64 -6821244322942678763}
!205 = !{i64 5366874049115495346}
!206 = !{i64 311657846183830845}
!207 = !{i64 -2624081020897602054}
