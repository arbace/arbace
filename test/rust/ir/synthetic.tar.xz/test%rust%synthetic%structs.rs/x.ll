; ModuleID = 'structs.2341239319d38580-cgu.0'
source_filename = "structs.2341239319d38580-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%Version = type { i8, i8, i8 }
%Token = type { i32, [3 x i32] }
%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }
%"core::mem::maybe_uninit::MaybeUninit<&str>" = type { [2 x i64] }

@_RNvCs31EPG3twprw_7structs5TABLE = internal constant [4 x i8] c"\01\02\04\08", align 1, !guid !0
@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !1
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !2
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !3
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !4
@alloc_67f63f1edba9c857548f5126ab7ce3c2 = private unnamed_addr constant [36 x i8] c"core/src/slice/sort/stable/merge.rs\00", align 1, !guid !5
@alloc_fdb60fb5b6a688ef522fd0615d36880a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00v\00\00\00%\00\00\00" }>, align 8, !guid !6
@alloc_da4db734c057a1035818039c5f2cff53 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00w\00\00\00&\00\00\00" }>, align 8, !guid !7
@alloc_dbe0429b9a60c3340cdd89d89688dc8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00x\00\00\00\1B\00\00\00" }>, align 8, !guid !8
@alloc_766632cf75d088c2aec994d85ef6a106 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00\7F\00\00\00!\00\00\00" }>, align 8, !guid !9
@alloc_529aa4c4fd2d7c0d041fb141fa6954c5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00\80\00\00\00\22\00\00\00" }>, align 8, !guid !10
@alloc_22aeb683d111f116ce81304814e59560 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00_\00\00\00\1E\00\00\00" }>, align 8, !guid !11
@alloc_5fdc9e59b7004febe916aa193690e482 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00`\00\00\00\1F\00\00\00" }>, align 8, !guid !12
@alloc_90003bfdf1f7042f7a6739b0adf34bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00b\00\00\00\1C\00\00\00" }>, align 8, !guid !13
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAhj3_NtB6_5Debug3fmtCs31EPG3twprw_7structs }>, align 8, !guid !14
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtCs31EPG3twprw_7structs7VersionNtB6_5Debug3fmtBy_ }>, align 8, !guid !15
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !16
@alloc_5aa56aa9c48804c2060fa51fd405a2a7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0B\10\00\00.\00\00\00" }>, align 8, !guid !17
@alloc_99b75caf23590dadf6af761a907c30e6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0B\10\00\00\11\00\00\00" }>, align 8, !guid !18
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs31EPG3twprw_7structs, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs31EPG3twprw_7structs, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs31EPG3twprw_7structs }>, align 8, !guid !19
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !20
@alloc_4267f6d2b1c6fe0d6aaa5e106110e530 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\C6\0A\00\00\0E\00\00\00" }>, align 8, !guid !21
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !22
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !23
@alloc_16babad1faddf07a74f2f1bf3db5920d = private unnamed_addr constant [17 x i8] c"core/src/hint.rs\00", align 1, !guid !24
@alloc_4abf659b91fe7b31ded00e9133a8280f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16babad1faddf07a74f2f1bf3db5920d, [16 x i8] c"\10\00\00\00\00\00\00\00o\03\00\00Q\00\00\00" }>, align 8, !guid !25
@alloc_cb304c8bbb6b9195bc454f414df930e7 = private unnamed_addr constant [34 x i8] c"core/src/slice/sort/shared/mod.rs\00", align 1, !guid !26
@alloc_b1a59a7585543a4a25115f0cbf40f484 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00\22\00\00\00-\00\00\00" }>, align 8, !guid !27
@alloc_4e95ed00d8479deaf9b8943b85759bde = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00\22\00\00\00A\00\00\00" }>, align 8, !guid !28
@alloc_0aa54d60960e578bf5dc3db64f9182b2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00(\00\00\00/\00\00\00" }>, align 8, !guid !29
@alloc_34d92db687bf3e85a75e319cac8072d0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00(\00\00\00I\00\00\00" }>, align 8, !guid !30
@alloc_3a54043bf62a6816be5c3584bd0aab69 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00$\00\00\00.\00\00\00" }>, align 8, !guid !31
@alloc_435a452c7ddb8b633a1045ff18a4d695 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00$\00\00\00H\00\00\00" }>, align 8, !guid !32
@alloc_302a40d1b3e97481190cef1fa0a61594 = private unnamed_addr constant [34 x i8] c"core/src/slice/sort/stable/mod.rs\00", align 1, !guid !33
@alloc_63f80f9ffc23059c68b68d596767dcd4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_302a40d1b3e97481190cef1fa0a61594, [16 x i8] c"!\00\00\00\00\00\00\00p\00\00\00\1A\00\00\00" }>, align 8, !guid !34
@alloc_5d8412d29d22d9db01454032d8b4fb6b = private unnamed_addr constant [36 x i8] c"core/src/slice/sort/shared/pivot.rs\00", align 1, !guid !35
@alloc_99632a891b912b3f72527a56e4385e22 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00C\00\00\00\22\00\00\00" }>, align 8, !guid !36
@alloc_09b6e462f7991c3c89272eedf987595a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00C\00\00\001\00\00\00" }>, align 8, !guid !37
@alloc_ff6d2fff2e86935f8ee7efadcbb4f63c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00D\00\00\00\22\00\00\00" }>, align 8, !guid !38
@alloc_a1fbc84c38974b09c08d1ec7662e37f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00D\00\00\001\00\00\00" }>, align 8, !guid !39
@alloc_7346065d37ade22e9dac3d1740436530 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00E\00\00\00\22\00\00\00" }>, align 8, !guid !40
@alloc_8d141bec50a4ecf1e0d49d05dd5d5a28 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00E\00\00\001\00\00\00" }>, align 8, !guid !41
@alloc_ce80262f7993cac42401bc51ff6be40f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00\1F\00\00\00\18\00\00\00" }>, align 8, !guid !42
@alloc_8fdae93ef9d304733cddf77b9bee7ee5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00 \00\00\00\18\00\00\00" }>, align 8, !guid !43
@alloc_f0b38f15064fc95bc0114a55e7ca2131 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00%\00\00\006\00\00\00" }>, align 8, !guid !44
@alloc_1824be00902e801da9c2923e0e00ce0b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00#\00\00\00-\00\00\00" }>, align 8, !guid !45
@alloc_ab4c6a2d756e35f752701a51dadd262d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00*\00\00\00\09\00\00\00" }>, align 8, !guid !46
@alloc_f23d27f71cf62f918f1bed533c70d704 = private unnamed_addr constant [40 x i8] c"core/src/slice/sort/shared/smallsort.rs\00", align 1, !guid !47
@alloc_dec6cf59bf3c4f4ee712ccf93b06ede2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\E0\02\00\00\13\00\00\00" }>, align 8, !guid !48
@alloc_d37f5665651ea8a963ab5b8e3fc8edc3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\1C\02\00\00\1D\00\00\00" }>, align 8, !guid !49
@alloc_fdc854ce3bacec098be26750747cb188 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00&\02\00\00*\00\00\00" }>, align 8, !guid !50
@alloc_9deddb0feaaab459a2c7bc3556806f0a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\005\02\00\00\19\00\00\00" }>, align 8, !guid !51
@alloc_d25d1aaad97ebd3cd2f74cf98d99708b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00l\02\00\00#\00\00\00" }>, align 8, !guid !52
@alloc_7559890e91a3e111de81bd762d3bd47b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00m\02\00\00#\00\00\00" }>, align 8, !guid !53
@alloc_9b8e086b7f9a13f6b87be36922fe3508 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00m\02\00\004\00\00\00" }>, align 8, !guid !54
@alloc_4d667cad9e6bd5c37f0224e029fdac09 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00n\02\00\00\18\00\00\00" }>, align 8, !guid !55
@alloc_b1a74bf155318ff7697ff97ab6eab62f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00o\02\00\00\18\00\00\00" }>, align 8, !guid !56
@alloc_5b26eaacf3418840255607328a9ebf80 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00p\02\00\00\18\00\00\00" }>, align 8, !guid !57
@alloc_363ed81fe39abdd8a5079e48018053d0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00q\02\00\00\18\00\00\00" }>, align 8, !guid !58
@alloc_417b4ff3eddaf23cb9f5daaf8042e173 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\88\02\00\00*\00\00\00" }>, align 8, !guid !59
@alloc_5aef466167aa735606252f9c0ea6593f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\89\02\00\00*\00\00\00" }>, align 8, !guid !60
@alloc_030cd358d2f5c80597f9fd26abd3c2a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\8A\02\00\00+\00\00\00" }>, align 8, !guid !61
@alloc_7a8e4a95c146a6c2f88953bb46a5cc11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\9A\02\00\00\1D\00\00\00" }>, align 8, !guid !62
@alloc_6b013669700cca0a3c4ffe02b2be411a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\9A\02\00\002\00\00\00" }>, align 8, !guid !63
@alloc_0ab1672cf9b06a39e5138e5643964c99 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\A0\02\00\00\1D\00\00\00" }>, align 8, !guid !64
@alloc_309c25bb111f12fc56d067e96fc10c4d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00$\03\00\00\1D\00\00\00" }>, align 8, !guid !65
@alloc_448a388e6d58225948aba50cc1a6d287 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00'\03\00\00 \00\00\00" }>, align 8, !guid !66
@alloc_0f305da993ffb5dd0c56a60daa72ac11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00(\03\00\00!\00\00\00" }>, align 8, !guid !67
@alloc_5c83ade1182dd85b92ed28e4ff47ff65 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00)\03\00\00\1F\00\00\00" }>, align 8, !guid !68
@alloc_93577c96033441b3a93f04582b1dcd3c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\008\03\00\00\19\00\00\00" }>, align 8, !guid !69
@alloc_73f0e688413d58d51ee7d8bf7ee8fce8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\009\03\00\00\1B\00\00\00" }>, align 8, !guid !70
@alloc_f03f13dd652dcc6c8ef2b56857ba12fd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00O\02\00\00\1C\00\00\00" }>, align 8, !guid !71
@alloc_db2dccc6f36daf34898e5d24ec4427c7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00P\02\00\00\1F\00\00\00" }>, align 8, !guid !72
@alloc_0977e4bfeef367cc9b1ee8484f31ed3e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00W\02\00\00\19\00\00\00" }>, align 8, !guid !73
@alloc_9a8ea5ce0558e5156f6c03bd8315475b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\04\01\00\00-\00\00\00" }>, align 8, !guid !74
@alloc_9f2322a70f1cdf56e7a06ccd06d355bd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\04\01\00\00J\00\00\00" }>, align 8, !guid !75
@alloc_c1f1e1e090df8fced69504921b66da98 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\FF\00\00\00!\00\00\00" }>, align 8, !guid !76
@alloc_1d52a18521d4b096220396e4abdd5c93 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\FF\00\00\00>\00\00\00" }>, align 8, !guid !77
@alloc_5597fc2d1a2380cd4ab5ac1a539e8a22 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F3\00\00\00=\00\00\00" }>, align 8, !guid !78
@alloc_e13dc99a925a6bd4a73408f1fbbddb5f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F5\00\00\00\18\00\00\00" }>, align 8, !guid !79
@alloc_2288ef688a5190ec529d3a4c5860298d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F6\00\00\00\1E\00\00\00" }>, align 8, !guid !80
@alloc_4a7db440c2c67d9cd260b0d40e6000e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F7\00\00\00\1E\00\00\00" }>, align 8, !guid !81
@alloc_dea82b1a5cc143169db7b7d27413b6f6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\1F\01\00\00\0D\00\00\00" }>, align 8, !guid !82
@alloc_581886408b98ee2e542da40823dc7fbc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\0C\01\00\00\1E\00\00\00" }>, align 8, !guid !83
@alloc_4f39daafd3dae09b4a4c732def155bd3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\0D\01\00\00$\00\00\00" }>, align 8, !guid !84
@alloc_bf1a118daf399e69d630cbc17cad5ced = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\11\01\00\00.\00\00\00" }>, align 8, !guid !85
@alloc_40ef727ccfc43dc7481d04a8f29418d4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\11\01\00\00:\00\00\00" }>, align 8, !guid !86
@alloc_400da1c41164a324a087a19b9508009c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\12\01\00\00&\00\00\00" }>, align 8, !guid !87
@alloc_aaec00fa598af579a3c30bdcf4b2d93d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\BD\02\00\00\1F\00\00\00" }>, align 8, !guid !88
@alloc_8746fce18c06124837c134543b80e6a7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\BE\02\00\00\1D\00\00\00" }>, align 8, !guid !89
@alloc_bb2fc3b74a4bb7a8908f20b7bbc281bc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\BF\02\00\00\13\00\00\00" }>, align 8, !guid !90
@alloc_b64624e679dbd4ce1203b98702274009 = private unnamed_addr constant [36 x i8] c"core/src/slice/sort/stable/drift.rs\00", align 1, !guid !91
@alloc_ea3823fa310c0ac95d0d5924e997a992 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\FF\00\00\00\19\00\00\00" }>, align 8, !guid !92
@alloc_0b170457ff613254af1d0cbd2a159dca = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\F2\00\00\00\12\00\00\00" }>, align 8, !guid !93
@alloc_c54bc7e12f54e1b6a5d6ee337e066d20 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\CE\00\00\00$\00\00\00" }>, align 8, !guid !94
@alloc_4b0ce783e358f6d901ee99bada134993 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\D1\00\00\00$\00\00\00" }>, align 8, !guid !95
@alloc_5b26bc7b45e7e23728885c9a7d45b9d3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\0D\01\00\00#\00\00\00" }>, align 8, !guid !96
@alloc_418d50aea1f432fc229dc42e85bc0c4e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00@\00\00\00\22\00\00\00" }>, align 8, !guid !97
@alloc_e6fc37ca432e3141da706e397b9bb790 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00W\00\00\004\00\00\00" }>, align 8, !guid !98
@alloc_93fee4c110c8615e3a44cfd0974e3956 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00g\00\00\00\13\00\00\00" }>, align 8, !guid !99
@alloc_ad9b3ef1565e0278a16153d428d3f2bf = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00h\00\00\00\1D\00\00\00" }>, align 8, !guid !100
@alloc_1a50229706ade81408c400fb610c9b55 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00Z\00\00\00\22\00\00\00" }>, align 8, !guid !101
@alloc_289e523c22daf4b02f0ced64176f9f7d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00]\00\00\00%\00\00\00" }>, align 8, !guid !102
@alloc_0f1d702ef74aa7166083d4a51933e745 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00)\00\00\00\1C\00\00\00" }>, align 8, !guid !103
@alloc_c1de2663403b8d62e29c8e4804352bb5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00*\00\00\00\1C\00\00\00" }>, align 8, !guid !104
@alloc_1b2260870073aafe108a5ee9a05f9377 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\005\00\00\00A\00\00\00" }>, align 8, !guid !105
@alloc_31616bb5bbed1ce5b2e84544eb586cfa = private unnamed_addr constant [40 x i8] c"core/src/slice/sort/stable/quicksort.rs\00", align 1, !guid !106
@alloc_8dae72bdaad9bf2cafde7b2cd598f477 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00r\00\00\00\1C\00\00\00" }>, align 8, !guid !107
@alloc_6b7a24d3e2ffd1fcade669520d81ebba = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\82\00\00\00)\00\00\00" }>, align 8, !guid !108
@alloc_77a953284c34024a97a172b82a9b5128 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\8B\00\00\00#\00\00\00" }>, align 8, !guid !109
@alloc_99697bcb2ea96e2031a95f1524bc6f42 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\AE\00\00\00\1E\00\00\00" }>, align 8, !guid !110
@alloc_27f0c46980e62edb2ad618f3979fb7d8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\AF\00\00\00\18\00\00\00" }>, align 8, !guid !111
@alloc_4b681e459e5d8eeddb2bdf3b83cf18ab = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00-\00\00\009\00\00\00" }>, align 8, !guid !112
@alloc_1c4a9aaa93e622ac2e6c018a51cab7ab = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00-\00\00\00#\00\00\00" }>, align 8, !guid !113
@alloc_2b7dc74fc6b7aa0b08aab5733d36da25 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00<\00\00\00;\00\00\00" }>, align 8, !guid !114
@alloc_06823d4b39e256f98f8c7a33a4ce85ea = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00M\00\00\00\1F\00\00\00" }>, align 8, !guid !115
@alloc_d82d96a4fa703c840ac11f4b07c0ef3c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00G\00\00\00\17\00\00\00" }>, align 8, !guid !116
@alloc_e86c6ef68ba94e4a4bc451173d753cca = private unnamed_addr constant [22 x i8] c"core/src/slice/mod.rs\00", align 1, !guid !117
@alloc_ab5ed840fe8613ddcabc97b74e0b565e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F1\03\00\00\1C\00\00\00" }>, align 8, !guid !118
@alloc_f7fcaa33fdba299ee035b5518e72c889 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F2\03\00\00\1C\00\00\00" }>, align 8, !guid !119
@alloc_1466797b2db3a3ca9645efa4732978a2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F6\03\00\00 \00\00\00" }>, align 8, !guid !120
@alloc_853b9dc5190658ffe6dc67504ed95441 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F6\03\00\00+\00\00\00" }>, align 8, !guid !121
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !122
@alloc_5bb642ca6df5ad9ba078972a9d3a5201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !123
@alloc_8df3287b4fbc190437d91041421e919b = private unnamed_addr constant [30 x i8] c"core/src/iter/traits/accum.rs\00", align 1, !guid !124
@alloc_a840ce68d073c0ef52d40243c1f57585 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8df3287b4fbc190437d91041421e919b, [16 x i8] c"\1D\00\00\00\00\00\00\00\CE\00\00\00\01\00\00\00" }>, align 8, !guid !125
@alloc_e90bd9a80b7f188aa76a1bfb741a5999 = private unnamed_addr constant [34 x i8] c"core/src/array/iter/iter_inner.rs\00", align 1, !guid !126
@alloc_ac893681874450253b62899ecf8cf06a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\00 \00\00\00" }>, align 8, !guid !127
@alloc_b0b7c7361940ea6a8360c2bdef76bb12 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\003\00\00\00" }>, align 8, !guid !128
@alloc_e576147d56d9d550c35b74f710d650b6 = private unnamed_addr constant [31 x i8] c"test/rust/synthetic/structs.rs\00", align 1, !guid !129
@alloc_11031eeda41e187e6b6226c72cffb5ed = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\1C\00\00\007\00\00\00" }>, align 8, !guid !130
@alloc_135341f3cce8efd686943e936cdabffb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\1C\00\00\00T\00\00\00" }>, align 8, !guid !131
@alloc_9167e64474dcc15fd7b8376d61e32929 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\1C\00\00\00\BB\00\00\00" }>, align 8, !guid !132
@alloc_1a6bd3a289dc6a0cca1fc174cb2b3862 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\1C\00\00\00w\00\00\00" }>, align 8, !guid !133
@alloc_0e637fc846cbe6acb26e3dc0d1c24d0c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\1C\00\00\00\98\00\00\00" }>, align 8, !guid !134
@alloc_9203d5fb81b5296cec933dac0a2d48d5 = private unnamed_addr constant [14 x i8] c"\0Bunexpected \C0\00", align 1, !guid !135
@alloc_935aa0beb3f1208e931cafc1817e27f8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\1C\00\00\00\DB\00\00\00" }>, align 8, !guid !136
@alloc_bf17dfe2c3752d5e0766f39eb9b04ce8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\14\00\00\00\22\00\00\00" }>, align 8, !guid !137
@alloc_5e987218b28a875571f5776dc4899fa3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\14\00\00\00@\00\00\00" }>, align 8, !guid !138
@alloc_c117e4ea55a54919dac3e7ac464ee900 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\14\00\00\00t\00\00\00" }>, align 8, !guid !139
@alloc_9831a659bd72cbfbe3d0a44e7423f266 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\1E\00\00\00\12\00\00\00" }>, align 8, !guid !140
@alloc_cb632dac8d2b8fdc3392de9a1bed186f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00 \00\00\00\1F\00\00\00" }>, align 8, !guid !141
@alloc_7c1bc021357540848ef6cc658b8cab1e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00 \00\00\00'\00\00\00" }>, align 8, !guid !142
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !143
@alloc_def31162d169fa90e9c3b165e0c91340 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00!\00\00\00&\00\00\00" }>, align 8, !guid !144
@alloc_30553d7ac0d67b30b55024312d9ec03d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\22\00\00\00(\00\00\00" }>, align 8, !guid !145
@alloc_102ac9ba096fdcfef4b2af1af8a74ea6 = private unnamed_addr constant [11 x i8] c"(1 + 2) * 3", align 1, !guid !146
@alloc_612e8d03c1ccc604ca0ae564b6c95f0a = private unnamed_addr constant [10 x i8] c"10 / 4 - 1", align 1, !guid !147
@alloc_6b1fa8ed27b8eecb9d228eafb96b6d4d = private unnamed_addr constant [14 x i8] c"-(2 + 3) * 2.5", align 1, !guid !148
@alloc_a91eb42b8cfa99966a1fda64ebf3c985 = private unnamed_addr constant [9 x i8] c"1 + 2 * 3", align 1, !guid !149
@alloc_94d761dacdaa8992553f7036ea7ad2ab = private unnamed_addr constant [1 x i8] c"\06", align 1, !guid !150
@alloc_5d94ea03d8df86d72a13735ba104914b = private unnamed_addr constant [1 x i8] c"\05", align 1, !guid !151
@alloc_718d190fb84d683e104eb3024ff19535 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00$\00\00\00=\00\00\00" }>, align 8, !guid !152
@alloc_fc18870ebd3bffa18e161a5a63775070 = private unnamed_addr constant [4 x i8] c"\07\00\00\00", align 4, !guid !153
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !154
@alloc_9a23790d84995f493af2397c695bbae0 = private unnamed_addr constant [8 x i8] c"\0C\00\00\00\00\00\00\00", align 8, !guid !155
@alloc_ee2a3d99accaa3cec7cc99bf20f81916 = private unnamed_addr constant [8 x i8] c"\04\00\00\00\00\00\00\00", align 8, !guid !156
@alloc_c3b1946345a8630bc4d2f804c02f8ade = private unnamed_addr constant [8 x i8] c"\C1 \00\80`\01\0A\00", align 1, !guid !157
@alloc_0fde3b0be97b88d90da8b15d980ef1c1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00(\00\00\007\00\00\00" }>, align 8, !guid !158
@alloc_d4f9eee8b3859a4cb2c5427791046c70 = private unnamed_addr constant [13 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !159
@alloc_3827bbb606bbdb0f0c926011c14ccc34 = private unnamed_addr constant [1 x i8] c"a", align 1, !guid !160
@alloc_4d1a664ed2308dd6e6eda90c4f1f0189 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00+\00\00\007\00\00\00" }>, align 8, !guid !161
@alloc_d979a3f5c1d7fd2495d3b80b472a1351 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00,\00\00\00:\00\00\00" }>, align 8, !guid !162
@alloc_bd5bcfb13d65237a2c081ec4304fc906 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00,\00\00\00_\00\00\00" }>, align 8, !guid !163
@alloc_c45a3435f86173cc8075b6cb1218b25d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00-\00\00\00\05\00\00\00" }>, align 8, !guid !164
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !165
@alloc_427f5753095982aa1d9009267af3847a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00.\00\00\00\22\00\00\00" }>, align 8, !guid !166
@alloc_6c342f467cee9eb46aaa013cf1ccd49c = private unnamed_addr constant [5 x i8] c"inner", align 1, !guid !167
@alloc_cfd9774bc6691391e2b423b9909d66ce = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\000\00\00\00\0E\00\00\00" }>, align 8, !guid !168
@alloc_35c18a3d99c204eafc413a93d7c0b667 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\000\00\00\00 \00\00\00" }>, align 8, !guid !169
@alloc_d18c4256912d8668c4a6fabc64706525 = private unnamed_addr constant [9 x i8] c"\C0\03 = \C0\01\0A\00", align 1, !guid !170
@alloc_7f0421388533e360fd6edeaab0fdb02f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\19\00\00\00\22\00\00\00" }>, align 8, !guid !171
@alloc_18c2cad16391a89dafdc59d2b3cd018f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\19\00\00\00@\00\00\00" }>, align 8, !guid !172
@alloc_3da697690ecb5212e940b5e4cb1b788f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\19\00\00\00t\00\00\00" }>, align 8, !guid !173
@alloc_8da44e18dbeb7ba2d02948803b29a0bc = private unnamed_addr constant [2 x i8] c"hi", align 1, !guid !174
@_RNvCs31EPG3twprw_7structs8GREETING = internal constant <{ ptr, [8 x i8] }> <{ ptr @alloc_8da44e18dbeb7ba2d02948803b29a0bc, [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8, !guid !175
@alloc_b747c96906ffbce453a9207e9b2128e6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00$\00\00\00" }>, align 8, !guid !176
@alloc_2bb9350cbc6ff862e12ea81bef4f3327 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00<\00\00\00" }>, align 8, !guid !177
@alloc_f022ae404959d59c9f31a4214d0e7b44 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00#\01\00\00" }>, align 8, !guid !178
@alloc_5ba5e083a1faa1c75156e6d84a0a62e2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00O\01\00\00" }>, align 8, !guid !179
@alloc_28815ad4accad0d1e0197a9f19c642a3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00x\01\00\00" }>, align 8, !guid !180
@alloc_47eafba4cd49b663816ad426862e813e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00\80\00\00\00" }>, align 8, !guid !181
@alloc_ae1effdc3b6984cddf3f7f5f83f39971 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00\9A\00\00\00" }>, align 8, !guid !182
@alloc_622181568d1ef9370268f280836c98b9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00\C8\00\00\00" }>, align 8, !guid !183
@alloc_1398e555233619a1db74b0a79be8bc4a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00\F3\00\00\00" }>, align 8, !guid !184
@alloc_9073897bf448b380015b1f1a594c5d53 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e576147d56d9d550c35b74f710d650b6, [16 x i8] c"\1E\00\00\00\00\00\00\00\0F\00\00\00\A8\00\00\00" }>, align 8, !guid !185
@alloc_2b51dca0044e8b3e194b82b8219a1fd4 = private unnamed_addr constant [20 x i8] c"alloc/src/string.rs\00", align 1, !guid !186
@alloc_f359bc50cb9af0e9ab554d6f9dd402ac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2b51dca0044e8b3e194b82b8219a1fd4, [16 x i8] c"\13\00\00\00\00\00\00\00\9F\05\00\00T\00\00\00" }>, align 8, !guid !187
@alloc_d1084648e479974e70c9329824bf76f9 = private unnamed_addr constant [9 x i8] c"mid > len", align 1, !guid !188
@alloc_36e015fa750e45dca62b9d94b6d857e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00J\03\00\00\22\00\00\00" }>, align 8, !guid !189
@alloc_a6541cbd0ddc1cb3d23757a1b3f12432 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\9D\08\00\00 \00\00\00" }>, align 8, !guid !190
@alloc_c0be9056d9e7c9d32564b353e6cdd76b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\DD\03\00\00\15\00\00\00" }>, align 8, !guid !191
@alloc_73d74aabd1e8eaefe4cbe59407c3c85c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\DE\03\00\003\00\00\00" }>, align 8, !guid !192
@alloc_11a111513757e9d53adfd2e1c4df0866 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\DE\03\00\00\15\00\00\00" }>, align 8, !guid !193
@alloc_00ae4b301f7fab8ac9617c03fcbd7274 = private unnamed_addr constant [43 x i8] c"called `Result::unwrap()` on an `Err` value", align 1, !guid !194
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_15ParseFloatErrorNtNtB9_3fmt5Debug3fmtCs31EPG3twprw_7structs }>, align 8, !guid !195
@alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b = private unnamed_addr constant [28 x i8] c"core/src/ops/index_range.rs\00", align 1, !guid !196
@alloc_de9a5d9a80d554992107c1ea3afec081 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b, [16 x i8] c"\1B\00\00\00\00\00\00\00?\00\00\00%\00\00\00" }>, align 8, !guid !197
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !198
@alloc_f5abd596fd0c54395cb86286cae95a93 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_302a40d1b3e97481190cef1fa0a61594, [16 x i8] c"!\00\00\00\00\00\00\00\A0\00\00\00\13\00\00\00" }>, align 8, !guid !199
@alloc_2491cc18f41182435b2301519a149a1c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_302a40d1b3e97481190cef1fa0a61594, [16 x i8] c"!\00\00\00\00\00\00\00\A3\00\00\00\12\00\00\00" }>, align 8, !guid !200
@alloc_a96f4d0356403e36c78136287f0c1b2f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\DE\00\00\001\00\00\00" }>, align 8, !guid !201
@alloc_a56b047bd0b34a39f54c81b6689d3e24 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\E3\00\00\00 \00\00\00" }>, align 8, !guid !202
@alloc_35909116da33a5c42c9fe1f80ecea2ce = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\E7\00\00\00#\00\00\00" }>, align 8, !guid !203
@alloc_9738d6b9b3097219ddae8e296f0517dc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\CB\00\00\00X\00\00\00" }>, align 8, !guid !204
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !205
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !206
@alloc_3d5b7f261101b120d30419294a27cc6f = private unnamed_addr constant [23 x i8] c"core/src/ptr/unique.rs\00", align 1, !guid !207
@alloc_8e8e5d43991787ef9fba0c8fe53b59fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3d5b7f261101b120d30419294a27cc6f, [16 x i8] c"\16\00\00\00\00\00\00\00X\00\00\00$\00\00\00" }>, align 8, !guid !208
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !209
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !210
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !211
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !212
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !213
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !214
@alloc_9f4cf96e0cfa121f5a07edf0a5a77ed7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\AC\05\00\00\05\00\00\00" }>, align 8, !guid !215
@alloc_9420a1aba537dc94842201b7589e1f0c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0C\04\00\00)\00\00\00" }>, align 8, !guid !216
@alloc_ce6d47b03c47f09012a85da1d9cb0822 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0D\04\00\00\0D\00\00\00" }>, align 8, !guid !217
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !218
@alloc_1cbb975cc83b9471f5f1e14e3976c3b1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\EA\0C\00\00#\00\00\00" }>, align 8, !guid !219
@alloc_027cef065c3c71aa2f31a680ec9e0201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\E9\0C\00\00\0D\00\00\00" }>, align 8, !guid !220
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !221
@alloc_ab1ae74de3e4549d53c3a5a25a7b5349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\FE\05\00\00.\00\00\00" }>, align 8, !guid !222
@alloc_bde50f121dd28b1208f603a6cb579e2e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\FE\05\00\00<\00\00\00" }>, align 8, !guid !223
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !224
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !225
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !226
@alloc_f4d2d51edb3c135010ec58fc6ec81116 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\15\0A\00\00\0E\00\00\00" }>, align 8, !guid !227
@alloc_eb7679a68dcd7061369dc30b8473eab2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\16\0A\00\00\0E\00\00\00" }>, align 8, !guid !228
@alloc_6f0e944e7da96ae12b21ce9c7329439a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\17\0A\00\00\0E\00\00\00" }>, align 8, !guid !229
@alloc_1dccca3d63175c9b0934ec0c77c6825a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\0F\0A\00\00\12\00\00\00" }>, align 8, !guid !230
@alloc_c08b8de47e200b21f5fc7f6be35bac90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\10\0A\00\00\12\00\00\00" }>, align 8, !guid !231
@alloc_56e5aecdad28a2fc525042f7daf0ab58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\09\0A\00\00\12\00\00\00" }>, align 8, !guid !232
@alloc_945f2c369c171e278c4be97205a79e9b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !233
@alloc_8b70662a33190959512d6213db47913f = private unnamed_addr constant [22 x i8] c"Platform not supported", align 1, !guid !234
@alloc_32204aadf0ef6d74ed8e4766f91eb6a4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\9E\00\00\00\09\00\00\00" }>, align 8, !guid !235
@alloc_6b0b11c9e93314b588b613b55005cf18 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: slice::split_at_mut_unchecked requires the index to be within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !236
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !237
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !238
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !239
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !240
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !241
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !242
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !243
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !244
@alloc_2875d9f120b8cc0de1c30c014c7b6715 = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::swap_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !245
@alloc_21be34ed5a7b8b5ac8a692be276474da = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\EB\05\00\00\09\00\00\00" }>, align 8, !guid !246
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !247
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !248
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !249
@alloc_5c1a2f972552229672fc942406cfc298 = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts_mut requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !250
@alloc_97d92cbf2a68a6ac45a1b13da79836e4 = private unnamed_addr constant [214 x i8] c"unsafe precondition(s) violated: slice::get_unchecked requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !251
@alloc_5a8fdd84b3281310cbf6b74bb6bf0065 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !252
@alloc_18d73aa062d524e9620b9e3b55bd9eb1 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the range is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !253
@alloc_94a6065ee1f45dfce5759e12c7406524 = private unnamed_addr constant [7 x i8] c"Version", align 1, !guid !254
@alloc_4cdb24b42a80f22b6b821bb3f8a02159 = private unnamed_addr constant [5 x i8] c"major", align 1, !guid !255
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCs31EPG3twprw_7structs }>, align 8, !guid !256
@alloc_274e8598b8ce915f77b7aff9fb214dfa = private unnamed_addr constant [5 x i8] c"minor", align 1, !guid !257
@alloc_9b505451451ec50119c3c52e8a43d511 = private unnamed_addr constant [5 x i8] c"patch", align 1, !guid !258
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_ }>, align 8, !guid !259
@alloc_cff8939d5dc637bf609a2f92b31c63ab = private unnamed_addr constant [39 x i8] c"alloc/src/vec/spec_from_iter_nested.rs\00", align 1, !guid !260
@alloc_6dccda4ce48382006a7e66da98798d14 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cff8939d5dc637bf609a2f92b31c63ab, [16 x i8] c"&\00\00\00\00\00\00\00!\00\00\00\15\00\00\00" }>, align 8, !guid !261
@alloc_11474c3953230bd025f06b3f9a855a1c = private unnamed_addr constant [21 x i8] c"core/src/str/iter.rs\00", align 1, !guid !262
@alloc_1a7c685630b0735376eef9074b3e654a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11474c3953230bd025f06b3f9a855a1c, [16 x i8] c"\14\00\00\00\00\00\00\00f\00\00\00\0E\00\00\00" }>, align 8, !guid !263
@alloc_c7037efb906203803aa3ca07167c9120 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\13\00\00\00\17\00\00\00" }>, align 8, !guid !264
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !265
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !266
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCs31EPG3twprw_7structs }>, align 8, !guid !267
@alloc_252aee8158a2b6b4b1e300c3f8f7bd7a = private unnamed_addr constant [15 x i8] c"ParseFloatError", align 1, !guid !268
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !269
@vtable.9 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse14FloatErrorKindNtB6_5Debug3fmtCs31EPG3twprw_7structs }>, align 8, !guid !270
@alloc_59ba7b9f7211443cd55a366616eef46a = private unnamed_addr constant [5 x i8] c"Empty", align 1, !guid !271
@alloc_6693e43df3406efcf64b4ab3d59228bb = private unnamed_addr constant [7 x i8] c"Invalid", align 1, !guid !272
@alloc_cd8bd3d0cc5cd08c5d601c797c5ed9fe = private unnamed_addr constant [3 x i8] c"Num", align 1, !guid !273
@alloc_523bf151c3c09163b55b95f71c18ed3a = private unnamed_addr constant [2 x i8] c"Op", align 1, !guid !274
@vtable.a = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRcNtB6_5Debug3fmtCs31EPG3twprw_7structs }>, align 8, !guid !275
@alloc_cc20e6bc48d43d2101037702189cb9d9 = private unnamed_addr constant [6 x i8] c"LParen", align 1, !guid !276
@alloc_70ea4c882379873e16e82da9fde23a53 = private unnamed_addr constant [6 x i8] c"RParen", align 1, !guid !277
@alloc_4a07d64a21980758f07ef2afc3d73d2d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00\92\00\00\00 \00\00\00" }>, align 8, !guid !278
@alloc_0d0353b85363a9d264096e7bdbfe6900 = private unnamed_addr constant [22 x i8] c"core/src/array/mod.rs\00", align 1, !guid !279
@alloc_bb689cb4c05c0bf38d31dd7cd71b8150 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d0353b85363a9d264096e7bdbfe6900, [16 x i8] c"\15\00\00\00\00\00\00\00e\01\00\00\1F\00\00\00" }>, align 8, !guid !280
@alloc_f68f945f4b0d5582669e4f82589ddb09 = private unnamed_addr constant [3 x i8] c"Red", align 1, !guid !281
@alloc_c2c110312de72f05b4f6b2dd5161b81c = private unnamed_addr constant [5 x i8] c"Green", align 1, !guid !282
@alloc_9dd73c20dc576e7c6b01311c1d3cd76d = private unnamed_addr constant [4 x i8] c"Blue", align 1, !guid !283

; <[structs::Version]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCs31EPG3twprw_7structs7Version8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !289 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[structs::Version]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCs31EPG3twprw_7structs7VersionE23into_raw_with_allocatorBK_(ptr %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<structs::Version>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[structs::Version]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCs31EPG3twprw_7structs7VersionEEB1d_(ptr align 8 %self) #21
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable
}

; <str>::parse::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !290 {
start:
; call <f64 as core::str::traits::FromStr>::from_str
  call void @_RNvXs2_NtNtCsl10jNU3mE6R_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #23
  ret void
}

; <bool>::then_some::<&structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core4boolb9then_someRNtCs31EPG3twprw_7structs7VersionEBH_(i1 zeroext %self, ptr %t) unnamed_addr #0 !guid !291 {
start:
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  store i8 0, ptr %_4, align 1
  store i8 1, ptr %_4, align 1
  br i1 %self, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_4, align 1
  store ptr %t, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load i8, ptr %_4, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb3
  %2 = load ptr, ptr %_0, align 8
  ret ptr %2

bb5:                                              ; preds = %bb3
  br label %bb4
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitReE13get_uncheckedjECs31EPG3twprw_7structs(ptr align 8 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !292 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitReEE13get_uncheckedCs31EPG3twprw_7structs(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #24
  ret ptr %_3
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitReE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECs31EPG3twprw_7structs(ptr align 8 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !293 {
start:
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitReEE17get_unchecked_mutCs31EPG3twprw_7structs(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #24
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <[structs::Version]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version13get_uncheckedjEBx_(ptr %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !294 {
start:
; call <usize as core::slice::index::SliceIndex<[structs::Version]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE13get_uncheckedB10_(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #24
  ret ptr %_3
}

; <[structs::Version]>::get_unchecked_mut::<core::ops::range::Range<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version17get_unchecked_mutINtNtNtB5_3ops5range5RangejEEBx_(ptr %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !295 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[structs::Version]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE17get_unchecked_mutB1r_(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #24
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <core::option::Option<usize>>::map::<&str, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapReNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBY_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECs31EPG3twprw_7structs(i64 %0, i64 %1, ptr align 8 %f.0, i64 %f.1) unnamed_addr #0 !guid !296 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next::{closure#0}
  %7 = call { ptr, i64 } @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitReEE4next0Cs31EPG3twprw_7structs(ptr align 8 %f.0, i64 %f.1, i64 %x) #24
  %_5.0 = extractvalue { ptr, i64 } %7, 0
  %_5.1 = extractvalue { ptr, i64 } %7, 1
  store ptr %_5.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %8, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %9 = load i8, ptr %_8, align 1
  %10 = trunc nuw i8 %9 to i1
  br i1 %10, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %11 = load ptr, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  ret { ptr, i64 } %15

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !297 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs31EPG3twprw_7structs(ptr %x) #24
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs31EPG3twprw_7structs(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !298 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs31EPG3twprw_7structs(ptr align 8 %x) #24
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs31EPG3twprw_7structs(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<[[u8; 3]; 2]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAAhj3_j2_ECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !299 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<[[u8; 3]; 2]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAAhj3_j2_E8from_refCs31EPG3twprw_7structs(ptr %x) #24
; call <core::ptr::non_null::NonNull<[[u8; 3]; 2]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAAhj3_j2_E4castuECs31EPG3twprw_7structs(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAAhj3_j2_NtNtB7_3fmt5Debug3fmtCs31EPG3twprw_7structs, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<[u8; 4]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAhj4_ECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !300 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<[u8; 4]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAhj4_E8from_refCs31EPG3twprw_7structs(ptr %x) #24
; call <core::ptr::non_null::NonNull<[u8; 4]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAhj4_E4castuECs31EPG3twprw_7structs(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAhj4_NtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<alloc::vec::Vec<structs::Version>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEEB1u_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !301 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::vec::Vec<structs::Version>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEE8from_refB1s_(ptr align 8 %x) #24
; call <core::ptr::non_null::NonNull<alloc::vec::Vec<structs::Version>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEE4castuEB1t_(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtBH_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<structs::Color>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCs31EPG3twprw_7structs5ColorEBX_(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !302 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<structs::Color>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs31EPG3twprw_7structs5ColorE8from_refBV_(ptr %x) #24
; call <core::ptr::non_null::NonNull<structs::Color>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCs31EPG3twprw_7structs5ColorE4castuEBW_(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsd_Cs31EPG3twprw_7structsNtB5_5ColorNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCs31EPG3twprw_7structs7VersionEBX_(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !303 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<structs::Version>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs31EPG3twprw_7structs7VersionE8from_refBV_(ptr %x) #24
; call <core::ptr::non_null::NonNull<structs::Version>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCs31EPG3twprw_7structs7VersionE4castuEBW_(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXCs31EPG3twprw_7structsNtB2_7VersionNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB2_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<&structs::Token>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRNtCs31EPG3twprw_7structs5TokenEBY_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !304 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&structs::Token>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtCs31EPG3twprw_7structs5TokenE8from_refBW_(ptr align 8 %x) #24
; call <core::ptr::non_null::NonNull<&structs::Token>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtCs31EPG3twprw_7structs5TokenE4castuEBX_(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtCs31EPG3twprw_7structs5TokenNtB6_5Debug3fmtBy_, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(i32, &str, f64)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTlRedEECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !305 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(i32, &str, f64)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTlRedEE8from_refCs31EPG3twprw_7structs(ptr align 8 %x) #24
; call <core::ptr::non_null::NonNull<(i32, &str, f64)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTlRedEE4castuECs31EPG3twprw_7structs(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1F_NtCsl10jNU3mE6R_4core3fmtTlRedENtB6_5Debug3fmtCs31EPG3twprw_7structs, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawINtNtB5_12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEB1H_(ptr %val) unnamed_addr #0 !guid !306 {
start:
; call core::mem::align_of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawINtNtB2_12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEB1l_(ptr %val) #24
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs31EPG3twprw_7structs(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #24
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawNtCs31EPG3twprw_7structs7VersionEB17_(ptr %val) unnamed_addr #0 !guid !307 {
start:
; call core::mem::align_of_val_raw::<structs::Version>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawNtCs31EPG3twprw_7structs7VersionEBL_(ptr %val) #24
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs31EPG3twprw_7structs(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #24
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<[structs::Version]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCs31EPG3twprw_7structs7VersionEB18_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !308 {
start:
; call core::mem::align_of_val_raw::<[structs::Version]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCs31EPG3twprw_7structs7VersionEBM_(ptr %val.0, i64 %val.1) #24
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs31EPG3twprw_7structs(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #24
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of::<structs::Token>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofNtCs31EPG3twprw_7structs5TokenEBY_() unnamed_addr #0 !guid !309 {
start:
  ret i64 8
}

; <core::mem::alignment::Alignment>::of::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofcECs31EPG3twprw_7structs() unnamed_addr #0 !guid !310 {
start:
  ret i64 4
}

; <core::alloc::layout::Layout>::for_value_raw::<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawINtNtNtB7_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEB1M_(ptr %val) unnamed_addr #0 !guid !311 {
start:
; call core::mem::size_of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawINtNtB2_12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEB1k_(ptr %val) #24
; call <core::mem::alignment::Alignment>::of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawINtNtB5_12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEB1H_(ptr %val) #24
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs31EPG3twprw_7structs(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #24
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawNtCs31EPG3twprw_7structs7VersionEB16_(ptr %val) unnamed_addr #0 !guid !312 {
start:
; call core::mem::size_of_val_raw::<structs::Version>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawNtCs31EPG3twprw_7structs7VersionEBK_(ptr %val) #24
; call <core::mem::alignment::Alignment>::of_val_raw::<structs::Version>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawNtCs31EPG3twprw_7structs7VersionEB17_(ptr %val) #24
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs31EPG3twprw_7structs(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #24
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<[structs::Version]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCs31EPG3twprw_7structs7VersionEB17_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !313 {
start:
; call core::mem::size_of_val_raw::<[structs::Version]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCs31EPG3twprw_7structs7VersionEBL_(ptr %val.0, i64 %val.1) #24
; call <core::mem::alignment::Alignment>::of_val_raw::<[structs::Version]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCs31EPG3twprw_7structs7VersionEB18_(ptr %val.0, i64 %val.1) #24
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs31EPG3twprw_7structs(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #24
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::slice::sort::stable::merge::MergeState<structs::Version>>::merge_down::<<structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStateNtCs31EPG3twprw_7structs7VersionE10merge_downNvYB1a_NtNtBb_3cmp10PartialOrd2ltEB1c_(ptr align 8 %self, ptr %left_end, ptr %right_end, ptr %0, ptr %is_less) unnamed_addr #1 !guid !314 {
start:
  %_0.i6 = alloca [8 x i8], align 8
  %_0.i4 = alloca [8 x i8], align 8
  %_0.i2 = alloca [8 x i8], align 8
  %src = alloca [8 x i8], align 8
  %out = alloca [8 x i8], align 8
  store ptr %0, ptr %out, align 8
  br label %bb1

bb1:                                              ; preds = %bb12, %start
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_7 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds %Version, ptr %_7, i64 -1
  store ptr %2, ptr %_0.i6, align 8
  %3 = load ptr, ptr %_0.i6, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_9 = load ptr, ptr %4, align 8
  %5 = getelementptr inbounds %Version, ptr %_9, i64 -1
  store ptr %5, ptr %_0.i4, align 8
  %6 = load ptr, ptr %_0.i4, align 8
  %_11 = load ptr, ptr %out, align 8
  %7 = getelementptr inbounds %Version, ptr %_11, i64 -1
  store ptr %7, ptr %_0.i2, align 8
  %8 = load ptr, ptr %_0.i2, align 8
  store ptr %8, ptr %out, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %consume_left = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %6, ptr %3) #24
  br i1 %consume_left, label %bb6, label %bb7

bb7:                                              ; preds = %bb1
  store ptr %6, ptr %src, align 8
  br label %bb8

bb6:                                              ; preds = %bb1
  store ptr %3, ptr %src, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_19 = load ptr, ptr %src, align 8
  %_20 = load ptr, ptr %out, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %bb8
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_19, ptr %_20, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %bb8, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_20, ptr align 1 %_19, i64 3, i1 false)
  %_23 = xor i1 %consume_left, true
  %_22 = zext i1 %_23 to i64
  %_0.i1 = getelementptr inbounds nuw %Version, ptr %3, i64 %_22
  %9 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %_0.i1, ptr %9, align 8
  %_25 = zext i1 %consume_left to i64
  %_0.i = getelementptr inbounds nuw %Version, ptr %6, i64 %_25
  %10 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_0.i, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 16
  %_28 = load ptr, ptr %11, align 8
  %_26 = icmp eq ptr %_28, %left_end
  br i1 %_26, label %bb13, label %bb12

bb12:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit
  %12 = getelementptr inbounds i8, ptr %self, i64 8
  %_31 = load ptr, ptr %12, align 8
  %_29 = icmp eq ptr %_31, %right_end
  br i1 %_29, label %bb13, label %bb1

bb13:                                             ; preds = %bb12, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit
  ret void
}

; <core::slice::sort::stable::merge::MergeState<structs::Version>>::merge_up::<<structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStateNtCs31EPG3twprw_7structs7VersionE8merge_upNvYB1a_NtNtBb_3cmp10PartialOrd2ltEB1c_(ptr align 8 %self, ptr %0, ptr %right_end, ptr %is_less) unnamed_addr #1 !guid !315 {
start:
  %src = alloca [8 x i8], align 8
  %right = alloca [8 x i8], align 8
  store ptr %0, ptr %right, align 8
  %out = getelementptr inbounds i8, ptr %self, i64 16
  br label %bb1

bb1:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit, %start
  %_8 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %_9 = load ptr, ptr %1, align 8
  %_7 = icmp ne ptr %_8, %_9
  br i1 %_7, label %bb2, label %bb12

bb12:                                             ; preds = %bb2, %bb1
  ret void

bb2:                                              ; preds = %bb1
  %_11 = load ptr, ptr %right, align 8
  %_10 = icmp ne ptr %_11, %right_end
  br i1 %_10, label %bb3, label %bb12

bb3:                                              ; preds = %bb2
  %_15 = load ptr, ptr %right, align 8
  %_31 = load ptr, ptr %self, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_13 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_15, ptr %_31) #24
  %consume_left = xor i1 %_13, true
  br i1 %consume_left, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %2 = load ptr, ptr %right, align 8
  store ptr %2, ptr %src, align 8
  br label %bb7

bb5:                                              ; preds = %bb3
  %_18 = load ptr, ptr %self, align 8
  store ptr %_18, ptr %src, align 8
  br label %bb7

bb7:                                              ; preds = %bb5, %bb6
  %_20 = load ptr, ptr %src, align 8
  %_21 = load ptr, ptr %out, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %bb7
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_20, ptr %_21, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %bb7, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_21, ptr align 1 %_20, i64 3, i1 false)
  %_23 = load ptr, ptr %self, align 8
  %_24 = zext i1 %consume_left to i64
  %_0.i1 = getelementptr inbounds nuw %Version, ptr %_23, i64 %_24
  store ptr %_0.i1, ptr %self, align 8
  %_26 = load ptr, ptr %right, align 8
  %_28 = xor i1 %consume_left, true
  %_27 = zext i1 %_28 to i64
  %_0.i2 = getelementptr inbounds nuw %Version, ptr %_26, i64 %_27
  store ptr %_0.i2, ptr %right, align 8
  %_30 = load ptr, ptr %out, align 8
  %_0.i = getelementptr inbounds nuw %Version, ptr %_30, i64 1
  store ptr %_0.i, ptr %out, align 8
  br label %bb1
}

; <core::ptr::unique::Unique<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueINtNtNtBa_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EE4casthEB1z_(ptr %self) unnamed_addr #0 !guid !316 {
start:
; call <core::ptr::non_null::NonNull<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtNtBa_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EE4casthEB1C_(ptr %self) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<structs::Version>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueNtCs31EPG3twprw_7structs7VersionE4casthEBT_(ptr %self) unnamed_addr #0 !guid !317 {
start:
; call <core::ptr::non_null::NonNull<structs::Version>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCs31EPG3twprw_7structs7VersionE4casthEBW_(ptr %self) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<[structs::Version]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCs31EPG3twprw_7structs7VersionE4casthEBU_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !318 {
start:
; call <core::ptr::non_null::NonNull<[structs::Version]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCs31EPG3twprw_7structs7VersionE4casthEBX_(ptr %self.0, i64 %self.1) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<structs::Token>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCs31EPG3twprw_7structs5TokenEB10_(ptr %self) unnamed_addr #0 !guid !319 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<structs::Token>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCs31EPG3twprw_7structs5TokenEB13_(ptr %self) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCs31EPG3twprw_7structs7VersionEB10_(ptr %self) unnamed_addr #0 !guid !320 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<structs::Version>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCs31EPG3twprw_7structs7VersionEB13_(ptr %self) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castcECs31EPG3twprw_7structs(ptr %self) unnamed_addr #0 !guid !321 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<char>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castcECs31EPG3twprw_7structs(ptr %self) #24
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[[u8; 3]; 2]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAAhj3_j2_E4castuECs31EPG3twprw_7structs(ptr %self) unnamed_addr #0 !guid !322 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[u8; 4]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAhj4_E4castuECs31EPG3twprw_7structs(ptr %self) unnamed_addr #0 !guid !323 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::vec::Vec<structs::Version>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEE4castuEB1t_(ptr %self) unnamed_addr #0 !guid !324 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtNtBa_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EE4casthEB1C_(ptr %self) unnamed_addr #0 !guid !325 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<structs::Color>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCs31EPG3twprw_7structs5ColorE4castuEBW_(ptr %self) unnamed_addr #0 !guid !326 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<structs::Version>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCs31EPG3twprw_7structs7VersionE4casthEBW_(ptr %self) unnamed_addr #0 !guid !327 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<structs::Version>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtCs31EPG3twprw_7structs7VersionE4castuEBW_(ptr %self) unnamed_addr #0 !guid !328 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&structs::Token>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRNtCs31EPG3twprw_7structs5TokenE4castuEBX_(ptr %self) unnamed_addr #0 !guid !329 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[[u8; 3]]>>::cast::<[u8; 3]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAhj3_E4castBV_ECs31EPG3twprw_7structs(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !330 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[structs::Version]>>::cast::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCs31EPG3twprw_7structs7VersionE4castBV_EBX_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !331 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[structs::Version]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCs31EPG3twprw_7structs7VersionE4casthEBX_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !332 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<(i32, &str, f64)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTlRedEE4castuECs31EPG3twprw_7structs(ptr %self) unnamed_addr #0 !guid !333 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs31EPG3twprw_7structs(ptr %self) unnamed_addr #0 !guid !334 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs31EPG3twprw_7structs(ptr %self) unnamed_addr #0 !guid !335 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<structs::Token>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCs31EPG3twprw_7structs5TokenEB13_(ptr %self) unnamed_addr #0 !guid !336 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCs31EPG3twprw_7structs7VersionEB13_(ptr %self) unnamed_addr #0 !guid !337 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castcECs31EPG3twprw_7structs(ptr %self) unnamed_addr #0 !guid !338 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<structs::Token>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCs31EPG3twprw_7structs5TokenEBY_(ptr align 8 %self) unnamed_addr #0 !guid !339 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<structs::Token>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCs31EPG3twprw_7structs5TokenEB13_(ptr align 8 %self) #24
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::ptr::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCs31EPG3twprw_7structs7VersionEBY_(ptr align 8 %self) unnamed_addr #0 !guid !340 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<structs::Version>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCs31EPG3twprw_7structs7VersionEB13_(ptr align 8 %self) #24
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::ptr::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrcECs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !341 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<char>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullcECs31EPG3twprw_7structs(ptr align 8 %self) #24
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<structs::Token>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCs31EPG3twprw_7structs5TokenEB13_(ptr align 8 %self) unnamed_addr #0 !guid !342 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<structs::Token>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCs31EPG3twprw_7structs5TokenEB10_(ptr %_3) #24
; call <core::ptr::unique::Unique<structs::Token>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCs31EPG3twprw_7structs5TokenE15as_non_null_ptrBS_(ptr %_2) #24
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::non_null::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCs31EPG3twprw_7structs7VersionEB13_(ptr align 8 %self) unnamed_addr #0 !guid !343 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<structs::Version>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCs31EPG3twprw_7structs7VersionEB10_(ptr %_3) #24
; call <core::ptr::unique::Unique<structs::Version>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCs31EPG3twprw_7structs7VersionE15as_non_null_ptrBS_(ptr %_2) #24
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::non_null::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullcECs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !344 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<char>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castcECs31EPG3twprw_7structs(ptr %_3) #24
; call <core::ptr::unique::Unique<char>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquecE15as_non_null_ptrCs31EPG3twprw_7structs(ptr %_2) #24
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<9, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj9_Kj2_ECs31EPG3twprw_7structs(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !345 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs31EPG3twprw_7structs(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !346 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs31EPG3twprw_7structs(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !347 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::builders::DebugList>::entries::<&[u8; 3], core::slice::iter::Iter<[u8; 3]>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRAhj3_INtNtNtBa_5slice4iter4IterB14_EECs31EPG3twprw_7structs(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !348 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<[u8; 3]> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterAhj3_ENtB2_12IntoIterator9into_iterCs31EPG3twprw_7structs(ptr %entries.0, ptr %entries.1) #24
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<[u8; 3]> as core::iter::traits::iterator::Iterator>::next
  %2 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterAhj3_ENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs31EPG3twprw_7structs(ptr align 8 %iter) #24
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !349
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.0)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&structs::Version, core::slice::iter::Iter<structs::Version>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRNtCs31EPG3twprw_7structs7VersionINtNtNtBa_5slice4iter4IterB14_EEB16_(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !350 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<structs::Version> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterNtCs31EPG3twprw_7structs7VersionENtB2_12IntoIterator9into_iterB1d_(ptr %entries.0, ptr %entries.1) #24
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<structs::Version> as core::iter::traits::iterator::Iterator>::next
  %2 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterNtCs31EPG3twprw_7structs7VersionENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBR_(ptr align 8 %iter) #24
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !349
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.1)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<char>>::extend_desugared::<core::str::iter::Chars>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VeccE16extend_desugaredNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsECs31EPG3twprw_7structs(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !351 {
start:
  %_23 = alloca [1 x i8], align 1
  %_13 = alloca [24 x i8], align 8
  %_3 = alloca [4 x i8], align 4
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %2 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_23, align 1
  br label %bb1

bb1:                                              ; preds = %bb13, %start
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
  %3 = call i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCs31EPG3twprw_7structs(ptr align 8 %iterator) #24
  store i32 %3, ptr %_3, align 4
  br label %bb2

bb2:                                              ; preds = %bb1
  %4 = load i32, ptr %_3, align 4
  %5 = icmp eq i32 %4, -1
  %_5 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_5 to i1
  br i1 %6, label %bb3, label %bb14

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_23, align 1
  %element = load i32, ptr %_3, align 4
; call <alloc::vec::Vec<char>>::len
  %len = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCs31EPG3twprw_7structs(ptr align 8 %self) #24
  br label %bb4

bb14:                                             ; preds = %bb2
  ret void

bb4:                                              ; preds = %bb3
; call <alloc::vec::Vec<char>>::capacity
  %_10 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8capacityCs31EPG3twprw_7structs(ptr align 8 %self) #24
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = icmp eq i64 %len, %_10
  br i1 %_9, label %bb6, label %bb9

bb9:                                              ; preds = %bb21, %bb5
; call <alloc::vec::Vec<char>>::as_mut_ptr
  %_19 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE10as_mut_ptrCs31EPG3twprw_7structs(ptr align 8 %self) #24
  br label %bb10

bb6:                                              ; preds = %bb5
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator9size_hintCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_13, ptr align 8 %iterator) #24
  br label %bb7

bb7:                                              ; preds = %bb6
  %lower = load i64, ptr %_13, align 8
  %_0.i1 = call i64 @llvm.uadd.sat.i64(i64 %lower, i64 1)
  br label %bb8

bb8:                                              ; preds = %bb7
; call <alloc::vec::Vec<char>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7reserveCs31EPG3twprw_7structs(ptr align 8 %self, i64 %_0.i1)
  br label %bb21

bb21:                                             ; preds = %bb8
  br label %bb9

bb10:                                             ; preds = %bb9
  %_0.i = getelementptr inbounds nuw i32, ptr %_19, i64 %len
  br label %bb11

bb11:                                             ; preds = %bb10
  store i8 0, ptr %_23, align 1
  store i32 %element, ptr %_0.i, align 4
  br label %bb12

bb12:                                             ; preds = %bb11
  %_22 = add i64 %len, 1
; call <alloc::vec::Vec<char>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7set_lenCs31EPG3twprw_7structs(ptr align 8 %self, i64 %_22) #24
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_23, align 1
  br label %bb1

bb20:                                             ; No predecessors!
  unreachable

bb16:                                             ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable
}

; alloc::slice::stable_sort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCs7CppTae75M1_5alloc5slice11stable_sortNtCs31EPG3twprw_7structs7VersionNvYBH_NtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltEBJ_(ptr %v.0, i64 %v.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !352 {
start:
  %_0.i1 = alloca [1 x i8], align 1
  %_0.i = alloca [1 x i8], align 1
  %is_less = alloca [0 x i8], align 1
  %_6.i = icmp ult i64 %v.1, 2
  br i1 %_6.i, label %bb1.i3, label %bb2.i2

bb2.i2:                                           ; preds = %start
  store i8 0, ptr %_0.i1, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4

bb1.i3:                                           ; preds = %start
  store i8 1, ptr %_0.i1, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4

_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4: ; preds = %bb2.i2, %bb1.i3
  %0 = load i8, ptr %_0.i1, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortNtCs31EPG3twprw_7structs7VersionNvYBO_NtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VecBO_EEBQ_.exit, label %bb3.i

bb3.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4
  %_8.i = icmp ule i64 %v.1, 20
  br i1 %_8.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb3.i
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit

bb1.i:                                            ; preds = %bb3.i
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit: ; preds = %bb2.i, %bb1.i
  %2 = load i8, ptr %_0.i, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb5.i, label %bb6.i

bb6.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit
; call core::slice::sort::stable::driftsort_main::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt, alloc::vec::Vec<structs::Version>>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable14driftsort_mainNtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VecBZ_EEB11_(ptr %v.0, i64 %v.1, ptr %is_less) #23
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortNtCs31EPG3twprw_7structs7VersionNvYBO_NtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VecBO_EEBQ_.exit

bb5.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit
; call core::slice::sort::shared::smallsort::insertion_sort_shift_left::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtCs31EPG3twprw_7structs7VersionNvYB1m_NtNtBa_3cmp10PartialOrd2ltEB1o_(ptr %v.0, i64 %v.1, i64 1, ptr %is_less)
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortNtCs31EPG3twprw_7structs7VersionNvYBO_NtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VecBO_EEBQ_.exit

_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortNtCs31EPG3twprw_7structs7VersionNvYBO_NtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VecBO_EEBQ_.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4, %bb6.i, %bb5.i
  br label %bb1

bb1:                                              ; preds = %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortNtCs31EPG3twprw_7structs7VersionNvYBO_NtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VecBO_EEBQ_.exit
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; alloc::raw_vec::new_cap::<structs::Version>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCs31EPG3twprw_7structs7VersionEBG_(i64 %cap) unnamed_addr #1 !guid !353 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs31EPG3twprw_7structs(i64 %cap) #24
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs31EPG3twprw_7structs(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !354 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.2, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::select_unpredictable::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal ptr @_RINvNtCsl10jNU3mE6R_4core10intrinsics20select_unpredictableINtNtNtB4_3mem12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEEB1D_(i1 zeroext %b, ptr %true_val, ptr %false_val) unnamed_addr #2 !guid !355 {
start:
  %_0 = alloca [8 x i8], align 8
  br i1 %b, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr %false_val, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store ptr %true_val, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; core::intrinsics::select_unpredictable::<*mut *const structs::Version>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal ptr @_RINvNtCsl10jNU3mE6R_4core10intrinsics20select_unpredictableOPNtCs31EPG3twprw_7structs7VersionEBZ_(i1 zeroext %b, ptr %true_val, ptr %false_val) unnamed_addr #2 !guid !356 {
start:
  %_0 = alloca [8 x i8], align 8
  br i1 %b, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr %false_val, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store ptr %true_val, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; core::intrinsics::typed_swap_nonoverlapping::<structs::Version>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core10intrinsics25typed_swap_nonoverlappingNtCs31EPG3twprw_7structs7VersionEB12_(ptr %x, ptr %y) unnamed_addr #2 personality ptr @rust_eh_personality !guid !357 {
start:
; invoke core::ptr::swap_nonoverlapping::<structs::Version>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_(ptr %x, ptr %y, i64 1, ptr align 8 @alloc_4267f6d2b1c6fe0d6aaa5e106110e530)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  ret void
}

; core::mem::needs_drop::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropReECs31EPG3twprw_7structs() unnamed_addr #0 !guid !358 {
start:
  ret i1 false
}

; core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>, *const structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEB1f_EB1i_(ptr %src) unnamed_addr #0 !guid !359 {
start:
  ret ptr %src
}

; core::mem::size_of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawINtNtB2_12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEB1k_(ptr %val) unnamed_addr #0 !guid !360 {
start:
  ret i64 9
}

; core::mem::size_of_val_raw::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawNtCs31EPG3twprw_7structs7VersionEBK_(ptr %val) unnamed_addr #0 !guid !361 {
start:
  ret i64 3
}

; core::mem::size_of_val_raw::<[structs::Version]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCs31EPG3twprw_7structs7VersionEBL_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !362 {
start:
  %_0 = mul nuw nsw i64 %val.1, 3
  ret i64 %_0
}

; core::mem::align_of_val_raw::<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawINtNtB2_12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEB1l_(ptr %val) unnamed_addr #0 !guid !363 {
start:
  ret i64 1
}

; core::mem::align_of_val_raw::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawNtCs31EPG3twprw_7structs7VersionEBL_(ptr %val) unnamed_addr #0 !guid !364 {
start:
  ret i64 1
}

; core::mem::align_of_val_raw::<[structs::Version]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCs31EPG3twprw_7structs7VersionEBM_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !365 {
start:
  %0 = mul nuw nsw i64 %val.1, 3
  ret i64 1
}

; core::mem::drop::<alloc::boxed::Box<structs::Version>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc5boxed3BoxNtCs31EPG3twprw_7structs7VersionEEB17_(ptr %0) unnamed_addr #0 !guid !366 {
start:
  %_x = alloca [8 x i8], align 8
  store ptr %0, ptr %_x, align 8
; call core::ptr::drop_glue::<alloc::boxed::Box<structs::Version>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxNtCs31EPG3twprw_7structs7VersionEEB1c_(ptr align 8 %_x)
  ret void
}

; core::mem::swap::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem4swapNtCs31EPG3twprw_7structs7VersionEBy_(ptr %x, ptr %y) unnamed_addr #0 !guid !367 {
start:
  %0 = alloca [3 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %0, ptr align 1 %x, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %x, ptr align 1 %y, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %y, ptr align 1 %0, i64 3, i1 false)
  ret void
}

; core::mem::forget::<core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDropNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %t) unnamed_addr #0 !guid !368 {
start:
  %0 = alloca [24 x i8], align 8
  %_2.i = alloca [24 x i8], align 8
  %1 = alloca [24 x i8], align 8
  %_2 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %t, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 24, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtNtB6_5slice4sort6shared9smallsort10CopyOnDropNtCs31EPG3twprw_7structs7VersionEE3newB1Y_(ptr sret([24 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_2, ptr align 8 %_2.i, i64 24, i1 false)
  ret void
}

; core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1p_(ptr %t) unnamed_addr #0 !guid !369 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>>::new
  %_2.i = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNvNtB6_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEE3newB1V_(ptr %t)
  ret void
}

; core::ptr::swap_nonoverlapping::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_(ptr %x, ptr %y, i64 %count, ptr align 8 %0) unnamed_addr #0 !guid !370 {
start:
  %_10 = alloca [24 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::swap_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %x, ptr %y, i64 3, i64 1, i64 %count, ptr align 8 %0) #25
  br label %bb4

bb4:                                              ; preds = %bb1
  store ptr %x, ptr %_10, align 8
  %1 = getelementptr inbounds i8, ptr %_10, i64 8
  store ptr %y, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_10, i64 16
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_10, align 8
  %4 = getelementptr inbounds i8, ptr %_10, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_10, i64 16
  %7 = load i64, ptr %6, align 8
; call core::ptr::swap_nonoverlapping::runtime::<structs::Version>
  call void @_RINvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping7runtimeNtCs31EPG3twprw_7structs7VersionEBY_(ptr %3, ptr %5, i64 %7) #24
  ret void
}

; core::ptr::slice_from_raw_parts::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partsNtCs31EPG3twprw_7structs7VersionEBP_(ptr %data, i64 %len) unnamed_addr #0 !guid !371 {
start:
; call core::ptr::metadata::from_raw_parts::<[structs::Version], structs::Version>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsSNtCs31EPG3twprw_7structs7VersionBT_EBV_(ptr %data, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<structs::Version>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtNtB4_3mem12maybe_uninit11MaybeUninitNtCs31EPG3twprw_7structs7VersionEEB1y_(ptr %data, i64 %len) unnamed_addr #0 !guid !372 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[core::mem::maybe_uninit::MaybeUninit<structs::Version>], core::mem::maybe_uninit::MaybeUninit<structs::Version>>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtNtB6_3mem12maybe_uninit11MaybeUninitNtCs31EPG3twprw_7structs7VersionEBX_EB1E_(ptr %data, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<structs::Token>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCs31EPG3twprw_7structs5TokenEBT_(ptr %data, i64 %len) unnamed_addr #0 !guid !373 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[structs::Token], structs::Token>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCs31EPG3twprw_7structs5TokenBX_EBZ_(ptr %data, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionEBT_(ptr %data, i64 %len) unnamed_addr #0 !guid !374 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[structs::Version], structs::Version>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCs31EPG3twprw_7structs7VersionBX_EBZ_(ptr %data, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutcECs31EPG3twprw_7structs(ptr %data, i64 %len) unnamed_addr #0 !guid !375 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[char], char>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSccECs31EPG3twprw_7structs(ptr %data, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<alloc::vec::Vec<structs::Token>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs5TokenEEB1a_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !376 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<structs::Token> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<structs::Token>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCs31EPG3twprw_7structs5TokenEEB1h_(ptr align 8 %_1) #21
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<structs::Token>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCs31EPG3twprw_7structs5TokenEEB1h_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<structs::Version>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEEB1a_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !377 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<structs::Version> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCs31EPG3twprw_7structs7VersionEEB1h_(ptr align 8 %_1) #21
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<structs::Version>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCs31EPG3twprw_7structs7VersionEEB1h_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<char>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECs31EPG3twprw_7structs(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !378 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<char> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs31EPG3twprw_7structs(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeccEECs31EPG3twprw_7structs(ptr align 8 %_1) #21
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<char>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeccEECs31EPG3twprw_7structs(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtNtB4_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEEB1S_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !379 {
start:
  %0 = alloca [16 x i8], align 8
  %_6 = load ptr, ptr %_1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtNtCsl10jNU3mE6R_4core3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EENtNtNtBO_3ops4drop4Drop4dropB1F_(ptr align 8 %_1) #24
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtNtCsl10jNU3mE6R_4core3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EENtNtNtBO_3ops4drop4Drop4dropB1F_(ptr align 8 %_1) #21
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb2:                                              ; preds = %bb4
  %2 = load ptr, ptr %0, align 8
  %3 = getelementptr inbounds i8, ptr %0, i64 8
  %4 = load i32, ptr %3, align 8
  %5 = insertvalue { ptr, i32 } poison, ptr %2, 0
  %6 = insertvalue { ptr, i32 } %5, i32 %4, 1
  resume { ptr, i32 } %6
}

; core::ptr::drop_glue::<alloc::boxed::Box<structs::Version>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxNtCs31EPG3twprw_7structs7VersionEEB1c_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !380 {
start:
  %0 = alloca [16 x i8], align 8
  %_6 = load ptr, ptr %_1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<structs::Version> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBJ_(ptr align 8 %_1) #24
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<structs::Version> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBJ_(ptr align 8 %_1) #21
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb2:                                              ; preds = %bb4
  %2 = load ptr, ptr %0, align 8
  %3 = getelementptr inbounds i8, ptr %0, i64 8
  %4 = load i32, ptr %3, align 8
  %5 = insertvalue { ptr, i32 } poison, ptr %2, 0
  %6 = insertvalue { ptr, i32 } %5, i32 %4, 1
  resume { ptr, i32 } %6
}

; core::ptr::drop_glue::<alloc::boxed::Box<[structs::Version]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCs31EPG3twprw_7structs7VersionEEB1d_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !381 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[structs::Version]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #24
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<[structs::Version]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #21
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb2:                                              ; preds = %bb4
  %3 = load ptr, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8
  %6 = insertvalue { ptr, i32 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i32 } %6, i32 %5, 1
  resume { ptr, i32 } %7
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<structs::Token>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCs31EPG3twprw_7structs5TokenEEB1h_(ptr align 8 %_1) unnamed_addr #1 !guid !382 {
start:
; call <alloc::raw_vec::RawVec<structs::Token> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<structs::Version>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCs31EPG3twprw_7structs7VersionEEB1h_(ptr align 8 %_1) unnamed_addr #1 !guid !383 {
start:
; call <alloc::raw_vec::RawVec<structs::Version> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<char>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeccEECs31EPG3twprw_7structs(ptr align 8 %_1) unnamed_addr #1 !guid !384 {
start:
; call <alloc::raw_vec::RawVec<char> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs31EPG3twprw_7structs(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<&str, 4>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterReKj4_EECs31EPG3twprw_7structs(ptr align 8 %_1) unnamed_addr #1 !guid !385 {
start:
; call <core::array::iter::IntoIter<&str, 4> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj4_ENtNtNtB9_3ops4drop4Drop4dropCs31EPG3twprw_7structs(ptr align 8 %_1) #24
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitReEj4_EECs31EPG3twprw_7structs(ptr align 8 %_1) unnamed_addr #1 !guid !386 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj4_ENtNtNtBb_3ops4drop4Drop4dropCs31EPG3twprw_7structs(ptr align 8 %_1) #24
  ret void
}

; core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDropNtCs31EPG3twprw_7structs7VersionEEB1v_(ptr align 8 %_1) unnamed_addr #1 !guid !387 {
start:
; call <core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsortINtB5_10CopyOnDropNtCs31EPG3twprw_7structs7VersionENtNtNtBd_3ops4drop4Drop4dropB1i_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::slice::sort::stable::merge::MergeState<structs::Version>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6stable5merge10MergeStateNtCs31EPG3twprw_7structs7VersionEEB1r_(ptr align 8 %_1) unnamed_addr #1 !guid !388 {
start:
; call <core::slice::sort::stable::merge::MergeState<structs::Version> as core::ops::drop::Drop>::drop
  call void @_RNvXs_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB4_10MergeStateNtCs31EPG3twprw_7structs7VersionENtNtNtBc_3ops4drop4Drop4dropB1d_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %_1) unnamed_addr #1 !guid !389 {
start:
; call <core::hint::select_unpredictable::DropOnPanic<*const structs::Version> as core::ops::drop::Drop>::drop
  call void @_RNvXNvNtCsl10jNU3mE6R_4core4hint20select_unpredictableINtB2_11DropOnPanicPNtCs31EPG3twprw_7structs7VersionENtNtNtB6_3ops4drop4Drop4dropB1c_(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxReECs31EPG3twprw_7structs(ptr %dummy.0, i64 %dummy.1) unnamed_addr #0 !guid !390 {
start:
  %_0 = alloca [16 x i8], align 8
  store ptr %dummy.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %dummy.1, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !391
  %1 = load ptr, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { ptr, i64 } poison, ptr %1, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %3, 1
  ret { ptr, i64 } %5
}

; core::hint::black_box::<(i32, &str, f64)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxTlRedEECs31EPG3twprw_7structs(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %dummy) unnamed_addr #0 !guid !392 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %dummy, i64 32, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !391
  ret void
}

; core::hint::black_box::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs31EPG3twprw_7structs(float %dummy) unnamed_addr #0 !guid !393 {
start:
  %_0 = alloca [4 x i8], align 4
  store float %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !391
  %0 = load float, ptr %_0, align 4
  ret float %0
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs31EPG3twprw_7structs(i8 %dummy) unnamed_addr #0 !guid !394 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !391
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs31EPG3twprw_7structs(i32 %dummy) unnamed_addr #0 !guid !395 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !391
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs31EPG3twprw_7structs(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !396 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs31EPG3twprw_7structs(ptr %f) #24
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #24
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[structs::Version], structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsSNtCs31EPG3twprw_7structs7VersionBT_EBV_(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !397 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<structs::Version, ()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionuEBY_(ptr %data_pointer) unnamed_addr #0 !guid !398 {
start:
  ret ptr %data_pointer
}

; core::ptr::metadata::from_raw_parts_mut::<[core::mem::maybe_uninit::MaybeUninit<structs::Version>], core::mem::maybe_uninit::MaybeUninit<structs::Version>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtNtB6_3mem12maybe_uninit11MaybeUninitNtCs31EPG3twprw_7structs7VersionEBX_EB1E_(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !399 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[structs::Token], structs::Token>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCs31EPG3twprw_7structs5TokenBX_EBZ_(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !400 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[structs::Version], structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCs31EPG3twprw_7structs7VersionBX_EBZ_(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !401 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[char], char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSccECs31EPG3twprw_7structs(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !402 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&str>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitReEECs31EPG3twprw_7structs(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !403 {
start:
  ret i64 %ptr.1
}

; core::ptr::metadata::metadata::<[structs::Version]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSNtCs31EPG3twprw_7structs7VersionEBO_(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !404 {
start:
  ret i64 %ptr.1
}

; core::slice::raw::from_raw_parts::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partsNtCs31EPG3twprw_7structs7VersionEBR_(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !405 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts::<structs::Version>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partsNtCs31EPG3twprw_7structs7VersionEBP_(ptr %data, i64 %len) #24
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCs31EPG3twprw_7structs(ptr %data, i64 3, i64 1, i64 %len, ptr align 8 %0) #25
  br label %bb5
}

; core::slice::raw::from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<structs::Version>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutINtNtNtB6_3mem12maybe_uninit11MaybeUninitNtCs31EPG3twprw_7structs7VersionEEB1A_(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !406 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<structs::Version>>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtNtB4_3mem12maybe_uninit11MaybeUninitNtCs31EPG3twprw_7structs7VersionEEB1y_(ptr %data, i64 %len) #24
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts_mut::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCs31EPG3twprw_7structs(ptr %data, i64 3, i64 1, i64 %len, ptr align 8 %0) #25
  br label %bb5
}

; core::slice::raw::from_raw_parts_mut::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionEBV_(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !407 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts_mut::<structs::Version>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionEBT_(ptr %data, i64 %len) #24
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts_mut::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCs31EPG3twprw_7structs(ptr %data, i64 3, i64 1, i64 %len, ptr align 8 %0) #25
  br label %bb5
}

; core::iter::adapters::map::map_fold::<&char, char, (), <char as core::clone::Clone>::clone, core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRccuNvYcNtNtB8_5clone5Clone5cloneNCINvNvNtNtNtB6_6traits8iterator8Iterator8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB2s_6StringINtNtB1A_7collect6ExtendcE6extendINtNtB4_6cloned6ClonedINtNtNtB8_5slice4iter4ItercEEE0E0ECs31EPG3twprw_7structs(ptr align 8 %g) unnamed_addr #1 !guid !408 {
start:
  ret ptr %g
}

; core::iter::adapters::map::map_fold::<&u8, usize, usize, structs::main::{closure#0}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRhjjNCNvCs31EPG3twprw_7structs4main0NCINvXsK_NtNtB6_6traits5accumjNtB1B_3Sum3sumINtB2_3MapINtNtNtB8_5slice4iter4IterhEBW_EE0EB10_() unnamed_addr #1 !guid !409 {
start:
  ret void
}

; core::slice::sort::stable::driftsort_main::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt, alloc::vec::Vec<structs::Version>>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable14driftsort_mainNtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VecBZ_EEB11_(ptr %v.0, i64 %v.1, ptr %is_less) unnamed_addr #3 personality ptr @rust_eh_personality !guid !410 {
start:
  %0 = alloca [16 x i8], align 8
  %_30 = alloca [1 x i8], align 1
  %_23 = alloca [24 x i8], align 8
  %scratch = alloca [16 x i8], align 8
  %heap_buf = alloca [24 x i8], align 8
  %stack_buf = alloca [4096 x i8], align 1
  store i8 0, ptr %_30, align 1
  %_5 = icmp eq i64 3, 0
  br i1 %_5, label %panic, label %bb2

bb2:                                              ; preds = %start
  %max_full_alloc = udiv i64 8000000, 3
  %_11 = udiv i64 %v.1, 2
  %_10 = sub i64 %v.1, %_11
; call core::cmp::min::<usize>
  %_13 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %v.1, i64 %max_full_alloc) #24
; call core::cmp::max::<usize>
  %_9 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64 %_10, i64 %_13) #24
; call core::cmp::max::<usize>
  %alloc_len = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64 %_9, i64 48) #24
; call <core::slice::sort::stable::AlignedStorage<structs::Version, 4096>>::new
  call void @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStorageNtCs31EPG3twprw_7structs7VersionKj1000_E3newB17_(ptr sret([4096 x i8]) align 1 %stack_buf)
; call <core::slice::sort::stable::AlignedStorage<structs::Version, 4096>>::as_uninit_slice_mut
  %1 = call { ptr, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStorageNtCs31EPG3twprw_7structs7VersionKj1000_E19as_uninit_slice_mutB17_(ptr %stack_buf)
  %stack_scratch.0 = extractvalue { ptr, i64 } %1, 0
  %stack_scratch.1 = extractvalue { ptr, i64 } %1, 1
  %_19 = icmp uge i64 %stack_scratch.1, %alloc_len
  br i1 %_19, label %bb9, label %bb10

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_63f80f9ffc23059c68b68d596767dcd4) #26
  unreachable

bb10:                                             ; preds = %bb2
; invoke <alloc::vec::Vec<structs::Version> as core::slice::sort::stable::BufGuard<structs::Version>>::with_capacity
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VecNtCs31EPG3twprw_7structs7VersionEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardBN_E13with_capacityBP_(ptr sret([24 x i8]) align 8 %_23, i64 %alloc_len)
          to label %bb11 unwind label %cleanup

bb9:                                              ; preds = %bb2
  store ptr %stack_scratch.0, ptr %scratch, align 8
  %2 = getelementptr inbounds i8, ptr %scratch, i64 8
  store i64 %stack_scratch.1, ptr %2, align 8
  br label %bb13

bb20:                                             ; preds = %cleanup
  %3 = load i8, ptr %_30, align 1
  %4 = trunc nuw i8 %3 to i1
  br i1 %4, label %bb19, label %bb17

cleanup:                                          ; preds = %bb14, %bb11, %bb10
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb20

bb11:                                             ; preds = %bb10
  store i8 1, ptr %_30, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %heap_buf, ptr align 8 %_23, i64 24, i1 false)
; invoke <alloc::vec::Vec<structs::Version> as core::slice::sort::stable::BufGuard<structs::Version>>::as_uninit_slice_mut
  %9 = invoke { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VecNtCs31EPG3twprw_7structs7VersionEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardBN_E19as_uninit_slice_mutBP_(ptr align 8 %heap_buf)
          to label %bb12 unwind label %cleanup

bb12:                                             ; preds = %bb11
  %_22.0 = extractvalue { ptr, i64 } %9, 0
  %_22.1 = extractvalue { ptr, i64 } %9, 1
  store ptr %_22.0, ptr %scratch, align 8
  %10 = getelementptr inbounds i8, ptr %scratch, i64 8
  store i64 %_22.1, ptr %10, align 8
  br label %bb13

bb13:                                             ; preds = %bb9, %bb12
  br label %bb14

bb14:                                             ; preds = %bb13
  %_26 = mul i64 32, 2
  %eager_sort = icmp ule i64 %v.1, %_26
  %_29.0 = load ptr, ptr %scratch, align 8
  %11 = getelementptr inbounds i8, ptr %scratch, i64 8
  %_29.1 = load i64, ptr %11, align 8
; invoke core::slice::sort::stable::drift::sort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  invoke void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift4sortNtCs31EPG3twprw_7structs7VersionNvYBW_NtNtBa_3cmp10PartialOrd2ltEBY_(ptr %v.0, i64 %v.1, ptr %_29.0, i64 %_29.1, i1 zeroext %eager_sort, ptr %is_less)
          to label %bb15 unwind label %cleanup

bb15:                                             ; preds = %bb14
  %12 = load i8, ptr %_30, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb18, label %bb16

bb16:                                             ; preds = %bb18, %bb15
  store i8 0, ptr %_30, align 1
  ret void

bb18:                                             ; preds = %bb15
; call core::ptr::drop_glue::<alloc::vec::Vec<structs::Version>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEEB1a_(ptr align 8 %heap_buf)
  br label %bb16

bb17:                                             ; preds = %bb19, %bb20
  %14 = load ptr, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  %16 = load i32, ptr %15, align 8
  %17 = insertvalue { ptr, i32 } poison, ptr %14, 0
  %18 = insertvalue { ptr, i32 } %17, i32 %16, 1
  resume { ptr, i32 } %18

bb19:                                             ; preds = %bb20
; invoke core::ptr::drop_glue::<alloc::vec::Vec<structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEEB1a_(ptr align 8 %heap_buf) #21
          to label %bb17 unwind label %terminate

terminate:                                        ; preds = %bb19
  %19 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable
}

; core::slice::sort::shared::pivot::median3_rec::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_recNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_(ptr %0, ptr %1, ptr %2, i64 %n, ptr %is_less) unnamed_addr #1 !guid !411 {
start:
  %_0.i = alloca [8 x i8], align 8
  %c = alloca [8 x i8], align 8
  %b = alloca [8 x i8], align 8
  %a = alloca [8 x i8], align 8
  store ptr %0, ptr %a, align 8
  store ptr %1, ptr %b, align 8
  store ptr %2, ptr %c, align 8
  %_7 = mul i64 %n, 8
  %_6 = icmp uge i64 %_7, 64
  br i1 %_6, label %bb1, label %bb12

bb12:                                             ; preds = %bb1, %start
  %_34 = load ptr, ptr %a, align 8
  %_35 = load ptr, ptr %b, align 8
  %_36 = load ptr, ptr %c, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %x.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_34, ptr %_35) #24
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %y.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_34, ptr %_36) #24
  %_9.i = icmp eq i1 %x.i, %y.i
  br i1 %_9.i, label %bb3.i, label %bb7.i

bb7.i:                                            ; preds = %bb12
  store ptr %_34, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3NtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtBa_3cmp10PartialOrd2ltEB11_.exit

bb3.i:                                            ; preds = %bb12
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %z.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_35, ptr %_36) #24
  %_12.i = xor i1 %z.i, %x.i
  br i1 %_12.i, label %bb5.i, label %bb6.i

bb6.i:                                            ; preds = %bb3.i
  store ptr %_35, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3NtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtBa_3cmp10PartialOrd2ltEB11_.exit

bb5.i:                                            ; preds = %bb3.i
  store ptr %_36, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3NtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtBa_3cmp10PartialOrd2ltEB11_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3NtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtBa_3cmp10PartialOrd2ltEB11_.exit: ; preds = %bb7.i, %bb6.i, %bb5.i
  %3 = load ptr, ptr %_0.i, align 8
  ret ptr %3

bb1:                                              ; preds = %start
  %n8 = udiv i64 %n, 8
  %_11 = load ptr, ptr %a, align 8
  %_13 = load ptr, ptr %a, align 8
  %_14 = mul i64 %n8, 4
  %_0.i6 = getelementptr inbounds nuw %Version, ptr %_13, i64 %_14
  %_16 = load ptr, ptr %a, align 8
  %_17 = mul i64 %n8, 7
  %_0.i5 = getelementptr inbounds nuw %Version, ptr %_16, i64 %_17
; call core::slice::sort::shared::pivot::median3_rec::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  %_10 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_recNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_(ptr %_11, ptr %_0.i6, ptr %_0.i5, i64 %n8, ptr %is_less)
  store ptr %_10, ptr %a, align 8
  %_19 = load ptr, ptr %b, align 8
  %_21 = load ptr, ptr %b, align 8
  %_22 = mul i64 %n8, 4
  %_0.i4 = getelementptr inbounds nuw %Version, ptr %_21, i64 %_22
  %_24 = load ptr, ptr %b, align 8
  %_25 = mul i64 %n8, 7
  %_0.i3 = getelementptr inbounds nuw %Version, ptr %_24, i64 %_25
; call core::slice::sort::shared::pivot::median3_rec::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  %_18 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_recNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_(ptr %_19, ptr %_0.i4, ptr %_0.i3, i64 %n8, ptr %is_less)
  store ptr %_18, ptr %b, align 8
  %_27 = load ptr, ptr %c, align 8
  %_29 = load ptr, ptr %c, align 8
  %_30 = mul i64 %n8, 4
  %_0.i2 = getelementptr inbounds nuw %Version, ptr %_29, i64 %_30
  %_32 = load ptr, ptr %c, align 8
  %_33 = mul i64 %n8, 7
  %_0.i1 = getelementptr inbounds nuw %Version, ptr %_32, i64 %_33
; call core::slice::sort::shared::pivot::median3_rec::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  %_26 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_recNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_(ptr %_27, ptr %_0.i2, ptr %_0.i1, i64 %n8, ptr %is_less)
  store ptr %_26, ptr %c, align 8
  br label %bb12
}

; core::slice::sort::shared::pivot::choose_pivot::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot12choose_pivotNtCs31EPG3twprw_7structs7VersionNvYB15_NtNtBa_3cmp10PartialOrd2ltEB17_(ptr %v.0, i64 %v.1, ptr %is_less) unnamed_addr #0 !guid !412 {
start:
  %_0.i = alloca [8 x i8], align 8
  %index = alloca [8 x i8], align 8
  %_4 = icmp ult i64 %v.1, 8
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %len_div_8 = udiv i64 %v.1, 8
  %_11 = mul i64 %len_div_8, 4
  %_0.i2 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_11
  %_13 = mul i64 %len_div_8, 7
  %_0.i1 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_13
  %_14 = icmp ult i64 %v.1, 64
  br i1 %_14, label %bb7, label %bb9

bb1:                                              ; preds = %start
  call void @llvm.trap()
  unreachable

bb9:                                              ; preds = %bb2
; call core::slice::sort::shared::pivot::median3_rec::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  %_19 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_recNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_(ptr %v.0, ptr %_0.i2, ptr %_0.i1, i64 %len_div_8, ptr %is_less)
; call <*const structs::Version>::offset_from_unsigned
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPNtCs31EPG3twprw_7structs7Version20offset_from_unsignedBG_(ptr %_19, ptr %v.0, ptr align 8 @alloc_f0b38f15064fc95bc0114a55e7ca2131) #24
  store i64 %0, ptr %index, align 8
  br label %bb11

bb7:                                              ; preds = %bb2
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %x.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %v.0, ptr %_0.i2) #24
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %y.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %v.0, ptr %_0.i1) #24
  %_9.i = icmp eq i1 %x.i, %y.i
  br i1 %_9.i, label %bb3.i, label %bb7.i

bb7.i:                                            ; preds = %bb7
  store ptr %v.0, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3NtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtBa_3cmp10PartialOrd2ltEB11_.exit

bb3.i:                                            ; preds = %bb7
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %z.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_0.i2, ptr %_0.i1) #24
  %_12.i = xor i1 %z.i, %x.i
  br i1 %_12.i, label %bb5.i, label %bb6.i

bb6.i:                                            ; preds = %bb3.i
  store ptr %_0.i2, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3NtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtBa_3cmp10PartialOrd2ltEB11_.exit

bb5.i:                                            ; preds = %bb3.i
  store ptr %_0.i1, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3NtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtBa_3cmp10PartialOrd2ltEB11_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3NtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtBa_3cmp10PartialOrd2ltEB11_.exit: ; preds = %bb7.i, %bb6.i, %bb5.i
  %1 = load ptr, ptr %_0.i, align 8
; call <*const structs::Version>::offset_from_unsigned
  %2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPNtCs31EPG3twprw_7structs7Version20offset_from_unsignedBG_(ptr %1, ptr %v.0, ptr align 8 @alloc_1824be00902e801da9c2923e0e00ce0b) #24
  store i64 %2, ptr %index, align 8
  br label %bb11

bb11:                                             ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3NtCs31EPG3twprw_7structs7VersionNvYBZ_NtNtBa_3cmp10PartialOrd2ltEB11_.exit, %bb9
  %_22 = load i64, ptr %index, align 8
  %_21 = icmp ult i64 %_22, %v.1
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb11
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs31EPG3twprw_7structs(i1 zeroext %_21, ptr align 8 @alloc_ab4c6a2d756e35f752701a51dadd262d) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb11, %bb2.i
  %_0 = load i64, ptr %index, align 8
  ret i64 %_0
}

; core::slice::sort::shared::smallsort::insert_tail::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort11insert_tailNtCs31EPG3twprw_7structs7VersionNvYB18_NtNtBa_3cmp10PartialOrd2ltEB1a_(ptr %begin, ptr %tail, ptr %is_less) unnamed_addr #1 personality ptr @rust_eh_personality !guid !413 {
start:
  %_0.i.i = alloca [4 x i8], align 1
  %0 = alloca [4 x i8], align 4
  %_0.i6 = alloca [4 x i8], align 1
  %_0.i4 = alloca [8 x i8], align 8
  %_0.i2 = alloca [8 x i8], align 8
  %1 = alloca [4 x i8], align 4
  %2 = alloca [4 x i8], align 4
  %_2.i = alloca [3 x i8], align 1
  %_0.i = alloca [4 x i8], align 1
  %3 = alloca [4 x i8], align 4
  %value.i = alloca [3 x i8], align 1
  %4 = alloca [16 x i8], align 8
  %5 = alloca [4 x i8], align 4
  %6 = alloca [4 x i8], align 4
  %7 = alloca [4 x i8], align 4
  %gap_guard = alloca [24 x i8], align 8
  %_10 = alloca [3 x i8], align 1
  %tmp = alloca [3 x i8], align 1
  %sift = alloca [8 x i8], align 8
  %8 = getelementptr inbounds %Version, ptr %tail, i64 -1
  store ptr %8, ptr %_0.i4, align 8
  %9 = load ptr, ptr %_0.i4, align 8
  store ptr %9, ptr %sift, align 8
  %_8 = load ptr, ptr %sift, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_5 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %tail, ptr %_8) #24
  br i1 %_5, label %bb3, label %bb14

bb14:                                             ; preds = %bb13, %start
  ret void

bb3:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i.i, ptr align 1 %tail, i64 3, i1 false)
  %10 = load i24, ptr %_0.i.i, align 1
  store i24 %10, ptr %0, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i6, ptr align 4 %0, i64 3, i1 false)
  %11 = load i24, ptr %_0.i6, align 1
  store i24 %11, ptr %7, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_10, ptr align 4 %7, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 1 %_10, i64 3, i1 false)
  %12 = load i24, ptr %6, align 4
  store i24 %12, ptr %3, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %value.i, ptr align 4 %3, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 1 %value.i, i64 3, i1 false)
  %13 = load i24, ptr %2, align 4
; call <core::mem::maybe_dangling::MaybeDangling<structs::Version>>::new
  %14 = call i24 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtCs31EPG3twprw_7structs7VersionE3newB16_(i24 %13)
  store i24 %14, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2.i, ptr align 4 %1, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i, ptr align 1 %_2.i, i64 3, i1 false)
  %15 = load i24, ptr %_0.i, align 1
  store i24 %15, ptr %5, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %tmp, ptr align 4 %5, i64 3, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<structs::Version>>::as_ref
  %_0.i9 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtCs31EPG3twprw_7structs7VersionE6as_refB16_(ptr %tmp)
  store ptr %_0.i9, ptr %gap_guard, align 8
  %16 = getelementptr inbounds i8, ptr %gap_guard, i64 8
  store ptr %tail, ptr %16, align 8
  %17 = getelementptr inbounds i8, ptr %gap_guard, i64 16
  store i64 1, ptr %17, align 8
  br label %bb7

bb7:                                              ; preds = %bb12, %bb3
  %_17 = load ptr, ptr %sift, align 8
  %18 = getelementptr inbounds i8, ptr %gap_guard, i64 8
  %_18 = load ptr, ptr %18, align 8
; invoke core::ub_checks::check_language_ub
  %_4.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
          to label %_4.i.noexc unwind label %cleanup

_4.i.noexc:                                       ; preds = %bb7
  br i1 %_4.i1, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %_4.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_17, ptr %_18, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %_4.i.noexc, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_18, ptr align 1 %_17, i64 3, i1 false)
  br label %bb8

bb15:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDropNtCs31EPG3twprw_7structs7VersionEEB1v_(ptr align 8 %gap_guard) #21
          to label %bb16 unwind label %terminate

cleanup:                                          ; preds = %bb10, %bb7, %bb11
  %19 = landingpad { ptr, i32 }
          cleanup
  %20 = extractvalue { ptr, i32 } %19, 0
  %21 = extractvalue { ptr, i32 } %19, 1
  store ptr %20, ptr %4, align 8
  %22 = getelementptr inbounds i8, ptr %4, i64 8
  store i32 %21, ptr %22, align 8
  br label %bb15

bb8:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit
  %_19 = load ptr, ptr %sift, align 8
  %23 = getelementptr inbounds i8, ptr %gap_guard, i64 8
  store ptr %_19, ptr %23, align 8
  %_21 = load ptr, ptr %sift, align 8
  %_20 = icmp eq ptr %_21, %begin
  br i1 %_20, label %bb13, label %bb9

bb9:                                              ; preds = %bb8
  %_23 = load ptr, ptr %sift, align 8
  %24 = getelementptr inbounds %Version, ptr %_23, i64 -1
  store ptr %24, ptr %_0.i2, align 8
  %25 = load ptr, ptr %_0.i2, align 8
  br label %bb10

bb13:                                             ; preds = %bb12, %bb8
; call core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDropNtCs31EPG3twprw_7structs7VersionEEB1v_(ptr align 8 %gap_guard)
  br label %bb14

bb10:                                             ; preds = %bb9
  store ptr %25, ptr %sift, align 8
; invoke <core::mem::maybe_dangling::MaybeDangling<structs::Version>>::as_ref
  %_0.i78 = invoke ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtCs31EPG3twprw_7structs7VersionE6as_refB16_(ptr %tmp)
          to label %_RNvXs0_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB5_12ManuallyDropNtCs31EPG3twprw_7structs7VersionENtNtNtB9_3ops5deref5Deref5derefB17_.exit unwind label %cleanup

_RNvXs0_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB5_12ManuallyDropNtCs31EPG3twprw_7structs7VersionENtNtNtB9_3ops5deref5Deref5derefB17_.exit: ; preds = %bb10
  br label %bb11

bb11:                                             ; preds = %_RNvXs0_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB5_12ManuallyDropNtCs31EPG3twprw_7structs7VersionENtNtNtB9_3ops5deref5Deref5derefB17_.exit
  %_28 = load ptr, ptr %sift, align 8
; invoke <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_24 = invoke zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_0.i78, ptr %_28)
          to label %bb12 unwind label %cleanup

bb12:                                             ; preds = %bb11
  br i1 %_24, label %bb7, label %bb13

terminate:                                        ; preds = %bb15
  %26 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb16:                                             ; preds = %bb15
  %27 = load ptr, ptr %4, align 8
  %28 = getelementptr inbounds i8, ptr %4, i64 8
  %29 = load i32, ptr %28, align 8
  %30 = insertvalue { ptr, i32 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i32 } %30, i32 %29, 1
  resume { ptr, i32 } %31
}

; core::slice::sort::shared::smallsort::sort4_stable::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stableNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %v_base, ptr %dst, ptr %is_less) unnamed_addr #1 personality ptr @rust_eh_personality !guid !414 {
start:
  %0 = alloca [16 x i8], align 8
  %_21.i155 = alloca [1 x i8], align 1
  %_20.i156 = alloca [1 x i8], align 1
  %guard.i157 = alloca [8 x i8], align 8
  %false_val2.i158 = alloca [8 x i8], align 8
  %true_val1.i159 = alloca [8 x i8], align 8
  %1 = alloca [16 x i8], align 8
  %_21.i131 = alloca [1 x i8], align 1
  %_20.i132 = alloca [1 x i8], align 1
  %guard.i133 = alloca [8 x i8], align 8
  %false_val2.i134 = alloca [8 x i8], align 8
  %true_val1.i135 = alloca [8 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %_21.i107 = alloca [1 x i8], align 1
  %_20.i108 = alloca [1 x i8], align 1
  %guard.i109 = alloca [8 x i8], align 8
  %false_val2.i110 = alloca [8 x i8], align 8
  %true_val1.i111 = alloca [8 x i8], align 8
  %3 = alloca [16 x i8], align 8
  %_21.i83 = alloca [1 x i8], align 1
  %_20.i84 = alloca [1 x i8], align 1
  %guard.i85 = alloca [8 x i8], align 8
  %false_val2.i86 = alloca [8 x i8], align 8
  %true_val1.i87 = alloca [8 x i8], align 8
  %4 = alloca [16 x i8], align 8
  %_21.i59 = alloca [1 x i8], align 1
  %_20.i60 = alloca [1 x i8], align 1
  %guard.i61 = alloca [8 x i8], align 8
  %false_val2.i62 = alloca [8 x i8], align 8
  %true_val1.i63 = alloca [8 x i8], align 8
  %5 = alloca [16 x i8], align 8
  %_21.i35 = alloca [1 x i8], align 1
  %_20.i36 = alloca [1 x i8], align 1
  %guard.i37 = alloca [8 x i8], align 8
  %false_val2.i38 = alloca [8 x i8], align 8
  %true_val1.i39 = alloca [8 x i8], align 8
  %6 = alloca [16 x i8], align 8
  %_21.i11 = alloca [1 x i8], align 1
  %_20.i12 = alloca [1 x i8], align 1
  %guard.i13 = alloca [8 x i8], align 8
  %false_val2.i14 = alloca [8 x i8], align 8
  %true_val1.i15 = alloca [8 x i8], align 8
  %7 = alloca [16 x i8], align 8
  %_21.i = alloca [1 x i8], align 1
  %_20.i = alloca [1 x i8], align 1
  %guard.i = alloca [8 x i8], align 8
  %false_val2.i = alloca [8 x i8], align 8
  %true_val1.i = alloca [8 x i8], align 8
  %_0.i188 = getelementptr inbounds nuw %Version, ptr %v_base, i64 1
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %c1 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_0.i188, ptr %v_base) #24
  %_0.i187 = getelementptr inbounds nuw %Version, ptr %v_base, i64 3
  %_0.i186 = getelementptr inbounds nuw %Version, ptr %v_base, i64 2
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %c2 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_0.i187, ptr %_0.i186) #24
  %_16 = zext i1 %c1 to i64
  %_0.i185 = getelementptr inbounds nuw %Version, ptr %v_base, i64 %_16
  %_19 = xor i1 %c1, true
  %_18 = zext i1 %_19 to i64
  %_0.i184 = getelementptr inbounds nuw %Version, ptr %v_base, i64 %_18
  %_22 = zext i1 %c2 to i64
  %_21 = add i64 2, %_22
  %_0.i183 = getelementptr inbounds nuw %Version, ptr %v_base, i64 %_21
  %_26 = xor i1 %c2, true
  %_25 = zext i1 %_26 to i64
  %_24 = add i64 2, %_25
  %_0.i182 = getelementptr inbounds nuw %Version, ptr %v_base, i64 %_24
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %c3 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_0.i183, ptr %_0.i185) #24
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %c4 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_0.i182, ptr %_0.i184) #24
  store i8 0, ptr %_21.i155, align 1
  store i8 0, ptr %_20.i156, align 1
  store i8 1, ptr %_21.i155, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i212 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i183)
  store ptr %_2.i.i212, ptr %true_val1.i159, align 8
  store i8 0, ptr %_21.i155, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i185)
  store ptr %_2.i.i, ptr %false_val2.i158, align 8
  %guard3.i163 = select i1 %c3, ptr %true_val1.i159, ptr %false_val2.i158, !unpredictable !415
  %drop.i164 = select i1 %c3, ptr %false_val2.i158, ptr %true_val1.i159, !unpredictable !415
  store i8 1, ptr %_20.i156, align 1
  store ptr %guard3.i163, ptr %guard.i157, align 8
  br label %bb7.i171

cleanup.i165:                                     ; preds = %bb8.i173, %bb7.i171
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %10, ptr %11, align 8
  %12 = load i8, ptr %_20.i156, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb12.i169, label %bb15.i166

bb7.i171:                                         ; preds = %start
  store i8 0, ptr %_20.i156, align 1
  %_16.i172 = load ptr, ptr %guard.i157, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1p_(ptr %_16.i172)
          to label %bb8.i173 unwind label %cleanup.i165

bb8.i173:                                         ; preds = %bb7.i171
  %_18.i174 = load ptr, ptr %true_val1.i159, align 8
  %_19.i175 = load ptr, ptr %false_val2.i158, align 8
  %_17.i176 = select i1 %c3, ptr %_18.i174, ptr %_19.i175, !unpredictable !415
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>, *const structs::Version>
  %_0.i189190 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEB1f_EB1i_(ptr %_17.i176) #24
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit unwind label %cleanup.i165

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit: ; preds = %bb8.i173
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit178

bb15.i166:                                        ; preds = %bb12.i169, %cleanup.i165
  %14 = load i8, ptr %_21.i155, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb14.i168, label %bb11.i167

bb12.i169:                                        ; preds = %cleanup.i165
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %guard.i157) #21
          to label %bb15.i166 unwind label %terminate.i170

terminate.i170:                                   ; preds = %bb12.i169
  %16 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i167:                                        ; preds = %bb14.i168, %bb15.i166
  %17 = load ptr, ptr %0, align 8
  %18 = getelementptr inbounds i8, ptr %0, i64 8
  %19 = load i32, ptr %18, align 8
  %20 = insertvalue { ptr, i32 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i32 } %20, i32 %19, 1
  resume { ptr, i32 } %21

bb14.i168:                                        ; preds = %bb15.i166
  br label %bb11.i167

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit178: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit
  store i8 0, ptr %_20.i156, align 1
  store i8 0, ptr %_21.i131, align 1
  store i8 0, ptr %_20.i132, align 1
  store i8 1, ptr %_21.i131, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i214 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i184)
  store ptr %_2.i.i214, ptr %true_val1.i135, align 8
  store i8 0, ptr %_21.i131, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i213 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i182)
  store ptr %_2.i.i213, ptr %false_val2.i134, align 8
  %guard3.i139 = select i1 %c4, ptr %true_val1.i135, ptr %false_val2.i134, !unpredictable !415
  %drop.i140 = select i1 %c4, ptr %false_val2.i134, ptr %true_val1.i135, !unpredictable !415
  store i8 1, ptr %_20.i132, align 1
  store ptr %guard3.i139, ptr %guard.i133, align 8
  br label %bb7.i147

cleanup.i141:                                     ; preds = %bb8.i149, %bb7.i147
  %22 = landingpad { ptr, i32 }
          cleanup
  %23 = extractvalue { ptr, i32 } %22, 0
  %24 = extractvalue { ptr, i32 } %22, 1
  store ptr %23, ptr %1, align 8
  %25 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %24, ptr %25, align 8
  %26 = load i8, ptr %_20.i132, align 1
  %27 = trunc nuw i8 %26 to i1
  br i1 %27, label %bb12.i145, label %bb15.i142

bb7.i147:                                         ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit178
  store i8 0, ptr %_20.i132, align 1
  %_16.i148 = load ptr, ptr %guard.i133, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1p_(ptr %_16.i148)
          to label %bb8.i149 unwind label %cleanup.i141

bb8.i149:                                         ; preds = %bb7.i147
  %_18.i150 = load ptr, ptr %true_val1.i135, align 8
  %_19.i151 = load ptr, ptr %false_val2.i134, align 8
  %_17.i152 = select i1 %c4, ptr %_18.i150, ptr %_19.i151, !unpredictable !415
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>, *const structs::Version>
  %_0.i191192 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEB1f_EB1i_(ptr %_17.i152) #24
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit193 unwind label %cleanup.i141

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit193: ; preds = %bb8.i149
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit154

bb15.i142:                                        ; preds = %bb12.i145, %cleanup.i141
  %28 = load i8, ptr %_21.i131, align 1
  %29 = trunc nuw i8 %28 to i1
  br i1 %29, label %bb14.i144, label %bb11.i143

bb12.i145:                                        ; preds = %cleanup.i141
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %guard.i133) #21
          to label %bb15.i142 unwind label %terminate.i146

terminate.i146:                                   ; preds = %bb12.i145
  %30 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i143:                                        ; preds = %bb14.i144, %bb15.i142
  %31 = load ptr, ptr %1, align 8
  %32 = getelementptr inbounds i8, ptr %1, i64 8
  %33 = load i32, ptr %32, align 8
  %34 = insertvalue { ptr, i32 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i32 } %34, i32 %33, 1
  resume { ptr, i32 } %35

bb14.i144:                                        ; preds = %bb15.i142
  br label %bb11.i143

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit154: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit193
  store i8 0, ptr %_20.i132, align 1
  store i8 0, ptr %_21.i107, align 1
  store i8 0, ptr %_20.i108, align 1
  store i8 1, ptr %_21.i107, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i216 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i183)
  store ptr %_2.i.i216, ptr %true_val1.i111, align 8
  store i8 0, ptr %_21.i107, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i215 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i184)
  store ptr %_2.i.i215, ptr %false_val2.i110, align 8
  %guard3.i115 = select i1 %c4, ptr %true_val1.i111, ptr %false_val2.i110, !unpredictable !415
  %drop.i116 = select i1 %c4, ptr %false_val2.i110, ptr %true_val1.i111, !unpredictable !415
  store i8 1, ptr %_20.i108, align 1
  store ptr %guard3.i115, ptr %guard.i109, align 8
  br label %bb7.i123

cleanup.i117:                                     ; preds = %bb8.i125, %bb7.i123
  %36 = landingpad { ptr, i32 }
          cleanup
  %37 = extractvalue { ptr, i32 } %36, 0
  %38 = extractvalue { ptr, i32 } %36, 1
  store ptr %37, ptr %2, align 8
  %39 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %38, ptr %39, align 8
  %40 = load i8, ptr %_20.i108, align 1
  %41 = trunc nuw i8 %40 to i1
  br i1 %41, label %bb12.i121, label %bb15.i118

bb7.i123:                                         ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit154
  store i8 0, ptr %_20.i108, align 1
  %_16.i124 = load ptr, ptr %guard.i109, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1p_(ptr %_16.i124)
          to label %bb8.i125 unwind label %cleanup.i117

bb8.i125:                                         ; preds = %bb7.i123
  %_18.i126 = load ptr, ptr %true_val1.i111, align 8
  %_19.i127 = load ptr, ptr %false_val2.i110, align 8
  %_17.i128 = select i1 %c4, ptr %_18.i126, ptr %_19.i127, !unpredictable !415
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>, *const structs::Version>
  %_0.i194195 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEB1f_EB1i_(ptr %_17.i128) #24
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit196 unwind label %cleanup.i117

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit196: ; preds = %bb8.i125
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit130

bb15.i118:                                        ; preds = %bb12.i121, %cleanup.i117
  %42 = load i8, ptr %_21.i107, align 1
  %43 = trunc nuw i8 %42 to i1
  br i1 %43, label %bb14.i120, label %bb11.i119

bb12.i121:                                        ; preds = %cleanup.i117
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %guard.i109) #21
          to label %bb15.i118 unwind label %terminate.i122

terminate.i122:                                   ; preds = %bb12.i121
  %44 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i119:                                        ; preds = %bb14.i120, %bb15.i118
  %45 = load ptr, ptr %2, align 8
  %46 = getelementptr inbounds i8, ptr %2, i64 8
  %47 = load i32, ptr %46, align 8
  %48 = insertvalue { ptr, i32 } poison, ptr %45, 0
  %49 = insertvalue { ptr, i32 } %48, i32 %47, 1
  resume { ptr, i32 } %49

bb14.i120:                                        ; preds = %bb15.i118
  br label %bb11.i119

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit130: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit196
  store i8 0, ptr %_20.i108, align 1
  store i8 0, ptr %_21.i83, align 1
  store i8 0, ptr %_20.i84, align 1
  store i8 1, ptr %_21.i83, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i218 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i185)
  store ptr %_2.i.i218, ptr %true_val1.i87, align 8
  store i8 0, ptr %_21.i83, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i217 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i194195)
  store ptr %_2.i.i217, ptr %false_val2.i86, align 8
  %guard3.i91 = select i1 %c3, ptr %true_val1.i87, ptr %false_val2.i86, !unpredictable !415
  %drop.i92 = select i1 %c3, ptr %false_val2.i86, ptr %true_val1.i87, !unpredictable !415
  store i8 1, ptr %_20.i84, align 1
  store ptr %guard3.i91, ptr %guard.i85, align 8
  br label %bb7.i99

cleanup.i93:                                      ; preds = %bb8.i101, %bb7.i99
  %50 = landingpad { ptr, i32 }
          cleanup
  %51 = extractvalue { ptr, i32 } %50, 0
  %52 = extractvalue { ptr, i32 } %50, 1
  store ptr %51, ptr %3, align 8
  %53 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %52, ptr %53, align 8
  %54 = load i8, ptr %_20.i84, align 1
  %55 = trunc nuw i8 %54 to i1
  br i1 %55, label %bb12.i97, label %bb15.i94

bb7.i99:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit130
  store i8 0, ptr %_20.i84, align 1
  %_16.i100 = load ptr, ptr %guard.i85, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1p_(ptr %_16.i100)
          to label %bb8.i101 unwind label %cleanup.i93

bb8.i101:                                         ; preds = %bb7.i99
  %_18.i102 = load ptr, ptr %true_val1.i87, align 8
  %_19.i103 = load ptr, ptr %false_val2.i86, align 8
  %_17.i104 = select i1 %c3, ptr %_18.i102, ptr %_19.i103, !unpredictable !415
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>, *const structs::Version>
  %_0.i197198 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEB1f_EB1i_(ptr %_17.i104) #24
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit199 unwind label %cleanup.i93

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit199: ; preds = %bb8.i101
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit106

bb15.i94:                                         ; preds = %bb12.i97, %cleanup.i93
  %56 = load i8, ptr %_21.i83, align 1
  %57 = trunc nuw i8 %56 to i1
  br i1 %57, label %bb14.i96, label %bb11.i95

bb12.i97:                                         ; preds = %cleanup.i93
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %guard.i85) #21
          to label %bb15.i94 unwind label %terminate.i98

terminate.i98:                                    ; preds = %bb12.i97
  %58 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i95:                                         ; preds = %bb14.i96, %bb15.i94
  %59 = load ptr, ptr %3, align 8
  %60 = getelementptr inbounds i8, ptr %3, i64 8
  %61 = load i32, ptr %60, align 8
  %62 = insertvalue { ptr, i32 } poison, ptr %59, 0
  %63 = insertvalue { ptr, i32 } %62, i32 %61, 1
  resume { ptr, i32 } %63

bb14.i96:                                         ; preds = %bb15.i94
  br label %bb11.i95

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit106: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit199
  store i8 0, ptr %_20.i84, align 1
  store i8 0, ptr %_21.i59, align 1
  store i8 0, ptr %_20.i60, align 1
  store i8 1, ptr %_21.i59, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i220 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i184)
  store ptr %_2.i.i220, ptr %true_val1.i63, align 8
  store i8 0, ptr %_21.i59, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i219 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i183)
  store ptr %_2.i.i219, ptr %false_val2.i62, align 8
  %guard3.i67 = select i1 %c3, ptr %true_val1.i63, ptr %false_val2.i62, !unpredictable !415
  %drop.i68 = select i1 %c3, ptr %false_val2.i62, ptr %true_val1.i63, !unpredictable !415
  store i8 1, ptr %_20.i60, align 1
  store ptr %guard3.i67, ptr %guard.i61, align 8
  br label %bb7.i75

cleanup.i69:                                      ; preds = %bb8.i77, %bb7.i75
  %64 = landingpad { ptr, i32 }
          cleanup
  %65 = extractvalue { ptr, i32 } %64, 0
  %66 = extractvalue { ptr, i32 } %64, 1
  store ptr %65, ptr %4, align 8
  %67 = getelementptr inbounds i8, ptr %4, i64 8
  store i32 %66, ptr %67, align 8
  %68 = load i8, ptr %_20.i60, align 1
  %69 = trunc nuw i8 %68 to i1
  br i1 %69, label %bb12.i73, label %bb15.i70

bb7.i75:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit106
  store i8 0, ptr %_20.i60, align 1
  %_16.i76 = load ptr, ptr %guard.i61, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1p_(ptr %_16.i76)
          to label %bb8.i77 unwind label %cleanup.i69

bb8.i77:                                          ; preds = %bb7.i75
  %_18.i78 = load ptr, ptr %true_val1.i63, align 8
  %_19.i79 = load ptr, ptr %false_val2.i62, align 8
  %_17.i80 = select i1 %c3, ptr %_18.i78, ptr %_19.i79, !unpredictable !415
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>, *const structs::Version>
  %_0.i200201 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEB1f_EB1i_(ptr %_17.i80) #24
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit202 unwind label %cleanup.i69

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit202: ; preds = %bb8.i77
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit82

bb15.i70:                                         ; preds = %bb12.i73, %cleanup.i69
  %70 = load i8, ptr %_21.i59, align 1
  %71 = trunc nuw i8 %70 to i1
  br i1 %71, label %bb14.i72, label %bb11.i71

bb12.i73:                                         ; preds = %cleanup.i69
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %guard.i61) #21
          to label %bb15.i70 unwind label %terminate.i74

terminate.i74:                                    ; preds = %bb12.i73
  %72 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i71:                                         ; preds = %bb14.i72, %bb15.i70
  %73 = load ptr, ptr %4, align 8
  %74 = getelementptr inbounds i8, ptr %4, i64 8
  %75 = load i32, ptr %74, align 8
  %76 = insertvalue { ptr, i32 } poison, ptr %73, 0
  %77 = insertvalue { ptr, i32 } %76, i32 %75, 1
  resume { ptr, i32 } %77

bb14.i72:                                         ; preds = %bb15.i70
  br label %bb11.i71

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit82: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit202
  store i8 0, ptr %_20.i60, align 1
  store i8 0, ptr %_21.i35, align 1
  store i8 0, ptr %_20.i36, align 1
  store i8 1, ptr %_21.i35, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i222 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i182)
  store ptr %_2.i.i222, ptr %true_val1.i39, align 8
  store i8 0, ptr %_21.i35, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i221 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i200201)
  store ptr %_2.i.i221, ptr %false_val2.i38, align 8
  %guard3.i43 = select i1 %c4, ptr %true_val1.i39, ptr %false_val2.i38, !unpredictable !415
  %drop.i44 = select i1 %c4, ptr %false_val2.i38, ptr %true_val1.i39, !unpredictable !415
  store i8 1, ptr %_20.i36, align 1
  store ptr %guard3.i43, ptr %guard.i37, align 8
  br label %bb7.i51

cleanup.i45:                                      ; preds = %bb8.i53, %bb7.i51
  %78 = landingpad { ptr, i32 }
          cleanup
  %79 = extractvalue { ptr, i32 } %78, 0
  %80 = extractvalue { ptr, i32 } %78, 1
  store ptr %79, ptr %5, align 8
  %81 = getelementptr inbounds i8, ptr %5, i64 8
  store i32 %80, ptr %81, align 8
  %82 = load i8, ptr %_20.i36, align 1
  %83 = trunc nuw i8 %82 to i1
  br i1 %83, label %bb12.i49, label %bb15.i46

bb7.i51:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit82
  store i8 0, ptr %_20.i36, align 1
  %_16.i52 = load ptr, ptr %guard.i37, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1p_(ptr %_16.i52)
          to label %bb8.i53 unwind label %cleanup.i45

bb8.i53:                                          ; preds = %bb7.i51
  %_18.i54 = load ptr, ptr %true_val1.i39, align 8
  %_19.i55 = load ptr, ptr %false_val2.i38, align 8
  %_17.i56 = select i1 %c4, ptr %_18.i54, ptr %_19.i55, !unpredictable !415
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>, *const structs::Version>
  %_0.i203204 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEB1f_EB1i_(ptr %_17.i56) #24
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit205 unwind label %cleanup.i45

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit205: ; preds = %bb8.i53
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit58

bb15.i46:                                         ; preds = %bb12.i49, %cleanup.i45
  %84 = load i8, ptr %_21.i35, align 1
  %85 = trunc nuw i8 %84 to i1
  br i1 %85, label %bb14.i48, label %bb11.i47

bb12.i49:                                         ; preds = %cleanup.i45
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %guard.i37) #21
          to label %bb15.i46 unwind label %terminate.i50

terminate.i50:                                    ; preds = %bb12.i49
  %86 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i47:                                         ; preds = %bb14.i48, %bb15.i46
  %87 = load ptr, ptr %5, align 8
  %88 = getelementptr inbounds i8, ptr %5, i64 8
  %89 = load i32, ptr %88, align 8
  %90 = insertvalue { ptr, i32 } poison, ptr %87, 0
  %91 = insertvalue { ptr, i32 } %90, i32 %89, 1
  resume { ptr, i32 } %91

bb14.i48:                                         ; preds = %bb15.i46
  br label %bb11.i47

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit58: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit205
  store i8 0, ptr %_20.i36, align 1
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %c5 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_0.i203204, ptr %_0.i197198) #24
  store i8 0, ptr %_21.i11, align 1
  store i8 0, ptr %_20.i12, align 1
  store i8 1, ptr %_21.i11, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i224 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i203204)
  store ptr %_2.i.i224, ptr %true_val1.i15, align 8
  store i8 0, ptr %_21.i11, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i223 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i197198)
  store ptr %_2.i.i223, ptr %false_val2.i14, align 8
  %guard3.i19 = select i1 %c5, ptr %true_val1.i15, ptr %false_val2.i14, !unpredictable !415
  %drop.i20 = select i1 %c5, ptr %false_val2.i14, ptr %true_val1.i15, !unpredictable !415
  store i8 1, ptr %_20.i12, align 1
  store ptr %guard3.i19, ptr %guard.i13, align 8
  br label %bb7.i27

cleanup.i21:                                      ; preds = %bb8.i29, %bb7.i27
  %92 = landingpad { ptr, i32 }
          cleanup
  %93 = extractvalue { ptr, i32 } %92, 0
  %94 = extractvalue { ptr, i32 } %92, 1
  store ptr %93, ptr %6, align 8
  %95 = getelementptr inbounds i8, ptr %6, i64 8
  store i32 %94, ptr %95, align 8
  %96 = load i8, ptr %_20.i12, align 1
  %97 = trunc nuw i8 %96 to i1
  br i1 %97, label %bb12.i25, label %bb15.i22

bb7.i27:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit58
  store i8 0, ptr %_20.i12, align 1
  %_16.i28 = load ptr, ptr %guard.i13, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1p_(ptr %_16.i28)
          to label %bb8.i29 unwind label %cleanup.i21

bb8.i29:                                          ; preds = %bb7.i27
  %_18.i30 = load ptr, ptr %true_val1.i15, align 8
  %_19.i31 = load ptr, ptr %false_val2.i14, align 8
  %_17.i32 = select i1 %c5, ptr %_18.i30, ptr %_19.i31, !unpredictable !415
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>, *const structs::Version>
  %_0.i206207 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEB1f_EB1i_(ptr %_17.i32) #24
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit208 unwind label %cleanup.i21

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit208: ; preds = %bb8.i29
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit34

bb15.i22:                                         ; preds = %bb12.i25, %cleanup.i21
  %98 = load i8, ptr %_21.i11, align 1
  %99 = trunc nuw i8 %98 to i1
  br i1 %99, label %bb14.i24, label %bb11.i23

bb12.i25:                                         ; preds = %cleanup.i21
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %guard.i13) #21
          to label %bb15.i22 unwind label %terminate.i26

terminate.i26:                                    ; preds = %bb12.i25
  %100 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i23:                                         ; preds = %bb14.i24, %bb15.i22
  %101 = load ptr, ptr %6, align 8
  %102 = getelementptr inbounds i8, ptr %6, i64 8
  %103 = load i32, ptr %102, align 8
  %104 = insertvalue { ptr, i32 } poison, ptr %101, 0
  %105 = insertvalue { ptr, i32 } %104, i32 %103, 1
  resume { ptr, i32 } %105

bb14.i24:                                         ; preds = %bb15.i22
  br label %bb11.i23

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit34: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit208
  store i8 0, ptr %_20.i12, align 1
  store i8 0, ptr %_21.i, align 1
  store i8 0, ptr %_20.i, align 1
  store i8 1, ptr %_21.i, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i226 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i197198)
  store ptr %_2.i.i226, ptr %true_val1.i, align 8
  store i8 0, ptr %_21.i, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
  %_2.i.i225 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %_0.i203204)
  store ptr %_2.i.i225, ptr %false_val2.i, align 8
  %guard3.i = select i1 %c5, ptr %true_val1.i, ptr %false_val2.i, !unpredictable !415
  %drop.i = select i1 %c5, ptr %false_val2.i, ptr %true_val1.i, !unpredictable !415
  store i8 1, ptr %_20.i, align 1
  store ptr %guard3.i, ptr %guard.i, align 8
  br label %bb7.i

cleanup.i:                                        ; preds = %bb8.i, %bb7.i
  %106 = landingpad { ptr, i32 }
          cleanup
  %107 = extractvalue { ptr, i32 } %106, 0
  %108 = extractvalue { ptr, i32 } %106, 1
  store ptr %107, ptr %7, align 8
  %109 = getelementptr inbounds i8, ptr %7, i64 8
  store i32 %108, ptr %109, align 8
  %110 = load i8, ptr %_20.i, align 1
  %111 = trunc nuw i8 %110 to i1
  br i1 %111, label %bb12.i, label %bb15.i

bb7.i:                                            ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit34
  store i8 0, ptr %_20.i, align 1
  %_16.i = load ptr, ptr %guard.i, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1p_(ptr %_16.i)
          to label %bb8.i unwind label %cleanup.i

bb8.i:                                            ; preds = %bb7.i
  %_18.i = load ptr, ptr %true_val1.i, align 8
  %_19.i = load ptr, ptr %false_val2.i, align 8
  %_17.i = select i1 %c5, ptr %_18.i, ptr %_19.i, !unpredictable !415
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const structs::Version>, *const structs::Version>
  %_0.i209210 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPNtCs31EPG3twprw_7structs7VersionEB1f_EB1i_(ptr %_17.i) #24
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit211 unwind label %cleanup.i

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit211: ; preds = %bb8.i
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit

bb15.i:                                           ; preds = %bb12.i, %cleanup.i
  %112 = load i8, ptr %_21.i, align 1
  %113 = trunc nuw i8 %112 to i1
  br i1 %113, label %bb14.i, label %bb11.i

bb12.i:                                           ; preds = %cleanup.i
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %guard.i) #21
          to label %bb15.i unwind label %terminate.i

terminate.i:                                      ; preds = %bb12.i
  %114 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i:                                           ; preds = %bb14.i, %bb15.i
  %115 = load ptr, ptr %7, align 8
  %116 = getelementptr inbounds i8, ptr %7, i64 8
  %117 = load i32, ptr %116, align 8
  %118 = insertvalue { ptr, i32 } poison, ptr %115, 0
  %119 = insertvalue { ptr, i32 } %118, i32 %117, 1
  resume { ptr, i32 } %119

bb14.i:                                           ; preds = %bb15.i
  br label %bb11.i

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPNtCs31EPG3twprw_7structs7VersionE11assume_initB16_.exit211
  store i8 0, ptr %_20.i, align 1
; call core::ub_checks::check_language_ub
  %_4.i7 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i7, label %bb2.i8, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit9

bb2.i8:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i189190, ptr %dst, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit9

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit9: ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePNtCs31EPG3twprw_7structs7VersionEBR_.exit, %bb2.i8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %dst, ptr align 1 %_0.i189190, i64 3, i1 false)
  %_0.i181 = getelementptr inbounds nuw %Version, ptr %dst, i64 1
; call core::ub_checks::check_language_ub
  %_4.i4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i4, label %bb2.i5, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit6

bb2.i5:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit9
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i206207, ptr %_0.i181, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit6

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit6: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit9, %bb2.i5
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i181, ptr align 1 %_0.i206207, i64 3, i1 false)
  %_0.i180 = getelementptr inbounds nuw %Version, ptr %dst, i64 2
; call core::ub_checks::check_language_ub
  %_4.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i1, label %bb2.i2, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit3

bb2.i2:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit6
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i209210, ptr %_0.i180, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit3

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit3: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit6, %bb2.i2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i180, ptr align 1 %_0.i209210, i64 3, i1 false)
  %_0.i179 = getelementptr inbounds nuw %Version, ptr %dst, i64 3
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit3
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i191192, ptr %_0.i179, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit3, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i179, ptr align 1 %_0.i191192, i64 3, i1 false)
  ret void
}

; core::slice::sort::shared::smallsort::sort8_stable::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort8_stableNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %v_base, ptr %dst, ptr %scratch_base, ptr %is_less) unnamed_addr #1 !guid !416 {
start:
; call core::slice::sort::shared::smallsort::sort4_stable::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stableNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %v_base, ptr %scratch_base, ptr %is_less)
  %_0.i1 = getelementptr inbounds nuw %Version, ptr %v_base, i64 4
  %_0.i = getelementptr inbounds nuw %Version, ptr %scratch_base, i64 4
; call core::slice::sort::shared::smallsort::sort4_stable::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stableNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %_0.i1, ptr %_0.i, ptr %is_less)
; call core::slice::raw::from_raw_parts::<structs::Version>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partsNtCs31EPG3twprw_7structs7VersionEBR_(ptr %scratch_base, i64 8, ptr align 8 @alloc_0ab1672cf9b06a39e5138e5643964c99) #24
  %_12.0 = extractvalue { ptr, i64 } %0, 0
  %_12.1 = extractvalue { ptr, i64 } %0, 1
; call core::slice::sort::shared::smallsort::bidirectional_merge::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort19bidirectional_mergeNtCs31EPG3twprw_7structs7VersionNvYB1g_NtNtBa_3cmp10PartialOrd2ltEB1i_(ptr %_12.0, i64 %_12.1, ptr %dst, ptr %is_less)
  ret void
}

; core::slice::sort::shared::smallsort::bidirectional_merge::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort19bidirectional_mergeNtCs31EPG3twprw_7structs7VersionNvYB1g_NtNtBa_3cmp10PartialOrd2ltEB1i_(ptr %v.0, i64 %v.1, ptr %dst, ptr %is_less) unnamed_addr #1 !guid !417 {
start:
  %_0.i30 = alloca [8 x i8], align 8
  %src.i3 = alloca [8 x i8], align 8
  %dst.i4 = alloca [8 x i8], align 8
  %right_src.i5 = alloca [8 x i8], align 8
  %left_src.i6 = alloca [8 x i8], align 8
  %src.i = alloca [8 x i8], align 8
  %dst.i = alloca [8 x i8], align 8
  %right_src.i = alloca [8 x i8], align 8
  %left_src.i = alloca [8 x i8], align 8
  %last_src = alloca [8 x i8], align 8
  %_35 = alloca [24 x i8], align 8
  %_28 = alloca [24 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %dst_rev = alloca [8 x i8], align 8
  %right_rev = alloca [8 x i8], align 8
  %left_rev = alloca [8 x i8], align 8
  %dst1 = alloca [8 x i8], align 8
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  %len_div_2 = udiv i64 %v.1, 2
  %_8 = icmp ne i64 %len_div_2, 0
  store ptr %v.0, ptr %left, align 8
  %_0.i48 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %len_div_2
  store ptr %_0.i48, ptr %right, align 8
  store ptr %dst, ptr %dst1, align 8
  %_13 = sub i64 %len_div_2, 1
  %_0.i47 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_13
  store ptr %_0.i47, ptr %left_rev, align 8
  %_15 = sub i64 %v.1, 1
  %_0.i46 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_15
  store ptr %_0.i46, ptr %right_rev, align 8
  %_17 = load ptr, ptr %dst1, align 8
  %_18 = sub i64 %v.1, 1
  %_0.i29 = getelementptr inbounds nuw %Version, ptr %_17, i64 %_18
  store ptr %_0.i29, ptr %dst_rev, align 8
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %len_div_2) #24
  %_19.0 = extractvalue { i64, i64 } %0, 0
  %_19.1 = extractvalue { i64, i64 } %0, 1
  store i64 %_19.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_19.1, ptr %1, align 8
  br label %bb8

bb8:                                              ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBa_3cmp10PartialOrd2ltEB19_.exit, %start
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %2 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #24
  %_22.0 = extractvalue { i64, i64 } %2, 0
  %_22.1 = extractvalue { i64, i64 } %2, 1
  %3 = trunc nuw i64 %_22.0 to i1
  br i1 %3, label %bb11, label %bb12

bb11:                                             ; preds = %bb8
  %_29 = load ptr, ptr %left, align 8
  %_30 = load ptr, ptr %right, align 8
  %_31 = load ptr, ptr %dst1, align 8
  store ptr %_29, ptr %left_src.i6, align 8
  store ptr %_30, ptr %right_src.i5, align 8
  store ptr %_31, ptr %dst.i4, align 8
  %_8.i7 = load ptr, ptr %right_src.i5, align 8
  %_9.i8 = load ptr, ptr %left_src.i6, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_6.i9 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_8.i7, ptr %_9.i8) #24
  %is_l.i10 = xor i1 %_6.i9, true
  br i1 %is_l.i10, label %bb2.i28, label %bb3.i11

bb3.i11:                                          ; preds = %bb11
  %4 = load ptr, ptr %right_src.i5, align 8
  store ptr %4, ptr %src.i3, align 8
  br label %bb4.i12

bb2.i28:                                          ; preds = %bb11
  %5 = load ptr, ptr %left_src.i6, align 8
  store ptr %5, ptr %src.i3, align 8
  br label %bb4.i12

bb4.i12:                                          ; preds = %bb2.i28, %bb3.i11
  %_12.i13 = load ptr, ptr %src.i3, align 8
  %_13.i14 = load ptr, ptr %dst.i4, align 8
; call core::ub_checks::check_language_ub
  %_4.i.i15 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i.i15, label %bb2.i.i27, label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_upNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_.exit

bb2.i.i27:                                        ; preds = %bb4.i12
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_12.i13, ptr %_13.i14, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_upNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_upNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_.exit: ; preds = %bb4.i12, %bb2.i.i27
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_13.i14, ptr align 1 %_12.i13, i64 3, i1 false)
  %_15.i16 = load ptr, ptr %right_src.i5, align 8
  %_16.i18 = zext i1 %_6.i9 to i64
  %_0.i43 = getelementptr inbounds nuw %Version, ptr %_15.i16, i64 %_16.i18
  store ptr %_0.i43, ptr %right_src.i5, align 8
  %_19.i20 = load ptr, ptr %left_src.i6, align 8
  %_20.i = zext i1 %is_l.i10 to i64
  %_0.i42 = getelementptr inbounds nuw %Version, ptr %_19.i20, i64 %_20.i
  store ptr %_0.i42, ptr %left_src.i6, align 8
  %_22.i22 = load ptr, ptr %dst.i4, align 8
  %_0.i = getelementptr inbounds nuw %Version, ptr %_22.i22, i64 1
  store ptr %_0.i, ptr %dst.i4, align 8
  %_23.i24 = load ptr, ptr %left_src.i6, align 8
  %_24.i25 = load ptr, ptr %right_src.i5, align 8
  %_25.i26 = load ptr, ptr %dst.i4, align 8
  store ptr %_23.i24, ptr %_28, align 8
  %6 = getelementptr inbounds i8, ptr %_28, i64 8
  store ptr %_24.i25, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_28, i64 16
  store ptr %_25.i26, ptr %7, align 8
  %_25 = load ptr, ptr %_28, align 8
  %8 = getelementptr inbounds i8, ptr %_28, i64 8
  %_26 = load ptr, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %_28, i64 16
  %_27 = load ptr, ptr %9, align 8
  store ptr %_25, ptr %left, align 8
  store ptr %_26, ptr %right, align 8
  store ptr %_27, ptr %dst1, align 8
  %_36 = load ptr, ptr %left_rev, align 8
  %_37 = load ptr, ptr %right_rev, align 8
  %_38 = load ptr, ptr %dst_rev, align 8
  store ptr %_36, ptr %left_src.i, align 8
  store ptr %_37, ptr %right_src.i, align 8
  store ptr %_38, ptr %dst.i, align 8
  %_8.i = load ptr, ptr %right_src.i, align 8
  %_9.i = load ptr, ptr %left_src.i, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_6.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_8.i, ptr %_9.i) #24
  %is_l.i = xor i1 %_6.i, true
  br i1 %is_l.i, label %bb2.i2, label %bb3.i

bb3.i:                                            ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_upNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_.exit
  %10 = load ptr, ptr %left_src.i, align 8
  store ptr %10, ptr %src.i, align 8
  br label %bb4.i

bb2.i2:                                           ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_upNtCs31EPG3twprw_7structs7VersionNvYB14_NtNtBa_3cmp10PartialOrd2ltEB16_.exit
  %11 = load ptr, ptr %right_src.i, align 8
  store ptr %11, ptr %src.i, align 8
  br label %bb4.i

bb4.i:                                            ; preds = %bb2.i2, %bb3.i
  %_12.i = load ptr, ptr %src.i, align 8
  %_13.i = load ptr, ptr %dst.i, align 8
; call core::ub_checks::check_language_ub
  %_4.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i.i, label %bb2.i.i, label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBa_3cmp10PartialOrd2ltEB19_.exit

bb2.i.i:                                          ; preds = %bb4.i
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_12.i, ptr %_13.i, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBa_3cmp10PartialOrd2ltEB19_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBa_3cmp10PartialOrd2ltEB19_.exit: ; preds = %bb4.i, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_13.i, ptr align 1 %_12.i, i64 3, i1 false)
  %_15.i = load ptr, ptr %right_src.i, align 8
  %_16.i = zext i1 %is_l.i to i64
  %_0.i52 = sub i64 0, %_16.i
  %_0.i38 = getelementptr %Version, ptr %_15.i, i64 %_0.i52
  store ptr %_0.i38, ptr %right_src.i, align 8
  %_18.i = load ptr, ptr %left_src.i, align 8
  %_19.i = zext i1 %_6.i to i64
  %_0.i51 = sub i64 0, %_19.i
  %_0.i39 = getelementptr %Version, ptr %_18.i, i64 %_0.i51
  store ptr %_0.i39, ptr %left_src.i, align 8
  %_22.i = load ptr, ptr %dst.i, align 8
  %12 = getelementptr inbounds %Version, ptr %_22.i, i64 -1
  store ptr %12, ptr %_0.i30, align 8
  %13 = load ptr, ptr %_0.i30, align 8
  store ptr %13, ptr %dst.i, align 8
  %_23.i = load ptr, ptr %left_src.i, align 8
  %_24.i = load ptr, ptr %right_src.i, align 8
  %_25.i = load ptr, ptr %dst.i, align 8
  store ptr %_23.i, ptr %_35, align 8
  %14 = getelementptr inbounds i8, ptr %_35, i64 8
  store ptr %_24.i, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %_35, i64 16
  store ptr %_25.i, ptr %15, align 8
  %_32 = load ptr, ptr %_35, align 8
  %16 = getelementptr inbounds i8, ptr %_35, i64 8
  %_33 = load ptr, ptr %16, align 8
  %17 = getelementptr inbounds i8, ptr %_35, i64 16
  %_34 = load ptr, ptr %17, align 8
  store ptr %_32, ptr %left_rev, align 8
  store ptr %_33, ptr %right_rev, align 8
  store ptr %_34, ptr %dst_rev, align 8
  br label %bb8

bb12:                                             ; preds = %bb8
  %_40 = load ptr, ptr %left_rev, align 8
  %_0.i40 = getelementptr %Version, ptr %_40, i64 1
  %_42 = load ptr, ptr %right_rev, align 8
  %_0.i41 = getelementptr %Version, ptr %_42, i64 1
; call <usize>::is_multiple_of
  %_43 = call zeroext i1 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj14is_multiple_ofCs31EPG3twprw_7structs(i64 %v.1, i64 2) #24
  br i1 %_43, label %bb25, label %bb18

bb18:                                             ; preds = %bb12
  %_45 = load ptr, ptr %left, align 8
  %left_nonempty = icmp ult ptr %_45, %_0.i40
  br i1 %left_nonempty, label %bb19, label %bb20

bb25:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit, %bb12
  %_58 = load ptr, ptr %left, align 8
  %_57 = icmp ne ptr %_58, %_0.i40
  br i1 %_57, label %bb27, label %bb26

bb20:                                             ; preds = %bb18
  %18 = load ptr, ptr %right, align 8
  store ptr %18, ptr %last_src, align 8
  br label %bb21

bb19:                                             ; preds = %bb18
  %19 = load ptr, ptr %left, align 8
  store ptr %19, ptr %last_src, align 8
  br label %bb21

bb21:                                             ; preds = %bb19, %bb20
  %_48 = load ptr, ptr %last_src, align 8
  %_49 = load ptr, ptr %dst1, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %bb21
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_48, ptr %_49, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %bb21, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_49, ptr align 1 %_48, i64 3, i1 false)
  %_51 = load ptr, ptr %left, align 8
  %_52 = zext i1 %left_nonempty to i64
  %_0.i45 = getelementptr inbounds nuw %Version, ptr %_51, i64 %_52
  store ptr %_0.i45, ptr %left, align 8
  %_54 = load ptr, ptr %right, align 8
  %_56 = xor i1 %left_nonempty, true
  %_55 = zext i1 %_56 to i64
  %_0.i44 = getelementptr inbounds nuw %Version, ptr %_54, i64 %_55
  store ptr %_0.i44, ptr %right, align 8
  br label %bb25

bb26:                                             ; preds = %bb25
  %_60 = load ptr, ptr %right, align 8
  %_59 = icmp ne ptr %_60, %_0.i41
  br i1 %_59, label %bb27, label %bb28

bb27:                                             ; preds = %bb26, %bb25
; call core::slice::sort::shared::smallsort::panic_on_ord_violation
  call void @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort22panic_on_ord_violation() #26
  unreachable

bb28:                                             ; preds = %bb26
  ret void

bb10:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::shared::smallsort::insertion_sort_shift_left::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtCs31EPG3twprw_7structs7VersionNvYB1m_NtNtBa_3cmp10PartialOrd2ltEB1o_(ptr %v.0, i64 %v.1, i64 %offset, ptr %is_less) unnamed_addr #1 !guid !418 {
start:
  %tail = alloca [8 x i8], align 8
  %_6 = icmp eq i64 %offset, 0
  br i1 %_6, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_7 = icmp ugt i64 %offset, %v.1
  br i1 %_7, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
  call void @llvm.trap()
  unreachable

bb3:                                              ; preds = %bb1
  %_0.i2 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %v.1
  %_0.i1 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %offset
  store ptr %_0.i1, ptr %tail, align 8
  br label %bb6

bb6:                                              ; preds = %bb7, %bb3
  %_13 = load ptr, ptr %tail, align 8
  %_12 = icmp ne ptr %_13, %_0.i2
  br i1 %_12, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  ret void

bb7:                                              ; preds = %bb6
  %_15 = load ptr, ptr %tail, align 8
; call core::slice::sort::shared::smallsort::insert_tail::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort11insert_tailNtCs31EPG3twprw_7structs7VersionNvYB18_NtNtBa_3cmp10PartialOrd2ltEB1a_(ptr %v.0, ptr %_15, ptr %is_less)
  %_17 = load ptr, ptr %tail, align 8
  %_0.i = getelementptr inbounds nuw %Version, ptr %_17, i64 1
  store ptr %_0.i, ptr %tail, align 8
  br label %bb6
}

; core::slice::sort::shared::smallsort::small_sort_general_with_scratch::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchNtCs31EPG3twprw_7structs7VersionNvYB1s_NtNtBa_3cmp10PartialOrd2ltEB1u_(ptr %v.0, i64 %v.1, ptr %scratch.0, i64 %scratch.1, ptr %is_less) unnamed_addr #1 personality ptr @rust_eh_personality !guid !419 {
start:
  %0 = alloca [16 x i8], align 8
  %_74 = alloca [1 x i8], align 1
  %_73 = alloca [24 x i8], align 8
  %drop_guard = alloca [24 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %iter1 = alloca [16 x i8], align 8
  %desired_len = alloca [8 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %iter = alloca [32 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_39 = alloca [32 x i8], align 8
  %presorted_len = alloca [8 x i8], align 8
  store i8 0, ptr %_74, align 1
  %_6 = icmp ult i64 %v.1, 2
  br i1 %_6, label %bb50, label %bb1

bb1:                                              ; preds = %start
  %_10 = add i64 %v.1, 16
  %_7 = icmp ult i64 %scratch.1, %_10
  br i1 %_7, label %bb2, label %bb3

bb50:                                             ; preds = %bb49, %start
  ret void

bb3:                                              ; preds = %bb1
  %len_div_2 = udiv i64 %v.1, 2
  br label %bb7

bb2:                                              ; preds = %bb1
  call void @llvm.trap()
  unreachable

bb7:                                              ; preds = %bb3
  %_18 = icmp uge i64 %v.1, 16
  br i1 %_18, label %bb8, label %bb15

bb15:                                             ; preds = %bb7
  %_26 = icmp uge i64 %v.1, 8
  br i1 %_26, label %bb16, label %bb21

bb8:                                              ; preds = %bb7
  %_0.i16 = getelementptr inbounds nuw %Version, ptr %scratch.0, i64 %v.1
; call core::slice::sort::shared::smallsort::sort8_stable::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort8_stableNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %v.0, ptr %scratch.0, ptr %_0.i16, ptr %is_less)
  %_0.i15 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %len_div_2
  %_0.i14 = getelementptr inbounds nuw %Version, ptr %scratch.0, i64 %len_div_2
  %_25 = add i64 %v.1, 8
  %_0.i13 = getelementptr inbounds nuw %Version, ptr %scratch.0, i64 %_25
; call core::slice::sort::shared::smallsort::sort8_stable::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort8_stableNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %_0.i15, ptr %_0.i14, ptr %_0.i13, ptr %is_less)
  store i64 8, ptr %presorted_len, align 8
  br label %bb26

bb21:                                             ; preds = %bb15
; call core::ub_checks::check_language_ub
  %_4.i6 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i6, label %bb2.i7, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit8

bb2.i7:                                           ; preds = %bb21
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %v.0, ptr %scratch.0, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit8

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit8: ; preds = %bb21, %bb2.i7
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %scratch.0, ptr align 1 %v.0, i64 3, i1 false)
  %_0.i20 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %len_div_2
  %_0.i19 = getelementptr inbounds nuw %Version, ptr %scratch.0, i64 %len_div_2
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i4, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit5

bb2.i4:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit8
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i20, ptr %_0.i19, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit5

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit5: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit8, %bb2.i4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i19, ptr align 1 %_0.i20, i64 3, i1 false)
  store i64 1, ptr %presorted_len, align 8
  br label %bb26

bb16:                                             ; preds = %bb15
; call core::slice::sort::shared::smallsort::sort4_stable::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stableNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %v.0, ptr %scratch.0, ptr %is_less)
  %_0.i18 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %len_div_2
  %_0.i17 = getelementptr inbounds nuw %Version, ptr %scratch.0, i64 %len_div_2
; call core::slice::sort::shared::smallsort::sort4_stable::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stableNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %_0.i18, ptr %_0.i17, ptr %is_less)
  store i64 4, ptr %presorted_len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8, %bb16, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit5
  %1 = getelementptr inbounds nuw i64, ptr %_40, i64 0
  store i64 0, ptr %1, align 8
  %2 = getelementptr inbounds nuw i64, ptr %_40, i64 1
  store i64 %len_div_2, ptr %2, align 8
; call <[usize; 2] as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAjj2_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCshGsV4pNJ6ra_6object(ptr sret([32 x i8]) align 8 %_39, ptr align 8 %_40) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter, ptr align 8 %_39, i64 32, i1 false)
  br label %bb28

bb28:                                             ; preds = %bb40, %bb26
; invoke <core::array::iter::IntoIter<usize, 2> as core::iter::traits::iterator::Iterator>::next
  %3 = invoke { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterjKj2_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCshGsV4pNJ6ra_6object(ptr align 8 %iter)
          to label %bb29 unwind label %cleanup

bb51:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<usize, 2>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterjKj2_EECshGsV4pNJ6ra_6object(ptr align 8 %iter) #21
          to label %bb52 unwind label %terminate

cleanup:                                          ; preds = %bb43, %bb45, %bb39, %bb37, %bb28
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb51

bb29:                                             ; preds = %bb28
  %8 = extractvalue { i64, i64 } %3, 0
  %9 = extractvalue { i64, i64 } %3, 1
  store i64 %8, ptr %_42, align 8
  %10 = getelementptr inbounds i8, ptr %_42, i64 8
  store i64 %9, ptr %10, align 8
  %_44 = load i64, ptr %_42, align 8
  %11 = getelementptr inbounds i8, ptr %_42, i64 8
  %12 = load i64, ptr %11, align 8
  %13 = trunc nuw i64 %_44 to i1
  br i1 %13, label %bb31, label %bb32

bb31:                                             ; preds = %bb29
  %14 = getelementptr inbounds i8, ptr %_42, i64 8
  %offset = load i64, ptr %14, align 8
  %_0.i12 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %offset
  br label %bb33

bb32:                                             ; preds = %bb29
; call core::ptr::drop_glue::<core::array::iter::IntoIter<usize, 2>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterjKj2_EECshGsV4pNJ6ra_6object(ptr align 8 %iter)
  store i8 1, ptr %_74, align 1
  store ptr %scratch.0, ptr %drop_guard, align 8
  %15 = getelementptr inbounds i8, ptr %drop_guard, i64 8
  store ptr %v.0, ptr %15, align 8
  %16 = getelementptr inbounds i8, ptr %drop_guard, i64 16
  store i64 %v.1, ptr %16, align 8
  %_69 = load ptr, ptr %drop_guard, align 8
  %17 = getelementptr inbounds i8, ptr %drop_guard, i64 16
  %_70 = load i64, ptr %17, align 8
; invoke core::slice::raw::from_raw_parts::<structs::Version>
  %18 = invoke { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partsNtCs31EPG3twprw_7structs7VersionEBR_(ptr %_69, i64 %_70, ptr align 8 @alloc_dea82b1a5cc143169db7b7d27413b6f6)
          to label %bb47 unwind label %cleanup2

bb54:                                             ; preds = %cleanup2
  %19 = load i8, ptr %_74, align 1
  %20 = trunc nuw i8 %19 to i1
  br i1 %20, label %bb53, label %bb52

cleanup2:                                         ; preds = %bb48, %bb47, %bb32
  %21 = landingpad { ptr, i32 }
          cleanup
  %22 = extractvalue { ptr, i32 } %21, 0
  %23 = extractvalue { ptr, i32 } %21, 1
  store ptr %22, ptr %0, align 8
  %24 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %23, ptr %24, align 8
  br label %bb54

bb47:                                             ; preds = %bb32
  %_68.0 = extractvalue { ptr, i64 } %18, 0
  %_68.1 = extractvalue { ptr, i64 } %18, 1
  %25 = getelementptr inbounds i8, ptr %drop_guard, i64 8
  %_71 = load ptr, ptr %25, align 8
; invoke core::slice::sort::shared::smallsort::bidirectional_merge::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  invoke void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort19bidirectional_mergeNtCs31EPG3twprw_7structs7VersionNvYB1g_NtNtBa_3cmp10PartialOrd2ltEB1i_(ptr %_68.0, i64 %_68.1, ptr %_71, ptr %is_less)
          to label %bb48 unwind label %cleanup2

bb48:                                             ; preds = %bb47
  store i8 0, ptr %_74, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_73, ptr align 8 %drop_guard, i64 24, i1 false)
; invoke core::mem::forget::<core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDropNtCs31EPG3twprw_7structs7VersionEEB1s_(ptr align 8 %_73)
          to label %bb49 unwind label %cleanup2

bb49:                                             ; preds = %bb48
  store i8 0, ptr %_74, align 1
  br label %bb50

bb52:                                             ; preds = %bb51, %bb53, %bb54
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr inbounds i8, ptr %0, i64 8
  %28 = load i32, ptr %27, align 8
  %29 = insertvalue { ptr, i32 } poison, ptr %26, 0
  %30 = insertvalue { ptr, i32 } %29, i32 %28, 1
  resume { ptr, i32 } %30

bb53:                                             ; preds = %bb54
; invoke core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDropNtCs31EPG3twprw_7structs7VersionEEB1v_(ptr align 8 %drop_guard) #21
          to label %bb52 unwind label %terminate

terminate:                                        ; preds = %bb51, %bb53
  %31 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb33:                                             ; preds = %bb31
  %_0.i11 = getelementptr inbounds nuw %Version, ptr %scratch.0, i64 %offset
  br label %bb34

bb34:                                             ; preds = %bb33
  %_49 = icmp eq i64 %offset, 0
  br i1 %_49, label %bb35, label %bb36

bb36:                                             ; preds = %bb34
  %32 = sub i64 %v.1, %len_div_2
  store i64 %32, ptr %desired_len, align 8
  br label %bb37

bb35:                                             ; preds = %bb34
  store i64 %len_div_2, ptr %desired_len, align 8
  br label %bb37

bb37:                                             ; preds = %bb35, %bb36
  %_52 = load i64, ptr %presorted_len, align 8
  %_53 = load i64, ptr %desired_len, align 8
; invoke <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %33 = invoke { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 %_52, i64 %_53)
          to label %bb38 unwind label %cleanup

bb38:                                             ; preds = %bb37
  %_50.0 = extractvalue { i64, i64 } %33, 0
  %_50.1 = extractvalue { i64, i64 } %33, 1
  store i64 %_50.0, ptr %iter1, align 8
  %34 = getelementptr inbounds i8, ptr %iter1, i64 8
  store i64 %_50.1, ptr %34, align 8
  br label %bb39

bb39:                                             ; preds = %bb55, %bb38
; invoke <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %35 = invoke { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter1)
          to label %bb40 unwind label %cleanup

bb40:                                             ; preds = %bb39
  %36 = extractvalue { i64, i64 } %35, 0
  %37 = extractvalue { i64, i64 } %35, 1
  store i64 %36, ptr %_55, align 8
  %38 = getelementptr inbounds i8, ptr %_55, i64 8
  store i64 %37, ptr %38, align 8
  %_57 = load i64, ptr %_55, align 8
  %39 = getelementptr inbounds i8, ptr %_55, i64 8
  %40 = load i64, ptr %39, align 8
  %41 = trunc nuw i64 %_57 to i1
  br i1 %41, label %bb41, label %bb28

bb41:                                             ; preds = %bb40
  %42 = getelementptr inbounds i8, ptr %_55, i64 8
  %i = load i64, ptr %42, align 8
  %_0.i10 = getelementptr inbounds nuw %Version, ptr %_0.i12, i64 %i
  br label %bb42

bb42:                                             ; preds = %bb41
  %_0.i9 = getelementptr inbounds nuw %Version, ptr %_0.i11, i64 %i
  br label %bb43

bb43:                                             ; preds = %bb42
; invoke core::ub_checks::check_language_ub
  %_4.i3 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
          to label %_4.i.noexc unwind label %cleanup

_4.i.noexc:                                       ; preds = %bb43
  br i1 %_4.i3, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %_4.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i10, ptr %_0.i9, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %_4.i.noexc, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i9, ptr align 1 %_0.i10, i64 3, i1 false)
  br label %bb44

bb44:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit
  %_0.i = getelementptr inbounds nuw %Version, ptr %_0.i11, i64 %i
  br label %bb45

bb45:                                             ; preds = %bb44
; invoke core::slice::sort::shared::smallsort::insert_tail::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  invoke void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort11insert_tailNtCs31EPG3twprw_7structs7VersionNvYB18_NtNtBa_3cmp10PartialOrd2ltEB1a_(ptr %_0.i11, ptr %_0.i, ptr %is_less)
          to label %bb55 unwind label %cleanup

bb55:                                             ; preds = %bb45
  br label %bb39

bb30:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::stable::drift::create_run::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift10create_runNtCs31EPG3twprw_7structs7VersionNvYB13_NtNtBa_3cmp10PartialOrd2ltEB15_(ptr %v.0, i64 %v.1, ptr %scratch.0, i64 %scratch.1, i64 %min_good_run_len, i1 zeroext %eager_sort, ptr %is_less) unnamed_addr #1 !guid !420 {
start:
  %run_len.i = alloca [8 x i8], align 8
  %_0.i = alloca [16 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %_8 = icmp uge i64 %v.1, %min_good_run_len
  br i1 %_8, label %bb1, label %bb7

bb7:                                              ; preds = %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runNtCs31EPG3twprw_7structs7VersionNvYB12_NtNtB8_3cmp10PartialOrd2ltEB14_.exit, %start
  br i1 %eager_sort, label %bb8, label %bb13

bb1:                                              ; preds = %start
  %_4.i = icmp ult i64 %v.1, 2
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb1
  store i64 2, ptr %run_len.i, align 8
; call <[structs::Version]>::get_unchecked::<usize>
  %_8.i = call ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version13get_uncheckedjEBx_(ptr %v.0, i64 %v.1, i64 1, ptr align 8 @alloc_b1a59a7585543a4a25115f0cbf40f484) #24
; call <[structs::Version]>::get_unchecked::<usize>
  %_9.i = call ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version13get_uncheckedjEBx_(ptr %v.0, i64 %v.1, i64 0, ptr align 8 @alloc_4e95ed00d8479deaf9b8943b85759bde) #24
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %strictly_descending.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_8.i, ptr %_9.i) #24
  br i1 %strictly_descending.i, label %bb6.i, label %bb12.i

bb1.i:                                            ; preds = %bb1
  store i64 %v.1, ptr %_0.i, align 8
  %0 = getelementptr inbounds i8, ptr %_0.i, i64 8
  store i8 0, ptr %0, align 8
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runNtCs31EPG3twprw_7structs7VersionNvYB12_NtNtB8_3cmp10PartialOrd2ltEB14_.exit

bb12.i:                                           ; preds = %bb17.i, %bb2.i
  %_20.i = load i64, ptr %run_len.i, align 8
  %_19.i = icmp ult i64 %_20.i, %v.1
  br i1 %_19.i, label %bb13.i, label %bb18.i

bb6.i:                                            ; preds = %bb11.i, %bb2.i
  %_11.i = load i64, ptr %run_len.i, align 8
  %_10.i = icmp ult i64 %_11.i, %v.1
  br i1 %_10.i, label %bb7.i, label %bb18.i

bb18.i:                                           ; preds = %bb7.i, %bb13.i, %bb6.i, %bb12.i
  %_28.i = load i64, ptr %run_len.i, align 8
  store i64 %_28.i, ptr %_0.i, align 8
  %1 = getelementptr inbounds i8, ptr %_0.i, i64 8
  %2 = zext i1 %strictly_descending.i to i8
  store i8 %2, ptr %1, align 8
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runNtCs31EPG3twprw_7structs7VersionNvYB12_NtNtB8_3cmp10PartialOrd2ltEB14_.exit

bb13.i:                                           ; preds = %bb12.i
  %_24.i = load i64, ptr %run_len.i, align 8
; call <[structs::Version]>::get_unchecked::<usize>
  %_23.i = call ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version13get_uncheckedjEBx_(ptr %v.0, i64 %v.1, i64 %_24.i, ptr align 8 @alloc_0aa54d60960e578bf5dc3db64f9182b2) #24
  %_27.i = load i64, ptr %run_len.i, align 8
  %_26.i = sub i64 %_27.i, 1
; call <[structs::Version]>::get_unchecked::<usize>
  %_25.i = call ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version13get_uncheckedjEBx_(ptr %v.0, i64 %v.1, i64 %_26.i, ptr align 8 @alloc_34d92db687bf3e85a75e319cac8072d0) #24
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_21.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_23.i, ptr %_25.i) #24
  br i1 %_21.i, label %bb18.i, label %bb17.i

bb17.i:                                           ; preds = %bb13.i
  %3 = load i64, ptr %run_len.i, align 8
  %4 = add i64 %3, 1
  store i64 %4, ptr %run_len.i, align 8
  br label %bb12.i

bb7.i:                                            ; preds = %bb6.i
  %_15.i = load i64, ptr %run_len.i, align 8
; call <[structs::Version]>::get_unchecked::<usize>
  %_14.i = call ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version13get_uncheckedjEBx_(ptr %v.0, i64 %v.1, i64 %_15.i, ptr align 8 @alloc_3a54043bf62a6816be5c3584bd0aab69) #24
  %_18.i = load i64, ptr %run_len.i, align 8
  %_17.i = sub i64 %_18.i, 1
; call <[structs::Version]>::get_unchecked::<usize>
  %_16.i = call ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version13get_uncheckedjEBx_(ptr %v.0, i64 %v.1, i64 %_17.i, ptr align 8 @alloc_435a452c7ddb8b633a1045ff18a4d695) #24
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_12.i = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_14.i, ptr %_16.i) #24
  br i1 %_12.i, label %bb11.i, label %bb18.i

bb11.i:                                           ; preds = %bb7.i
  %5 = load i64, ptr %run_len.i, align 8
  %6 = add i64 %5, 1
  store i64 %6, ptr %run_len.i, align 8
  br label %bb6.i

_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runNtCs31EPG3twprw_7structs7VersionNvYB12_NtNtB8_3cmp10PartialOrd2ltEB14_.exit: ; preds = %bb1.i, %bb18.i
  %7 = load i64, ptr %_0.i, align 8
  %8 = getelementptr inbounds i8, ptr %_0.i, i64 8
  %9 = load i8, ptr %8, align 8
  %10 = trunc nuw i8 %9 to i1
  %11 = insertvalue { i64, i1 } poison, i64 %7, 0
  %12 = insertvalue { i64, i1 } %11, i1 %10, 1
  %_11.0 = extractvalue { i64, i1 } %12, 0
  %_11.1 = extractvalue { i64, i1 } %12, 1
  %_13 = icmp ule i64 %_11.0, %v.1
  %_14 = icmp uge i64 %_11.0, %min_good_run_len
  br i1 %_14, label %bb3, label %bb7

bb3:                                              ; preds = %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runNtCs31EPG3twprw_7structs7VersionNvYB12_NtNtB8_3cmp10PartialOrd2ltEB14_.exit
  br i1 %_11.1, label %bb4, label %bb6

bb13:                                             ; preds = %bb7
; call core::cmp::min::<usize>
  %_24 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %min_good_run_len, i64 %v.1) #24
  %_2.i3 = shl i64 %_24, 1
  store i64 %_2.i3, ptr %_0, align 8
  br label %bb15

bb8:                                              ; preds = %bb7
; call core::cmp::min::<usize>
  %eager_run_len = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 32, i64 %v.1) #24
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
  %13 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1t_(i64 %eager_run_len, ptr %v.0, i64 %v.1, ptr align 8 @alloc_ea3823fa310c0ac95d0d5924e997a992) #24
  %_0.0.i4 = extractvalue { ptr, i64 } %13, 0
  %_0.1.i5 = extractvalue { ptr, i64 } %13, 1
  %_21.0 = extractvalue { ptr, i64 } %13, 0
  %_21.1 = extractvalue { ptr, i64 } %13, 1
; call core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB15_NtNtBa_3cmp10PartialOrd2ltEB17_(ptr %_21.0, i64 %_21.1, ptr %scratch.0, i64 %scratch.1, i32 0, ptr null, ptr %is_less) #23
  %_3.i1 = shl i64 %eager_run_len, 1
  %_2.i2 = or i64 %_3.i1, 1
  store i64 %_2.i2, ptr %_0, align 8
  br label %bb15

bb15:                                             ; preds = %bb6, %bb8, %bb13
  %14 = load i64, ptr %_0, align 8
  ret i64 %14

bb6:                                              ; preds = %bb4, %bb3
  %_3.i = shl i64 %_11.0, 1
  %_2.i = or i64 %_3.i, 1
  store i64 %_2.i, ptr %_0, align 8
  br label %bb15

bb4:                                              ; preds = %bb3
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
  %15 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1t_(i64 %_11.0, ptr %v.0, i64 %v.1, ptr align 8 @alloc_0b170457ff613254af1d0cbd2a159dca) #24
  %_0.0.i = extractvalue { ptr, i64 } %15, 0
  %_0.1.i = extractvalue { ptr, i64 } %15, 1
  %_16.0 = extractvalue { ptr, i64 } %15, 0
  %_16.1 = extractvalue { ptr, i64 } %15, 1
; call <[structs::Version]>::reverse
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version7reverseBw_(ptr %_16.0, i64 %_16.1) #24
  br label %bb6
}

; core::slice::sort::stable::drift::stable_quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %v.0, i64 %v.1, ptr %scratch.0, i64 %scratch.1, ptr %is_less) unnamed_addr #1 !guid !421 {
start:
  %_6 = or i64 %v.1, 1
; call <usize>::ilog2
  %_5 = call i32 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj5ilog2Cs31EPG3twprw_7structs(i64 %_6, ptr align 8 @alloc_5b26bc7b45e7e23728885c9a7d45b9d3) #24
  %limit = mul i32 2, %_5
; call core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB15_NtNtBa_3cmp10PartialOrd2ltEB17_(ptr %v.0, i64 %v.1, ptr %scratch.0, i64 %scratch.1, i32 %limit, ptr null, ptr %is_less) #23
  ret void
}

; core::slice::sort::stable::drift::sort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift4sortNtCs31EPG3twprw_7structs7VersionNvYBW_NtNtBa_3cmp10PartialOrd2ltEBY_(ptr %v.0, i64 %v.1, ptr %scratch.0, i64 %scratch.1, i1 zeroext %eager_sort, ptr %is_less) unnamed_addr #1 !guid !422 {
start:
  %_0.i = alloca [8 x i8], align 8
  %desired_depth = alloca [1 x i8], align 1
  %next_run = alloca [8 x i8], align 8
  %prev_run = alloca [8 x i8], align 8
  %scan_idx = alloca [8 x i8], align 8
  %desired_depth_storage = alloca [66 x i8], align 1
  %run_storage = alloca [528 x i8], align 8
  %stack_len = alloca [8 x i8], align 8
  %min_good_run_len = alloca [8 x i8], align 8
  %_7 = icmp ult i64 %v.1, 2
  br i1 %_7, label %bb39, label %bb1

bb1:                                              ; preds = %start
; call <u64>::div_ceil
  %_0.i26 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8div_ceilCs31EPG3twprw_7structs(i64 4611686018427387904, i64 %v.1, ptr align 8 @alloc_945f2c369c171e278c4be97205a79e9b) #24
  %_10 = icmp ule i64 %v.1, 4096
  br i1 %_10, label %bb3, label %bb5

bb39:                                             ; preds = %bb38, %bb34, %start
  ret void

bb5:                                              ; preds = %bb1
; call core::slice::sort::stable::drift::sqrt_approx
  %0 = call i64 @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift11sqrt_approx(i64 %v.1)
  store i64 %0, ptr %min_good_run_len, align 8
  br label %bb6

bb3:                                              ; preds = %bb1
  %_13 = udiv i64 %v.1, 2
  %_12 = sub i64 %v.1, %_13
; call core::cmp::min::<usize>
  %1 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %_12, i64 64) #24
  store i64 %1, ptr %min_good_run_len, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb5
  store i64 0, ptr %stack_len, align 8
  store i64 0, ptr %scan_idx, align 8
  store i64 1, ptr %prev_run, align 8
  br label %bb13

bb13:                                             ; preds = %bb35, %bb6
  %_29 = load i64, ptr %scan_idx, align 8
  %_28 = icmp ult i64 %_29, %v.1
  br i1 %_28, label %bb14, label %bb20

bb20:                                             ; preds = %bb13
  store i64 1, ptr %next_run, align 8
  store i8 0, ptr %desired_depth, align 1
  br label %bb22

bb14:                                             ; preds = %bb13
  %_33 = load i64, ptr %scan_idx, align 8
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
  %2 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1v_(i64 %_33, ptr %v.0, i64 %v.1, ptr align 8 @alloc_418d50aea1f432fc229dc42e85bc0c4e) #24
  %_0.0.i29 = extractvalue { ptr, i64 } %2, 0
  %_0.1.i30 = extractvalue { ptr, i64 } %2, 1
  %_31.0 = extractvalue { ptr, i64 } %2, 0
  %_31.1 = extractvalue { ptr, i64 } %2, 1
  %_34 = load i64, ptr %min_good_run_len, align 8
; call core::slice::sort::stable::drift::create_run::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  %_30 = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift10create_runNtCs31EPG3twprw_7structs7VersionNvYB13_NtNtBa_3cmp10PartialOrd2ltEB15_(ptr %_31.0, i64 %_31.1, ptr %scratch.0, i64 %scratch.1, i64 %_34, i1 zeroext %eager_sort, ptr %is_less)
  store i64 %_30, ptr %next_run, align 8
  %_37 = load i64, ptr %scan_idx, align 8
  %_39 = load i64, ptr %prev_run, align 8
  %_0.i13 = lshr i64 %_39, 1
  %_36 = sub i64 %_37, %_0.i13
  %_40 = load i64, ptr %scan_idx, align 8
  %_42 = load i64, ptr %scan_idx, align 8
  %_44 = load i64, ptr %next_run, align 8
  %_0.i12 = lshr i64 %_44, 1
  %_41 = add i64 %_42, %_0.i12
  %x.i = add i64 %_36, %_40
  %y.i = add i64 %_40, %_41
  %_13.i = mul i64 %_0.i26, %x.i
  %_14.i = mul i64 %_0.i26, %y.i
  %_12.i = xor i64 %_13.i, %_14.i
  %3 = call i64 @llvm.ctlz.i64(i64 %_12.i, i1 false)
  %_0.i.i = trunc i64 %3 to i32
  %_0.i24 = trunc i32 %_0.i.i to i8
  store i8 %_0.i24, ptr %desired_depth, align 1
  br label %bb22

bb22:                                             ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergeNtCs31EPG3twprw_7structs7VersionNvYB16_NtNtBa_3cmp10PartialOrd2ltEB18_.exit, %bb14, %bb20
  %_47 = load i64, ptr %stack_len, align 8
  %_46 = icmp ugt i64 %_47, 1
  br i1 %_46, label %bb23, label %bb31

bb31:                                             ; preds = %bb23, %bb22
  %_69 = load i64, ptr %prev_run, align 8
  %_71 = load i64, ptr %stack_len, align 8
  %_0.i2 = getelementptr inbounds nuw i64, ptr %run_storage, i64 %_71
  store i64 %_69, ptr %_0.i2, align 8
  %_72 = load i8, ptr %desired_depth, align 1
  %_74 = load i64, ptr %stack_len, align 8
  %_0.i3 = getelementptr inbounds nuw i8, ptr %desired_depth_storage, i64 %_74
  store i8 %_72, ptr %_0.i3, align 1
  %4 = load i64, ptr %stack_len, align 8
  %5 = add i64 %4, 1
  store i64 %5, ptr %stack_len, align 8
  %_76 = load i64, ptr %scan_idx, align 8
  %_75 = icmp uge i64 %_76, %v.1
  br i1 %_75, label %bb34, label %bb35

bb23:                                             ; preds = %bb22
  %_52 = load i64, ptr %stack_len, align 8
  %_51 = sub i64 %_52, 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %desired_depth_storage, i64 %_51
  %_49 = load i8, ptr %_0.i4, align 1
  %_53 = load i8, ptr %desired_depth, align 1
  %_48 = icmp uge i8 %_49, %_53
  br i1 %_48, label %bb25, label %bb31

bb25:                                             ; preds = %bb23
  %_57 = load i64, ptr %stack_len, align 8
  %_56 = sub i64 %_57, 1
  %_0.i1 = getelementptr inbounds nuw i64, ptr %run_storage, i64 %_56
  %left = load i64, ptr %_0.i1, align 8
  %_0.i10 = lshr i64 %left, 1
  %_61 = load i64, ptr %prev_run, align 8
  %_0.i9 = lshr i64 %_61, 1
  %merged_len = add i64 %_0.i10, %_0.i9
  %_63 = load i64, ptr %scan_idx, align 8
  %merge_start_idx = sub i64 %_63, %merged_len
  %_66 = load i64, ptr %scan_idx, align 8
; call <[structs::Version]>::get_unchecked_mut::<core::ops::range::Range<usize>>
  %6 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version17get_unchecked_mutINtNtNtB5_3ops5range5RangejEEBx_(ptr %v.0, i64 %v.1, i64 %merge_start_idx, i64 %_66, ptr align 8 @alloc_289e523c22daf4b02f0ced64176f9f7d) #24
  %merge_slice.0 = extractvalue { ptr, i64 } %6, 0
  %merge_slice.1 = extractvalue { ptr, i64 } %6, 1
  %_68 = load i64, ptr %prev_run, align 8
  %can_fit_in_scratch.i = icmp ule i64 %merge_slice.1, %scratch.1
  br i1 %can_fit_in_scratch.i, label %bb1.i, label %bb5.i

bb5.i:                                            ; preds = %bb3.i, %bb1.i, %bb25
  %_2.i20 = and i64 %left, 1
  %_0.i21 = icmp eq i64 %_2.i20, 1
  br i1 %_0.i21, label %bb10.i, label %bb7.i

bb1.i:                                            ; preds = %bb25
  %_2.i16 = and i64 %left, 1
  %_0.i17 = icmp eq i64 %_2.i16, 1
  br i1 %_0.i17, label %bb5.i, label %bb3.i

bb3.i:                                            ; preds = %bb1.i
  %_2.i14 = and i64 %_68, 1
  %_0.i15 = icmp eq i64 %_2.i14, 1
  br i1 %_0.i15, label %bb5.i, label %bb18.i

bb18.i:                                           ; preds = %bb3.i
  %_2.i5 = shl i64 %merge_slice.1, 1
  store i64 %_2.i5, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergeNtCs31EPG3twprw_7structs7VersionNvYB16_NtNtBa_3cmp10PartialOrd2ltEB18_.exit

bb7.i:                                            ; preds = %bb5.i
  %_0.i8 = lshr i64 %left, 1
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
  %7 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1t_(i64 %_0.i8, ptr %merge_slice.0, i64 %merge_slice.1, ptr align 8 @alloc_c54bc7e12f54e1b6a5d6ee337e066d20) #24
  %_0.0.i = extractvalue { ptr, i64 } %7, 0
  %_0.1.i = extractvalue { ptr, i64 } %7, 1
  %_15.0.i = extractvalue { ptr, i64 } %7, 0
  %_15.1.i = extractvalue { ptr, i64 } %7, 1
; call core::slice::sort::stable::drift::stable_quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %_15.0.i, i64 %_15.1.i, ptr %scratch.0, i64 %scratch.1, ptr %is_less)
  br label %bb10.i

bb10.i:                                           ; preds = %bb7.i, %bb5.i
  %_2.i18 = and i64 %_68, 1
  %_0.i19 = icmp eq i64 %_2.i18, 1
  br i1 %_0.i19, label %bb15.i, label %bb12.i

bb12.i:                                           ; preds = %bb10.i
  %_0.i7 = lshr i64 %left, 1
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
  %8 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1v_(i64 %_0.i7, ptr %merge_slice.0, i64 %merge_slice.1, ptr align 8 @alloc_4b0ce783e358f6d901ee99bada134993) #24
  %_0.0.i27 = extractvalue { ptr, i64 } %8, 0
  %_0.1.i28 = extractvalue { ptr, i64 } %8, 1
  %_20.0.i = extractvalue { ptr, i64 } %8, 0
  %_20.1.i = extractvalue { ptr, i64 } %8, 1
; call core::slice::sort::stable::drift::stable_quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %_20.0.i, i64 %_20.1.i, ptr %scratch.0, i64 %scratch.1, ptr %is_less)
  br label %bb15.i

bb15.i:                                           ; preds = %bb12.i, %bb10.i
  %_0.i6 = lshr i64 %left, 1
; call core::slice::sort::stable::merge::merge::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5merge5mergeNtCs31EPG3twprw_7structs7VersionNvYBX_NtNtBa_3cmp10PartialOrd2ltEBZ_(ptr %merge_slice.0, i64 %merge_slice.1, ptr %scratch.0, i64 %scratch.1, i64 %_0.i6, ptr %is_less)
  %_3.i = shl i64 %merge_slice.1, 1
  %_2.i = or i64 %_3.i, 1
  store i64 %_2.i, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergeNtCs31EPG3twprw_7structs7VersionNvYB16_NtNtBa_3cmp10PartialOrd2ltEB18_.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergeNtCs31EPG3twprw_7structs7VersionNvYB16_NtNtBa_3cmp10PartialOrd2ltEB18_.exit: ; preds = %bb18.i, %bb15.i
  %9 = load i64, ptr %_0.i, align 8
  store i64 %9, ptr %prev_run, align 8
  %10 = load i64, ptr %stack_len, align 8
  %11 = sub i64 %10, 1
  store i64 %11, ptr %stack_len, align 8
  br label %bb22

bb35:                                             ; preds = %bb31
  %_78 = load i64, ptr %next_run, align 8
  %_0.i11 = lshr i64 %_78, 1
  %12 = load i64, ptr %scan_idx, align 8
  %13 = add i64 %12, %_0.i11
  store i64 %13, ptr %scan_idx, align 8
  %_79 = load i64, ptr %next_run, align 8
  store i64 %_79, ptr %prev_run, align 8
  br label %bb13

bb34:                                             ; preds = %bb31
  %_81 = load i64, ptr %prev_run, align 8
  %_2.i22 = and i64 %_81, 1
  %_0.i23 = icmp eq i64 %_2.i22, 1
  br i1 %_0.i23, label %bb39, label %bb38

bb38:                                             ; preds = %bb34
; call core::slice::sort::stable::drift::stable_quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortNtCs31EPG3twprw_7structs7VersionNvYB19_NtNtBa_3cmp10PartialOrd2ltEB1b_(ptr %v.0, i64 %v.1, ptr %scratch.0, i64 %scratch.1, ptr %is_less)
  br label %bb39
}

; core::slice::sort::stable::merge::merge::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5merge5mergeNtCs31EPG3twprw_7structs7VersionNvYBX_NtNtBa_3cmp10PartialOrd2ltEBZ_(ptr %v.0, i64 %v.1, ptr %scratch.0, i64 %scratch.1, i64 %mid, ptr %is_less) unnamed_addr #1 personality ptr @rust_eh_personality !guid !423 {
start:
  %0 = alloca [16 x i8], align 8
  %merge_state = alloca [24 x i8], align 8
  %save_len = alloca [8 x i8], align 8
  %save_base = alloca [8 x i8], align 8
  %_7 = icmp eq i64 %mid, 0
  br i1 %_7, label %bb21, label %bb1

bb1:                                              ; preds = %start
  %_8 = icmp uge i64 %mid, %v.1
  br i1 %_8, label %bb21, label %bb2

bb21:                                             ; preds = %bb20, %bb2, %bb1, %start
  ret void

bb2:                                              ; preds = %bb1
  %_13 = sub i64 %v.1, %mid
; call core::cmp::min::<usize>
  %_12 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %mid, i64 %_13) #24
  %_9 = icmp ult i64 %scratch.1, %_12
  br i1 %_9, label %bb21, label %bb4

bb4:                                              ; preds = %bb2
  %_0.i2 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %mid
  %_0.i1 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %v.1
  %right_len = sub i64 %v.1, %mid
  %left_is_shorter = icmp ule i64 %mid, %right_len
  br i1 %left_is_shorter, label %bb10, label %bb11

bb11:                                             ; preds = %bb4
  store ptr %_0.i2, ptr %save_base, align 8
  br label %bb12

bb10:                                             ; preds = %bb4
  store ptr %v.0, ptr %save_base, align 8
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  br i1 %left_is_shorter, label %bb13, label %bb14

bb14:                                             ; preds = %bb12
  store i64 %right_len, ptr %save_len, align 8
  br label %bb15

bb13:                                             ; preds = %bb12
  store i64 %mid, ptr %save_len, align 8
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_25 = load ptr, ptr %save_base, align 8
  %_26 = load i64, ptr %save_len, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %bb15
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_25, ptr %scratch.0, i64 3, i64 1, i64 %_26, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %bb15, %bb2.i
  %1 = mul nuw nsw i64 %_26, 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %scratch.0, ptr align 1 %_25, i64 %1, i1 false)
  %_29 = load i64, ptr %save_len, align 8
  %_0.i = getelementptr inbounds nuw %Version, ptr %scratch.0, i64 %_29
  %_30 = load ptr, ptr %save_base, align 8
  store ptr %scratch.0, ptr %merge_state, align 8
  %2 = getelementptr inbounds i8, ptr %merge_state, i64 8
  store ptr %_0.i, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %merge_state, i64 16
  store ptr %_30, ptr %3, align 8
  br i1 %left_is_shorter, label %bb18, label %bb19

bb19:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit
; invoke <core::slice::sort::stable::merge::MergeState<structs::Version>>::merge_down::<<structs::Version as core::cmp::PartialOrd>::lt>
  invoke void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStateNtCs31EPG3twprw_7structs7VersionE10merge_downNvYB1a_NtNtBb_3cmp10PartialOrd2ltEB1c_(ptr align 8 %merge_state, ptr %v.0, ptr %scratch.0, ptr %_0.i1, ptr %is_less)
          to label %bb25 unwind label %cleanup

bb18:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit
; invoke <core::slice::sort::stable::merge::MergeState<structs::Version>>::merge_up::<<structs::Version as core::cmp::PartialOrd>::lt>
  invoke void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStateNtCs31EPG3twprw_7structs7VersionE8merge_upNvYB1a_NtNtBb_3cmp10PartialOrd2ltEB1c_(ptr align 8 %merge_state, ptr %_0.i2, ptr %_0.i1, ptr %is_less)
          to label %bb24 unwind label %cleanup

bb22:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::slice::sort::stable::merge::MergeState<structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6stable5merge10MergeStateNtCs31EPG3twprw_7structs7VersionEEB1r_(ptr align 8 %merge_state) #21
          to label %bb23 unwind label %terminate

cleanup:                                          ; preds = %bb18, %bb19
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb22

bb25:                                             ; preds = %bb19
  br label %bb20

bb20:                                             ; preds = %bb24, %bb25
; call core::ptr::drop_glue::<core::slice::sort::stable::merge::MergeState<structs::Version>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6stable5merge10MergeStateNtCs31EPG3twprw_7structs7VersionEEB1r_(ptr align 8 %merge_state)
  br label %bb21

bb24:                                             ; preds = %bb18
  br label %bb20

terminate:                                        ; preds = %bb22
  %8 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb23:                                             ; preds = %bb22
  %9 = load ptr, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { ptr, i32 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i32 } %12, i32 %11, 1
  resume { ptr, i32 } %13
}

; core::slice::sort::stable::quicksort::stable_partition::<structs::Version, core::slice::sort::stable::quicksort::quicksort<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionNtCs31EPG3twprw_7structs7VersionNCINvB2_9quicksortB1d_NvYB1d_NtNtBa_3cmp10PartialOrd2ltE0EB1f_(ptr %v.0, i64 %v.1, ptr %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext %pivot_goes_left, ptr align 8 %is_less) unnamed_addr #1 !guid !424 {
start:
  %_0.i14 = alloca [1 x i8], align 1
  %_78 = alloca [16 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %loop_end_pos = alloca [8 x i8], align 8
  %pivot_in_scratch = alloca [8 x i8], align 8
  %state = alloca [32 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_10 = icmp ult i64 %scratch.1, %v.1
  br i1 %_10, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = icmp uge i64 %pivot_pos, %v.1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_9, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %_9, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_9, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb3
  store i8 0, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb3
  store i8 1, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i14, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb5, label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_0.i12 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %pivot_pos
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::new
  call void @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE3newB1j_(ptr sret([32 x i8]) align 8 %state, ptr %v.0, ptr %scratch.0, i64 %v.1)
; call core::ptr::metadata::from_raw_parts_mut::<structs::Version, ()>
  %_0.i = call ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionuEBY_(ptr null) #24
  store ptr %_0.i, ptr %pivot_in_scratch, align 8
  store i64 %pivot_pos, ptr %loop_end_pos, align 8
  br label %bb13

bb5:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  call void @llvm.trap()
  unreachable

bb13:                                             ; preds = %bb31, %bb6
  br label %bb14

bb14:                                             ; preds = %bb13
  %_24 = load i64, ptr %loop_end_pos, align 8
  %_0.i13 = call i64 @llvm.usub.sat.i64(i64 %_24, i64 3)
  %_0.i11 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_0.i13
  br label %bb16

bb16:                                             ; preds = %bb17, %bb14
  %6 = getelementptr inbounds i8, ptr %state, i64 8
  %_27 = load ptr, ptr %6, align 8
  %_26 = icmp ult ptr %_27, %_0.i11
  br i1 %_26, label %bb17, label %bb25

bb25:                                             ; preds = %bb16
  %_53 = load i64, ptr %loop_end_pos, align 8
  %_0.i10 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_53
  br label %bb26

bb17:                                             ; preds = %bb16
  %7 = getelementptr inbounds i8, ptr %state, i64 8
  %_90 = load ptr, ptr %7, align 8
; call core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>::{closure#0}
  %_30 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBc_3cmp10PartialOrd2ltE0B19_(ptr align 8 %is_less, ptr %_90, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_28 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_30)
  %8 = getelementptr inbounds i8, ptr %state, i64 8
  %_91 = load ptr, ptr %8, align 8
; call core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>::{closure#0}
  %_36 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBc_3cmp10PartialOrd2ltE0B19_(ptr align 8 %is_less, ptr %_91, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_34 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_36)
  %9 = getelementptr inbounds i8, ptr %state, i64 8
  %_92 = load ptr, ptr %9, align 8
; call core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>::{closure#0}
  %_42 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBc_3cmp10PartialOrd2ltE0B19_(ptr align 8 %is_less, ptr %_92, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_40 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_42)
  %10 = getelementptr inbounds i8, ptr %state, i64 8
  %_93 = load ptr, ptr %10, align 8
; call core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>::{closure#0}
  %_48 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBc_3cmp10PartialOrd2ltE0B19_(ptr align 8 %is_less, ptr %_93, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_46 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_48)
  br label %bb16

bb26:                                             ; preds = %bb27, %bb25
  %11 = getelementptr inbounds i8, ptr %state, i64 8
  %_55 = load ptr, ptr %11, align 8
  %_54 = icmp ult ptr %_55, %_0.i10
  br i1 %_54, label %bb27, label %bb29

bb29:                                             ; preds = %bb26
  %_63 = load i64, ptr %loop_end_pos, align 8
  %_62 = icmp eq i64 %_63, %v.1
  br i1 %_62, label %bb30, label %bb31

bb27:                                             ; preds = %bb26
  %12 = getelementptr inbounds i8, ptr %state, i64 8
  %_94 = load ptr, ptr %12, align 8
; call core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>::{closure#0}
  %_58 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBc_3cmp10PartialOrd2ltE0B19_(ptr align 8 %is_less, ptr %_94, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_56 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_58)
  br label %bb26

bb31:                                             ; preds = %bb29
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_64 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %pivot_goes_left)
  store ptr %_64, ptr %pivot_in_scratch, align 8
  store i64 %v.1, ptr %loop_end_pos, align 8
  br label %bb13

bb30:                                             ; preds = %bb29
; call core::slice::sort::stable::quicksort::has_direct_interior_mutability::<structs::Version>
  %_66 = call zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilityNtCs31EPG3twprw_7structs7VersionEB1t_()
  br i1 %_66, label %bb34, label %bb35

bb35:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit7, %bb30
  %13 = getelementptr inbounds i8, ptr %state, i64 16
  %_72 = load i64, ptr %13, align 8
; call core::ub_checks::check_language_ub
  %_4.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i2, label %bb2.i3, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit4

bb2.i3:                                           ; preds = %bb35
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %scratch.0, ptr %v.0, i64 3, i64 1, i64 %_72, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit4

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit4: ; preds = %bb35, %bb2.i3
  %14 = mul nuw nsw i64 %_72, 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %v.0, ptr align 1 %scratch.0, i64 %14, i1 false)
  %15 = getelementptr inbounds i8, ptr %state, i64 16
  %_76 = load i64, ptr %15, align 8
  %_75 = sub i64 %v.1, %_76
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %16 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %_75) #24
  %_73.0 = extractvalue { i64, i64 } %16, 0
  %_73.1 = extractvalue { i64, i64 } %16, 1
  store i64 %_73.0, ptr %iter, align 8
  %17 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_73.1, ptr %17, align 8
  br label %bb39

bb34:                                             ; preds = %bb30
  %_68 = load ptr, ptr %pivot_in_scratch, align 8
; call core::ub_checks::check_language_ub
  %_4.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i5, label %bb2.i6, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit7

bb2.i6:                                           ; preds = %bb34
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i12, ptr %_68, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit7

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit7: ; preds = %bb34, %bb2.i6
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_68, ptr align 1 %_0.i12, i64 3, i1 false)
  br label %bb35

bb39:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit4
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %18 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #24
  %19 = extractvalue { i64, i64 } %18, 0
  %20 = extractvalue { i64, i64 } %18, 1
  store i64 %19, ptr %_78, align 8
  %21 = getelementptr inbounds i8, ptr %_78, i64 8
  store i64 %20, ptr %21, align 8
  %_80 = load i64, ptr %_78, align 8
  %22 = getelementptr inbounds i8, ptr %_78, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = trunc nuw i64 %_80 to i1
  br i1 %24, label %bb42, label %bb43

bb42:                                             ; preds = %bb39
  %25 = getelementptr inbounds i8, ptr %_78, i64 8
  %i = load i64, ptr %25, align 8
  %_86 = sub i64 %v.1, 1
  %_85 = sub i64 %_86, %i
  %_0.i9 = getelementptr inbounds nuw %Version, ptr %scratch.0, i64 %_85
  %26 = getelementptr inbounds i8, ptr %state, i64 16
  %_89 = load i64, ptr %26, align 8
  %_88 = add i64 %_89, %i
  %_0.i8 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_88
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %bb42
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i9, ptr %_0.i8, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %bb42, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i8, ptr align 1 %_0.i9, i64 3, i1 false)
  br label %bb39

bb43:                                             ; preds = %bb39
  %27 = getelementptr inbounds i8, ptr %state, i64 16
  %_0 = load i64, ptr %27, align 8
  ret i64 %_0

bb41:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::stable::quicksort::stable_partition::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionNtCs31EPG3twprw_7structs7VersionNvYB1d_NtNtBa_3cmp10PartialOrd2ltEB1f_(ptr %v.0, i64 %v.1, ptr %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext %pivot_goes_left, ptr %is_less) unnamed_addr #1 !guid !425 {
start:
  %_0.i14 = alloca [1 x i8], align 1
  %_78 = alloca [16 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %loop_end_pos = alloca [8 x i8], align 8
  %pivot_in_scratch = alloca [8 x i8], align 8
  %state = alloca [32 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_10 = icmp ult i64 %scratch.1, %v.1
  br i1 %_10, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = icmp uge i64 %pivot_pos, %v.1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_9, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %_9, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_9, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb3
  store i8 0, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb3
  store i8 1, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i14, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb5, label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_0.i12 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %pivot_pos
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::new
  call void @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE3newB1j_(ptr sret([32 x i8]) align 8 %state, ptr %v.0, ptr %scratch.0, i64 %v.1)
; call core::ptr::metadata::from_raw_parts_mut::<structs::Version, ()>
  %_0.i = call ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionuEBY_(ptr null) #24
  store ptr %_0.i, ptr %pivot_in_scratch, align 8
  store i64 %pivot_pos, ptr %loop_end_pos, align 8
  br label %bb13

bb5:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  call void @llvm.trap()
  unreachable

bb13:                                             ; preds = %bb31, %bb6
  br label %bb14

bb14:                                             ; preds = %bb13
  %_24 = load i64, ptr %loop_end_pos, align 8
  %_0.i13 = call i64 @llvm.usub.sat.i64(i64 %_24, i64 3)
  %_0.i11 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_0.i13
  br label %bb16

bb16:                                             ; preds = %bb17, %bb14
  %6 = getelementptr inbounds i8, ptr %state, i64 8
  %_27 = load ptr, ptr %6, align 8
  %_26 = icmp ult ptr %_27, %_0.i11
  br i1 %_26, label %bb17, label %bb25

bb25:                                             ; preds = %bb16
  %_53 = load i64, ptr %loop_end_pos, align 8
  %_0.i10 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_53
  br label %bb26

bb17:                                             ; preds = %bb16
  %7 = getelementptr inbounds i8, ptr %state, i64 8
  %_90 = load ptr, ptr %7, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_30 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_90, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_28 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_30)
  %8 = getelementptr inbounds i8, ptr %state, i64 8
  %_91 = load ptr, ptr %8, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_36 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_91, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_34 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_36)
  %9 = getelementptr inbounds i8, ptr %state, i64 8
  %_92 = load ptr, ptr %9, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_42 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_92, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_40 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_42)
  %10 = getelementptr inbounds i8, ptr %state, i64 8
  %_93 = load ptr, ptr %10, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_48 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_93, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_46 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_48)
  br label %bb16

bb26:                                             ; preds = %bb27, %bb25
  %11 = getelementptr inbounds i8, ptr %state, i64 8
  %_55 = load ptr, ptr %11, align 8
  %_54 = icmp ult ptr %_55, %_0.i10
  br i1 %_54, label %bb27, label %bb29

bb29:                                             ; preds = %bb26
  %_63 = load i64, ptr %loop_end_pos, align 8
  %_62 = icmp eq i64 %_63, %v.1
  br i1 %_62, label %bb30, label %bb31

bb27:                                             ; preds = %bb26
  %12 = getelementptr inbounds i8, ptr %state, i64 8
  %_94 = load ptr, ptr %12, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_58 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %_94, ptr %_0.i12) #24
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_56 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %_58)
  br label %bb26

bb31:                                             ; preds = %bb29
; call <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
  %_64 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %state, i1 zeroext %pivot_goes_left)
  store ptr %_64, ptr %pivot_in_scratch, align 8
  store i64 %v.1, ptr %loop_end_pos, align 8
  br label %bb13

bb30:                                             ; preds = %bb29
; call core::slice::sort::stable::quicksort::has_direct_interior_mutability::<structs::Version>
  %_66 = call zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilityNtCs31EPG3twprw_7structs7VersionEB1t_()
  br i1 %_66, label %bb34, label %bb35

bb35:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit7, %bb30
  %13 = getelementptr inbounds i8, ptr %state, i64 16
  %_72 = load i64, ptr %13, align 8
; call core::ub_checks::check_language_ub
  %_4.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i2, label %bb2.i3, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit4

bb2.i3:                                           ; preds = %bb35
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %scratch.0, ptr %v.0, i64 3, i64 1, i64 %_72, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit4

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit4: ; preds = %bb35, %bb2.i3
  %14 = mul nuw nsw i64 %_72, 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %v.0, ptr align 1 %scratch.0, i64 %14, i1 false)
  %15 = getelementptr inbounds i8, ptr %state, i64 16
  %_76 = load i64, ptr %15, align 8
  %_75 = sub i64 %v.1, %_76
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %16 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %_75) #24
  %_73.0 = extractvalue { i64, i64 } %16, 0
  %_73.1 = extractvalue { i64, i64 } %16, 1
  store i64 %_73.0, ptr %iter, align 8
  %17 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_73.1, ptr %17, align 8
  br label %bb39

bb34:                                             ; preds = %bb30
  %_68 = load ptr, ptr %pivot_in_scratch, align 8
; call core::ub_checks::check_language_ub
  %_4.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i5, label %bb2.i6, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit7

bb2.i6:                                           ; preds = %bb34
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i12, ptr %_68, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit7

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit7: ; preds = %bb34, %bb2.i6
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_68, ptr align 1 %_0.i12, i64 3, i1 false)
  br label %bb35

bb39:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit4
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %18 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #24
  %19 = extractvalue { i64, i64 } %18, 0
  %20 = extractvalue { i64, i64 } %18, 1
  store i64 %19, ptr %_78, align 8
  %21 = getelementptr inbounds i8, ptr %_78, i64 8
  store i64 %20, ptr %21, align 8
  %_80 = load i64, ptr %_78, align 8
  %22 = getelementptr inbounds i8, ptr %_78, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = trunc nuw i64 %_80 to i1
  br i1 %24, label %bb42, label %bb43

bb42:                                             ; preds = %bb39
  %25 = getelementptr inbounds i8, ptr %_78, i64 8
  %i = load i64, ptr %25, align 8
  %_86 = sub i64 %v.1, 1
  %_85 = sub i64 %_86, %i
  %_0.i9 = getelementptr inbounds nuw %Version, ptr %scratch.0, i64 %_85
  %26 = getelementptr inbounds i8, ptr %state, i64 16
  %_89 = load i64, ptr %26, align 8
  %_88 = add i64 %_89, %i
  %_0.i8 = getelementptr inbounds nuw %Version, ptr %v.0, i64 %_88
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %bb42
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_0.i9, ptr %_0.i8, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %bb42, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i8, ptr align 1 %_0.i9, i64 3, i1 false)
  br label %bb39

bb43:                                             ; preds = %bb39
  %27 = getelementptr inbounds i8, ptr %state, i64 16
  %_0 = load i64, ptr %27, align 8
  ret i64 %_0

bb41:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::stable::quicksort::has_direct_interior_mutability::<structs::Version>
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilityNtCs31EPG3twprw_7structs7VersionEB1t_() unnamed_addr #1 !guid !426 {
start:
; call <structs::Version as core::slice::sort::stable::quicksort::IsFreeze>::is_freeze
  %_1 = call zeroext i1 @_RNvXs0_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortNtCs31EPG3twprw_7structs7VersionNtB5_8IsFreeze9is_freezeB10_()
  %_0 = xor i1 %_1, true
  ret i1 %_0
}

; core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB15_NtNtBa_3cmp10PartialOrd2ltEB17_(ptr %0, i64 %1, ptr %scratch.0, i64 %scratch.1, i32 %2, ptr %3, ptr %is_less) unnamed_addr #3 !guid !427 {
start:
  %_0.i = alloca [4 x i8], align 1
  %4 = alloca [4 x i8], align 4
  %_55 = alloca [32 x i8], align 8
  %_48 = alloca [8 x i8], align 8
  %left_partition_len = alloca [8 x i8], align 8
  %perform_equal_partition = alloca [1 x i8], align 1
  %pivot_copy = alloca [3 x i8], align 1
  %left_ancestor_pivot = alloca [8 x i8], align 8
  %limit = alloca [4 x i8], align 4
  %v = alloca [16 x i8], align 8
  store ptr %0, ptr %v, align 8
  %5 = getelementptr inbounds i8, ptr %v, i64 8
  store i64 %1, ptr %5, align 8
  store i32 %2, ptr %limit, align 4
  store ptr %3, ptr %left_ancestor_pivot, align 8
  br label %bb1

bb1:                                              ; preds = %bb21, %bb24, %start
  %_7.0 = load ptr, ptr %v, align 8
  %6 = getelementptr inbounds i8, ptr %v, i64 8
  %_7.1 = load i64, ptr %6, align 8
  %_8 = icmp ule i64 %_7.1, 32
  br i1 %_8, label %bb3, label %bb4

bb4:                                              ; preds = %bb1
  %_13 = load i32, ptr %limit, align 4
  %_12 = icmp eq i32 %_13, 0
  br i1 %_12, label %bb5, label %bb6

bb3:                                              ; preds = %bb1
  %_11.0 = load ptr, ptr %v, align 8
  %7 = getelementptr inbounds i8, ptr %v, i64 8
  %_11.1 = load i64, ptr %7, align 8
; call core::slice::sort::shared::smallsort::small_sort_general_with_scratch::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchNtCs31EPG3twprw_7structs7VersionNvYB1s_NtNtBa_3cmp10PartialOrd2ltEB1u_(ptr %_11.0, i64 %_11.1, ptr %scratch.0, i64 %scratch.1, ptr %is_less)
  br label %bb27

bb6:                                              ; preds = %bb4
  %8 = load i32, ptr %limit, align 4
  %9 = sub i32 %8, 1
  store i32 %9, ptr %limit, align 4
  %_17.0 = load ptr, ptr %v, align 8
  %10 = getelementptr inbounds i8, ptr %v, i64 8
  %_17.1 = load i64, ptr %10, align 8
; call core::slice::sort::shared::pivot::choose_pivot::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  %pivot_pos = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot12choose_pivotNtCs31EPG3twprw_7structs7VersionNvYB15_NtNtBa_3cmp10PartialOrd2ltEB17_(ptr %_17.0, i64 %_17.1, ptr %is_less) #24
  %_21.0 = load ptr, ptr %v, align 8
  %11 = getelementptr inbounds i8, ptr %v, i64 8
  %_21.1 = load i64, ptr %11, align 8
  %_23 = icmp ult i64 %pivot_pos, %_21.1
  br i1 %_23, label %bb8, label %panic

bb5:                                              ; preds = %bb4
  %_15.0 = load ptr, ptr %v, align 8
  %12 = getelementptr inbounds i8, ptr %v, i64 8
  %_15.1 = load i64, ptr %12, align 8
; call core::slice::sort::stable::drift::sort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift4sortNtCs31EPG3twprw_7structs7VersionNvYBW_NtNtBa_3cmp10PartialOrd2ltEBY_(ptr %_15.0, i64 %_15.1, ptr %scratch.0, i64 %scratch.1, i1 zeroext true, ptr %is_less)
  br label %bb27

bb8:                                              ; preds = %bb6
  %13 = load ptr, ptr %v, align 8
  %14 = getelementptr inbounds i8, ptr %v, i64 8
  %15 = load i64, ptr %14, align 8
  %_20 = getelementptr inbounds nuw %Version, ptr %13, i64 %pivot_pos
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i, ptr align 1 %_20, i64 3, i1 false)
  %16 = load i24, ptr %_0.i, align 1
  store i24 %16, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %pivot_copy, ptr align 4 %4, i64 3, i1 false)
; call core::slice::sort::stable::quicksort::has_direct_interior_mutability::<structs::Version>
  %_26 = call zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilityNtCs31EPG3twprw_7structs7VersionEB1t_()
  %_25 = xor i1 %_26, true
; call <bool>::then_some::<&structs::Version>
  %pivot_ref = call ptr @_RINvMNtCsl10jNU3mE6R_4core4boolb9then_someRNtCs31EPG3twprw_7structs7VersionEBH_(i1 zeroext %_25, ptr %pivot_copy) #24
  store i8 0, ptr %perform_equal_partition, align 1
  %17 = load ptr, ptr %left_ancestor_pivot, align 8
  %18 = ptrtoint ptr %17 to i64
  %19 = icmp eq i64 %18, 0
  %_31 = select i1 %19, i64 0, i64 1
  %20 = trunc nuw i64 %_31 to i1
  br i1 %20, label %bb14, label %bb17

panic:                                            ; preds = %bb6
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %pivot_pos, i64 %_21.1, ptr align 8 @alloc_4b681e459e5d8eeddb2bdf3b83cf18ab) #26
  unreachable

bb14:                                             ; preds = %bb8
  %la_pivot = load ptr, ptr %left_ancestor_pivot, align 8
  %_36.0 = load ptr, ptr %v, align 8
  %21 = getelementptr inbounds i8, ptr %v, i64 8
  %_36.1 = load i64, ptr %21, align 8
  %_38 = icmp ult i64 %pivot_pos, %_36.1
  br i1 %_38, label %bb15, label %panic1

bb17:                                             ; preds = %bb15, %bb8
  store i64 0, ptr %left_partition_len, align 8
  %22 = load i8, ptr %perform_equal_partition, align 1
  %_40 = trunc nuw i8 %22 to i1
  br i1 %_40, label %bb20, label %bb18

bb15:                                             ; preds = %bb14
  %23 = load ptr, ptr %v, align 8
  %24 = getelementptr inbounds i8, ptr %v, i64 8
  %25 = load i64, ptr %24, align 8
  %_35 = getelementptr inbounds nuw %Version, ptr %23, i64 %pivot_pos
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_33 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %is_less, ptr %la_pivot, ptr %_35) #24
  %26 = xor i1 %_33, true
  %27 = zext i1 %26 to i8
  store i8 %27, ptr %perform_equal_partition, align 1
  br label %bb17

panic1:                                           ; preds = %bb14
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %pivot_pos, i64 %_36.1, ptr align 8 @alloc_2b7dc74fc6b7aa0b08aab5733d36da25) #26
  unreachable

bb18:                                             ; preds = %bb17
  %_42.0 = load ptr, ptr %v, align 8
  %28 = getelementptr inbounds i8, ptr %v, i64 8
  %_42.1 = load i64, ptr %28, align 8
; call core::slice::sort::stable::quicksort::stable_partition::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  %_41 = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionNtCs31EPG3twprw_7structs7VersionNvYB1d_NtNtBa_3cmp10PartialOrd2ltEB1f_(ptr %_42.0, i64 %_42.1, ptr %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext false, ptr %is_less)
  store i64 %_41, ptr %left_partition_len, align 8
  %_43 = load i64, ptr %left_partition_len, align 8
  %29 = icmp eq i64 %_43, 0
  %30 = zext i1 %29 to i8
  store i8 %30, ptr %perform_equal_partition, align 1
  br label %bb20

bb20:                                             ; preds = %bb18, %bb17
  %31 = load i8, ptr %perform_equal_partition, align 1
  %_44 = trunc nuw i8 %31 to i1
  br i1 %_44, label %bb21, label %bb24

bb24:                                             ; preds = %bb20
  %_56.0 = load ptr, ptr %v, align 8
  %32 = getelementptr inbounds i8, ptr %v, i64 8
  %_56.1 = load i64, ptr %32, align 8
  %_57 = load i64, ptr %left_partition_len, align 8
; call <[structs::Version]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version12split_at_mutBw_(ptr sret([32 x i8]) align 8 %_55, ptr %_56.0, i64 %_56.1, i64 %_57, ptr align 8 @alloc_06823d4b39e256f98f8c7a33a4ce85ea) #24
  %left.0 = load ptr, ptr %_55, align 8
  %33 = getelementptr inbounds i8, ptr %_55, i64 8
  %left.1 = load i64, ptr %33, align 8
  %34 = getelementptr inbounds i8, ptr %_55, i64 16
  %right.0 = load ptr, ptr %34, align 8
  %35 = getelementptr inbounds i8, ptr %34, i64 8
  %right.1 = load i64, ptr %35, align 8
  %_59 = load i32, ptr %limit, align 4
; call core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB15_NtNtBa_3cmp10PartialOrd2ltEB17_(ptr %right.0, i64 %right.1, ptr %scratch.0, i64 %scratch.1, i32 %_59, ptr %pivot_ref, ptr %is_less) #23
  store ptr %left.0, ptr %v, align 8
  %36 = getelementptr inbounds i8, ptr %v, i64 8
  store i64 %left.1, ptr %36, align 8
  br label %bb1

bb21:                                             ; preds = %bb20
  %_46.0 = load ptr, ptr %v, align 8
  %37 = getelementptr inbounds i8, ptr %v, i64 8
  %_46.1 = load i64, ptr %37, align 8
  store ptr %is_less, ptr %_48, align 8
; call core::slice::sort::stable::quicksort::stable_partition::<structs::Version, core::slice::sort::stable::quicksort::quicksort<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>::{closure#0}>
  %mid_eq = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionNtCs31EPG3twprw_7structs7VersionNCINvB2_9quicksortB1d_NvYB1d_NtNtBa_3cmp10PartialOrd2ltE0EB1f_(ptr %_46.0, i64 %_46.1, ptr %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext true, ptr align 8 %_48)
  %_50.0 = load ptr, ptr %v, align 8
  %38 = getelementptr inbounds i8, ptr %v, i64 8
  %_50.1 = load i64, ptr %38, align 8
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
  %39 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1v_(i64 %mid_eq, ptr %_50.0, i64 %_50.1, ptr align 8 @alloc_d82d96a4fa703c840ac11f4b07c0ef3c) #24
  %_0.0.i = extractvalue { ptr, i64 } %39, 0
  %_0.1.i = extractvalue { ptr, i64 } %39, 1
  %_49.0 = extractvalue { ptr, i64 } %39, 0
  %_49.1 = extractvalue { ptr, i64 } %39, 1
  store ptr %_49.0, ptr %v, align 8
  %40 = getelementptr inbounds i8, ptr %v, i64 8
  store i64 %_49.1, ptr %40, align 8
  store ptr null, ptr %left_ancestor_pivot, align 8
  br label %bb1

bb28:                                             ; No predecessors!
  unreachable

bb27:                                             ; preds = %bb3, %bb5
  ret void
}

; <[_]>::reverse::revswap::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvMNtCsl10jNU3mE6R_4core5sliceSp7reverse7revswapNtCs31EPG3twprw_7structs7VersionEBQ_(ptr %a.0, i64 %a.1, ptr %b.0, i64 %b.1, i64 %n) unnamed_addr #0 !guid !428 {
start:
  %i = alloca [8 x i8], align 8
  %_7 = alloca [32 x i8], align 8
  %_5 = alloca [32 x i8], align 8
; call <[structs::Version]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version12split_at_mutBw_(ptr sret([32 x i8]) align 8 %_5, ptr %a.0, i64 %a.1, i64 %n, ptr align 8 @alloc_ab5ed840fe8613ddcabc97b74e0b565e) #24
  %a.01 = load ptr, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  %a.12 = load i64, ptr %0, align 8
; call <[structs::Version]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version12split_at_mutBw_(ptr sret([32 x i8]) align 8 %_7, ptr %b.0, i64 %b.1, i64 %n, ptr align 8 @alloc_f7fcaa33fdba299ee035b5518e72c889) #24
  %b.03 = load ptr, ptr %_7, align 8
  %1 = getelementptr inbounds i8, ptr %_7, i64 8
  %b.14 = load i64, ptr %1, align 8
  store i64 0, ptr %i, align 8
  br label %bb3

bb3:                                              ; preds = %bb6, %start
  %_10 = load i64, ptr %i, align 8
  %_9 = icmp ult i64 %_10, %n
  br i1 %_9, label %bb4, label %bb8

bb8:                                              ; preds = %bb3
  ret void

bb4:                                              ; preds = %bb3
  %_13 = load i64, ptr %i, align 8
  %_16 = icmp ult i64 %_13, %a.12
  br i1 %_16, label %bb5, label %panic

bb5:                                              ; preds = %bb4
  %_12 = getelementptr inbounds nuw %Version, ptr %a.01, i64 %_13
  %_19 = sub i64 %n, 1
  %_20 = load i64, ptr %i, align 8
  %_18 = sub i64 %_19, %_20
  %_23 = icmp ult i64 %_18, %b.14
  br i1 %_23, label %bb6, label %panic5

panic:                                            ; preds = %bb4
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_13, i64 %a.12, ptr align 8 @alloc_1466797b2db3a3ca9645efa4732978a2) #26
  unreachable

bb6:                                              ; preds = %bb5
  %_17 = getelementptr inbounds nuw %Version, ptr %b.03, i64 %_18
; call core::mem::swap::<structs::Version>
  call void @_RINvNtCsl10jNU3mE6R_4core3mem4swapNtCs31EPG3twprw_7structs7VersionEBy_(ptr %_12, ptr %_17) #24
  %2 = load i64, ptr %i, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %i, align 8
  br label %bb3

panic5:                                           ; preds = %bb5
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_18, i64 %b.14, ptr align 8 @alloc_853b9dc5190658ffe6dc67504ed95441) #26
  unreachable
}

; core::ptr::swap_nonoverlapping::runtime::<structs::Version>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping7runtimeNtCs31EPG3twprw_7structs7VersionEBY_(ptr %x, ptr %y, i64 %count) unnamed_addr #0 !guid !429 {
start:
  %_7 = alloca [8 x i8], align 8
; call core::ptr::slice_from_raw_parts_mut::<structs::Version>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionEBT_(ptr %x, i64 %count) #24
  %slice.0 = extractvalue { ptr, i64 } %0, 0
  %slice.1 = extractvalue { ptr, i64 } %0, 1
; call core::mem::size_of_val_raw::<[structs::Version]>
  %bytes = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCs31EPG3twprw_7structs7VersionEBL_(ptr %slice.0, i64 %slice.1) #24
; call <core::num::nonzero::NonZero<usize>>::new
  %1 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %bytes) #24
  store i64 %1, ptr %_7, align 8
  %2 = load i64, ptr %_7, align 8
  %3 = icmp eq i64 %2, 0
  %_8 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_8 to i1
  br i1 %4, label %bb4, label %bb7

bb4:                                              ; preds = %start
  %bytes1 = load i64, ptr %_7, align 8
; call core::ptr::swap_nonoverlapping_bytes
  call void @_RNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytesCs31EPG3twprw_7structs(ptr %x, ptr %y, i64 %bytes1) #24
  br label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb8:                                              ; No predecessors!
  unreachable
}

; core::iter::traits::iterator::Iterator::for_each::call::<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB1n_6StringINtNtB8_7collect6ExtendcE6extendINtNtNtBa_8adapters6cloned6ClonedINtNtNtBc_5slice4iter4ItercEEE0ECs31EPG3twprw_7structs(ptr align 8 %f) unnamed_addr #0 !guid !430 {
start:
  ret ptr %f
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<char>, <char as core::clone::Clone>::clone> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4ItercENvYcNtNtBc_5clone5Clone5cloneENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB1T_8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB36_6StringINtNtB1X_7collect6ExtendcE6extendINtNtB8_6cloned6ClonedBX_EE0E0ECs31EPG3twprw_7structs(ptr %self.0, ptr %self.1, ptr align 8 %g) unnamed_addr #1 personality ptr @rust_eh_personality !guid !431 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
; call core::iter::adapters::map::map_fold::<&char, char, (), <char as core::clone::Clone>::clone, core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>
  %_6 = call align 8 ptr @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRccuNvYcNtNtB8_5clone5Clone5cloneNCINvNvNtNtNtB6_6traits8iterator8Iterator8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB2s_6StringINtNtB1A_7collect6ExtendcE6extendINtNtB4_6cloned6ClonedINtNtNtB8_5slice4iter4ItercEEE0E0ECs31EPG3twprw_7structs(ptr align 8 %g)
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::adapters::map::map_fold<&char, char, (), <char as core::clone::Clone>::clone, core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4ItercENtNtNtNtBb_4iter6traits8iterator8Iterator4folduNCINvNtNtBY_8adapters3map8map_foldRccuNvYcNtNtBb_5clone5Clone5cloneNCINvNvBS_8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB3g_6StringINtNtBW_7collect6ExtendcE6extendINtNtB1K_6cloned6ClonedBF_EE0E0E0ECs31EPG3twprw_7structs(ptr %self.0, ptr %self.1, ptr align 8 %_6) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_9, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0ENtNtNtBa_6traits8iterator8Iterator4foldjNCINvXsK_NtB20_5accumjNtB2J_3Sum3sumBN_E0EB1t_(ptr %self.0, ptr %self.1, i64 %init) unnamed_addr #1 personality ptr @rust_eh_personality !guid !432 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
; call core::iter::adapters::map::map_fold::<&u8, usize, usize, structs::main::{closure#0}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRhjjNCNvCs31EPG3twprw_7structs4main0NCINvXsK_NtNtB6_6traits5accumjNtB1B_3Sum3sumINtB2_3MapINtNtNtB8_5slice4iter4IterhEBW_EE0EB10_()
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<&u8, usize, usize, structs::main::{closure#0}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}>::{closure#0}>
  %_0 = call i64 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator4foldjNCINvNtNtBY_8adapters3map8map_foldRhjjNCNvCs31EPG3twprw_7structs4main0NCINvXsK_NtBW_5accumjNtB2U_3Sum3sumINtB1I_3MapBF_B2f_EE0E0EB2j_(ptr %self.0, ptr %self.1, i64 %init) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_9, align 1
  ret i64 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::adapters::map::map_fold<&char, char, (), <char as core::clone::Clone>::clone, core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4ItercENtNtNtNtBb_4iter6traits8iterator8Iterator4folduNCINvNtNtBY_8adapters3map8map_foldRccuNvYcNtNtBb_5clone5Clone5cloneNCINvNvBS_8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB3g_6StringINtNtBW_7collect6ExtendcE6extendINtNtB1K_6cloned6ClonedBF_EE0E0E0ECs31EPG3twprw_7structs(ptr %0, ptr %1, ptr align 8 %2) unnamed_addr #0 personality ptr @rust_eh_personality !guid !433 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %f = alloca [8 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store ptr %2, ptr %f, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %4, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<char> as core::cmp::PartialEq>::eq
  %5 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullcENtNtB9_3cmp9PartialEq2eqCs257F0UrNG3U_14rustc_demangle(ptr align 8 %self, ptr align 8 %end) #24
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %7 = load i8, ptr %_4, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  br label %bb16

bb8:                                              ; preds = %bb6
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %9, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<char>>::offset_from_unsigned
  %10 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullcE20offset_from_unsignedCs31EPG3twprw_7structs(ptr %_17, ptr %_18) #24
  store i64 %10, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw i32, ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call core::iter::adapters::map::map_fold::<&char, char, (), <char as core::clone::Clone>::clone, core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>::{closure#0}
  call void @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRccuNvYcNtNtBa_5clone5Clone5cloneNCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB2u_6StringINtNtB1C_7collect6ExtendcE6extendINtNtB6_6cloned6ClonedINtNtNtBa_5slice4iter4ItercEEE0E0E0Cs31EPG3twprw_7structs(ptr align 8 %f, ptr align 4 %_3.i) #24
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs31EPG3twprw_7structs(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #25
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  ret void

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<&u8, usize, usize, structs::main::{closure#0}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator4foldjNCINvNtNtBY_8adapters3map8map_foldRhjjNCNvCs31EPG3twprw_7structs4main0NCINvXsK_NtBW_5accumjNtB2U_3Sum3sumINtB1I_3MapBF_B2f_EE0E0EB2j_(ptr %0, ptr %1, i64 %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !434 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %acc = alloca [8 x i8], align 8
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %f = alloca [0 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %3, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
  %4 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqB9_(ptr align 8 %self, ptr align 8 %end) #24
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %6 = load i8, ptr %_4, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store i64 %init, ptr %acc, align 8
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i64 %init, ptr %_0, align 8
  br label %bb16

bb8:                                              ; preds = %bb6
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %8, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %9 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedB9_(ptr %_17, ptr %_18) #24
  store i64 %9, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_22 = load i64, ptr %acc, align 8
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw i8, ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call core::iter::adapters::map::map_fold::<&u8, usize, usize, structs::main::{closure#0}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}>::{closure#0}
  %_19 = call i64 @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRhjjNCNvCs31EPG3twprw_7structs4main0NCINvXsK_NtNtB8_6traits5accumjNtB1D_3Sum3sumINtB4_3MapINtNtNtBa_5slice4iter4IterhEBY_EE0E0B12_(ptr %f, i64 %_22, ptr %_3.i) #24
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  store i64 %_19, ptr %acc, align 8
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs31EPG3twprw_7structs(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #25
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  %10 = load i64, ptr %acc, align 8
  store i64 %10, ptr %_0, align 8
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  %11 = load i64, ptr %_0, align 8
  ret i64 %11

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <alloc::string::String as core::iter::traits::collect::FromIterator<&char>>::from_iter::<core::slice::iter::Iter<char>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXs6_NtCs7CppTae75M1_5alloc6stringNtB6_6StringINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorRcE9from_iterINtNtNtBU_5slice4iter4ItercEECs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %iter.0, ptr %iter.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !435 {
start:
  %0 = alloca [16 x i8], align 8
  %_6 = alloca [1 x i8], align 1
  %buf = alloca [24 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
; call <alloc::string::String>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %buf) #24
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; invoke <alloc::string::String as core::iter::traits::collect::Extend<&char>>::extend::<core::slice::iter::Iter<char>>
  invoke void @_RINvXse_NtCs7CppTae75M1_5alloc6stringNtB6_6StringINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect6ExtendRcE6extendINtNtNtBU_5slice4iter4ItercEECs31EPG3twprw_7structs(ptr align 8 %buf, ptr %iter.0, ptr %iter.1)
          to label %bb2 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %buf) #21
          to label %bb6 unwind label %terminate

cleanup:                                          ; preds = %bb1
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb2:                                              ; preds = %bb1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %buf, i64 24, i1 false)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb6:                                              ; preds = %bb3
  %6 = load i8, ptr %_6, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb5:                                              ; preds = %bb6
  br label %bb4
}

; <usize as core::iter::traits::accum::Sum>::sum::<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvXsK_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumjNtB6_3Sum3sumINtNtNtBa_8adapters3map3MapINtNtNtBc_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0EEB1Y_(ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !436 {
start:
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<usize, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}>
  %_0 = call i64 @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0ENtNtNtBa_6traits8iterator8Iterator4foldjNCINvXsK_NtB20_5accumjNtB2J_3Sum3sumBN_E0EB1t_(ptr %iter.0, ptr %iter.1, i64 0)
  ret i64 %_0
}

; <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB5_6ClonedINtNtNtBb_5slice4iter4ItercEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNvB1v_8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB2I_6StringINtNtB1z_7collect6ExtendcE6extendBP_E0E0ECs31EPG3twprw_7structs(ptr %self.0, ptr %self.1, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !437 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
; call <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::map::<char, <char as core::clone::Clone>::clone>
  %0 = call { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4ItercENtNtNtNtBa_4iter6traits8iterator8Iterator3mapcNvYcNtNtBa_5clone5Clone5cloneECs31EPG3twprw_7structs(ptr %self.0, ptr %self.1) #24
  %_4.0 = extractvalue { ptr, ptr } %0, 0
  %_4.1 = extractvalue { ptr, ptr } %0, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<char>, <char as core::clone::Clone>::clone> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>
  call void @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4ItercENvYcNtNtBc_5clone5Clone5cloneENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB1T_8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB36_6StringINtNtB1X_7collect6ExtendcE6extendINtNtB8_6cloned6ClonedBX_EE0E0ECs31EPG3twprw_7structs(ptr %_4.0, ptr %_4.1, ptr align 8 %f)
  br label %bb2

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend::<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXsd_NtCs7CppTae75M1_5alloc6stringNtB6_6StringINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect6ExtendcE6extendINtNtNtBS_8adapters6cloned6ClonedINtNtNtBU_5slice4iter4ItercEEECs31EPG3twprw_7structs(ptr align 8 %self, ptr %iter.0, ptr %iter.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !438 {
start:
  %_11 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %iterator = alloca [16 x i8], align 8
  store i8 0, ptr %_11, align 1
; call <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters6cloned6ClonedINtNtNtB8_5slice4iter4ItercEENtB2_12IntoIterator9into_iterCs31EPG3twprw_7structs(ptr %iter.0, ptr %iter.1) #24
  %1 = extractvalue { ptr, ptr } %0, 0
  %2 = extractvalue { ptr, ptr } %0, 1
  store ptr %1, ptr %iterator, align 8
  %3 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %2, ptr %3, align 8
  store i8 1, ptr %_11, align 1
; call <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB4_6ClonedINtNtNtBa_5slice4iter4ItercEENtNtNtB8_6traits8iterator8Iterator9size_hintCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %iterator)
  br label %bb2

bb2:                                              ; preds = %start
  %lower_bound = load i64, ptr %_5, align 8
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs31EPG3twprw_7structs(ptr align 8 %self, i64 %lower_bound) #24
  br label %bb3

bb3:                                              ; preds = %bb2
  store i8 0, ptr %_11, align 1
  %_9.0 = load ptr, ptr %iterator, align 8
  %4 = getelementptr inbounds i8, ptr %iterator, i64 8
  %_9.1 = load ptr, ptr %4, align 8
; call <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>
  call void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6cloned6ClonedINtNtNtBc_5slice4iter4ItercEENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB2g_6StringINtNtB1u_7collect6ExtendcE6extendB3_E0ECs31EPG3twprw_7structs(ptr %_9.0, ptr %_9.1, ptr align 8 %self) #24
  br label %bb4

bb4:                                              ; preds = %bb3
  store i8 0, ptr %_11, align 1
  ret void

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::iter::traits::collect::Extend<&char>>::extend::<core::slice::iter::Iter<char>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXse_NtCs7CppTae75M1_5alloc6stringNtB6_6StringINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect6ExtendRcE6extendINtNtNtBU_5slice4iter4ItercEECs31EPG3twprw_7structs(ptr align 8 %self, ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !439 {
start:
; call <core::slice::iter::Iter<char> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4ItercENtB2_12IntoIterator9into_iterCs31EPG3twprw_7structs(ptr %iter.0, ptr %iter.1) #24
  %_5.0 = extractvalue { ptr, ptr } %0, 0
  %_5.1 = extractvalue { ptr, ptr } %0, 1
; call <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::cloned::<char>
  %1 = call { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4ItercENtNtNtNtBa_4iter6traits8iterator8Iterator6clonedcECs31EPG3twprw_7structs(ptr %_5.0, ptr %_5.1)
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend::<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>
  call void @_RINvXsd_NtCs7CppTae75M1_5alloc6stringNtB6_6StringINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect6ExtendcE6extendINtNtNtBS_8adapters6cloned6ClonedINtNtNtBU_5slice4iter4ItercEEECs31EPG3twprw_7structs(ptr align 8 %self, ptr %_4.0, ptr %_4.1)
  ret void
}

; <alloc::vec::Vec<char> as core::iter::traits::collect::FromIterator<char>>::from_iter::<core::str::iter::Chars>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VeccEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorcE9from_iterNtNtNtBR_3str4iter5CharsECs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %iter.0, ptr %iter.1) unnamed_addr #0 !guid !440 {
start:
; call <core::str::iter::Chars as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectNtNtNtB8_3str4iter5CharsNtB2_12IntoIterator9into_iterB8_(ptr %iter.0, ptr %iter.1) #24
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call <alloc::vec::Vec<char> as alloc::vec::spec_from_iter::SpecFromIter<char, core::str::iter::Chars>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VeccEINtB2_12SpecFromItercNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE9from_iterCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, ptr %_2.1)
  ret void
}

; <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::map::<char, <char as core::clone::Clone>::clone>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4ItercENtNtNtNtBa_4iter6traits8iterator8Iterator3mapcNvYcNtNtBa_5clone5Clone5cloneECs31EPG3twprw_7structs(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !441 {
start:
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<char>, <char as core::clone::Clone>::clone>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4ItercENvYcNtNtB8_5clone5Clone5cloneE3newCs31EPG3twprw_7structs(ptr %self.0, ptr %self.1)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::cloned::<char>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4ItercENtNtNtNtBa_4iter6traits8iterator8Iterator6clonedcECs31EPG3twprw_7structs(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !442 {
start:
; call <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB2_6ClonedINtNtNtB8_5slice4iter4ItercEE3newCs31EPG3twprw_7structs(ptr %self.0, ptr %self.1)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::collect::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4ItercENtNtNtNtBa_4iter6traits8iterator8Iterator7collectNtNtCs7CppTae75M1_5alloc6string6StringECs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, ptr %self.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !443 {
start:
  %_6 = alloca [1 x i8], align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  store i8 0, ptr %_6, align 1
; call <alloc::string::String as core::iter::traits::collect::FromIterator<&char>>::from_iter::<core::slice::iter::Iter<char>>
  call void @_RINvXs6_NtCs7CppTae75M1_5alloc6stringNtB6_6StringINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorRcE9from_iterINtNtNtBU_5slice4iter4ItercEECs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, ptr %self.1)
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::map::<usize, structs::main::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator3mapjNCNvCs31EPG3twprw_7structs4main0EB1z_(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !444 {
start:
; call <core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0E3newB1p_(ptr %self.0, ptr %self.1)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}> as core::iter::traits::iterator::Iterator>::sum::<usize>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0ENtNtNtBa_6traits8iterator8Iterator3sumjEB1n_(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !445 {
start:
; call <usize as core::iter::traits::accum::Sum>::sum::<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>
  %_0 = call i64 @_RINvXsK_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumjNtB6_3Sum3sumINtNtNtBa_8adapters3map3MapINtNtNtBc_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0EEB1Y_(ptr %self.0, ptr %self.1)
  ret i64 %_0
}

; <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6cloned6ClonedINtNtNtBc_5slice4iter4ItercEENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB2g_6StringINtNtB1u_7collect6ExtendcE6extendB3_E0ECs31EPG3twprw_7structs(ptr %self.0, ptr %self.1, ptr align 8 %f) unnamed_addr #0 personality ptr @rust_eh_personality !guid !446 {
start:
  %_6 = alloca [1 x i8], align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
; call core::iter::traits::iterator::Iterator::for_each::call::<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>
  %_5 = call align 8 ptr @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB1n_6StringINtNtB8_7collect6ExtendcE6extendINtNtNtBa_8adapters6cloned6ClonedINtNtNtBc_5slice4iter4ItercEEE0ECs31EPG3twprw_7structs(ptr align 8 %f) #24
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; call <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>
  call void @_RINvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB5_6ClonedINtNtNtBb_5slice4iter4ItercEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNvB1v_8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB2I_6StringINtNtB1z_7collect6ExtendcE6extendBP_E0E0ECs31EPG3twprw_7structs(ptr %self.0, ptr %self.1, ptr align 8 %_5)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<char>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VeccEECs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, ptr %self.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !447 {
start:
  %_6 = alloca [1 x i8], align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  store i8 0, ptr %_6, align 1
; call <alloc::vec::Vec<char> as core::iter::traits::collect::FromIterator<char>>::from_iter::<core::str::iter::Chars>
  call void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VeccEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorcE9from_iterNtNtNtBR_3str4iter5CharsECs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, ptr %self.1) #24
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs31EPG3twprw_7structs(ptr align 8 %_1) unnamed_addr #0 !guid !448 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs31EPG3twprw_7structs(ptr %_4) #23
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs31EPG3twprw_7structs() #24
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs31EPG3twprw_7structs(i8 %_2) #24
  ret i32 %_0
}

; core::iter::adapters::map::map_fold::<&char, char, (), <char as core::clone::Clone>::clone, core::iter::traits::iterator::Iterator::for_each::call<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRccuNvYcNtNtBa_5clone5Clone5cloneNCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB2u_6StringINtNtB1C_7collect6ExtendcE6extendINtNtB6_6cloned6ClonedINtNtNtBa_5slice4iter4ItercEEE0E0E0Cs31EPG3twprw_7structs(ptr align 8 %_1, ptr align 4 %elt) unnamed_addr #0 personality ptr @rust_eh_personality !guid !449 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
  %_8 = getelementptr inbounds i8, ptr %_1, i64 8
; call <<char as core::clone::Clone>::clone as core::ops::function::FnMut<(&char,)>>::call_mut
  %_7 = call i32 @_RNvYNvYcNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBa_3ops8function5FnMutTRcEE8call_mutCs31EPG3twprw_7structs(ptr %_8, ptr align 4 %elt) #24
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call core::iter::traits::iterator::Iterator::for_each::call::<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}
  call void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB1p_6StringINtNtBa_7collect6ExtendcE6extendINtNtNtBc_8adapters6cloned6ClonedINtNtNtBe_5slice4iter4ItercEEE0E0Cs31EPG3twprw_7structs(ptr align 8 %_1, i32 %_7) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_10, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; core::iter::adapters::map::map_fold::<&u8, usize, usize, structs::main::{closure#0}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRhjjNCNvCs31EPG3twprw_7structs4main0NCINvXsK_NtNtB8_6traits5accumjNtB1D_3Sum3sumINtB4_3MapINtNtNtBa_5slice4iter4IterhEBY_EE0E0B12_(ptr %_1, i64 %acc, ptr %elt) unnamed_addr #0 personality ptr @rust_eh_personality !guid !450 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
; call structs::main::{closure#0}
  %_7 = call i64 @_RNCNvCs31EPG3twprw_7structs4main0B3_(ptr %_1, ptr %elt) #24
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call <usize as core::iter::traits::accum::Sum>::sum::<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}
  %_0 = call i64 @_RNCINvXsK_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumjNtB8_3Sum3sumINtNtNtBc_8adapters3map3MapINtNtNtBe_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0EE0B20_(ptr %_1, i64 %acc, i64 %_7) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_10, align 1
  ret i64 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; core::slice::sort::stable::quicksort::quicksort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortNtCs31EPG3twprw_7structs7VersionNvYB17_NtNtBc_3cmp10PartialOrd2ltE0B19_(ptr align 8 %_1, ptr %a, ptr %b) unnamed_addr #0 !guid !451 {
start:
  %_6 = load ptr, ptr %_1, align 8
; call <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
  %_4 = call zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %_6, ptr %b, ptr %a) #24
  %_0 = xor i1 %_4, true
  ret i1 %_0
}

; core::iter::traits::iterator::Iterator::for_each::call::<char, <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callcNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB1p_6StringINtNtBa_7collect6ExtendcE6extendINtNtNtBc_8adapters6cloned6ClonedINtNtNtBe_5slice4iter4ItercEEE0E0Cs31EPG3twprw_7structs(ptr align 8 %_1, i32 %item) unnamed_addr #0 !guid !452 {
start:
; call <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend::<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}
  call void @_RNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB8_6StringINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect6ExtendcE6extendINtNtNtBU_8adapters6cloned6ClonedINtNtNtBW_5slice4iter4ItercEEE0Cs31EPG3twprw_7structs(ptr align 8 %_1, i32 %item) #24
  ret void
}

; <usize as core::iter::traits::accum::Sum>::sum::<core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCINvXsK_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumjNtB8_3Sum3sumINtNtNtBc_8adapters3map3MapINtNtNtBe_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0EE0B20_(ptr %_1, i64 %a, i64 %b) unnamed_addr #0 !guid !453 {
start:
  %_4.0 = add i64 %a, %b
  %_4.1 = icmp ult i64 %_4.0, %a
  br i1 %_4.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i64 %_4.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_a840ce68d073c0ef52d40243c1f57585) #26
  unreachable
}

; <alloc::string::String as core::iter::traits::collect::Extend<char>>::extend::<core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvXsd_NtCs7CppTae75M1_5alloc6stringNtB8_6StringINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect6ExtendcE6extendINtNtNtBU_8adapters6cloned6ClonedINtNtNtBW_5slice4iter4ItercEEE0Cs31EPG3twprw_7structs(ptr align 8 %_1, i32 %c) unnamed_addr #0 !guid !454 {
start:
  %_3 = load ptr, ptr %_1, align 8
; call <alloc::string::String>::push
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs31EPG3twprw_7structs(ptr align 8 %_3, i32 %c) #24
  ret void
}

; structs::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNvCs31EPG3twprw_7structs4main0B3_(ptr %_1, ptr %_2) unnamed_addr #0 !guid !455 {
start:
  %x = load i8, ptr %_2, align 1
  %_0 = zext i8 %x to i64
  ret i64 %_0
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitReEE4next0Cs31EPG3twprw_7structs(ptr align 8 %_1.0, i64 %_1.1, i64 %idx) unnamed_addr #0 !guid !456 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&str>]>::get_unchecked::<usize>
  %_3 = call align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitReE13get_uncheckedjECs31EPG3twprw_7structs(ptr align 8 %_1.0, i64 %_1.1, i64 %idx, ptr align 8 @alloc_ac893681874450253b62899ecf8cf06a) #24
  %_0.0.i.i.i = load ptr, ptr %_3, align 8
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %_0.1.i.i.i = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1.i.i.i, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1.i.i.i, 1
  %5 = insertvalue { ptr, i64 } poison, ptr %_0.0.i.i.i, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_0.1.i.i.i, 1
  %_0.0 = extractvalue { ptr, i64 } %6, 0
  %_0.1 = extractvalue { ptr, i64 } %6, 1
  %7 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %_0.1, 1
  ret { ptr, i64 } %8
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs31EPG3twprw_7structs(ptr %_1) unnamed_addr #0 !guid !457 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs31EPG3twprw_7structs(ptr %0) #24
  ret i32 %_0
}

; structs::atom
; Function Attrs: nonlazybind uwtable
define internal double @_RNvCs31EPG3twprw_7structs4atom(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos) unnamed_addr #1 !guid !458 {
start:
  %_21 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %o = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %_4 = load i64, ptr %pos, align 8
  %_6 = icmp ult i64 %_4, %t.1
  br i1 %_6, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_3 = getelementptr inbounds nuw %Token, ptr %t.0, i64 %_4
  %0 = load i32, ptr %_3, align 8
  %_7 = zext i32 %0 to i64
  switch i64 %_7, label %bb16 [
    i64 0, label %bb6
    i64 1, label %bb3
    i64 2, label %bb5
    i64 3, label %bb2
  ]

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_4, i64 %t.1, ptr align 8 @alloc_11031eeda41e187e6b6226c72cffb5ed) #26
  unreachable

bb16:                                             ; preds = %bb1
  unreachable

bb6:                                              ; preds = %bb1
  %n = getelementptr inbounds i8, ptr %_3, i64 8
  %1 = load i64, ptr %pos, align 8
  %_9.0 = add i64 %1, 1
  %_9.1 = icmp ult i64 %_9.0, %1
  br i1 %_9.1, label %panic1, label %bb7

bb3:                                              ; preds = %bb1
  %2 = getelementptr inbounds i8, ptr %_3, i64 4
  %3 = load i32, ptr %2, align 4
  %4 = icmp eq i32 %3, 45
  br i1 %4, label %bb4, label %bb2

bb5:                                              ; preds = %bb1
  %5 = load i64, ptr %pos, align 8
  %_10.0 = add i64 %5, 1
  %_10.1 = icmp ult i64 %_10.0, %5
  br i1 %_10.1, label %panic3, label %bb8

bb2:                                              ; preds = %bb3, %bb1
  store ptr %_3, ptr %o, align 8, !captures !349
; call <core::fmt::rt::Argument>::new_debug::<&structs::Token>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRNtCs31EPG3twprw_7structs5TokenEBY_(ptr sret([16 x i8]) align 8 %_21, ptr align 8 %o) #24
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_21, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<14, 1>
  %7 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_9203d5fb81b5296cec933dac0a2d48d5, ptr align 8 %args) #24
  %_17.0 = extractvalue { ptr, ptr } %7, 0
  %_17.1 = extractvalue { ptr, ptr } %7, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_17.0, ptr %_17.1, ptr align 8 @alloc_935aa0beb3f1208e931cafc1817e27f8) #26
  unreachable

bb7:                                              ; preds = %bb6
  store i64 %_9.0, ptr %pos, align 8
  %8 = load double, ptr %n, align 8
  store double %8, ptr %_0, align 8
  br label %bb15

panic1:                                           ; preds = %bb6
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_135341f3cce8efd686943e936cdabffb) #26
  unreachable

bb15:                                             ; preds = %bb10, %bb11, %bb7
  %9 = load double, ptr %_0, align 8
  ret double %9

bb4:                                              ; preds = %bb3
  %10 = load i64, ptr %pos, align 8
  %_13.0 = add i64 %10, 1
  %_13.1 = icmp ult i64 %_13.0, %10
  br i1 %_13.1, label %panic2, label %bb11

bb11:                                             ; preds = %bb4
  store i64 %_13.0, ptr %pos, align 8
; call structs::atom
  %_14 = call double @_RNvCs31EPG3twprw_7structs4atom(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos)
  %11 = fneg double %_14
  store double %11, ptr %_0, align 8
  br label %bb15

panic2:                                           ; preds = %bb4
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_9167e64474dcc15fd7b8376d61e32929) #26
  unreachable

bb8:                                              ; preds = %bb5
  store i64 %_10.0, ptr %pos, align 8
; call structs::eval
  %v = call double @_RNvCs31EPG3twprw_7structs4eval(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos)
  %12 = load i64, ptr %pos, align 8
  %_12.0 = add i64 %12, 1
  %_12.1 = icmp ult i64 %_12.0, %12
  br i1 %_12.1, label %panic4, label %bb10

panic3:                                           ; preds = %bb5
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_1a6bd3a289dc6a0cca1fc174cb2b3862) #26
  unreachable

bb10:                                             ; preds = %bb8
  store i64 %_12.0, ptr %pos, align 8
  store double %v, ptr %_0, align 8
  br label %bb15

panic4:                                           ; preds = %bb8
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_0e637fc846cbe6acb26e3dc0d1c24d0c) #26
  unreachable
}

; structs::eval
; Function Attrs: nonlazybind uwtable
define internal double @_RNvCs31EPG3twprw_7structs4eval(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos) unnamed_addr #1 !guid !459 {
start:
  %v = alloca [8 x i8], align 8
; call structs::term
  %0 = call double @_RNvCs31EPG3twprw_7structs4term(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos)
  store double %0, ptr %v, align 8
  br label %bb1

bb1:                                              ; preds = %bb9, %bb7, %start
  %_5 = load i64, ptr %pos, align 8
  %_4 = icmp ult i64 %_5, %t.1
  br i1 %_4, label %bb2, label %bb11

bb11:                                             ; preds = %bb4, %bb3, %bb1
  %_0 = load double, ptr %v, align 8
  ret double %_0

bb2:                                              ; preds = %bb1
  %_7 = load i64, ptr %pos, align 8
  %_9 = icmp ult i64 %_7, %t.1
  br i1 %_9, label %bb3, label %panic

bb3:                                              ; preds = %bb2
  %1 = getelementptr inbounds nuw %Token, ptr %t.0, i64 %_7
  %2 = load i32, ptr %1, align 8
  %_10 = zext i32 %2 to i64
  %3 = icmp eq i64 %_10, 1
  br i1 %3, label %bb4, label %bb11

panic:                                            ; preds = %bb2
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_7, i64 %t.1, ptr align 8 @alloc_bf17dfe2c3752d5e0766f39eb9b04ce8) #26
  unreachable

bb4:                                              ; preds = %bb3
  %4 = getelementptr inbounds nuw %Token, ptr %t.0, i64 %_7
  %5 = getelementptr inbounds i8, ptr %4, i64 4
  %6 = load i32, ptr %5, align 4
  switch i32 %6, label %bb11 [
    i32 43, label %bb6
    i32 45, label %bb5
  ]

bb6:                                              ; preds = %bb4
  %7 = load i64, ptr %pos, align 8
  %_11.0 = add i64 %7, 1
  %_11.1 = icmp ult i64 %_11.0, %7
  br i1 %_11.1, label %panic1, label %bb7

bb5:                                              ; preds = %bb4
  %8 = load i64, ptr %pos, align 8
  %_13.0 = add i64 %8, 1
  %_13.1 = icmp ult i64 %_13.0, %8
  br i1 %_13.1, label %panic2, label %bb9

bb7:                                              ; preds = %bb6
  store i64 %_11.0, ptr %pos, align 8
; call structs::term
  %_12 = call double @_RNvCs31EPG3twprw_7structs4term(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos)
  %9 = load double, ptr %v, align 8
  %10 = fadd double %9, %_12
  store double %10, ptr %v, align 8
  br label %bb1

panic1:                                           ; preds = %bb6
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_5e987218b28a875571f5776dc4899fa3) #26
  unreachable

bb9:                                              ; preds = %bb5
  store i64 %_13.0, ptr %pos, align 8
; call structs::term
  %_14 = call double @_RNvCs31EPG3twprw_7structs4term(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos)
  %11 = load double, ptr %v, align 8
  %12 = fsub double %11, %_14
  store double %12, ptr %v, align 8
  br label %bb1

panic2:                                           ; preds = %bb5
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_c117e4ea55a54919dac3e7ac464ee900) #26
  unreachable
}

; structs::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs31EPG3twprw_7structs4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !460 {
start:
  %_4.i = alloca [1 x i8], align 1
  %0 = alloca [4 x i8], align 4
  %x.i = alloca [3 x i8], align 1
  %1 = alloca [4 x i8], align 4
  %2 = alloca [4 x i8], align 4
  %3 = alloca [4 x i8], align 4
  %4 = alloca [4 x i8], align 4
  %5 = alloca [4 x i8], align 4
  %6 = alloca [4 x i8], align 4
  %7 = alloca [16 x i8], align 8
  %_215 = alloca [16 x i8], align 8
  %args16 = alloca [16 x i8], align 8
  %_208 = alloca [3 x i8], align 1
  %_204 = alloca [16 x i8], align 8
  %args15 = alloca [16 x i8], align 8
  %_196 = alloca [16 x i8], align 8
  %args14 = alloca [16 x i8], align 8
  %shadow13 = alloca [16 x i8], align 8
  %shadow = alloca [4 x i8], align 4
  %_184 = alloca [16 x i8], align 8
  %args12 = alloca [16 x i8], align 8
  %n = alloca [4 x i8], align 4
  %label = alloca [4 x i8], align 4
  %_167 = alloca [16 x i8], align 8
  %_166 = alloca [16 x i8], align 8
  %args11 = alloca [32 x i8], align 8
  %_155 = alloca [8 x i8], align 8
  %_149 = alloca [3 x i8], align 1
  %arr = alloca [6 x i8], align 1
  %_145 = alloca [16 x i8], align 8
  %_144 = alloca [16 x i8], align 8
  %_143 = alloca [16 x i8], align 8
  %_142 = alloca [16 x i8], align 8
  %args10 = alloca [64 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %z = alloca [8 x i8], align 8
  %y = alloca [16 x i8], align 8
  %x = alloca [4 x i8], align 4
  %_130 = alloca [32 x i8], align 8
  %t = alloca [32 x i8], align 8
  %_126 = alloca [16 x i8], align 8
  %_125 = alloca [16 x i8], align 8
  %_124 = alloca [16 x i8], align 8
  %_123 = alloca [16 x i8], align 8
  %args8 = alloca [64 x i8], align 8
  %_115 = alloca [8 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_105 = alloca [16 x i8], align 8
  %args6 = alloca [16 x i8], align 8
  %_103 = alloca [4 x i8], align 4
  %u = alloca [4 x i8], align 4
  %_94 = alloca [16 x i8], align 8
  %_93 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_84 = alloca [16 x i8], align 8
  %_83 = alloca [16 x i8], align 8
  %_82 = alloca [16 x i8], align 8
  %args4 = alloca [48 x i8], align 8
  %args3 = alloca [24 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_64 = alloca [8 x i8], align 8
  %_61 = alloca [24 x i8], align 8
  %_58 = alloca [8 x i8], align 8
  %e = alloca [16 x i8], align 8
  %_49 = alloca [16 x i8], align 8
  %iter = alloca [80 x i8], align 8
  %_44 = alloca [64 x i8], align 8
  %_43 = alloca [80 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_39 = alloca [16 x i8], align 8
  %args1 = alloca [32 x i8], align 8
  %_35 = alloca [3 x i8], align 1
  %_34 = alloca [3 x i8], align 1
  %v2 = alloca [3 x i8], align 1
  %_23 = alloca [16 x i8], align 8
  %_22 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_16 = alloca [1 x i8], align 1
  %_7 = alloca [3 x i8], align 1
  %_5 = alloca [3 x i8], align 1
  %_4 = alloca [3 x i8], align 1
  %_3 = alloca [8 x i8], align 8
  %vs = alloca [24 x i8], align 8
; call alloc::boxed::box_new_uninit
  %_1.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs31EPG3twprw_7structs(i64 1, i64 9) #24
  store ptr %_1.i, ptr %_3, align 8
  store i8 1, ptr %_4, align 1
  %8 = getelementptr inbounds i8, ptr %_4, i64 1
  store i8 2, ptr %8, align 1
  %9 = getelementptr inbounds i8, ptr %_4, i64 2
  store i8 3, ptr %9, align 1
; invoke core::hint::black_box::<u8>
  %_6 = invoke i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs31EPG3twprw_7structs(i8 0)
          to label %bb2 unwind label %cleanup

bb103:                                            ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxINtNtNtB4_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEEB1S_(ptr align 8 %_3) #21
          to label %bb104 unwind label %terminate

cleanup:                                          ; preds = %bb2, %start
  %10 = landingpad { ptr, i32 }
          cleanup
  %11 = extractvalue { ptr, i32 } %10, 0
  %12 = extractvalue { ptr, i32 } %10, 1
  store ptr %11, ptr %7, align 8
  %13 = getelementptr inbounds i8, ptr %7, i64 8
  store i32 %12, ptr %13, align 8
  br label %bb103

bb2:                                              ; preds = %start
  store i8 1, ptr %_5, align 1
  %14 = getelementptr inbounds i8, ptr %_5, i64 1
  store i8 %_6, ptr %14, align 1
  %15 = getelementptr inbounds i8, ptr %_5, i64 2
  store i8 9, ptr %15, align 1
; invoke <structs::Version as core::default::Default>::default
  %16 = invoke i24 @_RNvXs8_Cs31EPG3twprw_7structsNtB5_7VersionNtNtCsl10jNU3mE6R_4core7default7Default7defaultB5_()
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %bb2
  store i24 %16, ptr %6, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_7, ptr align 4 %6, i64 3, i1 false)
  %_246 = load ptr, ptr %_3, align 8
  %_258 = ptrtoint ptr %_246 to i64
  %_260 = and i64 %_258, 0
  %_261 = icmp eq i64 %_260, 0
  br i1 %_261, label %bb107, label %panic

bb107:                                            ; preds = %bb3
  %_263 = ptrtoint ptr %_246 to i64
  %_265 = icmp eq i64 %_263, 0
  %_266 = and i1 %_265, true
  %_267 = xor i1 %_266, true
  br i1 %_267, label %bb108, label %panic17

panic:                                            ; preds = %bb3
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 1, i64 %_258, ptr align 8 @alloc_9831a659bd72cbfbe3d0a44e7423f266) #27
  unreachable

bb108:                                            ; preds = %bb107
  %17 = getelementptr inbounds nuw %Version, ptr %_246, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %17, ptr align 1 %_4, i64 3, i1 false)
  %18 = getelementptr inbounds nuw %Version, ptr %_246, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %18, ptr align 1 %_5, i64 3, i1 false)
  %19 = getelementptr inbounds nuw %Version, ptr %_246, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %19, ptr align 1 %_7, i64 3, i1 false)
  %_2 = load ptr, ptr %_3, align 8
; call <[structs::Version]>::into_vec::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCs31EPG3twprw_7structs7Version8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %vs, ptr %_2, i64 3) #24
; invoke <alloc::vec::Vec<structs::Version> as core::ops::deref::DerefMut>::deref_mut
  %20 = invoke { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutBH_(ptr align 8 %vs)
          to label %bb5 unwind label %cleanup18

panic17:                                          ; preds = %bb107
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_9831a659bd72cbfbe3d0a44e7423f266) #27
  unreachable

bb102:                                            ; preds = %bb101, %cleanup18
; invoke core::ptr::drop_glue::<alloc::vec::Vec<structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEEB1a_(ptr align 8 %vs) #21
          to label %bb104 unwind label %terminate

cleanup18:                                        ; preds = %bb91, %bb97, %bb96, %bb95, %bb94, %bb110, %bb92, %bb90, %bb89, %bb88, %bb87, %bb86, %bb85, %bb84, %panic26, %bb82, %bb81, %bb80, %panic25, %panic24, %bb76, %panic23, %bb73, %bb72, %bb71, %bb70, %panic22, %bb67, %bb66, %bb65, %bb64, %bb63, %bb62, %bb61, %bb60, %bb59, %bb58, %bb57, %bb56, %bb55, %panic21, %bb53, %bb52, %bb51, %bb50, %bb49, %bb48, %bb47, %bb46, %bb45, %bb44, %bb43, %bb42, %bb41, %bb40, %bb39, %bb38, %panic20, %bb26, %bb20, %bb19, %bb18, %bb17, %bb16, %bb15, %bb14, %bb13, %bb12, %bb11, %bb10, %bb9, %bb8, %bb7, %bb6, %bb5, %bb108
  %21 = landingpad { ptr, i32 }
          cleanup
  %22 = extractvalue { ptr, i32 } %21, 0
  %23 = extractvalue { ptr, i32 } %21, 1
  store ptr %22, ptr %7, align 8
  %24 = getelementptr inbounds i8, ptr %7, i64 8
  store i32 %23, ptr %24, align 8
  br label %bb102

bb5:                                              ; preds = %bb108
  %_9.0 = extractvalue { ptr, i64 } %20, 0
  %_9.1 = extractvalue { ptr, i64 } %20, 1
; invoke <[structs::Version]>::sort
  invoke void @_RNvMNtCs7CppTae75M1_5alloc5sliceSNtCs31EPG3twprw_7structs7Version4sortBx_(ptr %_9.0, i64 %_9.1)
          to label %bb6 unwind label %cleanup18

bb6:                                              ; preds = %bb5
; invoke <alloc::vec::Vec<structs::Version> as core::ops::index::Index<usize>>::index
  %_17 = invoke ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexBH_(ptr align 8 %vs, i64 0, ptr align 8 @alloc_cb632dac8d2b8fdc3392de9a1bed186f)
          to label %bb7 unwind label %cleanup18

bb7:                                              ; preds = %bb6
; invoke <alloc::vec::Vec<structs::Version> as core::ops::index::Index<usize>>::index
  %_19 = invoke ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexBH_(ptr align 8 %vs, i64 1, ptr align 8 @alloc_7c1bc021357540848ef6cc658b8cab1e)
          to label %bb8 unwind label %cleanup18

bb8:                                              ; preds = %bb7
; invoke <structs::Version as core::cmp::PartialOrd>::lt
  %25 = invoke zeroext i1 @_RNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltB4_(ptr %_17, ptr %_19)
          to label %bb9 unwind label %cleanup18

bb9:                                              ; preds = %bb8
  %26 = zext i1 %25 to i8
  store i8 %26, ptr %_16, align 1
; invoke <core::fmt::rt::Argument>::new_debug::<alloc::vec::Vec<structs::Version>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEEB1u_(ptr sret([16 x i8]) align 8 %_22, ptr align 8 %vs)
          to label %bb10 unwind label %cleanup18

bb10:                                             ; preds = %bb9
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_23, ptr %_16)
          to label %bb11 unwind label %cleanup18

bb11:                                             ; preds = %bb10
  %27 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %27, ptr align 8 %_22, i64 16, i1 false)
  %28 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %28, ptr align 8 %_23, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %29 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args)
          to label %bb12 unwind label %cleanup18

bb12:                                             ; preds = %bb11
  %_12.0 = extractvalue { ptr, ptr } %29, 0
  %_12.1 = extractvalue { ptr, ptr } %29, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_12.0, ptr %_12.1)
          to label %bb13 unwind label %cleanup18

bb13:                                             ; preds = %bb12
; invoke <alloc::vec::Vec<structs::Version> as core::ops::index::Index<usize>>::index
  %_27 = invoke ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexBH_(ptr align 8 %vs, i64 2, ptr align 8 @alloc_def31162d169fa90e9c3b165e0c91340)
          to label %bb14 unwind label %cleanup18

bb14:                                             ; preds = %bb13
  %30 = load i8, ptr %_27, align 1
  store i8 %30, ptr %v2, align 1
  %31 = getelementptr inbounds i8, ptr %_27, i64 1
  %32 = load i8, ptr %31, align 1
  %33 = getelementptr inbounds i8, ptr %v2, i64 1
  store i8 %32, ptr %33, align 1
  %34 = getelementptr inbounds i8, ptr %v2, i64 2
  store i8 7, ptr %34, align 1
; invoke <alloc::vec::Vec<structs::Version> as core::ops::index::Index<usize>>::index
  %_36 = invoke ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexBH_(ptr align 8 %vs, i64 1, ptr align 8 @alloc_30553d7ac0d67b30b55024312d9ec03d)
          to label %bb15 unwind label %cleanup18

bb15:                                             ; preds = %bb14
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_35, ptr align 1 %_36, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 1 %v2, i64 3, i1 false)
  %35 = load i24, ptr %5, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %4, ptr align 1 %_35, i64 3, i1 false)
  %36 = load i24, ptr %4, align 4
; invoke <structs::Version as core::cmp::Ord>::max
  %37 = invoke i24 @_RNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxB4_(i24 %35, i24 %36)
          to label %bb16 unwind label %cleanup18

bb16:                                             ; preds = %bb15
  store i24 %37, ptr %3, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_34, ptr align 4 %3, i64 3, i1 false)
; invoke <core::fmt::rt::Argument>::new_debug::<structs::Version>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCs31EPG3twprw_7structs7VersionEBX_(ptr sret([16 x i8]) align 8 %_39, ptr %v2)
          to label %bb17 unwind label %cleanup18

bb17:                                             ; preds = %bb16
; invoke <core::fmt::rt::Argument>::new_debug::<structs::Version>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCs31EPG3twprw_7structs7VersionEBX_(ptr sret([16 x i8]) align 8 %_40, ptr %_34)
          to label %bb18 unwind label %cleanup18

bb18:                                             ; preds = %bb17
  %38 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %38, ptr align 8 %_39, i64 16, i1 false)
  %39 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %39, ptr align 8 %_40, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %40 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args1)
          to label %bb19 unwind label %cleanup18

bb19:                                             ; preds = %bb18
  %_30.0 = extractvalue { ptr, ptr } %40, 0
  %_30.1 = extractvalue { ptr, ptr } %40, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_30.0, ptr %_30.1)
          to label %bb20 unwind label %cleanup18

bb20:                                             ; preds = %bb19
  %41 = getelementptr inbounds nuw { ptr, i64 }, ptr %_44, i64 0
  store ptr @alloc_a91eb42b8cfa99966a1fda64ebf3c985, ptr %41, align 8
  %42 = getelementptr inbounds i8, ptr %41, i64 8
  store i64 9, ptr %42, align 8
  %43 = getelementptr inbounds nuw { ptr, i64 }, ptr %_44, i64 1
  store ptr @alloc_102ac9ba096fdcfef4b2af1af8a74ea6, ptr %43, align 8
  %44 = getelementptr inbounds i8, ptr %43, i64 8
  store i64 11, ptr %44, align 8
  %45 = getelementptr inbounds nuw { ptr, i64 }, ptr %_44, i64 2
  store ptr @alloc_612e8d03c1ccc604ca0ae564b6c95f0a, ptr %45, align 8
  %46 = getelementptr inbounds i8, ptr %45, i64 8
  store i64 10, ptr %46, align 8
  %47 = getelementptr inbounds nuw { ptr, i64 }, ptr %_44, i64 3
  store ptr @alloc_6b1fa8ed27b8eecb9d228eafb96b6d4d, ptr %47, align 8
  %48 = getelementptr inbounds i8, ptr %47, i64 8
  store i64 14, ptr %48, align 8
; invoke <[&str; 4] as core::iter::traits::collect::IntoIterator>::into_iter
  invoke void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARej4_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs31EPG3twprw_7structs(ptr sret([80 x i8]) align 8 %_43, ptr align 8 %_44)
          to label %bb21 unwind label %cleanup18

bb21:                                             ; preds = %bb20
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter, ptr align 8 %_43, i64 80, i1 false)
  br label %bb22

bb22:                                             ; preds = %bb34, %bb21
; invoke <core::array::iter::IntoIter<&str, 4> as core::iter::traits::iterator::Iterator>::next
  %49 = invoke { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj4_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs31EPG3twprw_7structs(ptr align 8 %iter)
          to label %bb23 unwind label %cleanup19

bb101:                                            ; preds = %bb100, %cleanup19
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<&str, 4>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterReKj4_EECs31EPG3twprw_7structs(ptr align 8 %iter) #21
          to label %bb102 unwind label %terminate

cleanup19:                                        ; preds = %bb34, %bb27, %bb25, %bb22
  %50 = landingpad { ptr, i32 }
          cleanup
  %51 = extractvalue { ptr, i32 } %50, 0
  %52 = extractvalue { ptr, i32 } %50, 1
  store ptr %51, ptr %7, align 8
  %53 = getelementptr inbounds i8, ptr %7, i64 8
  store i32 %52, ptr %53, align 8
  br label %bb101

bb23:                                             ; preds = %bb22
  %54 = extractvalue { ptr, i64 } %49, 0
  %55 = extractvalue { ptr, i64 } %49, 1
  store ptr %54, ptr %_49, align 8
  %56 = getelementptr inbounds i8, ptr %_49, i64 8
  store i64 %55, ptr %56, align 8
  %57 = load ptr, ptr %_49, align 8
  %58 = getelementptr inbounds i8, ptr %_49, i64 8
  %59 = load i64, ptr %58, align 8
  %60 = ptrtoint ptr %57 to i64
  %61 = icmp eq i64 %60, 0
  %_51 = select i1 %61, i64 0, i64 1
  %62 = trunc nuw i64 %_51 to i1
  br i1 %62, label %bb25, label %bb26

bb25:                                             ; preds = %bb23
  %63 = load ptr, ptr %_49, align 8
  %64 = getelementptr inbounds i8, ptr %_49, i64 8
  %65 = load i64, ptr %64, align 8
  store ptr %63, ptr %e, align 8, !captures !349
  %66 = getelementptr inbounds i8, ptr %e, i64 8
  store i64 %65, ptr %66, align 8
  %67 = load ptr, ptr %e, align 8
  %68 = getelementptr inbounds i8, ptr %e, i64 8
  %69 = load i64, ptr %68, align 8
; invoke core::hint::black_box::<&str>
  %70 = invoke { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxReECs31EPG3twprw_7structs(ptr %67, i64 %69)
          to label %bb27 unwind label %cleanup19

bb26:                                             ; preds = %bb23
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<&str, 4>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterReKj4_EECs31EPG3twprw_7structs(ptr align 8 %iter)
          to label %bb35 unwind label %cleanup18

bb35:                                             ; preds = %bb26
  br label %bb36

bb36:                                             ; preds = %bb35
  br label %bb37

bb37:                                             ; preds = %bb36
  %71 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 6, i32 1)
  %_80.0 = extractvalue { i32, i1 } %71, 0
  %_80.1 = extractvalue { i32, i1 } %71, 1
  br i1 %_80.1, label %panic20, label %bb38

bb38:                                             ; preds = %bb37
  store ptr @alloc_94d761dacdaa8992553f7036ea7ad2ab, ptr %args3, align 8
  %72 = getelementptr inbounds i8, ptr %args3, i64 8
  store ptr @alloc_5d94ea03d8df86d72a13735ba104914b, ptr %72, align 8
  %73 = getelementptr inbounds i8, ptr %args3, i64 16
  store ptr @alloc_fc18870ebd3bffa18e161a5a63775070, ptr %73, align 8
  %_226 = load ptr, ptr %args3, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<structs::Color>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCs31EPG3twprw_7structs5ColorEBX_(ptr sret([16 x i8]) align 8 %_82, ptr %_226)
          to label %bb39 unwind label %cleanup18

panic20:                                          ; preds = %bb37
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_718d190fb84d683e104eb3024ff19535) #28
          to label %unreachable unwind label %cleanup18

unreachable:                                      ; preds = %panic26, %panic25, %panic24, %panic23, %panic22, %panic21, %panic20
  unreachable

bb39:                                             ; preds = %bb38
  %74 = getelementptr inbounds i8, ptr %args3, i64 8
  %_227 = load ptr, ptr %74, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_83, ptr %_227)
          to label %bb40 unwind label %cleanup18

bb40:                                             ; preds = %bb39
  %75 = getelementptr inbounds i8, ptr %args3, i64 16
  %_228 = load ptr, ptr %75, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_84, ptr align 4 %_228)
          to label %bb41 unwind label %cleanup18

bb41:                                             ; preds = %bb40
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_82, i64 16, i1 false)
  %77 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %77, ptr align 8 %_83, i64 16, i1 false)
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_84, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 3>
  %79 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs31EPG3twprw_7structs(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args4)
          to label %bb42 unwind label %cleanup18

bb42:                                             ; preds = %bb41
  %_71.0 = extractvalue { ptr, ptr } %79, 0
  %_71.1 = extractvalue { ptr, ptr } %79, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
          to label %bb43 unwind label %cleanup18

bb43:                                             ; preds = %bb42
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_93, ptr align 8 @alloc_9a23790d84995f493af2397c695bbae0)
          to label %bb44 unwind label %cleanup18

bb44:                                             ; preds = %bb43
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_94, ptr align 8 @alloc_ee2a3d99accaa3cec7cc99bf20f81916)
          to label %bb45 unwind label %cleanup18

bb45:                                             ; preds = %bb44
  %80 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %80, ptr align 8 %_93, i64 16, i1 false)
  %81 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %81, ptr align 8 %_94, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %82 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5)
          to label %bb46 unwind label %cleanup18

bb46:                                             ; preds = %bb45
  %_88.0 = extractvalue { ptr, ptr } %82, 0
  %_88.1 = extractvalue { ptr, ptr } %82, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_88.0, ptr %_88.1)
          to label %bb47 unwind label %cleanup18

bb47:                                             ; preds = %bb46
; invoke core::hint::black_box::<f32>
  %_98 = invoke float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs31EPG3twprw_7structs(float 1.000000e+00)
          to label %bb48 unwind label %cleanup18

bb48:                                             ; preds = %bb47
  store float %_98, ptr %u, align 4
  %83 = load i32, ptr %u, align 4
  store i32 %83, ptr %_103, align 4
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexmEB7_(ptr sret([16 x i8]) align 8 %_105, ptr align 4 %_103)
          to label %bb49 unwind label %cleanup18

bb49:                                             ; preds = %bb48
  %84 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %84, ptr align 8 %_105, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %85 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_c3b1946345a8630bc4d2f804c02f8ade, ptr align 8 %args6)
          to label %bb50 unwind label %cleanup18

bb50:                                             ; preds = %bb49
  %_100.0 = extractvalue { ptr, ptr } %85, 0
  %_100.1 = extractvalue { ptr, ptr } %85, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_100.0, ptr %_100.1)
          to label %bb51 unwind label %cleanup18

bb51:                                             ; preds = %bb50
; invoke <[u8]>::iter
  %86 = invoke { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterB4_(ptr @_RNvCs31EPG3twprw_7structs5TABLE, i64 4)
          to label %bb52 unwind label %cleanup18

bb52:                                             ; preds = %bb51
  %_118.0 = extractvalue { ptr, ptr } %86, 0
  %_118.1 = extractvalue { ptr, ptr } %86, 1
; invoke <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::map::<usize, structs::main::{closure#0}>
  %87 = invoke { ptr, ptr } @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator3mapjNCNvCs31EPG3twprw_7structs4main0EB1z_(ptr %_118.0, ptr %_118.1)
          to label %bb53 unwind label %cleanup18

bb53:                                             ; preds = %bb52
  %_117.0 = extractvalue { ptr, ptr } %87, 0
  %_117.1 = extractvalue { ptr, ptr } %87, 1
; invoke <core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}> as core::iter::traits::iterator::Iterator>::sum::<usize>
  %_116 = invoke i64 @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0ENtNtNtBa_6traits8iterator8Iterator3sumjEB1n_(ptr %_117.0, ptr %_117.1)
          to label %bb54 unwind label %cleanup18

bb54:                                             ; preds = %bb53
  %88 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_116, i64 4)
  %_121.0 = extractvalue { i64, i1 } %88, 0
  %_121.1 = extractvalue { i64, i1 } %88, 1
  br i1 %_121.1, label %panic21, label %bb55

bb55:                                             ; preds = %bb54
  store i64 %_121.0, ptr %_115, align 8
  store ptr @alloc_ee2a3d99accaa3cec7cc99bf20f81916, ptr %args7, align 8
  %89 = getelementptr inbounds i8, ptr %args7, i64 8
  store ptr @_RNvCs31EPG3twprw_7structs8GREETING, ptr %89, align 8
  %90 = getelementptr inbounds i8, ptr %args7, i64 16
  store ptr @_RNvCs31EPG3twprw_7structs5TABLE, ptr %90, align 8
  %91 = getelementptr inbounds i8, ptr %args7, i64 24
  store ptr %_115, ptr %91, align 8
  %_232 = load ptr, ptr %args7, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_123, ptr align 8 %_232)
          to label %bb56 unwind label %cleanup18

panic21:                                          ; preds = %bb54
; invoke core::panicking::panic_const::panic_const_mul_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_0fde3b0be97b88d90da8b15d980ef1c1) #28
          to label %unreachable unwind label %cleanup18

bb56:                                             ; preds = %bb55
  %92 = getelementptr inbounds i8, ptr %args7, i64 8
  %_233 = load ptr, ptr %92, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_124, ptr align 8 %_233)
          to label %bb57 unwind label %cleanup18

bb57:                                             ; preds = %bb56
  %93 = getelementptr inbounds i8, ptr %args7, i64 16
  %_234 = load ptr, ptr %93, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<[u8; 4]>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAhj4_ECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_125, ptr %_234)
          to label %bb58 unwind label %cleanup18

bb58:                                             ; preds = %bb57
  %94 = getelementptr inbounds i8, ptr %args7, i64 24
  %_235 = load ptr, ptr %94, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_126, ptr align 8 %_235)
          to label %bb59 unwind label %cleanup18

bb59:                                             ; preds = %bb58
  %95 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %95, ptr align 8 %_123, i64 16, i1 false)
  %96 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %96, ptr align 8 %_124, i64 16, i1 false)
  %97 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %97, ptr align 8 %_125, i64 16, i1 false)
  %98 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %98, ptr align 8 %_126, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 4>
  %99 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs31EPG3twprw_7structs(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args8)
          to label %bb60 unwind label %cleanup18

bb60:                                             ; preds = %bb59
  %_109.0 = extractvalue { ptr, ptr } %99, 0
  %_109.1 = extractvalue { ptr, ptr } %99, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_109.0, ptr %_109.1)
          to label %bb61 unwind label %cleanup18

bb61:                                             ; preds = %bb60
  %100 = getelementptr inbounds i8, ptr %_130, i64 16
  store i32 1, ptr %100, align 8
  store ptr @alloc_3827bbb606bbdb0f0c926011c14ccc34, ptr %_130, align 8
  %101 = getelementptr inbounds i8, ptr %_130, i64 8
  store i64 1, ptr %101, align 8
  %102 = getelementptr inbounds i8, ptr %_130, i64 24
  store double 2.500000e+00, ptr %102, align 8
; invoke core::hint::black_box::<(i32, &str, f64)>
  invoke void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxTlRedEECs31EPG3twprw_7structs(ptr sret([32 x i8]) align 8 %t, ptr align 8 %_130)
          to label %bb62 unwind label %cleanup18

bb62:                                             ; preds = %bb61
  %103 = getelementptr inbounds i8, ptr %t, i64 16
  %104 = load i32, ptr %103, align 8
  store i32 %104, ptr %x, align 4
  %105 = load ptr, ptr %t, align 8
  %106 = getelementptr inbounds i8, ptr %t, i64 8
  %107 = load i64, ptr %106, align 8
  store ptr %105, ptr %y, align 8, !captures !349
  %108 = getelementptr inbounds i8, ptr %y, i64 8
  store i64 %107, ptr %108, align 8
  %109 = getelementptr inbounds i8, ptr %t, i64 24
  %110 = load double, ptr %109, align 8
  store double %110, ptr %z, align 8
  store ptr %x, ptr %args9, align 8
  %111 = getelementptr inbounds i8, ptr %args9, i64 8
  store ptr %y, ptr %111, align 8
  %112 = getelementptr inbounds i8, ptr %args9, i64 16
  store ptr %z, ptr %112, align 8
  %113 = getelementptr inbounds i8, ptr %args9, i64 24
  store ptr %t, ptr %113, align 8
  %_236 = load ptr, ptr %args9, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_142, ptr align 4 %_236)
          to label %bb63 unwind label %cleanup18

bb63:                                             ; preds = %bb62
  %114 = getelementptr inbounds i8, ptr %args9, i64 8
  %_237 = load ptr, ptr %114, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_143, ptr align 8 %_237)
          to label %bb64 unwind label %cleanup18

bb64:                                             ; preds = %bb63
  %115 = getelementptr inbounds i8, ptr %args9, i64 16
  %_238 = load ptr, ptr %115, align 8
; invoke <core::fmt::rt::Argument>::new_display::<f64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_144, ptr align 8 %_238)
          to label %bb65 unwind label %cleanup18

bb65:                                             ; preds = %bb64
  %116 = getelementptr inbounds i8, ptr %args9, i64 24
  %_239 = load ptr, ptr %116, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<(i32, &str, f64)>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTlRedEECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_145, ptr align 8 %_239)
          to label %bb66 unwind label %cleanup18

bb66:                                             ; preds = %bb65
  %117 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %117, ptr align 8 %_142, i64 16, i1 false)
  %118 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %118, ptr align 8 %_143, i64 16, i1 false)
  %119 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %119, ptr align 8 %_144, i64 16, i1 false)
  %120 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %120, ptr align 8 %_145, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 4>
  %121 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs31EPG3twprw_7structs(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args10)
          to label %bb67 unwind label %cleanup18

bb67:                                             ; preds = %bb66
  %_135.0 = extractvalue { ptr, ptr } %121, 0
  %_135.1 = extractvalue { ptr, ptr } %121, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_135.0, ptr %_135.1)
          to label %bb68 unwind label %cleanup18

bb68:                                             ; preds = %bb67
  call void @llvm.memset.p0.i64(ptr align 1 %_149, i8 1, i64 3, i1 false)
  %122 = getelementptr inbounds nuw [3 x i8], ptr %arr, i64 0
  %123 = getelementptr inbounds nuw [3 x i8], ptr %arr, i64 2
  br label %repeat_loop_header

repeat_loop_header:                               ; preds = %repeat_loop_body, %bb68
  %124 = phi ptr [ %122, %bb68 ], [ %126, %repeat_loop_body ]
  %125 = icmp ne ptr %124, %123
  br i1 %125, label %repeat_loop_body, label %repeat_loop_next

repeat_loop_body:                                 ; preds = %repeat_loop_header
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %124, ptr align 1 %_149, i64 3, i1 false)
  %126 = getelementptr inbounds [3 x i8], ptr %124, i64 1
  br label %repeat_loop_header

repeat_loop_next:                                 ; preds = %repeat_loop_header
  br label %bb69

bb69:                                             ; preds = %repeat_loop_next
  %_161 = getelementptr inbounds nuw [3 x i8], ptr %arr, i64 0
  %127 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 2, i64 3)
  %_164.0 = extractvalue { i64, i1 } %127, 0
  %_164.1 = extractvalue { i64, i1 } %127, 1
  br i1 %_164.1, label %panic22, label %bb70

bb70:                                             ; preds = %bb69
  store i64 %_164.0, ptr %_155, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<[[u8; 3]; 2]>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAAhj3_j2_ECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_166, ptr %arr)
          to label %bb71 unwind label %cleanup18

panic22:                                          ; preds = %bb69
; invoke core::panicking::panic_const::panic_const_mul_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_4d1a664ed2308dd6e6eda90c4f1f0189) #28
          to label %unreachable unwind label %cleanup18

bb71:                                             ; preds = %bb70
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_167, ptr align 8 %_155)
          to label %bb72 unwind label %cleanup18

bb72:                                             ; preds = %bb71
  %128 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %128, ptr align 8 %_166, i64 16, i1 false)
  %129 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %129, ptr align 8 %_167, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %130 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args11)
          to label %bb73 unwind label %cleanup18

bb73:                                             ; preds = %bb72
  %_151.0 = extractvalue { ptr, ptr } %130, 0
  %_151.1 = extractvalue { ptr, ptr } %130, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_151.0, ptr %_151.1)
          to label %bb74 unwind label %cleanup18

bb74:                                             ; preds = %bb73
  store i32 0, ptr %n, align 4
  br label %bb75

bb75:                                             ; preds = %bb77, %bb74
  %131 = load i32, ptr %n, align 4
  %132 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %131, i32 1)
  %_172.0 = extractvalue { i32, i1 } %132, 0
  %_172.1 = extractvalue { i32, i1 } %132, 1
  br i1 %_172.1, label %panic23, label %bb76

bb76:                                             ; preds = %bb75
  store i32 %_172.0, ptr %n, align 4
  %_174 = load i32, ptr %n, align 4
; invoke core::hint::black_box::<i32>
  %_175 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs31EPG3twprw_7structs(i32 5)
          to label %bb77 unwind label %cleanup18

panic23:                                          ; preds = %bb75
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_d979a3f5c1d7fd2495d3b80b472a1351) #28
          to label %unreachable unwind label %cleanup18

bb77:                                             ; preds = %bb76
  %_173 = icmp eq i32 %_174, %_175
  br i1 %_173, label %bb78, label %bb75

bb78:                                             ; preds = %bb77
  %_176 = load i32, ptr %n, align 4
  %133 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %_176, i32 2)
  %_177.0 = extractvalue { i32, i1 } %133, 0
  %_177.1 = extractvalue { i32, i1 } %133, 1
  br i1 %_177.1, label %panic24, label %bb79

bb79:                                             ; preds = %bb78
  store i32 %_177.0, ptr %label, align 4
  %134 = load i32, ptr %label, align 4
  %135 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %134, i32 1)
  %_178.0 = extractvalue { i32, i1 } %135, 0
  %_178.1 = extractvalue { i32, i1 } %135, 1
  br i1 %_178.1, label %panic25, label %bb80

panic24:                                          ; preds = %bb78
; invoke core::panicking::panic_const::panic_const_mul_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_bd5bcfb13d65237a2c081ec4304fc906) #28
          to label %unreachable unwind label %cleanup18

bb80:                                             ; preds = %bb79
  store i32 %_178.0, ptr %label, align 4
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_184, ptr align 4 %label)
          to label %bb81 unwind label %cleanup18

panic25:                                          ; preds = %bb79
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_c45a3435f86173cc8075b6cb1218b25d) #28
          to label %unreachable unwind label %cleanup18

bb81:                                             ; preds = %bb80
  %136 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %136, ptr align 8 %_184, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %137 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args12)
          to label %bb82 unwind label %cleanup18

bb82:                                             ; preds = %bb81
  %_180.0 = extractvalue { ptr, ptr } %137, 0
  %_180.1 = extractvalue { ptr, ptr } %137, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_180.0, ptr %_180.1)
          to label %bb83 unwind label %cleanup18

bb83:                                             ; preds = %bb82
  %138 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 5, i32 2)
  %_189.0 = extractvalue { i32, i1 } %138, 0
  %_189.1 = extractvalue { i32, i1 } %138, 1
  br i1 %_189.1, label %panic26, label %bb84

bb84:                                             ; preds = %bb83
  store i32 %_189.0, ptr %shadow, align 4
  store ptr @alloc_6c342f467cee9eb46aaa013cf1ccd49c, ptr %shadow13, align 8, !captures !349
  %139 = getelementptr inbounds i8, ptr %shadow13, i64 8
  store i64 5, ptr %139, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_196, ptr align 8 %shadow13)
          to label %bb85 unwind label %cleanup18

panic26:                                          ; preds = %bb83
; invoke core::panicking::panic_const::panic_const_mul_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_427f5753095982aa1d9009267af3847a) #28
          to label %unreachable unwind label %cleanup18

bb85:                                             ; preds = %bb84
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_196, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %141 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args14)
          to label %bb86 unwind label %cleanup18

bb86:                                             ; preds = %bb85
  %_192.0 = extractvalue { ptr, ptr } %141, 0
  %_192.1 = extractvalue { ptr, ptr } %141, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_192.0, ptr %_192.1)
          to label %bb87 unwind label %cleanup18

bb87:                                             ; preds = %bb86
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_204, ptr align 4 %shadow)
          to label %bb88 unwind label %cleanup18

bb88:                                             ; preds = %bb87
  %142 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %142, ptr align 8 %_204, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %143 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args15)
          to label %bb89 unwind label %cleanup18

bb89:                                             ; preds = %bb88
  %_200.0 = extractvalue { ptr, ptr } %143, 0
  %_200.1 = extractvalue { ptr, ptr } %143, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_200.0, ptr %_200.1)
          to label %bb90 unwind label %cleanup18

bb90:                                             ; preds = %bb89
; invoke <structs::Version as core::default::Default>::default
  %144 = invoke i24 @_RNvXs8_Cs31EPG3twprw_7structsNtB5_7VersionNtNtCsl10jNU3mE6R_4core7default7Default7defaultB5_()
          to label %bb91 unwind label %cleanup18

bb91:                                             ; preds = %bb90
  store i24 %144, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_208, ptr align 4 %2, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %1, ptr align 1 %_208, i64 3, i1 false)
  %145 = load i24, ptr %1, align 4
  store i24 %145, ptr %0, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %x.i, ptr align 4 %0, i64 3, i1 false)
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; invoke alloc::boxed::box_new_uninit
  %_3.i3233 = invoke ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs31EPG3twprw_7structs(i64 1, i64 3) #24
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtCs31EPG3twprw_7structs7VersionE3newBG_.exit unwind label %cleanup18

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtCs31EPG3twprw_7structs7VersionE3newBG_.exit: ; preds = %bb91
  store i8 0, ptr %_4.i, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_3.i3233, ptr align 1 %x.i, i64 3, i1 false)
  br label %bb92

bb92:                                             ; preds = %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxNtCs31EPG3twprw_7structs7VersionE3newBG_.exit
; invoke <alloc::boxed::Box<structs::Version>>::into_raw
  %raw = invoke ptr @_RNvMs6_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtCs31EPG3twprw_7structs7VersionE8into_rawBJ_(ptr %_3.i3233)
          to label %bb93 unwind label %cleanup18

bb93:                                             ; preds = %bb92
  %_253 = ptrtoint ptr %raw to i64
  %_255 = and i64 %_253, 0
  %_256 = icmp eq i64 %_255, 0
  br i1 %_256, label %bb106, label %panic27

bb106:                                            ; preds = %bb93
  %_269 = ptrtoint ptr %raw to i64
  %_271 = icmp eq i64 %_269, 0
  %_272 = and i1 %_271, true
  %_273 = xor i1 %_272, true
  br i1 %_273, label %bb109, label %panic28

panic27:                                          ; preds = %bb93
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 1, i64 %_253, ptr align 8 @alloc_cfd9774bc6691391e2b423b9909d66ce) #27
  unreachable

bb109:                                            ; preds = %bb106
  store i8 9, ptr %raw, align 1
  %_248 = ptrtoint ptr %raw to i64
  %_250 = and i64 %_248, 0
  %_251 = icmp eq i64 %_250, 0
  br i1 %_251, label %bb105, label %panic29

panic28:                                          ; preds = %bb106
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_cfd9774bc6691391e2b423b9909d66ce) #27
  unreachable

bb105:                                            ; preds = %bb109
  %_275 = ptrtoint ptr %raw to i64
  %_276 = icmp eq i64 %_275, 0
  %_277 = and i1 %_276, true
  %_278 = xor i1 %_277, true
  br i1 %_278, label %bb110, label %panic30

panic29:                                          ; preds = %bb109
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 1, i64 %_248, ptr align 8 @alloc_35c18a3d99c204eafc413a93d7c0b667) #27
  unreachable

bb110:                                            ; preds = %bb105
; invoke <core::fmt::rt::Argument>::new_debug::<structs::Version>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtCs31EPG3twprw_7structs7VersionEBX_(ptr sret([16 x i8]) align 8 %_215, ptr %raw)
          to label %bb94 unwind label %cleanup18

panic30:                                          ; preds = %bb105
; call core::panicking::panic_null_reference_constructed
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking32panic_null_reference_constructed(ptr align 8 @alloc_35c18a3d99c204eafc413a93d7c0b667) #27
  unreachable

bb94:                                             ; preds = %bb110
  %146 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %146, ptr align 8 %_215, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %147 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args16)
          to label %bb95 unwind label %cleanup18

bb95:                                             ; preds = %bb94
  %_211.0 = extractvalue { ptr, ptr } %147, 0
  %_211.1 = extractvalue { ptr, ptr } %147, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_211.0, ptr %_211.1)
          to label %bb96 unwind label %cleanup18

bb96:                                             ; preds = %bb95
; invoke <alloc::boxed::Box<structs::Version>>::from_raw
  %_219 = invoke ptr @_RNvMs6_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtCs31EPG3twprw_7structs7VersionE8from_rawBJ_(ptr %raw)
          to label %bb97 unwind label %cleanup18

bb97:                                             ; preds = %bb96
; invoke core::mem::drop::<alloc::boxed::Box<structs::Version>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc5boxed3BoxNtCs31EPG3twprw_7structs7VersionEEB17_(ptr %_219)
          to label %bb98 unwind label %cleanup18

bb98:                                             ; preds = %bb97
; call core::ptr::drop_glue::<alloc::vec::Vec<structs::Version>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEEB1a_(ptr align 8 %vs)
  ret void

bb27:                                             ; preds = %bb25
  %_62.0 = extractvalue { ptr, i64 } %70, 0
  %_62.1 = extractvalue { ptr, i64 } %70, 1
; invoke structs::tokenize
  invoke void @_RNvCs31EPG3twprw_7structs8tokenize(ptr sret([24 x i8]) align 8 %_61, ptr %_62.0, i64 %_62.1)
          to label %bb28 unwind label %cleanup19

bb28:                                             ; preds = %bb27
; invoke <alloc::vec::Vec<structs::Token> as core::ops::deref::Deref>::deref
  %148 = invoke { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefBH_(ptr align 8 %_61)
          to label %bb29 unwind label %cleanup31

bb100:                                            ; preds = %cleanup31
; invoke core::ptr::drop_glue::<alloc::vec::Vec<structs::Token>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs5TokenEEB1a_(ptr align 8 %_61) #21
          to label %bb101 unwind label %terminate

cleanup31:                                        ; preds = %bb33, %bb32, %bb31, %bb30, %bb29, %bb28
  %149 = landingpad { ptr, i32 }
          cleanup
  %150 = extractvalue { ptr, i32 } %149, 0
  %151 = extractvalue { ptr, i32 } %149, 1
  store ptr %150, ptr %7, align 8
  %152 = getelementptr inbounds i8, ptr %7, i64 8
  store i32 %151, ptr %152, align 8
  br label %bb100

bb29:                                             ; preds = %bb28
  %_59.0 = extractvalue { ptr, i64 } %148, 0
  %_59.1 = extractvalue { ptr, i64 } %148, 1
  store i64 0, ptr %_64, align 8
; invoke structs::eval
  %153 = invoke double @_RNvCs31EPG3twprw_7structs4eval(ptr align 8 %_59.0, i64 %_59.1, ptr align 8 %_64)
          to label %bb30 unwind label %cleanup31

bb30:                                             ; preds = %bb29
  store double %153, ptr %_58, align 8
; invoke <core::fmt::rt::Argument>::new_display::<&str>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_66, ptr align 8 %e)
          to label %bb31 unwind label %cleanup31

bb31:                                             ; preds = %bb30
; invoke <core::fmt::rt::Argument>::new_display::<f64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_67, ptr align 8 %_58)
          to label %bb32 unwind label %cleanup31

bb32:                                             ; preds = %bb31
  %154 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %154, ptr align 8 %_66, i64 16, i1 false)
  %155 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %155, ptr align 8 %_67, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<9, 2>
  %156 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj9_Kj2_ECs31EPG3twprw_7structs(ptr @alloc_d18c4256912d8668c4a6fabc64706525, ptr align 8 %args2)
          to label %bb33 unwind label %cleanup31

bb33:                                             ; preds = %bb32
  %_54.0 = extractvalue { ptr, ptr } %156, 0
  %_54.1 = extractvalue { ptr, ptr } %156, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_54.0, ptr %_54.1)
          to label %bb34 unwind label %cleanup31

bb34:                                             ; preds = %bb33
; invoke core::ptr::drop_glue::<alloc::vec::Vec<structs::Token>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs5TokenEEB1a_(ptr align 8 %_61)
          to label %bb22 unwind label %cleanup19

terminate:                                        ; preds = %bb103, %bb102, %bb101, %bb100
  %157 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb24:                                             ; No predecessors!
  unreachable

bb104:                                            ; preds = %bb103, %bb102
  %158 = load ptr, ptr %7, align 8
  %159 = getelementptr inbounds i8, ptr %7, i64 8
  %160 = load i32, ptr %159, align 8
  %161 = insertvalue { ptr, i32 } poison, ptr %158, 0
  %162 = insertvalue { ptr, i32 } %161, i32 %160, 1
  resume { ptr, i32 } %162
}

; structs::term
; Function Attrs: nonlazybind uwtable
define internal double @_RNvCs31EPG3twprw_7structs4term(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos) unnamed_addr #1 !guid !461 {
start:
  %v = alloca [8 x i8], align 8
; call structs::atom
  %0 = call double @_RNvCs31EPG3twprw_7structs4atom(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos)
  store double %0, ptr %v, align 8
  br label %bb1

bb1:                                              ; preds = %bb9, %bb7, %start
  %_5 = load i64, ptr %pos, align 8
  %_4 = icmp ult i64 %_5, %t.1
  br i1 %_4, label %bb2, label %bb11

bb11:                                             ; preds = %bb4, %bb3, %bb1
  %_0 = load double, ptr %v, align 8
  ret double %_0

bb2:                                              ; preds = %bb1
  %_7 = load i64, ptr %pos, align 8
  %_9 = icmp ult i64 %_7, %t.1
  br i1 %_9, label %bb3, label %panic

bb3:                                              ; preds = %bb2
  %1 = getelementptr inbounds nuw %Token, ptr %t.0, i64 %_7
  %2 = load i32, ptr %1, align 8
  %_10 = zext i32 %2 to i64
  %3 = icmp eq i64 %_10, 1
  br i1 %3, label %bb4, label %bb11

panic:                                            ; preds = %bb2
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_7, i64 %t.1, ptr align 8 @alloc_7f0421388533e360fd6edeaab0fdb02f) #26
  unreachable

bb4:                                              ; preds = %bb3
  %4 = getelementptr inbounds nuw %Token, ptr %t.0, i64 %_7
  %5 = getelementptr inbounds i8, ptr %4, i64 4
  %6 = load i32, ptr %5, align 4
  switch i32 %6, label %bb11 [
    i32 42, label %bb6
    i32 47, label %bb5
  ]

bb6:                                              ; preds = %bb4
  %7 = load i64, ptr %pos, align 8
  %_11.0 = add i64 %7, 1
  %_11.1 = icmp ult i64 %_11.0, %7
  br i1 %_11.1, label %panic1, label %bb7

bb5:                                              ; preds = %bb4
  %8 = load i64, ptr %pos, align 8
  %_13.0 = add i64 %8, 1
  %_13.1 = icmp ult i64 %_13.0, %8
  br i1 %_13.1, label %panic2, label %bb9

bb7:                                              ; preds = %bb6
  store i64 %_11.0, ptr %pos, align 8
; call structs::atom
  %_12 = call double @_RNvCs31EPG3twprw_7structs4atom(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos)
  %9 = load double, ptr %v, align 8
  %10 = fmul double %9, %_12
  store double %10, ptr %v, align 8
  br label %bb1

panic1:                                           ; preds = %bb6
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_18c2cad16391a89dafdc59d2b3cd018f) #26
  unreachable

bb9:                                              ; preds = %bb5
  store i64 %_13.0, ptr %pos, align 8
; call structs::atom
  %_14 = call double @_RNvCs31EPG3twprw_7structs4atom(ptr align 8 %t.0, i64 %t.1, ptr align 8 %pos)
  %11 = load double, ptr %v, align 8
  %12 = fdiv double %11, %_14
  store double %12, ptr %v, align 8
  br label %bb1

panic2:                                           ; preds = %bb5
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_3da697690ecb5212e940b5e4cb1b788f) #26
  unreachable
}

; structs::tokenize
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCs31EPG3twprw_7structs8tokenize(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !462 {
start:
  %e.i = alloca [1 x i8], align 1
  %0 = alloca [16 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %_51 = alloca [16 x i8], align 8
  %_47 = alloca [16 x i8], align 8
  %_39 = alloca [24 x i8], align 8
  %_36 = alloca [16 x i8], align 8
  %_34 = alloca [16 x i8], align 8
  %out = alloca [24 x i8], align 8
  %i = alloca [8 x i8], align 8
  %cs = alloca [24 x i8], align 8
; call <str>::chars
  %1 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core3stre5charsCs31EPG3twprw_7structs(ptr %s.0, i64 %s.1) #24
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<char>>
  call void @_RINvYNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VeccEECs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %cs, ptr %_3.0, ptr %_3.1) #24
  store i64 0, ptr %i, align 8
; invoke <alloc::vec::Vec<structs::Token>>::new
  invoke void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecNtCs31EPG3twprw_7structs5TokenE3newBE_(ptr sret([24 x i8]) align 8 %out)
          to label %bb44 unwind label %cleanup

bb42:                                             ; preds = %bb41, %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECs31EPG3twprw_7structs(ptr align 8 %cs) #21
          to label %bb43 unwind label %terminate

cleanup:                                          ; preds = %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb42

bb44:                                             ; preds = %start
  br label %bb3

bb3:                                              ; preds = %bb31, %bb37, %bb35, %bb33, %bb14, %bb44
  %_7 = load i64, ptr %i, align 8
; invoke <alloc::vec::Vec<char>>::len
  %_8 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCs31EPG3twprw_7structs(ptr align 8 %cs)
          to label %bb4 unwind label %cleanup1

bb41:                                             ; preds = %bb40, %cleanup1
; invoke core::ptr::drop_glue::<alloc::vec::Vec<structs::Token>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs5TokenEEB1a_(ptr align 8 %out) #21
          to label %bb42 unwind label %terminate

cleanup1:                                         ; preds = %panic6, %bb31, %bb26, %bb25, %bb24, %bb20, %bb18, %bb17, %bb15, %panic4, %bb7, %panic3, %bb10, %panic2, %bb11, %panic, %bb5, %bb3
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb41

bb4:                                              ; preds = %bb3
  %_6 = icmp ult i64 %_7, %_8
  br i1 %_6, label %bb5, label %bb38

bb38:                                             ; preds = %bb4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %out, i64 24, i1 false)
; call core::ptr::drop_glue::<alloc::vec::Vec<char>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECs31EPG3twprw_7structs(ptr align 8 %cs)
  ret void

bb5:                                              ; preds = %bb4
  %_13 = load i64, ptr %i, align 8
; invoke <alloc::vec::Vec<char> as core::ops::index::Index<usize>>::index
  %_11 = invoke align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCs31EPG3twprw_7structs(ptr align 8 %cs, i64 %_13, ptr align 8 @alloc_b747c96906ffbce453a9207e9b2128e6)
          to label %bb6 unwind label %cleanup1

bb6:                                              ; preds = %bb5
  %c = load i32, ptr %_11, align 4
  switch i32 %c, label %bb8 [
    i32 32, label %bb13
    i32 46, label %bb12
    i32 40, label %bb11
    i32 41, label %bb10
  ]

bb8:                                              ; preds = %bb6
  %_14 = icmp ule i32 48, %c
  br i1 %_14, label %bb9, label %bb7

bb13:                                             ; preds = %bb6
  %10 = load i64, ptr %i, align 8
  %_16.0 = add i64 %10, 1
  %_16.1 = icmp ult i64 %_16.0, %10
  br i1 %_16.1, label %panic, label %bb14

bb12:                                             ; preds = %bb9, %bb6
  %st = load i64, ptr %i, align 8
  br label %bb15

bb11:                                             ; preds = %bb6
  store i32 2, ptr %_47, align 8
; invoke <alloc::vec::Vec<structs::Token>>::push
  invoke void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenE4pushBH_(ptr align 8 %out, ptr align 8 %_47)
          to label %bb32 unwind label %cleanup1

bb10:                                             ; preds = %bb6
  store i32 3, ptr %_51, align 8
; invoke <alloc::vec::Vec<structs::Token>>::push
  invoke void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenE4pushBH_(ptr align 8 %out, ptr align 8 %_51)
          to label %bb34 unwind label %cleanup1

bb14:                                             ; preds = %bb13
  store i64 %_16.0, ptr %i, align 8
  br label %bb3

panic:                                            ; preds = %bb13
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_2bb9350cbc6ff862e12ea81bef4f3327) #28
          to label %unreachable unwind label %cleanup1

unreachable:                                      ; preds = %panic6, %panic4, %panic3, %panic2, %panic
  unreachable

bb32:                                             ; preds = %bb11
  %11 = load i64, ptr %i, align 8
  %_48.0 = add i64 %11, 1
  %_48.1 = icmp ult i64 %_48.0, %11
  br i1 %_48.1, label %panic2, label %bb33

bb33:                                             ; preds = %bb32
  store i64 %_48.0, ptr %i, align 8
  br label %bb3

panic2:                                           ; preds = %bb32
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_f022ae404959d59c9f31a4214d0e7b44) #28
          to label %unreachable unwind label %cleanup1

bb34:                                             ; preds = %bb10
  %12 = load i64, ptr %i, align 8
  %_52.0 = add i64 %12, 1
  %_52.1 = icmp ult i64 %_52.0, %12
  br i1 %_52.1, label %panic3, label %bb35

bb35:                                             ; preds = %bb34
  store i64 %_52.0, ptr %i, align 8
  br label %bb3

panic3:                                           ; preds = %bb34
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_5ba5e083a1faa1c75156e6d84a0a62e2) #28
          to label %unreachable unwind label %cleanup1

bb7:                                              ; preds = %bb9, %bb8
  %13 = getelementptr inbounds i8, ptr %_55, i64 4
  store i32 %c, ptr %13, align 4
  store i32 1, ptr %_55, align 8
; invoke <alloc::vec::Vec<structs::Token>>::push
  invoke void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenE4pushBH_(ptr align 8 %out, ptr align 8 %_55)
          to label %bb36 unwind label %cleanup1

bb9:                                              ; preds = %bb8
  %_15 = icmp ule i32 %c, 57
  br i1 %_15, label %bb12, label %bb7

bb36:                                             ; preds = %bb7
  %14 = load i64, ptr %i, align 8
  %_56.0 = add i64 %14, 1
  %_56.1 = icmp ult i64 %_56.0, %14
  br i1 %_56.1, label %panic4, label %bb37

bb37:                                             ; preds = %bb36
  store i64 %_56.0, ptr %i, align 8
  br label %bb3

panic4:                                           ; preds = %bb36
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_28815ad4accad0d1e0197a9f19c642a3) #28
          to label %unreachable unwind label %cleanup1

bb15:                                             ; preds = %bb23, %bb12
  %_19 = load i64, ptr %i, align 8
; invoke <alloc::vec::Vec<char>>::len
  %_20 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCs31EPG3twprw_7structs(ptr align 8 %cs)
          to label %bb16 unwind label %cleanup1

bb16:                                             ; preds = %bb15
  %_18 = icmp ult i64 %_19, %_20
  br i1 %_18, label %bb17, label %bb24

bb24:                                             ; preds = %bb21, %bb16
  %_44 = load i64, ptr %i, align 8
; invoke <alloc::vec::Vec<char> as core::ops::index::Index<core::ops::range::Range<usize>>>::index
  %15 = invoke { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBM_5range5RangejEE5indexCs31EPG3twprw_7structs(ptr align 8 %cs, i64 %st, i64 %_44, ptr align 8 @alloc_622181568d1ef9370268f280836c98b9)
          to label %bb25 unwind label %cleanup1

bb17:                                             ; preds = %bb16
  %_25 = load i64, ptr %i, align 8
; invoke <alloc::vec::Vec<char> as core::ops::index::Index<usize>>::index
  %_23 = invoke align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCs31EPG3twprw_7structs(ptr align 8 %cs, i64 %_25, ptr align 8 @alloc_47eafba4cd49b663816ad426862e813e)
          to label %bb18 unwind label %cleanup1

bb18:                                             ; preds = %bb17
; invoke <char>::is_ascii_digit
  %_22 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc14is_ascii_digitCs31EPG3twprw_7structs(ptr align 4 %_23)
          to label %bb19 unwind label %cleanup1

bb19:                                             ; preds = %bb18
  br i1 %_22, label %bb22, label %bb20

bb20:                                             ; preds = %bb19
  %_30 = load i64, ptr %i, align 8
; invoke <alloc::vec::Vec<char> as core::ops::index::Index<usize>>::index
  %_28 = invoke align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCs31EPG3twprw_7structs(ptr align 8 %cs, i64 %_30, ptr align 8 @alloc_ae1effdc3b6984cddf3f7f5f83f39971)
          to label %bb21 unwind label %cleanup1

bb22:                                             ; preds = %bb21, %bb19
  %16 = load i64, ptr %i, align 8
  %_31.0 = add i64 %16, 1
  %_31.1 = icmp ult i64 %_31.0, %16
  br i1 %_31.1, label %panic6, label %bb23

bb21:                                             ; preds = %bb20
  %_27 = load i32, ptr %_28, align 4
  %_26 = icmp eq i32 %_27, 46
  br i1 %_26, label %bb22, label %bb24

bb25:                                             ; preds = %bb24
  %_41.0 = extractvalue { ptr, i64 } %15, 0
  %_41.1 = extractvalue { ptr, i64 } %15, 1
; invoke <[char]>::iter
  %17 = invoke { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSc4iterCs257F0UrNG3U_14rustc_demangle(ptr align 4 %_41.0, i64 %_41.1)
          to label %bb26 unwind label %cleanup1

bb26:                                             ; preds = %bb25
  %_40.0 = extractvalue { ptr, ptr } %17, 0
  %_40.1 = extractvalue { ptr, ptr } %17, 1
; invoke <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::collect::<alloc::string::String>
  invoke void @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4ItercENtNtNtNtBa_4iter6traits8iterator8Iterator7collectNtNtCs7CppTae75M1_5alloc6string6StringECs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_39, ptr %_40.0, ptr %_40.1)
          to label %bb27 unwind label %cleanup1

bb27:                                             ; preds = %bb26
; invoke <alloc::string::String as core::ops::deref::Deref>::deref
  %18 = invoke { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs31EPG3twprw_7structs(ptr align 8 %_39)
          to label %bb28 unwind label %cleanup5

bb40:                                             ; preds = %cleanup5
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_39) #21
          to label %bb41 unwind label %terminate

cleanup5:                                         ; preds = %bb2.i, %bb30, %bb28, %bb27
  %19 = landingpad { ptr, i32 }
          cleanup
  %20 = extractvalue { ptr, i32 } %19, 0
  %21 = extractvalue { ptr, i32 } %19, 1
  store ptr %20, ptr %0, align 8
  %22 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %21, ptr %22, align 8
  br label %bb40

bb28:                                             ; preds = %bb27
  %_37.0 = extractvalue { ptr, i64 } %18, 0
  %_37.1 = extractvalue { ptr, i64 } %18, 1
; invoke <str>::parse::<f64>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core3stre5parsedECs31EPG3twprw_7structs(ptr sret([16 x i8]) align 8 %_36, ptr %_37.0, i64 %_37.1)
          to label %bb29 unwind label %cleanup5

bb29:                                             ; preds = %bb28
  %23 = load i8, ptr %_36, align 8
  %24 = trunc nuw i8 %23 to i1
  %_2.i = zext i1 %24 to i64
  br i1 %24, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultdNtNtNtB4_3num11float_parse15ParseFloatErrorE6unwrapCs31EPG3twprw_7structs.exit

bb2.i:                                            ; preds = %bb29
  %25 = getelementptr inbounds i8, ptr %_36, i64 1
  %26 = load i8, ptr %25, align 1
  %27 = trunc nuw i8 %26 to i1
  store i8 %26, ptr %e.i, align 1
; invoke core::result::unwrap_failed
  invoke void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 43, ptr %e.i, ptr align 8 @vtable.3, ptr align 8 @alloc_1398e555233619a1db74b0a79be8bc4a) #26
          to label %.noexc unwind label %cleanup5

.noexc:                                           ; preds = %bb2.i
  unreachable

_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultdNtNtNtB4_3num11float_parse15ParseFloatErrorE6unwrapCs31EPG3twprw_7structs.exit: ; preds = %bb29
  %28 = getelementptr inbounds i8, ptr %_36, i64 8
  %t.i = load double, ptr %28, align 8
  br label %bb30

bb30:                                             ; preds = %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultdNtNtNtB4_3num11float_parse15ParseFloatErrorE6unwrapCs31EPG3twprw_7structs.exit
  %29 = getelementptr inbounds i8, ptr %_34, i64 8
  store double %t.i, ptr %29, align 8
  store i32 0, ptr %_34, align 8
; invoke <alloc::vec::Vec<structs::Token>>::push
  invoke void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenE4pushBH_(ptr align 8 %out, ptr align 8 %_34)
          to label %bb31 unwind label %cleanup5

bb31:                                             ; preds = %bb30
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_39)
          to label %bb3 unwind label %cleanup1

terminate:                                        ; preds = %bb42, %bb41, %bb40
  %30 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb23:                                             ; preds = %bb22
  store i64 %_31.0, ptr %i, align 8
  br label %bb15

panic6:                                           ; preds = %bb22
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_9073897bf448b380015b1f1a594c5d53) #28
          to label %unreachable unwind label %cleanup1

bb43:                                             ; preds = %bb42
  %31 = load ptr, ptr %0, align 8
  %32 = getelementptr inbounds i8, ptr %0, i64 8
  %33 = load i32, ptr %32, align 8
  %34 = insertvalue { ptr, i32 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i32 } %34, i32 %33, 1
  resume { ptr, i32 } %35
}

; <alloc::vec::Vec<structs::Token>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecNtCs31EPG3twprw_7structs5TokenE3newBE_(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !463 {
start:
; call <alloc::raw_vec::RawVec<structs::Token>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecNtCs31EPG3twprw_7structs5TokenE3newBL_()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<structs::Version>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecNtCs31EPG3twprw_7structs7VersionE13with_capacityBE_(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !464 {
start:
; call <alloc::vec::Vec<structs::Version>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionE16with_capacity_inBH_(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #24
  ret void
}

; <alloc::vec::Vec<char>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeccE13with_capacityCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !465 {
start:
; call <alloc::vec::Vec<char>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccE16with_capacity_inCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #24
  ret void
}

; <alloc::vec::Vec<char>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeccE3newCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !466 {
start:
; call <alloc::raw_vec::RawVec<char>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVeccE3newCs31EPG3twprw_7structs()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <[structs::Version]>::sort
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc5sliceSNtCs31EPG3twprw_7structs7Version4sortBx_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !467 {
start:
; call alloc::slice::stable_sort::<structs::Version, <structs::Version as core::cmp::PartialOrd>::lt>
  call void @_RINvNtCs7CppTae75M1_5alloc5slice11stable_sortNtCs31EPG3twprw_7structs7VersionNvYBH_NtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltEBJ_(ptr %self.0, i64 %self.1) #24
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !468 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #24
  ret i64 %_0
}

; <alloc::string::String>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !469 {
start:
  %_1 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newB4_(ptr sret([24 x i8]) align 8 %_1) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_1, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String4pushCs31EPG3twprw_7structs(ptr align 8 %self, i32 %ch) unnamed_addr #0 !guid !470 {
start:
; call <alloc::string::String>::len
  %len = call i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCs31EPG3twprw_7structs(ptr align 8 %self) #24
; call <char>::len_utf8
  %ch_len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs31EPG3twprw_7structs(i32 %ch) #24
; call <alloc::string::String>::reserve
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs31EPG3twprw_7structs(ptr align 8 %self, i64 %ch_len) #24
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8 %self) #24
  %_0.i = getelementptr inbounds nuw i8, ptr %_10, i64 %len
; call core::char::methods::encode_utf8_raw_unchecked
  call void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs31EPG3twprw_7structs(i32 %ch, ptr %_0.i) #24
  %_14 = add i64 %len, %ch_len
; call <alloc::vec::Vec<u8>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8 %self, i64 %_14) #24
  ret void
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !471 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8 %self) #24
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs31EPG3twprw_7structs(ptr %_2.0, i64 %_2.1) #24
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <alloc::string::String>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String7reserveCs31EPG3twprw_7structs(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !472 {
start:
; call <alloc::vec::Vec<u8>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8 %self, i64 %additional)
  ret void
}

; <alloc::raw_vec::RawVec<structs::Token>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecNtCs31EPG3twprw_7structs5TokenE3newBL_() unnamed_addr #1 !guid !473 {
start:
; call <alloc::raw_vec::RawVec<structs::Token>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenE6new_inBO_() #24
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<char>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVeccE3newCs31EPG3twprw_7structs() unnamed_addr #1 !guid !474 {
start:
; call <alloc::raw_vec::RawVec<char>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE6new_inCs31EPG3twprw_7structs() #24
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs31EPG3twprw_7structs(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !475 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <str>::chars
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core3stre5charsCs31EPG3twprw_7structs(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !476 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8]>::iter
  %2 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterB4_(ptr %_3.0, i64 %_3.1) #24
  %_2.0 = extractvalue { ptr, ptr } %2, 0
  %_2.1 = extractvalue { ptr, ptr } %2, 1
  %3 = insertvalue { ptr, ptr } poison, ptr %_2.0, 0
  %4 = insertvalue { ptr, ptr } %3, ptr %_2.1, 1
  ret { ptr, ptr } %4
}

; <[[u8; 3]]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAhj3_4iterCs31EPG3twprw_7structs(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !477 {
start:
; call <core::slice::iter::Iter<[u8; 3]>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAhj3_E3newCs31EPG3twprw_7structs(ptr %self.0, i64 %self.1) #24
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitReE8is_emptyCs31EPG3twprw_7structs(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !478 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[structs::Version]>::split_at_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version12split_at_mutBw_(ptr sret([32 x i8]) align 8 %pair, ptr %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #0 !guid !479 {
start:
  %_3 = alloca [32 x i8], align 8
; call <[structs::Version]>::split_at_mut_checked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version20split_at_mut_checkedBw_(ptr sret([32 x i8]) align 8 %_3, ptr %self.0, i64 %self.1, i64 %mid) #24
  %1 = load ptr, ptr %_3, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_4 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %pair, ptr align 8 %_3, i64 32, i1 false)
  ret void

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %5 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_d1084648e479974e70c9329824bf76f9, i64 9) #24
  %_6.0 = extractvalue { ptr, ptr } %5, 0
  %_6.1 = extractvalue { ptr, ptr } %5, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 %0) #26
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <[structs::Version]>::as_mut_ptr_range
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version16as_mut_ptr_rangeBw_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !480 {
start:
  %_0.i = getelementptr inbounds nuw %Version, ptr %self.0, i64 %self.1
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_0.i, 1
  ret { ptr, ptr } %1
}

; <[structs::Version]>::split_at_mut_checked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version20split_at_mut_checkedBw_(ptr sret([32 x i8]) align 8 %_0, ptr %self.0, i64 %self.1, i64 %mid) unnamed_addr #0 !guid !481 {
start:
  %_6 = alloca [32 x i8], align 8
  %_3 = icmp ule i64 %mid, %self.1
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb1:                                              ; preds = %start
; call <[structs::Version]>::split_at_mut_unchecked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version22split_at_mut_uncheckedBw_(ptr sret([32 x i8]) align 8 %_6, ptr %self.0, i64 %self.1, i64 %mid, ptr align 8 @alloc_a6541cbd0ddc1cb3d23757a1b3f12432) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 32, i1 false)
  br label %bb4

bb4:                                              ; preds = %bb1, %bb3
  ret void
}

; <[structs::Version]>::split_at_mut_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version22split_at_mut_uncheckedBw_(ptr sret([32 x i8]) align 8 %_0, ptr %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #0 !guid !482 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <[_]>::split_at_mut_unchecked::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp22split_at_mut_unchecked18precondition_checkCs31EPG3twprw_7structs(i64 %mid, i64 %self.1, ptr align 8 %0) #25
  br label %bb3

bb3:                                              ; preds = %bb2
; call core::slice::raw::from_raw_parts_mut::<structs::Version>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionEBV_(ptr %self.0, i64 %mid, ptr align 8 %0) #24
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %_0.i = getelementptr inbounds nuw %Version, ptr %self.0, i64 %mid
  %_11 = sub nuw i64 %self.1, %mid
; call core::slice::raw::from_raw_parts_mut::<structs::Version>
  %2 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionEBV_(ptr %_0.i, i64 %_11, ptr align 8 %0) #24
  %_9.0 = extractvalue { ptr, i64 } %2, 0
  %_9.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_8.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8.1, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 16
  store ptr %_9.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %_9.1, ptr %5, align 8
  ret void
}

; <[structs::Version]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version4iterBw_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !483 {
start:
; call <core::slice::iter::Iter<structs::Version>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterNtCs31EPG3twprw_7structs7VersionE3newBQ_(ptr %self.0, i64 %self.1) #24
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[structs::Version]>::reverse
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version7reverseBw_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !484 {
start:
  %_0.i = alloca [8 x i8], align 8
  %_11 = alloca [32 x i8], align 8
  %half_len = udiv i64 %self.1, 2
; call <[structs::Version]>::as_mut_ptr_range
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version16as_mut_ptr_rangeBw_(ptr %self.0, i64 %self.1) #24
  %_8.0 = extractvalue { ptr, ptr } %0, 0
  %_8.1 = extractvalue { ptr, ptr } %0, 1
; call core::slice::raw::from_raw_parts_mut::<structs::Version>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionEBV_(ptr %_8.0, i64 %half_len, ptr align 8 @alloc_c0be9056d9e7c9d32564b353e6cdd76b) #24
  %_12.0 = extractvalue { ptr, i64 } %1, 0
  %_12.1 = extractvalue { ptr, i64 } %1, 1
  %_3.i = sub nsw i64 0, %half_len
  %2 = getelementptr inbounds %Version, ptr %_8.1, i64 %_3.i
  store ptr %2, ptr %_0.i, align 8
  %3 = load ptr, ptr %_0.i, align 8
; call core::slice::raw::from_raw_parts_mut::<structs::Version>
  %4 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionEBV_(ptr %3, i64 %half_len, ptr align 8 @alloc_11a111513757e9d53adfd2e1c4df0866) #24
  %_13.0 = extractvalue { ptr, i64 } %4, 0
  %_13.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_12.0, ptr %_11, align 8
  %5 = getelementptr inbounds i8, ptr %_11, i64 8
  store i64 %_12.1, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_11, i64 16
  store ptr %_13.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %_13.1, ptr %7, align 8
  %front_half.0 = load ptr, ptr %_11, align 8
  %8 = getelementptr inbounds i8, ptr %_11, i64 8
  %front_half.1 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %_11, i64 16
  %back_half.0 = load ptr, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  %back_half.1 = load i64, ptr %10, align 8
; call <[_]>::reverse::revswap::<structs::Version>
  call void @_RINvNvMNtCsl10jNU3mE6R_4core5sliceSp7reverse7revswapNtCs31EPG3twprw_7structs7VersionEBQ_(ptr %front_half.0, i64 %front_half.1, ptr %back_half.0, i64 %back_half.1, i64 %half_len) #24
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<structs::Version>>>::new
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxNtCs31EPG3twprw_7structs7VersionEE3newB1F_(ptr %x) unnamed_addr #1 !guid !485 {
start:
  ret ptr %x
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<structs::Version>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxNtCs31EPG3twprw_7structs7VersionEE6as_mutB1F_(ptr align 8 %self) unnamed_addr #1 !guid !486 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[structs::Version]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCs31EPG3twprw_7structs7VersionEE3newB1G_(ptr %x.0, i64 %x.1) unnamed_addr #1 !guid !487 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[structs::Version]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCs31EPG3twprw_7structs7VersionEE6as_mutB1G_(ptr align 8 %self) unnamed_addr #1 !guid !488 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[structs::Version]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCs31EPG3twprw_7structs7VersionEE6as_refB1G_(ptr align 8 %self) unnamed_addr #1 !guid !489 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE3newCs31EPG3twprw_7structs(ptr sret([80 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !490 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 80, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE6as_mutCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #1 !guid !491 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtNtB6_5slice4sort6shared9smallsort10CopyOnDropNtCs31EPG3twprw_7structs7VersionEE3newB1Y_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !492 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::hint::select_unpredictable::DropOnPanic<*const structs::Version>>>::new
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNvNtB6_4hint20select_unpredictable11DropOnPanicPNtCs31EPG3twprw_7structs7VersionEE3newB1V_(ptr %x) unnamed_addr #1 !guid !493 {
start:
  ret ptr %x
}

; <core::mem::maybe_dangling::MaybeDangling<structs::Version>>::new
; Function Attrs: nonlazybind uwtable
define internal i24 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtCs31EPG3twprw_7structs7VersionE3newB16_(i24 %0) unnamed_addr #1 !guid !494 {
start:
  %_0 = alloca [4 x i8], align 1
  %1 = alloca [4 x i8], align 4
  %x = alloca [3 x i8], align 1
  store i24 %0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %x, ptr align 4 %1, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0, ptr align 1 %x, i64 3, i1 false)
  %2 = load i24, ptr %_0, align 1
  ret i24 %2
}

; <core::mem::maybe_dangling::MaybeDangling<structs::Version>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNtCs31EPG3twprw_7structs7VersionE6as_refB16_(ptr %self) unnamed_addr #1 !guid !495 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<*const structs::Version>>::new
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPNtCs31EPG3twprw_7structs7VersionE3newB17_(ptr %x) unnamed_addr #1 !guid !496 {
start:
  ret ptr %x
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs31EPG3twprw_7structs(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !497 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs31EPG3twprw_7structs(i64 %align, ptr align 8 %0) #25
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs31EPG3twprw_7structs(i64 %self) unnamed_addr #0 !guid !498 {
start:
  ret i64 %self
}

; <core::ops::index_range::IndexRange>::next_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !499 {
start:
  %value = load i64, ptr %self, align 8
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs31EPG3twprw_7structs(i64 %value, i64 1, ptr align 8 @alloc_de9a5d9a80d554992107c1ea3afec081) #25
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i64 %value, 1
  store i64 %_0.i, ptr %self, align 8
  ret i64 %value
}

; <core::ops::index_range::IndexRange>::end
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !500 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !501 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_2 = load i64, ptr %0, align 8
  %_3 = load i64, ptr %self, align 8
  %_0 = sub nuw i64 %_2, %_3
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::start
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !502 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::zero_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCs31EPG3twprw_7structs(i64 %end) unnamed_addr #0 !guid !503 {
start:
  %0 = insertvalue { i64, i64 } { i64 0, i64 poison }, i64 %end, 1
  ret { i64, i64 } %0
}

; <*mut structs::Version>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCs31EPG3twprw_7structs7Version20offset_from_unsignedBE_(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !504 {
start:
; call <*const structs::Version>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPNtCs31EPG3twprw_7structs7Version20offset_from_unsignedBG_(ptr %self, ptr %origin, ptr align 8 %0) #24
  ret i64 %_0
}

; <*mut char>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOc20offset_from_unsignedCs31EPG3twprw_7structs(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !505 {
start:
; call <*const char>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPc20offset_from_unsignedCs31EPG3twprw_7structs(ptr %self, ptr %origin, ptr align 8 %0) #24
  ret i64 %_0
}

; <*const structs::Version>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPNtCs31EPG3twprw_7structs7Version20offset_from_unsignedBG_(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !506 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 3
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs31EPG3twprw_7structs(ptr %self, ptr %origin, ptr align 8 %0) #25
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #26
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 3, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 3
  ret i64 %_0
}

; <*const char>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPc20offset_from_unsignedCs31EPG3twprw_7structs(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !507 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 4
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs31EPG3twprw_7structs(ptr %self, ptr %origin, ptr align 8 %0) #25
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #26
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 4, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 4
  ret i64 %_0
}

; <char>::is_ascii_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc14is_ascii_digitCs31EPG3twprw_7structs(ptr align 4 %self) unnamed_addr #0 !guid !508 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i32, ptr %self, align 4
  %_2 = icmp ule i32 48, %0
  br i1 %_2, label %bb3, label %bb1

bb1:                                              ; preds = %bb3, %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %1 = load i32, ptr %self, align 4
  %_3 = icmp ule i32 %1, 57
  br i1 %_3, label %bb2, label %bb1

bb2:                                              ; preds = %bb3
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb1
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  ret i1 %3
}

; <char>::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8len_utf8Cs31EPG3twprw_7structs(i32 %self) unnamed_addr #0 !guid !509 {
start:
; call core::char::methods::len_utf8
  %_0 = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs31EPG3twprw_7structs(i32 %self) #24
  ret i64 %_0
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !510 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs31EPG3twprw_7structs(i64 %_3) #24
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #24
  ret ptr %_0
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs31EPG3twprw_7structs(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !511 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs31EPG3twprw_7structs(i64 %size, i64 %alignment, ptr align 8 %0) #25
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !512 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !513 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::array::iter::IntoIter<&str, 4>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterReKj4_E10unsize_mutCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !514 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE6as_mutCs31EPG3twprw_7structs(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 4, 1
  ret { ptr, i64 } %1
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<char>, <char as core::clone::Clone>::clone>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4ItercENvYcNtNtB8_5clone5Clone5cloneE3newCs31EPG3twprw_7structs(ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !515 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %iter.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %iter.1, 1
  ret { ptr, ptr } %1
}

; <core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, structs::main::{closure#0}>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_5slice4iter4IterhENCNvCs31EPG3twprw_7structs4main0E3newB1p_(ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !516 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %iter.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %iter.1, 1
  ret { ptr, ptr } %1
}

; <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB2_6ClonedINtNtNtB8_5slice4iter4ItercEE3newCs31EPG3twprw_7structs(ptr %it.0, ptr %it.1) unnamed_addr #1 !guid !517 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %it.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %it.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::sort::stable::AlignedStorage<structs::Version, 4096>>::as_uninit_slice_mut
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStorageNtCs31EPG3twprw_7structs7VersionKj1000_E19as_uninit_slice_mutB17_(ptr %self) unnamed_addr #1 !guid !518 {
start:
  %_4 = icmp eq i64 3, 0
  br i1 %_4, label %panic, label %bb2

bb2:                                              ; preds = %start
  %len = udiv i64 4096, 3
; call core::slice::raw::from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<structs::Version>>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutINtNtNtB6_3mem12maybe_uninit11MaybeUninitNtCs31EPG3twprw_7structs7VersionEEB1A_(ptr %self, i64 %len, ptr align 8 @alloc_2491cc18f41182435b2301519a149a1c) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_f5abd596fd0c54395cb86286cae95a93) #26
  unreachable
}

; <core::slice::sort::stable::AlignedStorage<structs::Version, 4096>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStorageNtCs31EPG3twprw_7structs7VersionKj1000_E3newB17_(ptr sret([4096 x i8]) align 1 %_0) unnamed_addr #1 !guid !519 {
start:
  %_1 = alloca [4096 x i8], align 1
  call void @llvm.memset.p0.i64(ptr align 1 %_1, i8 undef, i64 4096, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0, ptr align 1 %_1, i64 4096, i1 false)
  ret void
}

; <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::partition_one
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE13partition_oneB1j_(ptr align 8 %self, i1 zeroext %towards_left) unnamed_addr #1 !guid !520 {
start:
  %_0.i1 = alloca [8 x i8], align 8
  %dst_base = alloca [8 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 24
  %_4 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds %Version, ptr %_4, i64 -1
  store ptr %1, ptr %_0.i1, align 8
  %2 = load ptr, ptr %_0.i1, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 24
  store ptr %2, ptr %3, align 8
  br i1 %towards_left, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 24
  %5 = load ptr, ptr %4, align 8
  store ptr %5, ptr %dst_base, align 8
  br label %bb4

bb2:                                              ; preds = %start
  %6 = load ptr, ptr %self, align 8
  store ptr %6, ptr %dst_base, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %_6 = load ptr, ptr %dst_base, align 8
  %7 = getelementptr inbounds i8, ptr %self, i64 16
  %_7 = load i64, ptr %7, align 8
  %_0.i = getelementptr inbounds nuw %Version, ptr %_6, i64 %_7
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_9 = load ptr, ptr %8, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %bb4
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_9, ptr %_0.i, i64 3, i64 1, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %bb4, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0.i, ptr align 1 %_9, i64 3, i1 false)
  %_10 = zext i1 %towards_left to i64
  %9 = getelementptr inbounds i8, ptr %self, i64 16
  %10 = getelementptr inbounds i8, ptr %self, i64 16
  %11 = load i64, ptr %10, align 8
  %12 = add i64 %11, %_10
  store i64 %12, ptr %9, align 8
  %13 = getelementptr inbounds i8, ptr %self, i64 8
  %_12 = load ptr, ptr %13, align 8
  %_0.i3 = getelementptr inbounds nuw %Version, ptr %_12, i64 1
  %14 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_0.i3, ptr %14, align 8
  ret ptr %_0.i
}

; <core::slice::sort::stable::quicksort::PartitionState<structs::Version>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStateNtCs31EPG3twprw_7structs7VersionE3newB1j_(ptr sret([32 x i8]) align 8 %_0, ptr %scan, ptr %scratch, i64 %len) unnamed_addr #1 !guid !521 {
start:
  %_0.i = getelementptr inbounds nuw %Version, ptr %scratch, i64 %len
  store ptr %scratch, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %scan, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 24
  store ptr %_0.i, ptr %2, align 8
  ret void
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs31EPG3twprw_7structs(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !522 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs31EPG3twprw_7structs(i64 %3, i64 %5, i1 zeroext %8) #24
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs31EPG3twprw_7structs(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !523 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs31EPG3twprw_7structs(ptr %2, i64 %4, i64 %6) #24
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs31EPG3twprw_7structs(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !524 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs31EPG3twprw_7structs(ptr align 8 %layout) #24
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs31EPG3twprw_7structs(ptr align 8 %layout) #24
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #24
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs31EPG3twprw_7structs(i64 %11, i64 %13) #24
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs31EPG3twprw_7structs(i64 %15, i64 %17) #24
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #24
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #24
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #24
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #24
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #24
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs31EPG3twprw_7structs(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !525 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs31EPG3twprw_7structs(ptr align 8 %layout) #24
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs31EPG3twprw_7structs(ptr %ptr, i64 %3, i64 %5) #24
  br label %bb3
}

; <alloc::raw_vec::RawVec<structs::Token>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenE3ptrBO_(ptr align 8 %self) unnamed_addr #0 !guid !526 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<structs::Token>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCs31EPG3twprw_7structs5TokenEBY_(ptr align 8 %self) #24
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<structs::Token>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenE6new_inBO_() unnamed_addr #0 personality ptr @rust_eh_personality !guid !527 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<structs::Token>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofNtCs31EPG3twprw_7structs5TokenEBY_() #24
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64 %_4) #24
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<structs::Token>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenE8capacityBO_(ptr align 8 %self) unnamed_addr #0 !guid !528 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 16) #24
  ret i64 %_0
}

; <alloc::raw_vec::RawVec<structs::Version>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !529 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<structs::Version>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCs31EPG3twprw_7structs7VersionEBG_(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr %ptr, i64 %capacity2) #24
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<structs::Version>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionE3ptrBO_(ptr align 8 %self) unnamed_addr #0 !guid !530 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<structs::Version>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCs31EPG3twprw_7structs7VersionEBY_(ptr align 8 %self) #24
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<structs::Version>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionE8capacityBO_(ptr align 8 %self) unnamed_addr #0 !guid !531 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 3) #24
  ret i64 %_0
}

; <alloc::raw_vec::RawVec<char>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE3ptrCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !532 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<char>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrcECs31EPG3twprw_7structs(ptr align 8 %self) #24
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<char>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE6new_inCs31EPG3twprw_7structs() unnamed_addr #0 personality ptr @rust_eh_personality !guid !533 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<char>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofcECs31EPG3twprw_7structs() #24
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64 %_4) #24
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<char>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE7reserveCs31EPG3twprw_7structs(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #0 !guid !534 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8 %self, i64 %len, i64 %additional, i64 4, i64 4) #24
  ret void
}

; <alloc::raw_vec::RawVec<char>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE8capacityCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !535 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 4) #24
  ret i64 %_0
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs31EPG3twprw_7structs(i32 %self) unnamed_addr #0 !guid !536 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs31EPG3twprw_7structs(i32 %self) #24
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs31EPG3twprw_7structs(i32 %self) unnamed_addr #0 !guid !537 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::ptr::unique::Unique<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueINtNtNtB9_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EE6as_ptrB1y_(ptr %self) unnamed_addr #0 !guid !538 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<structs::Token>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCs31EPG3twprw_7structs5TokenE15as_non_null_ptrBS_(ptr %self) unnamed_addr #0 !guid !539 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<structs::Version>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCs31EPG3twprw_7structs7VersionE13new_uncheckedBS_(ptr %ptr) unnamed_addr #0 !guid !540 {
start:
; call <core::ptr::non_null::NonNull<structs::Version>>::new_unchecked
  %_2 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs31EPG3twprw_7structs7VersionE13new_uncheckedBV_(ptr %ptr, ptr align 8 @alloc_8e8e5d43991787ef9fba0c8fe53b59fb) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<structs::Version>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCs31EPG3twprw_7structs7VersionE15as_non_null_ptrBS_(ptr %self) unnamed_addr #0 !guid !541 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<structs::Version>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCs31EPG3twprw_7structs7VersionE6as_ptrBS_(ptr %self) unnamed_addr #0 !guid !542 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<[structs::Version]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCs31EPG3twprw_7structs7VersionE6as_ptrBT_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !543 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::unique::Unique<char>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquecE15as_non_null_ptrCs31EPG3twprw_7structs(ptr %self) unnamed_addr #0 !guid !544 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[[u8; 3]; 2]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAAhj3_j2_E8from_refCs31EPG3twprw_7structs(ptr %r) unnamed_addr #0 !guid !545 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[u8; 4]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAhj4_E8from_refCs31EPG3twprw_7structs(ptr %r) unnamed_addr #0 !guid !546 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::vec::Vec<structs::Version>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VecNtCs31EPG3twprw_7structs7VersionEE8from_refB1s_(ptr align 8 %r) unnamed_addr #0 !guid !547 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<structs::Color>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs31EPG3twprw_7structs5ColorE8from_refBV_(ptr %r) unnamed_addr #0 !guid !548 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<structs::Version>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs31EPG3twprw_7structs7VersionE13new_uncheckedBV_(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !549 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs31EPG3twprw_7structs(ptr %ptr, ptr align 8 %0) #25
  br label %bb3
}

; <core::ptr::non_null::NonNull<structs::Version>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs31EPG3twprw_7structs7VersionE8from_refBV_(ptr %r) unnamed_addr #0 !guid !550 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&structs::Token>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRNtCs31EPG3twprw_7structs5TokenE8from_refBW_(ptr align 8 %r) unnamed_addr #0 !guid !551 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[[u8; 3]]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAhj3_E8from_refCs31EPG3twprw_7structs(ptr %r.0, i64 %r.1) unnamed_addr #0 !guid !552 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[structs::Version]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSNtCs31EPG3twprw_7structs7VersionE8from_refBW_(ptr %r.0, i64 %r.1) unnamed_addr #0 !guid !553 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<(i32, &str, f64)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTlRedEE8from_refCs31EPG3twprw_7structs(ptr align 8 %r) unnamed_addr #0 !guid !554 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs31EPG3twprw_7structs(ptr %r) unnamed_addr #0 !guid !555 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<char>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullcE20offset_from_unsignedCs31EPG3twprw_7structs(ptr %self, ptr %subtracted) unnamed_addr #0 !guid !556 {
start:
; call <*mut char>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOc20offset_from_unsignedCs31EPG3twprw_7structs(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #24
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs31EPG3twprw_7structs(ptr align 8 %r) unnamed_addr #0 !guid !557 {
start:
  ret ptr %r
}

; <core::num::nonzero::NonZero<usize>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE13leading_zerosCs31EPG3twprw_7structs(i64 %self) unnamed_addr #0 !guid !558 {
start:
; call <core::num::nonzero::NonZero<usize>>::get
  %_2 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %self) #24
  %0 = call i64 @llvm.ctlz.i64(i64 %_2, i1 true)
  %_0 = trunc i64 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<usize>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE5ilog2Cs31EPG3twprw_7structs(i64 %self) unnamed_addr #0 !guid !559 {
start:
; call <core::num::nonzero::NonZero<usize>>::leading_zeros
  %_3 = call i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE13leading_zerosCs31EPG3twprw_7structs(i64 %self) #24
  %_0 = sub i32 63, %_3
  ret i32 %_0
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs31EPG3twprw_7structs(i64 %val) unnamed_addr #0 !guid !560 {
start:
  ret i64 %val
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj4_E13new_uncheckedCs31EPG3twprw_7structs(ptr sret([80 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 8 %data) unnamed_addr #0 !guid !561 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %data, i64 64, i1 false)
  ret void
}

; <alloc::raw_vec::RawVec<structs::Token>>::grow_one
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenE8grow_oneBO_(ptr align 8 %self) unnamed_addr #3 !guid !562 {
start:
; call <alloc::raw_vec::RawVecInner>::grow_one
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneB7_(ptr align 8 %self, i64 8, i64 16) #24
  ret void
}

; <alloc::raw_vec::RawVec<structs::Version>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionE16with_capacity_inBO_(i64 %capacity) unnamed_addr #0 !guid !563 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 1, i64 3) #24
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<char>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE16with_capacity_inCs31EPG3twprw_7structs(i64 %capacity) unnamed_addr #0 !guid !564 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 4, i64 4) #24
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !565 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs31EPG3twprw_7structs(ptr %s.0, i64 %s.1) #24
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<[u8; 3]>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAhj3_E3newCs31EPG3twprw_7structs(ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !566 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[[u8; 3]]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAhj3_E8from_refCs31EPG3twprw_7structs(ptr %slice.0, i64 %slice.1) #24
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[[u8; 3]]>>::cast::<[u8; 3]>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAhj3_E4castBV_ECs31EPG3twprw_7structs(ptr %_4.0, i64 %_4.1) #24
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw [3 x i8], ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<structs::Version>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterNtCs31EPG3twprw_7structs7VersionE3newBQ_(ptr %slice.0, i64 %slice.1) unnamed_addr #0 !guid !567 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[structs::Version]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSNtCs31EPG3twprw_7structs7VersionE8from_refBW_(ptr %slice.0, i64 %slice.1) #24
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[structs::Version]>>::cast::<structs::Version>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCs31EPG3twprw_7structs7VersionE4castBV_EBX_(ptr %_4.0, i64 %_4.1) #24
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw %Version, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<structs::Version>>::from_raw
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs6_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtCs31EPG3twprw_7structs7VersionE8from_rawBJ_(ptr %raw) unnamed_addr #0 !guid !568 {
start:
; call <alloc::boxed::Box<structs::Version>>::from_raw_in
  %_0 = call ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtCs31EPG3twprw_7structs7VersionE11from_raw_inBJ_(ptr %raw) #24
  ret ptr %_0
}

; <alloc::boxed::Box<structs::Version>>::into_raw
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs6_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtCs31EPG3twprw_7structs7VersionE8into_rawBJ_(ptr %b) unnamed_addr #0 !guid !569 {
start:
  %b1 = alloca [8 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<structs::Version>>>::new
  %_2.i = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxNtCs31EPG3twprw_7structs7VersionEE3newB1F_(ptr %b)
  store ptr %_2.i, ptr %b1, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<structs::Version>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxNtCs31EPG3twprw_7structs7VersionEE6as_mutB1F_(ptr align 8 %b1)
  %_6 = load ptr, ptr %_0.i, align 8
  ret ptr %_6
}

; <alloc::boxed::Box<structs::Version>>::from_raw_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtCs31EPG3twprw_7structs7VersionE11from_raw_inBJ_(ptr %raw) unnamed_addr #0 personality ptr @rust_eh_personality !guid !570 {
start:
; call <core::ptr::unique::Unique<structs::Version>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCs31EPG3twprw_7structs7VersionE13new_uncheckedBS_(ptr %raw) #24
  br label %bb1

bb1:                                              ; preds = %start
  ret ptr %_3

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<[structs::Version]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCs31EPG3twprw_7structs7VersionE23into_raw_with_allocatorBK_(ptr %b.0, i64 %b.1) unnamed_addr #0 !guid !571 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[structs::Version]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCs31EPG3twprw_7structs7VersionEE3newB1G_(ptr %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[structs::Version]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCs31EPG3twprw_7structs7VersionEE6as_mutB1G_(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[structs::Version]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCs31EPG3twprw_7structs7VersionEE6as_refB1G_(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <u64>::div_ceil
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8div_ceilCs31EPG3twprw_7structs(i64 %self, i64 %rhs, ptr align 8 %0) unnamed_addr #0 !guid !572 {
start:
  %_0 = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %panic, label %bb1

bb1:                                              ; preds = %start
  %d = udiv i64 %self, %rhs
  %_6 = icmp eq i64 %rhs, 0
  br i1 %_6, label %panic1, label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 %0) #26
  unreachable

bb2:                                              ; preds = %bb1
  %r = urem i64 %self, %rhs
  %_7 = icmp ugt i64 %r, 0
  br i1 %_7, label %bb3, label %bb4

panic1:                                           ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 %0) #26
  unreachable

bb4:                                              ; preds = %bb2
  store i64 %d, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb2
  %1 = add i64 %d, 1
  store i64 %1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %2 = load i64, ptr %_0, align 8
  ret i64 %2
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEE4nextCs31EPG3twprw_7structs(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !573 {
start:
; call <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCs31EPG3twprw_7structs(ptr align 8 %self.0) #24
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_5.0 = getelementptr inbounds i8, ptr %self.0, i64 16
; call <core::option::Option<usize>>::map::<&str, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next::{closure#0}>
  %1 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapReNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBY_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitBO_EE4next0ECs31EPG3twprw_7structs(i64 %_2.0, i64 %_2.1, ptr align 8 %_5.0, i64 %self.1) #24
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs31EPG3twprw_7structs(ptr %self) unnamed_addr #0 !guid !574 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs31EPG3twprw_7structs(i64 %self, i64 %rhs) unnamed_addr #0 !guid !575 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCs31EPG3twprw_7structs(i64 %self, i64 %rhs) unnamed_addr #0 !guid !576 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <usize>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj13checked_ilog2Cs31EPG3twprw_7structs(i64 %self) unnamed_addr #0 !guid !577 {
start:
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<usize>>::new
  %0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %self) #24
  store i64 %0, ptr %_2, align 8
  %1 = load i64, ptr %_2, align 8
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i64, ptr %_2, align 8
; call <core::num::nonzero::NonZero<usize>>::ilog2
  %_5 = call i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE5ilog2Cs31EPG3twprw_7structs(i64 %x) #24
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <usize>::is_multiple_of
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj14is_multiple_ofCs31EPG3twprw_7structs(i64 %self, i64 %rhs) unnamed_addr #0 !guid !578 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = icmp eq i64 %rhs, 0
  br i1 %0, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %self, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_0, align 1
  br label %bb4

bb1:                                              ; preds = %start
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %panic, label %bb3

bb4:                                              ; preds = %bb3, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb3:                                              ; preds = %bb1
  %_3 = urem i64 %self, %rhs
  %5 = icmp eq i64 %_3, 0
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

panic:                                            ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_9f4cf96e0cfa121f5a07edf0a5a77ed7) #26
  unreachable
}

; <usize>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj5ilog2Cs31EPG3twprw_7structs(i64 %self, ptr align 8 %0) unnamed_addr #0 !guid !579 {
start:
  %_2 = alloca [8 x i8], align 4
; call <usize>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj13checked_ilog2Cs31EPG3twprw_7structs(i64 %self) #24
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #28
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs31EPG3twprw_7structs(i64 %self, i64 %other) unnamed_addr #0 !guid !580 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs31EPG3twprw_7structs(i32 %_0.i) #24
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <usize>::div_ceil
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8div_ceilCs31EPG3twprw_7structs(i64 %self, i64 %rhs, ptr align 8 %0) unnamed_addr #0 !guid !581 {
start:
  %_0 = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %panic, label %bb1

bb1:                                              ; preds = %start
  %d = udiv i64 %self, %rhs
  %_6 = icmp eq i64 %rhs, 0
  br i1 %_6, label %panic1, label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 %0) #26
  unreachable

bb2:                                              ; preds = %bb1
  %r = urem i64 %self, %rhs
  %_7 = icmp ugt i64 %r, 0
  br i1 %_7, label %bb3, label %bb4

panic1:                                           ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 %0) #26
  unreachable

bb4:                                              ; preds = %bb2
  store i64 %d, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb2
  %1 = add i64 %d, 1
  store i64 %1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %2 = load i64, ptr %_0, align 8
  ret i64 %2
}

; <alloc::vec::Vec<structs::Token>>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenE4pushBH_(ptr align 8 %self, ptr align 8 %value) unnamed_addr #0 !guid !582 {
start:
  %0 = alloca [16 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %value, i64 16, i1 false)
; call <alloc::vec::Vec<structs::Token>>::push_mut
  %_3 = call align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenE8push_mutBH_(ptr align 8 %self, ptr align 8 %0) #24
  ret void
}

; <alloc::vec::Vec<structs::Token>>::push_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenE8push_mutBH_(ptr align 8 %self, ptr align 8 %value) unnamed_addr #0 personality ptr @rust_eh_personality !guid !583 {
start:
  %_13 = alloca [1 x i8], align 1
  %_12 = alloca [16 x i8], align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<structs::Token>>::capacity
  %_5 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenE8capacityBO_(ptr align 8 %self) #24
  br label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp eq i64 %len, %_5
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb10, %bb1
; call <alloc::vec::Vec<structs::Token>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs5TokenE10as_mut_ptrBG_(ptr align 8 %self) #24
  br label %bb4

bb2:                                              ; preds = %bb1
; call <alloc::raw_vec::RawVec<structs::Token>>::grow_one
  call void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenE8grow_oneBO_(ptr align 8 %self) #23
  br label %bb10

bb10:                                             ; preds = %bb2
  br label %bb3

bb4:                                              ; preds = %bb3
  %_0.i = getelementptr inbounds nuw %Token, ptr %_10, i64 %len
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_13, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_12, ptr align 8 %value, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0.i, ptr align 8 %_12, i64 16, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb5
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = add i64 %len, 1
  store i64 %2, ptr %1, align 8
  ret ptr %_0.i

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<structs::Version>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionE16with_capacity_inBH_(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !584 {
start:
; call <alloc::raw_vec::RawVec<structs::Version>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionE16with_capacity_inBO_(i64 %capacity) #24
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<char>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccE16with_capacity_inCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !585 {
start:
; call <alloc::raw_vec::RawVec<char>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE16with_capacity_inCs31EPG3twprw_7structs(i64 %capacity) #24
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs31EPG3twprw_7structs(i8 %0) unnamed_addr #0 !guid !586 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs31EPG3twprw_7structs(ptr %self) #24
  ret i32 %_0
}

; <alloc::vec::Vec<structs::Token>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs5TokenE10as_mut_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !587 {
start:
; call <alloc::raw_vec::RawVec<structs::Token>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenE3ptrBO_(ptr align 8 %self) #24
  ret ptr %_0
}

; <alloc::vec::Vec<structs::Token>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs5TokenE6as_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !588 {
start:
; call <alloc::raw_vec::RawVec<structs::Token>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenE3ptrBO_(ptr align 8 %self) #24
  ret ptr %_2
}

; <alloc::vec::Vec<structs::Token>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs5TokenE8as_sliceBG_(ptr align 8 %self) unnamed_addr #0 !guid !589 {
start:
; call <alloc::vec::Vec<structs::Token>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs5TokenE6as_ptrBG_(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<structs::Version>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE10as_mut_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !590 {
start:
; call <alloc::raw_vec::RawVec<structs::Version>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionE3ptrBO_(ptr align 8 %self) #24
  ret ptr %_0
}

; <alloc::vec::Vec<structs::Version>>::as_mut_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE12as_mut_sliceBG_(ptr align 8 %self) unnamed_addr #0 !guid !591 {
start:
; call <alloc::vec::Vec<structs::Version>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE10as_mut_ptrBG_(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<structs::Version>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !592 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs31EPG3twprw_7structs(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #25
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<structs::Version>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) #24
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<structs::Version>>::spare_capacity_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE18spare_capacity_mutBG_(ptr align 8 %self) unnamed_addr #0 !guid !593 {
start:
; call <alloc::vec::Vec<structs::Version>>::as_mut_ptr
  %_4 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE10as_mut_ptrBG_(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
  %_0.i = getelementptr inbounds nuw %Version, ptr %_4, i64 %_5
; call <alloc::raw_vec::RawVec<structs::Version>>::capacity
  %_7 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionE8capacityBO_(ptr align 8 %self) #24
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_9 = load i64, ptr %1, align 8
  %_6 = sub i64 %_7, %_9
; call core::slice::raw::from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<structs::Version>>
  %2 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutINtNtNtB6_3mem12maybe_uninit11MaybeUninitNtCs31EPG3twprw_7structs7VersionEEB1A_(ptr %_0.i, i64 %_6, ptr align 8 @alloc_027cef065c3c71aa2f31a680ec9e0201) #24
  %_0.0 = extractvalue { ptr, i64 } %2, 0
  %_0.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1, 1
  ret { ptr, i64 } %4
}

; <alloc::vec::Vec<structs::Version>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE6as_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !594 {
start:
; call <alloc::raw_vec::RawVec<structs::Version>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionE3ptrBO_(ptr align 8 %self) #24
  ret ptr %_2
}

; <alloc::vec::Vec<structs::Version>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE8as_sliceBG_(ptr align 8 %self) unnamed_addr #0 !guid !595 {
start:
; call <alloc::vec::Vec<structs::Version>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE6as_ptrBG_(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<char>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE10as_mut_ptrCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !596 {
start:
; call <alloc::raw_vec::RawVec<char>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE3ptrCs31EPG3twprw_7structs(ptr align 8 %self) #24
  ret ptr %_0
}

; <alloc::vec::Vec<char>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !597 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 2305843009213693951
  ret i64 %len
}

; <alloc::vec::Vec<char>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE6as_ptrCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !598 {
start:
; call <alloc::raw_vec::RawVec<char>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE3ptrCs31EPG3twprw_7structs(ptr align 8 %self) #24
  ret ptr %_2
}

; <alloc::vec::Vec<char>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7reserveCs31EPG3twprw_7structs(ptr align 8 %self, i64 %additional) unnamed_addr #1 !guid !599 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<char>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE7reserveCs31EPG3twprw_7structs(ptr align 8 %self, i64 %_5, i64 %additional) #24
  ret void
}

; <alloc::vec::Vec<char>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7set_lenCs31EPG3twprw_7structs(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !600 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<char>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8capacityCs31EPG3twprw_7structs(ptr align 8 %self) #24
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs31EPG3twprw_7structs(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #25
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<char>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8as_sliceCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !601 {
start:
; call <alloc::vec::Vec<char>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE6as_ptrCs31EPG3twprw_7structs(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<char>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8capacityCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !602 {
start:
; call <alloc::raw_vec::RawVec<char>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE8capacityCs31EPG3twprw_7structs(ptr align 8 %self) #24
  ret i64 %_0
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitReEj4_EE4dropCs31EPG3twprw_7structs(ptr align 8 %slot) unnamed_addr #0 !guid !603 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE6as_mutCs31EPG3twprw_7structs(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitReEj4_EECs31EPG3twprw_7structs(ptr align 8 %_3)
  ret void
}

; <*mut structs::Token>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCs31EPG3twprw_7structs5Token10cast_sliceBG_(ptr %self, i64 %len) unnamed_addr #0 !guid !604 {
start:
; call core::ptr::slice_from_raw_parts_mut::<structs::Token>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCs31EPG3twprw_7structs5TokenEBT_(ptr %self, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut structs::Version>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCs31EPG3twprw_7structs7Version10cast_sliceBG_(ptr %self, i64 %len) unnamed_addr #0 !guid !605 {
start:
; call core::ptr::slice_from_raw_parts_mut::<structs::Version>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCs31EPG3twprw_7structs7VersionEBT_(ptr %self, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut char>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOc10cast_sliceCs31EPG3twprw_7structs(ptr %self, i64 %len) unnamed_addr #0 !guid !606 {
start:
; call core::ptr::slice_from_raw_parts_mut::<char>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutcECs31EPG3twprw_7structs(ptr %self, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs31EPG3twprw_7structs(i64 %0, i64 %1) unnamed_addr #0 !guid !607 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs31EPG3twprw_7structs(ptr align 8 %layout) #24
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs31EPG3twprw_7structs(ptr align 8 %layout) #24
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs31EPG3twprw_7structs(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !608 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs31EPG3twprw_7structs(ptr align 8 %layout) #24
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs31EPG3twprw_7structs(ptr align 8 %layout) #24
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #29
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs31EPG3twprw_7structs(i64 %0, i64 %1) unnamed_addr #0 !guid !609 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #29
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs31EPG3twprw_7structs(ptr align 8 %layout) #24
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs31EPG3twprw_7structs(ptr align 8 %layout) #24
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #29
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs31EPG3twprw_7structs(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !610 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs31EPG3twprw_7structs(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #24
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #28
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #24
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCs31EPG3twprw_7structs() unnamed_addr #4 !guid !611 {
start:
  ret void
}

; core::ptr::swap_nonoverlapping_bytes
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytesCs31EPG3twprw_7structs(ptr %x, ptr %y, i64 %bytes) unnamed_addr #0 !guid !612 {
start:
  %_15 = alloca [8 x i8], align 8
  %_9 = alloca [8 x i8], align 8
; call <core::num::nonzero::NonZero<usize>>::get
  %bytes1 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %bytes) #24
  %chunks = udiv i64 %bytes1, 8
  %tail = urem i64 %bytes1, 8
; call <core::num::nonzero::NonZero<usize>>::new
  %0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %chunks) #24
  store i64 %0, ptr %_9, align 8
  %1 = load i64, ptr %_9, align 8
  %2 = icmp eq i64 %1, 0
  %_10 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_10 to i1
  br i1 %3, label %bb5, label %bb8

bb5:                                              ; preds = %start
  %chunks2 = load i64, ptr %_9, align 8
; call core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_chunks::<8>
  call void @_RINvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes26swap_nonoverlapping_chunksKj8_ECshGsV4pNJ6ra_6object(ptr %x, ptr %y, i64 %chunks2)
  br label %bb8

bb8:                                              ; preds = %bb5, %start
; call <core::num::nonzero::NonZero<usize>>::new
  %4 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %tail) #24
  store i64 %4, ptr %_15, align 8
  %5 = load i64, ptr %_15, align 8
  %6 = icmp eq i64 %5, 0
  %_16 = select i1 %6, i64 0, i64 1
  %7 = trunc nuw i64 %_16 to i1
  br i1 %7, label %bb10, label %bb13

bb10:                                             ; preds = %bb8
  %tail3 = load i64, ptr %_15, align 8
  %delta = mul i64 %chunks, 8
  %_0.i4 = getelementptr inbounds nuw i8, ptr %x, i64 %delta
  %_0.i = getelementptr inbounds nuw i8, ptr %y, i64 %delta
; call core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_short
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes25swap_nonoverlapping_shortCs31EPG3twprw_7structs(ptr %_0.i4, ptr %_0.i, i64 %tail3) #24
  br label %bb13

bb13:                                             ; preds = %bb10, %bb8
  ret void

bb14:                                             ; No predecessors!
  unreachable
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs31EPG3twprw_7structs(ptr %ptr, i64 %align) unnamed_addr #0 !guid !613 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs31EPG3twprw_7structs(ptr %ptr, i64 %align) #24
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() unnamed_addr #0 !guid !614 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs31EPG3twprw_7structs() #24
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs31EPG3twprw_7structs(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !615 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs31EPG3twprw_7structs(ptr %3, ptr %5, i64 %7, i64 %9) #24
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs31EPG3twprw_7structs(i64 %size, i64 %len) unnamed_addr #0 !guid !616 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #26
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs31EPG3twprw_7structs(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !617 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs31EPG3twprw_7structs(ptr %ptr, i64 %align) #24
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr %ptr) #24
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCs31EPG3twprw_7structs(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !618 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::char::methods::encode_utf8_raw_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtNtCsl10jNU3mE6R_4core4char7methods25encode_utf8_raw_uncheckedCs31EPG3twprw_7structs(i32 %code, ptr %dst) unnamed_addr #0 !guid !619 {
start:
; call core::char::methods::len_utf8
  %len = call i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs31EPG3twprw_7structs(i32 %code) #24
  %_4 = icmp eq i64 %len, 1
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_8 = lshr i32 %code, 0
  %_7 = and i32 %_8, 63
  %_6 = trunc i32 %_7 to i8
  %last1 = or i8 %_6, -128
  %_12 = lshr i32 %code, 6
  %_11 = and i32 %_12, 63
  %_10 = trunc i32 %_11 to i8
  %last2 = or i8 %_10, -128
  %_16 = lshr i32 %code, 12
  %_15 = and i32 %_16, 63
  %_14 = trunc i32 %_15 to i8
  %last3 = or i8 %_14, -128
  %_20 = lshr i32 %code, 18
  %_19 = and i32 %_20, 63
  %_18 = trunc i32 %_19 to i8
  %last4 = or i8 %_18, -16
  %_21 = icmp eq i64 %len, 2
  br i1 %_21, label %bb4, label %bb5

bb2:                                              ; preds = %start
  %0 = trunc i32 %code to i8
  store i8 %0, ptr %dst, align 1
  br label %bb14

bb5:                                              ; preds = %bb3
  %_23 = icmp eq i64 %len, 3
  br i1 %_23, label %bb7, label %bb8

bb4:                                              ; preds = %bb3
  %1 = or i8 %last2, -64
  store i8 %1, ptr %dst, align 1
  %_0.i = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last1, ptr %_0.i, align 1
  br label %bb14

bb8:                                              ; preds = %bb5
  store i8 %last4, ptr %dst, align 1
  %_0.i5 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last3, ptr %_0.i5, align 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last2, ptr %_0.i4, align 1
  %_0.i3 = getelementptr inbounds nuw i8, ptr %dst, i64 3
  store i8 %last1, ptr %_0.i3, align 1
  br label %bb14

bb7:                                              ; preds = %bb5
  %2 = or i8 %last3, -32
  store i8 %2, ptr %dst, align 1
  %_0.i2 = getelementptr inbounds nuw i8, ptr %dst, i64 1
  store i8 %last2, ptr %_0.i2, align 1
  %_0.i1 = getelementptr inbounds nuw i8, ptr %dst, i64 2
  store i8 %last1, ptr %_0.i1, align 1
  br label %bb14

bb14:                                             ; preds = %bb2, %bb4, %bb7, %bb8
  ret void
}

; core::char::methods::len_utf8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtCsl10jNU3mE6R_4core4char7methods8len_utf8Cs31EPG3twprw_7structs(i32 %code) unnamed_addr #0 !guid !620 {
start:
  %_0 = alloca [8 x i8], align 8
  %_2 = icmp ult i32 %code, 128
  br i1 %_2, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_3 = icmp ult i32 %code, 2048
  br i1 %_3, label %bb5, label %bb2

bb6:                                              ; preds = %start
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %bb1
  %_4 = icmp ult i32 %code, 65536
  br i1 %_4, label %bb4, label %bb3

bb5:                                              ; preds = %bb1
  store i64 2, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
  store i64 4, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %bb2
  store i64 3, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; <[_]>::split_at_mut_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp22split_at_mut_unchecked18precondition_checkCs31EPG3twprw_7structs(i64 %mid, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !621 {
start:
  %_3 = icmp ule i64 %mid, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_6b0b11c9e93314b588b613b55005cf18, i64 221)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs31EPG3twprw_7structs(i64 %align, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !622 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs31EPG3twprw_7structs(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !623 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs31EPG3twprw_7structs(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !624 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs31EPG3twprw_7structs(ptr %ptr, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !625 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullB6_(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs31EPG3twprw_7structs(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !626 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs31EPG3twprw_7structs(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !627 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCs31EPG3twprw_7structs(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !628 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !629 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs31EPG3twprw_7structs(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs31EPG3twprw_7structs(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs31EPG3twprw_7structs(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; core::ptr::swap_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %x, ptr %y, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !630 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %size, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %count, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_11 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs31EPG3twprw_7structs(ptr %x, i64 %align, i1 zeroext %_11)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_14 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_12 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs31EPG3twprw_7structs(ptr %y, i64 %align, i1 zeroext %_14)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_12, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs31EPG3twprw_7structs(ptr %x, ptr %y, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_2875d9f120b8cc0de1c30c014c7b6715, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_18.0 = extractvalue { ptr, ptr } %10, 0
  %_18.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_18.0, ptr %_18.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_short
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes25swap_nonoverlapping_shortCs31EPG3twprw_7structs(ptr %x, ptr %y, i64 %bytes) unnamed_addr #0 !guid !631 {
start:
  %i = alloca [8 x i8], align 8
; call <core::num::nonzero::NonZero<usize>>::get
  %bytes1 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %bytes) #24
  store i64 0, ptr %i, align 8
  %_7 = and i64 %bytes1, 4
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb2, label %bb8

bb8:                                              ; preds = %bb2, %start
  %_18 = and i64 %bytes1, 2
  %_17 = icmp ne i64 %_18, 0
  br i1 %_17, label %bb9, label %bb15

bb2:                                              ; preds = %start
  %_12 = load i64, ptr %i, align 8
  %_0.i6 = getelementptr inbounds nuw i8, ptr %x, i64 %_12
  %_16 = load i64, ptr %i, align 8
  %_0.i5 = getelementptr inbounds nuw i8, ptr %y, i64 %_16
; call core::ptr::swap_chunk::<4>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj4_ECshGsV4pNJ6ra_6object(ptr %_0.i6, ptr %_0.i5) #24
  %0 = load i64, ptr %i, align 8
  %1 = or i64 %0, 4
  store i64 %1, ptr %i, align 8
  br label %bb8

bb15:                                             ; preds = %bb9, %bb8
  %_29 = and i64 %bytes1, 1
  %_28 = icmp ne i64 %_29, 0
  br i1 %_28, label %bb16, label %bb22

bb9:                                              ; preds = %bb8
  %_23 = load i64, ptr %i, align 8
  %_0.i4 = getelementptr inbounds nuw i8, ptr %x, i64 %_23
  %_27 = load i64, ptr %i, align 8
  %_0.i3 = getelementptr inbounds nuw i8, ptr %y, i64 %_27
; call core::ptr::swap_chunk::<2>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj2_ECshGsV4pNJ6ra_6object(ptr %_0.i4, ptr %_0.i3) #24
  %2 = load i64, ptr %i, align 8
  %3 = or i64 %2, 2
  store i64 %3, ptr %i, align 8
  br label %bb15

bb22:                                             ; preds = %bb16, %bb15
  ret void

bb16:                                             ; preds = %bb15
  %_34 = load i64, ptr %i, align 8
  %_0.i2 = getelementptr inbounds nuw i8, ptr %x, i64 %_34
  %_38 = load i64, ptr %i, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %y, i64 %_38
; call core::ptr::swap_chunk::<1>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj1_ECshGsV4pNJ6ra_6object(ptr %_0.i2, ptr %_0.i) #24
  %4 = load i64, ptr %i, align 8
  %5 = or i64 %4, 1
  store i64 %5, ptr %i, align 8
  br label %bb22
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs31EPG3twprw_7structs(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !632 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs31EPG3twprw_7structs(ptr %ptr, i64 %align) unnamed_addr #0 !guid !633 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr %ptr, i64 %align) #24
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs31EPG3twprw_7structs() unnamed_addr #0 !guid !634 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs31EPG3twprw_7structs(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !635 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs31EPG3twprw_7structs(i64 %size, i64 %count) #24
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs31EPG3twprw_7structs(i64 %_0.i2, i64 %_0.i) #24
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #27
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCs31EPG3twprw_7structs(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !636 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs31EPG3twprw_7structs(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_a28e8c8fd5088943a8b5d44af697ff83, i64 279)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs31EPG3twprw_7structs(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; core::slice::raw::from_raw_parts_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCs31EPG3twprw_7structs(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !637 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs31EPG3twprw_7structs(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_5c1a2f972552229672fc942406cfc298, i64 283)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs31EPG3twprw_7structs(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCs31EPG3twprw_7structs(i64 %this, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !638 {
start:
  %_3 = icmp ult i64 %this, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_97d92cbf2a68a6ac45a1b13da79836e4, i64 214)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs31EPG3twprw_7structs(i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !639 {
start:
  %_3 = icmp ule i64 %end, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_5a8fdd84b3281310cbf6b74bb6bf0065, i64 218)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtBb_3ops5range5RangejEINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs31EPG3twprw_7structs(i64 %start1, i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #2 personality ptr @rust_eh_personality !guid !640 {
start:
  %_4 = icmp uge i64 %end, %start1
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs31EPG3twprw_7structs(ptr @alloc_18d73aa062d524e9620b9e3b55bd9eb1, i64 218)
          to label %bb4 unwind label %terminate

bb1:                                              ; preds = %start
  %_5 = icmp ule i64 %end, %len
  br i1 %_5, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  ret void

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb4:                                              ; preds = %bb3
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_7.0, ptr %_7.1, i1 zeroext false, ptr align 8 %0) #27
  unreachable
}

; <structs::Version as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXCs31EPG3twprw_7structsNtB2_7VersionNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB2_(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !641 {
start:
  %_13 = alloca [8 x i8], align 8
  %_9 = getelementptr inbounds i8, ptr %self, i64 1
  %0 = getelementptr inbounds i8, ptr %self, i64 2
  store ptr %0, ptr %_13, align 8
; call <core::fmt::Formatter>::debug_struct_field3_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field3_finish(ptr align 8 %f, ptr @alloc_94a6065ee1f45dfce5759e12c7406524, i64 7, ptr @alloc_4cdb24b42a80f22b6b821bb3f8a02159, i64 5, ptr %self, ptr align 8 @vtable.4, ptr @alloc_274e8598b8ce915f77b7aff9fb214dfa, i64 5, ptr %_9, ptr align 8 @vtable.4, ptr @alloc_9b505451451ec50119c3c52e8a43d511, i64 5, ptr %_13, ptr align 8 @vtable.5)
  ret i1 %_0
}

; <alloc::vec::Vec<char> as alloc::vec::spec_extend::SpecExtend<char, core::str::iter::Chars>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB4_3VeccEINtB2_10SpecExtendcNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE11spec_extendCs31EPG3twprw_7structs(ptr align 8 %self, ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !642 {
start:
; call <alloc::vec::Vec<char>>::extend_desugared::<core::str::iter::Chars>
  call void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VeccE16extend_desugaredNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsECs31EPG3twprw_7structs(ptr align 8 %self, ptr %iter.0, ptr %iter.1)
  ret void
}

; <alloc::vec::Vec<char> as alloc::vec::spec_from_iter::SpecFromIter<char, core::str::iter::Chars>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VeccEINtB2_12SpecFromItercNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE9from_iterCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %iterator.0, ptr %iterator.1) unnamed_addr #1 !guid !643 {
start:
; call <alloc::vec::Vec<char> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<char, core::str::iter::Chars>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB4_3VeccEINtB2_18SpecFromIterNestedcNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE9from_iterCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %iterator.0, ptr %iterator.1)
  ret void
}

; <alloc::vec::Vec<char> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<char, core::str::iter::Chars>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB4_3VeccEINtB2_18SpecFromIterNestedcNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE9from_iterCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !644 {
start:
  %2 = alloca [16 x i8], align 8
  %_23 = alloca [1 x i8], align 1
  %_22 = alloca [1 x i8], align 1
  %vector1 = alloca [24 x i8], align 8
  %_8 = alloca [24 x i8], align 8
  %_3 = alloca [4 x i8], align 4
  %vector = alloca [24 x i8], align 8
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %3 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_23, align 1
  store i8 0, ptr %_22, align 1
  store i8 1, ptr %_23, align 1
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
  %4 = call i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCs31EPG3twprw_7structs(ptr align 8 %iterator) #24
  store i32 %4, ptr %_3, align 4
  br label %bb1

bb1:                                              ; preds = %start
  %5 = load i32, ptr %_3, align 4
  %6 = icmp eq i32 %5, -1
  %_5 = select i1 %6, i64 0, i64 1
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
  store i8 1, ptr %_22, align 1
  %element = load i32, ptr %_3, align 4
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator9size_hintCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_8, ptr align 8 %iterator) #24
  br label %bb5

bb4:                                              ; preds = %bb1
; call <alloc::vec::Vec<char>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeccE3newCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0) #24
  br label %bb13

bb13:                                             ; preds = %bb4
  br label %bb14

bb14:                                             ; preds = %bb12, %bb13
  ret void

bb5:                                              ; preds = %bb3
  %lower = load i64, ptr %_8, align 8
  %_0.i = call i64 @llvm.uadd.sat.i64(i64 %lower, i64 1)
  br label %bb6

bb6:                                              ; preds = %bb5
; call core::cmp::max::<usize>
  %initial_capacity = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64 4, i64 %_0.i) #24
  br label %bb7

bb7:                                              ; preds = %bb6
; call <alloc::vec::Vec<char>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeccE13with_capacityCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %vector1, i64 %initial_capacity) #24
  br label %bb8

bb8:                                              ; preds = %bb7
; invoke <alloc::vec::Vec<char>>::as_mut_ptr
  %_14 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE10as_mut_ptrCs31EPG3twprw_7structs(ptr align 8 %vector1)
          to label %bb9 unwind label %cleanup

bb16:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECs31EPG3twprw_7structs(ptr align 8 %vector1) #21
          to label %bb19 unwind label %terminate

cleanup:                                          ; preds = %bb10, %bb8
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb16

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_22, align 1
  store i32 %element, ptr %_14, align 4
  br label %bb10

bb10:                                             ; preds = %bb9
; invoke <alloc::vec::Vec<char>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7set_lenCs31EPG3twprw_7structs(ptr align 8 %vector1, i64 1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %vector, ptr align 8 %vector1, i64 24, i1 false)
  store i8 0, ptr %_22, align 1
  store i8 0, ptr %_23, align 1
  %_21.0 = load ptr, ptr %iterator, align 8
  %12 = getelementptr inbounds i8, ptr %iterator, i64 8
  %_21.1 = load ptr, ptr %12, align 8
; invoke <alloc::vec::Vec<char> as alloc::vec::spec_extend::SpecExtend<char, core::str::iter::Chars>>::spec_extend
  invoke void @_RNvXNtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB4_3VeccEINtB2_10SpecExtendcNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE11spec_extendCs31EPG3twprw_7structs(ptr align 8 %vector, ptr %_21.0, ptr %_21.1)
          to label %bb12 unwind label %cleanup2

bb15:                                             ; preds = %cleanup2
; invoke core::ptr::drop_glue::<alloc::vec::Vec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECs31EPG3twprw_7structs(ptr align 8 %vector) #21
          to label %bb21 unwind label %terminate

cleanup2:                                         ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          cleanup
  %14 = extractvalue { ptr, i32 } %13, 0
  %15 = extractvalue { ptr, i32 } %13, 1
  store ptr %14, ptr %2, align 8
  %16 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %15, ptr %16, align 8
  br label %bb15

bb12:                                             ; preds = %bb11
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %vector, i64 24, i1 false)
  br label %bb14

terminate:                                        ; preds = %bb16, %bb15
  %17 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb21:                                             ; preds = %bb18, %bb19, %bb15
  %18 = load i8, ptr %_23, align 1
  %19 = trunc nuw i8 %18 to i1
  br i1 %19, label %bb20, label %bb17

bb19:                                             ; preds = %bb16
  %20 = load i8, ptr %_22, align 1
  %21 = trunc nuw i8 %20 to i1
  br i1 %21, label %bb18, label %bb21

bb18:                                             ; preds = %bb19
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb17:                                             ; preds = %bb20, %bb21
  %22 = load ptr, ptr %2, align 8
  %23 = getelementptr inbounds i8, ptr %2, i64 8
  %24 = load i32, ptr %23, align 8
  %25 = insertvalue { ptr, i32 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i32 } %25, i32 %24, 1
  resume { ptr, i32 } %26

bb20:                                             ; preds = %bb21
  br label %bb17
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !645 {
start:
; call core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>
  %0 = call { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEEB6_(ptr align 8 %self) #24
  %_2.0 = extractvalue { i32, i32 } %0, 0
  %_2.1 = extractvalue { i32, i32 } %0, 1
; call <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}>
  %_0 = call i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXNtNtB5_3str4iterNtBU_5CharsNtNtNtNtB5_4iter6traits8iterator8Iterator4next0EB5_(i32 %_2.0, i32 %_2.1) #24
  ret i32 %_0
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator9size_hintCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !646 {
start:
  %_0.i = alloca [8 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.i = load ptr, ptr %0, align 8
  %_6.i = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedB9_(ptr %_5.i, ptr %_6.i) #24
  store i64 %1, ptr %_0.i, align 8
  %2 = load i64, ptr %_0.i, align 8
; call <usize>::div_ceil
  %_4 = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8div_ceilCs31EPG3twprw_7structs(i64 %2, i64 4, ptr align 8 @alloc_1a7c685630b0735376eef9074b3e654a) #24
  store i64 %_4, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %2, ptr %4, align 8
  ret void
}

; <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters6cloned6ClonedINtNtNtB8_5slice4iter4ItercEENtB2_12IntoIterator9into_iterCs31EPG3twprw_7structs(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !647 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<[u8; 3]> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterAhj3_ENtB2_12IntoIterator9into_iterCs31EPG3twprw_7structs(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !648 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<structs::Version> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterNtCs31EPG3twprw_7structs7VersionENtB2_12IntoIterator9into_iterB1d_(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !649 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<char> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4ItercENtB2_12IntoIterator9into_iterCs31EPG3twprw_7structs(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !650 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitReENtB2_11PartialDrop12partial_dropCs31EPG3twprw_7structs(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !651 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&str>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitReE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECs31EPG3twprw_7structs(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1, ptr align 8 @alloc_c7037efb906203803aa3ca07167c9120) #24
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<&str>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitReE8is_emptyCs31EPG3twprw_7structs(ptr align 8 %_3.0, i64 %_3.1) #24
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitReE16assume_init_dropCs31EPG3twprw_7structs.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitReE16assume_init_dropCs31EPG3twprw_7structs.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitReE16assume_init_dropCs31EPG3twprw_7structs.exit: ; preds = %start, %bb2.i
  ret void
}

; <core::hint::select_unpredictable::DropOnPanic<*const structs::Version> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNvNtCsl10jNU3mE6R_4core4hint20select_unpredictableINtB2_11DropOnPanicPNtCs31EPG3twprw_7structs7VersionENtNtNtB6_3ops4drop4Drop4dropB1c_(ptr align 8 %self) unnamed_addr #1 !guid !652 {
start:
  %_2 = load ptr, ptr %self, align 8
  ret void
}

; <[&str; 4] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterARej4_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs31EPG3twprw_7structs(ptr sret([80 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !653 {
start:
  %0 = alloca [80 x i8], align 8
  %_2.i = alloca [80 x i8], align 8
  %1 = alloca [80 x i8], align 8
  %2 = alloca [64 x i8], align 8
  %_5 = alloca [80 x i8], align 8
  %inner = alloca [80 x i8], align 8
  %data = alloca [64 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %self, i64 64, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCs31EPG3twprw_7structs(i64 4) #24
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %data, i64 64, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj4_E13new_uncheckedCs31EPG3twprw_7structs(ptr sret([80 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 8 %2) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 80, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 80, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitReEj4_EE3newCs31EPG3twprw_7structs(ptr sret([80 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 80, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 80, i1 false)
  ret void
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitReEE13get_uncheckedCs31EPG3twprw_7structs(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !654 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&str>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitReEECs31EPG3twprw_7structs(ptr %slice.0, i64 %slice.1) #24
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<&str>", ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&str>]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitReEECs31EPG3twprw_7structs(ptr %slice.0, i64 %slice.1) #24
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCs31EPG3twprw_7structs(i64 %self, i64 %_0.i1, ptr align 8 %0) #25
  br label %bb4
}

; <usize as core::slice::index::SliceIndex<[structs::Version]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE13get_uncheckedB10_(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !655 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[structs::Version]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSNtCs31EPG3twprw_7structs7VersionEBO_(ptr %slice.0, i64 %slice.1) #24
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw %Version, ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[structs::Version]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSNtCs31EPG3twprw_7structs7VersionEBO_(ptr %slice.0, i64 %slice.1) #24
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCs31EPG3twprw_7structs(i64 %self, i64 %_0.i1, ptr align 8 %0) #25
  br label %bb4
}

; <usize as core::slice::index::SliceIndex<[structs::Version]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE5indexB10_(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !656 {
start:
  %_4 = icmp ult i64 %self, %slice.1
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw %Version, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #26
  unreachable
}

; <usize as core::slice::index::SliceIndex<[char]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexScE5indexCs31EPG3twprw_7structs(i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !657 {
start:
  %_4 = icmp ult i64 %self, %slice.1
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #26
  unreachable
}

; <structs::Version as core::slice::sort::stable::quicksort::IsFreeze>::is_freeze
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs0_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortNtCs31EPG3twprw_7structs7VersionNtB5_8IsFreeze9is_freezeB10_() unnamed_addr #1 !guid !658 {
start:
  ret i1 true
}

; <(i32, &str, f64) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1F_NtCsl10jNU3mE6R_4core3fmtTlRedENtB6_5Debug3fmtCs31EPG3twprw_7structs(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !659 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %V = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %0, ptr %V, align 8
  store ptr %self, ptr %U, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 24
  store ptr %1, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_8 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %V, ptr align 8 @vtable.6)
; call <core::fmt::builders::DebugTuple>::field
  %_12 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.7)
; call <core::fmt::builders::DebugTuple>::field
  %_16 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.8)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs31EPG3twprw_7structs(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !660 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs31EPG3twprw_7structs(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #24
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs31EPG3twprw_7structs(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !661 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs31EPG3twprw_7structs(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<structs::Token> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs5TokenENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %self) unnamed_addr #1 !guid !662 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 8, i64 16)
  ret void
}

; <alloc::raw_vec::RawVec<structs::Version> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %self) unnamed_addr #1 !guid !663 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 1, i64 3)
  ret void
}

; <alloc::raw_vec::RawVec<char> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #1 !guid !664 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 4, i64 4)
  ret void
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitReEE17get_unchecked_mutCs31EPG3twprw_7structs(i64 %0, i64 %1, ptr %slice.0, i64 %slice.1, ptr align 8 %2) unnamed_addr #0 !guid !665 {
start:
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ops::index_range::IndexRange>::end
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCs31EPG3twprw_7structs(ptr align 8 %self) #24
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<&str>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitReEECs31EPG3twprw_7structs(ptr %slice.0, i64 %slice.1) #24
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs31EPG3twprw_7structs(i64 %_5, i64 %_0.i, ptr align 8 %2) #25
  br label %bb4

bb4:                                              ; preds = %bb1
; call <core::ops::index_range::IndexRange>::start
  %_8 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCs31EPG3twprw_7structs(ptr align 8 %self) #24
; call <core::ops::index_range::IndexRange>::len
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCs31EPG3twprw_7structs(ptr align 8 %self) #24
  %ptr.i = getelementptr inbounds nuw %"core::mem::maybe_uninit::MaybeUninit<&str>", ptr %slice.0, i64 %_8
  %4 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_10, 1
  %_0.0 = extractvalue { ptr, i64 } %5, 0
  %_0.1 = extractvalue { ptr, i64 } %5, 1
  %6 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %_0.1, 1
  ret { ptr, i64 } %7
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEj4_ENtNtNtBb_3ops4drop4Drop4dropCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !666 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCs31EPG3twprw_7structs(ptr align 8 %self) #24
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<&str>; 4] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitReEj4_NtB4_11PartialDrop12partial_dropCs31EPG3twprw_7structs(ptr align 8 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <&[u8; 3] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAhj3_NtB6_5Debug3fmtCs31EPG3twprw_7structs(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !667 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <[u8; 3] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAhj3_NtNtB7_3fmt5Debug3fmtCs31EPG3twprw_7structs(ptr %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&structs::Token as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtCs31EPG3twprw_7structs5TokenNtB6_5Debug3fmtBy_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !668 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <structs::Token as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs9_Cs31EPG3twprw_7structsNtB5_5TokenNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_(ptr align 8 %_3, ptr align 8 %f) #24
  ret i1 %_0
}

; <&structs::Version as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtCs31EPG3twprw_7structs7VersionNtB6_5Debug3fmtBy_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !669 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <structs::Version as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXCs31EPG3twprw_7structsNtB2_7VersionNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB2_(ptr %_3, ptr align 8 %f) #24
  ret i1 %_0
}

; <&core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num11float_parse14FloatErrorKindNtB6_5Debug3fmtCs31EPG3twprw_7structs(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !670 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_14FloatErrorKindNtNtB9_3fmt5Debug3fmtCs31EPG3twprw_7structs(ptr %_3, ptr align 8 %f) #24
  ret i1 %_0
}

; <&[[u8; 3]] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSAhj3_NtB6_5Debug3fmtCs31EPG3twprw_7structs(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !671 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[[u8; 3]] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSAhj3_NtB5_5Debug3fmtCs31EPG3twprw_7structs(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&char as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRcNtB6_5Debug3fmtCs31EPG3twprw_7structs(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !672 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <char as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsj_NtCsl10jNU3mE6R_4core3fmtcNtB5_5Debug3fmt(ptr align 4 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCs31EPG3twprw_7structs(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !673 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <f64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <core::slice::iter::Iter<[u8; 3]> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterAhj3_ENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !674 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<[u8; 3]> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAhj3_ENtNtB9_3cmp9PartialEq2eqCs31EPG3twprw_7structs(ptr align 8 %ptr, ptr align 8 %_11) #24
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw [3 x i8], ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<structs::Version> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterNtCs31EPG3twprw_7structs7VersionENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBR_(ptr align 8 %self) unnamed_addr #0 !guid !675 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<structs::Version> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs31EPG3twprw_7structs7VersionENtNtB9_3cmp9PartialEq2eqBV_(ptr align 8 %ptr, ptr align 8 %_11) #24
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw %Version, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4ItercENtNtNtNtBa_4iter6traits8iterator8Iterator9size_hintCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !676 {
start:
  %exact = alloca [8 x i8], align 8
  br label %bb3

bb3:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_6 = load ptr, ptr %0, align 8
  %_7 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<char>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullcE20offset_from_unsignedCs31EPG3twprw_7structs(ptr %_6, ptr %_7) #24
  store i64 %1, ptr %exact, align 8
  br label %bb4

bb4:                                              ; preds = %bb3
  %_8 = load i64, ptr %exact, align 8
  %_10 = load i64, ptr %exact, align 8
  store i64 %_8, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %_10, ptr %3, align 8
  ret void

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[structs::Version]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE17get_unchecked_mutB1r_(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !677 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[structs::Version]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSNtCs31EPG3twprw_7structs7VersionEBO_(ptr %slice.0, i64 %slice.1) #24
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtBb_3ops5range5RangejEINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs31EPG3twprw_7structs(i64 %self.0, i64 %self.1, i64 %_0.i, ptr align 8 %0) #25
  br label %bb3

bb3:                                              ; preds = %bb1
  %new_len = sub nuw i64 %self.1, %self.0
  %ptr.i = getelementptr inbounds nuw %Version, ptr %slice.0, i64 %self.0
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %new_len, 1
  %_0.0 = extractvalue { ptr, i64 } %2, 0
  %_0.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1, 1
  ret { ptr, i64 } %4
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1r_(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !678 {
start:
  %_3 = alloca [16 x i8], align 8
; call <usize>::checked_sub
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCs31EPG3twprw_7structs(i64 %self.1, i64 %self.0) #24
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_6 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_6 to i1
  br i1 %7, label %bb2, label %bb5

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %new_len = load i64, ptr %8, align 8
  %_8 = icmp ule i64 %self.1, %slice.1
  br i1 %_8, label %bb3, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %self.0, i64 %self.1, i64 %slice.1, ptr align 8 %0) #26
  unreachable

bb3:                                              ; preds = %bb2
  %ptr.i = getelementptr inbounds nuw %Version, ptr %slice.0, i64 %self.0
  %9 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %new_len, 1
  %_12.0 = extractvalue { ptr, i64 } %10, 0
  %_12.1 = extractvalue { ptr, i64 } %10, 1
  %11 = insertvalue { ptr, i64 } poison, ptr %_12.0, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %_12.1, 1
  ret { ptr, i64 } %12

bb6:                                              ; No predecessors!
  unreachable
}

; <core::num::float_parse::ParseFloatError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_15ParseFloatErrorNtNtB9_3fmt5Debug3fmtCs31EPG3twprw_7structs(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !679 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_252aee8158a2b6b4b1e300c3f8f7bd7a, i64 15, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.9)
  ret i1 %_0
}

; <core::array::iter::IntoIter<&str, 4> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj4_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !680 {
start:
; call <core::array::iter::IntoIter<&str, 4>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterReKj4_E10unsize_mutCs31EPG3twprw_7structs(ptr align 8 %self) #24
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>]>>::next
  %1 = call { ptr, i64 } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitReEE4nextCs31EPG3twprw_7structs(ptr align 8 %_2.0, i64 %_2.1) #24
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1t_(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !681 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
  %1 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1r_(i64 0, i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) #24
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <structs::Version as core::cmp::PartialOrd>::partial_cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXs5_Cs31EPG3twprw_7structsNtB5_7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd11partial_cmpB5_(ptr %self, ptr %other) unnamed_addr #0 !guid !682 {
start:
; call <structs::Version as core::cmp::Ord>::cmp
  %_3 = call i8 @_RNvXs6_Cs31EPG3twprw_7structsNtB5_7VersionNtNtCsl10jNU3mE6R_4core3cmp3Ord3cmpB5_(ptr %self, ptr %other) #24
  ret i8 %_3
}

; <core::ops::index_range::IndexRange as core::clone::Clone>::clone
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !683 {
start:
  %_2 = load i64, ptr %self, align 8
  %_5 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %_5, align 8
  %0 = insertvalue { i64, i64 } poison, i64 %_2, 0
  %1 = insertvalue { i64, i64 } %0, i64 %_4, 1
  ret { i64, i64 } %1
}

; <core::array::iter::IntoIter<&str, 4> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterReKj4_ENtNtNtB9_3ops4drop4Drop4dropCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !684 {
start:
; call core::mem::needs_drop::<&str>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropReECs31EPG3twprw_7structs() #24
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<&str>; 4]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitReEj4_EE4dropCs31EPG3twprw_7structs(ptr align 8 %self) #24
  br label %bb3
}

; <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[structs::Version]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE9index_mutB1v_(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !685 {
start:
  %_3 = icmp ugt i64 %self, %slice.1
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %new_len = sub nuw i64 %slice.1, %self
  %ptr.i = getelementptr inbounds nuw %Version, ptr %slice.0, i64 %self
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %new_len, 1
  %_17.0 = extractvalue { ptr, i64 } %2, 0
  %_17.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_17.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_17.1, 1
  ret { ptr, i64 } %4

bb1:                                              ; preds = %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %self, i64 %slice.1, i64 %slice.1, ptr align 8 %0) #26
  unreachable
}

; <core::slice::sort::shared::smallsort::CopyOnDrop<structs::Version> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs5_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsortINtB5_10CopyOnDropNtCs31EPG3twprw_7structs7VersionENtNtNtBd_3ops4drop4Drop4dropB1i_(ptr align 8 %self) unnamed_addr #1 !guid !686 {
start:
  %_3 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %1, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %start
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_3, ptr %_4, i64 3, i64 1, i64 %_5, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %start, %bb2.i
  %2 = mul nuw nsw i64 %_5, 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_4, ptr align 1 %_3, i64 %2, i1 false)
  ret void
}

; <structs::Version as core::cmp::Ord>::cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXs6_Cs31EPG3twprw_7structsNtB5_7VersionNtNtCsl10jNU3mE6R_4core3cmp3Ord3cmpB5_(ptr %self, ptr %other) unnamed_addr #0 !guid !687 {
start:
  %_0 = alloca [1 x i8], align 1
; call <u8 as core::cmp::Ord>::cmp
  %cmp = call i8 @_RNvXsX_NtNtCsl10jNU3mE6R_4core3cmp5implshNtB7_3Ord3cmpCs31EPG3twprw_7structs(ptr %self, ptr %other) #24
  %0 = icmp eq i8 %cmp, 0
  br i1 %0, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %_8 = getelementptr inbounds i8, ptr %self, i64 1
  %_9 = getelementptr inbounds i8, ptr %other, i64 1
; call <u8 as core::cmp::Ord>::cmp
  %cmp1 = call i8 @_RNvXsX_NtNtCsl10jNU3mE6R_4core3cmp5implshNtB7_3Ord3cmpCs31EPG3twprw_7structs(ptr %_8, ptr %_9) #24
  %1 = icmp eq i8 %cmp1, 0
  br i1 %1, label %bb6, label %bb5

bb2:                                              ; preds = %start
  store i8 %cmp, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
  %_11 = getelementptr inbounds i8, ptr %self, i64 2
  %_12 = getelementptr inbounds i8, ptr %other, i64 2
; call <u8 as core::cmp::Ord>::cmp
  %2 = call i8 @_RNvXsX_NtNtCsl10jNU3mE6R_4core3cmp5implshNtB7_3Ord3cmpCs31EPG3twprw_7structs(ptr %_11, ptr %_12) #24
  store i8 %2, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
  store i8 %cmp1, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %3 = load i8, ptr %_0, align 1
  ret i8 %3
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[[u8; 3]]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSAhj3_E5indexCs31EPG3twprw_7structs(ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !688 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <structs::Version as core::default::Default>::default
; Function Attrs: inlinehint nonlazybind uwtable
define internal i24 @_RNvXs8_Cs31EPG3twprw_7structsNtB5_7VersionNtNtCsl10jNU3mE6R_4core7default7Default7defaultB5_() unnamed_addr #0 !guid !689 {
start:
  %_0 = alloca [4 x i8], align 1
  store i8 0, ptr %_0, align 1
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  %1 = getelementptr inbounds i8, ptr %_0, i64 2
  store i8 0, ptr %1, align 1
  %2 = load i24, ptr %_0, align 1
  ret i24 %2
}

; <alloc::vec::Vec<structs::Token> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefBH_(ptr align 8 %self) unnamed_addr #0 !guid !690 {
start:
; call <alloc::vec::Vec<structs::Token>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs5TokenE8as_sliceBG_(ptr align 8 %self) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<structs::Version> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefBH_(ptr align 8 %self) unnamed_addr #0 !guid !691 {
start:
; call <alloc::vec::Vec<structs::Version>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE8as_sliceBG_(ptr align 8 %self) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<char> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !692 {
start:
; call <alloc::vec::Vec<char>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8as_sliceCs31EPG3twprw_7structs(ptr align 8 %self) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::boxed::Box<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxINtNtNtCsl10jNU3mE6R_4core3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EENtNtNtBO_3ops4drop4Drop4dropB1F_(ptr align 8 %self) unnamed_addr #0 !guid !693 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr = load ptr, ptr %self, align 8
; call <core::ptr::unique::Unique<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>>::as_ptr
  %_5 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueINtNtNtB9_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EE6as_ptrB1y_(ptr %ptr) #24
; call <core::alloc::layout::Layout>::for_value_raw::<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>
  %0 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawINtNtNtB7_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EEB1M_(ptr %_5) #24
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %layout, align 8
  %3 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %2, ptr %3, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs31EPG3twprw_7structs(ptr align 8 %layout) #24
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ptr::unique::Unique<core::mem::maybe_uninit::MaybeUninit<[structs::Version; 3]>>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueINtNtNtBa_3mem12maybe_uninit11MaybeUninitANtCs31EPG3twprw_7structs7Versionj3_EE4casthEB1z_(ptr %ptr) #24
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #24
  %4 = load i64, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs31EPG3twprw_7structs(ptr %_10, ptr %_11, i64 %4, i64 %6) #24
  br label %bb7
}

; <alloc::boxed::Box<structs::Version> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBJ_(ptr align 8 %self) unnamed_addr #0 !guid !694 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr = load ptr, ptr %self, align 8
; call <core::ptr::unique::Unique<structs::Version>>::as_ptr
  %_5 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCs31EPG3twprw_7structs7VersionE6as_ptrBS_(ptr %ptr) #24
; call <core::alloc::layout::Layout>::for_value_raw::<structs::Version>
  %0 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawNtCs31EPG3twprw_7structs7VersionEB16_(ptr %_5) #24
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %layout, align 8
  %3 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %2, ptr %3, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs31EPG3twprw_7structs(ptr align 8 %layout) #24
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ptr::unique::Unique<structs::Version>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueNtCs31EPG3twprw_7structs7VersionE4casthEBT_(ptr %ptr) #24
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #24
  %4 = load i64, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs31EPG3twprw_7structs(ptr %_10, ptr %_11, i64 %4, i64 %6) #24
  br label %bb7
}

; <alloc::boxed::Box<[structs::Version]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %self) unnamed_addr #0 !guid !695 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[structs::Version]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCs31EPG3twprw_7structs7VersionE6as_ptrBT_(ptr %ptr.0, i64 %ptr.1) #24
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[structs::Version]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCs31EPG3twprw_7structs7VersionEB17_(ptr %_5.0, i64 %_5.1) #24
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs31EPG3twprw_7structs(ptr align 8 %layout) #24
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[structs::Version]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCs31EPG3twprw_7structs7VersionE4casthEBU_(ptr %ptr.0, i64 %ptr.1) #24
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #24
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs31EPG3twprw_7structs(ptr %_10, ptr %_11, i64 %6, i64 %8) #24
  br label %bb7
}

; <alloc::vec::Vec<structs::Version> as core::slice::sort::stable::BufGuard<structs::Version>>::with_capacity
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VecNtCs31EPG3twprw_7structs7VersionEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardBN_E13with_capacityBP_(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !696 {
start:
; call <alloc::vec::Vec<structs::Version>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecNtCs31EPG3twprw_7structs7VersionE13with_capacityBE_(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #24
  ret void
}

; <alloc::vec::Vec<structs::Version> as core::slice::sort::stable::BufGuard<structs::Version>>::as_uninit_slice_mut
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VecNtCs31EPG3twprw_7structs7VersionEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardBN_E19as_uninit_slice_mutBP_(ptr align 8 %self) unnamed_addr #1 !guid !697 {
start:
; call <alloc::vec::Vec<structs::Version>>::spare_capacity_mut
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE18spare_capacity_mutBG_(ptr align 8 %self) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::num::float_parse::FloatErrorKind as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs8_NtNtCsl10jNU3mE6R_4core3num11float_parseNtB5_14FloatErrorKindNtNtB9_3fmt5Debug3fmtCs31EPG3twprw_7structs(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !698 {
start:
  %_3 = alloca [16 x i8], align 8
  %0 = load i8, ptr %self, align 1
  %1 = trunc nuw i8 %0 to i1
  %_4 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_4 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr @alloc_6693e43df3406efcf64b4ab3d59228bb, ptr %_3, align 8, !captures !349
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 7, ptr %3, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store ptr @alloc_59ba7b9f7211443cd55a366616eef46a, ptr %_3, align 8, !captures !349
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %4, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_3, align 8
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  %7 = load i64, ptr %6, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %5, i64 %7)
  ret i1 %_0

bb1:                                              ; No predecessors!
  unreachable
}

; <structs::Token as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs9_Cs31EPG3twprw_7structsNtB5_5TokenNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !699 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i32, ptr %self, align 8
  %_3 = zext i32 %0 to i64
  switch i64 %_3, label %bb1 [
    i64 0, label %bb5
    i64 1, label %bb4
    i64 2, label %bb3
    i64 3, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb5:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %2 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_cd8bd3d0cc5cd08c5d601c797c5ed9fe, i64 3, ptr %__self_0, ptr align 8 @vtable.8)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb6

bb4:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  store ptr %4, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_523bf151c3c09163b55b95f71c18ed3a, i64 2, ptr %__self_01, ptr align 8 @vtable.a)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb6

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_cc20e6bc48d43d2101037702189cb9d9, i64 6)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb6

bb2:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %9 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_70ea4c882379873e16e82da9fde23a53, i64 6)
  %10 = zext i1 %9 to i8
  store i8 %10, ptr %_0, align 1
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3, %bb4, %bb5
  %11 = load i8, ptr %_0, align 1
  %12 = trunc nuw i8 %11 to i1
  ret i1 %12
}

; <alloc::vec::Vec<structs::Version> as core::ops::deref::DerefMut>::deref_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutBH_(ptr align 8 %self) unnamed_addr #0 !guid !700 {
start:
; call <alloc::vec::Vec<structs::Version>>::as_mut_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE12as_mut_sliceBG_(ptr align 8 %self) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs31EPG3twprw_7structs() unnamed_addr #0 !guid !701 {
start:
  ret i8 0
}

; <u8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCs31EPG3twprw_7structs(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !702 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <u8 as core::cmp::Ord>::cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsX_NtNtCsl10jNU3mE6R_4core3cmp5implshNtB7_3Ord3cmpCs31EPG3twprw_7structs(ptr %self, ptr %other) unnamed_addr #0 !guid !703 {
start:
  %_3 = load i8, ptr %self, align 1
  %_4 = load i8, ptr %other, align 1
  %_0 = call i8 @llvm.ucmp.i8.i8(i8 %_3, i8 %_4)
  ret i8 %_0
}

; <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCs31EPG3twprw_7structs(ptr align 8 %0) unnamed_addr #0 !guid !704 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
; call <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_3 = call i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenB8_(ptr align 8 %self)
  %_2 = icmp ugt i64 %_3, 0
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  %1 = load ptr, ptr %self, align 8
; call <core::ops::index_range::IndexRange>::next_unchecked
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCs31EPG3twprw_7structs(ptr align 8 %1) #24
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <core::iter::adapters::cloned::Cloned<core::slice::iter::Iter<char>> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6clonedINtB4_6ClonedINtNtNtBa_5slice4iter4ItercEENtNtNtB8_6traits8iterator8Iterator9size_hintCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !705 {
start:
; call <core::slice::iter::Iter<char> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4ItercENtNtNtNtBa_4iter6traits8iterator8Iterator9size_hintCs31EPG3twprw_7structs(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #24
  ret void
}

; <[core::mem::maybe_uninit::MaybeUninit<&str>; 4] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitReEj4_NtB4_11PartialDrop12partial_dropCs31EPG3twprw_7structs(ptr align 8 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !706 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<&str>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitReENtB2_11PartialDrop12partial_dropCs31EPG3twprw_7structs(ptr align 8 %self, i64 4, i64 %alive.0, i64 %alive.1)
  ret void
}

; <core::slice::sort::stable::merge::MergeState<structs::Version> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB4_10MergeStateNtCs31EPG3twprw_7structs7VersionENtNtNtBc_3ops4drop4Drop4dropB1d_(ptr align 8 %self) unnamed_addr #1 !guid !707 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %_5 = load ptr, ptr %self, align 8
; call <*mut structs::Version>::offset_from_unsigned
  %len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCs31EPG3twprw_7structs7Version20offset_from_unsignedBE_(ptr %_3, ptr %_5, ptr align 8 @alloc_4a07d64a21980758f07ef2afc3d73d2d) #24
  %_8 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_9 = load ptr, ptr %1, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs31EPG3twprw_7structs() #24
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

bb2.i:                                            ; preds = %start
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs31EPG3twprw_7structs(ptr %_8, ptr %_9, i64 3, i64 1, i64 %len, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingNtCs31EPG3twprw_7structs7VersionEBO_.exit: ; preds = %start, %bb2.i
  %2 = mul nuw nsw i64 %len, 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_9, ptr align 1 %_8, i64 %2, i1 false)
  ret void
}

; <[[u8; 3]; 2] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAAhj3_j2_NtNtB7_3fmt5Debug3fmtCs31EPG3twprw_7structs(ptr %self, ptr align 8 %f) unnamed_addr #1 !guid !708 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[[u8; 3]; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAAhj3_j2_INtNtNtB7_3ops5index5IndexNtNtBK_5range9RangeFullE5indexCs31EPG3twprw_7structs(ptr %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #24
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !349
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[[u8; 3]] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSAhj3_NtB6_5Debug3fmtCs31EPG3twprw_7structs(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[u8; 3] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAhj3_NtNtB7_3fmt5Debug3fmtCs31EPG3twprw_7structs(ptr %self, ptr align 8 %f) unnamed_addr #1 !guid !709 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[u8; 3] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAhj3_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexB7_(ptr %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #24
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !349
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[u8] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRShNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <structs::Color as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_Cs31EPG3twprw_7structsNtB5_5ColorNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtB5_(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !710 {
start:
  %_3 = alloca [16 x i8], align 8
  %_4 = load i8, ptr %self, align 1
  switch i8 %_4, label %bb1 [
    i8 1, label %bb4
    i8 5, label %bb3
    i8 6, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb4:                                              ; preds = %start
  store ptr @alloc_f68f945f4b0d5582669e4f82589ddb09, ptr %_3, align 8, !captures !349
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 3, ptr %0, align 8
  br label %bb5

bb3:                                              ; preds = %start
  store ptr @alloc_c2c110312de72f05b4f6b2dd5161b81c, ptr %_3, align 8, !captures !349
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %1, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr @alloc_9dd73c20dc576e7c6b01311c1d3cd76d, ptr %_3, align 8, !captures !349
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %2, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3, %bb4
  %3 = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %5 = load i64, ptr %4, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %3, i64 %5)
  ret i1 %_0
}

; <alloc::vec::Vec<structs::Version> as core::ops::index::Index<usize>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexBH_(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !711 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<structs::Version> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefBH_(ptr align 8 %self) #24
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[structs::Version]>>::index
  %_0.i = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSNtCs31EPG3twprw_7structs7VersionE5indexB10_(i64 %index, ptr %_3.0, i64 %_3.1, ptr align 8 %0) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<char> as core::ops::index::Index<core::ops::range::Range<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBM_5range5RangejEE5indexCs31EPG3twprw_7structs(ptr align 8 %self, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !712 {
start:
  %_3.i = alloca [16 x i8], align 8
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<char> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs31EPG3twprw_7structs(ptr align 8 %self) #24
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize>::checked_sub
  %2 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCs31EPG3twprw_7structs(i64 %index.1, i64 %index.0) #24
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %_3.i, align 8
  %5 = getelementptr inbounds i8, ptr %_3.i, i64 8
  store i64 %4, ptr %5, align 8
  %_6.i = load i64, ptr %_3.i, align 8
  %6 = getelementptr inbounds i8, ptr %_3.i, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = trunc nuw i64 %_6.i to i1
  br i1 %8, label %bb2.i, label %bb5.i

bb2.i:                                            ; preds = %bb1
  %9 = getelementptr inbounds i8, ptr %_3.i, i64 8
  %new_len.i = load i64, ptr %9, align 8
  %_8.i = icmp ule i64 %index.1, %_3.1
  br i1 %_8.i, label %_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexScE5indexCs31EPG3twprw_7structs.exit, label %bb5.i

bb5.i:                                            ; preds = %bb2.i, %bb1
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %index.0, i64 %index.1, i64 %_3.1, ptr align 8 %0) #26
  unreachable

_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexScE5indexCs31EPG3twprw_7structs.exit: ; preds = %bb2.i
  %ptr.i.i = getelementptr inbounds nuw i32, ptr %_3.0, i64 %index.0
  %10 = insertvalue { ptr, i64 } poison, ptr %ptr.i.i, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %new_len.i, 1
  %12 = insertvalue { ptr, i64 } poison, ptr %ptr.i.i, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %new_len.i, 1
  %_0.0.i = extractvalue { ptr, i64 } %13, 0
  %_0.1.i = extractvalue { ptr, i64 } %13, 1
  %_0.0 = extractvalue { ptr, i64 } %13, 0
  %_0.1 = extractvalue { ptr, i64 } %13, 1
  br label %bb2

bb2:                                              ; preds = %_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexScE5indexCs31EPG3twprw_7structs.exit
  %14 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %_0.1, 1
  ret { ptr, i64 } %15

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<char> as core::ops::index::Index<usize>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCs31EPG3twprw_7structs(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !713 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<char> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs31EPG3twprw_7structs(ptr align 8 %self) #24
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[char]>>::index
  %_0.i = call align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexScE5indexCs31EPG3twprw_7structs(i64 %index, ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %0) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <[[u8; 3]; 2] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAAhj3_j2_INtNtNtB7_3ops5index5IndexNtNtBK_5range9RangeFullE5indexCs31EPG3twprw_7structs(ptr %self, ptr align 8 %0) unnamed_addr #0 !guid !714 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[[u8; 3]]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSAhj3_E5indexCs31EPG3twprw_7structs(ptr %self, i64 2, ptr align 8 %0) #24
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::non_null::NonNull<[u8; 3]> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAhj3_ENtNtB9_3cmp9PartialEq2eqCs31EPG3twprw_7structs(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !715 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<structs::Version> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtCs31EPG3twprw_7structs7VersionENtNtB9_3cmp9PartialEq2eqBV_(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !716 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <alloc::vec::Vec<structs::Token> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs5TokenENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %self) unnamed_addr #1 !guid !717 {
start:
; call <alloc::vec::Vec<structs::Token>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs5TokenE10as_mut_ptrBG_(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut structs::Token>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCs31EPG3twprw_7structs5Token10cast_sliceBG_(ptr %_3, i64 %_4) #24
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<structs::Version> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %self) unnamed_addr #1 !guid !718 {
start:
; call <alloc::vec::Vec<structs::Version>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCs31EPG3twprw_7structs7VersionE10as_mut_ptrBG_(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut structs::Version>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCs31EPG3twprw_7structs7Version10cast_sliceBG_(ptr %_3, i64 %_4) #24
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<char> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #1 !guid !719 {
start:
; call <alloc::vec::Vec<char>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE10as_mut_ptrCs31EPG3twprw_7structs(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut char>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOc10cast_sliceCs31EPG3twprw_7structs(ptr %_3, i64 %_4) #24
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<structs::Version> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtBH_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !720 {
start:
; call <alloc::vec::Vec<structs::Version> as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCs31EPG3twprw_7structs7VersionENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefBH_(ptr align 8 %self) #24
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[structs::Version] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSNtCs31EPG3twprw_7structs7VersionNtB5_5Debug3fmtBx_(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <[[u8; 3]] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSAhj3_NtB5_5Debug3fmtCs31EPG3twprw_7structs(ptr %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !721 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[[u8; 3]]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAhj3_4iterCs31EPG3twprw_7structs(ptr %self.0, i64 %self.1) #24
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&[u8; 3], core::slice::iter::Iter<[u8; 3]>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRAhj3_INtNtNtBa_5slice4iter4IterB14_EECs31EPG3twprw_7structs(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[structs::Version] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSNtCs31EPG3twprw_7structs7VersionNtB5_5Debug3fmtBx_(ptr %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !722 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[structs::Version]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSNtCs31EPG3twprw_7structs7Version4iterBw_(ptr %self.0, i64 %self.1) #24
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&structs::Version, core::slice::iter::Iter<structs::Version>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRNtCs31EPG3twprw_7structs7VersionINtNtNtBa_5slice4iter4IterB14_EEB16_(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs31EPG3twprw_7structs(ptr align 8 %self) unnamed_addr #0 !guid !723 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCs31EPG3twprw_7structs(ptr align 8 %self) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs31EPG3twprw_7structs(ptr %_1) unnamed_addr #0 !guid !724 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs31EPG3twprw_7structs(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !725 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs31EPG3twprw_7structs(ptr align 8 %_1) #24
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <structs::Version as core::cmp::PartialOrd>::lt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltB4_(ptr %self, ptr %other) unnamed_addr #0 !guid !726 {
start:
; call <structs::Version as core::cmp::PartialOrd>::partial_cmp
  %_3 = call i8 @_RNvXs5_Cs31EPG3twprw_7structsNtB5_7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd11partial_cmpB5_(ptr %self, ptr %other) #24
; call <core::option::Option<core::cmp::Ordering>>::is_some_and::<<core::cmp::Ordering>::is_lt>
  %_0 = call zeroext i1 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionNtNtB5_3cmp8OrderingE11is_some_andNvMBK_BI_5is_ltEB5_(i8 %_3) #24
  ret i1 %_0
}

; <structs::Version as core::cmp::Ord>::max
; Function Attrs: inlinehint nonlazybind uwtable
define internal i24 @_RNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp3Ord3maxB4_(i24 %0, i24 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !727 {
start:
  %_7 = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 1
  %2 = alloca [4 x i8], align 4
  %other = alloca [3 x i8], align 1
  %3 = alloca [4 x i8], align 4
  %self = alloca [3 x i8], align 1
  store i24 %0, ptr %3, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %self, ptr align 4 %3, i64 3, i1 false)
  store i24 %1, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %other, ptr align 4 %2, i64 3, i1 false)
  store i8 0, ptr %_7, align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_7, align 1
  store i8 1, ptr %_6, align 1
; call <structs::Version as core::cmp::PartialOrd>::lt
  %_3 = call zeroext i1 @_RNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltB4_(ptr %other, ptr %self) #24
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0, ptr align 1 %other, i64 3, i1 false)
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_0, ptr align 1 %self, i64 3, i1 false)
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %4 = load i8, ptr %_6, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb9, label %bb5

bb5:                                              ; preds = %bb9, %bb4
  %6 = load i8, ptr %_7, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb10, label %bb6

bb9:                                              ; preds = %bb4
  br label %bb5

bb6:                                              ; preds = %bb10, %bb5
  %8 = load i24, ptr %_0, align 1
  ret i24 %8

bb10:                                             ; preds = %bb5
  br label %bb6

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable
}

; <<structs::Version as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&structs::Version, &structs::Version)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvYNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBF_3ops8function5FnMutTRB5_B1L_EE8call_mutB7_(ptr %_1, ptr %0, ptr %1) unnamed_addr #0 !guid !728 {
start:
  %_2 = alloca [16 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr %1, ptr %2, align 8
  %3 = load ptr, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load ptr, ptr %4, align 8
; call <structs::Version as core::cmp::PartialOrd>::lt
  %_0 = call zeroext i1 @_RNvYNtCs31EPG3twprw_7structs7VersionNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltB4_(ptr %3, ptr %5) #24
  ret i1 %_0
}

; <<char as core::clone::Clone>::clone as core::ops::function::FnMut<(&char,)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNvYcNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBa_3ops8function5FnMutTRcEE8call_mutCs31EPG3twprw_7structs(ptr %_1, ptr align 4 %0) unnamed_addr #0 !guid !729 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
  %_0.i = load i32, ptr %1, align 4
  ret i32 %_0.i
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #5

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #6

; <f64 as core::str::traits::FromStr>::from_str
; Function Attrs: noinline nonlazybind uwtable
declare void @_RNvXs2_NtNtCsl10jNU3mE6R_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str(ptr sret([16 x i8]) align 8, ptr, i64) unnamed_addr #3

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <[u8; 4] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAhj4_NtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugList>::entry
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #6

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; core::cmp::min::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64, i64) unnamed_addr #0

; core::cmp::max::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64, i64) unnamed_addr #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #9

; <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64, i64) unnamed_addr #0

; <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8) unnamed_addr #0

; core::slice::sort::shared::smallsort::panic_on_ord_violation
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort22panic_on_ord_violation() unnamed_addr #8

; <[usize; 2] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAjj2_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCshGsV4pNJ6ra_6object(ptr sret([32 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::array::iter::IntoIter<usize, 2> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterjKj2_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<core::array::iter::IntoIter<usize, 2>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterjKj2_EECshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #1

; core::slice::sort::stable::drift::sqrt_approx
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift11sqrt_approx(i64) unnamed_addr #1

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #10

; <core::num::nonzero::NonZero<usize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<char> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullcENtNtB9_3cmp9PartialEq2eqCs257F0UrNG3U_14rustc_demangle(ptr align 8, ptr align 8) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqB9_(ptr align 8, ptr align 8) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedB9_(ptr, ptr) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; <core::str::iter::Chars as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectNtNtNtB8_3str4iter5CharsNtB2_12IntoIterator9into_iterB8_(ptr, ptr) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<14, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #6

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #6

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #11

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_lower_hex::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexmEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; <[u8]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterB4_(ptr, i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #11

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32) #11

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_null_reference_constructed
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking32panic_null_reference_constructed(ptr align 8) unnamed_addr #6

; <[char]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSc4iterCs257F0UrNG3U_14rustc_demangle(ptr align 4, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newB4_(ptr sret([24 x i8]) align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenB6_(ptr align 8, i64) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::reserve
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7reserveB6_(ptr align 8, i64) unnamed_addr #1

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #8

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #8

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8, i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr, i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8, i64, i64, i64, i64) unnamed_addr #0

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #13

; <alloc::raw_vec::RawVecInner>::grow_one
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneB7_(ptr align 8, i64, i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64, i64, i64) unnamed_addr #0

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.uadd.sat.i64(i64, i64) #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.usub.sat.i64(i64, i64) #11

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #14

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #5

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #15

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #16

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #17

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #18

; core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_chunks::<8>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes26swap_nonoverlapping_chunksKj8_ECshGsV4pNJ6ra_6object(ptr, ptr, i64) unnamed_addr #1

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr) unnamed_addr #0

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #19

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullB6_(ptr) unnamed_addr #0

; core::ptr::swap_chunk::<4>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj4_ECshGsV4pNJ6ra_6object(ptr, ptr) unnamed_addr #0

; core::ptr::swap_chunk::<2>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj2_ECshGsV4pNJ6ra_6object(ptr, ptr) unnamed_addr #0

; core::ptr::swap_chunk::<1>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj1_ECshGsV4pNJ6ra_6object(ptr, ptr) unnamed_addr #0

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr, i64) unnamed_addr #0

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #19

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field3_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field3_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
declare { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEEB6_(ptr align 8) unnamed_addr #0

; <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
declare i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXNtNtB5_3str4iterNtBU_5CharsNtNtNtNtB5_4iter6traits8iterator8Iterator4next0EB5_(i32, i32) unnamed_addr #0

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <&&str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRReNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8, i64, i64) unnamed_addr #1

; <char as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsj_NtCsl10jNU3mE6R_4core3fmtcNtB5_5Debug3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64, i64, i64, ptr align 8) unnamed_addr #8

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.ucmp.i8.i8(i8, i8) #11

; <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenB8_(ptr align 8) unnamed_addr #1

; <[u8; 3] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAhj3_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexB7_(ptr, ptr align 8) unnamed_addr #0

; <&[u8] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRShNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugList>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8) unnamed_addr #1

; <core::option::Option<core::cmp::Ordering>>::is_some_and::<<core::cmp::Ordering>::is_lt>
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionNtNtB5_3cmp8OrderingE11is_some_andNvMBK_BI_5is_ltEB5_(i8) unnamed_addr #0

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #20 !guid !730 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs31EPG3twprw_7structs(ptr @_RNvCs31EPG3twprw_7structs4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #10 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #13 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #14 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #20 = { nonlazybind "target-cpu"="x86-64" }
attributes #21 = { cold }
attributes #22 = { cold noreturn nounwind }
attributes #23 = { noinline }
attributes #24 = { inlinehint }
attributes #25 = { inlinehint nounwind }
attributes #26 = { noinline noreturn }
attributes #27 = { noinline noreturn nounwind }
attributes #28 = { noreturn }
attributes #29 = { nounwind }

!llvm.module.flags = !{!284, !285, !286, !287}
!llvm.ident = !{!288}

!0 = !{i64 -5123152399914545195}
!1 = !{i64 -5989343640973918366}
!2 = !{i64 -96533991601289600}
!3 = !{i64 -468726859428414328}
!4 = !{i64 4373705996250023429}
!5 = !{i64 -1295435725637127079}
!6 = !{i64 7943988973987122742}
!7 = !{i64 4350560188077564801}
!8 = !{i64 -5444644627961908585}
!9 = !{i64 3577766949199020397}
!10 = !{i64 765234093340407936}
!11 = !{i64 1618318295715917783}
!12 = !{i64 -3629243805862391924}
!13 = !{i64 8508221767504656859}
!14 = !{i64 2154796521037506737}
!15 = !{i64 3237407358516602915}
!16 = !{i64 8003769587923573423}
!17 = !{i64 -8932035688214340926}
!18 = !{i64 1763894483441842201}
!19 = !{i64 3957972106330089329}
!20 = !{i64 7812826670488891889}
!21 = !{i64 -441307128660607054}
!22 = !{i64 8651383035869365016}
!23 = !{i64 -3768845547795183230}
!24 = !{i64 8744057190668512436}
!25 = !{i64 -353667445181106163}
!26 = !{i64 -8708838522744473215}
!27 = !{i64 3403531769292570929}
!28 = !{i64 6433653006499658544}
!29 = !{i64 -8900549635179920786}
!30 = !{i64 5744100155382045502}
!31 = !{i64 -5599926947638821743}
!32 = !{i64 1386806660274431890}
!33 = !{i64 -5430726354565016733}
!34 = !{i64 5773830973868220404}
!35 = !{i64 7308555460578401589}
!36 = !{i64 -4695623555071169984}
!37 = !{i64 3682215058892958299}
!38 = !{i64 385428169827400136}
!39 = !{i64 -8377730225429220282}
!40 = !{i64 2888386801150326110}
!41 = !{i64 -2638933883465029519}
!42 = !{i64 1853324988280361947}
!43 = !{i64 -3020861706451008828}
!44 = !{i64 -7426935367907004442}
!45 = !{i64 8233452803272143931}
!46 = !{i64 -5461700855196598411}
!47 = !{i64 2680073189793999795}
!48 = !{i64 -8739693393813411932}
!49 = !{i64 1319344642622456913}
!50 = !{i64 -2074967594748630001}
!51 = !{i64 5298550115197452246}
!52 = !{i64 -7596266337289010090}
!53 = !{i64 -8183631351828823163}
!54 = !{i64 -3229253800319569296}
!55 = !{i64 5206254400831307355}
!56 = !{i64 -1416607784059999485}
!57 = !{i64 8773555258227631319}
!58 = !{i64 4100365948289547418}
!59 = !{i64 -7912045827861554195}
!60 = !{i64 3688607993698243251}
!61 = !{i64 6217314265576056193}
!62 = !{i64 7045755817386279514}
!63 = !{i64 924150763300906442}
!64 = !{i64 7515607562904035765}
!65 = !{i64 -4683124884185187977}
!66 = !{i64 1360913604440874083}
!67 = !{i64 8609087322177326400}
!68 = !{i64 -1976174387627563183}
!69 = !{i64 -3429991708306595778}
!70 = !{i64 5742596444446560398}
!71 = !{i64 698640680644297517}
!72 = !{i64 -8059461472236160948}
!73 = !{i64 6342444981191609931}
!74 = !{i64 7396558452868716130}
!75 = !{i64 309876822412505887}
!76 = !{i64 515493064945142265}
!77 = !{i64 6774725021763775149}
!78 = !{i64 -6873747417548616279}
!79 = !{i64 4221847877637716268}
!80 = !{i64 2695192230994845397}
!81 = !{i64 7951730057547034213}
!82 = !{i64 -4418768018258719532}
!83 = !{i64 4535273943853990504}
!84 = !{i64 7637289370575299593}
!85 = !{i64 5057034300480738040}
!86 = !{i64 1752239013756785518}
!87 = !{i64 5142081386550690918}
!88 = !{i64 7329899155980398902}
!89 = !{i64 -3355356541992746520}
!90 = !{i64 1705886367188664078}
!91 = !{i64 3161830503617244307}
!92 = !{i64 8999799917259329899}
!93 = !{i64 6280681748518157873}
!94 = !{i64 5620937400698499040}
!95 = !{i64 3077258306880647825}
!96 = !{i64 2194634173255844528}
!97 = !{i64 -8468327035372689076}
!98 = !{i64 -7879227991585122854}
!99 = !{i64 -1588988123885012001}
!100 = !{i64 172363275756036093}
!101 = !{i64 -7567954779743687069}
!102 = !{i64 -3467981045956291486}
!103 = !{i64 -2724184937522406598}
!104 = !{i64 -5881701095842312188}
!105 = !{i64 7807215145662002838}
!106 = !{i64 5549748451272970528}
!107 = !{i64 -3909884645043795545}
!108 = !{i64 1796093322542138954}
!109 = !{i64 7751502603666685300}
!110 = !{i64 -1234507983103808906}
!111 = !{i64 4855291188417431163}
!112 = !{i64 6266295607970976133}
!113 = !{i64 646278366386531487}
!114 = !{i64 7608773694285456776}
!115 = !{i64 8945094661950135914}
!116 = !{i64 -8528749423198887431}
!117 = !{i64 -4425170332174971784}
!118 = !{i64 4113257950702106460}
!119 = !{i64 1414101146609278333}
!120 = !{i64 -4231536560902035380}
!121 = !{i64 -4795505903861171228}
!122 = !{i64 -8992691924151704879}
!123 = !{i64 7288805489646299842}
!124 = !{i64 -8262642965981634868}
!125 = !{i64 -5292117316562157832}
!126 = !{i64 -6043917889763470676}
!127 = !{i64 4378981082152940753}
!128 = !{i64 3079517126721609745}
!129 = !{i64 3876195959216560159}
!130 = !{i64 -3249781447655195651}
!131 = !{i64 4410786344254982842}
!132 = !{i64 -2830682081186727449}
!133 = !{i64 8072133283746388622}
!134 = !{i64 -7025397098087230704}
!135 = !{i64 -3641583651260762480}
!136 = !{i64 5420905515770076599}
!137 = !{i64 5301124756352161569}
!138 = !{i64 -5654849754462891038}
!139 = !{i64 2263238814252232302}
!140 = !{i64 5312085583409919228}
!141 = !{i64 -4863545799304593365}
!142 = !{i64 1774578559234190707}
!143 = !{i64 -7713679276494230859}
!144 = !{i64 -4260496117143765120}
!145 = !{i64 -6129254395148376282}
!146 = !{i64 3364660988816135237}
!147 = !{i64 8508910495379277969}
!148 = !{i64 -8366659855114211197}
!149 = !{i64 7498650747138427690}
!150 = !{i64 7828581274085124126}
!151 = !{i64 1754211832969621672}
!152 = !{i64 6816675605151788667}
!153 = !{i64 5825938961788188299}
!154 = !{i64 7359332159020671459}
!155 = !{i64 -4455230312978712563}
!156 = !{i64 2011673241168168386}
!157 = !{i64 -1203653556430378460}
!158 = !{i64 4266658615319555452}
!159 = !{i64 3399318413148418409}
!160 = !{i64 6510339866923027987}
!161 = !{i64 -4452801390090614604}
!162 = !{i64 5419047717029221509}
!163 = !{i64 -1824204997237934086}
!164 = !{i64 3192517643426150254}
!165 = !{i64 -6257669261690254569}
!166 = !{i64 -4827027509383044339}
!167 = !{i64 3054691147505290449}
!168 = !{i64 8137314736595356911}
!169 = !{i64 857865827228797752}
!170 = !{i64 4072056827076250758}
!171 = !{i64 -4868191716259994277}
!172 = !{i64 -1609916933310394585}
!173 = !{i64 -6020945405257039148}
!174 = !{i64 -321081015528828929}
!175 = !{i64 2034943427732393881}
!176 = !{i64 -6783706056441844219}
!177 = !{i64 5501205593879033407}
!178 = !{i64 2341673307758147092}
!179 = !{i64 -329258752798469101}
!180 = !{i64 3393503677226997851}
!181 = !{i64 -932583924530076600}
!182 = !{i64 8404402235930294528}
!183 = !{i64 -5274845015401301891}
!184 = !{i64 433450091024188614}
!185 = !{i64 -3313617732655488456}
!186 = !{i64 5521376827458011641}
!187 = !{i64 -5888918915327583014}
!188 = !{i64 1000665658376890137}
!189 = !{i64 -6658064864959258898}
!190 = !{i64 4953649638239195650}
!191 = !{i64 -8634803552804325964}
!192 = !{i64 1560498213342859225}
!193 = !{i64 4451181445373784985}
!194 = !{i64 4756340364514682113}
!195 = !{i64 6455218820636305248}
!196 = !{i64 -4108567638963714693}
!197 = !{i64 1634511983205159349}
!198 = !{i64 -7757506588016572781}
!199 = !{i64 -1630693461897059071}
!200 = !{i64 2407589203671393570}
!201 = !{i64 -3742815684956522143}
!202 = !{i64 -2696270670924113062}
!203 = !{i64 5021229294192214933}
!204 = !{i64 1634720896525715380}
!205 = !{i64 1118173920176497792}
!206 = !{i64 -6031582387290574946}
!207 = !{i64 -6446683453866923982}
!208 = !{i64 -3997714153934601287}
!209 = !{i64 7598292015322877866}
!210 = !{i64 -5115502146859013860}
!211 = !{i64 -8602099318258562725}
!212 = !{i64 -6871753789227128775}
!213 = !{i64 4327904705717548023}
!214 = !{i64 4258509420559193195}
!215 = !{i64 8388928963795409203}
!216 = !{i64 -4842654994582314553}
!217 = !{i64 -5853823859334459152}
!218 = !{i64 3456830081675758761}
!219 = !{i64 -1721767376874819811}
!220 = !{i64 -8301206982980700939}
!221 = !{i64 6579321662420949011}
!222 = !{i64 1697936204630548395}
!223 = !{i64 3506694176814495827}
!224 = !{i64 1647072692014542839}
!225 = !{i64 -1149137815834728644}
!226 = !{i64 5066222912314209268}
!227 = !{i64 -3269309908038743483}
!228 = !{i64 -8486008681140027626}
!229 = !{i64 -8318761918763324272}
!230 = !{i64 5188931007394166978}
!231 = !{i64 -7785779274274347360}
!232 = !{i64 -5400798491389742063}
!233 = !{i64 4321918304264303167}
!234 = !{i64 -8819027511233286458}
!235 = !{i64 5169176110307556056}
!236 = !{i64 -9208800749711909764}
!237 = !{i64 2260079233146846657}
!238 = !{i64 -338911322804681728}
!239 = !{i64 -3165048278141658020}
!240 = !{i64 -4461549396125962036}
!241 = !{i64 -7434128541917966336}
!242 = !{i64 -813109213405440187}
!243 = !{i64 7326607996981018843}
!244 = !{i64 5214951625249249885}
!245 = !{i64 569894233838222507}
!246 = !{i64 7904908042584317918}
!247 = !{i64 7993703688649248172}
!248 = !{i64 -4010175457801008293}
!249 = !{i64 -6823693325525724843}
!250 = !{i64 -740138520396028438}
!251 = !{i64 -1863559804967597856}
!252 = !{i64 4592052342247834219}
!253 = !{i64 1809812945094909809}
!254 = !{i64 -2579580230027581522}
!255 = !{i64 7676528469366493734}
!256 = !{i64 118442952456311116}
!257 = !{i64 4782232575325470016}
!258 = !{i64 1567196741132769924}
!259 = !{i64 -6259777966556179282}
!260 = !{i64 -7149609987794500025}
!261 = !{i64 -2777258443658319959}
!262 = !{i64 902138439956295973}
!263 = !{i64 -6925830683306055560}
!264 = !{i64 -102443644973204948}
!265 = !{i64 -286353827018338806}
!266 = !{i64 4247663965098807881}
!267 = !{i64 2988962200068068385}
!268 = !{i64 -2871870010123971632}
!269 = !{i64 -8248503457954020526}
!270 = !{i64 -3731339459825241196}
!271 = !{i64 7575779779597609972}
!272 = !{i64 -5705222907432083720}
!273 = !{i64 -4550755564070682474}
!274 = !{i64 4081197644619677150}
!275 = !{i64 -6495263078965539643}
!276 = !{i64 3717620286214865829}
!277 = !{i64 -223790509751724392}
!278 = !{i64 6233526116655216081}
!279 = !{i64 1595748321883604047}
!280 = !{i64 -2721128466175220376}
!281 = !{i64 -3426203513023069048}
!282 = !{i64 -6197847127539572622}
!283 = !{i64 1011833685261363858}
!284 = !{i32 8, !"PIC Level", i32 2}
!285 = !{i32 7, !"PIE Level", i32 2}
!286 = !{i32 2, !"RtLibUseGOT", i32 1}
!287 = !{i32 7, !"uwtable", i32 2}
!288 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!289 = !{i64 4488821900954504684}
!290 = !{i64 6095214601674879428}
!291 = !{i64 2127932559295733361}
!292 = !{i64 -5221949616991091536}
!293 = !{i64 5427152024997203743}
!294 = !{i64 2109439792023336686}
!295 = !{i64 -127563726709340432}
!296 = !{i64 431205141780763944}
!297 = !{i64 5581319487127708386}
!298 = !{i64 -2818028296531533890}
!299 = !{i64 3456494411996727458}
!300 = !{i64 -1072407468583322259}
!301 = !{i64 7008615473389419051}
!302 = !{i64 226467946920873763}
!303 = !{i64 2040569599257335509}
!304 = !{i64 4017868882260972258}
!305 = !{i64 -3445524395249429901}
!306 = !{i64 -734595571631315041}
!307 = !{i64 -7738534543353852255}
!308 = !{i64 -9200164262221077455}
!309 = !{i64 5766325693223487538}
!310 = !{i64 907654387327039363}
!311 = !{i64 4565147852012745821}
!312 = !{i64 7407643649198755190}
!313 = !{i64 -4868942132206965443}
!314 = !{i64 -9012357610266354546}
!315 = !{i64 2082982553164816794}
!316 = !{i64 8424404856480236430}
!317 = !{i64 3613793328406829532}
!318 = !{i64 8697616944040869654}
!319 = !{i64 -5616696703619922089}
!320 = !{i64 4705971091361204510}
!321 = !{i64 887822310228574327}
!322 = !{i64 -5311307374482170389}
!323 = !{i64 5621434018191391314}
!324 = !{i64 -4689867346652764295}
!325 = !{i64 -6411220331804593640}
!326 = !{i64 -6591648648461137131}
!327 = !{i64 6861967425823511542}
!328 = !{i64 7390596339715685661}
!329 = !{i64 7035499165305362373}
!330 = !{i64 -2702076628097782193}
!331 = !{i64 -7617784926289701999}
!332 = !{i64 5214684999123544656}
!333 = !{i64 3832645776601377454}
!334 = !{i64 4424567363778919252}
!335 = !{i64 8128999658290010180}
!336 = !{i64 -6142084136428604190}
!337 = !{i64 6966885071254180996}
!338 = !{i64 5322179798779115992}
!339 = !{i64 -3545949075022811294}
!340 = !{i64 5492079247051828686}
!341 = !{i64 2532600743114400305}
!342 = !{i64 2620065930343904449}
!343 = !{i64 5408477581277945237}
!344 = !{i64 4924800937508366712}
!345 = !{i64 7499676174757873227}
!346 = !{i64 -6882070851145342731}
!347 = !{i64 4259517832715353174}
!348 = !{i64 -3548185131630803107}
!349 = !{!"address", !"read_provenance"}
!350 = !{i64 -6659271200703832768}
!351 = !{i64 7102744188133656398}
!352 = !{i64 -1119039928492934183}
!353 = !{i64 118838137152782850}
!354 = !{i64 -6883943837248790925}
!355 = !{i64 2001063229394999187}
!356 = !{i64 -6176232631596488947}
!357 = !{i64 -2704752773898622549}
!358 = !{i64 -6688493583173140698}
!359 = !{i64 5760359251038835569}
!360 = !{i64 2105416431343253512}
!361 = !{i64 89748728475593960}
!362 = !{i64 4890014377835203252}
!363 = !{i64 -8797841869200394314}
!364 = !{i64 8097792415320025006}
!365 = !{i64 5613141657878594334}
!366 = !{i64 -4735276208260865641}
!367 = !{i64 1357801004081974607}
!368 = !{i64 3394153948012494330}
!369 = !{i64 -5871244058458206106}
!370 = !{i64 -4948746708968618097}
!371 = !{i64 989721932516438049}
!372 = !{i64 8308809125166772107}
!373 = !{i64 -8103199966602634817}
!374 = !{i64 8840584624715123296}
!375 = !{i64 -4585117992500470643}
!376 = !{i64 -489912557925853611}
!377 = !{i64 406492168924536730}
!378 = !{i64 -4787532881766202787}
!379 = !{i64 -2727671923601601714}
!380 = !{i64 -5728988339613294689}
!381 = !{i64 3596312072878121477}
!382 = !{i64 6076561444968210113}
!383 = !{i64 1980414756598322759}
!384 = !{i64 1863816582523354460}
!385 = !{i64 1686160757868575045}
!386 = !{i64 4727208196471574161}
!387 = !{i64 -6939360450122979927}
!388 = !{i64 -8978070757458727254}
!389 = !{i64 -8468419219480314042}
!390 = !{i64 -8848974624984993784}
!391 = !{i64 1325233634325800}
!392 = !{i64 -1766477147522534695}
!393 = !{i64 -8399697457390659908}
!394 = !{i64 -1729888655071391311}
!395 = !{i64 -985515290169289816}
!396 = !{i64 -6621947124407207995}
!397 = !{i64 -6876277058427967035}
!398 = !{i64 -5808542201835708403}
!399 = !{i64 7721400097940977686}
!400 = !{i64 -3233755390449439167}
!401 = !{i64 -4107971154910095657}
!402 = !{i64 -6236066590174152960}
!403 = !{i64 407128317059602179}
!404 = !{i64 -3383653398204676451}
!405 = !{i64 -3682182317941312287}
!406 = !{i64 -2049228248344585593}
!407 = !{i64 -836824122032450422}
!408 = !{i64 -7529641935994620035}
!409 = !{i64 3915357676350028815}
!410 = !{i64 7226861627627977304}
!411 = !{i64 7995465490828774724}
!412 = !{i64 -2766021790078033753}
!413 = !{i64 -8414096615158320438}
!414 = !{i64 -6870746554664427155}
!415 = !{}
!416 = !{i64 3573118899299123049}
!417 = !{i64 6470696422090428178}
!418 = !{i64 7226986291721387895}
!419 = !{i64 -6909678363235164191}
!420 = !{i64 -6604803984038066674}
!421 = !{i64 5105930877763302868}
!422 = !{i64 4366248767191498439}
!423 = !{i64 -199589569953302384}
!424 = !{i64 3396709464100369581}
!425 = !{i64 2076749523101259053}
!426 = !{i64 -6969531241592676869}
!427 = !{i64 -5644982190213819224}
!428 = !{i64 -4308957092625074963}
!429 = !{i64 1758781597084911622}
!430 = !{i64 -2844263522165357728}
!431 = !{i64 7828757513395506692}
!432 = !{i64 -4224546951406376286}
!433 = !{i64 7457891316893029346}
!434 = !{i64 -7026060863521683775}
!435 = !{i64 -9102523597360704980}
!436 = !{i64 2424030694984516726}
!437 = !{i64 -90183077095868798}
!438 = !{i64 -8138649644988971493}
!439 = !{i64 -8485917226041915962}
!440 = !{i64 6704179198498137415}
!441 = !{i64 -2670936501976416637}
!442 = !{i64 6905490701366432251}
!443 = !{i64 -1513476345490257066}
!444 = !{i64 8164674314119367754}
!445 = !{i64 5785914404910380551}
!446 = !{i64 -108860520664893669}
!447 = !{i64 -7976499385088318707}
!448 = !{i64 -502276999008880788}
!449 = !{i64 -4278496744911408077}
!450 = !{i64 -9186634372209821654}
!451 = !{i64 -8921473848594047051}
!452 = !{i64 433248441971931132}
!453 = !{i64 5598860285598334633}
!454 = !{i64 -6788510412189352038}
!455 = !{i64 7004463897672010168}
!456 = !{i64 371288528192356749}
!457 = !{i64 -8542529505565542593}
!458 = !{i64 7902152398451181259}
!459 = !{i64 -7105043909449347759}
!460 = !{i64 5736551522164185892}
!461 = !{i64 -647164856978026582}
!462 = !{i64 -610078056702644121}
!463 = !{i64 -395690895880033335}
!464 = !{i64 1771940391463272089}
!465 = !{i64 5395687247148453383}
!466 = !{i64 -2223044652010490684}
!467 = !{i64 -2896229635567236231}
!468 = !{i64 -2280039455576023794}
!469 = !{i64 -6702980200875885844}
!470 = !{i64 -1886452383481202275}
!471 = !{i64 -8565355071107693568}
!472 = !{i64 -3776971042856527828}
!473 = !{i64 -7461451798477021891}
!474 = !{i64 -8133766146440455035}
!475 = !{i64 -3290988463330105891}
!476 = !{i64 536561189412303346}
!477 = !{i64 1219149973387098100}
!478 = !{i64 3156422927586704294}
!479 = !{i64 -8893814207407612288}
!480 = !{i64 -8516296531663526890}
!481 = !{i64 1530080606557465017}
!482 = !{i64 -978680558782589238}
!483 = !{i64 -9069404924139140040}
!484 = !{i64 -5323348140416727431}
!485 = !{i64 36904015917599031}
!486 = !{i64 -7174965999412345871}
!487 = !{i64 -5111446046350000730}
!488 = !{i64 -1680134702267285694}
!489 = !{i64 1012375337080371475}
!490 = !{i64 -6475926842045621605}
!491 = !{i64 8331378783602146879}
!492 = !{i64 9206413852459383966}
!493 = !{i64 1894709902833264362}
!494 = !{i64 4846532959535308213}
!495 = !{i64 7005534996301452745}
!496 = !{i64 1770118667340868478}
!497 = !{i64 -4775226129706109378}
!498 = !{i64 3435061792484323209}
!499 = !{i64 -4337676686925396484}
!500 = !{i64 3808923305571626432}
!501 = !{i64 -5314076505068108339}
!502 = !{i64 5281025637294561348}
!503 = !{i64 964222450133259178}
!504 = !{i64 1139118472073454673}
!505 = !{i64 3744978216870610016}
!506 = !{i64 -2030401969852317167}
!507 = !{i64 -6539869878156444484}
!508 = !{i64 7445542350410743892}
!509 = !{i64 4148828938203909685}
!510 = !{i64 3207116078788207206}
!511 = !{i64 3828574080477830162}
!512 = !{i64 4727408035040407051}
!513 = !{i64 -2927802301997967146}
!514 = !{i64 -2728749117037171872}
!515 = !{i64 -7287944283927464520}
!516 = !{i64 -6721983061581529061}
!517 = !{i64 6839995772865844217}
!518 = !{i64 -4764001528306197487}
!519 = !{i64 -1983966892735539100}
!520 = !{i64 -7812677298954105768}
!521 = !{i64 9152716904182828842}
!522 = !{i64 -3524180661440221061}
!523 = !{i64 -3755163160143433487}
!524 = !{i64 -615659954038296087}
!525 = !{i64 -3528224533741802419}
!526 = !{i64 -1651564670943515088}
!527 = !{i64 -8196747335533287733}
!528 = !{i64 -4236589902756618085}
!529 = !{i64 7660271095071130408}
!530 = !{i64 -8193819863333609213}
!531 = !{i64 -4308636510424847502}
!532 = !{i64 -562180334575302073}
!533 = !{i64 -6078222715066977336}
!534 = !{i64 -2307262796041199408}
!535 = !{i64 5144793695912346301}
!536 = !{i64 1723232499731479676}
!537 = !{i64 -2966637951733225365}
!538 = !{i64 -7253952771242452568}
!539 = !{i64 -8634588949971205480}
!540 = !{i64 6086935329277090845}
!541 = !{i64 -856669822269441373}
!542 = !{i64 4074137122614552708}
!543 = !{i64 -2006373418780163053}
!544 = !{i64 -3080328298621901386}
!545 = !{i64 7799000940692105398}
!546 = !{i64 -6286709539848054413}
!547 = !{i64 8179508669422086655}
!548 = !{i64 -4567413303308712421}
!549 = !{i64 2121063689553590601}
!550 = !{i64 6428213278086491979}
!551 = !{i64 -7385158584019067307}
!552 = !{i64 2124952571008774134}
!553 = !{i64 -8154864897018363862}
!554 = !{i64 -8495537028200030010}
!555 = !{i64 -4098862667844628796}
!556 = !{i64 3567289212313963176}
!557 = !{i64 2729178204971337929}
!558 = !{i64 3818131274255844016}
!559 = !{i64 491850173814026935}
!560 = !{i64 4861615566677243081}
!561 = !{i64 -5691633645973900401}
!562 = !{i64 6608770519592922031}
!563 = !{i64 -3157855916967620688}
!564 = !{i64 4451641136794249365}
!565 = !{i64 -6106096956729706800}
!566 = !{i64 7307422129799235133}
!567 = !{i64 -8489649622950929445}
!568 = !{i64 -8070060813879809664}
!569 = !{i64 8836221573137020661}
!570 = !{i64 4871386475249136028}
!571 = !{i64 5233040939370675562}
!572 = !{i64 -5680039797224712832}
!573 = !{i64 6598670828264582264}
!574 = !{i64 -6596672237742006143}
!575 = !{i64 -6275402638510894375}
!576 = !{i64 -9029789723321153427}
!577 = !{i64 7466437545653311687}
!578 = !{i64 6612774233453269484}
!579 = !{i64 -1070162384107587531}
!580 = !{i64 4232804551567599967}
!581 = !{i64 962246535947739710}
!582 = !{i64 421451956094881919}
!583 = !{i64 -2965077490101986332}
!584 = !{i64 3626701963152078295}
!585 = !{i64 1999357049320214962}
!586 = !{i64 -1966484606767055834}
!587 = !{i64 -1358887272411626071}
!588 = !{i64 -5093056230238965840}
!589 = !{i64 -8334750462560429874}
!590 = !{i64 8522818256334732536}
!591 = !{i64 -1331200255125534266}
!592 = !{i64 1994303759948226383}
!593 = !{i64 -3381750116272275166}
!594 = !{i64 3169123281916383620}
!595 = !{i64 -6398788354521864644}
!596 = !{i64 -250976695041514026}
!597 = !{i64 1879146909367476155}
!598 = !{i64 7037051782973326283}
!599 = !{i64 -1860599565513446948}
!600 = !{i64 -6759112153938479000}
!601 = !{i64 -5937213013350384541}
!602 = !{i64 -4772851302632073712}
!603 = !{i64 3826779611854097948}
!604 = !{i64 3555796393127370247}
!605 = !{i64 5210031782825070709}
!606 = !{i64 2097628893128395172}
!607 = !{i64 1856584942444645940}
!608 = !{i64 -8563598085629799827}
!609 = !{i64 -3572361890297966832}
!610 = !{i64 -6590880379517576368}
!611 = !{i64 898391822719013677}
!612 = !{i64 3853978710740749231}
!613 = !{i64 5325643377440120184}
!614 = !{i64 8162266102167253938}
!615 = !{i64 -5939568420352028191}
!616 = !{i64 5448757396428092808}
!617 = !{i64 4564589445010193477}
!618 = !{i64 4203959220330401952}
!619 = !{i64 8381946068392572310}
!620 = !{i64 -2181309019536973050}
!621 = !{i64 4813846747018779239}
!622 = !{i64 7568911933831346180}
!623 = !{i64 2039014839929941190}
!624 = !{i64 -7541909189259931200}
!625 = !{i64 8559864804603656303}
!626 = !{i64 4215270192571474648}
!627 = !{i64 -996712432503023845}
!628 = !{i64 1459700016648287813}
!629 = !{i64 -8745801970892130020}
!630 = !{i64 -6924523259686406241}
!631 = !{i64 -1299520256350826379}
!632 = !{i64 -4303053773312089853}
!633 = !{i64 -3109153204206854036}
!634 = !{i64 1141428995616342261}
!635 = !{i64 2538832073544341629}
!636 = !{i64 -1145138628645620296}
!637 = !{i64 -1966838212530322808}
!638 = !{i64 -3183158966609619761}
!639 = !{i64 -5074348232766692966}
!640 = !{i64 -7216900606544779313}
!641 = !{i64 7955621260520374680}
!642 = !{i64 6425189645937502417}
!643 = !{i64 453491482181583549}
!644 = !{i64 -4118564737471909281}
!645 = !{i64 4196719395554055405}
!646 = !{i64 4838000267235946089}
!647 = !{i64 656470759190502855}
!648 = !{i64 -3276893236519854894}
!649 = !{i64 -3549089698262578524}
!650 = !{i64 -2289657641769650604}
!651 = !{i64 -6410327204669843544}
!652 = !{i64 789163330599797487}
!653 = !{i64 5133603464908243917}
!654 = !{i64 -8313366159042924333}
!655 = !{i64 -5383731244102086519}
!656 = !{i64 8061880235780268650}
!657 = !{i64 -2400962468121836976}
!658 = !{i64 7214120649192641595}
!659 = !{i64 3626563844301656912}
!660 = !{i64 6665911627758899068}
!661 = !{i64 -4818196436381480247}
!662 = !{i64 2954441437093872446}
!663 = !{i64 -5262479709898746334}
!664 = !{i64 7463606852520401406}
!665 = !{i64 -3895045125438907490}
!666 = !{i64 -5699247609343737222}
!667 = !{i64 1848956492519811220}
!668 = !{i64 4285907620849399742}
!669 = !{i64 -7345248136695949577}
!670 = !{i64 -1851082140600438783}
!671 = !{i64 -541458771306503719}
!672 = !{i64 -6888479270717749556}
!673 = !{i64 -5420273735000443931}
!674 = !{i64 3177950822150694658}
!675 = !{i64 -8024988638792493691}
!676 = !{i64 4427393628445516652}
!677 = !{i64 2574138243620544941}
!678 = !{i64 5486080370386781342}
!679 = !{i64 8910065453089746052}
!680 = !{i64 -1978786729978338223}
!681 = !{i64 7172878546074948691}
!682 = !{i64 -9221926133830258986}
!683 = !{i64 3504183121965719610}
!684 = !{i64 4112095261022486293}
!685 = !{i64 -9187529689419294395}
!686 = !{i64 1925831877713815137}
!687 = !{i64 8777366751778396337}
!688 = !{i64 7962257397315386410}
!689 = !{i64 -5487855561037482124}
!690 = !{i64 -8310648453061106707}
!691 = !{i64 -4763292868491883035}
!692 = !{i64 3609970681282418696}
!693 = !{i64 -3440689529787476618}
!694 = !{i64 -7742962266872268545}
!695 = !{i64 -5033305122600925380}
!696 = !{i64 4062954173309103671}
!697 = !{i64 -3610879432219019905}
!698 = !{i64 -2349485326408683563}
!699 = !{i64 1002360916800364988}
!700 = !{i64 -7310054282949316418}
!701 = !{i64 -5292750107010016125}
!702 = !{i64 4894841590961133273}
!703 = !{i64 6531635668052035893}
!704 = !{i64 65482570630785608}
!705 = !{i64 5350606979701582338}
!706 = !{i64 2706887389554759065}
!707 = !{i64 -4724013250427416843}
!708 = !{i64 6275826058852986592}
!709 = !{i64 176522284370405547}
!710 = !{i64 -1632625631968941662}
!711 = !{i64 -6384078167369562400}
!712 = !{i64 8862816229313465528}
!713 = !{i64 3287020646440366561}
!714 = !{i64 -664565194787089944}
!715 = !{i64 6699748693322806154}
!716 = !{i64 8494568710595236255}
!717 = !{i64 3713363421461174344}
!718 = !{i64 -8559167758604676073}
!719 = !{i64 -989364341754531061}
!720 = !{i64 -8687177164105440943}
!721 = !{i64 -3428738756228287287}
!722 = !{i64 1588146630882499002}
!723 = !{i64 -5897722120095045187}
!724 = !{i64 862064057428581837}
!725 = !{i64 -85684162283219557}
!726 = !{i64 -5304226531146658584}
!727 = !{i64 3912916208220488148}
!728 = !{i64 4687760840051738277}
!729 = !{i64 4456266427296914719}
!730 = !{i64 -2624081020897602054}
