; ModuleID = 'algorithms.935b318b2d36fcbe-cgu.0'
source_filename = "algorithms.935b318b2d36fcbe-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@alloc_04746a8446e618bbe2d5501aa053057a = private unnamed_addr constant [34 x i8] c"test/rust/synthetic/algorithms.rs\00", align 1, !guid !0
@alloc_3f046313402cf9d112a7ec1a1a46896c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00W\00\00\00" }>, align 8, !guid !1
@alloc_4740451e630eacf1c934674f31b3df4b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00\80\00\00\00" }>, align 8, !guid !2
@alloc_5e6e7bcba3a2b880b27bb87788baeb90 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00\9B\00\00\00" }>, align 8, !guid !3
@alloc_b3ffa52520fd637707107e0da6539f01 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00\B6\00\00\00" }>, align 8, !guid !4
@alloc_bd7a221f280eb8a5c3589ee94b51abf4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00\E2\00\00\00" }>, align 8, !guid !5
@alloc_ad124890fb01d57067a49869e6a3f64f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00\EE\00\00\00" }>, align 8, !guid !6
@alloc_32766398bbe1ef37d5243959bca58e4f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00\F6\00\00\00" }>, align 8, !guid !7
@alloc_5347189550883c5cf2dac15d1989f2cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00\0F\01\00\00" }>, align 8, !guid !8
@alloc_e6e6af7b7f0cdf434d4c3ff85dabee83 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00\C1\00\00\00" }>, align 8, !guid !9
@alloc_d87d7a041001c7c62725288599d7f2af = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\06\00\00\00\A6\00\00\00" }>, align 8, !guid !10
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAxj3_NtB6_5Debug3fmtCscEnaBunu62E_10algorithms }>, align 8, !guid !11
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRThhENtB6_5Debug3fmtCscEnaBunu62E_10algorithms }>, align 8, !guid !12
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCscEnaBunu62E_10algorithms }>, align 8, !guid !13
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRjNtB6_5Debug3fmtB8_ }>, align 8, !guid !14
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRxNtB6_5Debug3fmtCs2d0hS33vDhg_5gimli }>, align 8, !guid !15
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtB8_ }>, align 8, !guid !16
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !17
@alloc_5aa56aa9c48804c2060fa51fd405a2a7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0B\10\00\00.\00\00\00" }>, align 8, !guid !18
@alloc_99b75caf23590dadf6af761a907c30e6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0B\10\00\00\11\00\00\00" }>, align 8, !guid !19
@alloc_31365cfefba383c4d2bf6b6a04cc10aa = private unnamed_addr constant [17 x i8] c"capacity overflow", align 1, !guid !20
@alloc_8d2d54b2e3654c99232db78ca79b95fd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\002\10\00\00\0D\00\00\00" }>, align 8, !guid !21
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCscEnaBunu62E_10algorithms, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CscEnaBunu62E_10algorithms, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CscEnaBunu62E_10algorithms }>, align 8, !guid !22
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !23
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !24
@alloc_9c04098d1f5b2a23ccf9ca333796c0a8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\8C\02\00\00\09\00\00\00" }>, align 8, !guid !25
@alloc_9e812b429644231d02a02f23d39f324b = private unnamed_addr constant [23 x i8] c"core/src/slice/iter.rs\00", align 1, !guid !26
@alloc_5bb642ca6df5ad9ba078972a9d3a5201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !27
@alloc_914b2c69d7eca30497b9feaf15ac92f1 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1, !guid !28
@alloc_9de8e9d950889b89b57820c769482176 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00%\10\00\00$\00\00\00" }>, align 8, !guid !29
@alloc_673b3b79d500d405af0869a4e4a93e2d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00%\10\00\00\15\00\00\00" }>, align 8, !guid !30
@alloc_4c11efc3573b34f9d7b7c296f26e49be = private unnamed_addr constant [36 x i8] c"core/src/iter/adapters/enumerate.rs\00", align 1, !guid !31
@alloc_ab27f9f2532b251b4a877c1004f487aa = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4c11efc3573b34f9d7b7c296f26e49be, [16 x i8] c"#\00\00\00\00\00\00\00x\00\00\00\11\00\00\00" }>, align 8, !guid !32
@alloc_8df3287b4fbc190437d91041421e919b = private unnamed_addr constant [30 x i8] c"core/src/iter/traits/accum.rs\00", align 1, !guid !33
@alloc_a840ce68d073c0ef52d40243c1f57585 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8df3287b4fbc190437d91041421e919b, [16 x i8] c"\1D\00\00\00\00\00\00\00\CE\00\00\00\01\00\00\00" }>, align 8, !guid !34
@alloc_e4bdac4122206b2ebe40e840c39c6050 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\15\00\00\001\00\00\00" }>, align 8, !guid !35
@alloc_fe8078b694f80294d33efed07a1c45e3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\15\00\00\009\00\00\00" }>, align 8, !guid !36
@alloc_da54e803e52fa44cc6a5f7a3e4224be8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00\F4\00\00\00" }>, align 8, !guid !37
@alloc_34f9bf62090ec1c25e1e679d9928e24e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\07\00\00\00\B3\00\00\00" }>, align 8, !guid !38
@alloc_d49eccfc497d83b90860188daee00009 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\07\00\00\00\C9\00\00\00" }>, align 8, !guid !39
@alloc_1f244101ca7e35c6553d1f6e1ba28be6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00l\01\00\00" }>, align 8, !guid !40
@alloc_30038872a02853dff7e9d1f3b7db7968 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00\D8\00\00\00" }>, align 8, !guid !41
@alloc_6a023b1094c6eb16d5ccfa1e897366df = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00\DE\00\00\00" }>, align 8, !guid !42
@alloc_35e68c292623e250f2a024a2d074ed00 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00\07\01\00\00" }>, align 8, !guid !43
@alloc_344c4a9eedccea7f789f54d456d48e26 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00\15\01\00\00" }>, align 8, !guid !44
@alloc_0d3036d5066b52afce94e10193712463 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00\13\01\00\00" }>, align 8, !guid !45
@alloc_effbfcebd38dd98a42af3a174b625e55 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00$\01\00\00" }>, align 8, !guid !46
@alloc_43bead3de7a3f6408d3bda4a3b5d93e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00#\01\00\00" }>, align 8, !guid !47
@alloc_b636263e217c642eda5e010ebf359b1e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00\22\01\00\00" }>, align 8, !guid !48
@alloc_92f0a599d59ec93f39caf1e6f9686f60 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00>\01\00\00" }>, align 8, !guid !49
@alloc_7562f6df21f699c39bbc01e02e62f638 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00=\01\00\00" }>, align 8, !guid !50
@alloc_fe18793f53b7b8eac4f8c785aad2ca03 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00J\01\00\00" }>, align 8, !guid !51
@alloc_88911a2c0bb32188e1abe26cdea16430 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00I\01\00\00" }>, align 8, !guid !52
@alloc_3f637da660a89abe5c384b401a0f7492 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\004\01\00\00" }>, align 8, !guid !53
@alloc_c4de8564844e5da2d10cb9a3b4c74182 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0B\00\00\00\0D\01\00\00" }>, align 8, !guid !54
@alloc_fc0dcd0c736cf9722649bc1ad3ee19ab = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0E\00\00\00%\00\00\00" }>, align 8, !guid !55
@alloc_3dd69aa1e6bd6c491f8ea1d559e0aa1d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0E\00\00\00$\00\00\00" }>, align 8, !guid !56
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !57
@alloc_0b418e65da9c7294cb2b537c556e6d81 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0F\00\00\00F\00\00\00" }>, align 8, !guid !58
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !59
@alloc_7e5ee055e10d111bad73c6c929b6d373 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\15\00\00\00\1E\00\00\00" }>, align 8, !guid !60
@alloc_ac6b8349d588d58d90cd0792249d61ee = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\15\00\00\00B\00\00\00" }>, align 8, !guid !61
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !62
@alloc_1a2b9f3efbe1a8edd339fa75af2334ed = private unnamed_addr constant [5 x i8] c"hello", align 1, !guid !63
@alloc_a66c752209206854431018eae2c84372 = private unnamed_addr constant [100 x i8] zeroinitializer, align 1, !guid !64
@alloc_6473256df3cba3ec5d3325489f1ee0ac = private unnamed_addr constant [19 x i8] c"\C3 \00\00i\08\00\01 \C3 \00\00i\08\00\01\0A\00", align 1, !guid !65
@alloc_b74eb839d19cdfd196e850aa30197964 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\1C\00\00\00&\00\00\00" }>, align 8, !guid !66
@alloc_302a407efbd8750c84addd68544775ce = private unnamed_addr constant [6 x i8] c"kitten", align 1, !guid !67
@alloc_1f9f2d6055fba255e78e97b42c2847ad = private unnamed_addr constant [7 x i8] c"sitting", align 1, !guid !68
@alloc_13af184f83ea529683dab3456027e412 = private unnamed_addr constant [3 x i8] c"abc", align 1, !guid !69
@alloc_a4c2357cd563880631800cfb72d07d96 = private unnamed_addr constant [11 x i8] c"\C1 \00\80`\01 \C0\01\0A\00", align 1, !guid !70
@alloc_dfba7a9f04fbaa6390bf02c689ab4249 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00$\00\00\00@\00\00\00" }>, align 8, !guid !71
@alloc_61553a8974d11d1c2bba665d1fa65efd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\22\00\00\00\1E\00\00\00" }>, align 8, !guid !72
@alloc_844d47394c74c675e427a77bd173d726 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\1F\00\00\003\00\00\00" }>, align 8, !guid !73
@alloc_e0a963c8c52418d41875d5af6eb67898 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\1F\00\00\00%\00\00\00" }>, align 8, !guid !74
@alloc_3f68606c5ef51f8055afb7a1e5d4ad99 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0A\00\00\00f\00\00\00" }>, align 8, !guid !75
@alloc_82676f12db8c9acfc822abd244b147f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\0A\00\00\00\A2\00\00\00" }>, align 8, !guid !76
@alloc_2f36b7f353d1ebc57656aead9d638748 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00;\00\00\00" }>, align 8, !guid !77
@alloc_77c67f70dae2105acf749b9d81eda6bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00D\00\00\00" }>, align 8, !guid !78
@alloc_baa66a3d08576406f722455aac3420c1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00^\00\00\00" }>, align 8, !guid !79
@alloc_752c0e18b7acdf7a8afc1c9f37ab6e61 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00\82\00\00\00" }>, align 8, !guid !80
@alloc_2799c0c10378e64b12cbbf20aaaef37b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00\93\00\00\00" }>, align 8, !guid !81
@alloc_dc6bd9ef32bef3583a8a50d96ff787fa = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00\A5\00\00\00" }>, align 8, !guid !82
@alloc_fad89990a3b2c6841a5c0d2fe72b5ca9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00\D5\00\00\00" }>, align 8, !guid !83
@alloc_749b606d3fd2333e3362f86c92ea02f0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00\BC\00\00\00" }>, align 8, !guid !84
@alloc_50eb1b4837dc463244be4029579bca1d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\03\00\00\00\C9\00\00\00" }>, align 8, !guid !85
@alloc_b6bbc700a0c1fe109f02cd751fb9fbea = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\05\00\00\00\98\00\00\00" }>, align 8, !guid !86
@alloc_3a752da0d9c387e233264eb275d4db27 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\05\00\00\00\A2\00\00\00" }>, align 8, !guid !87
@alloc_b8742e1bf7fd2dfcd21dfda7733f34c9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\05\00\00\00\8D\00\00\00" }>, align 8, !guid !88
@alloc_e6cf31bb971a81020169998b7fa1ad6b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\07\00\00\00\0E\01\00\00" }>, align 8, !guid !89
@alloc_4d9386d8787472a8c94adbac48d3ce1f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\07\00\00\00\FF\00\00\00" }>, align 8, !guid !90
@alloc_6200402616926a8995aa5edb9c9fc69f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\04\00\00\00b\00\00\00" }>, align 8, !guid !91
@alloc_abe21e5532099025985d937f0a6b5bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04746a8446e618bbe2d5501aa053057a, [16 x i8] c"!\00\00\00\00\00\00\00\04\00\00\00o\00\00\00" }>, align 8, !guid !92
@alloc_d1084648e479974e70c9329824bf76f9 = private unnamed_addr constant [9 x i8] c"mid > len", align 1, !guid !93
@alloc_e86c6ef68ba94e4a4bc451173d753cca = private unnamed_addr constant [22 x i8] c"core/src/slice/mod.rs\00", align 1, !guid !94
@alloc_a6541cbd0ddc1cb3d23757a1b3f12432 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\9D\08\00\00 \00\00\00" }>, align 8, !guid !95
@alloc_d0b5540d38aa67683bd942cb6db4a43b = private unnamed_addr constant [28 x i8] c"window size must be non-zero", align 1, !guid !96
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !97
@alloc_4aead6e2018a46d0df208d5729447de7 = private unnamed_addr constant [27 x i8] c"assertion failed: step != 0", align 1, !guid !98
@alloc_593eecefe877e7691ba660a02cca5b67 = private unnamed_addr constant [34 x i8] c"core/src/iter/adapters/step_by.rs\00", align 1, !guid !99
@alloc_2fa97f0ace01f08d7a0ffb6d9dc8c562 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_593eecefe877e7691ba660a02cca5b67, [16 x i8] c"!\00\00\00\00\00\00\00$\00\00\00\09\00\00\00" }>, align 8, !guid !100
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !101
@alloc_498f56052dc304c3bdbc06db4cd2922f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\82\03\00\00 \00\00\00" }>, align 8, !guid !102
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !103
@alloc_ae8736b8ce7095907a2b2a6db978b45d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00/\02\00\00\05\00\00\00" }>, align 8, !guid !104
@alloc_a18c902037ca3c86ff9f817452de438e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\85\0E\00\00-\00\00\00" }>, align 8, !guid !105
@alloc_49a9e3dda8367adcc4a9a3ab759ffd77 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\95\0E\00\00\11\00\00\00" }>, align 8, !guid !106
@alloc_03f845104ef38bb6b19f93bd749e2e99 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\8D\0E\00\00\11\00\00\00" }>, align 8, !guid !107
@alloc_d63f376f192bb7dbe1dea3ff339d9fc6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\8E\0E\00\00\1B\00\00\00" }>, align 8, !guid !108
@alloc_c8b8d8c3a374d686273200eada4f143a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00d\00\00\00N\00\00\00" }>, align 8, !guid !109
@alloc_9420a1aba537dc94842201b7589e1f0c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0C\04\00\00)\00\00\00" }>, align 8, !guid !110
@alloc_ce6d47b03c47f09012a85da1d9cb0822 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\0D\04\00\00\0D\00\00\00" }>, align 8, !guid !111
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !112
@alloc_e4da8bf01562d69d010b033568f84c60 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00>\0B\00\00\11\00\00\00" }>, align 8, !guid !113
@alloc_cbabb9260c61319f616b774cb11774be = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00?\0B\00\00.\00\00\00" }>, align 8, !guid !114
@alloc_454727c1a5d38ea894b54abbaea90bf6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00?\0B\00\00\16\00\00\00" }>, align 8, !guid !115
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !116
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !117
@alloc_111374654bf6d257ff5ed1ae570a570d = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::swap_unchecked requires that the indices are within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !118
@alloc_6b0b11c9e93314b588b613b55005cf18 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: slice::split_at_mut_unchecked requires the index to be within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !119
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !120
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !121
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !122
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !123
@alloc_5ee6cd0de5bab89c84438a39fb5fb08c = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: ptr::copy requires that both pointer arguments are aligned and non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !124
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !125
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !126
@alloc_5c1a2f972552229672fc942406cfc298 = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts_mut requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !127
@alloc_cff8939d5dc637bf609a2f92b31c63ab = private unnamed_addr constant [39 x i8] c"alloc/src/vec/spec_from_iter_nested.rs\00", align 1, !guid !128
@alloc_6dccda4ce48382006a7e66da98798d14 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cff8939d5dc637bf609a2f92b31c63ab, [16 x i8] c"&\00\00\00\00\00\00\00!\00\00\00\15\00\00\00" }>, align 8, !guid !129
@alloc_11474c3953230bd025f06b3f9a855a1c = private unnamed_addr constant [21 x i8] c"core/src/str/iter.rs\00", align 1, !guid !130
@alloc_1a7c685630b0735376eef9074b3e654a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11474c3953230bd025f06b3f9a855a1c, [16 x i8] c"\14\00\00\00\00\00\00\00f\00\00\00\0E\00\00\00" }>, align 8, !guid !131
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_ }>, align 8, !guid !132
@alloc_f764952b50ffad1fb52cf6916450b6b7 = private unnamed_addr constant [23 x i8] c"core/src/iter/range.rs\00", align 1, !guid !133
@alloc_33c781d4b73231c4b72218e776044e11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f764952b50ffad1fb52cf6916450b6b7, [16 x i8] c"\16\00\00\00\00\00\00\00$\02\00\00\01\00\00\00" }>, align 8, !guid !134
@alloc_4174dac9b534508af33ae1f81dabb21d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00N\05\00\00#\00\00\00" }>, align 8, !guid !135
@alloc_023f381c9f0987bf7ab9a4d4a6f7a392 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9e812b429644231d02a02f23d39f324b, [16 x i8] c"\16\00\00\00\00\00\00\00O\05\00\00\1D\00\00\00" }>, align 8, !guid !136
@alloc_391673418deaa0b14b40e679e64fed1a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cff8939d5dc637bf609a2f92b31c63ab, [16 x i8] c"&\00\00\00\00\00\00\009\00\00\00\12\00\00\00" }>, align 8, !guid !137
@alloc_0d0353b85363a9d264096e7bdbfe6900 = private unnamed_addr constant [22 x i8] c"core/src/array/mod.rs\00", align 1, !guid !138
@alloc_bb689cb4c05c0bf38d31dd7cd71b8150 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_0d0353b85363a9d264096e7bdbfe6900, [16 x i8] c"\15\00\00\00\00\00\00\00e\01\00\00\1F\00\00\00" }>, align 8, !guid !139

; algorithms::quicksort::<f64>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvCscEnaBunu62E_10algorithms9quicksortdEB2_(ptr align 8 %v.0, i64 %v.1) unnamed_addr #0 !guid !145 {
start:
  %_46 = alloca [32 x i8], align 8
  %j = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %p = alloca [8 x i8], align 8
  %_2 = icmp ule i64 %v.1, 1
  br i1 %_2, label %bb23, label %bb1

bb1:                                              ; preds = %start
  %_6 = udiv i64 %v.1, 2
  %_12 = icmp ult i64 %_6, %v.1
  br i1 %_12, label %bb3, label %panic

bb23:                                             ; preds = %bb16, %start
  ret void

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds nuw double, ptr %v.0, i64 %_6
  %1 = load double, ptr %0, align 8
  store double %1, ptr %p, align 8
  %_19.0 = sub i64 %v.1, 1
  %_19.1 = icmp ult i64 %v.1, 1
  br i1 %_19.1, label %panic1, label %bb4

panic:                                            ; preds = %bb1
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_6, i64 %v.1, ptr align 8 @alloc_3f046313402cf9d112a7ec1a1a46896c) #14
  unreachable

bb4:                                              ; preds = %bb3
  store i64 0, ptr %i, align 8
  store i64 %_19.0, ptr %j, align 8
  br label %bb5

panic1:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_4740451e630eacf1c934674f31b3df4b) #14
  unreachable

bb5:                                              ; preds = %bb9, %bb20, %bb4
  %_22 = load i64, ptr %i, align 8
  %_25 = icmp ult i64 %_22, %v.1
  br i1 %_25, label %bb6, label %panic2

bb6:                                              ; preds = %bb5
  %_21 = getelementptr inbounds nuw double, ptr %v.0, i64 %_22
  %_3.i8 = load double, ptr %_21, align 8
  %_4.i9 = load double, ptr %p, align 8
  %_0.i10 = fcmp olt double %_3.i8, %_4.i9
  br i1 %_0.i10, label %bb8, label %bb10

panic2:                                           ; preds = %bb5
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_22, i64 %v.1, ptr align 8 @alloc_5e6e7bcba3a2b880b27bb87788baeb90) #14
  unreachable

bb10:                                             ; preds = %bb14, %bb6
  %_30 = load i64, ptr %j, align 8
  %_33 = icmp ult i64 %_30, %v.1
  br i1 %_33, label %bb11, label %panic3

bb8:                                              ; preds = %bb6
  %2 = load i64, ptr %i, align 8
  %_27.0 = add i64 %2, 1
  %_27.1 = icmp ult i64 %_27.0, %2
  br i1 %_27.1, label %panic7, label %bb9

bb11:                                             ; preds = %bb10
  %_29 = getelementptr inbounds nuw double, ptr %v.0, i64 %_30
  %_3.i = load double, ptr %_29, align 8
  %_4.i = load double, ptr %p, align 8
  %_0.i = fcmp ogt double %_3.i, %_4.i
  br i1 %_0.i, label %bb13, label %bb15

panic3:                                           ; preds = %bb10
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_30, i64 %v.1, ptr align 8 @alloc_b3ffa52520fd637707107e0da6539f01) #14
  unreachable

bb15:                                             ; preds = %bb11
  %_37 = load i64, ptr %i, align 8
  %_38 = load i64, ptr %j, align 8
  %_36 = icmp uge i64 %_37, %_38
  br i1 %_36, label %bb16, label %bb17

bb13:                                             ; preds = %bb11
  %3 = load i64, ptr %j, align 8
  %_35.0 = sub i64 %3, 1
  %_35.1 = icmp ult i64 %3, 1
  br i1 %_35.1, label %panic6, label %bb14

bb17:                                             ; preds = %bb15
  %_40 = load i64, ptr %i, align 8
  %_41 = load i64, ptr %j, align 8
; call <[f64]>::swap
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4swapCscEnaBunu62E_10algorithms(ptr align 8 %v.0, i64 %v.1, i64 %_40, i64 %_41, ptr align 8 @alloc_bd7a221f280eb8a5c3589ee94b51abf4) #15
  %4 = load i64, ptr %i, align 8
  %_42.0 = add i64 %4, 1
  %_42.1 = icmp ult i64 %_42.0, %4
  br i1 %_42.1, label %panic4, label %bb19

bb16:                                             ; preds = %bb15
  %_47 = load i64, ptr %i, align 8
; call <[f64]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd12split_at_mutCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_46, ptr align 8 %v.0, i64 %v.1, i64 %_47, ptr align 8 @alloc_5347189550883c5cf2dac15d1989f2cb) #15
  %l.0 = load ptr, ptr %_46, align 8
  %5 = getelementptr inbounds i8, ptr %_46, i64 8
  %l.1 = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_46, i64 16
  %r.0 = load ptr, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  %r.1 = load i64, ptr %7, align 8
; call algorithms::quicksort::<f64>
  call void @_RINvCscEnaBunu62E_10algorithms9quicksortdEB2_(ptr align 8 %l.0, i64 %l.1)
; call algorithms::quicksort::<f64>
  call void @_RINvCscEnaBunu62E_10algorithms9quicksortdEB2_(ptr align 8 %r.0, i64 %r.1)
  br label %bb23

bb19:                                             ; preds = %bb17
  store i64 %_42.0, ptr %i, align 8
  %8 = load i64, ptr %j, align 8
  %_43.0 = sub i64 %8, 1
  %_43.1 = icmp ult i64 %8, 1
  br i1 %_43.1, label %panic5, label %bb20

panic4:                                           ; preds = %bb17
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_ad124890fb01d57067a49869e6a3f64f) #14
  unreachable

bb20:                                             ; preds = %bb19
  store i64 %_43.0, ptr %j, align 8
  br label %bb5

panic5:                                           ; preds = %bb19
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_32766398bbe1ef37d5243959bca58e4f) #14
  unreachable

bb14:                                             ; preds = %bb13
  store i64 %_35.0, ptr %j, align 8
  br label %bb10

panic6:                                           ; preds = %bb13
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_e6e6af7b7f0cdf434d4c3ff85dabee83) #14
  unreachable

bb9:                                              ; preds = %bb8
  store i64 %_27.0, ptr %i, align 8
  br label %bb5

panic7:                                           ; preds = %bb8
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_d87d7a041001c7c62725288599d7f2af) #14
  unreachable
}

; algorithms::quicksort::<u64>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvCscEnaBunu62E_10algorithms9quicksortyEB2_(ptr align 8 %v.0, i64 %v.1) unnamed_addr #0 !guid !146 {
start:
  %_46 = alloca [32 x i8], align 8
  %j = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %p = alloca [8 x i8], align 8
  %_2 = icmp ule i64 %v.1, 1
  br i1 %_2, label %bb23, label %bb1

bb1:                                              ; preds = %start
  %_6 = udiv i64 %v.1, 2
  %_12 = icmp ult i64 %_6, %v.1
  br i1 %_12, label %bb3, label %panic

bb23:                                             ; preds = %bb16, %start
  ret void

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds nuw i64, ptr %v.0, i64 %_6
  %1 = load i64, ptr %0, align 8
  store i64 %1, ptr %p, align 8
  %_19.0 = sub i64 %v.1, 1
  %_19.1 = icmp ult i64 %v.1, 1
  br i1 %_19.1, label %panic1, label %bb4

panic:                                            ; preds = %bb1
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_6, i64 %v.1, ptr align 8 @alloc_3f046313402cf9d112a7ec1a1a46896c) #14
  unreachable

bb4:                                              ; preds = %bb3
  store i64 0, ptr %i, align 8
  store i64 %_19.0, ptr %j, align 8
  br label %bb5

panic1:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_4740451e630eacf1c934674f31b3df4b) #14
  unreachable

bb5:                                              ; preds = %bb9, %bb20, %bb4
  %_22 = load i64, ptr %i, align 8
  %_25 = icmp ult i64 %_22, %v.1
  br i1 %_25, label %bb6, label %panic2

bb6:                                              ; preds = %bb5
  %_21 = getelementptr inbounds nuw i64, ptr %v.0, i64 %_22
  %_3.i8 = load i64, ptr %_21, align 8
  %_4.i9 = load i64, ptr %p, align 8
  %_0.i10 = icmp ult i64 %_3.i8, %_4.i9
  br i1 %_0.i10, label %bb8, label %bb10

panic2:                                           ; preds = %bb5
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_22, i64 %v.1, ptr align 8 @alloc_5e6e7bcba3a2b880b27bb87788baeb90) #14
  unreachable

bb10:                                             ; preds = %bb14, %bb6
  %_30 = load i64, ptr %j, align 8
  %_33 = icmp ult i64 %_30, %v.1
  br i1 %_33, label %bb11, label %panic3

bb8:                                              ; preds = %bb6
  %2 = load i64, ptr %i, align 8
  %_27.0 = add i64 %2, 1
  %_27.1 = icmp ult i64 %_27.0, %2
  br i1 %_27.1, label %panic7, label %bb9

bb11:                                             ; preds = %bb10
  %_29 = getelementptr inbounds nuw i64, ptr %v.0, i64 %_30
  %_3.i = load i64, ptr %_29, align 8
  %_4.i = load i64, ptr %p, align 8
  %_0.i = icmp ugt i64 %_3.i, %_4.i
  br i1 %_0.i, label %bb13, label %bb15

panic3:                                           ; preds = %bb10
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_30, i64 %v.1, ptr align 8 @alloc_b3ffa52520fd637707107e0da6539f01) #14
  unreachable

bb15:                                             ; preds = %bb11
  %_37 = load i64, ptr %i, align 8
  %_38 = load i64, ptr %j, align 8
  %_36 = icmp uge i64 %_37, %_38
  br i1 %_36, label %bb16, label %bb17

bb13:                                             ; preds = %bb11
  %3 = load i64, ptr %j, align 8
  %_35.0 = sub i64 %3, 1
  %_35.1 = icmp ult i64 %3, 1
  br i1 %_35.1, label %panic6, label %bb14

bb17:                                             ; preds = %bb15
  %_40 = load i64, ptr %i, align 8
  %_41 = load i64, ptr %j, align 8
; call <[u64]>::swap
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy4swapCscEnaBunu62E_10algorithms(ptr align 8 %v.0, i64 %v.1, i64 %_40, i64 %_41, ptr align 8 @alloc_bd7a221f280eb8a5c3589ee94b51abf4) #15
  %4 = load i64, ptr %i, align 8
  %_42.0 = add i64 %4, 1
  %_42.1 = icmp ult i64 %_42.0, %4
  br i1 %_42.1, label %panic4, label %bb19

bb16:                                             ; preds = %bb15
  %_47 = load i64, ptr %i, align 8
; call <[u64]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy12split_at_mutCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_46, ptr align 8 %v.0, i64 %v.1, i64 %_47, ptr align 8 @alloc_5347189550883c5cf2dac15d1989f2cb) #15
  %l.0 = load ptr, ptr %_46, align 8
  %5 = getelementptr inbounds i8, ptr %_46, i64 8
  %l.1 = load i64, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_46, i64 16
  %r.0 = load ptr, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  %r.1 = load i64, ptr %7, align 8
; call algorithms::quicksort::<u64>
  call void @_RINvCscEnaBunu62E_10algorithms9quicksortyEB2_(ptr align 8 %l.0, i64 %l.1)
; call algorithms::quicksort::<u64>
  call void @_RINvCscEnaBunu62E_10algorithms9quicksortyEB2_(ptr align 8 %r.0, i64 %r.1)
  br label %bb23

bb19:                                             ; preds = %bb17
  store i64 %_42.0, ptr %i, align 8
  %8 = load i64, ptr %j, align 8
  %_43.0 = sub i64 %8, 1
  %_43.1 = icmp ult i64 %8, 1
  br i1 %_43.1, label %panic5, label %bb20

panic4:                                           ; preds = %bb17
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_ad124890fb01d57067a49869e6a3f64f) #14
  unreachable

bb20:                                             ; preds = %bb19
  store i64 %_43.0, ptr %j, align 8
  br label %bb5

panic5:                                           ; preds = %bb19
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_32766398bbe1ef37d5243959bca58e4f) #14
  unreachable

bb14:                                             ; preds = %bb13
  store i64 %_35.0, ptr %j, align 8
  br label %bb10

panic6:                                           ; preds = %bb13
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_e6e6af7b7f0cdf434d4c3ff85dabee83) #14
  unreachable

bb9:                                              ; preds = %bb8
  store i64 %_27.0, ptr %i, align 8
  br label %bb5

panic7:                                           ; preds = %bb8
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_d87d7a041001c7c62725288599d7f2af) #14
  unreachable
}

; <core::option::Option<usize>>::and_then::<usize, <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::size_hint::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE8and_thenjNCNvXsd_NtNtB5_4iter5rangeINtNtNtB5_3ops5range14RangeInclusivejENtNtNtB14_6traits8iterator8Iterator9size_hint0ECscEnaBunu62E_10algorithms(i64 %0, i64 %1) unnamed_addr #1 !guid !147 {
start:
  %_7 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_7, align 1
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::size_hint::{closure#0}
  %7 = call { i64, i64 } @_RNCNvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBb_3ops5range14RangeInclusivejENtNtNtB9_6traits8iterator8Iterator9size_hint0CscEnaBunu62E_10algorithms(i64 %x) #15
  %8 = extractvalue { i64, i64 } %7, 0
  %9 = extractvalue { i64, i64 } %7, 1
  store i64 %8, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %9, ptr %10, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %11 = load i8, ptr %_7, align 1
  %12 = trunc nuw i8 %11 to i1
  br i1 %12, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %13 = load i64, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { i64, i64 } poison, i64 %13, 0
  %17 = insertvalue { i64, i64 } %16, i64 %15, 1
  ret { i64, i64 } %17

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u64>>::map::<u32, &mut algorithms::collatz>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionyE3mapmQNvCscEnaBunu62E_10algorithms7collatzEBS_(i64 %0, i64 %1, ptr %f) unnamed_addr #1 !guid !148 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <&mut algorithms::collatz as core::ops::function::FnOnce<(u64,)>>::call_once
  %_5 = call i32 @_RNvXs2_NtNtNtCsl10jNU3mE6R_4core3ops8function5implsQNvCscEnaBunu62E_10algorithms7collatzINtB7_6FnOnceTyEE9call_onceBQ_(ptr %f, i64 %x)
  %7 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %7, align 4
  store i32 1, ptr %_0, align 4
  br label %bb7

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_8, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %10 = load i32, ptr %_0, align 4
  %11 = getelementptr inbounds i8, ptr %_0, i64 4
  %12 = load i32, ptr %11, align 4
  %13 = insertvalue { i32, i32 } poison, i32 %10, 0
  %14 = insertvalue { i32, i32 } %13, i32 %12, 1
  ret { i32, i32 } %14

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #1 !guid !149 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCscEnaBunu62E_10algorithms(ptr %x) #15
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECscEnaBunu62E_10algorithms(ptr %_4) #15
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<[[i64; 3]; 3]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAAxj3_BY_ECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !150 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<[[i64; 3]; 3]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAAxj3_BW_E8from_refCscEnaBunu62E_10algorithms(ptr align 8 %x) #15
; call <core::ptr::non_null::NonNull<[[i64; 3]; 3]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAAxj3_BX_E4castuECscEnaBunu62E_10algorithms(ptr %_4) #15
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAAxj3_Bz_NtNtB7_3fmt5Debug3fmtCscEnaBunu62E_10algorithms, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<[f64; 5]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAdj5_ECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !151 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<[f64; 5]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAdj5_E8from_refCscEnaBunu62E_10algorithms(ptr align 8 %x) #15
; call <core::ptr::non_null::NonNull<[f64; 5]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAdj5_E4castuECscEnaBunu62E_10algorithms(ptr %_4) #15
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAdj5_NtNtB7_3fmt5Debug3fmtCscEnaBunu62E_10algorithms, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<&[(u8, u8)]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSThhEECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !152 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&[(u8, u8)]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSThhEE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %x) #15
; call <core::ptr::non_null::NonNull<&[(u8, u8)]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSThhEE4castuECscEnaBunu62E_10algorithms(ptr %_4) #15
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSThhENtB6_5Debug3fmtCscEnaBunu62E_10algorithms, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<&[usize]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSjECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !153 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&[usize]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSjE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %x) #15
; call <core::ptr::non_null::NonNull<&[usize]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSjE4castuECscEnaBunu62E_10algorithms(ptr %_4) #15
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSjNtB6_5Debug3fmtCscEnaBunu62E_10algorithms, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<&[u64]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSyECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !154 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<&[u64]>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSyE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %x) #15
; call <core::ptr::non_null::NonNull<&[u64]>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSyE4castuECscEnaBunu62E_10algorithms(ptr %_4) #15
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSyNtB6_5Debug3fmtCscEnaBunu62E_10algorithms, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of::<(u8, u8)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofThhEECscEnaBunu62E_10algorithms() unnamed_addr #1 !guid !155 {
start:
  ret i64 1
}

; <core::mem::alignment::Alignment>::of::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofcECscEnaBunu62E_10algorithms() unnamed_addr #1 !guid !156 {
start:
  ret i64 4
}

; <core::mem::alignment::Alignment>::of::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofjECscEnaBunu62E_10algorithms() unnamed_addr #1 !guid !157 {
start:
  ret i64 8
}

; <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtNtB7_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2t_3VecjE14extend_trustedINtNtB5_5range14RangeInclusivejEE0E0ECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %f) unnamed_addr #1 !guid !158 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %f, i64 24, i1 false)
  ret void
}

; <core::ptr::unique::Unique<u8>>::cast::<(u8, u8)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castThhEECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !159 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<(u8, u8)>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castThhEECscEnaBunu62E_10algorithms(ptr %self) #15
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castbECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !160 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<bool>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castbECscEnaBunu62E_10algorithms(ptr %self) #15
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castcECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !161 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<char>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castcECscEnaBunu62E_10algorithms(ptr %self) #15
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castyECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !162 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u64>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castyECscEnaBunu62E_10algorithms(ptr %self) #15
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[[i64; 3]; 3]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAAxj3_BX_E4castuECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !163 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[f64; 5]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullAdj5_E4castuECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !164 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&[(u8, u8)]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSThhEE4castuECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !165 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&[usize]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSjE4castuECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !166 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<&[u64]>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullRSyE4castuECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !167 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[[u8; 8]]>>::cast::<[u8; 8]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAhj8_E4castBV_ECscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !168 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[[i64; 3]]>>::cast::<[i64; 3]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAxj3_E4castBV_ECscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !169 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[(u8, u8)]>>::cast::<(u8, u8)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSThhEE4castBV_ECscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !170 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[f64]>>::cast::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSdE4castdECscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !171 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<[i64]>>::cast::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSxE4castxECscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !172 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !173 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<(u8, u8)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castThhEECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !174 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castbECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !175 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castcECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !176 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castyECscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !177 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<(u8, u8)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrThhEECscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !178 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<(u8, u8)>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullThhEECscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::ptr::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrbECscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !179 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<bool>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullbECscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::ptr::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrcECscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !180 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<char>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullcECscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::ptr::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptryECscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !181 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u64>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullyECscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<(u8, u8)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullThhEECscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !182 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<(u8, u8)>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castThhEECscEnaBunu62E_10algorithms(ptr %_3) #15
; call <core::ptr::unique::Unique<(u8, u8)>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueThhEE15as_non_null_ptrCscEnaBunu62E_10algorithms(ptr %_2) #15
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::non_null::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullbECscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !183 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<bool>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castbECscEnaBunu62E_10algorithms(ptr %_3) #15
; call <core::ptr::unique::Unique<bool>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquebE15as_non_null_ptrCscEnaBunu62E_10algorithms(ptr %_2) #15
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::non_null::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullcECscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !184 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<char>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castcECscEnaBunu62E_10algorithms(ptr %_3) #15
; call <core::ptr::unique::Unique<char>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquecE15as_non_null_ptrCscEnaBunu62E_10algorithms(ptr %_2) #15
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::non_null::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullyECscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !185 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u64>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castyECscEnaBunu62E_10algorithms(ptr %_3) #15
; call <core::ptr::unique::Unique<u64>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE15as_non_null_ptrCscEnaBunu62E_10algorithms(ptr %_2) #15
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<19, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj13_Kj2_ECscEnaBunu62E_10algorithms(ptr %template, ptr align 8 %args) unnamed_addr #1 !guid !186 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECscEnaBunu62E_10algorithms(ptr %template, ptr align 8 %args) unnamed_addr #1 !guid !187 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<11, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj2_ECscEnaBunu62E_10algorithms(ptr %template, ptr align 8 %args) unnamed_addr #1 !guid !188 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::builders::DebugList>::entries::<&[i64; 3], core::slice::iter::Iter<[i64; 3]>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRAxj3_INtNtNtBa_5slice4iter4IterB14_EECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !189 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<[i64; 3]> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterAxj3_ENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %entries.0, ptr %entries.1) #15
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<[i64; 3]> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterAxj3_ENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %iter) #15
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !190
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.0)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&(u8, u8), core::slice::iter::Iter<(u8, u8)>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRThhEINtNtNtBa_5slice4iter4IterB14_EECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !191 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<(u8, u8)> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterThhEENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %entries.0, ptr %entries.1) #15
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<(u8, u8)> as core::iter::traits::iterator::Iterator>::next
  %2 = call ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterThhEENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %iter) #15
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !190
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.1)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&f64, core::slice::iter::Iter<f64>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRdINtNtNtBa_5slice4iter4IterdEECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !192 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<f64> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterdENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %entries.0, ptr %entries.1) #15
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %iter) #15
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !190
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.2)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&usize, core::slice::iter::Iter<usize>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRjINtNtNtBa_5slice4iter4IterjEECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !193 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterjENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %entries.0, ptr %entries.1) #15
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<usize> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterjENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBa_(ptr align 8 %iter) #15
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !190
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.3)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&i64, core::slice::iter::Iter<i64>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRxINtNtNtBa_5slice4iter4IterxEECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !194 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<i64> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterxENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %entries.0, ptr %entries.1) #15
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<i64> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterxENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %iter) #15
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !190
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.4)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::fmt::builders::DebugList>::entries::<&u64, core::slice::iter::Iter<u64>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRyINtNtNtBa_5slice4iter4IteryEECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !195 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<u64> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IteryENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %entries.0, ptr %entries.1) #15
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<u64> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs2d0hS33vDhg_5gimli(ptr align 8 %iter) #15
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !190
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.5)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <core::iter::adapters::flatten::FlattenCompat<core::slice::iter::Iter<[u8; 8]>, core::slice::iter::Iter<u8>>>::iter_fold::<u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvMsg_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB6_13FlattenCompatINtNtNtBc_5slice4iter4IterAhj8_EIB1d_hEE9iter_foldmNCINvNvXsi_B6_IBS_ppENtNtNtBa_6traits8iterator8Iterator4fold7flattenB1I_mNCINvNtB8_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB2q_5accummNtB4p_3Sum3sumINtB3h_3MapINtB6_7FlattenB1c_EB3D_EE0E0E0EB3H_(ptr align 8 %self, i32 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !196 {
start:
  %_24 = alloca [1 x i8], align 1
  %_23 = alloca [1 x i8], align 1
  %_22 = alloca [1 x i8], align 1
  %_21 = alloca [1 x i8], align 1
  %_19 = alloca [24 x i8], align 8
  %_8 = alloca [24 x i8], align 8
  %fold = alloca [0 x i8], align 1
  %acc = alloca [4 x i8], align 4
  store i32 %0, ptr %acc, align 4
  store i8 0, ptr %_22, align 1
  store i8 0, ptr %_21, align 1
  store i8 0, ptr %_24, align 1
  store i8 0, ptr %_23, align 1
  store i8 1, ptr %_23, align 1
  store i8 1, ptr %_24, align 1
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds i8, ptr %1, i64 8
  %4 = load ptr, ptr %3, align 8
  %5 = ptrtoint ptr %2 to i64
  %6 = icmp eq i64 %5, 0
  %_4 = select i1 %6, i64 0, i64 1
  %7 = trunc nuw i64 %_4 to i1
  br i1 %7, label %bb1, label %bb3

bb1:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 16
  %iter.0 = load ptr, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %iter.1 = load ptr, ptr %9, align 8
  %_9 = load i32, ptr %acc, align 4
  store i32 %_9, ptr %_8, align 8
  %10 = getelementptr inbounds i8, ptr %_8, i64 8
  store ptr %iter.0, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 8
  store ptr %iter.1, ptr %11, align 8
  %12 = load i32, ptr %_8, align 8
  %13 = getelementptr inbounds i8, ptr %_8, i64 8
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds i8, ptr %13, i64 8
  %16 = load ptr, ptr %15, align 8
; call <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten::<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}
  %_6 = call i32 @_RNCINvNvXsi_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtBa_13FlattenCompatppENtNtNtBe_6traits8iterator8Iterator4fold7flattenINtNtNtBg_5slice4iter4IterhEmNCINvNtBc_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1n_5accummNtB3K_3Sum3sumINtB2C_3MapINtBa_7FlattenIB25_Ahj8_EEB2Y_EE0E0E0B32_(ptr %fold, i32 %12, ptr %14, ptr %16) #15
  br label %bb2

bb3:                                              ; preds = %bb2, %start
  store i8 0, ptr %_24, align 1
  store i8 1, ptr %_22, align 1
  %_11.0 = load ptr, ptr %self, align 8
  %17 = getelementptr inbounds i8, ptr %self, i64 8
  %_11.1 = load ptr, ptr %17, align 8
  store i8 1, ptr %_21, align 1
  %_12 = load i32, ptr %acc, align 4
; call <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten::<&[u8; 8], u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>
  %_13 = call ptr @_RINvNvMsg_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB8_13FlattenCompatppE9iter_fold7flattenRAhj8_mNCINvNvXsi_B8_BT_NtNtNtBc_6traits8iterator8Iterator4fold7flattenINtNtNtBe_5slice4iter4IterhEmNCINvNtBa_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB21_5accummNtB4o_3Sum3sumINtB3g_3MapINtB8_7FlattenIB2J_B1A_EEB3C_EE0E0E0EB3G_(ptr %fold) #15
  br label %bb4

bb2:                                              ; preds = %bb1
  store i32 %_6, ptr %acc, align 4
  br label %bb3

bb4:                                              ; preds = %bb3
  store i8 0, ptr %_22, align 1
  store i8 0, ptr %_21, align 1
; call <core::iter::adapters::fuse::Fuse<core::slice::iter::Iter<[u8; 8]>> as core::iter::traits::iterator::Iterator>::fold::<u32, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<&[u8; 8], u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>::{closure#0}>
  %_10 = call i32 @_RINvXs1_NtNtNtCsl10jNU3mE6R_4core4iter8adapters4fuseINtB6_4FuseINtNtNtBc_5slice4iter4IterAhj8_EENtNtNtBa_6traits8iterator8Iterator4foldmNCINvNvMsg_NtB8_7flattenINtB2l_13FlattenCompatppE9iter_fold7flattenRB1p_mNCINvNvXsi_B2l_B2y_B1w_4fold7flattenIB10_hEmNCINvNtB8_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1A_5accummNtB5g_3Sum3sumINtB48_3MapINtB2l_7FlattenBZ_EB4u_EE0E0E0E0EB4y_(ptr %_11.0, ptr %_11.1, i32 %_12, ptr %_13) #15
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_21, align 1
  store i8 0, ptr %_22, align 1
  store i32 %_10, ptr %acc, align 4
  %18 = getelementptr inbounds i8, ptr %self, i64 32
  %19 = load ptr, ptr %18, align 8
  %20 = getelementptr inbounds i8, ptr %18, i64 8
  %21 = load ptr, ptr %20, align 8
  %22 = ptrtoint ptr %19 to i64
  %23 = icmp eq i64 %22, 0
  %_15 = select i1 %23, i64 0, i64 1
  %24 = trunc nuw i64 %_15 to i1
  br i1 %24, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  store i8 0, ptr %_23, align 1
  %25 = getelementptr inbounds i8, ptr %self, i64 32
  %iter.01 = load ptr, ptr %25, align 8
  %26 = getelementptr inbounds i8, ptr %25, i64 8
  %iter.12 = load ptr, ptr %26, align 8
  %_20 = load i32, ptr %acc, align 4
  store i32 %_20, ptr %_19, align 8
  %27 = getelementptr inbounds i8, ptr %_19, i64 8
  store ptr %iter.01, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store ptr %iter.12, ptr %28, align 8
  %29 = load i32, ptr %_19, align 8
  %30 = getelementptr inbounds i8, ptr %_19, i64 8
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr inbounds i8, ptr %30, i64 8
  %33 = load ptr, ptr %32, align 8
; call <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten::<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}
  %_17 = call i32 @_RNCINvNvXsi_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtBa_13FlattenCompatppENtNtNtBe_6traits8iterator8Iterator4fold7flattenINtNtNtBg_5slice4iter4IterhEmNCINvNtBc_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1n_5accummNtB3K_3Sum3sumINtB2C_3MapINtBa_7FlattenIB25_Ahj8_EEB2Y_EE0E0E0B32_(ptr %fold, i32 %29, ptr %31, ptr %33) #15
  br label %bb7

bb8:                                              ; preds = %bb7, %bb5
  %_0 = load i32, ptr %acc, align 4
  br label %bb9

bb7:                                              ; preds = %bb6
  store i32 %_17, ptr %acc, align 4
  br label %bb8

bb9:                                              ; preds = %bb8
  ret i32 %_0

bb21:                                             ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable

bb14:                                             ; No predecessors!
  unreachable

bb15:                                             ; No predecessors!
  unreachable

bb16:                                             ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<char>>::extend_desugared::<core::str::iter::Chars>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VeccE16extend_desugaredNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr %0, ptr %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !197 {
start:
  %_23 = alloca [1 x i8], align 1
  %_13 = alloca [24 x i8], align 8
  %_3 = alloca [4 x i8], align 4
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %2 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_23, align 1
  br label %bb1

bb1:                                              ; preds = %bb13, %start
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
  %3 = call i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %iterator) #15
  store i32 %3, ptr %_3, align 4
  br label %bb2

bb2:                                              ; preds = %bb1
  %4 = load i32, ptr %_3, align 4
  %5 = icmp eq i32 %4, -1
  %_5 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_5 to i1
  br i1 %6, label %bb3, label %bb14

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_23, align 1
  %element = load i32, ptr %_3, align 4
; call <alloc::vec::Vec<char>>::len
  %len = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb4

bb14:                                             ; preds = %bb2
  ret void

bb4:                                              ; preds = %bb3
; call <alloc::vec::Vec<char>>::capacity
  %_10 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = icmp eq i64 %len, %_10
  br i1 %_9, label %bb6, label %bb9

bb9:                                              ; preds = %bb21, %bb5
; call <alloc::vec::Vec<char>>::as_mut_ptr
  %_19 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb10

bb6:                                              ; preds = %bb5
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator9size_hintCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_13, ptr align 8 %iterator) #15
  br label %bb7

bb7:                                              ; preds = %bb6
  %lower = load i64, ptr %_13, align 8
  %_0.i1 = call i64 @llvm.uadd.sat.i64(i64 %lower, i64 1)
  br label %bb8

bb8:                                              ; preds = %bb7
; call <alloc::vec::Vec<char>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %_0.i1)
  br label %bb21

bb21:                                             ; preds = %bb8
  br label %bb9

bb10:                                             ; preds = %bb9
  %_0.i = getelementptr inbounds nuw i32, ptr %_19, i64 %len
  br label %bb11

bb11:                                             ; preds = %bb10
  store i8 0, ptr %_23, align 1
  store i32 %element, ptr %_0.i, align 4
  br label %bb12

bb12:                                             ; preds = %bb11
  %_22 = add i64 %len, 1
; call <alloc::vec::Vec<char>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7set_lenCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %_22) #15
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_23, align 1
  br label %bb1

bb20:                                             ; No predecessors!
  unreachable

bb16:                                             ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<usize>>::extend_trusted::<core::ops::range::RangeInclusive<usize>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %iterator) unnamed_addr #0 personality ptr @rust_eh_personality !guid !198 {
start:
  %_23 = alloca [1 x i8], align 1
  %_20 = alloca [24 x i8], align 8
  %_19 = alloca [24 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %high = alloca [16 x i8], align 8
  store i8 0, ptr %_23, align 1
  store i8 1, ptr %_23, align 1
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range14RangeInclusivejENtNtNtB7_6traits8iterator8Iterator9size_hintCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %iterator) #15
  br label %bb1

bb1:                                              ; preds = %start
  %low = load i64, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = getelementptr inbounds i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
  store i64 %1, ptr %high, align 8
  %4 = getelementptr inbounds i8, ptr %high, i64 8
  store i64 %3, ptr %4, align 8
  %_7 = load i64, ptr %high, align 8
  %5 = getelementptr inbounds i8, ptr %high, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_7 to i1
  br i1 %7, label %bb2, label %bb7

bb2:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %high, i64 8
  %additional = load i64, ptr %8, align 8
; call <alloc::vec::Vec<usize>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %additional)
  br label %bb3

bb7:                                              ; preds = %bb1
; call <core::fmt::Arguments>::from_str
  %9 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_31365cfefba383c4d2bf6b6a04cc10aa, i64 17) #15
  %_22.0 = extractvalue { ptr, ptr } %9, 0
  %_22.1 = extractvalue { ptr, ptr } %9, 1
  br label %bb8

bb3:                                              ; preds = %bb2
; call <alloc::vec::Vec<usize>>::as_mut_ptr
  %ptr = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb4

bb4:                                              ; preds = %bb3
  %_17 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::new
  %10 = call { ptr, i64 } @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop3newCscEnaBunu62E_10algorithms(ptr align 8 %_17) #15
  %local_len.0 = extractvalue { ptr, i64 } %10, 0
  %local_len.1 = extractvalue { ptr, i64 } %10, 1
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_23, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_19, ptr align 8 %iterator, i64 24, i1 false)
  %11 = getelementptr inbounds i8, ptr %_20, i64 16
  store ptr %ptr, ptr %11, align 8
  store ptr %local_len.0, ptr %_20, align 8
  %12 = getelementptr inbounds i8, ptr %_20, i64 8
  store i64 %local_len.1, ptr %12, align 8
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>
  call void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejENtNtNtNtBa_4iter6traits8iterator8Iterator8for_eachNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1S_3VecjE14extend_trustedB3_E0ECscEnaBunu62E_10algorithms(ptr align 8 %_19, ptr align 8 %_20) #15
  br label %bb6

bb6:                                              ; preds = %bb5
  ret void

bb8:                                              ; preds = %bb7
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_22.0, ptr %_22.1, ptr align 8 @alloc_8d2d54b2e3654c99232db78ca79b95fd) #14
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<usize>>::extend_desugared::<core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjE16extend_desugaredINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtB19_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EEB2B_(ptr align 8 %self, ptr align 8 %iterator) unnamed_addr #0 personality ptr @rust_eh_personality !guid !199 {
start:
  %_23 = alloca [1 x i8], align 1
  %_13 = alloca [24 x i8], align 8
  %_3 = alloca [16 x i8], align 8
  store i8 0, ptr %_23, align 1
  br label %bb1

bb1:                                              ; preds = %bb13, %start
; call <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6filterINtB5_6FilterINtNtNtBb_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtNtNtB9_6traits8iterator8Iterator4nextB1I_(ptr align 8 %iterator) #15
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_3, align 8
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %2, ptr %3, align 8
  br label %bb2

bb2:                                              ; preds = %bb1
  %_5 = load i64, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_5 to i1
  br i1 %6, label %bb3, label %bb14

bb3:                                              ; preds = %bb2
  store i8 1, ptr %_23, align 1
  %7 = getelementptr inbounds i8, ptr %_3, i64 8
  %element = load i64, ptr %7, align 8
; call <alloc::vec::Vec<usize>>::len
  %len = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE3lenCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb4

bb14:                                             ; preds = %bb2
  ret void

bb4:                                              ; preds = %bb3
; call <alloc::vec::Vec<usize>>::capacity
  %_10 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = icmp eq i64 %len, %_10
  br i1 %_9, label %bb6, label %bb9

bb9:                                              ; preds = %bb21, %bb5
; call <alloc::vec::Vec<usize>>::as_mut_ptr
  %_19 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb10

bb6:                                              ; preds = %bb5
; call <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6filterINtB5_6FilterINtNtNtBb_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtNtNtB9_6traits8iterator8Iterator9size_hintB1I_(ptr sret([24 x i8]) align 8 %_13, ptr align 8 %iterator) #15
  br label %bb7

bb7:                                              ; preds = %bb6
  %lower = load i64, ptr %_13, align 8
  %_0.i1 = call i64 @llvm.uadd.sat.i64(i64 %lower, i64 1)
  br label %bb8

bb8:                                              ; preds = %bb7
; call <alloc::vec::Vec<usize>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %_0.i1)
  br label %bb21

bb21:                                             ; preds = %bb8
  br label %bb9

bb10:                                             ; preds = %bb9
  %_0.i = getelementptr inbounds nuw i64, ptr %_19, i64 %len
  br label %bb11

bb11:                                             ; preds = %bb10
  store i8 0, ptr %_23, align 1
  store i64 %element, ptr %_0.i, align 8
  br label %bb12

bb12:                                             ; preds = %bb11
  %_22 = add i64 %len, 1
; call <alloc::vec::Vec<usize>>::set_len
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE7set_lenCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %_22) #15
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_23, align 1
  br label %bb1

bb20:                                             ; No predecessors!
  unreachable

bb16:                                             ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u64>>::extend_trusted::<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecyE14extend_trustedINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB17_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EEB2j_(ptr align 8 %self, ptr align 8 %iterator) unnamed_addr #0 personality ptr @rust_eh_personality !guid !200 {
start:
  %_23 = alloca [1 x i8], align 1
  %_20 = alloca [24 x i8], align 8
  %_19 = alloca [16 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %high = alloca [16 x i8], align 8
  store i8 0, ptr %_23, align 1
  store i8 1, ptr %_23, align 1
; call <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtNtNtB9_6traits8iterator8Iterator9size_hintB1s_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %iterator) #15
  br label %bb1

bb1:                                              ; preds = %start
  %low = load i64, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = getelementptr inbounds i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
  store i64 %1, ptr %high, align 8
  %4 = getelementptr inbounds i8, ptr %high, i64 8
  store i64 %3, ptr %4, align 8
  %_7 = load i64, ptr %high, align 8
  %5 = getelementptr inbounds i8, ptr %high, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_7 to i1
  br i1 %7, label %bb2, label %bb7

bb2:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %high, i64 8
  %additional = load i64, ptr %8, align 8
; call <alloc::vec::Vec<u64>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %additional)
  br label %bb3

bb7:                                              ; preds = %bb1
; call <core::fmt::Arguments>::from_str
  %9 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_31365cfefba383c4d2bf6b6a04cc10aa, i64 17) #15
  %_22.0 = extractvalue { ptr, ptr } %9, 0
  %_22.1 = extractvalue { ptr, ptr } %9, 1
  br label %bb8

bb3:                                              ; preds = %bb2
; call <alloc::vec::Vec<u64>>::as_mut_ptr
  %ptr = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb4

bb4:                                              ; preds = %bb3
  %_17 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::new
  %10 = call { ptr, i64 } @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop3newCscEnaBunu62E_10algorithms(ptr align 8 %_17) #15
  %local_len.0 = extractvalue { ptr, i64 } %10, 0
  %local_len.1 = extractvalue { ptr, i64 } %10, 1
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_23, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_19, ptr align 8 %iterator, i64 16, i1 false)
  %11 = getelementptr inbounds i8, ptr %_20, i64 16
  store ptr %ptr, ptr %11, align 8
  store ptr %local_len.0, ptr %_20, align 8
  %12 = getelementptr inbounds i8, ptr %_20, i64 8
  store i64 %local_len.1, ptr %12, align 8
; call <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>
  call void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2K_3VecyE14extend_trustedB3_E0EB1n_(ptr align 8 %_19, ptr align 8 %_20) #15
  br label %bb6

bb6:                                              ; preds = %bb5
  ret void

bb8:                                              ; preds = %bb7
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_22.0, ptr %_22.1, ptr align 8 @alloc_8d2d54b2e3654c99232db78ca79b95fd) #14
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; alloc::vec::from_elem::<bool>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCs7CppTae75M1_5alloc3vec9from_elembECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i1 zeroext %elem, i64 %n) unnamed_addr #0 !guid !201 {
start:
; call <bool as alloc::vec::spec_from_elem::SpecFromElem>::from_elem::<alloc::alloc::Global>
  call void @_RINvXs_NtNtCs7CppTae75M1_5alloc3vec14spec_from_elembNtB5_12SpecFromElem9from_elemNtNtB9_5alloc6GlobalECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i1 zeroext %elem, i64 %n) #15
  ret void
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECscEnaBunu62E_10algorithms(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !202 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.6, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::cmp::max_by::<u32, &mut <u32 as core::cmp::Ord>::cmp>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core3cmp6max_bymQNvYmNtB2_3Ord3cmpECscEnaBunu62E_10algorithms(i32 %0, i32 %1, ptr %compare) unnamed_addr #1 personality ptr @rust_eh_personality !guid !203 {
start:
  %_10 = alloca [1 x i8], align 1
  %_9 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %v2 = alloca [4 x i8], align 4
  %v1 = alloca [4 x i8], align 4
  store i32 %0, ptr %v1, align 4
  store i32 %1, ptr %v2, align 4
  store i8 0, ptr %_10, align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_10, align 1
  store i8 1, ptr %_9, align 1
; call <&mut <u32 as core::cmp::Ord>::cmp as core::ops::function::FnOnce<(&u32, &u32)>>::call_once
  %_5 = call i8 @_RNvXs2_NtNtNtCsl10jNU3mE6R_4core3ops8function5implsQNvYmNtNtBb_3cmp3Ord3cmpINtB7_6FnOnceTRmB1p_EE9call_onceCscEnaBunu62E_10algorithms(ptr %compare, ptr align 4 %v1, ptr align 4 %v2)
  br label %bb1

bb1:                                              ; preds = %start
; call <core::cmp::Ordering>::is_gt
  %_4 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3cmpNtB2_8Ordering5is_gtCscEnaBunu62E_10algorithms(i8 %_5) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  br i1 %_4, label %bb3, label %bb4

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_9, align 1
  %2 = load i32, ptr %v2, align 4
  store i32 %2, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %bb2
  store i8 0, ptr %_10, align 1
  %3 = load i32, ptr %v1, align 4
  store i32 %3, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i8, ptr %_9, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb10, label %bb6

bb6:                                              ; preds = %bb10, %bb5
  %6 = load i8, ptr %_10, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb11, label %bb7

bb10:                                             ; preds = %bb5
  br label %bb6

bb7:                                              ; preds = %bb11, %bb6
  %8 = load i32, ptr %_0, align 4
  ret i32 %8

bb11:                                             ; preds = %bb6
  br label %bb7

bb8:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable
}

; core::ptr::slice_from_raw_parts_mut::<(u8, u8)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutThhEECscEnaBunu62E_10algorithms(ptr %data, i64 %len) unnamed_addr #1 !guid !204 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[(u8, u8)], (u8, u8)>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSThhEBX_ECscEnaBunu62E_10algorithms(ptr %data, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutbECscEnaBunu62E_10algorithms(ptr %data, i64 %len) unnamed_addr #1 !guid !205 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[bool], bool>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSbbECscEnaBunu62E_10algorithms(ptr %data, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutcECscEnaBunu62E_10algorithms(ptr %data, i64 %len) unnamed_addr #1 !guid !206 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[char], char>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSccECscEnaBunu62E_10algorithms(ptr %data, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutdECscEnaBunu62E_10algorithms(ptr %data, i64 %len) unnamed_addr #1 !guid !207 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[f64], f64>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSddECscEnaBunu62E_10algorithms(ptr %data, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutjECscEnaBunu62E_10algorithms(ptr %data, i64 %len) unnamed_addr #1 !guid !208 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[usize], usize>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSjjECscEnaBunu62E_10algorithms(ptr %data, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutyECscEnaBunu62E_10algorithms(ptr %data, i64 %len) unnamed_addr #1 !guid !209 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u64], u64>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSyyECscEnaBunu62E_10algorithms(ptr %data, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<alloc::vec::Vec<(u8, u8)>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecThhEEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !210 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<(u8, u8)> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<(u8, u8)>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecThhEEECscEnaBunu62E_10algorithms(ptr align 8 %_1) #16
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<(u8, u8)>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecThhEEECscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<bool>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecbEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !211 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<bool> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<bool>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecbEECscEnaBunu62E_10algorithms(ptr align 8 %_1) #16
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<bool>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecbEECscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<char>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !212 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<char> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeccEECscEnaBunu62E_10algorithms(ptr align 8 %_1) #16
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<char>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeccEECscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<usize>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !213 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<usize> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecjEECscEnaBunu62E_10algorithms(ptr align 8 %_1) #16
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<usize>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecjEECscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<u64>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecyEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !214 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u64> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u64>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecyEECscEnaBunu62E_10algorithms(ptr align 8 %_1) #16
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u64>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecyEECscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<(u8, u8)>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecThhEEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 !guid !215 {
start:
; call <alloc::raw_vec::RawVec<(u8, u8)> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<bool>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecbEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 !guid !216 {
start:
; call <alloc::raw_vec::RawVec<bool> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<char>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeccEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 !guid !217 {
start:
; call <alloc::raw_vec::RawVec<char> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<usize>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecjEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 !guid !218 {
start:
; call <alloc::raw_vec::RawVec<usize> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u64>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecyEECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 !guid !219 {
start:
; call <alloc::raw_vec::RawVec<u64> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<<core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMNtNtB4_3ops9try_traitINtBH_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2R_3VecjE14extend_trustedINtNtBJ_5range14RangeInclusivejEE0E0E0ECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 !guid !220 {
start:
; call core::ptr::drop_glue::<core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1L_3VecjE14extend_trustedINtNtNtB4_3ops5range14RangeInclusivejEE0E0ECscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<<alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtBK_3VecjE14extend_trustedINtNtNtB4_3ops5range14RangeInclusivejEE0ECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 !guid !221 {
start:
; call core::ptr::drop_glue::<alloc::vec::set_len_on_drop::SetLenOnDrop>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtNtCs7CppTae75M1_5alloc3vec15set_len_on_drop12SetLenOnDropECsddYV2PBJW9h_3std(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<<alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtBK_3VecyE14extend_trustedINtNtNtNtB4_4iter8adapters3map3MapINtNtNtB4_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0EB2G_(ptr align 8 %_1) unnamed_addr #0 !guid !222 {
start:
; call core::ptr::drop_glue::<alloc::vec::set_len_on_drop::SetLenOnDrop>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtNtCs7CppTae75M1_5alloc3vec15set_len_on_drop12SetLenOnDropECsddYV2PBJW9h_3std(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::iter::adapters::map::map_fold<i32, u64, (), algorithms::main::{closure#0}, core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldlyuNCNvCscEnaBunu62E_10algorithms4main0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2W_3VecyE14extend_trustedINtBG_3MapINtNtNtB4_3ops5range5RangelEB1j_EE0E0E0EB1n_(ptr align 8 %_1) unnamed_addr #0 !guid !223 {
start:
; call core::ptr::drop_glue::<core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1L_3VecyE14extend_trustedINtNtNtBO_8adapters3map3MapINtNtNtB4_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0E0EB3B_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1L_3VecjE14extend_trustedINtNtNtB4_3ops5range14RangeInclusivejEE0E0ECscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #0 !guid !224 {
start:
; call core::ptr::drop_glue::<<alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtBK_3VecjE14extend_trustedINtNtNtB4_3ops5range14RangeInclusivejEE0ECscEnaBunu62E_10algorithms(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1L_3VecyE14extend_trustedINtNtNtBO_8adapters3map3MapINtNtNtB4_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0E0EB3B_(ptr align 8 %_1) unnamed_addr #0 !guid !225 {
start:
; call core::ptr::drop_glue::<<alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtBK_3VecyE14extend_trustedINtNtNtNtB4_4iter8adapters3map3MapINtNtNtB4_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0EB2G_(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<[[i64; 3]; 3]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxAAxj3_BF_ECscEnaBunu62E_10algorithms(ptr sret([72 x i8]) align 8 %_0, ptr align 8 %dummy) unnamed_addr #1 !guid !226 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %dummy, i64 72, i1 false)
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !227
  ret void
}

; core::hint::black_box::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxReECscEnaBunu62E_10algorithms(ptr %dummy.0, i64 %dummy.1) unnamed_addr #1 !guid !228 {
start:
  %_0 = alloca [16 x i8], align 8
  store ptr %dummy.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %dummy.1, ptr %0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !227
  %1 = load ptr, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { ptr, i64 } poison, ptr %1, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %3, 1
  ret { ptr, i64 } %5
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECscEnaBunu62E_10algorithms(i64 %dummy) unnamed_addr #1 !guid !229 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !227
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECscEnaBunu62E_10algorithms(i32 %dummy) unnamed_addr #1 !guid !230 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !227
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECscEnaBunu62E_10algorithms(i64 %dummy) unnamed_addr #1 !guid !231 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !227
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscEnaBunu62E_10algorithms(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !232 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCscEnaBunu62E_10algorithms(ptr %f) #15
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #15
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts_mut::<[(u8, u8)], (u8, u8)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSThhEBX_ECscEnaBunu62E_10algorithms(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !233 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[bool], bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSbbECscEnaBunu62E_10algorithms(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !234 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[char], char>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSccECscEnaBunu62E_10algorithms(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !235 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[f64], f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSddECscEnaBunu62E_10algorithms(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !236 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[usize], usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSjjECscEnaBunu62E_10algorithms(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !237 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[u64], u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSyyECscEnaBunu62E_10algorithms(ptr %data_pointer, i64 %metadata) unnamed_addr #1 !guid !238 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::slice::raw::from_raw_parts_mut::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutdECscEnaBunu62E_10algorithms(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #1 !guid !239 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts_mut::<f64>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutdECscEnaBunu62E_10algorithms(ptr %data, i64 %len) #15
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts_mut::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCscEnaBunu62E_10algorithms(ptr %data, i64 8, i64 8, i64 %len, ptr align 8 %0) #18
  br label %bb5
}

; core::slice::raw::from_raw_parts_mut::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutyECscEnaBunu62E_10algorithms(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #1 !guid !240 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts_mut::<u64>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutyECscEnaBunu62E_10algorithms(ptr %data, i64 %len) #15
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts_mut::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCscEnaBunu62E_10algorithms(ptr %data, i64 8, i64 8, i64 %len, ptr align 8 %0) #18
  br label %bb5
}

; core::iter::adapters::map::map_fold::<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtNtB6_6traits5accummNtB1I_3Sum3sumINtB2_3MapINtNtB4_7flatten7FlattenINtNtNtB8_5slice4iter4IterAhj8_EEBW_EE0EB10_() unnamed_addr #0 !guid !241 {
start:
  ret void
}

; core::iter::adapters::map::map_fold::<i32, u64, (), algorithms::main::{closure#0}, core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldlyuNCNvCscEnaBunu62E_10algorithms4main0NCINvNvNtNtNtB6_6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2y_3VecyE14extend_trustedINtB2_3MapINtNtNtB8_3ops5range5RangelEBV_EE0E0EBZ_(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %f, ptr align 8 %g) unnamed_addr #0 !guid !242 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %g, i64 24, i1 false)
  %0 = getelementptr inbounds i8, ptr %_0, i64 24
  store ptr %f, ptr %0, align 8
  ret void
}

; core::iter::adapters::map::map_fold::<u64, u32, u32, algorithms::collatz, core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldymmNvCscEnaBunu62E_10algorithms7collatzNCINvNvNtNtNtB6_6traits8iterator8Iterator6max_by4foldmNvYmNtNtB8_3cmp3Ord3cmpE0EBX_() unnamed_addr #0 !guid !243 {
start:
  ret void
}

; <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten::<&[u8; 8], u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvNvMsg_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB8_13FlattenCompatppE9iter_fold7flattenRAhj8_mNCINvNvXsi_B8_BT_NtNtNtBc_6traits8iterator8Iterator4fold7flattenINtNtNtBe_5slice4iter4IterhEmNCINvNtBa_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB21_5accummNtB4o_3Sum3sumINtB3g_3MapINtB8_7FlattenIB2J_B1A_EEB3C_EE0E0E0EB3G_(ptr %fold) unnamed_addr #1 !guid !244 {
start:
  ret ptr %fold
}

; core::iter::traits::iterator::Iterator::all::check::<&[u64], algorithms::main::{closure#1}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator3all5checkRSyNCNvCscEnaBunu62E_10algorithms4mains_0EB1g_() unnamed_addr #1 !guid !245 {
start:
  ret void
}

; core::iter::traits::iterator::Iterator::all::check::<(usize, &usize), algorithms::queens::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator3all5checkTjRjENCNvCscEnaBunu62E_10algorithms6queens0EB1i_(ptr align 8 %f.0, ptr align 8 %f.1) unnamed_addr #1 !guid !246 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %f.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %f.1, 1
  ret { ptr, ptr } %1
}

; core::iter::traits::iterator::Iterator::find::check::<usize, &mut algorithms::sieve::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator4find5checkjQNCNvCscEnaBunu62E_10algorithms5sieve0EB1g_(ptr align 8 %predicate) unnamed_addr #1 !guid !247 {
start:
  ret ptr %predicate
}

; core::iter::traits::iterator::Iterator::max_by::fold::<u32, <u32 as core::cmp::Ord>::cmp>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator6max_by4foldmNvYmNtNtBc_3cmp3Ord3cmpECscEnaBunu62E_10algorithms() unnamed_addr #1 !guid !248 {
start:
  ret void
}

; core::iter::traits::iterator::Iterator::for_each::call::<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1n_3VecjE14extend_trustedINtNtNtBc_3ops5range14RangeInclusivejEE0ECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %f) unnamed_addr #1 !guid !249 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %f, i64 24, i1 false)
  ret void
}

; core::iter::traits::iterator::Iterator::for_each::call::<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1n_3VecyE14extend_trustedINtNtNtBa_8adapters3map3MapINtNtNtBc_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0EB3d_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %f) unnamed_addr #1 !guid !250 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %f, i64 24, i1 false)
  ret void
}

; <core::iter::adapters::enumerate::Enumerate<_> as core::iter::traits::iterator::Iterator>::try_fold::enumerate::<&usize, (), core::ops::control_flow::ControlFlow<()>, core::iter::traits::iterator::Iterator::all::check<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters9enumerateINtB7_9EnumeratepENtNtNtBb_6traits8iterator8Iterator8try_fold9enumerateRjuINtNtNtBd_3ops12control_flow11ControlFlowuENCINvNvB1c_3all5checkTjB23_ENCNvCscEnaBunu62E_10algorithms6queens0E0EB3j_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %count, ptr align 8 %fold.0, ptr align 8 %fold.1) unnamed_addr #1 !guid !251 {
start:
  store ptr %fold.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %fold.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store ptr %count, ptr %1, align 8
  ret void
}

; <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten::<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvXsi_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB8_13FlattenCompatppENtNtNtBc_6traits8iterator8Iterator4fold7flattenINtNtNtBe_5slice4iter4IterhEmNCINvNtBa_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1l_5accummNtB3I_3Sum3sumINtB2A_3MapINtB8_7FlattenIB23_Ahj8_EEB2W_EE0E0EB30_() unnamed_addr #1 !guid !252 {
start:
  ret void
}

; <core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<u32, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal i32 @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtB8_7flatten7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0ENtNtNtBa_6traits8iterator8Iterator4foldmNCINvXsy_NtB2A_5accummNtB3j_3Sum3sumBN_E0EB1W_(ptr align 8 %self, i32 %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !253 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  %_4 = alloca [48 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %self, i64 48, i1 false)
  store i8 1, ptr %_8, align 1
; call core::iter::adapters::map::map_fold::<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtNtB6_6traits5accummNtB1I_3Sum3sumINtB2_3MapINtNtB4_7flatten7FlattenINtNtNtB8_5slice4iter4IterAhj8_EEBW_EE0EB10_()
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>> as core::iter::traits::iterator::Iterator>::fold::<u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>
  %_0 = call i32 @_RINvXs9_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB6_7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENtNtNtBa_6traits8iterator8Iterator4foldmNCINvNtB8_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1G_5accummNtB3t_3Sum3sumINtB2l_3MapBR_B2H_EE0E0EB2L_(ptr align 8 %_4, i32 %init) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_9, align 1
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB20_8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB3d_3VecyE14extend_trustedBN_E0E0EB1t_(ptr align 8 %self, ptr align 8 %g) unnamed_addr #0 personality ptr @rust_eh_personality !guid !254 {
start:
  %0 = alloca [24 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  %_6 = alloca [32 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %_4.0 = load i32, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 4
  %_4.1 = load i32, ptr %2, align 4
  store i8 1, ptr %_8, align 1
  %_7 = load ptr, ptr %self, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %g, i64 24, i1 false)
; call core::iter::adapters::map::map_fold::<i32, u64, (), algorithms::main::{closure#0}, core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldlyuNCNvCscEnaBunu62E_10algorithms4main0NCINvNvNtNtNtB6_6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2y_3VecyE14extend_trustedINtB2_3MapINtNtNtB8_3ops5range5RangelEBV_EE0E0EBZ_(ptr sret([32 x i8]) align 8 %_6, ptr align 8 %_7, ptr align 8 %0)
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::adapters::map::map_fold<i32, u64, (), algorithms::main::{closure#0}, core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangelENtNtNtNtBa_4iter6traits8iterator8Iterator4folduNCINvNtNtBR_8adapters3map8map_foldlyuNCNvCscEnaBunu62E_10algorithms4main0NCINvNvBL_8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB3f_3VecyE14extend_trustedINtB1B_3MapB3_B27_EE0E0E0EB2b_(i32 %_4.0, i32 %_4.1, ptr align 8 %_6) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_9, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::fold::<u32, core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal i32 @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtBa_6traits8iterator8Iterator4foldmNCINvNvB20_6max_by4foldmNvYmNtNtBc_3cmp3Ord3cmpE0EB1r_(i64 %self.0, i64 %self.1, i32 %init) unnamed_addr #0 personality ptr @rust_eh_personality !guid !255 {
start:
  %_9 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_9, align 1
  store i8 1, ptr %_8, align 1
; call core::iter::adapters::map::map_fold::<u64, u32, u32, algorithms::collatz, core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldymmNvCscEnaBunu62E_10algorithms7collatzNCINvNvNtNtNtB6_6traits8iterator8Iterator6max_by4foldmNvYmNtNtB8_3cmp3Ord3cmpE0EBX_()
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
  store i8 0, ptr %_8, align 1
; call <core::ops::range::Range<u64> as core::iter::traits::iterator::Iterator>::fold::<u32, core::iter::adapters::map::map_fold<u64, u32, u32, algorithms::collatz, core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>::{closure#0}>
  %_0 = call i32 @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangeyENtNtNtNtBa_4iter6traits8iterator8Iterator4foldmNCINvNtNtBR_8adapters3map8map_foldymmNvCscEnaBunu62E_10algorithms7collatzNCINvNvBL_6max_by4foldmNvYmNtNtBa_3cmp3Ord3cmpE0E0EB29_(i64 %self.0, i64 %self.1, i32 %init) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_9, align 1
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::fuse::Fuse<core::slice::iter::Iter<[u8; 8]>> as core::iter::traits::iterator::Iterator>::fold::<u32, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<&[u8; 8], u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvXs1_NtNtNtCsl10jNU3mE6R_4core4iter8adapters4fuseINtB6_4FuseINtNtNtBc_5slice4iter4IterAhj8_EENtNtNtBa_6traits8iterator8Iterator4foldmNCINvNvMsg_NtB8_7flattenINtB2l_13FlattenCompatppE9iter_fold7flattenRB1p_mNCINvNvXsi_B2l_B2y_B1w_4fold7flattenIB10_hEmNCINvNtB8_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1A_5accummNtB5g_3Sum3sumINtB48_3MapINtB2l_7FlattenBZ_EB4u_EE0E0E0E0EB4y_(ptr %0, ptr %1, i32 %2, ptr %fold) unnamed_addr #1 !guid !256 {
start:
  %_9 = alloca [1 x i8], align 1
  %acc = alloca [4 x i8], align 4
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i32 %2, ptr %acc, align 4
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %4 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb1, label %bb3

bb1:                                              ; preds = %start
  %iter.0 = load ptr, ptr %self, align 8
  %10 = getelementptr inbounds i8, ptr %self, i64 8
  %iter.1 = load ptr, ptr %10, align 8
  %_7 = load i32, ptr %acc, align 4
  store i8 0, ptr %_9, align 1
; call <core::slice::iter::Iter<[u8; 8]> as core::iter::traits::iterator::Iterator>::fold::<u32, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<&[u8; 8], u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>::{closure#0}>
  %_6 = call i32 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterAhj8_ENtNtNtNtBb_4iter6traits8iterator8Iterator4foldmNCINvNvMsg_NtNtB12_8adapters7flattenINtB1S_13FlattenCompatppE9iter_fold7flattenRBQ_mNCINvNvXsi_B1S_B2h_BW_4fold7flattenIBG_hEmNCINvNtB1U_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB10_5accummNtB4X_3Sum3sumINtB3O_3MapINtB1S_7FlattenBF_EB4b_EE0E0E0E0EB4f_(ptr %iter.0, ptr %iter.1, i32 %_7, ptr %fold) #15
  store i32 %_6, ptr %acc, align 4
  br label %bb3

bb3:                                              ; preds = %bb1, %start
  %_0 = load i32, ptr %acc, align 4
  %11 = load i8, ptr %_9, align 1
  %12 = trunc nuw i8 %11 to i1
  br i1 %12, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb3
  ret i32 %_0

bb5:                                              ; preds = %bb3
  br label %bb4

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<[u8; 8]> as core::iter::traits::iterator::Iterator>::fold::<u32, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<&[u8; 8], u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterAhj8_ENtNtNtNtBb_4iter6traits8iterator8Iterator4foldmNCINvNvMsg_NtNtB12_8adapters7flattenINtB1S_13FlattenCompatppE9iter_fold7flattenRBQ_mNCINvNvXsi_B1S_B2h_BW_4fold7flattenIBG_hEmNCINvNtB1U_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB10_5accummNtB4X_3Sum3sumINtB3O_3MapINtB1S_7FlattenBF_EB4b_EE0E0E0E0EB4f_(ptr %0, ptr %1, i32 %init, ptr %2) unnamed_addr #1 personality ptr @rust_eh_personality !guid !257 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %acc = alloca [4 x i8], align 4
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %f = alloca [8 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store ptr %2, ptr %f, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %4, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<[u8; 8]> as core::cmp::PartialEq>::eq
  %5 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAhj8_ENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %end) #15
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %7 = load i8, ptr %_4, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store i32 %init, ptr %acc, align 4
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i32 %init, ptr %_0, align 4
  br label %bb16

bb8:                                              ; preds = %bb6
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %9, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<[u8; 8]>>::offset_from_unsigned
  %10 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAhj8_E20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %_17, ptr %_18) #15
  store i64 %10, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_22 = load i32, ptr %acc, align 4
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw [8 x i8], ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten::<&[u8; 8], u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>::{closure#0}
  %_19 = call i32 @_RNCINvNvMsg_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtBa_13FlattenCompatppE9iter_fold7flattenRAhj8_mNCINvNvXsi_Ba_BV_NtNtNtBe_6traits8iterator8Iterator4fold7flattenINtNtNtBg_5slice4iter4IterhEmNCINvNtBc_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB23_5accummNtB4q_3Sum3sumINtB3i_3MapINtBa_7FlattenIB2L_B1C_EEB3E_EE0E0E0E0B3I_(ptr align 8 %f, i32 %_22, ptr %_3.i) #15
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  store i32 %_19, ptr %acc, align 4
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCscEnaBunu62E_10algorithms(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #18
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  %11 = load i32, ptr %acc, align 4
  store i32 %11, ptr %_0, align 4
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  %12 = load i32, ptr %_0, align 4
  ret i32 %12

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::fold::<u32, algorithms::fnv::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator4foldmNCNvCscEnaBunu62E_10algorithms3fnv0EB1H_(ptr %0, ptr %1, i32 %init) unnamed_addr #1 personality ptr @rust_eh_personality !guid !258 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %acc = alloca [4 x i8], align 4
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %f = alloca [0 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %3, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
  %4 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqB9_(ptr align 8 %self, ptr align 8 %end) #15
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %6 = load i8, ptr %_4, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store i32 %init, ptr %acc, align 4
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i32 %init, ptr %_0, align 4
  br label %bb16

bb8:                                              ; preds = %bb6
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %8, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %9 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedB9_(ptr %_17, ptr %_18) #15
  store i64 %9, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_22 = load i32, ptr %acc, align 4
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw i8, ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call algorithms::fnv::{closure#0}
  %_19 = call i32 @_RNCNvCscEnaBunu62E_10algorithms3fnv0B3_(ptr %f, i32 %_22, ptr %_3.i) #15
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  store i32 %_19, ptr %acc, align 4
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCscEnaBunu62E_10algorithms(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #18
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  %10 = load i32, ptr %acc, align 4
  store i32 %10, ptr %_0, align 4
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  %11 = load i32, ptr %_0, align 4
  ret i32 %11

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::fold::<u32, &mut core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator4foldmQNCINvNtNtBY_8adapters3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtBW_5accummNtB32_3Sum3sumINtB1J_3MapINtNtB1L_7flatten7FlattenIBG_Ahj8_EEB2g_EE0E0EB2k_(ptr %0, ptr %1, i32 %init, ptr %2) unnamed_addr #1 personality ptr @rust_eh_personality !guid !259 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %acc = alloca [4 x i8], align 4
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %f = alloca [8 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store ptr %2, ptr %f, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %4, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
  %5 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqB9_(ptr align 8 %self, ptr align 8 %end) #15
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %7 = load i8, ptr %_4, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store i32 %init, ptr %acc, align 4
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i32 %init, ptr %_0, align 4
  br label %bb16

bb8:                                              ; preds = %bb6
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %9, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %10 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedB9_(ptr %_17, ptr %_18) #15
  store i64 %10, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_22 = load i32, ptr %acc, align 4
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw i8, ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call <&mut core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(u32, &u8)>>::call_mut
  %_19 = call i32 @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core3ops8function5implsQNCINvNtNtNtBb_4iter8adapters3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtNtBX_6traits5accummNtB2j_3Sum3sumINtBT_3MapINtNtBV_7flatten7FlattenINtNtNtBb_5slice4iter4IterAhj8_EEB1x_EE0E0INtB7_5FnMutTmB1t_EE8call_mutB1B_(ptr align 8 %f, i32 %_22, ptr %_3.i)
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  store i32 %_19, ptr %acc, align 4
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCscEnaBunu62E_10algorithms(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #18
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  %11 = load i32, ptr %acc, align 4
  store i32 %11, ptr %_0, align 4
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  %12 = load i32, ptr %_0, align 4
  ret i32 %12

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u64> as core::iter::traits::iterator::Iterator>::fold::<u64, <u64 as core::iter::traits::accum::Sum<&u64>>::sum<core::slice::iter::Iter<u64>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IteryENtNtNtNtBb_4iter6traits8iterator8Iterator4foldyNCINvXsE_NtBW_5accumyINtB1M_3SumRyE3sumBF_E0ECscEnaBunu62E_10algorithms(ptr %0, ptr %1, i64 %init) unnamed_addr #1 personality ptr @rust_eh_personality !guid !260 {
start:
  %_35 = alloca [1 x i8], align 1
  %_34 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %len = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %acc = alloca [8 x i8], align 8
  %end = alloca [8 x i8], align 8
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %f = alloca [0 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_35, align 1
  store i8 0, ptr %_34, align 1
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_35, align 1
  br label %bb3

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %_8 = load ptr, ptr %3, align 8
  store ptr %_8, ptr %end, align 8
; call <core::ptr::non_null::NonNull<u64> as core::cmp::PartialEq>::eq
  %4 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyENtNtB9_3cmp9PartialEq2eqCs2d0hS33vDhg_5gimli(ptr align 8 %self, ptr align 8 %end) #15
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_4, align 1
  br label %bb25

bb25:                                             ; preds = %bb3
  br label %bb4

bb4:                                              ; preds = %bb25
  %6 = load i8, ptr %_4, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb5, label %bb6

bb6:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i8 1, ptr %_34, align 1
  store i64 %init, ptr %acc, align 8
  store i64 0, ptr %i, align 8
  br label %bb8

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_35, align 1
  store i64 %init, ptr %_0, align 8
  br label %bb16

bb8:                                              ; preds = %bb6
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_17 = load ptr, ptr %8, align 8
  %_18 = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u64>>::offset_from_unsigned
  %9 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %_17, ptr %_18) #15
  store i64 %9, ptr %len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8
  br label %bb10

bb10:                                             ; preds = %bb14, %bb26
  store i8 0, ptr %_34, align 1
  store i8 1, ptr %_33, align 1
  %_22 = load i64, ptr %acc, align 8
  %_26 = load ptr, ptr %self, align 8
  %_27 = load i64, ptr %i, align 8
  %_3.i = getelementptr inbounds nuw i64, ptr %_26, i64 %_27
  br label %bb11

bb11:                                             ; preds = %bb10
  br label %bb12

bb12:                                             ; preds = %bb11
  store i8 0, ptr %_33, align 1
; call <u64 as core::iter::traits::accum::Sum<&u64>>::sum::<core::slice::iter::Iter<u64>>::{closure#0}
  %_19 = call i64 @_RNCINvXsE_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumyINtB8_3SumRyE3sumINtNtNtBe_5slice4iter4IteryEE0CscEnaBunu62E_10algorithms(ptr %f, i64 %_22, ptr align 8 %_3.i) #15
  br label %bb13

bb13:                                             ; preds = %bb12
  store i8 0, ptr %_33, align 1
  store i8 1, ptr %_34, align 1
  store i64 %_19, ptr %acc, align 8
  %_29 = load i64, ptr %i, align 8
; call core::ub_checks::check_language_ub
  %_3.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_3.i1, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %bb13
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCscEnaBunu62E_10algorithms(i64 %_29, i64 1, ptr align 8 @alloc_5bb642ca6df5ad9ba078972a9d3a5201) #18
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %bb13, %bb2.i
  %_0.i = add nuw i64 %_29, 1
  br label %bb14

bb14:                                             ; preds = %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit
  store i64 %_0.i, ptr %i, align 8
  %_31 = load i64, ptr %i, align 8
  %_32 = load i64, ptr %len, align 8
  %_30 = icmp eq i64 %_31, %_32
  br i1 %_30, label %bb15, label %bb10

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_34, align 1
  %10 = load i64, ptr %acc, align 8
  store i64 %10, ptr %_0, align 8
  store i8 0, ptr %_34, align 1
  br label %bb16

bb16:                                             ; preds = %bb5, %bb15
  %11 = load i64, ptr %_0, align 8
  ret i64 %11

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb17:                                             ; No predecessors!
  unreachable

bb18:                                             ; No predecessors!
  unreachable

bb19:                                             ; No predecessors!
  unreachable

bb20:                                             ; No predecessors!
  unreachable

bb21:                                             ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb23:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable
}

; <core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>> as core::iter::traits::iterator::Iterator>::fold::<u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvXs9_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB6_7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENtNtNtBa_6traits8iterator8Iterator4foldmNCINvNtB8_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1G_5accummNtB3t_3Sum3sumINtB2l_3MapBR_B2H_EE0E0EB2L_(ptr align 8 %self, i32 %init) unnamed_addr #1 !guid !261 {
start:
  %_4 = alloca [48 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %self, i64 48, i1 false)
; call <core::iter::adapters::flatten::FlattenCompat<core::slice::iter::Iter<[u8; 8]>, core::slice::iter::Iter<u8>> as core::iter::traits::iterator::Iterator>::fold::<u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>
  %_0 = call i32 @_RINvXsi_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB6_13FlattenCompatINtNtNtBc_5slice4iter4IterAhj8_EIB1d_hEENtNtNtBa_6traits8iterator8Iterator4foldmNCINvNtB8_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1U_5accummNtB3H_3Sum3sumINtB2z_3MapINtB6_7FlattenB1c_EB2V_EE0E0EB2Z_(ptr align 8 %_4, i32 %init) #15
  ret i32 %_0
}

; <u64 as core::iter::traits::accum::Sum<&u64>>::sum::<core::slice::iter::Iter<u64>>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvXsE_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumyINtB6_3SumRyE3sumINtNtNtBc_5slice4iter4IteryEECscEnaBunu62E_10algorithms(ptr %iter.0, ptr %iter.1) unnamed_addr #0 !guid !262 {
start:
; call <core::slice::iter::Iter<u64> as core::iter::traits::iterator::Iterator>::fold::<u64, <u64 as core::iter::traits::accum::Sum<&u64>>::sum<core::slice::iter::Iter<u64>>::{closure#0}>
  %_0 = call i64 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IteryENtNtNtNtBb_4iter6traits8iterator8Iterator4foldyNCINvXsE_NtBW_5accumyINtB1M_3SumRyE3sumBF_E0ECscEnaBunu62E_10algorithms(ptr %iter.0, ptr %iter.1, i64 0) #15
  ret i64 %_0
}

; <bool as alloc::vec::spec_from_elem::SpecFromElem>::from_elem::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs_NtNtCs7CppTae75M1_5alloc3vec14spec_from_elembNtB5_12SpecFromElem9from_elemNtNtB9_5alloc6GlobalECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i1 zeroext %0, i64 %n) unnamed_addr #1 personality ptr @rust_eh_personality !guid !263 {
start:
  %1 = alloca [16 x i8], align 8
  %_14 = alloca [1 x i8], align 1
  %_13 = alloca [1 x i8], align 1
  %v = alloca [24 x i8], align 8
  %elem = alloca [1 x i8], align 1
  %2 = zext i1 %0 to i8
  store i8 %2, ptr %elem, align 1
  store i8 0, ptr %_14, align 1
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_14, align 1
  store i8 1, ptr %_13, align 1
; call <bool as alloc::vec::is_zero::IsZero>::is_zero
  %_4 = call zeroext i1 @_RNvXsh_NtNtCs7CppTae75M1_5alloc3vec7is_zerobNtB5_6IsZero7is_zeroCscEnaBunu62E_10algorithms(ptr %elem) #15
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  store i8 0, ptr %_13, align 1
; call <alloc::vec::Vec<bool>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbE16with_capacity_inCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %v, i64 %n) #15
  br label %bb5

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_13, align 1
; call <alloc::raw_vec::RawVec<bool>>::with_capacity_zeroed_in
  %3 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbE23with_capacity_zeroed_inCscEnaBunu62E_10algorithms(i64 %n) #15
  %_6.0 = extractvalue { i64, ptr } %3, 0
  %_6.1 = extractvalue { i64, ptr } %3, 1
  br label %bb3

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_14, align 1
  %4 = load i8, ptr %elem, align 1
  %_12 = trunc nuw i8 %4 to i1
; invoke <alloc::vec::Vec<bool>>::extend_with
  invoke void @_RNvMs4_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbE11extend_withCscEnaBunu62E_10algorithms(ptr align 8 %v, i64 %n, i1 zeroext %_12)
          to label %bb6 unwind label %cleanup

bb8:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<bool>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecbEECscEnaBunu62E_10algorithms(ptr align 8 %v) #16
          to label %bb12 unwind label %terminate

cleanup:                                          ; preds = %bb5
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %1, align 8
  %8 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %v, i64 24, i1 false)
  br label %bb7

bb7:                                              ; preds = %bb3, %bb6
  ret void

terminate:                                        ; preds = %bb8
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb12:                                             ; preds = %bb8
  %10 = load i8, ptr %_13, align 1
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %bb11, label %bb9

bb3:                                              ; preds = %bb2
  store i64 %_6.0, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_6.1, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %n, ptr %13, align 8
  br label %bb7

bb9:                                              ; preds = %bb11, %bb12
  %14 = load i8, ptr %_14, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb13, label %bb10

bb11:                                             ; preds = %bb12
  br label %bb9

bb10:                                             ; preds = %bb13, %bb9
  %16 = load ptr, ptr %1, align 8
  %17 = getelementptr inbounds i8, ptr %1, i64 8
  %18 = load i32, ptr %17, align 8
  %19 = insertvalue { ptr, i32 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i32 } %19, i32 %18, 1
  resume { ptr, i32 } %20

bb13:                                             ; preds = %bb9
  br label %bb10
}

; <core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<usize>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::all::check<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters9enumerateINtB5_9EnumerateINtNtNtBb_5slice4iter4IterjEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1B_3all5checkTjRjENCNvCscEnaBunu62E_10algorithms6queens0E0INtNtNtBb_3ops12control_flow11ControlFlowuEEB2N_(ptr align 8 %self, ptr align 8 %fold.0, ptr align 8 %fold.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !264 {
start:
  %_8 = alloca [1 x i8], align 1
  %_6 = alloca [24 x i8], align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_7 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::iter::adapters::enumerate::Enumerate<_> as core::iter::traits::iterator::Iterator>::try_fold::enumerate::<&usize, (), core::ops::control_flow::ControlFlow<()>, core::iter::traits::iterator::Iterator::all::check<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}>
  call void @_RINvNvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters9enumerateINtB7_9EnumeratepENtNtNtBb_6traits8iterator8Iterator8try_fold9enumerateRjuINtNtNtBd_3ops12control_flow11ControlFlowuENCINvNvB1c_3all5checkTjB23_ENCNvCscEnaBunu62E_10algorithms6queens0E0EB3j_(ptr sret([24 x i8]) align 8 %_6, ptr align 8 %_7, ptr align 8 %fold.0, ptr align 8 %fold.1) #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_8, align 1
; call <core::slice::iter::Iter<usize> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::enumerate::Enumerate<_> as core::iter::traits::iterator::Iterator>::try_fold::enumerate<&usize, (), core::ops::control_flow::ControlFlow<()>, core::iter::traits::iterator::Iterator::all::check<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>
  %_0 = call zeroext i1 @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterjENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvXs_NtNtBR_8adapters9enumerateINtB1K_9EnumeratepEBL_8try_fold9enumerateRjuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkTjB2P_ENCNvCscEnaBunu62E_10algorithms6queens0E0E0B2S_EB44_(ptr align 8 %self, ptr align 8 %_6) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  ret i1 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<usize> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<(), <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<()>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtB6_26RangeInclusiveIteratorImpl13spec_try_folduNCINvMNtBJ_9try_traitINtB29_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB47_3VecjE14extend_trustedBE_E0E0E0B2o_ECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !265 {
start:
  %0 = alloca [16 x i8], align 8
  %_37 = alloca [1 x i8], align 1
  %_36 = alloca [1 x i8], align 1
  %_26 = alloca [0 x i8], align 1
  %_15 = alloca [0 x i8], align 1
  store i8 0, ptr %_37, align 1
  store i8 0, ptr %_36, align 1
  store i8 1, ptr %_37, align 1
; invoke <core::ops::range::RangeInclusive<usize>>::is_empty
  %_4 = invoke zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivejE8is_emptyCs2d0hS33vDhg_5gimli(ptr align 8 %self)
          to label %bb1 unwind label %cleanup

bb26:                                             ; preds = %bb28, %bb29, %cleanup
; invoke core::ptr::drop_glue::<<core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMNtNtB4_3ops9try_traitINtBH_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2R_3VecjE14extend_trustedINtNtBJ_5range14RangeInclusivejEE0E0E0ECscEnaBunu62E_10algorithms(ptr align 8 %f) #16
          to label %bb31 unwind label %terminate

cleanup:                                          ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb26

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
  store i8 1, ptr %_36, align 1
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
; invoke <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::from_output
  invoke void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try11from_outputCs7CppTae75M1_5alloc()
          to label %bb32 unwind label %cleanup

bb4:                                              ; preds = %bb12, %bb3
  %_10 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.i = load i64, ptr %self, align 8
  %_4.i = load i64, ptr %_10, align 8
  %_0.i = icmp ult i64 %_3.i, %_4.i
  br label %bb5

bb29:                                             ; preds = %cleanup1
  %5 = load i8, ptr %_36, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb28, label %bb26

cleanup1:                                         ; preds = %bb13, %bb9, %bb8, %bb7, %bb6, %bb20, %bb21, %bb17, %bb16, %bb14
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb29

bb5:                                              ; preds = %bb4
  br i1 %_0.i, label %bb6, label %bb14

bb14:                                             ; preds = %bb5
  %11 = getelementptr inbounds i8, ptr %self, i64 16
  store i8 1, ptr %11, align 8
  %_25 = getelementptr inbounds i8, ptr %self, i64 8
; invoke <usize as core::cmp::PartialEq>::eq
  %_23 = invoke zeroext i1 @_RNvXsj_NtNtCsl10jNU3mE6R_4core3cmp5implsjNtB7_9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %_25)
          to label %bb15 unwind label %cleanup1

bb6:                                              ; preds = %bb5
  %_12 = load i64, ptr %self, align 8
; invoke <usize as core::iter::range::Step>::forward_unchecked
  %n = invoke i64 @_RNvXsL_NtNtCsl10jNU3mE6R_4core4iter5rangejNtB5_4Step17forward_uncheckedCscEnaBunu62E_10algorithms(i64 %_12, i64 1)
          to label %bb7 unwind label %cleanup1

bb15:                                             ; preds = %bb14
  br i1 %_23, label %bb16, label %bb21

bb21:                                             ; preds = %bb19, %bb15
  store i8 0, ptr %_36, align 1
; invoke <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::from_output
  invoke void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try11from_outputCs7CppTae75M1_5alloc()
          to label %bb22 unwind label %cleanup1

bb16:                                             ; preds = %bb15
  store i8 0, ptr %_36, align 1
  %_31 = load i64, ptr %self, align 8
; invoke <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}
  invoke void @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtNtB9_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2v_3VecjE14extend_trustedINtNtB7_5range14RangeInclusivejEE0E0E0CscEnaBunu62E_10algorithms(ptr align 8 %f, i64 %_31)
          to label %bb17 unwind label %cleanup1

bb17:                                             ; preds = %bb16
; invoke <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::branch
  invoke void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try6branchCs7CppTae75M1_5alloc()
          to label %bb18 unwind label %cleanup1

bb18:                                             ; preds = %bb17
  br label %bb19

bb19:                                             ; preds = %bb18
  store i8 1, ptr %_36, align 1
  br label %bb21

bb22:                                             ; preds = %bb21
  store i8 0, ptr %_36, align 1
; call core::ptr::drop_glue::<<core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMNtNtB4_3ops9try_traitINtBH_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2R_3VecjE14extend_trustedINtNtBJ_5range14RangeInclusivejEE0E0E0ECscEnaBunu62E_10algorithms(ptr align 8 %f)
  br label %bb25

bb25:                                             ; preds = %bb24, %bb22
  ret void

bb20:                                             ; No predecessors!
; invoke <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
  invoke void @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCs7CppTae75M1_5alloc()
          to label %bb34 unwind label %cleanup1

bb34:                                             ; preds = %bb20
  br label %bb23

bb23:                                             ; preds = %bb33, %bb34
  store i8 0, ptr %_36, align 1
  br label %bb24

bb7:                                              ; preds = %bb6
; invoke core::mem::replace::<usize>
  %n2 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core3mem7replacejECs2d0hS33vDhg_5gimli(ptr align 8 %self, i64 %n)
          to label %bb8 unwind label %cleanup1

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_36, align 1
; invoke <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}
  invoke void @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtNtB9_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2v_3VecjE14extend_trustedINtNtB7_5range14RangeInclusivejEE0E0E0CscEnaBunu62E_10algorithms(ptr align 8 %f, i64 %n2)
          to label %bb9 unwind label %cleanup1

bb9:                                              ; preds = %bb8
; invoke <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::branch
  invoke void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try6branchCs7CppTae75M1_5alloc()
          to label %bb10 unwind label %cleanup1

bb10:                                             ; preds = %bb9
  br label %bb12

bb12:                                             ; preds = %bb10
  store i8 1, ptr %_36, align 1
  br label %bb4

bb13:                                             ; No predecessors!
; invoke <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
  invoke void @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCs7CppTae75M1_5alloc()
          to label %bb33 unwind label %cleanup1

bb33:                                             ; preds = %bb13
  br label %bb23

bb24:                                             ; preds = %bb32, %bb23
; call core::ptr::drop_glue::<<core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvMNtNtB4_3ops9try_traitINtBH_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtNtB4_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2R_3VecjE14extend_trustedINtNtBJ_5range14RangeInclusivejEE0E0E0ECscEnaBunu62E_10algorithms(ptr align 8 %f)
  br label %bb25

bb11:                                             ; No predecessors!
  unreachable

bb28:                                             ; preds = %bb29
  br label %bb26

bb32:                                             ; preds = %bb2
  br label %bb24

terminate:                                        ; preds = %bb26
  %12 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb31:                                             ; preds = %bb26
  %13 = load i8, ptr %_37, align 1
  %14 = trunc nuw i8 %13 to i1
  br i1 %14, label %bb30, label %bb27

bb27:                                             ; preds = %bb30, %bb31
  %15 = load ptr, ptr %0, align 8
  %16 = getelementptr inbounds i8, ptr %0, i64 8
  %17 = load i32, ptr %16, align 8
  %18 = insertvalue { ptr, i32 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i32 } %18, i32 %17, 1
  resume { ptr, i32 } %19

bb30:                                             ; preds = %bb31
  br label %bb27
}

; <core::ops::range::RangeInclusive<usize> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<(), core::iter::traits::iterator::Iterator::find::check<usize, &mut algorithms::sieve::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtB6_26RangeInclusiveIteratorImpl13spec_try_folduNCINvNvNtNtNtB8_6traits8iterator8Iterator4find5checkjQNCNvCscEnaBunu62E_10algorithms5sieve0E0INtNtBJ_12control_flow11ControlFlowjEEB2Z_(ptr align 8 %self, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !266 {
start:
  %_37 = alloca [1 x i8], align 1
  %_36 = alloca [1 x i8], align 1
  %_26 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %f = alloca [8 x i8], align 8
  store ptr %0, ptr %f, align 8
  store i8 0, ptr %_37, align 1
  store i8 0, ptr %_36, align 1
  store i8 1, ptr %_37, align 1
; call <core::ops::range::RangeInclusive<usize>>::is_empty
  %_4 = call zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivejE8is_emptyCs2d0hS33vDhg_5gimli(ptr align 8 %self) #15
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
  store i8 1, ptr %_36, align 1
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_37, align 1
; call <core::ops::control_flow::ControlFlow<usize> as core::ops::try_trait::Try>::from_output
  %1 = call { i64, i64 } @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowjENtNtB4_9try_trait3Try11from_outputCsddYV2PBJW9h_3std() #15
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %3, ptr %4, align 8
  br label %bb32

bb4:                                              ; preds = %bb12, %bb3
  %_10 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.i = load i64, ptr %self, align 8
  %_4.i = load i64, ptr %_10, align 8
  %_0.i = icmp ult i64 %_3.i, %_4.i
  br label %bb5

bb5:                                              ; preds = %bb4
  br i1 %_0.i, label %bb6, label %bb14

bb14:                                             ; preds = %bb5
  %5 = getelementptr inbounds i8, ptr %self, i64 16
  store i8 1, ptr %5, align 8
  %_25 = getelementptr inbounds i8, ptr %self, i64 8
; call <usize as core::cmp::PartialEq>::eq
  %_23 = call zeroext i1 @_RNvXsj_NtNtCsl10jNU3mE6R_4core3cmp5implsjNtB7_9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %_25) #15
  br label %bb15

bb6:                                              ; preds = %bb5
  %_12 = load i64, ptr %self, align 8
; call <usize as core::iter::range::Step>::forward_unchecked
  %n = call i64 @_RNvXsL_NtNtCsl10jNU3mE6R_4core4iter5rangejNtB5_4Step17forward_uncheckedCscEnaBunu62E_10algorithms(i64 %_12, i64 1) #15
  br label %bb7

bb15:                                             ; preds = %bb14
  br i1 %_23, label %bb16, label %bb21

bb21:                                             ; preds = %bb19, %bb15
  store i8 0, ptr %_36, align 1
; call <core::ops::control_flow::ControlFlow<usize> as core::ops::try_trait::Try>::from_output
  %6 = call { i64, i64 } @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowjENtNtB4_9try_trait3Try11from_outputCsddYV2PBJW9h_3std() #15
  %7 = extractvalue { i64, i64 } %6, 0
  %8 = extractvalue { i64, i64 } %6, 1
  store i64 %7, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %8, ptr %9, align 8
  br label %bb22

bb16:                                             ; preds = %bb15
  store i8 0, ptr %_36, align 1
  %_31 = load i64, ptr %self, align 8
; call core::iter::traits::iterator::Iterator::find::check::<usize, &mut algorithms::sieve::{closure#0}>::{closure#0}
  %10 = call { i64, i64 } @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator4find5checkjQNCNvCscEnaBunu62E_10algorithms5sieve0E0B1i_(ptr align 8 %f, i64 %_31) #15
  %_27.0 = extractvalue { i64, i64 } %10, 0
  %_27.1 = extractvalue { i64, i64 } %10, 1
  br label %bb17

bb17:                                             ; preds = %bb16
; call <core::ops::control_flow::ControlFlow<usize> as core::ops::try_trait::Try>::branch
  %11 = call { i64, i64 } @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowjENtNtB4_9try_trait3Try6branchCsddYV2PBJW9h_3std(i64 %_27.0, i64 %_27.1) #15
  %12 = extractvalue { i64, i64 } %11, 0
  %13 = extractvalue { i64, i64 } %11, 1
  store i64 %12, ptr %_26, align 8
  %14 = getelementptr inbounds i8, ptr %_26, i64 8
  store i64 %13, ptr %14, align 8
  br label %bb18

bb18:                                             ; preds = %bb17
  %_32 = load i64, ptr %_26, align 8
  %15 = getelementptr inbounds i8, ptr %_26, i64 8
  %16 = load i64, ptr %15, align 8
  %17 = trunc nuw i64 %_32 to i1
  br i1 %17, label %bb20, label %bb19

bb20:                                             ; preds = %bb18
  %18 = getelementptr inbounds i8, ptr %_26, i64 8
  %residual = load i64, ptr %18, align 8
; call <core::ops::control_flow::ControlFlow<usize> as core::ops::try_trait::FromResidual<core::ops::control_flow::ControlFlow<usize, core::convert::Infallible>>>::from_residual
  %19 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB4_11ControlFlowjEINtNtB6_9try_trait12FromResidualIBK_jNtNtB8_7convert10InfallibleEE13from_residualCsddYV2PBJW9h_3std(i64 %residual) #15
  %20 = extractvalue { i64, i64 } %19, 0
  %21 = extractvalue { i64, i64 } %19, 1
  store i64 %20, ptr %_0, align 8
  %22 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %21, ptr %22, align 8
  br label %bb34

bb19:                                             ; preds = %bb18
  store i8 1, ptr %_36, align 1
  br label %bb21

bb22:                                             ; preds = %bb21
  store i8 0, ptr %_36, align 1
  br label %bb25

bb25:                                             ; preds = %bb24, %bb22
  %23 = load i64, ptr %_0, align 8
  %24 = getelementptr inbounds i8, ptr %_0, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { i64, i64 } poison, i64 %23, 0
  %27 = insertvalue { i64, i64 } %26, i64 %25, 1
  ret { i64, i64 } %27

bb34:                                             ; preds = %bb20
  br label %bb23

bb23:                                             ; preds = %bb33, %bb34
  store i8 0, ptr %_36, align 1
  br label %bb24

bb7:                                              ; preds = %bb6
; call core::mem::replace::<usize>
  %n1 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem7replacejECs2d0hS33vDhg_5gimli(ptr align 8 %self, i64 %n) #15
  br label %bb8

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_36, align 1
; call core::iter::traits::iterator::Iterator::find::check::<usize, &mut algorithms::sieve::{closure#0}>::{closure#0}
  %28 = call { i64, i64 } @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator4find5checkjQNCNvCscEnaBunu62E_10algorithms5sieve0E0B1i_(ptr align 8 %f, i64 %n1) #15
  %_16.0 = extractvalue { i64, i64 } %28, 0
  %_16.1 = extractvalue { i64, i64 } %28, 1
  br label %bb9

bb9:                                              ; preds = %bb8
; call <core::ops::control_flow::ControlFlow<usize> as core::ops::try_trait::Try>::branch
  %29 = call { i64, i64 } @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowjENtNtB4_9try_trait3Try6branchCsddYV2PBJW9h_3std(i64 %_16.0, i64 %_16.1) #15
  %30 = extractvalue { i64, i64 } %29, 0
  %31 = extractvalue { i64, i64 } %29, 1
  store i64 %30, ptr %_15, align 8
  %32 = getelementptr inbounds i8, ptr %_15, i64 8
  store i64 %31, ptr %32, align 8
  br label %bb10

bb10:                                             ; preds = %bb9
  %_20 = load i64, ptr %_15, align 8
  %33 = getelementptr inbounds i8, ptr %_15, i64 8
  %34 = load i64, ptr %33, align 8
  %35 = trunc nuw i64 %_20 to i1
  br i1 %35, label %bb13, label %bb12

bb13:                                             ; preds = %bb10
  %36 = getelementptr inbounds i8, ptr %_15, i64 8
  %residual2 = load i64, ptr %36, align 8
; call <core::ops::control_flow::ControlFlow<usize> as core::ops::try_trait::FromResidual<core::ops::control_flow::ControlFlow<usize, core::convert::Infallible>>>::from_residual
  %37 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB4_11ControlFlowjEINtNtB6_9try_trait12FromResidualIBK_jNtNtB8_7convert10InfallibleEE13from_residualCsddYV2PBJW9h_3std(i64 %residual2) #15
  %38 = extractvalue { i64, i64 } %37, 0
  %39 = extractvalue { i64, i64 } %37, 1
  store i64 %38, ptr %_0, align 8
  %40 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %39, ptr %40, align 8
  br label %bb33

bb12:                                             ; preds = %bb10
  store i8 1, ptr %_36, align 1
  br label %bb4

bb33:                                             ; preds = %bb13
  br label %bb23

bb24:                                             ; preds = %bb32, %bb23
  br label %bb25

bb11:                                             ; No predecessors!
  unreachable

bb32:                                             ; preds = %bb2
  br label %bb24

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable

bb28:                                             ; No predecessors!
  unreachable

bb29:                                             ; No predecessors!
  unreachable

bb30:                                             ; No predecessors!
  unreachable

bb31:                                             ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtNtNtB8_6traits8iterator8Iterator4folduNCINvNvB1g_8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2t_3VecjE14extend_trustedBE_E0E0ECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %fold) unnamed_addr #1 personality ptr @rust_eh_personality !guid !267 {
start:
  %0 = alloca [24 x i8], align 8
  %_8 = alloca [1 x i8], align 1
  %_7 = alloca [24 x i8], align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %fold, i64 24, i1 false)
; call <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB3_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtNtB7_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2t_3VecjE14extend_trustedINtNtB5_5range14RangeInclusivejEE0E0ECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_7, ptr align 8 %0) #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_8, align 1
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<()>>
  call void @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvMNtBJ_9try_traitINtB24_17NeverShortCircuituE10wrap_mut_2ujNCINvNvB1g_8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB3y_3VecjE14extend_trustedBE_E0E0E0B2j_ECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %_7) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<()>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvMNtBJ_9try_traitINtB24_17NeverShortCircuituE10wrap_mut_2ujNCINvNvB1g_8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB3y_3VecjE14extend_trustedBE_E0E0E0B2j_ECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !268 {
start:
  %0 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %f, i64 24, i1 false)
; call <core::ops::range::RangeInclusive<usize> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<(), <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::try_trait::NeverShortCircuit<()>>
  call void @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtB6_26RangeInclusiveIteratorImpl13spec_try_folduNCINvMNtBJ_9try_traitINtB29_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB47_3VecjE14extend_trustedBE_E0E0E0B2o_ECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %0) #15
  ret void
}

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find::check<usize, &mut algorithms::sieve::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB1g_4find5checkjQNCNvCscEnaBunu62E_10algorithms5sieve0E0INtNtBJ_12control_flow11ControlFlowjEEB2q_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !269 {
start:
; call <core::ops::range::RangeInclusive<usize> as core::iter::range::RangeInclusiveIteratorImpl>::spec_try_fold::<(), core::iter::traits::iterator::Iterator::find::check<usize, &mut algorithms::sieve::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<usize>>
  %0 = call { i64, i64 } @_RINvXsc_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtB6_26RangeInclusiveIteratorImpl13spec_try_folduNCINvNvNtNtNtB8_6traits8iterator8Iterator4find5checkjQNCNvCscEnaBunu62E_10algorithms5sieve0E0INtNtBJ_12control_flow11ControlFlowjEEB2Z_(ptr align 8 %self, ptr align 8 %f) #15
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <alloc::vec::Vec<char> as core::iter::traits::collect::FromIterator<char>>::from_iter::<core::str::iter::Chars>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VeccEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorcE9from_iterNtNtNtBR_3str4iter5CharsECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !270 {
start:
; call <core::str::iter::Chars as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectNtNtNtB8_3str4iter5CharsNtB2_12IntoIterator9into_iterB8_(ptr %iter.0, ptr %iter.1) #15
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call <alloc::vec::Vec<char> as alloc::vec::spec_from_iter::SpecFromIter<char, core::str::iter::Chars>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VeccEINtB2_12SpecFromItercNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE9from_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, ptr %_2.1)
  ret void
}

; <alloc::vec::Vec<usize> as core::iter::traits::collect::FromIterator<usize>>::from_iter::<core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorjE9from_iterINtNtNtBP_8adapters6filter6FilterINtNtNtBR_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EEB37_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %iter) unnamed_addr #1 !guid !271 {
start:
  %0 = alloca [32 x i8], align 8
  %_2 = alloca [32 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iter, i64 32, i1 false)
; call <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters6filter6FilterINtNtNtB8_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtB2_12IntoIterator9into_iterB1Y_(ptr sret([32 x i8]) align 8 %_2, ptr align 8 %0) #15
; call <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter::SpecFromIter<usize, core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecjEINtB2_12SpecFromIterjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtB1q_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EE9from_iterB2S_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2)
  ret void
}

; <alloc::vec::Vec<usize> as core::iter::traits::collect::FromIterator<usize>>::from_iter::<core::ops::range::RangeInclusive<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorjE9from_iterINtNtNtBR_3ops5range14RangeInclusivejEECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %iter) unnamed_addr #1 !guid !272 {
start:
  %0 = alloca [24 x i8], align 8
  %_2 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iter, i64 24, i1 false)
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range14RangeInclusivejENtB2_12IntoIterator9into_iterCs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_2, ptr align 8 %0) #15
; call <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter::SpecFromIter<usize, core::ops::range::RangeInclusive<usize>>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecjEINtB2_12SpecFromIterjINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEE9from_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2)
  ret void
}

; <alloc::vec::Vec<u64> as core::iter::traits::collect::FromIterator<u64>>::from_iter::<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecyEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratoryE9from_iterINtNtNtBP_8adapters3map3MapINtNtNtBR_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EEB2R_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %iter) unnamed_addr #1 !guid !273 {
start:
  %0 = alloca [16 x i8], align 8
  %_2 = alloca [16 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iter, i64 16, i1 false)
; call <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters3map3MapINtNtNtB8_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtB2_12IntoIterator9into_iterB1I_(ptr sret([16 x i8]) align 8 %_2, ptr align 8 %0) #15
; call <alloc::vec::Vec<u64> as alloc::vec::spec_from_iter::SpecFromIter<u64, core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecyEINtB2_12SpecFromIteryINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1q_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE9from_iterB2C_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2)
  ret void
}

; <core::iter::adapters::flatten::FlattenCompat<core::slice::iter::Iter<[u8; 8]>, core::slice::iter::Iter<u8>> as core::iter::traits::iterator::Iterator>::fold::<u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvXsi_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB6_13FlattenCompatINtNtNtBc_5slice4iter4IterAhj8_EIB1d_hEENtNtNtBa_6traits8iterator8Iterator4foldmNCINvNtB8_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1U_5accummNtB3H_3Sum3sumINtB2z_3MapINtB6_7FlattenB1c_EB2V_EE0E0EB2Z_(ptr align 8 %self, i32 %init) unnamed_addr #1 personality ptr @rust_eh_personality !guid !274 {
start:
  %_8 = alloca [1 x i8], align 1
  %_7 = alloca [1 x i8], align 1
  %_4 = alloca [48 x i8], align 8
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_8, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %self, i64 48, i1 false)
  store i8 1, ptr %_7, align 1
; call <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten::<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>
  call void @_RINvNvXsi_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB8_13FlattenCompatppENtNtNtBc_6traits8iterator8Iterator4fold7flattenINtNtNtBe_5slice4iter4IterhEmNCINvNtBa_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1l_5accummNtB3I_3Sum3sumINtB2A_3MapINtB8_7FlattenIB23_Ahj8_EEB2W_EE0E0EB30_() #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_7, align 1
; call <core::iter::adapters::flatten::FlattenCompat<core::slice::iter::Iter<[u8; 8]>, core::slice::iter::Iter<u8>>>::iter_fold::<u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>
  %_0 = call i32 @_RINvMsg_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB6_13FlattenCompatINtNtNtBc_5slice4iter4IterAhj8_EIB1d_hEE9iter_foldmNCINvNvXsi_B6_IBS_ppENtNtNtBa_6traits8iterator8Iterator4fold7flattenB1I_mNCINvNtB8_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB2q_5accummNtB4p_3Sum3sumINtB3h_3MapINtB6_7FlattenB1c_EB3D_EE0E0E0EB3H_(ptr align 8 %_4, i32 %init) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  store i8 0, ptr %_8, align 1
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <u32 as core::iter::traits::accum::Sum>::sum::<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>
; Function Attrs: nonlazybind uwtable
define internal i32 @_RINvXsy_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accummNtB6_3Sum3sumINtNtNtBa_8adapters3map3MapINtNtB16_7flatten7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0EEB2s_(ptr align 8 %iter) unnamed_addr #0 !guid !275 {
start:
  %0 = alloca [48 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iter, i64 48, i1 false)
; call <core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<u32, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>
  %_0 = call i32 @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtB8_7flatten7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0ENtNtNtBa_6traits8iterator8Iterator4foldmNCINvXsy_NtB2A_5accummNtB3j_3Sum3sumBN_E0EB1W_(ptr align 8 %0, i32 0)
  ret i32 %_0
}

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::find::<&mut algorithms::sieve::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejENtNtNtNtBa_4iter6traits8iterator8Iterator4findQNCNvCscEnaBunu62E_10algorithms5sieve0EB1K_(ptr align 8 %self, ptr align 8 %predicate) unnamed_addr #1 !guid !276 {
start:
; call core::iter::traits::iterator::Iterator::find::check::<usize, &mut algorithms::sieve::{closure#0}>
  %_4 = call align 8 ptr @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator4find5checkjQNCNvCscEnaBunu62E_10algorithms5sieve0EB1g_(ptr align 8 %predicate) #15
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find::check<usize, &mut algorithms::sieve::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<usize>>
  %0 = call { i64, i64 } @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB1g_4find5checkjQNCNvCscEnaBunu62E_10algorithms5sieve0E0INtNtBJ_12control_flow11ControlFlowjEEB2q_(ptr align 8 %self, ptr align 8 %_4) #15
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <core::ops::control_flow::ControlFlow<usize>>::break_value
  %1 = call { i64, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB5_11ControlFlowjE11break_valueCsddYV2PBJW9h_3std(i64 %_3.0, i64 %_3.1) #15
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::filter::<algorithms::sieve::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejENtNtNtNtBa_4iter6traits8iterator8Iterator6filterNCNvCscEnaBunu62E_10algorithms5sieve0EB1L_(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %self, ptr align 8 %predicate) unnamed_addr #1 !guid !277 {
start:
  %0 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %self, i64 24, i1 false)
; call <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>::new
  call void @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filterINtB2_6FilterINtNtNtB8_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0E3newB1F_(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %0, ptr align 8 %predicate)
  ret void
}

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejENtNtNtNtBa_4iter6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !278 {
start:
  %_6 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  store i8 0, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %self, i64 24, i1 false)
; call <alloc::vec::Vec<usize> as core::iter::traits::collect::FromIterator<usize>>::from_iter::<core::ops::range::RangeInclusive<usize>>
  call void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorjE9from_iterINtNtNtBR_3ops5range14RangeInclusivejEECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_5) #15
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejENtNtNtNtBa_4iter6traits8iterator8Iterator8for_eachNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1S_3VecjE14extend_trustedB3_E0ECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !279 {
start:
  %0 = alloca [24 x i8], align 8
  %_6 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %_4 = alloca [24 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %f, i64 24, i1 false)
; call core::iter::traits::iterator::Iterator::for_each::call::<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>
  call void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1n_3VecjE14extend_trustedINtNtNtBc_3ops5range14RangeInclusivejEE0ECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %0) #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>
  call void @_RINvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBa_3ops5range14RangeInclusivejENtNtNtB8_6traits8iterator8Iterator4folduNCINvNvB1g_8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2t_3VecjE14extend_trustedBE_E0E0ECscEnaBunu62E_10algorithms(ptr align 8 %_4, ptr align 8 %_5) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::map::<u64, algorithms::main::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangelENtNtNtNtBa_4iter6traits8iterator8Iterator3mapyNCNvCscEnaBunu62E_10algorithms4main0EB1z_(ptr sret([16 x i8]) align 8 %_0, i32 %self.0, i32 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !280 {
start:
; call <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::new
  call void @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0E3newB1p_(ptr sret([16 x i8]) align 8 %_0, i32 %self.0, i32 %self.1, ptr align 8 %f)
  ret void
}

; <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::adapters::map::map_fold<i32, u64, (), algorithms::main::{closure#0}, core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangelENtNtNtNtBa_4iter6traits8iterator8Iterator4folduNCINvNtNtBR_8adapters3map8map_foldlyuNCNvCscEnaBunu62E_10algorithms4main0NCINvNvBL_8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB3f_3VecyE14extend_trustedINtB1B_3MapB3_B27_EE0E0E0EB2b_(i32 %0, i32 %1, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !281 {
start:
  %2 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %_5 = alloca [8 x i8], align 4
  %self = alloca [8 x i8], align 4
  store i32 %0, ptr %self, align 4
  %3 = getelementptr inbounds i8, ptr %self, i64 4
  store i32 %1, ptr %3, align 4
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  br label %bb1

bb1:                                              ; preds = %bb4, %start
; invoke <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::next
  %4 = invoke { i32, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangelENtNtNtB7_6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 4 %self)
          to label %bb2 unwind label %cleanup

bb12:                                             ; preds = %cleanup
  %5 = load i8, ptr %_13, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb11, label %bb8

cleanup:                                          ; preds = %bb3, %bb1
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %2, align 8
  %10 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb12

bb2:                                              ; preds = %bb1
  %11 = extractvalue { i32, i32 } %4, 0
  %12 = extractvalue { i32, i32 } %4, 1
  store i32 %11, ptr %_5, align 4
  %13 = getelementptr inbounds i8, ptr %_5, i64 4
  store i32 %12, ptr %13, align 4
  %14 = load i32, ptr %_5, align 4
  %15 = getelementptr inbounds i8, ptr %_5, i64 4
  %16 = load i32, ptr %15, align 4
  %_7 = zext i32 %14 to i64
  %17 = trunc nuw i64 %_7 to i1
  br i1 %17, label %bb3, label %bb5

bb3:                                              ; preds = %bb2
  %18 = getelementptr inbounds i8, ptr %_5, i64 4
  %x = load i32, ptr %18, align 4
  store i8 0, ptr %_13, align 1
; invoke core::iter::adapters::map::map_fold::<i32, u64, (), algorithms::main::{closure#0}, core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>::{closure#0}
  invoke void @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldlyuNCNvCscEnaBunu62E_10algorithms4main0NCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2A_3VecyE14extend_trustedINtB4_3MapINtNtNtBa_3ops5range5RangelEBX_EE0E0E0B11_(ptr align 8 %f, i32 %x)
          to label %bb4 unwind label %cleanup

bb5:                                              ; preds = %bb2
  store i8 0, ptr %_13, align 1
  store i8 0, ptr %_13, align 1
; call core::ptr::drop_glue::<core::iter::adapters::map::map_fold<i32, u64, (), algorithms::main::{closure#0}, core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>::{closure#0}>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldlyuNCNvCscEnaBunu62E_10algorithms4main0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2W_3VecyE14extend_trustedINtBG_3MapINtNtNtB4_3ops5range5RangelEB1j_EE0E0E0EB1n_(ptr align 8 %f)
  br label %bb6

bb4:                                              ; preds = %bb3
  store i8 1, ptr %_13, align 1
  br label %bb1

bb6:                                              ; preds = %bb5
  ret void

bb13:                                             ; No predecessors!
  unreachable

bb8:                                              ; preds = %bb11, %bb12
; invoke core::ptr::drop_glue::<core::iter::adapters::map::map_fold<i32, u64, (), algorithms::main::{closure#0}, core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>::{closure#0}>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNCINvNtNtNtB4_4iter8adapters3map8map_foldlyuNCNvCscEnaBunu62E_10algorithms4main0NCINvNvNtNtNtBK_6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2W_3VecyE14extend_trustedINtBG_3MapINtNtNtB4_3ops5range5RangelEB1j_EE0E0E0EB1n_(ptr align 8 %f) #16
          to label %bb9 unwind label %terminate

bb11:                                             ; preds = %bb12
  br label %bb8

terminate:                                        ; preds = %bb8
  %19 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb9:                                              ; preds = %bb8
  %20 = load ptr, ptr %2, align 8
  %21 = getelementptr inbounds i8, ptr %2, i64 8
  %22 = load i32, ptr %21, align 8
  %23 = insertvalue { ptr, i32 } poison, ptr %20, 0
  %24 = insertvalue { ptr, i32 } %23, i32 %22, 1
  resume { ptr, i32 } %24
}

; <core::ops::range::Range<u64> as core::iter::traits::iterator::Iterator>::map::<u32, algorithms::collatz>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangeyENtNtNtNtBa_4iter6traits8iterator8Iterator3mapmNvCscEnaBunu62E_10algorithms7collatzEB1x_(i64 %self.0, i64 %self.1) unnamed_addr #1 !guid !282 {
start:
; call <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz>>::new
  %0 = call { i64, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzE3newB1n_(i64 %self.0, i64 %self.1)
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ops::range::Range<u64> as core::iter::traits::iterator::Iterator>::fold::<u32, core::iter::adapters::map::map_fold<u64, u32, u32, algorithms::collatz, core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangeyENtNtNtNtBa_4iter6traits8iterator8Iterator4foldmNCINvNtNtBR_8adapters3map8map_foldymmNvCscEnaBunu62E_10algorithms7collatzNCINvNvBL_6max_by4foldmNvYmNtNtBa_3cmp3Ord3cmpE0E0EB29_(i64 %0, i64 %1, i32 %init) unnamed_addr #1 personality ptr @rust_eh_personality !guid !283 {
start:
  %_13 = alloca [1 x i8], align 1
  %_5 = alloca [16 x i8], align 8
  %accum = alloca [4 x i8], align 4
  %f = alloca [0 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  store i32 %init, ptr %accum, align 4
  br label %bb1

bb1:                                              ; preds = %bb4, %start
; call <core::ops::range::Range<u64> as core::iter::traits::iterator::Iterator>::next
  %3 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeyENtNtNtB7_6traits8iterator8Iterator4nextCs257F0UrNG3U_14rustc_demangle(ptr align 8 %self) #15
  %4 = extractvalue { i64, i64 } %3, 0
  %5 = extractvalue { i64, i64 } %3, 1
  store i64 %4, ptr %_5, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 8
  store i64 %5, ptr %6, align 8
  br label %bb2

bb2:                                              ; preds = %bb1
  %_7 = load i64, ptr %_5, align 8
  %7 = getelementptr inbounds i8, ptr %_5, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = trunc nuw i64 %_7 to i1
  br i1 %9, label %bb3, label %bb5

bb3:                                              ; preds = %bb2
  %10 = getelementptr inbounds i8, ptr %_5, i64 8
  %x = load i64, ptr %10, align 8
  store i8 0, ptr %_13, align 1
  %_12 = load i32, ptr %accum, align 4
; call core::iter::adapters::map::map_fold::<u64, u32, u32, algorithms::collatz, core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>::{closure#0}
  %_9 = call i32 @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldymmNvCscEnaBunu62E_10algorithms7collatzNCINvNvNtNtNtB8_6traits8iterator8Iterator6max_by4foldmNvYmNtNtBa_3cmp3Ord3cmpE0E0BZ_(ptr %f, i32 %_12, i64 %x) #15
  br label %bb4

bb5:                                              ; preds = %bb2
  store i8 0, ptr %_13, align 1
  %_0 = load i32, ptr %accum, align 4
  store i8 0, ptr %_13, align 1
  br label %bb6

bb4:                                              ; preds = %bb3
  store i8 1, ptr %_13, align 1
  store i32 %_9, ptr %accum, align 4
  br label %bb1

bb6:                                              ; preds = %bb5
  ret i32 %_0

bb13:                                             ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<usize> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::enumerate::Enumerate<_> as core::iter::traits::iterator::Iterator>::try_fold::enumerate<&usize, (), core::ops::control_flow::ControlFlow<()>, core::iter::traits::iterator::Iterator::all::check<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterjENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvXs_NtNtBR_8adapters9enumerateINtB1K_9EnumeratepEBL_8try_fold9enumerateRjuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkTjB2P_ENCNvCscEnaBunu62E_10algorithms6queens0E0E0B2S_EB44_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !284 {
start:
  %_17 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  store i8 0, ptr %_17, align 1
  store i8 1, ptr %_17, align 1
  br label %bb1

bb1:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<usize> as core::iter::traits::iterator::Iterator>::next
  %0 = call align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterjENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBa_(ptr align 8 %self) #15
  store ptr %0, ptr %_5, align 8
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = load ptr, ptr %_5, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_6 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_6 to i1
  br i1 %4, label %bb3, label %bb10

bb3:                                              ; preds = %bb2
  %x = load ptr, ptr %_5, align 8
  store i8 0, ptr %_17, align 1
; call <core::iter::adapters::enumerate::Enumerate<_> as core::iter::traits::iterator::Iterator>::try_fold::enumerate::<&usize, (), core::ops::control_flow::ControlFlow<()>, core::iter::traits::iterator::Iterator::all::check<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}>::{closure#0}
  %_9 = call zeroext i1 @_RNCINvNvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters9enumerateINtB9_9EnumeratepENtNtNtBd_6traits8iterator8Iterator8try_fold9enumerateRjuINtNtNtBf_3ops12control_flow11ControlFlowuENCINvNvB1e_3all5checkTjB25_ENCNvCscEnaBunu62E_10algorithms6queens0E0E0B3l_(ptr align 8 %f, ptr align 8 %x) #15
  br label %bb4

bb10:                                             ; preds = %bb2
  store i8 0, ptr %_17, align 1
; call <core::ops::control_flow::ControlFlow<()> as core::ops::try_trait::Try>::from_output
  %5 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowuENtNtB4_9try_trait3Try11from_outputCs257F0UrNG3U_14rustc_demangle() #15
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb11

bb4:                                              ; preds = %bb3
; call <core::ops::control_flow::ControlFlow<()> as core::ops::try_trait::Try>::branch
  %7 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowuENtNtB4_9try_trait3Try6branchCs257F0UrNG3U_14rustc_demangle(i1 zeroext %_9) #15
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_8, align 1
  br label %bb5

bb5:                                              ; preds = %bb4
  %9 = load i8, ptr %_8, align 1
  %10 = trunc nuw i8 %9 to i1
  %_13 = zext i1 %10 to i64
  %11 = trunc nuw i64 %_13 to i1
  br i1 %11, label %bb8, label %bb7

bb8:                                              ; preds = %bb5
; call <core::ops::control_flow::ControlFlow<()> as core::ops::try_trait::FromResidual<core::ops::control_flow::ControlFlow<(), core::convert::Infallible>>>::from_residual
  %12 = call zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB4_11ControlFlowuEINtNtB6_9try_trait12FromResidualIBK_uNtNtB8_7convert10InfallibleEE13from_residualCs257F0UrNG3U_14rustc_demangle() #15
  %13 = zext i1 %12 to i8
  store i8 %13, ptr %_0, align 1
  br label %bb9

bb7:                                              ; preds = %bb5
  store i8 1, ptr %_17, align 1
  br label %bb1

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_17, align 1
  br label %bb12

bb12:                                             ; preds = %bb11, %bb9
  %14 = load i8, ptr %_0, align 1
  %15 = trunc nuw i8 %14 to i1
  ret i1 %15

bb11:                                             ; preds = %bb10
  store i8 0, ptr %_17, align 1
  br label %bb12

bb6:                                              ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable

bb14:                                             ; No predecessors!
  unreachable

bb15:                                             ; No predecessors!
  unreachable

bb16:                                             ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<u64> as core::iter::traits::iterator::Iterator>::sum::<u64>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator3sumyECscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !285 {
start:
; call <u64 as core::iter::traits::accum::Sum<&u64>>::sum::<core::slice::iter::Iter<u64>>
  %_0 = call i64 @_RINvXsE_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumyINtB6_3SumRyE3sumINtNtNtBc_5slice4iter4IteryEECscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1)
  ret i64 %_0
}

; <core::slice::iter::Windows<u64> as core::iter::traits::iterator::Iterator>::all::<algorithms::main::{closure#1}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter7WindowsyENtNtNtNtBa_4iter6traits8iterator8Iterator3allNCNvCscEnaBunu62E_10algorithms4mains_0EB1B_(ptr align 8 %self) unnamed_addr #1 !guid !286 {
start:
  %_4 = alloca [1 x i8], align 1
; call core::iter::traits::iterator::Iterator::all::check::<&[u64], algorithms::main::{closure#1}>
  call void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator3all5checkRSyNCNvCscEnaBunu62E_10algorithms4mains_0EB1g_() #15
; call <core::slice::iter::Windows<u64> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::all::check<&[u64], algorithms::main::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>
  %0 = call zeroext i1 @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter7WindowsyENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBO_3all5checkRSyNCNvCscEnaBunu62E_10algorithms4mains_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB24_(ptr align 8 %self) #15
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_4, align 1
; call <core::ops::control_flow::ControlFlow<()> as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXs9_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB5_11ControlFlowuENtNtB9_3cmp9PartialEq2eqCs257F0UrNG3U_14rustc_demangle(ptr %_4, ptr @alloc_914b2c69d7eca30497b9feaf15ac92f1) #15
  ret i1 %_0
}

; <core::slice::iter::Windows<u64> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::all::check<&[u64], algorithms::main::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter7WindowsyENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBO_3all5checkRSyNCNvCscEnaBunu62E_10algorithms4mains_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB24_(ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !287 {
start:
  %_17 = alloca [1 x i8], align 1
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [16 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %f = alloca [0 x i8], align 1
  store i8 0, ptr %_17, align 1
  store i8 1, ptr %_17, align 1
  br label %bb1

bb1:                                              ; preds = %bb7, %start
; call <core::slice::iter::Windows<u64> as core::iter::traits::iterator::Iterator>::next
  %0 = call { ptr, i64 } @_RNvXsY_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_7WindowsyENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_5, align 8
  %3 = getelementptr inbounds i8, ptr %_5, i64 8
  store i64 %2, ptr %3, align 8
  br label %bb2

bb2:                                              ; preds = %bb1
  %4 = load ptr, ptr %_5, align 8
  %5 = getelementptr inbounds i8, ptr %_5, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_6 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_6 to i1
  br i1 %9, label %bb3, label %bb10

bb3:                                              ; preds = %bb2
  %x.0 = load ptr, ptr %_5, align 8
  %10 = getelementptr inbounds i8, ptr %_5, i64 8
  %x.1 = load i64, ptr %10, align 8
  store i8 0, ptr %_17, align 1
; call core::iter::traits::iterator::Iterator::all::check::<&[u64], algorithms::main::{closure#1}>::{closure#0}
  %_9 = call zeroext i1 @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator3all5checkRSyNCNvCscEnaBunu62E_10algorithms4mains_0E0B1i_(ptr %f, ptr align 8 %x.0, i64 %x.1) #15
  br label %bb4

bb10:                                             ; preds = %bb2
  store i8 0, ptr %_17, align 1
; call <core::ops::control_flow::ControlFlow<()> as core::ops::try_trait::Try>::from_output
  %11 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowuENtNtB4_9try_trait3Try11from_outputCs257F0UrNG3U_14rustc_demangle() #15
  %12 = zext i1 %11 to i8
  store i8 %12, ptr %_0, align 1
  br label %bb11

bb4:                                              ; preds = %bb3
; call <core::ops::control_flow::ControlFlow<()> as core::ops::try_trait::Try>::branch
  %13 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowuENtNtB4_9try_trait3Try6branchCs257F0UrNG3U_14rustc_demangle(i1 zeroext %_9) #15
  %14 = zext i1 %13 to i8
  store i8 %14, ptr %_8, align 1
  br label %bb5

bb5:                                              ; preds = %bb4
  %15 = load i8, ptr %_8, align 1
  %16 = trunc nuw i8 %15 to i1
  %_13 = zext i1 %16 to i64
  %17 = trunc nuw i64 %_13 to i1
  br i1 %17, label %bb8, label %bb7

bb8:                                              ; preds = %bb5
; call <core::ops::control_flow::ControlFlow<()> as core::ops::try_trait::FromResidual<core::ops::control_flow::ControlFlow<(), core::convert::Infallible>>>::from_residual
  %18 = call zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB4_11ControlFlowuEINtNtB6_9try_trait12FromResidualIBK_uNtNtB8_7convert10InfallibleEE13from_residualCs257F0UrNG3U_14rustc_demangle() #15
  %19 = zext i1 %18 to i8
  store i8 %19, ptr %_0, align 1
  br label %bb9

bb7:                                              ; preds = %bb5
  store i8 1, ptr %_17, align 1
  br label %bb1

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_17, align 1
  br label %bb12

bb12:                                             ; preds = %bb11, %bb9
  %20 = load i8, ptr %_0, align 1
  %21 = trunc nuw i8 %20 to i1
  ret i1 %21

bb11:                                             ; preds = %bb10
  store i8 0, ptr %_17, align 1
  br label %bb12

bb6:                                              ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable

bb14:                                             ; No predecessors!
  unreachable

bb15:                                             ; No predecessors!
  unreachable

bb16:                                             ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}> as core::iter::traits::iterator::Iterator>::sum::<u32>
; Function Attrs: nonlazybind uwtable
define internal i32 @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtB8_7flatten7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0ENtNtNtBa_6traits8iterator8Iterator3summEB1Q_(ptr align 8 %self) unnamed_addr #0 !guid !288 {
start:
  %0 = alloca [48 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %self, i64 48, i1 false)
; call <u32 as core::iter::traits::accum::Sum>::sum::<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>
  %_0 = call i32 @_RINvXsy_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accummNtB6_3Sum3sumINtNtNtBa_8adapters3map3MapINtNtB16_7flatten7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0EEB2s_(ptr align 8 %0)
  ret i32 %_0
}

; <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<u64>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtNtNtBa_6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VecyEEB1n_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !289 {
start:
  %_6 = alloca [1 x i8], align 1
  %_5 = alloca [16 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  store i8 0, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %self, i64 16, i1 false)
; call <alloc::vec::Vec<u64> as core::iter::traits::collect::FromIterator<u64>>::from_iter::<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>
  call void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecyEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratoryE9from_iterINtNtNtBP_8adapters3map3MapINtNtNtBR_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EEB2R_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_5) #15
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::iterator::Iterator>::for_each::<<alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2K_3VecyE14extend_trustedB3_E0EB1n_(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 personality ptr @rust_eh_personality !guid !290 {
start:
  %0 = alloca [24 x i8], align 8
  %_6 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %_4 = alloca [16 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %self, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %f, i64 24, i1 false)
; call core::iter::traits::iterator::Iterator::for_each::call::<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>
  call void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1n_3VecyE14extend_trustedINtNtNtBa_8adapters3map3MapINtNtNtBc_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0EB3d_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %0) #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; call <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::iterator::Iterator>::fold::<(), core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>
  call void @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB20_8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB3d_3VecyE14extend_trustedBN_E0E0EB1t_(ptr align 8 %_4, ptr align 8 %_5)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_6, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::max_by::<<u32 as core::cmp::Ord>::cmp>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtBa_6traits8iterator8Iterator6max_byNvYmNtNtBc_3cmp3Ord3cmpEB1l_(i64 %self.0, i64 %self.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !291 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call core::iter::traits::iterator::Iterator::max_by::fold::<u32, <u32 as core::cmp::Ord>::cmp>
  call void @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator6max_by4foldmNvYmNtNtBc_3cmp3Ord3cmpECscEnaBunu62E_10algorithms() #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::reduce::<core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>
  %0 = call { i32, i32 } @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtBa_6traits8iterator8Iterator6reduceNCINvNvB1U_6max_by4foldmNvYmNtNtBc_3cmp3Ord3cmpE0EB1l_(i64 %self.0, i64 %self.1) #15
  %_0.0 = extractvalue { i32, i32 } %0, 0
  %_0.1 = extractvalue { i32, i32 } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i32, i32 } poison, i32 %_0.0, 0
  %2 = insertvalue { i32, i32 } %1, i32 %_0.1, 1
  ret { i32, i32 } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::reduce::<core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtBa_6traits8iterator8Iterator6reduceNCINvNvB1U_6max_by4foldmNvYmNtNtBc_3cmp3Ord3cmpE0EB1l_(i64 %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !292 {
start:
  %_12 = alloca [1 x i8], align 1
  %_11 = alloca [1 x i8], align 1
  %_3 = alloca [8 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_12, align 1
  store i8 0, ptr %_11, align 1
  store i8 1, ptr %_12, align 1
  store i8 1, ptr %_11, align 1
; call <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::next
  %3 = call { i32, i32 } @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtB9_6traits8iterator8Iterator4nextB1q_(ptr align 8 %self) #15
  %_4.0 = extractvalue { i32, i32 } %3, 0
  %_4.1 = extractvalue { i32, i32 } %3, 1
  br label %bb1

bb1:                                              ; preds = %start
; call <core::option::Option<u32> as core::ops::try_trait::Try>::branch
  %4 = call { i32, i32 } @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmENtNtNtB7_3ops9try_trait3Try6branchB7_(i32 %_4.0, i32 %_4.1) #15
  %5 = extractvalue { i32, i32 } %4, 0
  %6 = extractvalue { i32, i32 } %4, 1
  store i32 %5, ptr %_3, align 4
  %7 = getelementptr inbounds i8, ptr %_3, i64 4
  store i32 %6, ptr %7, align 4
  br label %bb2

bb2:                                              ; preds = %bb1
  %8 = load i32, ptr %_3, align 4
  %9 = getelementptr inbounds i8, ptr %_3, i64 4
  %10 = load i32, ptr %9, align 4
  %_6 = zext i32 %8 to i64
  %11 = trunc nuw i64 %_6 to i1
  br i1 %11, label %bb5, label %bb4

bb5:                                              ; preds = %bb2
; call <core::option::Option<u32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
  %12 = call { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualB7_() #15
  %13 = extractvalue { i32, i32 } %12, 0
  %14 = extractvalue { i32, i32 } %12, 1
  store i32 %13, ptr %_0, align 4
  %15 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %14, ptr %15, align 4
  br label %bb6

bb4:                                              ; preds = %bb2
  %16 = getelementptr inbounds i8, ptr %_3, i64 4
  %first = load i32, ptr %16, align 4
  store i8 0, ptr %_12, align 1
  %_9.0 = load i64, ptr %self, align 8
  %17 = getelementptr inbounds i8, ptr %self, i64 8
  %_9.1 = load i64, ptr %17, align 8
  store i8 0, ptr %_11, align 1
; call <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::fold::<u32, core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>
  %_8 = call i32 @_RINvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtBa_6traits8iterator8Iterator4foldmNCINvNvB20_6max_by4foldmNvYmNtNtBc_3cmp3Ord3cmpE0EB1r_(i64 %_9.0, i64 %_9.1, i32 %first)
  br label %bb7

bb7:                                              ; preds = %bb4
  %18 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_8, ptr %18, align 4
  store i32 1, ptr %_0, align 4
  br label %bb9

bb9:                                              ; preds = %bb8, %bb7
  %19 = load i32, ptr %_0, align 4
  %20 = getelementptr inbounds i8, ptr %_0, i64 4
  %21 = load i32, ptr %20, align 4
  %22 = insertvalue { i32, i32 } poison, i32 %19, 0
  %23 = insertvalue { i32, i32 } %22, i32 %21, 1
  ret { i32, i32 } %23

bb6:                                              ; preds = %bb5
  br label %bb8

bb8:                                              ; preds = %bb6
  br label %bb9

bb3:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable

bb14:                                             ; No predecessors!
  unreachable
}

; <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtBc_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtNtNtBa_6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VecjEEB1D_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !293 {
start:
  %_6 = alloca [1 x i8], align 1
  %_5 = alloca [32 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  store i8 0, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %self, i64 32, i1 false)
; call <alloc::vec::Vec<usize> as core::iter::traits::collect::FromIterator<usize>>::from_iter::<core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>
  call void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorjE9from_iterINtNtNtBP_8adapters6filter6FilterINtNtNtBR_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EEB37_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_5) #15
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>> as core::iter::traits::iterator::Iterator>::map::<u32, algorithms::main::{closure#2}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters7flatten7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENtNtNtBa_6traits8iterator8Iterator3mapmNCNvCscEnaBunu62E_10algorithms4mains0_0EB2d_(ptr sret([48 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !294 {
start:
  %0 = alloca [48 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %self, i64 48, i1 false)
; call <core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::new
  call void @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtB4_7flatten7FlattenINtNtNtB8_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0E3newB1S_(ptr sret([48 x i8]) align 8 %_0, ptr align 8 %0)
  ret void
}

; <core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<usize>> as core::iter::traits::iterator::Iterator>::all::<algorithms::queens::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters9enumerate9EnumerateINtNtNtBc_5slice4iter4IterjEENtNtNtBa_6traits8iterator8Iterator3allNCNvCscEnaBunu62E_10algorithms6queens0EB2c_(ptr align 8 %self, ptr align 8 %f.0, ptr align 8 %f.1) unnamed_addr #1 !guid !295 {
start:
  %_4 = alloca [1 x i8], align 1
; call core::iter::traits::iterator::Iterator::all::check::<(usize, &usize), algorithms::queens::{closure#0}>
  %0 = call { ptr, ptr } @_RINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator3all5checkTjRjENCNvCscEnaBunu62E_10algorithms6queens0EB1i_(ptr align 8 %f.0, ptr align 8 %f.1) #15
  %_5.0 = extractvalue { ptr, ptr } %0, 0
  %_5.1 = extractvalue { ptr, ptr } %0, 1
; call <core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<usize>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::all::check<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>
  %1 = call zeroext i1 @_RINvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters9enumerateINtB5_9EnumerateINtNtNtBb_5slice4iter4IterjEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1B_3all5checkTjRjENCNvCscEnaBunu62E_10algorithms6queens0E0INtNtNtBb_3ops12control_flow11ControlFlowuEEB2N_(ptr align 8 %self, ptr align 8 %_5.0, ptr align 8 %_5.1) #15
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_4, align 1
; call <core::ops::control_flow::ControlFlow<()> as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXs9_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB5_11ControlFlowuENtNtB9_3cmp9PartialEq2eqCs257F0UrNG3U_14rustc_demangle(ptr %_4, ptr @alloc_914b2c69d7eca30497b9feaf15ac92f1) #15
  ret i1 %_0
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<char>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvYNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, ptr %self.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !296 {
start:
  %_6 = alloca [1 x i8], align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  store i8 0, ptr %_6, align 1
; call <alloc::vec::Vec<char> as core::iter::traits::collect::FromIterator<char>>::from_iter::<core::str::iter::Chars>
  call void @_RINvXsf_NtCs7CppTae75M1_5alloc3vecINtB6_3VeccEINtNtNtNtCsl10jNU3mE6R_4core4iter6traits7collect12FromIteratorcE9from_iterNtNtNtBR_3str4iter5CharsECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, ptr %self.1) #15
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ops::try_trait::NeverShortCircuit<()>>::wrap_mut_2::<(), usize, core::iter::traits::iterator::Iterator::for_each::call<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvMNtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituE10wrap_mut_2ujNCINvNvNtNtNtNtB9_4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2v_3VecjE14extend_trustedINtNtB7_5range14RangeInclusivejEE0E0E0CscEnaBunu62E_10algorithms(ptr align 8 %_1, i64 %b) unnamed_addr #1 !guid !297 {
start:
; call core::iter::traits::iterator::Iterator::for_each::call::<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}
  call void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1p_3VecjE14extend_trustedINtNtNtBe_3ops5range14RangeInclusivejEE0E0CscEnaBunu62E_10algorithms(ptr align 8 %_1, i64 %b) #15
  ret void
}

; <alloc::vec::Vec<usize>>::extend_trusted::<core::ops::range::RangeInclusive<usize>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB8_3VecjE14extend_trustedINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEE0CscEnaBunu62E_10algorithms(ptr align 8 %_1, i64 %element) unnamed_addr #1 personality ptr @rust_eh_personality !guid !298 {
start:
  %_11 = alloca [1 x i8], align 1
  store i8 0, ptr %_11, align 1
  store i8 1, ptr %_11, align 1
  %0 = getelementptr inbounds i8, ptr %_1, i64 16
  %_5 = load ptr, ptr %0, align 8
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::current_len
  %_6 = call i64 @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop11current_lenCscEnaBunu62E_10algorithms(ptr align 8 %_1) #15
  br label %bb1

bb1:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i64, ptr %_5, i64 %_6
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_11, align 1
  store i64 %element, ptr %_0.i, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::increment_len
  call void @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop13increment_lenCscEnaBunu62E_10algorithms(ptr align 8 %_1, i64 1) #15
  br label %bb4

bb4:                                              ; preds = %bb3
  ret void

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u64>>::extend_trusted::<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB8_3VecyE14extend_trustedINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB19_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0B2l_(ptr align 8 %_1, i64 %element) unnamed_addr #1 personality ptr @rust_eh_personality !guid !299 {
start:
  %_11 = alloca [1 x i8], align 1
  store i8 0, ptr %_11, align 1
  store i8 1, ptr %_11, align 1
  %0 = getelementptr inbounds i8, ptr %_1, i64 16
  %_5 = load ptr, ptr %0, align 8
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::current_len
  %_6 = call i64 @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop11current_lenCscEnaBunu62E_10algorithms(ptr align 8 %_1) #15
  br label %bb1

bb1:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i64, ptr %_5, i64 %_6
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_11, align 1
  store i64 %element, ptr %_0.i, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::increment_len
  call void @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop13increment_lenCscEnaBunu62E_10algorithms(ptr align 8 %_1, i64 1) #15
  br label %bb4

bb4:                                              ; preds = %bb3
  ret void

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CscEnaBunu62E_10algorithms(ptr align 8 %_1) unnamed_addr #1 !guid !300 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscEnaBunu62E_10algorithms(ptr %_4) #19
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCscEnaBunu62E_10algorithms() #15
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CscEnaBunu62E_10algorithms(i8 %_2) #15
  ret i32 %_0
}

; core::iter::adapters::map::map_fold::<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtNtB8_6traits5accummNtB1K_3Sum3sumINtB4_3MapINtNtB6_7flatten7FlattenINtNtNtBa_5slice4iter4IterAhj8_EEBY_EE0E0B12_(ptr %_1, i32 %acc, ptr %elt) unnamed_addr #1 personality ptr @rust_eh_personality !guid !301 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
; call algorithms::main::{closure#2}
  %_7 = call i32 @_RNCNvCscEnaBunu62E_10algorithms4mains0_0B3_(ptr %_1, ptr %elt) #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call <u32 as core::iter::traits::accum::Sum>::sum::<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}
  %_0 = call i32 @_RNCINvXsy_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accummNtB8_3Sum3sumINtNtNtBc_8adapters3map3MapINtNtB18_7flatten7FlattenINtNtNtBe_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0EE0B2u_(ptr %_1, i32 %acc, i32 %_7) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_10, align 1
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; core::iter::adapters::map::map_fold::<i32, u64, (), algorithms::main::{closure#0}, core::iter::traits::iterator::Iterator::for_each::call<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldlyuNCNvCscEnaBunu62E_10algorithms4main0NCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB2A_3VecyE14extend_trustedINtB4_3MapINtNtNtBa_3ops5range5RangelEBX_EE0E0E0B11_(ptr align 8 %_1, i32 %elt) unnamed_addr #1 personality ptr @rust_eh_personality !guid !302 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
  %_8 = getelementptr inbounds i8, ptr %_1, i64 24
; call algorithms::main::{closure#0}
  %_7 = call i64 @_RNCNvCscEnaBunu62E_10algorithms4main0B3_(ptr align 8 %_8, i32 %elt) #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call core::iter::traits::iterator::Iterator::for_each::call::<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}
  call void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1p_3VecyE14extend_trustedINtNtNtBc_8adapters3map3MapINtNtNtBe_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0E0B3f_(ptr align 8 %_1, i64 %_7) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_10, align 1
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; core::iter::adapters::map::map_fold::<u64, u32, u32, algorithms::collatz, core::iter::traits::iterator::Iterator::max_by::fold<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldymmNvCscEnaBunu62E_10algorithms7collatzNCINvNvNtNtNtB8_6traits8iterator8Iterator6max_by4foldmNvYmNtNtBa_3cmp3Ord3cmpE0E0BZ_(ptr %_1, i32 %acc, i64 %elt) unnamed_addr #1 personality ptr @rust_eh_personality !guid !303 {
start:
  %_10 = alloca [1 x i8], align 1
  store i8 0, ptr %_10, align 1
  store i8 1, ptr %_10, align 1
; call <algorithms::collatz as core::ops::function::FnMut<(u64,)>>::call_mut
  %_7 = call i32 @_RNvYNvCscEnaBunu62E_10algorithms7collatzINtNtNtCsl10jNU3mE6R_4core3ops8function5FnMutTyEE8call_mutB4_(ptr %_1, i64 %elt) #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call core::iter::traits::iterator::Iterator::max_by::fold::<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}
  %_0 = call i32 @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator6max_by4foldmNvYmNtNtBe_3cmp3Ord3cmpE0CscEnaBunu62E_10algorithms(ptr %_1, i32 %acc, i32 %_7) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_10, align 1
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten::<&[u8; 8], u32, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNvMsg_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtBa_13FlattenCompatppE9iter_fold7flattenRAhj8_mNCINvNvXsi_Ba_BV_NtNtNtBe_6traits8iterator8Iterator4fold7flattenINtNtNtBg_5slice4iter4IterhEmNCINvNtBc_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB23_5accummNtB4q_3Sum3sumINtB3i_3MapINtBa_7FlattenIB2L_B1C_EEB3E_EE0E0E0E0B3I_(ptr align 8 %_1, i32 %acc, ptr %iter) unnamed_addr #1 personality ptr @rust_eh_personality !guid !304 {
start:
  %_8 = alloca [1 x i8], align 1
  %_4 = alloca [24 x i8], align 8
  store i8 0, ptr %_8, align 1
  %_7 = load ptr, ptr %_1, align 8
  store i8 1, ptr %_8, align 1
; call <&[u8; 8] as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXsb_NtCsl10jNU3mE6R_4core5arrayRAhj8_NtNtNtNtB7_4iter6traits7collect12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %iter)
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_8, align 1
  store i32 %acc, ptr %_4, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store ptr %_6.0, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  store ptr %_6.1, ptr %2, align 8
  %3 = load i32, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %4, i64 8
  %7 = load ptr, ptr %6, align 8
; call <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten::<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}
  %_0 = call i32 @_RNCINvNvXsi_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtBa_13FlattenCompatppENtNtNtBe_6traits8iterator8Iterator4fold7flattenINtNtNtBg_5slice4iter4IterhEmNCINvNtBc_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1n_5accummNtB3K_3Sum3sumINtB2C_3MapINtBa_7FlattenIB25_Ahj8_EEB2Y_EE0E0E0B32_(ptr %_7, i32 %3, ptr %5, ptr %7) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; core::iter::traits::iterator::Iterator::all::check::<&[u64], algorithms::main::{closure#1}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator3all5checkRSyNCNvCscEnaBunu62E_10algorithms4mains_0E0B1i_(ptr %_1, ptr align 8 %x.0, i64 %x.1) unnamed_addr #1 !guid !305 {
start:
  %_0 = alloca [1 x i8], align 1
; call algorithms::main::{closure#1}
  %_4 = call zeroext i1 @_RNCNvCscEnaBunu62E_10algorithms4mains_0B3_(ptr %_1, ptr align 8 %x.0, i64 %x.1) #15
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::iter::traits::iterator::Iterator::all::check::<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator3all5checkTjRjENCNvCscEnaBunu62E_10algorithms6queens0E0B1k_(ptr align 8 %_1, i64 %x.0, ptr align 8 %x.1) unnamed_addr #1 !guid !306 {
start:
  %_0 = alloca [1 x i8], align 1
; call algorithms::queens::{closure#0}
  %_4 = call zeroext i1 @_RNCNvCscEnaBunu62E_10algorithms6queens0B3_(ptr align 8 %_1, i64 %x.0, ptr align 8 %x.1) #15
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::iter::traits::iterator::Iterator::find::check::<usize, &mut algorithms::sieve::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator4find5checkjQNCNvCscEnaBunu62E_10algorithms5sieve0E0B1i_(ptr align 8 %_1, i64 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !307 {
start:
  %_9 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %x = alloca [8 x i8], align 8
  store i64 %0, ptr %x, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
; call <&mut algorithms::sieve::{closure#0} as core::ops::function::FnMut<(&usize,)>>::call_mut
  %_4 = call zeroext i1 @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core3ops8function5implsQNCNvCscEnaBunu62E_10algorithms5sieve0INtB7_5FnMutTRjEE8call_mutBS_(ptr align 8 %_1, ptr align 8 %x)
  br label %bb1

bb1:                                              ; preds = %start
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i64 0, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
  %_8 = load i64, ptr %x, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8, ptr %1, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %2 = load i8, ptr %_9, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb8, label %bb5

bb5:                                              ; preds = %bb8, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8

bb8:                                              ; preds = %bb4
  br label %bb5

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::iter::traits::iterator::Iterator::max_by::fold::<u32, <u32 as core::cmp::Ord>::cmp>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator6max_by4foldmNvYmNtNtBe_3cmp3Ord3cmpE0CscEnaBunu62E_10algorithms(ptr %_1, i32 %x, i32 %y) unnamed_addr #1 !guid !308 {
start:
; call core::cmp::max_by::<u32, &mut <u32 as core::cmp::Ord>::cmp>
  %_0 = call i32 @_RINvNtCsl10jNU3mE6R_4core3cmp6max_bymQNvYmNtB2_3Ord3cmpECscEnaBunu62E_10algorithms(i32 %x, i32 %y, ptr %_1) #15
  ret i32 %_0
}

; core::iter::traits::iterator::Iterator::for_each::call::<usize, <alloc::vec::Vec<usize>>::extend_trusted<core::ops::range::RangeInclusive<usize>>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4calljNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1p_3VecjE14extend_trustedINtNtNtBe_3ops5range14RangeInclusivejEE0E0CscEnaBunu62E_10algorithms(ptr align 8 %_1, i64 %item) unnamed_addr #1 !guid !309 {
start:
; call <alloc::vec::Vec<usize>>::extend_trusted::<core::ops::range::RangeInclusive<usize>>::{closure#0}
  call void @_RNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB8_3VecjE14extend_trustedINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEE0CscEnaBunu62E_10algorithms(ptr align 8 %_1, i64 %item) #15
  ret void
}

; core::iter::traits::iterator::Iterator::for_each::call::<u64, <alloc::vec::Vec<u64>>::extend_trusted<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator8for_each4callyNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB1p_3VecyE14extend_trustedINtNtNtBc_8adapters3map3MapINtNtNtBe_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0E0B3f_(ptr align 8 %_1, i64 %item) unnamed_addr #1 !guid !310 {
start:
; call <alloc::vec::Vec<u64>>::extend_trusted::<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::{closure#0}
  call void @_RNCINvMsk_NtCs7CppTae75M1_5alloc3vecINtB8_3VecyE14extend_trustedINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB19_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE0B2l_(ptr align 8 %_1, i64 %item) #15
  ret void
}

; <core::iter::adapters::enumerate::Enumerate<_> as core::iter::traits::iterator::Iterator>::try_fold::enumerate::<&usize, (), core::ops::control_flow::ControlFlow<()>, core::iter::traits::iterator::Iterator::all::check<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCINvNvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters9enumerateINtB9_9EnumeratepENtNtNtBd_6traits8iterator8Iterator8try_fold9enumerateRjuINtNtNtBf_3ops12control_flow11ControlFlowuENCINvNvB1e_3all5checkTjB25_ENCNvCscEnaBunu62E_10algorithms6queens0E0E0B3l_(ptr align 8 %_1, ptr align 8 %item) unnamed_addr #1 personality ptr @rust_eh_personality !guid !311 {
start:
  %0 = getelementptr inbounds i8, ptr %_1, i64 16
  %_10 = load ptr, ptr %0, align 8
  %_8 = load i64, ptr %_10, align 8
; call core::iter::traits::iterator::Iterator::all::check::<(usize, &usize), algorithms::queens::{closure#0}>::{closure#0}
  %acc = call zeroext i1 @_RNCINvNvNtNtNtNtCsl10jNU3mE6R_4core4iter6traits8iterator8Iterator3all5checkTjRjENCNvCscEnaBunu62E_10algorithms6queens0E0B1k_(ptr align 8 %_1, i64 %_8, ptr align 8 %item) #15
  %1 = getelementptr inbounds i8, ptr %_1, i64 16
  %_11 = load ptr, ptr %1, align 8
  %2 = load i64, ptr %_11, align 8
  %_9.0 = add i64 %2, 1
  %_9.1 = icmp ult i64 %_9.0, %2
  %3 = getelementptr inbounds i8, ptr %_1, i64 16
  %_12 = load ptr, ptr %3, align 8
  br i1 %_9.1, label %panic, label %bb2

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %_1, i64 16
  %_13 = load ptr, ptr %4, align 8
  store i64 %_9.0, ptr %_13, align 8
  ret i1 %acc

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_ab27f9f2532b251b4a877c1004f487aa) #14
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::fold::flatten::<core::slice::iter::Iter<u8>, u32, core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNvXsi_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtBa_13FlattenCompatppENtNtNtBe_6traits8iterator8Iterator4fold7flattenINtNtNtBg_5slice4iter4IterhEmNCINvNtBc_3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtB1n_5accummNtB3K_3Sum3sumINtB2C_3MapINtBa_7FlattenIB25_Ahj8_EEB2Y_EE0E0E0B32_(ptr %_1, i32 %acc, ptr %iter.0, ptr %iter.1) unnamed_addr #1 !guid !312 {
start:
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::fold::<u32, &mut core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}>
  %_0 = call i32 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator4foldmQNCINvNtNtBY_8adapters3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtBW_5accummNtB32_3Sum3sumINtB1J_3MapINtNtB1L_7flatten7FlattenIBG_Ahj8_EEB2g_EE0E0EB2k_(ptr %iter.0, ptr %iter.1, i32 %acc, ptr %_1) #15
  ret i32 %_0
}

; <u64 as core::iter::traits::accum::Sum<&u64>>::sum::<core::slice::iter::Iter<u64>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCINvXsE_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accumyINtB8_3SumRyE3sumINtNtNtBe_5slice4iter4IteryEE0CscEnaBunu62E_10algorithms(ptr %_1, i64 %a, ptr align 8 %b) unnamed_addr #1 !guid !313 {
start:
; call <u64 as core::ops::arith::Add<&u64>>::add
  %_0 = call i64 @_RNvXsr_NtNtCsl10jNU3mE6R_4core3ops5arithyINtB5_3AddRyE3addCscEnaBunu62E_10algorithms(i64 %a, ptr align 8 %b, ptr align 8 @alloc_a840ce68d073c0ef52d40243c1f57585) #15
  ret i64 %_0
}

; <u32 as core::iter::traits::accum::Sum>::sum::<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvXsy_NtNtNtCsl10jNU3mE6R_4core4iter6traits5accummNtB8_3Sum3sumINtNtNtBc_8adapters3map3MapINtNtB18_7flatten7FlattenINtNtNtBe_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0EE0B2u_(ptr %_1, i32 %a, i32 %b) unnamed_addr #1 !guid !314 {
start:
  %_4.0 = add i32 %a, %b
  %_4.1 = icmp ult i32 %_4.0, %a
  br i1 %_4.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i32 %_4.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_a840ce68d073c0ef52d40243c1f57585) #14
  unreachable
}

; algorithms::fnv::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCscEnaBunu62E_10algorithms3fnv0B3_(ptr %_1, i32 %h, ptr %_3) unnamed_addr #1 !guid !315 {
start:
  %b = load i8, ptr %_3, align 1
  %_6 = zext i8 %b to i32
  %_5 = xor i32 %h, %_6
  %_0.i = mul i32 %_5, 16777619
  ret i32 %_0.i
}

; algorithms::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNvCscEnaBunu62E_10algorithms4main0B3_(ptr align 8 %_1, i32 %_2) unnamed_addr #1 !guid !316 {
start:
  %_5 = load ptr, ptr %_1, align 8
; call algorithms::lcg
  %_3 = call i64 @_RNvCscEnaBunu62E_10algorithms3lcg(ptr align 8 %_5)
  %_0 = urem i64 %_3, 1000
  ret i64 %_0
}

; algorithms::main::{closure#2}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCscEnaBunu62E_10algorithms4mains0_0B3_(ptr %_1, ptr %_2) unnamed_addr #1 !guid !317 {
start:
  %x = load i8, ptr %_2, align 1
  %_0 = zext i8 %x to i32
  ret i32 %_0
}

; algorithms::main::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvCscEnaBunu62E_10algorithms4mains_0B3_(ptr %_1, ptr align 8 %w.0, i64 %w.1) unnamed_addr #1 !guid !318 {
start:
  %_6 = icmp ult i64 0, %w.1
  br i1 %_6, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw i64, ptr %w.0, i64 0
  %_3 = load i64, ptr %0, align 8
  %_10 = icmp ult i64 1, %w.1
  br i1 %_10, label %bb2, label %panic1

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 0, i64 %w.1, ptr align 8 @alloc_e4bdac4122206b2ebe40e840c39c6050) #14
  unreachable

bb2:                                              ; preds = %bb1
  %1 = getelementptr inbounds nuw i64, ptr %w.0, i64 1
  %_7 = load i64, ptr %1, align 8
  %_0 = icmp ule i64 %_3, %_7
  ret i1 %_0

panic1:                                           ; preds = %bb1
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 1, i64 %w.1, ptr align 8 @alloc_fe8078b694f80294d33efed07a1c45e3) #14
  unreachable
}

; algorithms::sieve::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvCscEnaBunu62E_10algorithms5sieve0B3_(ptr align 8 %_1, ptr align 8 %_2) unnamed_addr #1 !guid !319 {
start:
  %i = load i64, ptr %_2, align 8
  %_5 = load ptr, ptr %_1, align 8
; call <alloc::vec::Vec<bool> as core::ops::index::Index<usize>>::index
  %_4 = call ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %_5, i64 %i, ptr align 8 @alloc_da54e803e52fa44cc6a5f7a3e4224be8) #15
  %0 = load i8, ptr %_4, align 1
  %_0 = trunc nuw i8 %0 to i1
  ret i1 %_0
}

; algorithms::queens::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvCscEnaBunu62E_10algorithms6queens0B3_(ptr align 8 %_1, i64 %_2.0, ptr align 8 %_2.1) unnamed_addr #1 !guid !320 {
start:
  %_0 = alloca [1 x i8], align 1
  %cc = load i64, ptr %_2.1, align 8
  %_18 = load ptr, ptr %_1, align 8
  %_6 = load i64, ptr %_18, align 8
  %_5 = icmp ne i64 %cc, %_6
  br i1 %_5, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb6

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_19 = load ptr, ptr %0, align 8
  %_9 = load i64, ptr %_19, align 8
  %_10.0 = sub i64 %_9, %_2.0
  %_10.1 = icmp ult i64 %_9, %_2.0
  br i1 %_10.1, label %panic, label %bb3

bb6:                                              ; preds = %bb4, %bb2
  %1 = load i8, ptr %_0, align 1
  %2 = trunc nuw i8 %1 to i1
  ret i1 %2

bb3:                                              ; preds = %bb1
  %_20 = load ptr, ptr %_1, align 8
  %_14 = load i64, ptr %_20, align 8
  %3 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %_14, i64 %cc)
  %_16.0 = extractvalue { i64, i1 } %3, 0
  %_16.1 = extractvalue { i64, i1 } %3, 1
  br i1 %_16.1, label %panic1, label %bb4

panic:                                            ; preds = %bb1
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_34f9bf62090ec1c25e1e679d9928e24e) #14
  unreachable

bb4:                                              ; preds = %bb3
; call <isize>::abs
  %_11 = call i64 @_RNvMs3_NtCsl10jNU3mE6R_4core3numi3absCscEnaBunu62E_10algorithms(i64 %_16.0) #15
  %4 = icmp ne i64 %_10.0, %_11
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb6

panic1:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_d49eccfc497d83b90860188daee00009) #14
  unreachable
}

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::size_hint::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtBb_3ops5range14RangeInclusivejENtNtNtB9_6traits8iterator8Iterator9size_hint0CscEnaBunu62E_10algorithms(i64 %steps) unnamed_addr #1 !guid !321 {
start:
; call <usize>::checked_add
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCscEnaBunu62E_10algorithms(i64 %steps, i64 1) #15
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <bool as alloc::vec::is_zero::IsZero>::is_zero::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvXsh_NtNtCs7CppTae75M1_5alloc3vec7is_zerobNtB7_6IsZero7is_zero0CscEnaBunu62E_10algorithms(ptr %_1, i1 zeroext %x) unnamed_addr #1 !guid !322 {
start:
  %_0 = xor i1 %x, true
  ret i1 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCscEnaBunu62E_10algorithms(ptr %_1) unnamed_addr #1 !guid !323 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCscEnaBunu62E_10algorithms(ptr %0) #15
  ret i32 %_0
}

; algorithms::edit_distance
; Function Attrs: nonlazybind uwtable
define internal i64 @_RNvCscEnaBunu62E_10algorithms13edit_distance(ptr %a.0, i64 %a.1, ptr %b.0, i64 %b.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !324 {
start:
  %0 = alloca [16 x i8], align 8
  %_33 = alloca [16 x i8], align 8
  %iter1 = alloca [24 x i8], align 8
  %_29 = alloca [24 x i8], align 8
  %_28 = alloca [24 x i8], align 8
  %prev = alloca [8 x i8], align 8
  %_19 = alloca [16 x i8], align 8
  %iter = alloca [24 x i8], align 8
  %_15 = alloca [24 x i8], align 8
  %_14 = alloca [24 x i8], align 8
  %_11 = alloca [24 x i8], align 8
  %d = alloca [24 x i8], align 8
  %_8 = alloca [24 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %_5 = alloca [48 x i8], align 8
  %b = alloca [24 x i8], align 8
  %a = alloca [24 x i8], align 8
; call <str>::chars
  %1 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core3stre5charsCscEnaBunu62E_10algorithms(ptr %a.0, i64 %a.1) #15
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<char>>
  call void @_RINvYNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_6, ptr %_7.0, ptr %_7.1) #15
; invoke <str>::chars
  %2 = invoke { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core3stre5charsCscEnaBunu62E_10algorithms(ptr %b.0, i64 %b.1)
          to label %bb3 unwind label %cleanup

bb46:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr align 8 %_6) #16
          to label %bb47 unwind label %terminate

cleanup:                                          ; preds = %bb3, %start
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb46

bb3:                                              ; preds = %start
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; invoke <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<char>>
  invoke void @_RINvYNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsNtNtNtNtB9_4iter6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_8, ptr %_9.0, ptr %_9.1)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_6, i64 24, i1 false)
  %7 = getelementptr inbounds i8, ptr %_5, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_8, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %a, ptr align 8 %_5, i64 24, i1 false)
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %b, ptr align 8 %8, i64 24, i1 false)
; invoke <alloc::vec::Vec<char>>::len
  %_12 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCscEnaBunu62E_10algorithms(ptr align 8 %b)
          to label %bb5 unwind label %cleanup2

bb44:                                             ; preds = %bb43, %cleanup2
; invoke core::ptr::drop_glue::<alloc::vec::Vec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr align 8 %b) #16
          to label %bb45 unwind label %terminate

cleanup2:                                         ; preds = %bb39, %bb6, %bb5, %bb4
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb44

bb5:                                              ; preds = %bb4
; invoke <core::ops::range::RangeInclusive<usize>>::new
  invoke void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivejE3newCs257F0UrNG3U_14rustc_demangle(ptr sret([24 x i8]) align 8 %_11, i64 0, i64 %_12)
          to label %bb6 unwind label %cleanup2

bb6:                                              ; preds = %bb5
; invoke <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<usize>>
  invoke void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejENtNtNtNtBa_4iter6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %d, ptr align 8 %_11)
          to label %bb7 unwind label %cleanup2

bb7:                                              ; preds = %bb6
; invoke <alloc::vec::Vec<char>>::len
  %_16 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCscEnaBunu62E_10algorithms(ptr align 8 %a)
          to label %bb8 unwind label %cleanup3

bb43:                                             ; preds = %cleanup3
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %d) #16
          to label %bb44 unwind label %terminate

cleanup3:                                         ; preds = %bb36, %bb35, %panic9, %bb33, %panic8, %bb31, %panic7, %bb29, %panic6, %bb27, %panic5, %panic, %bb24, %bb23, %bb21, %bb19, %bb18, %bb17, %bb16, %bb14, %bb38, %bb15, %bb11, %bb9, %bb8, %bb7
  %13 = landingpad { ptr, i32 }
          cleanup
  %14 = extractvalue { ptr, i32 } %13, 0
  %15 = extractvalue { ptr, i32 } %13, 1
  store ptr %14, ptr %0, align 8
  %16 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %15, ptr %16, align 8
  br label %bb43

bb8:                                              ; preds = %bb7
; invoke <core::ops::range::RangeInclusive<usize>>::new
  invoke void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivejE3newCs257F0UrNG3U_14rustc_demangle(ptr sret([24 x i8]) align 8 %_15, i64 1, i64 %_16)
          to label %bb9 unwind label %cleanup3

bb9:                                              ; preds = %bb8
; invoke <core::ops::range::RangeInclusive<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  invoke void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range14RangeInclusivejENtB2_12IntoIterator9into_iterCs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_14, ptr align 8 %_15)
          to label %bb10 unwind label %cleanup3

bb10:                                             ; preds = %bb9
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter, ptr align 8 %_14, i64 24, i1 false)
  br label %bb11

bb11:                                             ; preds = %bb22, %bb10
; invoke <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::next
  %17 = invoke { i64, i64 } @_RNvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range14RangeInclusivejENtNtNtB7_6traits8iterator8Iterator4nextCs2d0hS33vDhg_5gimli(ptr align 8 %iter)
          to label %bb12 unwind label %cleanup3

bb12:                                             ; preds = %bb11
  %18 = extractvalue { i64, i64 } %17, 0
  %19 = extractvalue { i64, i64 } %17, 1
  store i64 %18, ptr %_19, align 8
  %20 = getelementptr inbounds i8, ptr %_19, i64 8
  store i64 %19, ptr %20, align 8
  %_21 = load i64, ptr %_19, align 8
  %21 = getelementptr inbounds i8, ptr %_19, i64 8
  %22 = load i64, ptr %21, align 8
  %23 = trunc nuw i64 %_21 to i1
  br i1 %23, label %bb14, label %bb15

bb14:                                             ; preds = %bb12
  %24 = getelementptr inbounds i8, ptr %_19, i64 8
  %i = load i64, ptr %24, align 8
; invoke <alloc::vec::Vec<usize> as core::ops::index::Index<usize>>::index
  %_24 = invoke align 8 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %d, i64 0, ptr align 8 @alloc_30038872a02853dff7e9d1f3b7db7968)
          to label %bb16 unwind label %cleanup3

bb15:                                             ; preds = %bb12
; invoke <alloc::vec::Vec<char>>::len
  %_73 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCscEnaBunu62E_10algorithms(ptr align 8 %b)
          to label %bb38 unwind label %cleanup3

bb38:                                             ; preds = %bb15
; invoke <alloc::vec::Vec<usize> as core::ops::index::Index<usize>>::index
  %_71 = invoke align 8 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %d, i64 %_73, ptr align 8 @alloc_1f244101ca7e35c6553d1f6e1ba28be6)
          to label %bb39 unwind label %cleanup3

bb39:                                             ; preds = %bb38
  %_0 = load i64, ptr %_71, align 8
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %d)
          to label %bb40 unwind label %cleanup2

bb40:                                             ; preds = %bb39
; invoke core::ptr::drop_glue::<alloc::vec::Vec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr align 8 %b)
          to label %bb41 unwind label %cleanup4

bb45:                                             ; preds = %bb44, %cleanup4
; invoke core::ptr::drop_glue::<alloc::vec::Vec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr align 8 %a) #16
          to label %bb47 unwind label %terminate

cleanup4:                                         ; preds = %bb40
  %25 = landingpad { ptr, i32 }
          cleanup
  %26 = extractvalue { ptr, i32 } %25, 0
  %27 = extractvalue { ptr, i32 } %25, 1
  store ptr %26, ptr %0, align 8
  %28 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %27, ptr %28, align 8
  br label %bb45

bb41:                                             ; preds = %bb40
; call core::ptr::drop_glue::<alloc::vec::Vec<char>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr align 8 %a)
  ret i64 %_0

bb16:                                             ; preds = %bb14
  %29 = load i64, ptr %_24, align 8
  store i64 %29, ptr %prev, align 8
; invoke <alloc::vec::Vec<usize> as core::ops::index::IndexMut<usize>>::index_mut
  %_26 = invoke align 8 ptr @_RNvXse_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index8IndexMutjE9index_mutCscEnaBunu62E_10algorithms(ptr align 8 %d, i64 0, ptr align 8 @alloc_6a023b1094c6eb16d5ccfa1e897366df)
          to label %bb17 unwind label %cleanup3

bb17:                                             ; preds = %bb16
  store i64 %i, ptr %_26, align 8
; invoke <alloc::vec::Vec<char>>::len
  %_30 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCscEnaBunu62E_10algorithms(ptr align 8 %b)
          to label %bb18 unwind label %cleanup3

bb18:                                             ; preds = %bb17
; invoke <core::ops::range::RangeInclusive<usize>>::new
  invoke void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivejE3newCs257F0UrNG3U_14rustc_demangle(ptr sret([24 x i8]) align 8 %_29, i64 1, i64 %_30)
          to label %bb19 unwind label %cleanup3

bb19:                                             ; preds = %bb18
; invoke <core::ops::range::RangeInclusive<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  invoke void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range14RangeInclusivejENtB2_12IntoIterator9into_iterCs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_28, ptr align 8 %_29)
          to label %bb20 unwind label %cleanup3

bb20:                                             ; preds = %bb19
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter1, ptr align 8 %_28, i64 24, i1 false)
  br label %bb21

bb21:                                             ; preds = %bb37, %bb20
; invoke <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::next
  %30 = invoke { i64, i64 } @_RNvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range14RangeInclusivejENtNtNtB7_6traits8iterator8Iterator4nextCs2d0hS33vDhg_5gimli(ptr align 8 %iter1)
          to label %bb22 unwind label %cleanup3

bb22:                                             ; preds = %bb21
  %31 = extractvalue { i64, i64 } %30, 0
  %32 = extractvalue { i64, i64 } %30, 1
  store i64 %31, ptr %_33, align 8
  %33 = getelementptr inbounds i8, ptr %_33, i64 8
  store i64 %32, ptr %33, align 8
  %_35 = load i64, ptr %_33, align 8
  %34 = getelementptr inbounds i8, ptr %_33, i64 8
  %35 = load i64, ptr %34, align 8
  %36 = trunc nuw i64 %_35 to i1
  br i1 %36, label %bb23, label %bb11

bb23:                                             ; preds = %bb22
  %37 = getelementptr inbounds i8, ptr %_33, i64 8
  %j = load i64, ptr %37, align 8
; invoke <alloc::vec::Vec<usize> as core::ops::index::Index<usize>>::index
  %_38 = invoke align 8 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %d, i64 %j, ptr align 8 @alloc_35e68c292623e250f2a024a2d074ed00)
          to label %bb24 unwind label %cleanup3

bb24:                                             ; preds = %bb23
  %t = load i64, ptr %_38, align 8
; invoke <alloc::vec::Vec<usize> as core::ops::index::Index<usize>>::index
  %_44 = invoke align 8 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %d, i64 %j, ptr align 8 @alloc_344c4a9eedccea7f789f54d456d48e26)
          to label %bb25 unwind label %cleanup3

bb25:                                             ; preds = %bb24
  %_43 = load i64, ptr %_44, align 8
  %_46.0 = add i64 %_43, 1
  %_46.1 = icmp ult i64 %_46.0, %_43
  br i1 %_46.1, label %panic, label %bb26

bb26:                                             ; preds = %bb25
  %_52.0 = sub i64 %j, 1
  %_52.1 = icmp ult i64 %j, 1
  br i1 %_52.1, label %panic5, label %bb27

panic:                                            ; preds = %bb25
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_0d3036d5066b52afce94e10193712463) #20
          to label %unreachable unwind label %cleanup3

unreachable:                                      ; preds = %panic9, %panic8, %panic7, %panic6, %panic5, %panic
  unreachable

bb27:                                             ; preds = %bb26
; invoke <alloc::vec::Vec<usize> as core::ops::index::Index<usize>>::index
  %_49 = invoke align 8 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %d, i64 %_52.0, ptr align 8 @alloc_43bead3de7a3f6408d3bda4a3b5d93e0)
          to label %bb28 unwind label %cleanup3

panic5:                                           ; preds = %bb26
; invoke core::panicking::panic_const::panic_const_sub_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_effbfcebd38dd98a42af3a174b625e55) #20
          to label %unreachable unwind label %cleanup3

bb28:                                             ; preds = %bb27
  %_48 = load i64, ptr %_49, align 8
  %_53.0 = add i64 %_48, 1
  %_53.1 = icmp ult i64 %_53.0, %_48
  br i1 %_53.1, label %panic6, label %bb29

bb29:                                             ; preds = %bb28
; invoke <usize as core::cmp::Ord>::min
  %_41 = invoke i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3minB7_(i64 %_46.0, i64 %_53.0)
          to label %bb30 unwind label %cleanup3

panic6:                                           ; preds = %bb28
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_b636263e217c642eda5e010ebf359b1e) #20
          to label %unreachable unwind label %cleanup3

bb30:                                             ; preds = %bb29
  %_55 = load i64, ptr %prev, align 8
  %_62.0 = sub i64 %i, 1
  %_62.1 = icmp ult i64 %i, 1
  br i1 %_62.1, label %panic7, label %bb31

bb31:                                             ; preds = %bb30
; invoke <alloc::vec::Vec<char> as core::ops::index::Index<usize>>::index
  %_59 = invoke align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %a, i64 %_62.0, ptr align 8 @alloc_7562f6df21f699c39bbc01e02e62f638)
          to label %bb32 unwind label %cleanup3

panic7:                                           ; preds = %bb30
; invoke core::panicking::panic_const::panic_const_sub_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_92f0a599d59ec93f39caf1e6f9686f60) #20
          to label %unreachable unwind label %cleanup3

bb32:                                             ; preds = %bb31
  %_58 = load i32, ptr %_59, align 4
  %_67.0 = sub i64 %j, 1
  %_67.1 = icmp ult i64 %j, 1
  br i1 %_67.1, label %panic8, label %bb33

bb33:                                             ; preds = %bb32
; invoke <alloc::vec::Vec<char> as core::ops::index::Index<usize>>::index
  %_64 = invoke align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %b, i64 %_67.0, ptr align 8 @alloc_88911a2c0bb32188e1abe26cdea16430)
          to label %bb34 unwind label %cleanup3

panic8:                                           ; preds = %bb32
; invoke core::panicking::panic_const::panic_const_sub_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_fe18793f53b7b8eac4f8c785aad2ca03) #20
          to label %unreachable unwind label %cleanup3

bb34:                                             ; preds = %bb33
  %_63 = load i32, ptr %_64, align 4
  %_57 = icmp ne i32 %_58, %_63
  %_56 = zext i1 %_57 to i64
  %_68.0 = add i64 %_55, %_56
  %_68.1 = icmp ult i64 %_68.0, %_55
  br i1 %_68.1, label %panic9, label %bb35

bb35:                                             ; preds = %bb34
; invoke <usize as core::cmp::Ord>::min
  %_40 = invoke i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3minB7_(i64 %_41, i64 %_68.0)
          to label %bb36 unwind label %cleanup3

panic9:                                           ; preds = %bb34
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_3f637da660a89abe5c384b401a0f7492) #20
          to label %unreachable unwind label %cleanup3

bb36:                                             ; preds = %bb35
; invoke <alloc::vec::Vec<usize> as core::ops::index::IndexMut<usize>>::index_mut
  %_69 = invoke align 8 ptr @_RNvXse_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index8IndexMutjE9index_mutCscEnaBunu62E_10algorithms(ptr align 8 %d, i64 %j, ptr align 8 @alloc_c4de8564844e5da2d10cb9a3b4c74182)
          to label %bb37 unwind label %cleanup3

bb37:                                             ; preds = %bb36
  store i64 %_40, ptr %_69, align 8
  store i64 %t, ptr %prev, align 8
  br label %bb21

bb13:                                             ; No predecessors!
  unreachable

terminate:                                        ; preds = %bb46, %bb45, %bb44, %bb43
  %38 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb47:                                             ; preds = %bb46, %bb45
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr inbounds i8, ptr %0, i64 8
  %41 = load i32, ptr %40, align 8
  %42 = insertvalue { ptr, i32 } poison, ptr %39, 0
  %43 = insertvalue { ptr, i32 } %42, i32 %41, 1
  resume { ptr, i32 } %43
}

; algorithms::fnv
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCscEnaBunu62E_10algorithms3fnv(ptr %data.0, i64 %data.1) unnamed_addr #0 !guid !325 {
start:
; call <[u8]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterB4_(ptr %data.0, i64 %data.1) #15
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call <core::slice::iter::Iter<u8> as core::iter::traits::iterator::Iterator>::fold::<u32, algorithms::fnv::{closure#0}>
  %_0 = call i32 @_RINvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator4foldmNCNvCscEnaBunu62E_10algorithms3fnv0EB1H_(ptr %_2.0, ptr %_2.1, i32 -2128831035) #15
  ret i32 %_0
}

; algorithms::lcg
; Function Attrs: nonlazybind uwtable
define internal i64 @_RNvCscEnaBunu62E_10algorithms3lcg(ptr align 8 %seed) unnamed_addr #0 !guid !326 {
start:
  %_4 = load i64, ptr %seed, align 8
  %_0.i1 = mul i64 %_4, 6364136223846793005
  %_0.i = add i64 %_0.i1, 1442695040888963407
  store i64 %_0.i, ptr %seed, align 8
  %_5 = load i64, ptr %seed, align 8
  %_0 = lshr i64 %_5, 33
  ret i64 %_0
}

; algorithms::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCscEnaBunu62E_10algorithms4main() unnamed_addr #0 personality ptr @rust_eh_personality !guid !327 {
start:
  %self.i = alloca [8 x i8], align 4
  %0 = alloca [72 x i8], align 8
  %1 = alloca [16 x i8], align 8
  %_258 = alloca [16 x i8], align 8
  %_257 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_254 = alloca [4 x i8], align 4
  %_242 = alloca [8 x i8], align 4
  %iter14 = alloca [24 x i8], align 8
  %_239 = alloca [24 x i8], align 8
  %_238 = alloca [24 x i8], align 8
  %bits = alloca [8 x i8], align 8
  %_234 = alloca [16 x i8], align 8
  %args13 = alloca [16 x i8], align 8
  %iter12 = alloca [8 x i8], align 4
  %b = alloca [8 x i8], align 8
  %a = alloca [8 x i8], align 8
  %_211 = alloca [16 x i8], align 8
  %_210 = alloca [16 x i8], align 8
  %args11 = alloca [32 x i8], align 8
  %_205 = alloca [48 x i8], align 8
  %_204 = alloca [48 x i8], align 8
  %_203 = alloca [4 x i8], align 4
  %_186 = alloca [16 x i8], align 8
  %iter10 = alloca [16 x i8], align 8
  %_179 = alloca [16 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %_175 = alloca [8 x i8], align 1
  %grid = alloca [64 x i8], align 1
  %_171 = alloca [16 x i8], align 8
  %_170 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_165 = alloca [8 x i8], align 8
  %_161 = alloca [8 x i8], align 8
  %_154 = alloca [16 x i8], align 8
  %_153 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %_145 = alloca [8 x i8], align 8
  %mv = alloca [24 x i8], align 8
  %_134 = alloca [16 x i8], align 8
  %_133 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_129 = alloca [4 x i8], align 4
  %_125 = alloca [4 x i8], align 4
  %_118 = alloca [16 x i8], align 8
  %_117 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_115 = alloca [24 x i8], align 8
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [24 x i8], align 8
  %_108 = alloca [4 x i8], align 4
  %_101 = alloca [16 x i8], align 8
  %args5 = alloca [16 x i8], align 8
  %fl = alloca [40 x i8], align 8
  %_89 = alloca [16 x i8], align 8
  %_88 = alloca [16 x i8], align 8
  %_87 = alloca [16 x i8], align 8
  %args4 = alloca [48 x i8], align 8
  %_82 = alloca [8 x i8], align 8
  %_77 = alloca [16 x i8], align 8
  %_73 = alloca [24 x i8], align 8
  %_71 = alloca [1 x i8], align 1
  %args3 = alloca [24 x i8], align 8
  %_60 = alloca [16 x i8], align 8
  %v = alloca [24 x i8], align 8
  %seed = alloca [8 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %args2 = alloca [16 x i8], align 8
  %_53 = alloca [72 x i8], align 8
  %_49 = alloca [72 x i8], align 8
  %_47 = alloca [72 x i8], align 8
  %_42 = alloca [24 x i8], align 8
  %_41 = alloca [24 x i8], align 8
  %_40 = alloca [24 x i8], align 8
  %m = alloca [72 x i8], align 8
  %_36 = alloca [16 x i8], align 8
  %_35 = alloca [16 x i8], align 8
  %args1 = alloca [32 x i8], align 8
  %_30 = alloca [4 x i8], align 4
  %_27 = alloca [4 x i8], align 4
  %_20 = alloca [16 x i8], align 8
  %_19 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %_7 = alloca [8 x i8], align 8
  %p = alloca [24 x i8], align 8
; call core::hint::black_box::<usize>
  %_2 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECscEnaBunu62E_10algorithms(i64 100) #15
; call algorithms::sieve
  call void @_RNvCscEnaBunu62E_10algorithms5sieve(ptr sret([24 x i8]) align 8 %p, i64 %_2)
; invoke <alloc::vec::Vec<usize>>::len
  %2 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE3lenCscEnaBunu62E_10algorithms(ptr align 8 %p)
          to label %bb3 unwind label %cleanup

bb132:                                            ; preds = %bb131, %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %p) #16
          to label %bb133 unwind label %terminate

cleanup:                                          ; preds = %bb2.i, %bb125, %bb27, %bb26, %bb25, %bb24, %bb23, %bb22, %bb21, %bb20, %bb19, %bb18, %bb17, %bb16, %bb15, %bb13, %bb12, %bb11, %bb10, %bb9, %bb8, %bb7, %bb6, %bb5, %panic, %bb3, %start
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %1, align 8
  %6 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb132

bb3:                                              ; preds = %start
  store i64 %2, ptr %_7, align 8
; invoke <alloc::vec::Vec<usize>>::len
  %_15 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE3lenCscEnaBunu62E_10algorithms(ptr align 8 %p)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
  %_17.0 = sub i64 %_15, 5
  %_17.1 = icmp ult i64 %_15, 5
  br i1 %_17.1, label %panic, label %bb5

bb5:                                              ; preds = %bb4
; invoke <alloc::vec::Vec<usize> as core::ops::index::Index<core::ops::range::RangeFrom<usize>>>::index
  %7 = invoke { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBM_5range9RangeFromjEE5indexCscEnaBunu62E_10algorithms(ptr align 8 %p, i64 %_17.0, ptr align 8 @alloc_3dd69aa1e6bd6c491f8ea1d559e0aa1d)
          to label %bb6 unwind label %cleanup

panic:                                            ; preds = %bb4
; invoke core::panicking::panic_const::panic_const_sub_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_fc0dcd0c736cf9722649bc1ad3ee19ab) #20
          to label %unreachable unwind label %cleanup

unreachable:                                      ; preds = %panic25, %panic24, %panic23, %panic21, %panic20, %panic
  unreachable

bb6:                                              ; preds = %bb5
  %_11.0 = extractvalue { ptr, i64 } %7, 0
  %_11.1 = extractvalue { ptr, i64 } %7, 1
  store ptr %_11.0, ptr %_10, align 8, !captures !190
  %8 = getelementptr inbounds i8, ptr %_10, i64 8
  store i64 %_11.1, ptr %8, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_19, ptr align 8 %_7)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
; invoke <core::fmt::rt::Argument>::new_debug::<&[usize]>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSjECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_20, ptr align 8 %_10)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %9 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %_19, i64 16, i1 false)
  %10 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %10, ptr align 8 %_20, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %11 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
  %_4.0 = extractvalue { ptr, ptr } %11, 0
  %_4.1 = extractvalue { ptr, ptr } %11, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_4.0, ptr %_4.1)
          to label %bb10 unwind label %cleanup

bb10:                                             ; preds = %bb9
; invoke core::hint::black_box::<u64>
  %_28 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECscEnaBunu62E_10algorithms(i64 27)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
; invoke algorithms::collatz
  %12 = invoke i32 @_RNvCscEnaBunu62E_10algorithms7collatz(i64 %_28)
          to label %bb12 unwind label %cleanup

bb12:                                             ; preds = %bb11
  store i32 %12, ptr %_27, align 4
; invoke <core::ops::range::Range<u64> as core::iter::traits::iterator::Iterator>::map::<u32, algorithms::collatz>
  %13 = invoke { i64, i64 } @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangeyENtNtNtNtBa_4iter6traits8iterator8Iterator3mapmNvCscEnaBunu62E_10algorithms7collatzEB1x_(i64 1, i64 30)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb12
  %_32.0 = extractvalue { i64, i64 } %13, 0
  %_32.1 = extractvalue { i64, i64 } %13, 1
; invoke <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::max
  %14 = invoke { i32, i32 } @_RNvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBb_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtB9_6traits8iterator8Iterator3maxB1k_(i64 %_32.0, i64 %_32.1)
          to label %bb14 unwind label %cleanup

bb14:                                             ; preds = %bb13
  %_31.0 = extractvalue { i32, i32 } %14, 0
  %_31.1 = extractvalue { i32, i32 } %14, 1
  store i32 %_31.0, ptr %self.i, align 4
  %15 = getelementptr inbounds i8, ptr %self.i, i64 4
  store i32 %_31.1, ptr %15, align 4
  %16 = load i32, ptr %self.i, align 4
  %17 = getelementptr inbounds i8, ptr %self.i, i64 4
  %18 = load i32, ptr %17, align 4
  %_2.i = zext i32 %16 to i64
  %19 = trunc nuw i64 %_2.i to i1
  br i1 %19, label %_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionmE6unwrapCscEnaBunu62E_10algorithms.exit, label %bb2.i

bb2.i:                                            ; preds = %bb14
; invoke core::option::unwrap_failed
  invoke void @_RNvNtCsl10jNU3mE6R_4core6option13unwrap_failed(ptr align 8 @alloc_0b418e65da9c7294cb2b537c556e6d81) #14
          to label %.noexc unwind label %cleanup

.noexc:                                           ; preds = %bb2.i
  unreachable

_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionmE6unwrapCscEnaBunu62E_10algorithms.exit: ; preds = %bb14
  %20 = getelementptr inbounds i8, ptr %self.i, i64 4
  %val.i = load i32, ptr %20, align 4
  br label %bb15

bb15:                                             ; preds = %_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionmE6unwrapCscEnaBunu62E_10algorithms.exit
  store i32 %val.i, ptr %_30, align 4
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_35, ptr align 4 %_27)
          to label %bb16 unwind label %cleanup

bb16:                                             ; preds = %bb15
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_36, ptr align 4 %_30)
          to label %bb17 unwind label %cleanup

bb17:                                             ; preds = %bb16
  %21 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %21, ptr align 8 %_35, i64 16, i1 false)
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_36, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %23 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args1)
          to label %bb18 unwind label %cleanup

bb18:                                             ; preds = %bb17
  %_24.0 = extractvalue { ptr, ptr } %23, 0
  %_24.1 = extractvalue { ptr, ptr } %23, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_24.0, ptr %_24.1)
          to label %bb19 unwind label %cleanup

bb19:                                             ; preds = %bb18
  %24 = getelementptr inbounds nuw i64, ptr %_40, i64 0
  store i64 1, ptr %24, align 8
  %25 = getelementptr inbounds nuw i64, ptr %_40, i64 1
  store i64 2, ptr %25, align 8
  %26 = getelementptr inbounds nuw i64, ptr %_40, i64 2
  store i64 3, ptr %26, align 8
  %27 = getelementptr inbounds nuw i64, ptr %_41, i64 0
  store i64 4, ptr %27, align 8
  %28 = getelementptr inbounds nuw i64, ptr %_41, i64 1
  store i64 5, ptr %28, align 8
  %29 = getelementptr inbounds nuw i64, ptr %_41, i64 2
  store i64 6, ptr %29, align 8
  %30 = getelementptr inbounds nuw i64, ptr %_42, i64 0
  store i64 7, ptr %30, align 8
  %31 = getelementptr inbounds nuw i64, ptr %_42, i64 1
  store i64 8, ptr %31, align 8
  %32 = getelementptr inbounds nuw i64, ptr %_42, i64 2
  store i64 9, ptr %32, align 8
  %33 = getelementptr inbounds nuw [3 x i64], ptr %m, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_40, i64 24, i1 false)
  %34 = getelementptr inbounds nuw [3 x i64], ptr %m, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %34, ptr align 8 %_41, i64 24, i1 false)
  %35 = getelementptr inbounds nuw [3 x i64], ptr %m, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %35, ptr align 8 %_42, i64 24, i1 false)
; invoke algorithms::matmul
  invoke void @_RNvCscEnaBunu62E_10algorithms6matmul(ptr sret([72 x i8]) align 8 %_49, ptr align 8 %m, ptr align 8 %m)
          to label %bb20 unwind label %cleanup

bb20:                                             ; preds = %bb19
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %m, i64 72, i1 false)
; invoke core::hint::black_box::<[[i64; 3]; 3]>
  invoke void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxAAxj3_BF_ECscEnaBunu62E_10algorithms(ptr sret([72 x i8]) align 8 %_53, ptr align 8 %0)
          to label %bb21 unwind label %cleanup

bb21:                                             ; preds = %bb20
; invoke algorithms::matmul
  invoke void @_RNvCscEnaBunu62E_10algorithms6matmul(ptr sret([72 x i8]) align 8 %_47, ptr align 8 %_49, ptr align 8 %_53)
          to label %bb22 unwind label %cleanup

bb22:                                             ; preds = %bb21
; invoke <core::fmt::rt::Argument>::new_debug::<[[i64; 3]; 3]>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAAxj3_BY_ECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_55, ptr align 8 %_47)
          to label %bb23 unwind label %cleanup

bb23:                                             ; preds = %bb22
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_55, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %37 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args2)
          to label %bb24 unwind label %cleanup

bb24:                                             ; preds = %bb23
  %_44.0 = extractvalue { ptr, ptr } %37, 0
  %_44.1 = extractvalue { ptr, ptr } %37, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_44.0, ptr %_44.1)
          to label %bb25 unwind label %cleanup

bb25:                                             ; preds = %bb24
; invoke core::hint::black_box::<u64>
  %38 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECscEnaBunu62E_10algorithms(i64 42)
          to label %bb26 unwind label %cleanup

bb26:                                             ; preds = %bb25
  store i64 %38, ptr %seed, align 8
; invoke <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::map::<u64, algorithms::main::{closure#0}>
  invoke void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangelENtNtNtNtBa_4iter6traits8iterator8Iterator3mapyNCNvCscEnaBunu62E_10algorithms4main0EB1z_(ptr sret([16 x i8]) align 8 %_60, i32 0, i32 200, ptr align 8 %seed)
          to label %bb27 unwind label %cleanup

bb27:                                             ; preds = %bb26
; invoke <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<u64>>
  invoke void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtNtNtBa_6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VecyEEB1n_(ptr sret([24 x i8]) align 8 %v, ptr align 8 %_60)
          to label %bb28 unwind label %cleanup

bb28:                                             ; preds = %bb27
; invoke <alloc::vec::Vec<u64> as core::ops::deref::DerefMut>::deref_mut
  %39 = invoke { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCscEnaBunu62E_10algorithms(ptr align 8 %v)
          to label %bb29 unwind label %cleanup16

bb131:                                            ; preds = %bb130, %bb128, %cleanup16
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u64>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecyEECscEnaBunu62E_10algorithms(ptr align 8 %v) #16
          to label %bb132 unwind label %terminate

cleanup16:                                        ; preds = %bb124, %bb63, %bb62, %bb61, %bb60, %bb59, %bb58, %bb57, %bb56, %bb47, %bb46, %bb45, %bb44, %bb43, %bb42, %bb41, %bb40, %bb39, %bb38, %bb37, %bb36, %bb35, %bb34, %bb33, %bb32, %bb31, %bb30, %bb29, %bb28
  %40 = landingpad { ptr, i32 }
          cleanup
  %41 = extractvalue { ptr, i32 } %40, 0
  %42 = extractvalue { ptr, i32 } %40, 1
  store ptr %41, ptr %1, align 8
  %43 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %42, ptr %43, align 8
  br label %bb131

bb29:                                             ; preds = %bb28
  %_65.0 = extractvalue { ptr, i64 } %39, 0
  %_65.1 = extractvalue { ptr, i64 } %39, 1
; invoke algorithms::quicksort::<u64>
  invoke void @_RINvCscEnaBunu62E_10algorithms9quicksortyEB2_(ptr align 8 %_65.0, i64 %_65.1)
          to label %bb30 unwind label %cleanup16

bb30:                                             ; preds = %bb29
; invoke <alloc::vec::Vec<u64> as core::ops::deref::Deref>::deref
  %44 = invoke { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %v)
          to label %bb31 unwind label %cleanup16

bb31:                                             ; preds = %bb30
  %_74.0 = extractvalue { ptr, i64 } %44, 0
  %_74.1 = extractvalue { ptr, i64 } %44, 1
; invoke <[u64]>::windows
  invoke void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy7windowsCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_73, ptr align 8 %_74.0, i64 %_74.1, i64 2, ptr align 8 @alloc_7e5ee055e10d111bad73c6c929b6d373)
          to label %bb32 unwind label %cleanup16

bb32:                                             ; preds = %bb31
; invoke <core::slice::iter::Windows<u64> as core::iter::traits::iterator::Iterator>::all::<algorithms::main::{closure#1}>
  %45 = invoke zeroext i1 @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter7WindowsyENtNtNtNtBa_4iter6traits8iterator8Iterator3allNCNvCscEnaBunu62E_10algorithms4mains_0EB1B_(ptr align 8 %_73)
          to label %bb33 unwind label %cleanup16

bb33:                                             ; preds = %bb32
  %46 = zext i1 %45 to i8
  store i8 %46, ptr %_71, align 1
; invoke <alloc::vec::Vec<u64> as core::ops::index::Index<core::ops::range::RangeTo<usize>>>::index
  %47 = invoke { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBM_5range7RangeTojEE5indexCscEnaBunu62E_10algorithms(ptr align 8 %v, i64 6, ptr align 8 @alloc_ac6b8349d588d58d90cd0792249d61ee)
          to label %bb34 unwind label %cleanup16

bb34:                                             ; preds = %bb33
  %_78.0 = extractvalue { ptr, i64 } %47, 0
  %_78.1 = extractvalue { ptr, i64 } %47, 1
  store ptr %_78.0, ptr %_77, align 8, !captures !190
  %48 = getelementptr inbounds i8, ptr %_77, i64 8
  store i64 %_78.1, ptr %48, align 8
; invoke <alloc::vec::Vec<u64> as core::ops::deref::Deref>::deref
  %49 = invoke { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %v)
          to label %bb35 unwind label %cleanup16

bb35:                                             ; preds = %bb34
  %_84.0 = extractvalue { ptr, i64 } %49, 0
  %_84.1 = extractvalue { ptr, i64 } %49, 1
; invoke <[u64]>::iter
  %50 = invoke { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSy4iterCs2d0hS33vDhg_5gimli(ptr align 8 %_84.0, i64 %_84.1)
          to label %bb36 unwind label %cleanup16

bb36:                                             ; preds = %bb35
  %_83.0 = extractvalue { ptr, ptr } %50, 0
  %_83.1 = extractvalue { ptr, ptr } %50, 1
; invoke <core::slice::iter::Iter<u64> as core::iter::traits::iterator::Iterator>::sum::<u64>
  %51 = invoke i64 @_RINvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator3sumyECscEnaBunu62E_10algorithms(ptr %_83.0, ptr %_83.1)
          to label %bb37 unwind label %cleanup16

bb37:                                             ; preds = %bb36
  store i64 %51, ptr %_82, align 8
  store ptr %_71, ptr %args3, align 8
  %52 = getelementptr inbounds i8, ptr %args3, i64 8
  store ptr %_77, ptr %52, align 8
  %53 = getelementptr inbounds i8, ptr %args3, i64 16
  store ptr %_82, ptr %53, align 8
  %_266 = load ptr, ptr %args3, align 8
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_87, ptr %_266)
          to label %bb38 unwind label %cleanup16

bb38:                                             ; preds = %bb37
  %54 = getelementptr inbounds i8, ptr %args3, i64 8
  %_267 = load ptr, ptr %54, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<&[u64]>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSyECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_88, ptr align 8 %_267)
          to label %bb39 unwind label %cleanup16

bb39:                                             ; preds = %bb38
  %55 = getelementptr inbounds i8, ptr %args3, i64 16
  %_268 = load ptr, ptr %55, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_89, ptr align 8 %_268)
          to label %bb40 unwind label %cleanup16

bb40:                                             ; preds = %bb39
  %56 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_87, i64 16, i1 false)
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_88, i64 16, i1 false)
  %58 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %58, ptr align 8 %_89, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 3>
  %59 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECscEnaBunu62E_10algorithms(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args4)
          to label %bb41 unwind label %cleanup16

bb41:                                             ; preds = %bb40
  %_68.0 = extractvalue { ptr, ptr } %59, 0
  %_68.1 = extractvalue { ptr, ptr } %59, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_68.0, ptr %_68.1)
          to label %bb42 unwind label %cleanup16

bb42:                                             ; preds = %bb41
  %60 = getelementptr inbounds nuw double, ptr %fl, i64 0
  store double 3.500000e+00, ptr %60, align 8
  %61 = getelementptr inbounds nuw double, ptr %fl, i64 1
  store double -1.000000e+00, ptr %61, align 8
  %62 = getelementptr inbounds nuw double, ptr %fl, i64 2
  store double 2.250000e+00, ptr %62, align 8
  %63 = getelementptr inbounds nuw double, ptr %fl, i64 3
  store double 9.000000e+00, ptr %63, align 8
  %64 = getelementptr inbounds nuw double, ptr %fl, i64 4
  store double 0.000000e+00, ptr %64, align 8
; invoke algorithms::quicksort::<f64>
  invoke void @_RINvCscEnaBunu62E_10algorithms9quicksortdEB2_(ptr align 8 %fl, i64 5)
          to label %bb43 unwind label %cleanup16

bb43:                                             ; preds = %bb42
; invoke <core::fmt::rt::Argument>::new_debug::<[f64; 5]>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAdj5_ECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_101, ptr align 8 %fl)
          to label %bb44 unwind label %cleanup16

bb44:                                             ; preds = %bb43
  %65 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %65, ptr align 8 %_101, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %66 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args5)
          to label %bb45 unwind label %cleanup16

bb45:                                             ; preds = %bb44
  %_97.0 = extractvalue { ptr, ptr } %66, 0
  %_97.1 = extractvalue { ptr, ptr } %66, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_97.0, ptr %_97.1)
          to label %bb46 unwind label %cleanup16

bb46:                                             ; preds = %bb45
; invoke core::hint::black_box::<usize>
  %_109 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECscEnaBunu62E_10algorithms(i64 6)
          to label %bb47 unwind label %cleanup16

bb47:                                             ; preds = %bb46
; invoke <alloc::vec::Vec<usize>>::new
  invoke void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_111)
          to label %bb48 unwind label %cleanup16

bb48:                                             ; preds = %bb47
; invoke algorithms::queens
  %67 = invoke i32 @_RNvCscEnaBunu62E_10algorithms6queens(i64 %_109, i64 0, ptr align 8 %_111)
          to label %bb49 unwind label %cleanup17

bb130:                                            ; preds = %bb129, %cleanup17
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %_111) #16
          to label %bb131 unwind label %terminate

cleanup17:                                        ; preds = %bb55, %bb49, %bb48
  %68 = landingpad { ptr, i32 }
          cleanup
  %69 = extractvalue { ptr, i32 } %68, 0
  %70 = extractvalue { ptr, i32 } %68, 1
  store ptr %69, ptr %1, align 8
  %71 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %70, ptr %71, align 8
  br label %bb130

bb49:                                             ; preds = %bb48
  store i32 %67, ptr %_108, align 4
; invoke <alloc::vec::Vec<usize>>::new
  invoke void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_115)
          to label %bb50 unwind label %cleanup17

bb50:                                             ; preds = %bb49
; invoke algorithms::queens
  %72 = invoke i32 @_RNvCscEnaBunu62E_10algorithms6queens(i64 7, i64 0, ptr align 8 %_115)
          to label %bb51 unwind label %cleanup18

bb129:                                            ; preds = %cleanup18
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %_115) #16
          to label %bb130 unwind label %terminate

cleanup18:                                        ; preds = %bb54, %bb53, %bb52, %bb51, %bb50
  %73 = landingpad { ptr, i32 }
          cleanup
  %74 = extractvalue { ptr, i32 } %73, 0
  %75 = extractvalue { ptr, i32 } %73, 1
  store ptr %74, ptr %1, align 8
  %76 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %75, ptr %76, align 8
  br label %bb129

bb51:                                             ; preds = %bb50
  store i32 %72, ptr %_113, align 4
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_117, ptr align 4 %_108)
          to label %bb52 unwind label %cleanup18

bb52:                                             ; preds = %bb51
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_118, ptr align 4 %_113)
          to label %bb53 unwind label %cleanup18

bb53:                                             ; preds = %bb52
  %77 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %77, ptr align 8 %_117, i64 16, i1 false)
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_118, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %79 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6)
          to label %bb54 unwind label %cleanup18

bb54:                                             ; preds = %bb53
  %_105.0 = extractvalue { ptr, ptr } %79, 0
  %_105.1 = extractvalue { ptr, ptr } %79, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_105.0, ptr %_105.1)
          to label %bb55 unwind label %cleanup18

bb55:                                             ; preds = %bb54
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %_115)
          to label %bb56 unwind label %cleanup17

bb56:                                             ; preds = %bb55
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %_111)
          to label %bb57 unwind label %cleanup16

bb57:                                             ; preds = %bb56
; invoke algorithms::fnv
  %80 = invoke i32 @_RNvCscEnaBunu62E_10algorithms3fnv(ptr @alloc_1a2b9f3efbe1a8edd339fa75af2334ed, i64 5)
          to label %bb58 unwind label %cleanup16

bb58:                                             ; preds = %bb57
  store i32 %80, ptr %_125, align 4
; invoke algorithms::fnv
  %81 = invoke i32 @_RNvCscEnaBunu62E_10algorithms3fnv(ptr @alloc_a66c752209206854431018eae2c84372, i64 100)
          to label %bb59 unwind label %cleanup16

bb59:                                             ; preds = %bb58
  store i32 %81, ptr %_129, align 4
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexmEB7_(ptr sret([16 x i8]) align 8 %_133, ptr align 4 %_125)
          to label %bb60 unwind label %cleanup16

bb60:                                             ; preds = %bb59
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexmEB7_(ptr sret([16 x i8]) align 8 %_134, ptr align 4 %_129)
          to label %bb61 unwind label %cleanup16

bb61:                                             ; preds = %bb60
  %82 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %82, ptr align 8 %_133, i64 16, i1 false)
  %83 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %83, ptr align 8 %_134, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<19, 2>
  %84 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj13_Kj2_ECscEnaBunu62E_10algorithms(ptr @alloc_6473256df3cba3ec5d3325489f1ee0ac, ptr align 8 %args7)
          to label %bb62 unwind label %cleanup16

bb62:                                             ; preds = %bb61
  %_122.0 = extractvalue { ptr, ptr } %84, 0
  %_122.1 = extractvalue { ptr, ptr } %84, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_122.0, ptr %_122.1)
          to label %bb63 unwind label %cleanup16

bb63:                                             ; preds = %bb62
; invoke <alloc::vec::Vec<(u8, u8)>>::new
  invoke void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecThhEE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %mv)
          to label %bb64 unwind label %cleanup16

bb64:                                             ; preds = %bb63
; invoke core::hint::black_box::<u32>
  %_139 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECscEnaBunu62E_10algorithms(i32 6)
          to label %bb65 unwind label %cleanup19

bb128:                                            ; preds = %cleanup19
; invoke core::ptr::drop_glue::<alloc::vec::Vec<(u8, u8)>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecThhEEECscEnaBunu62E_10algorithms(ptr align 8 %mv) #16
          to label %bb131 unwind label %terminate

cleanup19:                                        ; preds = %panic25, %panic24, %panic23, %bb87, %bb84, %panic21, %panic20, %bb123, %bb122, %bb121, %bb120, %bb115, %bb113, %bb112, %bb111, %bb110, %bb108, %bb105, %bb103, %bb102, %bb101, %bb100, %bb99, %bb98, %bb97, %bb96, %bb95, %bb94, %bb81, %repeat_loop_next, %bb78, %bb77, %bb76, %bb75, %bb74, %bb73, %bb72, %bb71, %bb70, %bb69, %bb68, %bb67, %bb66, %bb65, %bb64
  %85 = landingpad { ptr, i32 }
          cleanup
  %86 = extractvalue { ptr, i32 } %85, 0
  %87 = extractvalue { ptr, i32 } %85, 1
  store ptr %86, ptr %1, align 8
  %88 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %87, ptr %88, align 8
  br label %bb128

bb65:                                             ; preds = %bb64
; invoke algorithms::hanoi
  invoke void @_RNvCscEnaBunu62E_10algorithms5hanoi(i32 %_139, i8 1, i8 3, i8 2, ptr align 8 %mv)
          to label %bb66 unwind label %cleanup19

bb66:                                             ; preds = %bb65
; invoke <alloc::vec::Vec<(u8, u8)>>::len
  %89 = invoke i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecThhEE3lenCscEnaBunu62E_10algorithms(ptr align 8 %mv)
          to label %bb67 unwind label %cleanup19

bb67:                                             ; preds = %bb66
  store i64 %89, ptr %_145, align 8
; invoke <alloc::vec::Vec<(u8, u8)> as core::ops::index::Index<core::ops::range::RangeTo<usize>>>::index
  %90 = invoke { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBP_5range7RangeTojEE5indexCscEnaBunu62E_10algorithms(ptr align 8 %mv, i64 4, ptr align 8 @alloc_b74eb839d19cdfd196e850aa30197964)
          to label %bb68 unwind label %cleanup19

bb68:                                             ; preds = %bb67
  %_149.0 = extractvalue { ptr, i64 } %90, 0
  %_149.1 = extractvalue { ptr, i64 } %90, 1
  store ptr %_149.0, ptr %_148, align 8, !captures !190
  %91 = getelementptr inbounds i8, ptr %_148, i64 8
  store i64 %_149.1, ptr %91, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_153, ptr align 8 %_145)
          to label %bb69 unwind label %cleanup19

bb69:                                             ; preds = %bb68
; invoke <core::fmt::rt::Argument>::new_debug::<&[(u8, u8)]>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugRSThhEECscEnaBunu62E_10algorithms(ptr sret([16 x i8]) align 8 %_154, ptr align 8 %_148)
          to label %bb70 unwind label %cleanup19

bb70:                                             ; preds = %bb69
  %92 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %92, ptr align 8 %_153, i64 16, i1 false)
  %93 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %93, ptr align 8 %_154, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %94 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8)
          to label %bb71 unwind label %cleanup19

bb71:                                             ; preds = %bb70
  %_142.0 = extractvalue { ptr, ptr } %94, 0
  %_142.1 = extractvalue { ptr, ptr } %94, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_142.0, ptr %_142.1)
          to label %bb72 unwind label %cleanup19

bb72:                                             ; preds = %bb71
; invoke algorithms::edit_distance
  %95 = invoke i64 @_RNvCscEnaBunu62E_10algorithms13edit_distance(ptr @alloc_302a407efbd8750c84addd68544775ce, i64 6, ptr @alloc_1f9f2d6055fba255e78e97b42c2847ad, i64 7)
          to label %bb73 unwind label %cleanup19

bb73:                                             ; preds = %bb72
  store i64 %95, ptr %_161, align 8
; invoke core::hint::black_box::<&str>
  %96 = invoke { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxReECscEnaBunu62E_10algorithms(ptr @alloc_13af184f83ea529683dab3456027e412, i64 3)
          to label %bb74 unwind label %cleanup19

bb74:                                             ; preds = %bb73
  %_167.0 = extractvalue { ptr, i64 } %96, 0
  %_167.1 = extractvalue { ptr, i64 } %96, 1
; invoke algorithms::edit_distance
  %97 = invoke i64 @_RNvCscEnaBunu62E_10algorithms13edit_distance(ptr inttoptr (i64 1 to ptr), i64 0, ptr %_167.0, i64 %_167.1)
          to label %bb75 unwind label %cleanup19

bb75:                                             ; preds = %bb74
  store i64 %97, ptr %_165, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_170, ptr align 8 %_161)
          to label %bb76 unwind label %cleanup19

bb76:                                             ; preds = %bb75
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_171, ptr align 8 %_165)
          to label %bb77 unwind label %cleanup19

bb77:                                             ; preds = %bb76
  %98 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %98, ptr align 8 %_170, i64 16, i1 false)
  %99 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %99, ptr align 8 %_171, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %100 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9)
          to label %bb78 unwind label %cleanup19

bb78:                                             ; preds = %bb77
  %_158.0 = extractvalue { ptr, ptr } %100, 0
  %_158.1 = extractvalue { ptr, ptr } %100, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_158.0, ptr %_158.1)
          to label %bb79 unwind label %cleanup19

bb79:                                             ; preds = %bb78
  call void @llvm.memset.p0.i64(ptr align 1 %_175, i8 0, i64 8, i1 false)
  %101 = getelementptr inbounds nuw [8 x i8], ptr %grid, i64 0
  %102 = getelementptr inbounds nuw [8 x i8], ptr %grid, i64 8
  br label %repeat_loop_header

repeat_loop_header:                               ; preds = %repeat_loop_body, %bb79
  %103 = phi ptr [ %101, %bb79 ], [ %105, %repeat_loop_body ]
  %104 = icmp ne ptr %103, %102
  br i1 %104, label %repeat_loop_body, label %repeat_loop_next

repeat_loop_body:                                 ; preds = %repeat_loop_header
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %103, ptr align 1 %_175, i64 8, i1 false)
  %105 = getelementptr inbounds [8 x i8], ptr %103, i64 1
  br label %repeat_loop_header

repeat_loop_next:                                 ; preds = %repeat_loop_header
; invoke <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %106 = invoke { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 8)
          to label %bb80 unwind label %cleanup19

bb80:                                             ; preds = %repeat_loop_next
  %_176.0 = extractvalue { i64, i64 } %106, 0
  %_176.1 = extractvalue { i64, i64 } %106, 1
  store i64 %_176.0, ptr %iter, align 8
  %107 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_176.1, ptr %107, align 8
  br label %bb81

bb81:                                             ; preds = %bb88, %bb80
; invoke <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %108 = invoke { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter)
          to label %bb82 unwind label %cleanup19

bb82:                                             ; preds = %bb81
  %109 = extractvalue { i64, i64 } %108, 0
  %110 = extractvalue { i64, i64 } %108, 1
  store i64 %109, ptr %_179, align 8
  %111 = getelementptr inbounds i8, ptr %_179, i64 8
  store i64 %110, ptr %111, align 8
  %_181 = load i64, ptr %_179, align 8
  %112 = getelementptr inbounds i8, ptr %_179, i64 8
  %113 = load i64, ptr %112, align 8
  %114 = trunc nuw i64 %_181 to i1
  br i1 %114, label %bb84, label %bb85

bb84:                                             ; preds = %bb82
  %115 = getelementptr inbounds i8, ptr %_179, i64 8
  %i22 = load i64, ptr %115, align 8
; invoke <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %116 = invoke { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 8)
          to label %bb86 unwind label %cleanup19

bb85:                                             ; preds = %bb82
  br label %bb94

bb94:                                             ; preds = %bb85
  %_199 = getelementptr inbounds nuw [8 x i8], ptr %grid, i64 5
; invoke <[[u8; 8]]>::iter
  %117 = invoke { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAhj8_4iterCscEnaBunu62E_10algorithms(ptr %grid, i64 8)
          to label %bb95 unwind label %cleanup19

bb95:                                             ; preds = %bb94
  %_206.0 = extractvalue { ptr, ptr } %117, 0
  %_206.1 = extractvalue { ptr, ptr } %117, 1
; invoke <core::slice::iter::Iter<[u8; 8]> as core::iter::traits::iterator::Iterator>::flatten
  invoke void @_RNvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterAhj8_ENtNtNtNtB9_4iter6traits8iterator8Iterator7flattenCscEnaBunu62E_10algorithms(ptr sret([48 x i8]) align 8 %_205, ptr %_206.0, ptr %_206.1)
          to label %bb96 unwind label %cleanup19

bb96:                                             ; preds = %bb95
; invoke <core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>> as core::iter::traits::iterator::Iterator>::map::<u32, algorithms::main::{closure#2}>
  invoke void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters7flatten7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENtNtNtBa_6traits8iterator8Iterator3mapmNCNvCscEnaBunu62E_10algorithms4mains0_0EB2d_(ptr sret([48 x i8]) align 8 %_204, ptr align 8 %_205)
          to label %bb97 unwind label %cleanup19

bb97:                                             ; preds = %bb96
; invoke <core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}> as core::iter::traits::iterator::Iterator>::sum::<u32>
  %118 = invoke i32 @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtB8_7flatten7FlattenINtNtNtBc_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0ENtNtNtBa_6traits8iterator8Iterator3summEB1Q_(ptr align 8 %_204)
          to label %bb98 unwind label %cleanup19

bb98:                                             ; preds = %bb97
  store i32 %118, ptr %_203, align 4
; invoke <core::fmt::rt::Argument>::new_debug::<[u8; 8]>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAhj8_ECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8 %_210, ptr %_199)
          to label %bb99 unwind label %cleanup19

bb99:                                             ; preds = %bb98
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_211, ptr align 4 %_203)
          to label %bb100 unwind label %cleanup19

bb100:                                            ; preds = %bb99
  %119 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %119, ptr align 8 %_210, i64 16, i1 false)
  %120 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %120, ptr align 8 %_211, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %121 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args11)
          to label %bb101 unwind label %cleanup19

bb101:                                            ; preds = %bb100
  %_197.0 = extractvalue { ptr, ptr } %121, 0
  %_197.1 = extractvalue { ptr, ptr } %121, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_197.0, ptr %_197.1)
          to label %bb102 unwind label %cleanup19

bb102:                                            ; preds = %bb101
; invoke core::hint::black_box::<u64>
  %_217 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECscEnaBunu62E_10algorithms(i64 0)
          to label %bb103 unwind label %cleanup19

bb103:                                            ; preds = %bb102
  store i64 %_217, ptr %a, align 8
  store i64 1, ptr %b, align 8
; invoke <core::ops::range::Range<i32> as core::iter::traits::collect::IntoIterator>::into_iter
  %122 = invoke { i32, i32 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangelENtB2_12IntoIterator9into_iterCsddYV2PBJW9h_3std(i32 0, i32 90)
          to label %bb104 unwind label %cleanup19

bb104:                                            ; preds = %bb103
  %_218.0 = extractvalue { i32, i32 } %122, 0
  %_218.1 = extractvalue { i32, i32 } %122, 1
  store i32 %_218.0, ptr %iter12, align 4
  %123 = getelementptr inbounds i8, ptr %iter12, i64 4
  store i32 %_218.1, ptr %123, align 4
  br label %bb105

bb105:                                            ; preds = %bb109, %bb104
; invoke <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::next
  %124 = invoke { i32, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangelENtNtNtB7_6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 4 %iter12)
          to label %bb106 unwind label %cleanup19

bb106:                                            ; preds = %bb105
  %_221.0 = extractvalue { i32, i32 } %124, 0
  %_221.1 = extractvalue { i32, i32 } %124, 1
  %_223 = zext i32 %_221.0 to i64
  %125 = trunc nuw i64 %_223 to i1
  br i1 %125, label %bb107, label %bb108

bb107:                                            ; preds = %bb106
  %_225 = load i64, ptr %a, align 8
  %_226 = load i64, ptr %b, align 8
  %_227.0 = add i64 %_225, %_226
  %_227.1 = icmp ult i64 %_227.0, %_225
  br i1 %_227.1, label %panic21, label %bb109

bb108:                                            ; preds = %bb106
; invoke <core::fmt::rt::Argument>::new_display::<u64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_234, ptr align 8 %a)
          to label %bb110 unwind label %cleanup19

bb110:                                            ; preds = %bb108
  %126 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %126, ptr align 8 %_234, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %127 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args13)
          to label %bb111 unwind label %cleanup19

bb111:                                            ; preds = %bb110
  %_230.0 = extractvalue { ptr, ptr } %127, 0
  %_230.1 = extractvalue { ptr, ptr } %127, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_230.0, ptr %_230.1)
          to label %bb112 unwind label %cleanup19

bb112:                                            ; preds = %bb111
  store i64 0, ptr %bits, align 8
; invoke <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::step_by
  invoke void @_RNvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangelENtNtNtNtB9_4iter6traits8iterator8Iterator7step_byCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_239, i32 0, i32 64, i64 3)
          to label %bb113 unwind label %cleanup19

bb113:                                            ; preds = %bb112
; invoke <core::iter::adapters::step_by::StepBy<core::ops::range::Range<i32>> as core::iter::traits::collect::IntoIterator>::into_iter
  invoke void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters7step_by6StepByINtNtNtB8_3ops5range5RangelEENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_238, ptr align 8 %_239)
          to label %bb114 unwind label %cleanup19

bb114:                                            ; preds = %bb113
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter14, ptr align 8 %_238, i64 24, i1 false)
  br label %bb115

bb115:                                            ; preds = %bb119, %bb114
; invoke <core::iter::adapters::step_by::StepBy<core::ops::range::Range<i32>> as core::iter::traits::iterator::Iterator>::next
  %128 = invoke { i32, i32 } @_RNvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7step_byINtB4_6StepByINtNtNtBa_3ops5range5RangelEENtNtNtB8_6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %iter14)
          to label %bb116 unwind label %cleanup19

bb116:                                            ; preds = %bb115
  %129 = extractvalue { i32, i32 } %128, 0
  %130 = extractvalue { i32, i32 } %128, 1
  store i32 %129, ptr %_242, align 4
  %131 = getelementptr inbounds i8, ptr %_242, i64 4
  store i32 %130, ptr %131, align 4
  %132 = load i32, ptr %_242, align 4
  %133 = getelementptr inbounds i8, ptr %_242, i64 4
  %134 = load i32, ptr %133, align 4
  %_244 = zext i32 %132 to i64
  %135 = trunc nuw i64 %_244 to i1
  br i1 %135, label %bb117, label %bb118

bb117:                                            ; preds = %bb116
  %136 = getelementptr inbounds i8, ptr %_242, i64 4
  %i = load i32, ptr %136, align 4
  %_248 = icmp ult i32 %i, 64
  br i1 %_248, label %bb119, label %panic20

bb118:                                            ; preds = %bb116
  %_255 = load i64, ptr %bits, align 8
  %137 = call i64 @llvm.ctpop.i64(i64 %_255)
  %_0.i = trunc i64 %137 to i32
  br label %bb120

bb120:                                            ; preds = %bb118
  store i32 %_0.i, ptr %_254, align 4
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs2d0hS33vDhg_5gimli(ptr sret([16 x i8]) align 8 %_257, ptr align 8 %bits)
          to label %bb121 unwind label %cleanup19

bb121:                                            ; preds = %bb120
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_258, ptr align 4 %_254)
          to label %bb122 unwind label %cleanup19

bb122:                                            ; preds = %bb121
  %138 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %138, ptr align 8 %_257, i64 16, i1 false)
  %139 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %139, ptr align 8 %_258, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<11, 2>
  %140 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj2_ECscEnaBunu62E_10algorithms(ptr @alloc_a4c2357cd563880631800cfb72d07d96, ptr align 8 %args15)
          to label %bb123 unwind label %cleanup19

bb123:                                            ; preds = %bb122
  %_250.0 = extractvalue { ptr, ptr } %140, 0
  %_250.1 = extractvalue { ptr, ptr } %140, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_250.0, ptr %_250.1)
          to label %bb124 unwind label %cleanup19

bb124:                                            ; preds = %bb123
; invoke core::ptr::drop_glue::<alloc::vec::Vec<(u8, u8)>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecThhEEECscEnaBunu62E_10algorithms(ptr align 8 %mv)
          to label %bb125 unwind label %cleanup16

bb125:                                            ; preds = %bb124
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u64>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecyEECscEnaBunu62E_10algorithms(ptr align 8 %v)
          to label %bb126 unwind label %cleanup

bb126:                                            ; preds = %bb125
; call core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %p)
  ret void

bb119:                                            ; preds = %bb117
  %141 = and i32 %i, 63
  %142 = zext i32 %141 to i64
  %_246 = shl i64 1, %142
  %143 = load i64, ptr %bits, align 8
  %144 = or i64 %143, %_246
  store i64 %144, ptr %bits, align 8
  br label %bb115

panic20:                                          ; preds = %bb117
; invoke core::panicking::panic_const::panic_const_shl_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_dfba7a9f04fbaa6390bf02c689ab4249) #20
          to label %unreachable unwind label %cleanup19

bb109:                                            ; preds = %bb107
  %_228 = load i64, ptr %b, align 8
  store i64 %_228, ptr %a, align 8
  store i64 %_227.0, ptr %b, align 8
  br label %bb105

panic21:                                          ; preds = %bb107
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_61553a8974d11d1c2bba665d1fa65efd) #20
          to label %unreachable unwind label %cleanup19

bb86:                                             ; preds = %bb84
  %_183.0 = extractvalue { i64, i64 } %116, 0
  %_183.1 = extractvalue { i64, i64 } %116, 1
  store i64 %_183.0, ptr %iter10, align 8
  %145 = getelementptr inbounds i8, ptr %iter10, i64 8
  store i64 %_183.1, ptr %145, align 8
  br label %bb87

bb87:                                             ; preds = %bb93, %bb86
; invoke <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %146 = invoke { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter10)
          to label %bb88 unwind label %cleanup19

bb88:                                             ; preds = %bb87
  %147 = extractvalue { i64, i64 } %146, 0
  %148 = extractvalue { i64, i64 } %146, 1
  store i64 %147, ptr %_186, align 8
  %149 = getelementptr inbounds i8, ptr %_186, i64 8
  store i64 %148, ptr %149, align 8
  %_188 = load i64, ptr %_186, align 8
  %150 = getelementptr inbounds i8, ptr %_186, i64 8
  %151 = load i64, ptr %150, align 8
  %152 = trunc nuw i64 %_188 to i1
  br i1 %152, label %bb89, label %bb81

bb89:                                             ; preds = %bb88
  %153 = getelementptr inbounds i8, ptr %_186, i64 8
  %j = load i64, ptr %153, align 8
  %154 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %i22, i64 %j)
  %_192.0 = extractvalue { i64, i1 } %154, 0
  %_192.1 = extractvalue { i64, i1 } %154, 1
  br i1 %_192.1, label %panic23, label %bb90

bb90:                                             ; preds = %bb89
  br label %bb91

panic23:                                          ; preds = %bb89
; invoke core::panicking::panic_const::panic_const_mul_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_844d47394c74c675e427a77bd173d726) #20
          to label %unreachable unwind label %cleanup19

bb91:                                             ; preds = %bb90
  %_190 = urem i64 %_192.0, 7
  %_194 = icmp ult i64 %i22, 8
  br i1 %_194, label %bb92, label %panic24

bb92:                                             ; preds = %bb91
  %_195 = icmp ult i64 %j, 8
  br i1 %_195, label %bb93, label %panic25

panic24:                                          ; preds = %bb91
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %i22, i64 8, ptr align 8 @alloc_e0a963c8c52418d41875d5af6eb67898) #20
          to label %unreachable unwind label %cleanup19

bb93:                                             ; preds = %bb92
  %155 = getelementptr inbounds nuw [8 x i8], ptr %grid, i64 %i22
  %156 = getelementptr inbounds nuw i8, ptr %155, i64 %j
  %157 = trunc i64 %_190 to i8
  store i8 %157, ptr %156, align 1
  br label %bb87

panic25:                                          ; preds = %bb92
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %j, i64 8, ptr align 8 @alloc_e0a963c8c52418d41875d5af6eb67898) #20
          to label %unreachable unwind label %cleanup19

bb83:                                             ; No predecessors!
  unreachable

terminate:                                        ; preds = %bb132, %bb131, %bb130, %bb129, %bb128
  %158 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb133:                                            ; preds = %bb132
  %159 = load ptr, ptr %1, align 8
  %160 = getelementptr inbounds i8, ptr %1, i64 8
  %161 = load i32, ptr %160, align 8
  %162 = insertvalue { ptr, i32 } poison, ptr %159, 0
  %163 = insertvalue { ptr, i32 } %162, i32 %161, 1
  resume { ptr, i32 } %163
}

; algorithms::hanoi
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCscEnaBunu62E_10algorithms5hanoi(i32 %n, i8 %from, i8 %to, i8 %via, ptr align 8 %moves) unnamed_addr #0 !guid !328 {
start:
  %_6 = icmp eq i32 %n, 0
  br i1 %_6, label %bb6, label %bb1

bb1:                                              ; preds = %start
  %_9.0 = sub i32 %n, 1
  %_9.1 = icmp ult i32 %n, 1
  br i1 %_9.1, label %panic, label %bb2

bb6:                                              ; preds = %bb5, %start
  ret void

bb2:                                              ; preds = %bb1
; call algorithms::hanoi
  call void @_RNvCscEnaBunu62E_10algorithms5hanoi(i32 %_9.0, i8 %from, i8 %via, i8 %to, ptr align 8 %moves)
; call <alloc::vec::Vec<(u8, u8)>>::push
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEE4pushCscEnaBunu62E_10algorithms(ptr align 8 %moves, i8 %from, i8 %to) #15
  %_14.0 = sub i32 %n, 1
  %_14.1 = icmp ult i32 %n, 1
  br i1 %_14.1, label %panic1, label %bb5

panic:                                            ; preds = %bb1
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_3f68606c5ef51f8055afb7a1e5d4ad99) #14
  unreachable

bb5:                                              ; preds = %bb2
; call algorithms::hanoi
  call void @_RNvCscEnaBunu62E_10algorithms5hanoi(i32 %_14.0, i8 %via, i8 %to, i8 %from, ptr align 8 %moves)
  br label %bb6

panic1:                                           ; preds = %bb2
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_82676f12db8c9acfc822abd244b147f7) #14
  unreachable
}

; algorithms::sieve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCscEnaBunu62E_10algorithms5sieve(ptr sret([24 x i8]) align 8 %_0, i64 %n) unnamed_addr #0 personality ptr @rust_eh_personality !guid !329 {
start:
  %0 = alloca [16 x i8], align 8
  %_33 = alloca [24 x i8], align 8
  %_32 = alloca [32 x i8], align 8
  %j = alloca [8 x i8], align 8
  %i = alloca [8 x i8], align 8
  %p = alloca [24 x i8], align 8
  %_4.0 = add i64 %n, 1
  %_4.1 = icmp ult i64 %_4.0, %n
  br i1 %_4.1, label %panic, label %bb1

bb1:                                              ; preds = %start
; call alloc::vec::from_elem::<bool>
  call void @_RINvNtCs7CppTae75M1_5alloc3vec9from_elembECscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %p, i1 zeroext true, i64 %_4.0)
; invoke <alloc::vec::Vec<bool> as core::ops::index::IndexMut<usize>>::index_mut
  %_5 = invoke ptr @_RNvXse_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbEINtNtNtCsl10jNU3mE6R_4core3ops5index8IndexMutjE9index_mutCscEnaBunu62E_10algorithms(ptr align 8 %p, i64 0, ptr align 8 @alloc_77c67f70dae2105acf749b9d81eda6bb)
          to label %bb3 unwind label %cleanup

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_2f36b7f353d1ebc57656aead9d638748) #14
  unreachable

bb24:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<bool>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecbEECscEnaBunu62E_10algorithms(ptr align 8 %p) #16
          to label %bb25 unwind label %terminate

cleanup:                                          ; preds = %panic4, %bb14, %panic3, %panic2, %bb9, %bb21, %bb20, %bb19, %panic1, %bb4, %bb1
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb24

bb3:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %_7 = icmp uge i64 %n, 1
  br i1 %_7, label %bb4, label %bb6

bb6:                                              ; preds = %bb5, %bb3
  store i64 2, ptr %i, align 8
  br label %bb7

bb4:                                              ; preds = %bb3
; invoke <alloc::vec::Vec<bool> as core::ops::index::IndexMut<usize>>::index_mut
  %_8 = invoke ptr @_RNvXse_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbEINtNtNtCsl10jNU3mE6R_4core3ops5index8IndexMutjE9index_mutCscEnaBunu62E_10algorithms(ptr align 8 %p, i64 1, ptr align 8 @alloc_baa66a3d08576406f722455aac3420c1)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_8, align 1
  br label %bb6

bb7:                                              ; preds = %bb18, %bb6
  %_13 = load i64, ptr %i, align 8
  %_14 = load i64, ptr %i, align 8
  %5 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_13, i64 %_14)
  %_15.0 = extractvalue { i64, i1 } %5, 0
  %_15.1 = extractvalue { i64, i1 } %5, 1
  br i1 %_15.1, label %panic1, label %bb8

bb8:                                              ; preds = %bb7
  %_11 = icmp ule i64 %_15.0, %n
  br i1 %_11, label %bb9, label %bb19

panic1:                                           ; preds = %bb7
; invoke core::panicking::panic_const::panic_const_mul_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_752c0e18b7acdf7a8afc1c9f37ab6e61) #20
          to label %unreachable unwind label %cleanup

unreachable:                                      ; preds = %panic4, %panic3, %panic2, %panic1
  unreachable

bb19:                                             ; preds = %bb8
; invoke <core::ops::range::RangeInclusive<usize>>::new
  invoke void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivejE3newCs257F0UrNG3U_14rustc_demangle(ptr sret([24 x i8]) align 8 %_33, i64 0, i64 %n)
          to label %bb20 unwind label %cleanup

bb9:                                              ; preds = %bb8
  %_19 = load i64, ptr %i, align 8
; invoke <alloc::vec::Vec<bool> as core::ops::index::Index<usize>>::index
  %_17 = invoke ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %p, i64 %_19, ptr align 8 @alloc_2799c0c10378e64b12cbbf20aaaef37b)
          to label %bb10 unwind label %cleanup

bb20:                                             ; preds = %bb19
; invoke <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::filter::<algorithms::sieve::{closure#0}>
  invoke void @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejENtNtNtNtBa_4iter6traits8iterator8Iterator6filterNCNvCscEnaBunu62E_10algorithms5sieve0EB1L_(ptr sret([32 x i8]) align 8 %_32, ptr align 8 %_33, ptr align 8 %p)
          to label %bb21 unwind label %cleanup

bb21:                                             ; preds = %bb20
; invoke <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::iterator::Iterator>::collect::<alloc::vec::Vec<usize>>
  invoke void @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtBc_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtNtNtBa_6traits8iterator8Iterator7collectINtNtCs7CppTae75M1_5alloc3vec3VecjEEB1D_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_32)
          to label %bb22 unwind label %cleanup

bb22:                                             ; preds = %bb21
; call core::ptr::drop_glue::<alloc::vec::Vec<bool>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecbEECscEnaBunu62E_10algorithms(ptr align 8 %p)
  ret void

bb10:                                             ; preds = %bb9
  %6 = load i8, ptr %_17, align 1
  %_16 = trunc nuw i8 %6 to i1
  br i1 %_16, label %bb11, label %bb17

bb17:                                             ; preds = %bb13, %bb10
  %7 = load i64, ptr %i, align 8
  %_31.0 = add i64 %7, 1
  %_31.1 = icmp ult i64 %_31.0, %7
  br i1 %_31.1, label %panic3, label %bb18

bb11:                                             ; preds = %bb10
  %_21 = load i64, ptr %i, align 8
  %_22 = load i64, ptr %i, align 8
  %8 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_21, i64 %_22)
  %_23.0 = extractvalue { i64, i1 } %8, 0
  %_23.1 = extractvalue { i64, i1 } %8, 1
  br i1 %_23.1, label %panic2, label %bb12

bb12:                                             ; preds = %bb11
  store i64 %_23.0, ptr %j, align 8
  br label %bb13

panic2:                                           ; preds = %bb11
; invoke core::panicking::panic_const::panic_const_mul_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_dc6bd9ef32bef3583a8a50d96ff787fa) #20
          to label %unreachable unwind label %cleanup

bb13:                                             ; preds = %bb16, %bb12
  %_25 = load i64, ptr %j, align 8
  %_24 = icmp ule i64 %_25, %n
  br i1 %_24, label %bb14, label %bb17

bb14:                                             ; preds = %bb13
  %_28 = load i64, ptr %j, align 8
; invoke <alloc::vec::Vec<bool> as core::ops::index::IndexMut<usize>>::index_mut
  %_26 = invoke ptr @_RNvXse_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbEINtNtNtCsl10jNU3mE6R_4core3ops5index8IndexMutjE9index_mutCscEnaBunu62E_10algorithms(ptr align 8 %p, i64 %_28, ptr align 8 @alloc_749b606d3fd2333e3362f86c92ea02f0)
          to label %bb15 unwind label %cleanup

bb18:                                             ; preds = %bb17
  store i64 %_31.0, ptr %i, align 8
  br label %bb7

panic3:                                           ; preds = %bb17
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_fad89990a3b2c6841a5c0d2fe72b5ca9) #20
          to label %unreachable unwind label %cleanup

bb15:                                             ; preds = %bb14
  store i8 0, ptr %_26, align 1
  %_29 = load i64, ptr %i, align 8
  %9 = load i64, ptr %j, align 8
  %_30.0 = add i64 %9, %_29
  %_30.1 = icmp ult i64 %_30.0, %9
  br i1 %_30.1, label %panic4, label %bb16

bb16:                                             ; preds = %bb15
  store i64 %_30.0, ptr %j, align 8
  br label %bb13

panic4:                                           ; preds = %bb15
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_50eb1b4837dc463244be4029579bca1d) #20
          to label %unreachable unwind label %cleanup

terminate:                                        ; preds = %bb24
  %10 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb25:                                             ; preds = %bb24
  %11 = load ptr, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  %13 = load i32, ptr %12, align 8
  %14 = insertvalue { ptr, i32 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i32 } %14, i32 %13, 1
  resume { ptr, i32 } %15
}

; algorithms::matmul
; Function Attrs: nonlazybind uwtable
define internal void @_RNvCscEnaBunu62E_10algorithms6matmul(ptr sret([72 x i8]) align 8 %_0, ptr align 8 %a, ptr align 8 %b) unnamed_addr #0 !guid !330 {
start:
  %_22 = alloca [16 x i8], align 8
  %iter2 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %iter1 = alloca [16 x i8], align 8
  %_8 = alloca [16 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %_4 = alloca [24 x i8], align 8
  %c = alloca [72 x i8], align 8
  call void @llvm.memset.p0.i64(ptr align 8 %_4, i8 0, i64 24, i1 false)
  %0 = getelementptr inbounds nuw [3 x i64], ptr %c, i64 0
  %1 = getelementptr inbounds nuw [3 x i64], ptr %c, i64 3
  br label %repeat_loop_header

repeat_loop_header:                               ; preds = %repeat_loop_body, %start
  %2 = phi ptr [ %0, %start ], [ %4, %repeat_loop_body ]
  %3 = icmp ne ptr %2, %1
  br i1 %3, label %repeat_loop_body, label %repeat_loop_next

repeat_loop_body:                                 ; preds = %repeat_loop_header
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %_4, i64 24, i1 false)
  %4 = getelementptr inbounds [3 x i64], ptr %2, i64 1
  br label %repeat_loop_header

repeat_loop_next:                                 ; preds = %repeat_loop_header
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %5 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 3) #15
  %_5.0 = extractvalue { i64, i64 } %5, 0
  %_5.1 = extractvalue { i64, i64 } %5, 1
  store i64 %_5.0, ptr %iter, align 8
  %6 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_5.1, ptr %6, align 8
  br label %bb2

bb2:                                              ; preds = %bb8, %repeat_loop_next
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %7 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #15
  %8 = extractvalue { i64, i64 } %7, 0
  %9 = extractvalue { i64, i64 } %7, 1
  store i64 %8, ptr %_8, align 8
  %10 = getelementptr inbounds i8, ptr %_8, i64 8
  store i64 %9, ptr %10, align 8
  %_10 = load i64, ptr %_8, align 8
  %11 = getelementptr inbounds i8, ptr %_8, i64 8
  %12 = load i64, ptr %11, align 8
  %13 = trunc nuw i64 %_10 to i1
  br i1 %13, label %bb5, label %bb6

bb5:                                              ; preds = %bb2
  %14 = getelementptr inbounds i8, ptr %_8, i64 8
  %i = load i64, ptr %14, align 8
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %15 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 3) #15
  %_12.0 = extractvalue { i64, i64 } %15, 0
  %_12.1 = extractvalue { i64, i64 } %15, 1
  store i64 %_12.0, ptr %iter1, align 8
  %16 = getelementptr inbounds i8, ptr %iter1, i64 8
  store i64 %_12.1, ptr %16, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %c, i64 72, i1 false)
  ret void

bb8:                                              ; preds = %bb12, %bb5
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %17 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter1) #15
  %18 = extractvalue { i64, i64 } %17, 0
  %19 = extractvalue { i64, i64 } %17, 1
  store i64 %18, ptr %_15, align 8
  %20 = getelementptr inbounds i8, ptr %_15, i64 8
  store i64 %19, ptr %20, align 8
  %_17 = load i64, ptr %_15, align 8
  %21 = getelementptr inbounds i8, ptr %_15, i64 8
  %22 = load i64, ptr %21, align 8
  %23 = trunc nuw i64 %_17 to i1
  br i1 %23, label %bb10, label %bb2

bb10:                                             ; preds = %bb8
  %24 = getelementptr inbounds i8, ptr %_15, i64 8
  %j = load i64, ptr %24, align 8
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %25 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 3) #15
  %_19.0 = extractvalue { i64, i64 } %25, 0
  %_19.1 = extractvalue { i64, i64 } %25, 1
  store i64 %_19.0, ptr %iter2, align 8
  %26 = getelementptr inbounds i8, ptr %iter2, i64 8
  store i64 %_19.1, ptr %26, align 8
  br label %bb12

bb12:                                             ; preds = %bb22, %bb10
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %27 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter2) #15
  %28 = extractvalue { i64, i64 } %27, 0
  %29 = extractvalue { i64, i64 } %27, 1
  store i64 %28, ptr %_22, align 8
  %30 = getelementptr inbounds i8, ptr %_22, i64 8
  store i64 %29, ptr %30, align 8
  %_24 = load i64, ptr %_22, align 8
  %31 = getelementptr inbounds i8, ptr %_22, i64 8
  %32 = load i64, ptr %31, align 8
  %33 = trunc nuw i64 %_24 to i1
  br i1 %33, label %bb14, label %bb8

bb14:                                             ; preds = %bb12
  %34 = getelementptr inbounds i8, ptr %_22, i64 8
  %k = load i64, ptr %34, align 8
  %_28 = icmp ult i64 %i, 3
  br i1 %_28, label %bb15, label %panic

bb15:                                             ; preds = %bb14
  %_29 = icmp ult i64 %k, 3
  br i1 %_29, label %bb16, label %panic3

panic:                                            ; preds = %bb14
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %i, i64 3, ptr align 8 @alloc_b6bbc700a0c1fe109f02cd751fb9fbea) #14
  unreachable

bb16:                                             ; preds = %bb15
  %35 = getelementptr inbounds nuw [3 x i64], ptr %a, i64 %i
  %36 = getelementptr inbounds nuw i64, ptr %35, i64 %k
  %_27 = load i64, ptr %36, align 8
  %_31 = icmp ult i64 %k, 3
  br i1 %_31, label %bb17, label %panic4

panic3:                                           ; preds = %bb15
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %k, i64 3, ptr align 8 @alloc_b6bbc700a0c1fe109f02cd751fb9fbea) #14
  unreachable

bb17:                                             ; preds = %bb16
  %_32 = icmp ult i64 %j, 3
  br i1 %_32, label %bb18, label %panic5

panic4:                                           ; preds = %bb16
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %k, i64 3, ptr align 8 @alloc_3a752da0d9c387e233264eb275d4db27) #14
  unreachable

bb18:                                             ; preds = %bb17
  %37 = getelementptr inbounds nuw [3 x i64], ptr %b, i64 %k
  %38 = getelementptr inbounds nuw i64, ptr %37, i64 %j
  %_30 = load i64, ptr %38, align 8
  %39 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %_27, i64 %_30)
  %_33.0 = extractvalue { i64, i1 } %39, 0
  %_33.1 = extractvalue { i64, i1 } %39, 1
  br i1 %_33.1, label %panic6, label %bb19

panic5:                                           ; preds = %bb17
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %j, i64 3, ptr align 8 @alloc_3a752da0d9c387e233264eb275d4db27) #14
  unreachable

bb19:                                             ; preds = %bb18
  %_34 = icmp ult i64 %i, 3
  br i1 %_34, label %bb20, label %panic7

panic6:                                           ; preds = %bb18
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_b6bbc700a0c1fe109f02cd751fb9fbea) #14
  unreachable

bb20:                                             ; preds = %bb19
  %_35 = icmp ult i64 %j, 3
  br i1 %_35, label %bb21, label %panic8

panic7:                                           ; preds = %bb19
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %i, i64 3, ptr align 8 @alloc_b8742e1bf7fd2dfcd21dfda7733f34c9) #14
  unreachable

bb21:                                             ; preds = %bb20
  %40 = getelementptr inbounds nuw [3 x i64], ptr %c, i64 %i
  %41 = getelementptr inbounds nuw i64, ptr %40, i64 %j
  %42 = load i64, ptr %41, align 8
  %43 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %42, i64 %_33.0)
  %_36.0 = extractvalue { i64, i1 } %43, 0
  %_36.1 = extractvalue { i64, i1 } %43, 1
  br i1 %_36.1, label %panic9, label %bb22

panic8:                                           ; preds = %bb20
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %j, i64 3, ptr align 8 @alloc_b8742e1bf7fd2dfcd21dfda7733f34c9) #14
  unreachable

bb22:                                             ; preds = %bb21
  %44 = getelementptr inbounds nuw [3 x i64], ptr %c, i64 %i
  %45 = getelementptr inbounds nuw i64, ptr %44, i64 %j
  store i64 %_36.0, ptr %45, align 8
  br label %bb12

panic9:                                           ; preds = %bb21
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_b8742e1bf7fd2dfcd21dfda7733f34c9) #14
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; algorithms::queens
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCscEnaBunu62E_10algorithms6queens(i64 %n, i64 %0, ptr align 8 %cols) unnamed_addr #0 !guid !331 {
start:
  %_15 = alloca [24 x i8], align 8
  %col = alloca [8 x i8], align 8
  %_9 = alloca [16 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %c = alloca [4 x i8], align 4
  %_0 = alloca [4 x i8], align 4
  %row = alloca [8 x i8], align 8
  store i64 %0, ptr %row, align 8
  %1 = load i64, ptr %row, align 8
  %_4 = icmp eq i64 %1, %n
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i32 0, ptr %c, align 4
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %2 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %n) #15
  %_6.0 = extractvalue { i64, i64 } %2, 0
  %_6.1 = extractvalue { i64, i64 } %2, 1
  store i64 %_6.0, ptr %iter, align 8
  %3 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb4

bb1:                                              ; preds = %start
  store i32 1, ptr %_0, align 4
  br label %bb18

bb4:                                              ; preds = %bb17, %bb7, %bb2
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %4 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #15
  %5 = extractvalue { i64, i64 } %4, 0
  %6 = extractvalue { i64, i64 } %4, 1
  store i64 %5, ptr %_9, align 8
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %6, ptr %7, align 8
  %_11 = load i64, ptr %_9, align 8
  %8 = getelementptr inbounds i8, ptr %_9, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = trunc nuw i64 %_11 to i1
  br i1 %10, label %bb7, label %bb8

bb7:                                              ; preds = %bb4
  %11 = getelementptr inbounds i8, ptr %_9, i64 8
  %12 = load i64, ptr %11, align 8
  store i64 %12, ptr %col, align 8
; call <alloc::vec::Vec<usize> as core::ops::deref::Deref>::deref
  %13 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshGsV4pNJ6ra_6object(ptr align 8 %cols) #15
  %_17.0 = extractvalue { ptr, i64 } %13, 0
  %_17.1 = extractvalue { ptr, i64 } %13, 1
; call <[usize]>::iter
  %14 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSj4iterB4_(ptr align 8 %_17.0, i64 %_17.1) #15
  %_16.0 = extractvalue { ptr, ptr } %14, 0
  %_16.1 = extractvalue { ptr, ptr } %14, 1
; call <core::slice::iter::Iter<usize> as core::iter::traits::iterator::Iterator>::enumerate
  call void @_RNvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterjENtNtNtNtB9_4iter6traits8iterator8Iterator9enumerateCsddYV2PBJW9h_3std(ptr sret([24 x i8]) align 8 %_15, ptr %_16.0, ptr %_16.1) #15
; call <core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<usize>> as core::iter::traits::iterator::Iterator>::all::<algorithms::queens::{closure#0}>
  %_13 = call zeroext i1 @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters9enumerate9EnumerateINtNtNtBc_5slice4iter4IterjEENtNtNtBa_6traits8iterator8Iterator3allNCNvCscEnaBunu62E_10algorithms6queens0EB2c_(ptr align 8 %_15, ptr align 8 %col, ptr align 8 %row) #15
  br i1 %_13, label %bb13, label %bb4

bb8:                                              ; preds = %bb4
  %15 = load i32, ptr %c, align 4
  store i32 %15, ptr %_0, align 4
  br label %bb18

bb18:                                             ; preds = %bb1, %bb8
  %16 = load i32, ptr %_0, align 4
  ret i32 %16

bb13:                                             ; preds = %bb7
  %17 = load i64, ptr %col, align 8
; call <alloc::vec::Vec<usize>>::push
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE4pushCscEnaBunu62E_10algorithms(ptr align 8 %cols, i64 %17) #15
  %18 = load i64, ptr %row, align 8
  %_25.0 = add i64 %18, 1
  %_25.1 = icmp ult i64 %_25.0, %18
  br i1 %_25.1, label %panic, label %bb15

bb15:                                             ; preds = %bb13
; call algorithms::queens
  %_23 = call i32 @_RNvCscEnaBunu62E_10algorithms6queens(i64 %n, i64 %_25.0, ptr align 8 %cols)
  %19 = load i32, ptr %c, align 4
  %_26.0 = add i32 %19, %_23
  %_26.1 = icmp ult i32 %_26.0, %19
  br i1 %_26.1, label %panic1, label %bb17

panic:                                            ; preds = %bb13
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_e6cf31bb971a81020169998b7fa1ad6b) #14
  unreachable

bb17:                                             ; preds = %bb15
  store i32 %_26.0, ptr %c, align 4
; call <alloc::vec::Vec<usize>>::pop
  %20 = call { i64, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE3popCscEnaBunu62E_10algorithms(ptr align 8 %cols) #15
  %_27.0 = extractvalue { i64, i64 } %20, 0
  %_27.1 = extractvalue { i64, i64 } %20, 1
  br label %bb4

panic1:                                           ; preds = %bb15
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_4d9386d8787472a8c94adbac48d3ce1f) #14
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; algorithms::collatz
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCscEnaBunu62E_10algorithms7collatz(i64 %0) unnamed_addr #0 !guid !332 {
start:
  %_5 = alloca [8 x i8], align 8
  %s = alloca [4 x i8], align 4
  %n = alloca [8 x i8], align 8
  store i64 %0, ptr %n, align 8
  store i32 0, ptr %s, align 4
  br label %bb1

bb1:                                              ; preds = %bb10, %start
  %_4 = load i64, ptr %n, align 8
  %_3 = icmp ne i64 %_4, 1
  br i1 %_3, label %bb2, label %bb11

bb11:                                             ; preds = %bb1
  %_0 = load i32, ptr %s, align 4
  ret i32 %_0

bb2:                                              ; preds = %bb1
  %_8 = load i64, ptr %n, align 8
  %_7 = urem i64 %_8, 2
  %_6 = icmp eq i64 %_7, 0
  br i1 %_6, label %bb4, label %bb6

bb6:                                              ; preds = %bb2
  %_13 = load i64, ptr %n, align 8
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 3, i64 %_13)
  %_14.0 = extractvalue { i64, i1 } %1, 0
  %_14.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_14.1, label %panic, label %bb7

bb4:                                              ; preds = %bb2
  %_10 = load i64, ptr %n, align 8
  %2 = udiv i64 %_10, 2
  store i64 %2, ptr %_5, align 8
  br label %bb9

bb7:                                              ; preds = %bb6
  %_15.0 = add i64 %_14.0, 1
  %_15.1 = icmp ult i64 %_15.0, %_14.0
  br i1 %_15.1, label %panic1, label %bb8

panic:                                            ; preds = %bb6
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_6200402616926a8995aa5edb9c9fc69f) #14
  unreachable

bb8:                                              ; preds = %bb7
  store i64 %_15.0, ptr %_5, align 8
  br label %bb9

panic1:                                           ; preds = %bb7
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_6200402616926a8995aa5edb9c9fc69f) #14
  unreachable

bb9:                                              ; preds = %bb4, %bb8
  %3 = load i64, ptr %_5, align 8
  store i64 %3, ptr %n, align 8
  %4 = load i32, ptr %s, align 4
  %_16.0 = add i32 %4, 1
  %_16.1 = icmp ult i32 %_16.0, %4
  br i1 %_16.1, label %panic2, label %bb10

bb10:                                             ; preds = %bb9
  store i32 %_16.0, ptr %s, align 4
  br label %bb1

panic2:                                           ; preds = %bb9
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_abe21e5532099025985d937f0a6b5bd6) #14
  unreachable
}

; <alloc::vec::Vec<(u8, u8)>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecThhEE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #1 !guid !333 {
start:
; call <alloc::raw_vec::RawVec<(u8, u8)>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecThhEE3newCscEnaBunu62E_10algorithms()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<char>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeccE13with_capacityCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !334 {
start:
; call <alloc::vec::Vec<char>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccE16with_capacity_inCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #15
  ret void
}

; <alloc::vec::Vec<char>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeccE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #1 !guid !335 {
start:
; call <alloc::raw_vec::RawVec<char>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVeccE3newCscEnaBunu62E_10algorithms()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<usize>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE13with_capacityCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !336 {
start:
; call <alloc::vec::Vec<usize>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE16with_capacity_inCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #15
  ret void
}

; <alloc::vec::Vec<usize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #1 !guid !337 {
start:
; call <alloc::raw_vec::RawVec<usize>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecjE3newCscEnaBunu62E_10algorithms()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<u64>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecyE13with_capacityCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !338 {
start:
; call <alloc::vec::Vec<u64>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyE16with_capacity_inCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #15
  ret void
}

; <alloc::raw_vec::RawVec<(u8, u8)>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecThhEE3newCscEnaBunu62E_10algorithms() unnamed_addr #0 !guid !339 {
start:
; call <alloc::raw_vec::RawVec<(u8, u8)>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEE6new_inCscEnaBunu62E_10algorithms() #15
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<char>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVeccE3newCscEnaBunu62E_10algorithms() unnamed_addr #0 !guid !340 {
start:
; call <alloc::raw_vec::RawVec<char>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE6new_inCscEnaBunu62E_10algorithms() #15
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<usize>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecjE3newCscEnaBunu62E_10algorithms() unnamed_addr #0 !guid !341 {
start:
; call <alloc::raw_vec::RawVec<usize>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE6new_inCscEnaBunu62E_10algorithms() #15
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <core::cmp::Ordering>::is_gt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3cmpNtB2_8Ordering5is_gtCscEnaBunu62E_10algorithms(i8 %self) unnamed_addr #1 !guid !342 {
start:
; call <core::cmp::Ordering>::as_raw
  %_2 = call i8 @_RNvMNtCsl10jNU3mE6R_4core3cmpNtB2_8Ordering6as_rawCscEnaBunu62E_10algorithms(i8 %self) #15
  %_0 = icmp sgt i8 %_2, 0
  ret i1 %_0
}

; <core::cmp::Ordering>::as_raw
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvMNtCsl10jNU3mE6R_4core3cmpNtB2_8Ordering6as_rawCscEnaBunu62E_10algorithms(i8 %0) unnamed_addr #1 !guid !343 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
  %_0 = load i8, ptr %self, align 1
  ret i8 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !344 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <str>::chars
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core3stre5charsCscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !345 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8]>::iter
  %2 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterB4_(ptr %_3.0, i64 %_3.1) #15
  %_2.0 = extractvalue { ptr, ptr } %2, 0
  %_2.1 = extractvalue { ptr, ptr } %2, 1
  %3 = insertvalue { ptr, ptr } poison, ptr %_2.0, 0
  %4 = insertvalue { ptr, ptr } %3, ptr %_2.1, 1
  ret { ptr, ptr } %4
}

; <[[u8; 8]]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAhj8_4iterCscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !346 {
start:
; call <core::slice::iter::Iter<[u8; 8]>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAhj8_E3newCscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) #15
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[[i64; 3]]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAxj3_4iterCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1) unnamed_addr #1 !guid !347 {
start:
; call <core::slice::iter::Iter<[i64; 3]>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAxj3_E3newCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1) #15
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[(u8, u8)]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSThhE4iterCscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !348 {
start:
; call <core::slice::iter::Iter<(u8, u8)>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterThhEE3newCscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) #15
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[f64]>::split_at_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd12split_at_mutCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %pair, ptr align 8 %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #1 !guid !349 {
start:
  %_3 = alloca [32 x i8], align 8
; call <[f64]>::split_at_mut_checked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd20split_at_mut_checkedCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_3, ptr align 8 %self.0, i64 %self.1, i64 %mid) #15
  %1 = load ptr, ptr %_3, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_4 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %pair, ptr align 8 %_3, i64 32, i1 false)
  ret void

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %5 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_d1084648e479974e70c9329824bf76f9, i64 9) #15
  %_6.0 = extractvalue { ptr, ptr } %5, 0
  %_6.1 = extractvalue { ptr, ptr } %5, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 %0) #14
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <[f64]>::swap_unchecked
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd14swap_uncheckedCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, i64 %a, i64 %b, ptr align 8 %0) unnamed_addr #0 !guid !350 {
start:
  %_9.i.i = alloca [1 x i8], align 1
  %tmp.i = alloca [8 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <[_]>::swap_unchecked::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp14swap_unchecked18precondition_checkCscEnaBunu62E_10algorithms(i64 %self.1, i64 %a, i64 %b, ptr align 8 %0) #18
  br label %bb2

bb2:                                              ; preds = %bb1
  %_0.i1 = getelementptr inbounds nuw double, ptr %self.0, i64 %a
  %_0.i = getelementptr inbounds nuw double, ptr %self.0, i64 %b
  store double undef, ptr %tmp.i, align 8
; call core::ub_checks::check_language_ub
  %_4.i1.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_4.i1.i, label %bb2.i2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingdECscEnaBunu62E_10algorithms.exit3.i

bb2.i2.i:                                         ; preds = %bb2
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCscEnaBunu62E_10algorithms(ptr %_0.i1, ptr %tmp.i, i64 8, i64 8, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #18
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingdECscEnaBunu62E_10algorithms.exit3.i

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingdECscEnaBunu62E_10algorithms.exit3.i: ; preds = %bb2.i2.i, %bb2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %tmp.i, ptr align 8 %_0.i1, i64 8, i1 false)
; call core::ub_checks::check_language_ub
  %_4.i4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_4.i4.i, label %bb2.i5.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr4copydECscEnaBunu62E_10algorithms.exit.i

bb2.i5.i:                                         ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingdECscEnaBunu62E_10algorithms.exit3.i
  store i8 0, ptr %_9.i.i, align 1
  %1 = load i8, ptr %_9.i.i, align 1
  %2 = trunc nuw i8 %1 to i1
; call core::ptr::copy::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr4copy18precondition_checkCscEnaBunu62E_10algorithms(ptr %_0.i, ptr %_0.i1, i64 8, i1 zeroext %2, ptr align 8 @alloc_9c04098d1f5b2a23ccf9ca333796c0a8) #18
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr4copydECscEnaBunu62E_10algorithms.exit.i

_RINvNtCsl10jNU3mE6R_4core3ptr4copydECscEnaBunu62E_10algorithms.exit.i: ; preds = %bb2.i5.i, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingdECscEnaBunu62E_10algorithms.exit3.i
  call void @llvm.memmove.p0.p0.i64(ptr align 8 %_0.i1, ptr align 8 %_0.i, i64 8, i1 false)
; call core::ub_checks::check_language_ub
  %_4.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_4.i.i, label %bb2.i.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr4swapdECscEnaBunu62E_10algorithms.exit

bb2.i.i:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr4copydECscEnaBunu62E_10algorithms.exit.i
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCscEnaBunu62E_10algorithms(ptr %tmp.i, ptr %_0.i, i64 8, i64 8, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #18
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr4swapdECscEnaBunu62E_10algorithms.exit

_RINvNtCsl10jNU3mE6R_4core3ptr4swapdECscEnaBunu62E_10algorithms.exit: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr4copydECscEnaBunu62E_10algorithms.exit.i, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0.i, ptr align 8 %tmp.i, i64 8, i1 false)
  ret void
}

; <[f64]>::split_at_mut_checked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd20split_at_mut_checkedCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %self.0, i64 %self.1, i64 %mid) unnamed_addr #1 !guid !351 {
start:
  %_6 = alloca [32 x i8], align 8
  %_3 = icmp ule i64 %mid, %self.1
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb1:                                              ; preds = %start
; call <[f64]>::split_at_mut_unchecked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd22split_at_mut_uncheckedCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_6, ptr align 8 %self.0, i64 %self.1, i64 %mid, ptr align 8 @alloc_a6541cbd0ddc1cb3d23757a1b3f12432) #15
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 32, i1 false)
  br label %bb4

bb4:                                              ; preds = %bb1, %bb3
  ret void
}

; <[f64]>::split_at_mut_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd22split_at_mut_uncheckedCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #1 !guid !352 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <[_]>::split_at_mut_unchecked::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp22split_at_mut_unchecked18precondition_checkCscEnaBunu62E_10algorithms(i64 %mid, i64 %self.1, ptr align 8 %0) #18
  br label %bb3

bb3:                                              ; preds = %bb2
; call core::slice::raw::from_raw_parts_mut::<f64>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutdECscEnaBunu62E_10algorithms(ptr %self.0, i64 %mid, ptr align 8 %0) #15
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %_0.i = getelementptr inbounds nuw double, ptr %self.0, i64 %mid
  %_11 = sub nuw i64 %self.1, %mid
; call core::slice::raw::from_raw_parts_mut::<f64>
  %2 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutdECscEnaBunu62E_10algorithms(ptr %_0.i, i64 %_11, ptr align 8 %0) #15
  %_9.0 = extractvalue { ptr, i64 } %2, 0
  %_9.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_8.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8.1, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 16
  store ptr %_9.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %_9.1, ptr %5, align 8
  ret void
}

; <[f64]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1) unnamed_addr #1 !guid !353 {
start:
; call <core::slice::iter::Iter<f64>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterdE3newCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1) #15
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[f64]>::swap
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4swapCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, i64 %a, i64 %b, ptr align 8 %0) unnamed_addr #1 !guid !354 {
start:
  %_6 = icmp ult i64 %a, %self.1
  br i1 %_6, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_9 = icmp ult i64 %b, %self.1
  br i1 %_9, label %bb2, label %panic1

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %a, i64 %self.1, ptr align 8 %0) #14
  unreachable

bb2:                                              ; preds = %bb1
; call <[f64]>::swap_unchecked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSd14swap_uncheckedCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, i64 %a, i64 %b, ptr align 8 %0)
  ret void

panic1:                                           ; preds = %bb1
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %b, i64 %self.1, ptr align 8 %0) #14
  unreachable
}

; <[i64]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSx4iterCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1) unnamed_addr #1 !guid !355 {
start:
; call <core::slice::iter::Iter<i64>>::new
  %0 = call { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterxE3newCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1) #15
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <[u64]>::split_at_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy12split_at_mutCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %pair, ptr align 8 %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #1 !guid !356 {
start:
  %_3 = alloca [32 x i8], align 8
; call <[u64]>::split_at_mut_checked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy20split_at_mut_checkedCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_3, ptr align 8 %self.0, i64 %self.1, i64 %mid) #15
  %1 = load ptr, ptr %_3, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_4 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %pair, ptr align 8 %_3, i64 32, i1 false)
  ret void

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %5 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_d1084648e479974e70c9329824bf76f9, i64 9) #15
  %_6.0 = extractvalue { ptr, ptr } %5, 0
  %_6.1 = extractvalue { ptr, ptr } %5, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 %0) #14
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <[u64]>::swap_unchecked
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy14swap_uncheckedCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, i64 %a, i64 %b, ptr align 8 %0) unnamed_addr #0 !guid !357 {
start:
  %_9.i.i = alloca [1 x i8], align 1
  %tmp.i = alloca [8 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <[_]>::swap_unchecked::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp14swap_unchecked18precondition_checkCscEnaBunu62E_10algorithms(i64 %self.1, i64 %a, i64 %b, ptr align 8 %0) #18
  br label %bb2

bb2:                                              ; preds = %bb1
  %_0.i1 = getelementptr inbounds nuw i64, ptr %self.0, i64 %a
  %_0.i = getelementptr inbounds nuw i64, ptr %self.0, i64 %b
  store i64 undef, ptr %tmp.i, align 8
; call core::ub_checks::check_language_ub
  %_4.i1.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_4.i1.i, label %bb2.i2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingyECscEnaBunu62E_10algorithms.exit3.i

bb2.i2.i:                                         ; preds = %bb2
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCscEnaBunu62E_10algorithms(ptr %_0.i1, ptr %tmp.i, i64 8, i64 8, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #18
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingyECscEnaBunu62E_10algorithms.exit3.i

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingyECscEnaBunu62E_10algorithms.exit3.i: ; preds = %bb2.i2.i, %bb2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %tmp.i, ptr align 8 %_0.i1, i64 8, i1 false)
; call core::ub_checks::check_language_ub
  %_4.i4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_4.i4.i, label %bb2.i5.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr4copyyECscEnaBunu62E_10algorithms.exit.i

bb2.i5.i:                                         ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingyECscEnaBunu62E_10algorithms.exit3.i
  store i8 0, ptr %_9.i.i, align 1
  %1 = load i8, ptr %_9.i.i, align 1
  %2 = trunc nuw i8 %1 to i1
; call core::ptr::copy::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr4copy18precondition_checkCscEnaBunu62E_10algorithms(ptr %_0.i, ptr %_0.i1, i64 8, i1 zeroext %2, ptr align 8 @alloc_9c04098d1f5b2a23ccf9ca333796c0a8) #18
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr4copyyECscEnaBunu62E_10algorithms.exit.i

_RINvNtCsl10jNU3mE6R_4core3ptr4copyyECscEnaBunu62E_10algorithms.exit.i: ; preds = %bb2.i5.i, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappingyECscEnaBunu62E_10algorithms.exit3.i
  call void @llvm.memmove.p0.p0.i64(ptr align 8 %_0.i1, ptr align 8 %_0.i, i64 8, i1 false)
; call core::ub_checks::check_language_ub
  %_4.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_4.i.i, label %bb2.i.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr4swapyECscEnaBunu62E_10algorithms.exit

bb2.i.i:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr4copyyECscEnaBunu62E_10algorithms.exit.i
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCscEnaBunu62E_10algorithms(ptr %tmp.i, ptr %_0.i, i64 8, i64 8, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #18
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr4swapyECscEnaBunu62E_10algorithms.exit

_RINvNtCsl10jNU3mE6R_4core3ptr4swapyECscEnaBunu62E_10algorithms.exit: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr4copyyECscEnaBunu62E_10algorithms.exit.i, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0.i, ptr align 8 %tmp.i, i64 8, i1 false)
  ret void
}

; <[u64]>::split_at_mut_checked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy20split_at_mut_checkedCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %self.0, i64 %self.1, i64 %mid) unnamed_addr #1 !guid !358 {
start:
  %_6 = alloca [32 x i8], align 8
  %_3 = icmp ule i64 %mid, %self.1
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb1:                                              ; preds = %start
; call <[u64]>::split_at_mut_unchecked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy22split_at_mut_uncheckedCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_6, ptr align 8 %self.0, i64 %self.1, i64 %mid, ptr align 8 @alloc_a6541cbd0ddc1cb3d23757a1b3f12432) #15
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 32, i1 false)
  br label %bb4

bb4:                                              ; preds = %bb1, %bb3
  ret void
}

; <[u64]>::split_at_mut_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy22split_at_mut_uncheckedCscEnaBunu62E_10algorithms(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #1 !guid !359 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <[_]>::split_at_mut_unchecked::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp22split_at_mut_unchecked18precondition_checkCscEnaBunu62E_10algorithms(i64 %mid, i64 %self.1, ptr align 8 %0) #18
  br label %bb3

bb3:                                              ; preds = %bb2
; call core::slice::raw::from_raw_parts_mut::<u64>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutyECscEnaBunu62E_10algorithms(ptr %self.0, i64 %mid, ptr align 8 %0) #15
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %_0.i = getelementptr inbounds nuw i64, ptr %self.0, i64 %mid
  %_11 = sub nuw i64 %self.1, %mid
; call core::slice::raw::from_raw_parts_mut::<u64>
  %2 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutyECscEnaBunu62E_10algorithms(ptr %_0.i, i64 %_11, ptr align 8 %0) #15
  %_9.0 = extractvalue { ptr, i64 } %2, 0
  %_9.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_8.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8.1, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 16
  store ptr %_9.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %_9.1, ptr %5, align 8
  ret void
}

; <[u64]>::swap
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy4swapCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, i64 %a, i64 %b, ptr align 8 %0) unnamed_addr #1 !guid !360 {
start:
  %_6 = icmp ult i64 %a, %self.1
  br i1 %_6, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_9 = icmp ult i64 %b, %self.1
  br i1 %_9, label %bb2, label %panic1

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %a, i64 %self.1, ptr align 8 %0) #14
  unreachable

bb2:                                              ; preds = %bb1
; call <[u64]>::swap_unchecked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy14swap_uncheckedCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, i64 %a, i64 %b, ptr align 8 %0)
  ret void

panic1:                                           ; preds = %bb1
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %b, i64 %self.1, ptr align 8 %0) #14
  unreachable
}

; <[u64]>::windows
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSy7windowsCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self.0, i64 %self.1, i64 %size, ptr align 8 %0) unnamed_addr #1 !guid !361 {
start:
; call <core::num::nonzero::NonZero<usize>>::new
  %_4 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %size) #15
; call <core::option::Option<core::num::nonzero::NonZero<usize>>>::expect
  %size1 = call i64 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionINtNtNtB4_3num7nonzero7NonZerojEE6expectCsddYV2PBJW9h_3std(i64 %_4, ptr @alloc_d0b5540d38aa67683bd942cb6db4a43b, i64 28, ptr align 8 %0) #15
; call <core::slice::iter::Windows<u64>>::new
  call void @_RNvMsW_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_7WindowsyE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self.0, i64 %self.1, i64 %size1) #15
  ret void
}

; <alloc::vec::set_len_on_drop::SetLenOnDrop>::current_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop11current_lenCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !362 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <alloc::vec::set_len_on_drop::SetLenOnDrop>::increment_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop13increment_lenCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %increment) unnamed_addr #1 !guid !363 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = add i64 %2, %increment
  store i64 %3, ptr %0, align 8
  ret void
}

; <alloc::vec::set_len_on_drop::SetLenOnDrop>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop3newCscEnaBunu62E_10algorithms(ptr align 8 %len) unnamed_addr #1 !guid !364 {
start:
  %_2 = load i64, ptr %len, align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %len, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %_2, 1
  ret { ptr, i64 } %1
}

; <*mut [u8; 8]>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOAhj8_20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #1 !guid !365 {
start:
; call <*const [u8; 8]>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPAhj8_20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %origin, ptr align 8 %0) #15
  ret i64 %_0
}

; <*mut u64>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOy20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #1 !guid !366 {
start:
; call <*const u64>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPy20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %origin, ptr align 8 %0) #15
  ret i64 %_0
}

; <*const [u8; 8]>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPAhj8_20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #1 !guid !367 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 8
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCscEnaBunu62E_10algorithms(ptr %self, ptr %origin, ptr align 8 %0) #18
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #14
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 8, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 8
  ret i64 %_0
}

; <*const u64>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPy20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #1 !guid !368 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 8
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCscEnaBunu62E_10algorithms(ptr %self, ptr %origin, ptr align 8 %0) #18
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #14
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 8, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 8
  ret i64 %_0
}

; <core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtB4_7flatten7FlattenINtNtNtB8_5slice4iter4IterAhj8_EENCNvCscEnaBunu62E_10algorithms4mains0_0E3newB1S_(ptr sret([48 x i8]) align 8 %_0, ptr align 8 %iter) unnamed_addr #0 !guid !369 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %iter, i64 48, i1 false)
  ret void
}

; <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0E3newB1p_(ptr sret([16 x i8]) align 8 %_0, i32 %iter.0, i32 %iter.1, ptr align 8 %f) unnamed_addr #0 !guid !370 {
start:
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %iter.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 4
  store i32 %iter.1, ptr %1, align 4
  store ptr %f, ptr %_0, align 8
  ret void
}

; <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB2_3MapINtNtNtB8_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzE3newB1n_(i64 %iter.0, i64 %iter.1) unnamed_addr #0 !guid !371 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %iter.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %iter.1, 1
  ret { i64, i64 } %1
}

; <core::iter::adapters::fuse::Fuse<core::slice::iter::Iter<[u8; 8]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters4fuseINtB2_4FuseINtNtNtB8_5slice4iter4IterAhj8_EE3newCscEnaBunu62E_10algorithms(ptr %iter.0, ptr %iter.1) unnamed_addr #0 !guid !372 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %iter.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %iter.1, 1
  ret { ptr, ptr } %1
}

; <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filterINtB2_6FilterINtNtNtB8_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0E3newB1F_(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %iter, ptr align 8 %predicate) unnamed_addr #0 !guid !373 {
start:
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iter, i64 24, i1 false)
  store ptr %predicate, ptr %_0, align 8
  ret void
}

; <core::iter::adapters::step_by::StepBy<core::ops::range::Range<i32>>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters7step_byINtB2_6StepByINtNtNtB8_3ops5range5RangelEE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i32 %iter.0, i32 %iter.1, i64 %step) unnamed_addr #1 personality ptr @rust_eh_personality !guid !374 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = icmp ne i64 %step, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_4aead6e2018a46d0df208d5729447de7, i64 27, ptr align 8 @alloc_2fa97f0ace01f08d7a0ffb6d9dc8c562) #14
  unreachable

bb1:                                              ; preds = %start
  store i8 0, ptr %_8, align 1
; call <core::ops::range::Range<i32> as core::iter::adapters::step_by::SpecRangeSetup<core::ops::range::Range<i32>>>::setup
  %0 = call { i32, i32 } @_RNvXs5_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7step_byINtNtNtBb_3ops5range5RangelEINtB5_14SpecRangeSetupBQ_E5setupCscEnaBunu62E_10algorithms(i32 %iter.0, i32 %iter.1, i64 %step) #15
  %iter.01 = extractvalue { i32, i32 } %0, 0
  %iter.12 = extractvalue { i32, i32 } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb1
  %_7 = sub i64 %step, 1
  store i32 %iter.01, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %iter.12, ptr %1, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_7, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 16
  store i8 1, ptr %3, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<(u8, u8)>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !375 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<(u8, u8)>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrThhEECscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<(u8, u8)>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEE6new_inCscEnaBunu62E_10algorithms() unnamed_addr #1 personality ptr @rust_eh_personality !guid !376 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<(u8, u8)>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofThhEECscEnaBunu62E_10algorithms() #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64 %_4) #15
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<(u8, u8)>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !377 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 2) #15
  ret i64 %_0
}

; <alloc::raw_vec::RawVec<bool>>::with_capacity_zeroed_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbE23with_capacity_zeroed_inCscEnaBunu62E_10algorithms(i64 %capacity) unnamed_addr #1 !guid !378 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_zeroed_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner23with_capacity_zeroed_inCsddYV2PBJW9h_3std(i64 %capacity, i64 1, i64 1) #15
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<bool>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !379 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<bool>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrbECscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<bool>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #1 !guid !380 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8 %self, i64 %len, i64 %additional, i64 1, i64 1) #15
  ret void
}

; <alloc::raw_vec::RawVec<char>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !381 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<char>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrcECscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<char>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE6new_inCscEnaBunu62E_10algorithms() unnamed_addr #1 personality ptr @rust_eh_personality !guid !382 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<char>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofcECscEnaBunu62E_10algorithms() #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64 %_4) #15
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<char>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #1 !guid !383 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8 %self, i64 %len, i64 %additional, i64 4, i64 4) #15
  ret void
}

; <alloc::raw_vec::RawVec<char>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !384 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 4) #15
  ret i64 %_0
}

; <alloc::raw_vec::RawVec<usize>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE6new_inCscEnaBunu62E_10algorithms() unnamed_addr #1 personality ptr @rust_eh_personality !guid !385 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<usize>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofjECscEnaBunu62E_10algorithms() #15
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64 %_4) #15
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<usize>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #1 !guid !386 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8 %self, i64 %len, i64 %additional, i64 8, i64 8) #15
  ret void
}

; <alloc::raw_vec::RawVec<usize>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !387 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 8) #15
  ret i64 %_0
}

; <alloc::raw_vec::RawVec<u64>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecyE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !388 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u64>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptryECscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u64>>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecyE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %len, i64 %additional) unnamed_addr #1 !guid !389 {
start:
; call <alloc::raw_vec::RawVecInner>::reserve
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8 %self, i64 %len, i64 %additional, i64 8, i64 8) #15
  ret void
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCscEnaBunu62E_10algorithms(i32 %self) unnamed_addr #1 !guid !390 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCscEnaBunu62E_10algorithms(i32 %self) #15
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCscEnaBunu62E_10algorithms(i32 %self) unnamed_addr #1 !guid !391 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <i32>::checked_add_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl20checked_add_unsignedCscEnaBunu62E_10algorithms(i32 %self, i32 %rhs) unnamed_addr #1 !guid !392 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
; call <i32>::overflowing_add_unsigned
  %0 = call { i32, i1 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl24overflowing_add_unsignedCscEnaBunu62E_10algorithms(i32 %self, i32 %rhs) #15
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <i32>::overflowing_add_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i1 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl24overflowing_add_unsignedCscEnaBunu62E_10algorithms(i32 %self, i32 %rhs) unnamed_addr #1 !guid !393 {
start:
  %0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_6.0 = extractvalue { i32, i1 } %0, 0
  %_6.1 = extractvalue { i32, i1 } %0, 1
  %_8 = icmp slt i32 %rhs, 0
  %_7 = xor i1 %_6.1, %_8
  %1 = insertvalue { i32, i1 } poison, i32 %_6.0, 0
  %2 = insertvalue { i32, i1 } %1, i1 %_7, 1
  ret { i32, i1 } %2
}

; <core::ptr::unique::Unique<(u8, u8)>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueThhEE15as_non_null_ptrCscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !394 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<bool>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquebE15as_non_null_ptrCscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !395 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<char>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquecE15as_non_null_ptrCscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !396 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<u64>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE15as_non_null_ptrCscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !397 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[[i64; 3]; 3]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAAxj3_BW_E8from_refCscEnaBunu62E_10algorithms(ptr align 8 %r) unnamed_addr #1 !guid !398 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[f64; 5]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAdj5_E8from_refCscEnaBunu62E_10algorithms(ptr align 8 %r) unnamed_addr #1 !guid !399 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[u8; 8]>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAhj8_E20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %subtracted) unnamed_addr #1 !guid !400 {
start:
; call <*mut [u8; 8]>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOAhj8_20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #15
  ret i64 %_0
}

; <core::ptr::non_null::NonNull<&[(u8, u8)]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSThhEE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %r) unnamed_addr #1 !guid !401 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&[usize]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSjE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %r) unnamed_addr #1 !guid !402 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<&[u64]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullRSyE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %r) unnamed_addr #1 !guid !403 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[[u8; 8]]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAhj8_E8from_refCscEnaBunu62E_10algorithms(ptr %r.0, i64 %r.1) unnamed_addr #1 !guid !404 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[[i64; 3]]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAxj3_E8from_refCscEnaBunu62E_10algorithms(ptr align 8 %r.0, i64 %r.1) unnamed_addr #1 !guid !405 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[(u8, u8)]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSThhEE8from_refCscEnaBunu62E_10algorithms(ptr %r.0, i64 %r.1) unnamed_addr #1 !guid !406 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[f64]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSdE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %r.0, i64 %r.1) unnamed_addr #1 !guid !407 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<[i64]>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSxE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %r.0, i64 %r.1) unnamed_addr #1 !guid !408 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %r.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %r.1, 1
  ret { ptr, i64 } %1
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCscEnaBunu62E_10algorithms(ptr %r) unnamed_addr #1 !guid !409 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u64>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %subtracted) unnamed_addr #1 !guid !410 {
start:
; call <*mut u64>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOy20offset_from_unsignedCscEnaBunu62E_10algorithms(ptr %self, ptr %subtracted, ptr align 8 @alloc_498f56052dc304c3bdbc06db4cd2922f) #15
  ret i64 %_0
}

; <isize>::abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs3_NtCsl10jNU3mE6R_4core3numi3absCscEnaBunu62E_10algorithms(i64 %self) unnamed_addr #1 !guid !411 {
start:
  %_0 = alloca [8 x i8], align 8
  %_0.i = icmp slt i64 %self, 0
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 %self, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  %_3 = icmp eq i64 %self, -9223372036854775808
  br i1 %_3, label %panic, label %bb3

bb5:                                              ; preds = %bb3, %bb4
  %0 = load i64, ptr %_0, align 8
  ret i64 %0

bb3:                                              ; preds = %bb2
  %1 = sub i64 0, %self
  store i64 %1, ptr %_0, align 8
  br label %bb5

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_neg_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_neg_overflow(ptr align 8 @alloc_ae8736b8ce7095907a2b2a6db978b45d) #14
  unreachable
}

; <alloc::vec::Vec<bool>>::extend_with
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs4_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbE11extend_withCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %n, i1 zeroext %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !412 {
start:
  %1 = alloca [16 x i8], align 8
  %_31 = alloca [1 x i8], align 1
  %iter = alloca [16 x i8], align 8
  %local_len = alloca [16 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %value = alloca [1 x i8], align 1
  %2 = zext i1 %0 to i8
  store i8 %2, ptr %value, align 1
  store i8 0, ptr %_31, align 1
  store i8 1, ptr %_31, align 1
; call <alloc::vec::Vec<bool>>::reserve
  call void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %n)
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<bool>>::as_mut_ptr
  %_6 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb2

bb2:                                              ; preds = %bb1
; call <alloc::vec::Vec<bool>>::len
  %_7 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE3lenCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb3

bb3:                                              ; preds = %bb2
  %_0.i1 = getelementptr inbounds nuw i8, ptr %_6, i64 %_7
  store ptr %_0.i1, ptr %ptr, align 8
  br label %bb4

bb4:                                              ; preds = %bb3
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::vec::set_len_on_drop::SetLenOnDrop>::new
  %3 = call { ptr, i64 } @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop3newCscEnaBunu62E_10algorithms(ptr align 8 %_10) #15
  %4 = extractvalue { ptr, i64 } %3, 0
  %5 = extractvalue { ptr, i64 } %3, 1
  store ptr %4, ptr %local_len, align 8
  %6 = getelementptr inbounds i8, ptr %local_len, i64 8
  store i64 %5, ptr %6, align 8
  br label %bb5

bb5:                                              ; preds = %bb4
; invoke <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %7 = invoke { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 1, i64 %n)
          to label %bb6 unwind label %cleanup

bb20:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::set_len_on_drop::SetLenOnDrop>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtNtCs7CppTae75M1_5alloc3vec15set_len_on_drop12SetLenOnDropECsddYV2PBJW9h_3std(ptr align 8 %local_len) #16
          to label %bb24 unwind label %terminate

cleanup:                                          ; preds = %bb14, %bb16, %bb7, %bb5
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %1, align 8
  %11 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb20

bb6:                                              ; preds = %bb5
  %_11.0 = extractvalue { i64, i64 } %7, 0
  %_11.1 = extractvalue { i64, i64 } %7, 1
  store i64 %_11.0, ptr %iter, align 8
  %12 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_11.1, ptr %12, align 8
  br label %bb7

bb7:                                              ; preds = %bb25, %bb6
; invoke <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %13 = invoke { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  %_14.0 = extractvalue { i64, i64 } %13, 0
  %_14.1 = extractvalue { i64, i64 } %13, 1
  %14 = trunc nuw i64 %_14.0 to i1
  br i1 %14, label %bb10, label %bb11

bb10:                                             ; preds = %bb8
  %_18 = load ptr, ptr %ptr, align 8
  %15 = load i8, ptr %value, align 1
  %_0.i2 = trunc nuw i8 %15 to i1
  br label %bb12

bb11:                                             ; preds = %bb8
  %_25 = icmp ugt i64 %n, 0
  br i1 %_25, label %bb15, label %bb17

bb17:                                             ; preds = %bb26, %bb11
; call core::ptr::drop_glue::<alloc::vec::set_len_on_drop::SetLenOnDrop>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtNtCs7CppTae75M1_5alloc3vec15set_len_on_drop12SetLenOnDropECsddYV2PBJW9h_3std(ptr align 8 %local_len)
  br label %bb18

bb15:                                             ; preds = %bb11
  %_27 = load ptr, ptr %ptr, align 8
  store i8 0, ptr %_31, align 1
  %16 = load i8, ptr %value, align 1
  %_28 = trunc nuw i8 %16 to i1
  store i8 %16, ptr %_27, align 1
  br label %bb16

bb16:                                             ; preds = %bb15
; invoke <alloc::vec::set_len_on_drop::SetLenOnDrop>::increment_len
  invoke void @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop13increment_lenCscEnaBunu62E_10algorithms(ptr align 8 %local_len, i64 1)
          to label %bb26 unwind label %cleanup

bb26:                                             ; preds = %bb16
  br label %bb17

bb18:                                             ; preds = %bb17
  %17 = load i8, ptr %_31, align 1
  %18 = trunc nuw i8 %17 to i1
  br i1 %18, label %bb22, label %bb19

bb19:                                             ; preds = %bb22, %bb18
  ret void

bb22:                                             ; preds = %bb18
  br label %bb19

bb12:                                             ; preds = %bb10
  %19 = zext i1 %_0.i2 to i8
  store i8 %19, ptr %_18, align 1
  br label %bb13

bb13:                                             ; preds = %bb12
  %_22 = load ptr, ptr %ptr, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %_22, i64 1
  br label %bb14

bb14:                                             ; preds = %bb13
  store ptr %_0.i, ptr %ptr, align 8
; invoke <alloc::vec::set_len_on_drop::SetLenOnDrop>::increment_len
  invoke void @_RNvMNtNtCs7CppTae75M1_5alloc3vec15set_len_on_dropNtB2_12SetLenOnDrop13increment_lenCscEnaBunu62E_10algorithms(ptr align 8 %local_len, i64 1)
          to label %bb25 unwind label %cleanup

bb25:                                             ; preds = %bb14
  br label %bb7

bb9:                                              ; No predecessors!
  unreachable

terminate:                                        ; preds = %bb20
  %20 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb24:                                             ; preds = %bb20
  %21 = load i8, ptr %_31, align 1
  %22 = trunc nuw i8 %21 to i1
  br i1 %22, label %bb23, label %bb21

bb21:                                             ; preds = %bb23, %bb24
  %23 = load ptr, ptr %1, align 8
  %24 = getelementptr inbounds i8, ptr %1, i64 8
  %25 = load i32, ptr %24, align 8
  %26 = insertvalue { ptr, i32 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i32 } %26, i32 %25, 1
  resume { ptr, i32 } %27

bb23:                                             ; preds = %bb24
  br label %bb21
}

; <alloc::raw_vec::RawVec<(u8, u8)>>::grow_one
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEE8grow_oneCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #2 !guid !413 {
start:
; call <alloc::raw_vec::RawVecInner>::grow_one
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneB7_(ptr align 8 %self, i64 1, i64 2) #15
  ret void
}

; <alloc::raw_vec::RawVec<bool>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbE16with_capacity_inCscEnaBunu62E_10algorithms(i64 %capacity) unnamed_addr #1 !guid !414 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 1, i64 1) #15
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<char>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE16with_capacity_inCscEnaBunu62E_10algorithms(i64 %capacity) unnamed_addr #1 !guid !415 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 4, i64 4) #15
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<usize>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE16with_capacity_inCscEnaBunu62E_10algorithms(i64 %capacity) unnamed_addr #1 !guid !416 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 8, i64 8) #15
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<usize>>::grow_one
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #2 !guid !417 {
start:
; call <alloc::raw_vec::RawVecInner>::grow_one
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneB7_(ptr align 8 %self, i64 8, i64 8) #15
  ret void
}

; <alloc::raw_vec::RawVec<u64>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecyE16with_capacity_inCscEnaBunu62E_10algorithms(i64 %capacity) unnamed_addr #1 !guid !418 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 8, i64 8) #15
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !419 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCscEnaBunu62E_10algorithms(ptr %s.0, i64 %s.1) #15
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<[u8; 8]>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAhj8_E3newCscEnaBunu62E_10algorithms(ptr %slice.0, i64 %slice.1) unnamed_addr #1 !guid !420 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[[u8; 8]]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAhj8_E8from_refCscEnaBunu62E_10algorithms(ptr %slice.0, i64 %slice.1) #15
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[[u8; 8]]>>::cast::<[u8; 8]>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAhj8_E4castBV_ECscEnaBunu62E_10algorithms(ptr %_4.0, i64 %_4.1) #15
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw [8 x i8], ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<[i64; 3]>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterAxj3_E3newCscEnaBunu62E_10algorithms(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #1 !guid !421 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[[i64; 3]]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSAxj3_E8from_refCscEnaBunu62E_10algorithms(ptr align 8 %slice.0, i64 %slice.1) #15
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[[i64; 3]]>>::cast::<[i64; 3]>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSAxj3_E4castBV_ECscEnaBunu62E_10algorithms(ptr %_4.0, i64 %_4.1) #15
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw [3 x i64], ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<(u8, u8)>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterThhEE3newCscEnaBunu62E_10algorithms(ptr %slice.0, i64 %slice.1) unnamed_addr #1 !guid !422 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[(u8, u8)]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSThhEE8from_refCscEnaBunu62E_10algorithms(ptr %slice.0, i64 %slice.1) #15
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[(u8, u8)]>>::cast::<(u8, u8)>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSThhEE4castBV_ECscEnaBunu62E_10algorithms(ptr %_4.0, i64 %_4.1) #15
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw { i8, i8 }, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f64>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterdE3newCscEnaBunu62E_10algorithms(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #1 !guid !423 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[f64]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSdE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %slice.0, i64 %slice.1) #15
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[f64]>>::cast::<f64>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSdE4castdECscEnaBunu62E_10algorithms(ptr %_4.0, i64 %_4.1) #15
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw double, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<i64>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_4IterxE3newCscEnaBunu62E_10algorithms(ptr align 8 %slice.0, i64 %slice.1) unnamed_addr #1 !guid !424 {
start:
  %end_or_len = alloca [8 x i8], align 8
; call <core::ptr::non_null::NonNull<[i64]>>::from_ref
  %0 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullSxE8from_refCscEnaBunu62E_10algorithms(ptr align 8 %slice.0, i64 %slice.1) #15
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[i64]>>::cast::<i64>
  %ptr = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSxE4castxECscEnaBunu62E_10algorithms(ptr %_4.0, i64 %_4.1) #15
  br label %bb4

bb4:                                              ; preds = %start
  %_0.i = getelementptr inbounds nuw i64, ptr %ptr, i64 %slice.1
  store ptr %_0.i, ptr %end_or_len, align 8
  br label %bb7

bb7:                                              ; preds = %bb4
  %_8 = load ptr, ptr %end_or_len, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %ptr, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_8, 1
  ret { ptr, ptr } %2

bb3:                                              ; No predecessors!
  unreachable
}

; <core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs6_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB5_7FlattenINtNtNtBb_5slice4iter4IterAhj8_EE3newCscEnaBunu62E_10algorithms(ptr sret([48 x i8]) align 8 %_0, ptr %iter.0, ptr %iter.1) unnamed_addr #0 !guid !425 {
start:
  %_2 = alloca [48 x i8], align 8
; call <core::iter::adapters::flatten::FlattenCompat<core::slice::iter::Iter<[u8; 8]>, core::slice::iter::Iter<u8>>>::new
  call void @_RNvMsf_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB5_13FlattenCompatINtNtNtBb_5slice4iter4IterAhj8_EIB1c_hEE3newCscEnaBunu62E_10algorithms(ptr sret([48 x i8]) align 8 %_2, ptr %iter.0, ptr %iter.1)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 48, i1 false)
  ret void
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !426 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_addCscEnaBunu62E_10algorithms(i64 %self, i64 %rhs) unnamed_addr #1 !guid !427 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5.0 = add i64 %self, %rhs
  %_5.1 = icmp ult i64 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCscEnaBunu62E_10algorithms(i64 %self, i64 %rhs) unnamed_addr #1 !guid !428 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCscEnaBunu62E_10algorithms(i64 %self, i64 %rhs) unnamed_addr #1 !guid !429 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCscEnaBunu62E_10algorithms(i64 %self, i64 %other) unnamed_addr #1 !guid !430 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCscEnaBunu62E_10algorithms(i32 %_0.i) #15
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <usize>::div_ceil
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8div_ceilCscEnaBunu62E_10algorithms(i64 %self, i64 %rhs, ptr align 8 %0) unnamed_addr #1 !guid !431 {
start:
  %_0 = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %panic, label %bb1

bb1:                                              ; preds = %start
  %d = udiv i64 %self, %rhs
  %_6 = icmp eq i64 %rhs, 0
  br i1 %_6, label %panic1, label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 %0) #14
  unreachable

bb2:                                              ; preds = %bb1
  %r = urem i64 %self, %rhs
  %_7 = icmp ugt i64 %r, 0
  br i1 %_7, label %bb3, label %bb4

panic1:                                           ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 %0) #14
  unreachable

bb4:                                              ; preds = %bb2
  store i64 %d, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb2
  %1 = add i64 %d, 1
  store i64 %1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %2 = load i64, ptr %_0, align 8
  ret i64 %2
}

; <alloc::vec::Vec<(u8, u8)>>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEE4pushCscEnaBunu62E_10algorithms(ptr align 8 %self, i8 %value.0, i8 %value.1) unnamed_addr #1 !guid !432 {
start:
; call <alloc::vec::Vec<(u8, u8)>>::push_mut
  %_3 = call ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEE8push_mutCscEnaBunu62E_10algorithms(ptr align 8 %self, i8 %value.0, i8 %value.1) #15
  ret void
}

; <alloc::vec::Vec<(u8, u8)>>::push_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEE8push_mutCscEnaBunu62E_10algorithms(ptr align 8 %self, i8 %value.0, i8 %value.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !433 {
start:
  %_13 = alloca [1 x i8], align 1
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<(u8, u8)>>::capacity
  %_5 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp eq i64 %len, %_5
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb10, %bb1
; call <alloc::vec::Vec<(u8, u8)>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecThhEE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb4

bb2:                                              ; preds = %bb1
; call <alloc::raw_vec::RawVec<(u8, u8)>>::grow_one
  call void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEE8grow_oneCscEnaBunu62E_10algorithms(ptr align 8 %self) #19
  br label %bb10

bb10:                                             ; preds = %bb2
  br label %bb3

bb4:                                              ; preds = %bb3
  %_0.i = getelementptr inbounds nuw { i8, i8 }, ptr %_10, i64 %len
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_13, align 1
  store i8 %value.0, ptr %_0.i, align 1
  %1 = getelementptr inbounds i8, ptr %_0.i, i64 1
  store i8 %value.1, ptr %1, align 1
  br label %bb6

bb6:                                              ; preds = %bb5
  %2 = getelementptr inbounds i8, ptr %self, i64 16
  %3 = add i64 %len, 1
  store i64 %3, ptr %2, align 8
  ret ptr %_0.i

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<bool>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbE16with_capacity_inCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !434 {
start:
; call <alloc::raw_vec::RawVec<bool>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbE16with_capacity_inCscEnaBunu62E_10algorithms(i64 %capacity) #15
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<char>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccE16with_capacity_inCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !435 {
start:
; call <alloc::raw_vec::RawVec<char>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE16with_capacity_inCscEnaBunu62E_10algorithms(i64 %capacity) #15
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<usize>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE16with_capacity_inCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !436 {
start:
; call <alloc::raw_vec::RawVec<usize>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE16with_capacity_inCscEnaBunu62E_10algorithms(i64 %capacity) #15
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<usize>>::push
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE4pushCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %value) unnamed_addr #1 !guid !437 {
start:
; call <alloc::vec::Vec<usize>>::push_mut
  %_3 = call align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE8push_mutCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %value) #15
  ret void
}

; <alloc::vec::Vec<usize>>::push_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjE8push_mutCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %value) unnamed_addr #1 personality ptr @rust_eh_personality !guid !438 {
start:
  %_13 = alloca [1 x i8], align 1
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<usize>>::capacity
  %_5 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp eq i64 %len, %_5
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %bb10, %bb1
; call <alloc::vec::Vec<usize>>::as_mut_ptr
  %_10 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  br label %bb4

bb2:                                              ; preds = %bb1
; call <alloc::raw_vec::RawVec<usize>>::grow_one
  call void @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCscEnaBunu62E_10algorithms(ptr align 8 %self) #19
  br label %bb10

bb10:                                             ; preds = %bb2
  br label %bb3

bb4:                                              ; preds = %bb3
  %_0.i = getelementptr inbounds nuw i64, ptr %_10, i64 %len
  br label %bb5

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_13, align 1
  store i64 %value, ptr %_0.i, align 8
  br label %bb6

bb6:                                              ; preds = %bb5
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = add i64 %len, 1
  store i64 %2, ptr %1, align 8
  ret ptr %_0.i

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u64>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyE16with_capacity_inCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !439 {
start:
; call <alloc::raw_vec::RawVec<u64>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecyE16with_capacity_inCscEnaBunu62E_10algorithms(i64 %capacity) #15
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CscEnaBunu62E_10algorithms(i8 %0) unnamed_addr #1 !guid !440 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CscEnaBunu62E_10algorithms(ptr %self) #15
  ret i32 %_0
}

; <core::slice::iter::Windows<u64>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsW_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_7WindowsyE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %slice.0, i64 %slice.1, i64 %size) unnamed_addr #1 !guid !441 {
start:
  store ptr %slice.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %slice.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %size, ptr %1, align 8
  ret void
}

; <alloc::vec::Vec<(u8, u8)>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecThhEE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !442 {
start:
; call <alloc::raw_vec::RawVec<(u8, u8)>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_0
}

; <alloc::vec::Vec<(u8, u8)>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecThhEE3lenCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !443 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 4611686018427387903
  ret i64 %len
}

; <alloc::vec::Vec<(u8, u8)>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecThhEE6as_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !444 {
start:
; call <alloc::raw_vec::RawVec<(u8, u8)>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_2
}

; <alloc::vec::Vec<(u8, u8)>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecThhEE8as_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !445 {
start:
; call <alloc::vec::Vec<(u8, u8)>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecThhEE6as_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<bool>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !446 {
start:
; call <alloc::raw_vec::RawVec<bool>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_0
}

; <alloc::vec::Vec<bool>>::as_mut_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE12as_mut_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !447 {
start:
; call <alloc::vec::Vec<bool>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<bool>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE3lenCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !448 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 9223372036854775807
  ret i64 %len
}

; <alloc::vec::Vec<bool>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE6as_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !449 {
start:
; call <alloc::raw_vec::RawVec<bool>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_2
}

; <alloc::vec::Vec<bool>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !450 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<bool>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %_5, i64 %additional) #15
  ret void
}

; <alloc::vec::Vec<bool>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE8as_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !451 {
start:
; call <alloc::vec::Vec<bool>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE6as_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<char>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !452 {
start:
; call <alloc::raw_vec::RawVec<char>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_0
}

; <alloc::vec::Vec<char>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE3lenCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !453 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 2305843009213693951
  ret i64 %len
}

; <alloc::vec::Vec<char>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE6as_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !454 {
start:
; call <alloc::raw_vec::RawVec<char>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_2
}

; <alloc::vec::Vec<char>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !455 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<char>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %_5, i64 %additional) #15
  ret void
}

; <alloc::vec::Vec<char>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7set_lenCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %new_len) unnamed_addr #1 !guid !456 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<char>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCscEnaBunu62E_10algorithms(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #18
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<char>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8as_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !457 {
start:
; call <alloc::vec::Vec<char>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE6as_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<char>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !458 {
start:
; call <alloc::raw_vec::RawVec<char>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret i64 %_0
}

; <alloc::vec::Vec<usize>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !459 {
start:
; call <alloc::raw_vec::RawVec<usize>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE3ptrCshGsV4pNJ6ra_6object(ptr align 8 %self) #15
  ret ptr %_0
}

; <alloc::vec::Vec<usize>>::as_mut_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE12as_mut_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !460 {
start:
; call <alloc::vec::Vec<usize>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<usize>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE3lenCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !461 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 1152921504606846975
  ret i64 %len
}

; <alloc::vec::Vec<usize>>::pop
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE3popCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !462 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_3 = load i64, ptr %0, align 8
  %_2 = icmp eq i64 %_3, 0
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = getelementptr inbounds i8, ptr %self, i64 16
  %3 = load i64, ptr %2, align 8
  %4 = sub i64 %3, 1
  store i64 %4, ptr %1, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 16
  %_6 = load i64, ptr %5, align 8
; call <alloc::vec::Vec<usize>>::capacity
  %_7 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_5 = icmp ult i64 %_6, %_7
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb2
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCscEnaBunu62E_10algorithms(i1 zeroext %_5, ptr align 8 @alloc_e4da8bf01562d69d010b033568f84c60) #18
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb2, %bb2.i
; call <alloc::vec::Vec<usize>>::as_ptr
  %_11 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE6as_ptrCshGsV4pNJ6ra_6object(ptr align 8 %self) #15
; call <alloc::vec::Vec<usize>>::len
  %_13 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE3lenCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_0.i1 = getelementptr inbounds nuw i64, ptr %_11, i64 %_13
  %_0.i = load i64, ptr %_0.i1, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_0.i, ptr %6, align 8
  store i64 1, ptr %_0, align 8
  br label %bb9

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb9

bb9:                                              ; preds = %bb1, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %7 = load i64, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { i64, i64 } poison, i64 %7, 0
  %11 = insertvalue { i64, i64 } %10, i64 %9, 1
  ret { i64, i64 } %11
}

; <alloc::vec::Vec<usize>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !463 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<usize>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %_5, i64 %additional) #15
  ret void
}

; <alloc::vec::Vec<usize>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE7set_lenCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %new_len) unnamed_addr #1 !guid !464 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<usize>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCscEnaBunu62E_10algorithms(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #18
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<usize>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !465 {
start:
; call <alloc::raw_vec::RawVec<usize>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE8capacityCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret i64 %_0
}

; <alloc::vec::Vec<u64>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !466 {
start:
; call <alloc::raw_vec::RawVec<u64>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecyE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_0
}

; <alloc::vec::Vec<u64>>::as_mut_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE12as_mut_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !467 {
start:
; call <alloc::vec::Vec<u64>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<u64>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE6as_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !468 {
start:
; call <alloc::raw_vec::RawVec<u64>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecyE3ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  ret ptr %_2
}

; <alloc::vec::Vec<u64>>::reserve
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %additional) unnamed_addr #0 !guid !469 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
; call <alloc::raw_vec::RawVec<u64>>::reserve
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecyE7reserveCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %_5, i64 %additional) #15
  ret void
}

; <alloc::vec::Vec<u64>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE8as_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !470 {
start:
; call <alloc::vec::Vec<u64>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE6as_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <*mut (u8, u8)>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOThhE10cast_sliceCscEnaBunu62E_10algorithms(ptr %self, i64 %len) unnamed_addr #1 !guid !471 {
start:
; call core::ptr::slice_from_raw_parts_mut::<(u8, u8)>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutThhEECscEnaBunu62E_10algorithms(ptr %self, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut bool>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOb10cast_sliceCscEnaBunu62E_10algorithms(ptr %self, i64 %len) unnamed_addr #1 !guid !472 {
start:
; call core::ptr::slice_from_raw_parts_mut::<bool>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutbECscEnaBunu62E_10algorithms(ptr %self, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut char>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOc10cast_sliceCscEnaBunu62E_10algorithms(ptr %self, i64 %len) unnamed_addr #1 !guid !473 {
start:
; call core::ptr::slice_from_raw_parts_mut::<char>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutcECscEnaBunu62E_10algorithms(ptr %self, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut usize>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOj10cast_sliceCscEnaBunu62E_10algorithms(ptr %self, i64 %len) unnamed_addr #1 !guid !474 {
start:
; call core::ptr::slice_from_raw_parts_mut::<usize>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutjECscEnaBunu62E_10algorithms(ptr %self, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut u64>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOy10cast_sliceCscEnaBunu62E_10algorithms(ptr %self, i64 %len) unnamed_addr #1 !guid !475 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u64>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutyECscEnaBunu62E_10algorithms(ptr %self, i64 %len) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::iter::adapters::flatten::FlattenCompat<core::slice::iter::Iter<[u8; 8]>, core::slice::iter::Iter<u8>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMsf_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB5_13FlattenCompatINtNtNtBb_5slice4iter4IterAhj8_EIB1c_hEE3newCscEnaBunu62E_10algorithms(ptr sret([48 x i8]) align 8 %_0, ptr %iter.0, ptr %iter.1) unnamed_addr #0 !guid !476 {
start:
; call <core::slice::iter::Iter<[u8; 8]> as core::iter::traits::iterator::Iterator>::fuse
  %0 = call { ptr, ptr } @_RNvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterAhj8_ENtNtNtNtB9_4iter6traits8iterator8Iterator4fuseCscEnaBunu62E_10algorithms(ptr %iter.0, ptr %iter.1) #15
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_2.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_2.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store ptr null, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store ptr undef, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 32
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store ptr undef, ptr %5, align 8
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCscEnaBunu62E_10algorithms() unnamed_addr #3 !guid !477 {
start:
  ret void
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCscEnaBunu62E_10algorithms(ptr %ptr, i64 %align) unnamed_addr #1 !guid !478 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCscEnaBunu62E_10algorithms(ptr %ptr, i64 %align) #15
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() unnamed_addr #1 !guid !479 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCscEnaBunu62E_10algorithms() #15
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCscEnaBunu62E_10algorithms(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #1 !guid !480 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCscEnaBunu62E_10algorithms(ptr %3, ptr %5, i64 %7, i64 %9) #15
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCscEnaBunu62E_10algorithms(i64 %size, i64 %len) unnamed_addr #1 !guid !481 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #14
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCscEnaBunu62E_10algorithms(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #1 !guid !482 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCscEnaBunu62E_10algorithms(ptr %ptr, i64 %align) #15
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr %ptr) #15
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; <[_]>::swap_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp14swap_unchecked18precondition_checkCscEnaBunu62E_10algorithms(i64 %len, i64 %a, i64 %b, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !483 {
start:
  %_4 = icmp ult i64 %a, %len
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_111374654bf6d257ff5ed1ae570a570d, i64 218)
          to label %bb4 unwind label %terminate

bb1:                                              ; preds = %start
  %_5 = icmp ult i64 %b, %len
  br i1 %_5, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  ret void

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb4:                                              ; preds = %bb3
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_7.0, ptr %_7.1, i1 zeroext false, ptr align 8 %0) #21
  unreachable
}

; <[_]>::split_at_mut_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp22split_at_mut_unchecked18precondition_checkCscEnaBunu62E_10algorithms(i64 %mid, i64 %len, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !484 {
start:
  %_3 = icmp ule i64 %mid, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_6b0b11c9e93314b588b613b55005cf18, i64 221)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #21
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCscEnaBunu62E_10algorithms(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !485 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #21
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCscEnaBunu62E_10algorithms(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !486 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #21
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCscEnaBunu62E_10algorithms(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !487 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #21
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCscEnaBunu62E_10algorithms(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !488 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCscEnaBunu62E_10algorithms(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCscEnaBunu62E_10algorithms(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCscEnaBunu62E_10algorithms(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #21
  unreachable
}

; core::ptr::copy::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr4copy18precondition_checkCscEnaBunu62E_10algorithms(ptr %src, ptr %dst, i64 %align, i1 zeroext %zero_size, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !489 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCscEnaBunu62E_10algorithms(ptr %src, i64 %align, i1 zeroext %zero_size)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_5ee6cd0de5bab89c84438a39fb5fb08c, i64 221)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCscEnaBunu62E_10algorithms(ptr %dst, i64 %align, i1 zeroext %zero_size)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #21
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCscEnaBunu62E_10algorithms(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !490 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #21
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCscEnaBunu62E_10algorithms(ptr %ptr, i64 %align) unnamed_addr #1 !guid !491 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr %ptr, i64 %align) #15
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCscEnaBunu62E_10algorithms() unnamed_addr #1 !guid !492 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCscEnaBunu62E_10algorithms(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #1 !guid !493 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCscEnaBunu62E_10algorithms(i64 %size, i64 %count) #15
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCscEnaBunu62E_10algorithms(i64 %_0.i2, i64 %_0.i) #15
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #21
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCscEnaBunu62E_10algorithms(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #4 personality ptr @rust_eh_personality !guid !494 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCscEnaBunu62E_10algorithms(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #17
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_5c1a2f972552229672fc942406cfc298, i64 283)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCscEnaBunu62E_10algorithms(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #21
  unreachable
}

; <alloc::vec::Vec<char> as alloc::vec::spec_extend::SpecExtend<char, core::str::iter::Chars>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB4_3VeccEINtB2_10SpecExtendcNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE11spec_extendCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr %iter.0, ptr %iter.1) unnamed_addr #0 !guid !495 {
start:
; call <alloc::vec::Vec<char>>::extend_desugared::<core::str::iter::Chars>
  call void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VeccE16extend_desugaredNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr %iter.0, ptr %iter.1)
  ret void
}

; <alloc::vec::Vec<usize> as alloc::vec::spec_extend::SpecExtend<usize, core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB4_3VecjEINtB2_10SpecExtendjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtB1l_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EE11spec_extendB2N_(ptr align 8 %self, ptr align 8 %iter) unnamed_addr #0 !guid !496 {
start:
  %0 = alloca [32 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iter, i64 32, i1 false)
; call <alloc::vec::Vec<usize>>::extend_desugared::<core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>
  call void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjE16extend_desugaredINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtB19_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EEB2B_(ptr align 8 %self, ptr align 8 %0)
  ret void
}

; <alloc::vec::Vec<char> as alloc::vec::spec_from_iter::SpecFromIter<char, core::str::iter::Chars>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VeccEINtB2_12SpecFromItercNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE9from_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr %iterator.0, ptr %iterator.1) unnamed_addr #0 !guid !497 {
start:
; call <alloc::vec::Vec<char> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<char, core::str::iter::Chars>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB4_3VeccEINtB2_18SpecFromIterNestedcNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE9from_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr %iterator.0, ptr %iterator.1)
  ret void
}

; <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter::SpecFromIter<usize, core::ops::range::RangeInclusive<usize>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecjEINtB2_12SpecFromIterjINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEE9from_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %iterator) unnamed_addr #0 !guid !498 {
start:
  %0 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iterator, i64 24, i1 false)
; call <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::ops::range::RangeInclusive<usize>>>::from_iter
  call void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB6_3VecjEINtB4_18SpecFromIterNestedjINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEE9from_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0)
  ret void
}

; <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter::SpecFromIter<usize, core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecjEINtB2_12SpecFromIterjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtB1q_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EE9from_iterB2S_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %iterator) unnamed_addr #0 !guid !499 {
start:
  %0 = alloca [32 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iterator, i64 32, i1 false)
; call <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>>::from_iter
  call void @_RNvXNtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB4_3VecjEINtB2_18SpecFromIterNestedjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtB1D_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EE9from_iterB35_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0)
  ret void
}

; <alloc::vec::Vec<u64> as alloc::vec::spec_from_iter::SpecFromIter<u64, core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec14spec_from_iterINtB4_3VecyEINtB2_12SpecFromIteryINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1q_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE9from_iterB2C_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %iterator) unnamed_addr #0 !guid !500 {
start:
  %0 = alloca [16 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iterator, i64 16, i1 false)
; call <alloc::vec::Vec<u64> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<u64, core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>>::from_iter
  call void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB6_3VecyEINtB4_18SpecFromIterNestedyINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1F_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE9from_iterB2R_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0)
  ret void
}

; <alloc::vec::Vec<char> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<char, core::str::iter::Chars>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB4_3VeccEINtB2_18SpecFromIterNestedcNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE9from_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !501 {
start:
  %2 = alloca [16 x i8], align 8
  %_23 = alloca [1 x i8], align 1
  %_22 = alloca [1 x i8], align 1
  %vector1 = alloca [24 x i8], align 8
  %_8 = alloca [24 x i8], align 8
  %_3 = alloca [4 x i8], align 4
  %vector = alloca [24 x i8], align 8
  %iterator = alloca [16 x i8], align 8
  store ptr %0, ptr %iterator, align 8
  %3 = getelementptr inbounds i8, ptr %iterator, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_23, align 1
  store i8 0, ptr %_22, align 1
  store i8 1, ptr %_23, align 1
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
  %4 = call i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %iterator) #15
  store i32 %4, ptr %_3, align 4
  br label %bb1

bb1:                                              ; preds = %start
  %5 = load i32, ptr %_3, align 4
  %6 = icmp eq i32 %5, -1
  %_5 = select i1 %6, i64 0, i64 1
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
  store i8 1, ptr %_22, align 1
  %element = load i32, ptr %_3, align 4
; call <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator9size_hintCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_8, ptr align 8 %iterator) #15
  br label %bb5

bb4:                                              ; preds = %bb1
; call <alloc::vec::Vec<char>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeccE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0) #15
  br label %bb13

bb13:                                             ; preds = %bb4
  br label %bb14

bb14:                                             ; preds = %bb12, %bb13
  ret void

bb5:                                              ; preds = %bb3
  %lower = load i64, ptr %_8, align 8
  %_0.i = call i64 @llvm.uadd.sat.i64(i64 %lower, i64 1)
  br label %bb6

bb6:                                              ; preds = %bb5
; call core::cmp::max::<usize>
  %initial_capacity = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64 4, i64 %_0.i) #15
  br label %bb7

bb7:                                              ; preds = %bb6
; call <alloc::vec::Vec<char>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeccE13with_capacityCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %vector1, i64 %initial_capacity) #15
  br label %bb8

bb8:                                              ; preds = %bb7
; invoke <alloc::vec::Vec<char>>::as_mut_ptr
  %_14 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %vector1)
          to label %bb9 unwind label %cleanup

bb16:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr align 8 %vector1) #16
          to label %bb19 unwind label %terminate

cleanup:                                          ; preds = %bb10, %bb8
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb16

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_22, align 1
  store i32 %element, ptr %_14, align 4
  br label %bb10

bb10:                                             ; preds = %bb9
; invoke <alloc::vec::Vec<char>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE7set_lenCscEnaBunu62E_10algorithms(ptr align 8 %vector1, i64 1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %vector, ptr align 8 %vector1, i64 24, i1 false)
  store i8 0, ptr %_22, align 1
  store i8 0, ptr %_23, align 1
  %_21.0 = load ptr, ptr %iterator, align 8
  %12 = getelementptr inbounds i8, ptr %iterator, i64 8
  %_21.1 = load ptr, ptr %12, align 8
; invoke <alloc::vec::Vec<char> as alloc::vec::spec_extend::SpecExtend<char, core::str::iter::Chars>>::spec_extend
  invoke void @_RNvXNtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB4_3VeccEINtB2_10SpecExtendcNtNtNtCsl10jNU3mE6R_4core3str4iter5CharsE11spec_extendCscEnaBunu62E_10algorithms(ptr align 8 %vector, ptr %_21.0, ptr %_21.1)
          to label %bb12 unwind label %cleanup2

bb15:                                             ; preds = %cleanup2
; invoke core::ptr::drop_glue::<alloc::vec::Vec<char>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeccEECscEnaBunu62E_10algorithms(ptr align 8 %vector) #16
          to label %bb21 unwind label %terminate

cleanup2:                                         ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          cleanup
  %14 = extractvalue { ptr, i32 } %13, 0
  %15 = extractvalue { ptr, i32 } %13, 1
  store ptr %14, ptr %2, align 8
  %16 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %15, ptr %16, align 8
  br label %bb15

bb12:                                             ; preds = %bb11
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %vector, i64 24, i1 false)
  br label %bb14

terminate:                                        ; preds = %bb16, %bb15
  %17 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb21:                                             ; preds = %bb18, %bb19, %bb15
  %18 = load i8, ptr %_23, align 1
  %19 = trunc nuw i8 %18 to i1
  br i1 %19, label %bb20, label %bb17

bb19:                                             ; preds = %bb16
  %20 = load i8, ptr %_22, align 1
  %21 = trunc nuw i8 %20 to i1
  br i1 %21, label %bb18, label %bb21

bb18:                                             ; preds = %bb19
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb17:                                             ; preds = %bb20, %bb21
  %22 = load ptr, ptr %2, align 8
  %23 = getelementptr inbounds i8, ptr %2, i64 8
  %24 = load i32, ptr %23, align 8
  %25 = insertvalue { ptr, i32 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i32 } %25, i32 %24, 1
  resume { ptr, i32 } %26

bb20:                                             ; preds = %bb21
  br label %bb17
}

; <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB4_3VecjEINtB2_18SpecFromIterNestedjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtB1D_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EE9from_iterB35_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %iterator) unnamed_addr #0 personality ptr @rust_eh_personality !guid !502 {
start:
  %0 = alloca [16 x i8], align 8
  %_23 = alloca [1 x i8], align 1
  %_22 = alloca [1 x i8], align 1
  %_21 = alloca [32 x i8], align 8
  %vector1 = alloca [24 x i8], align 8
  %_8 = alloca [24 x i8], align 8
  %_3 = alloca [16 x i8], align 8
  %vector = alloca [24 x i8], align 8
  store i8 0, ptr %_23, align 1
  store i8 0, ptr %_22, align 1
  store i8 1, ptr %_23, align 1
; call <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::iterator::Iterator>::next
  %1 = call { i64, i64 } @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6filterINtB5_6FilterINtNtNtBb_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtNtNtB9_6traits8iterator8Iterator4nextB1I_(ptr align 8 %iterator) #15
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  br label %bb1

bb1:                                              ; preds = %start
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
  store i8 1, ptr %_22, align 1
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %element = load i64, ptr %8, align 8
; call <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6filterINtB5_6FilterINtNtNtBb_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtNtNtB9_6traits8iterator8Iterator9size_hintB1I_(ptr sret([24 x i8]) align 8 %_8, ptr align 8 %iterator) #15
  br label %bb5

bb4:                                              ; preds = %bb1
; call <alloc::vec::Vec<usize>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0) #15
  br label %bb13

bb13:                                             ; preds = %bb4
  br label %bb14

bb14:                                             ; preds = %bb12, %bb13
  ret void

bb5:                                              ; preds = %bb3
  %lower = load i64, ptr %_8, align 8
  %_0.i = call i64 @llvm.uadd.sat.i64(i64 %lower, i64 1)
  br label %bb6

bb6:                                              ; preds = %bb5
; call core::cmp::max::<usize>
  %initial_capacity = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64 4, i64 %_0.i) #15
  br label %bb7

bb7:                                              ; preds = %bb6
; call <alloc::vec::Vec<usize>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE13with_capacityCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %vector1, i64 %initial_capacity) #15
  br label %bb8

bb8:                                              ; preds = %bb7
; invoke <alloc::vec::Vec<usize>>::as_mut_ptr
  %_14 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %vector1)
          to label %bb9 unwind label %cleanup

bb16:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %vector1) #16
          to label %bb19 unwind label %terminate

cleanup:                                          ; preds = %bb10, %bb8
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb16

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_22, align 1
  store i64 %element, ptr %_14, align 8
  br label %bb10

bb10:                                             ; preds = %bb9
; invoke <alloc::vec::Vec<usize>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE7set_lenCscEnaBunu62E_10algorithms(ptr align 8 %vector1, i64 1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb10
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %vector, ptr align 8 %vector1, i64 24, i1 false)
  store i8 0, ptr %_22, align 1
  store i8 0, ptr %_23, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_21, ptr align 8 %iterator, i64 32, i1 false)
; invoke <alloc::vec::Vec<usize> as alloc::vec::spec_extend::SpecExtend<usize, core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}>>>::spec_extend
  invoke void @_RNvXNtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB4_3VecjEINtB2_10SpecExtendjINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters6filter6FilterINtNtNtB1l_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0EE11spec_extendB2N_(ptr align 8 %vector, ptr align 8 %_21)
          to label %bb12 unwind label %cleanup2

bb15:                                             ; preds = %cleanup2
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %vector) #16
          to label %bb21 unwind label %terminate

cleanup2:                                         ; preds = %bb11
  %13 = landingpad { ptr, i32 }
          cleanup
  %14 = extractvalue { ptr, i32 } %13, 0
  %15 = extractvalue { ptr, i32 } %13, 1
  store ptr %14, ptr %0, align 8
  %16 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %15, ptr %16, align 8
  br label %bb15

bb12:                                             ; preds = %bb11
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %vector, i64 24, i1 false)
  br label %bb14

terminate:                                        ; preds = %bb16, %bb15
  %17 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb21:                                             ; preds = %bb18, %bb19, %bb15
  %18 = load i8, ptr %_23, align 1
  %19 = trunc nuw i8 %18 to i1
  br i1 %19, label %bb20, label %bb17

bb19:                                             ; preds = %bb16
  %20 = load i8, ptr %_22, align 1
  %21 = trunc nuw i8 %20 to i1
  br i1 %21, label %bb18, label %bb21

bb18:                                             ; preds = %bb19
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb17:                                             ; preds = %bb20, %bb21
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr inbounds i8, ptr %0, i64 8
  %24 = load i32, ptr %23, align 8
  %25 = insertvalue { ptr, i32 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i32 } %25, i32 %24, 1
  resume { ptr, i32 } %26

bb20:                                             ; preds = %bb21
  br label %bb17
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !503 {
start:
; call core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>
  %0 = call { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEEB6_(ptr align 8 %self) #15
  %_2.0 = extractvalue { i32, i32 } %0, 0
  %_2.1 = extractvalue { i32, i32 } %0, 1
; call <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}>
  %_0 = call i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXNtNtB5_3str4iterNtBU_5CharsNtNtNtNtB5_4iter6traits8iterator8Iterator4next0EB5_(i32 %_2.0, i32 %_2.1) #15
  ret i32 %_0
}

; <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXNtNtCsl10jNU3mE6R_4core3str4iterNtB2_5CharsNtNtNtNtB6_4iter6traits8iterator8Iterator9size_hintCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !504 {
start:
  %_0.i = alloca [8 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.i = load ptr, ptr %0, align 8
  %_6.i = load ptr, ptr %self, align 8
; call <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
  %1 = call i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedB9_(ptr %_5.i, ptr %_6.i) #15
  store i64 %1, ptr %_0.i, align 8
  %2 = load i64, ptr %_0.i, align 8
; call <usize>::div_ceil
  %_4 = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8div_ceilCscEnaBunu62E_10algorithms(i64 %2, i64 4, ptr align 8 @alloc_1a7c685630b0735376eef9074b3e654a) #15
  store i64 %_4, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %2, ptr %4, align 8
  ret void
}

; <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters3map3MapINtNtNtB8_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtB2_12IntoIterator9into_iterB1I_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !505 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %self, i64 16, i1 false)
  ret void
}

; <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters6filter6FilterINtNtNtB8_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtB2_12IntoIterator9into_iterB1Y_(ptr sret([32 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !506 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %self, i64 32, i1 false)
  ret void
}

; <core::iter::adapters::step_by::StepBy<core::ops::range::Range<i32>> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB6_8adapters7step_by6StepByINtNtNtB8_3ops5range5RangelEENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !507 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %self, i64 24, i1 false)
  ret void
}

; <core::slice::iter::Iter<[i64; 3]> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterAxj3_ENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !508 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<(u8, u8)> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterThhEENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !509 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<f64> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterdENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !510 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<usize> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterjENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !511 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<i64> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterxENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !512 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <core::slice::iter::Iter<u64> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IteryENtB2_12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !513 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <usize as core::slice::index::SliceIndex<[bool]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSbE5indexCscEnaBunu62E_10algorithms(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !514 {
start:
  %_4 = icmp ult i64 %self, %slice.1
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #14
  unreachable
}

; <usize as core::slice::index::SliceIndex<[bool]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSbE9index_mutCscEnaBunu62E_10algorithms(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !515 {
start:
  %_5 = icmp ult i64 %self, %slice.1
  br i1 %_5, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #14
  unreachable
}

; <usize as core::slice::index::SliceIndex<[char]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexScE5indexCscEnaBunu62E_10algorithms(i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !516 {
start:
  %_4 = icmp ult i64 %self, %slice.1
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #14
  unreachable
}

; <usize as core::slice::index::SliceIndex<[usize]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSjE5indexCscEnaBunu62E_10algorithms(i64 %self, ptr align 8 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !517 {
start:
  %_4 = icmp ult i64 %self, %slice.1
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw i64, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #14
  unreachable
}

; <usize as core::slice::index::SliceIndex<[usize]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSjE9index_mutCscEnaBunu62E_10algorithms(i64 %self, ptr align 8 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !518 {
start:
  %_5 = icmp ult i64 %self, %slice.1
  br i1 %_5, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw i64, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #14
  unreachable
}

; <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtNtNtB9_6traits8iterator8Iterator9size_hintB1s_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !519 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangelENtNtNtB7_6traits8iterator8Iterator9size_hintCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %_2) #15
  ret void
}

; <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtB9_6traits8iterator8Iterator4nextB1q_(ptr align 8 %self) unnamed_addr #1 !guid !520 {
start:
; call <core::ops::range::Range<u64> as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeyENtNtNtB7_6traits8iterator8Iterator4nextCs257F0UrNG3U_14rustc_demangle(ptr align 8 %self) #15
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_4 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::option::Option<u64>>::map::<u32, &mut algorithms::collatz>
  %1 = call { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionyE3mapmQNvCscEnaBunu62E_10algorithms7collatzEBS_(i64 %_2.0, i64 %_2.1, ptr %_4) #15
  %_0.0 = extractvalue { i32, i32 } %1, 0
  %_0.1 = extractvalue { i32, i32 } %1, 1
  %2 = insertvalue { i32, i32 } poison, i32 %_0.0, 0
  %3 = insertvalue { i32, i32 } %2, i32 %_0.1, 1
  ret { i32, i32 } %3
}

; <u32 as core::convert::TryFrom<usize>>::try_from
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core7convert3num18ptr_try_from_implsmINtB9_7TryFromjE8try_fromCscEnaBunu62E_10algorithms(i64 %u) unnamed_addr #1 !guid !521 {
start:
  %_0 = alloca [8 x i8], align 4
  %_2 = icmp ugt i64 %u, 4294967295
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = trunc i64 %u to i32
  %0 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_6, ptr %0, align 4
  store i8 0, ptr %_0, align 4
  br label %bb3

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %1, align 1
  store i8 1, ptr %_0, align 4
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i64, ptr %_0, align 4
  ret i64 %2
}

; <u32 as core::cmp::Ord>::cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXs11_NtNtCsl10jNU3mE6R_4core3cmp5implsmNtB8_3Ord3cmpCscEnaBunu62E_10algorithms(ptr align 4 %self, ptr align 4 %other) unnamed_addr #1 !guid !522 {
start:
  %_3 = load i32, ptr %self, align 4
  %_4 = load i32, ptr %other, align 4
  %_0 = call i8 @llvm.ucmp.i8.i32(i32 %_3, i32 %_4)
  ret i8 %_0
}

; <(u8, u8) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtThhENtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !523 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.7)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.7)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <alloc::raw_vec::RawVec<(u8, u8)> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecThhEENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !524 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 1, i64 2)
  ret void
}

; <alloc::raw_vec::RawVec<bool> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecbENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !525 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 1, i64 1)
  ret void
}

; <alloc::raw_vec::RawVec<char> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeccENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !526 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 4, i64 4)
  ret void
}

; <alloc::raw_vec::RawVec<usize> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !527 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 8, i64 8)
  ret void
}

; <alloc::raw_vec::RawVec<u64> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !528 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 8, i64 8)
  ret void
}

; <&mut core::iter::adapters::map::map_fold<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(u32, &u8)>>::call_mut
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core3ops8function5implsQNCINvNtNtNtBb_4iter8adapters3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtNtBX_6traits5accummNtB2j_3Sum3sumINtBT_3MapINtNtBV_7flatten7FlattenINtNtNtBb_5slice4iter4IterAhj8_EEB1x_EE0E0INtB7_5FnMutTmB1t_EE8call_mutB1B_(ptr align 8 %self, i32 %0, ptr %1) unnamed_addr #0 !guid !529 {
start:
  %args = alloca [16 x i8], align 8
  store i32 %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
  %_3 = load ptr, ptr %self, align 8
  %3 = load i32, ptr %args, align 8
  %4 = getelementptr inbounds i8, ptr %args, i64 8
  %5 = load ptr, ptr %4, align 8
; call core::iter::adapters::map::map_fold::<&u8, u32, u32, algorithms::main::{closure#2}, <u32 as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>, algorithms::main::{closure#2}>>::{closure#0}>::{closure#0}
  %_0 = call i32 @_RNCINvNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map8map_foldRhmmNCNvCscEnaBunu62E_10algorithms4mains0_0NCINvXsy_NtNtB8_6traits5accummNtB1K_3Sum3sumINtB4_3MapINtNtB6_7flatten7FlattenINtNtNtBa_5slice4iter4IterAhj8_EEBY_EE0E0B12_(ptr %_3, i32 %3, ptr %5) #15
  ret i32 %_0
}

; <&mut algorithms::sieve::{closure#0} as core::ops::function::FnMut<(&usize,)>>::call_mut
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core3ops8function5implsQNCNvCscEnaBunu62E_10algorithms5sieve0INtB7_5FnMutTRjEE8call_mutBS_(ptr align 8 %self, ptr align 8 %0) unnamed_addr #0 !guid !530 {
start:
  %args = alloca [8 x i8], align 8
  store ptr %0, ptr %args, align 8
  %_3 = load ptr, ptr %self, align 8
  %1 = load ptr, ptr %args, align 8
; call algorithms::sieve::{closure#0}
  %_0 = call zeroext i1 @_RNCNvCscEnaBunu62E_10algorithms5sieve0B3_(ptr align 8 %_3, ptr align 8 %1) #15
  ret i1 %_0
}

; <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6filterINtB5_6FilterINtNtNtBb_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtNtNtB9_6traits8iterator8Iterator4nextB1I_(ptr align 8 %self) unnamed_addr #1 !guid !531 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::find::<&mut algorithms::sieve::{closure#0}>
  %0 = call { i64, i64 } @_RINvYINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejENtNtNtNtBa_4iter6traits8iterator8Iterator4findQNCNvCscEnaBunu62E_10algorithms5sieve0EB1K_(ptr align 8 %_2, ptr align 8 %self) #15
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::iter::adapters::filter::Filter<core::ops::range::RangeInclusive<usize>, algorithms::sieve::{closure#0}> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core4iter8adapters6filterINtB5_6FilterINtNtNtBb_3ops5range14RangeInclusivejENCNvCscEnaBunu62E_10algorithms5sieve0ENtNtNtB9_6traits8iterator8Iterator9size_hintB1I_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !532 {
start:
  %_3 = alloca [24 x i8], align 8
  %_4 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range14RangeInclusivejENtNtNtB7_6traits8iterator8Iterator9size_hintCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %_4) #15
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %upper.0 = load i64, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  %upper.1 = load i64, ptr %1, align 8
  store i64 0, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %upper.0, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %upper.1, ptr %3, align 8
  ret void
}

; <&[i64; 3] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRAxj3_NtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !533 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <[i64; 3] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAxj3_NtNtB7_3fmt5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&[[i64; 3]] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSAxj3_NtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !534 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[[i64; 3]] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSAxj3_NtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[(u8, u8)] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSThhENtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !535 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[(u8, u8)] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSThhENtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[f64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSdNtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !536 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[f64] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSdNtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[usize] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSjNtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !537 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[usize] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSjNtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[i64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSxNtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !538 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[i64] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSxNtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&[u64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSyNtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !539 {
start:
  %_3.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3.1 = load i64, ptr %0, align 8
; call <[u64] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSyNtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <&(u8, u8) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRThhENtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !540 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <(u8, u8) as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtThhENtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr %_3, ptr align 8 %f)
  ret i1 %_0
}

; <&f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRdNtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !541 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <f64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8 %_3, ptr align 8 %f)
  ret i1 %_0
}

; <core::slice::iter::Iter<[i64; 3]> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterAxj3_ENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !542 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<[i64; 3]> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAxj3_ENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %ptr, ptr align 8 %_11) #15
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw [3 x i64], ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<(u8, u8)> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterThhEENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !543 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<(u8, u8)> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullThhEENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %ptr, ptr align 8 %_11) #15
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw { i8, i8 }, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<f64> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterdENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !544 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %ptr, ptr align 8 %_11) #15
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw double, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <core::slice::iter::Iter<i64> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterxENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !545 {
start:
  %_15 = alloca [8 x i8], align 8
  %_11 = alloca [8 x i8], align 8
  %ptr = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  store ptr %0, ptr %ptr, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %end_or_len = load ptr, ptr %1, align 8
  br label %bb7

bb7:                                              ; preds = %start
  store ptr %end_or_len, ptr %_11, align 8
; call <core::ptr::non_null::NonNull<i64> as core::cmp::PartialEq>::eq
  %_8 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %ptr, ptr align 8 %_11) #15
  br i1 %_8, label %bb9, label %bb10

bb10:                                             ; preds = %bb7
  %2 = load ptr, ptr %ptr, align 8
  %_3.i = getelementptr inbounds nuw i64, ptr %2, i64 1
  store ptr %_3.i, ptr %self, align 8
  br label %bb12

bb9:                                              ; preds = %bb7
  store ptr null, ptr %_0, align 8
  br label %bb14

bb12:                                             ; preds = %bb10
  %3 = load ptr, ptr %ptr, align 8
  store ptr %3, ptr %_15, align 8
  %_4.i = load ptr, ptr %_15, align 8
  store ptr %_4.i, ptr %_0, align 8
  br label %bb14

bb14:                                             ; preds = %bb9, %bb12
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <u64 as core::ops::arith::Add>::add
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXs2_NtNtCsl10jNU3mE6R_4core3ops5arithyNtB5_3Add3addCscEnaBunu62E_10algorithms(i64 %self, i64 %other, ptr align 8 %0) unnamed_addr #1 !guid !546 {
start:
  %_3.0 = add i64 %self, %other
  %_3.1 = icmp ult i64 %_3.0, %self
  br i1 %_3.1, label %panic, label %bb1

bb1:                                              ; preds = %start
  ret i64 %_3.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 %0) #14
  unreachable
}

; <&mut algorithms::collatz as core::ops::function::FnOnce<(u64,)>>::call_once
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvXs2_NtNtNtCsl10jNU3mE6R_4core3ops8function5implsQNvCscEnaBunu62E_10algorithms7collatzINtB7_6FnOnceTyEE9call_onceBQ_(ptr %self, i64 %0) unnamed_addr #0 !guid !547 {
start:
  %args = alloca [8 x i8], align 8
  store i64 %0, ptr %args, align 8
  %1 = load i64, ptr %args, align 8
; call <algorithms::collatz as core::ops::function::FnMut<(u64,)>>::call_mut
  %_0 = call i32 @_RNvYNvCscEnaBunu62E_10algorithms7collatzINtNtNtCsl10jNU3mE6R_4core3ops8function5FnMutTyEE8call_mutB4_(ptr %self, i64 %1) #15
  ret i32 %_0
}

; <&mut <u32 as core::cmp::Ord>::cmp as core::ops::function::FnOnce<(&u32, &u32)>>::call_once
; Function Attrs: nonlazybind uwtable
define internal i8 @_RNvXs2_NtNtNtCsl10jNU3mE6R_4core3ops8function5implsQNvYmNtNtBb_3cmp3Ord3cmpINtB7_6FnOnceTRmB1p_EE9call_onceCscEnaBunu62E_10algorithms(ptr %self, ptr align 4 %0, ptr align 4 %1) unnamed_addr #0 !guid !548 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
  %3 = load ptr, ptr %args, align 8
  %4 = getelementptr inbounds i8, ptr %args, i64 8
  %5 = load ptr, ptr %4, align 8
; call <<u32 as core::cmp::Ord>::cmp as core::ops::function::FnMut<(&u32, &u32)>>::call_mut
  %_0 = call i8 @_RNvYNvYmNtNtCsl10jNU3mE6R_4core3cmp3Ord3cmpINtNtNtBa_3ops8function5FnMutTRmB19_EE8call_mutCscEnaBunu62E_10algorithms(ptr %self, ptr align 4 %3, ptr align 4 %5) #15
  ret i8 %_0
}

; <core::ops::range::Range<i32> as core::iter::range::RangeIteratorImpl>::spec_nth
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangelENtB5_17RangeIteratorImpl8spec_nthCscEnaBunu62E_10algorithms(ptr align 4 %self, i64 %n) unnamed_addr #1 !guid !549 {
start:
  %plus_n = alloca [4 x i8], align 4
  %_3 = alloca [8 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_4 = load i32, ptr %self, align 4
; call <i32 as core::iter::range::Step>::forward_checked
  %0 = call { i32, i32 } @_RNvXsI_NtNtCsl10jNU3mE6R_4core4iter5rangelNtB5_4Step15forward_checkedCscEnaBunu62E_10algorithms(i32 %_4, i64 %n) #15
  %1 = extractvalue { i32, i32 } %0, 0
  %2 = extractvalue { i32, i32 } %0, 1
  store i32 %1, ptr %_3, align 4
  %3 = getelementptr inbounds i8, ptr %_3, i64 4
  store i32 %2, ptr %3, align 4
  %4 = load i32, ptr %_3, align 4
  %5 = getelementptr inbounds i8, ptr %_3, i64 4
  %6 = load i32, ptr %5, align 4
  %_5 = zext i32 %4 to i64
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb2, label %bb6

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 4
  %9 = load i32, ptr %8, align 4
  store i32 %9, ptr %plus_n, align 4
  %_9 = getelementptr inbounds i8, ptr %self, i64 4
  %_3.i = load i32, ptr %plus_n, align 4
  %_4.i = load i32, ptr %_9, align 4
  %_0.i = icmp slt i32 %_3.i, %_4.i
  br i1 %_0.i, label %bb4, label %bb6

bb6:                                              ; preds = %bb2, %start
  %10 = getelementptr inbounds i8, ptr %self, i64 4
  %_13 = load i32, ptr %10, align 4
  store i32 %_13, ptr %self, align 4
  store i32 0, ptr %_0, align 4
  br label %bb7

bb4:                                              ; preds = %bb2
  %_11 = load i32, ptr %plus_n, align 4
; call <i32 as core::iter::range::Step>::forward_unchecked
  %_10 = call i32 @_RNvXsI_NtNtCsl10jNU3mE6R_4core4iter5rangelNtB5_4Step17forward_uncheckedCscEnaBunu62E_10algorithms(i32 %_11, i64 1) #15
  store i32 %_10, ptr %self, align 4
  %_12 = load i32, ptr %plus_n, align 4
  %11 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_12, ptr %11, align 4
  store i32 1, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb6, %bb4
  %12 = load i32, ptr %_0, align 4
  %13 = getelementptr inbounds i8, ptr %_0, i64 4
  %14 = load i32, ptr %13, align 4
  %15 = insertvalue { i32, i32 } poison, i32 %12, 0
  %16 = insertvalue { i32, i32 } %15, i32 %14, 1
  ret { i32, i32 } %16

bb8:                                              ; No predecessors!
  unreachable
}

; <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::nth
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangelENtNtNtB7_6traits8iterator8Iterator3nthCscEnaBunu62E_10algorithms(ptr align 4 %self, i64 %n) unnamed_addr #1 !guid !550 {
start:
; call <core::ops::range::Range<i32> as core::iter::range::RangeIteratorImpl>::spec_nth
  %0 = call { i32, i32 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangelENtB5_17RangeIteratorImpl8spec_nthCscEnaBunu62E_10algorithms(ptr align 4 %self, i64 %n) #15
  %_0.0 = extractvalue { i32, i32 } %0, 0
  %_0.1 = extractvalue { i32, i32 } %0, 1
  %1 = insertvalue { i32, i32 } poison, i32 %_0.0, 0
  %2 = insertvalue { i32, i32 } %1, i32 %_0.1, 1
  ret { i32, i32 } %2
}

; <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangelENtNtNtB7_6traits8iterator8Iterator9size_hintCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %self) unnamed_addr #1 !guid !551 {
start:
  %_4 = getelementptr inbounds i8, ptr %self, i64 4
  %_3.i = load i32, ptr %self, align 4
  %_4.i = load i32, ptr %_4, align 4
  %_0.i = icmp slt i32 %_3.i, %_4.i
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 0, ptr %1, align 8
  br label %bb4

bb2:                                              ; preds = %start
  %_6 = getelementptr inbounds i8, ptr %self, i64 4
; call <i32 as core::iter::range::Step>::steps_between
  call void @_RNvXsI_NtNtCsl10jNU3mE6R_4core4iter5rangelNtB5_4Step13steps_betweenCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %self, ptr align 4 %_6) #15
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void
}

; <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[usize]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSjE5indexCscEnaBunu62E_10algorithms(i64 %self, ptr align 8 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !552 {
start:
  %_3 = icmp ugt i64 %self, %slice.1
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %new_len = sub nuw i64 %slice.1, %self
  %ptr.i = getelementptr inbounds nuw i64, ptr %slice.0, i64 %self
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %new_len, 1
  %_13.0 = extractvalue { ptr, i64 } %2, 0
  %_13.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_13.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_13.1, 1
  ret { ptr, i64 } %4

bb1:                                              ; preds = %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %self, i64 %slice.1, i64 %slice.1, ptr align 8 %0) #14
  unreachable
}

; <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[u64]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSyE5indexCscEnaBunu62E_10algorithms(i64 %self, ptr align 8 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !553 {
start:
  %_3 = icmp ugt i64 %self, %slice.1
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %new_len = sub nuw i64 %slice.1, %self
  %ptr.i = getelementptr inbounds nuw i64, ptr %slice.0, i64 %self
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %new_len, 1
  %_13.0 = extractvalue { ptr, i64 } %2, 0
  %_13.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_13.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_13.1, 1
  ret { ptr, i64 } %4

bb1:                                              ; preds = %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %self, i64 %slice.1, i64 %slice.1, ptr align 8 %0) #14
  unreachable
}

; <core::ops::range::Range<i32> as core::iter::adapters::step_by::SpecRangeSetup<core::ops::range::Range<i32>>>::setup
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXs5_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7step_byINtNtNtBb_3ops5range5RangelEINtB5_14SpecRangeSetupBQ_E5setupCscEnaBunu62E_10algorithms(i32 %inner.0, i32 %inner.1, i64 %_step) unnamed_addr #1 !guid !554 {
start:
  %0 = insertvalue { i32, i32 } poison, i32 %inner.0, 0
  %1 = insertvalue { i32, i32 } %0, i32 %inner.1, 1
  ret { i32, i32 } %1
}

; <core::iter::adapters::step_by::StepBy<core::ops::range::Range<i32>> as core::iter::adapters::step_by::StepByImpl<core::ops::range::Range<i32>>>::spec_next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXs6_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7step_byINtB5_6StepByINtNtNtBb_3ops5range5RangelEEINtB5_10StepByImplB13_E9spec_nextCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !555 {
start:
  %step_size = alloca [8 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %1 = load i8, ptr %0, align 8
  %_3 = trunc nuw i8 %1 to i1
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  %3 = load i64, ptr %2, align 8
  store i64 %3, ptr %step_size, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %step_size, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = getelementptr inbounds i8, ptr %self, i64 16
  store i8 0, ptr %4, align 8
  %_5 = load i64, ptr %step_size, align 8
; call <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::nth
  %5 = call { i32, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangelENtNtNtB7_6traits8iterator8Iterator3nthCscEnaBunu62E_10algorithms(ptr align 4 %self, i64 %_5) #15
  %_0.0 = extractvalue { i32, i32 } %5, 0
  %_0.1 = extractvalue { i32, i32 } %5, 1
  %6 = insertvalue { i32, i32 } poison, i32 %_0.0, 0
  %7 = insertvalue { i32, i32 } %6, i32 %_0.1, 1
  ret { i32, i32 } %7
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[[i64; 3]]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSAxj3_E5indexCscEnaBunu62E_10algorithms(ptr align 8 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !556 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[f64]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSdE5indexCscEnaBunu62E_10algorithms(ptr align 8 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !557 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i64]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSxE5indexCscEnaBunu62E_10algorithms(ptr align 8 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #1 !guid !558 {
start:
  %1 = insertvalue { ptr, i64 } poison, ptr %slice.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %slice.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<(u8, u8)> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !559 {
start:
; call <alloc::vec::Vec<(u8, u8)>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecThhEE8as_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<bool> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !560 {
start:
; call <alloc::vec::Vec<bool>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE8as_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<char> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !561 {
start:
; call <alloc::vec::Vec<char>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE8as_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<u64> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !562 {
start:
; call <alloc::vec::Vec<u64>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE8as_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<bool> as core::ops::deref::DerefMut>::deref_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !563 {
start:
; call <alloc::vec::Vec<bool>>::as_mut_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE12as_mut_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<usize> as core::ops::deref::DerefMut>::deref_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !564 {
start:
; call <alloc::vec::Vec<usize>>::as_mut_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE12as_mut_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<u64> as core::ops::deref::DerefMut>::deref_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !565 {
start:
; call <alloc::vec::Vec<u64>>::as_mut_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE12as_mut_sliceCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <i32 as core::iter::range::Step>::steps_between
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsI_NtNtCsl10jNU3mE6R_4core4iter5rangelNtB5_4Step13steps_betweenCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %start1, ptr align 4 %end) unnamed_addr #1 !guid !566 {
start:
  %_4 = load i32, ptr %start1, align 4
  %_5 = load i32, ptr %end, align 4
  %_3 = icmp sle i32 %_4, %_5
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 undef, ptr %1, align 8
  br label %bb4

bb1:                                              ; preds = %start
  %_9 = load i32, ptr %end, align 4
  %_8 = sext i32 %_9 to i64
  %_11 = load i32, ptr %start1, align 4
  %_10 = sext i32 %_11 to i64
  %_0.i = sub i64 %_8, %_10
  store i64 %_0.i, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %_0.i, ptr %3, align 8
  br label %bb4

bb4:                                              ; preds = %bb1, %bb3
  ret void
}

; <i32 as core::iter::range::Step>::forward_checked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXsI_NtNtCsl10jNU3mE6R_4core4iter5rangelNtB5_4Step15forward_checkedCscEnaBunu62E_10algorithms(i32 %start1, i64 %n) unnamed_addr #1 !guid !567 {
start:
  %0 = alloca [8 x i8], align 8
  %_3 = alloca [8 x i8], align 4
  %_0 = alloca [8 x i8], align 4
; call <u32 as core::convert::TryFrom<usize>>::try_from
  %1 = call i64 @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core7convert3num18ptr_try_from_implsmINtB9_7TryFromjE8try_fromCscEnaBunu62E_10algorithms(i64 %n) #15
  store i64 %1, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_3, ptr align 8 %0, i64 8, i1 false)
  %2 = load i8, ptr %_3, align 4
  %3 = trunc nuw i8 %2 to i1
  %_4 = zext i1 %3 to i64
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb3, label %bb4

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb8

bb4:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %_3, i64 4
  %n2 = load i32, ptr %5, align 4
  %_0.i = add i32 %start1, %n2
  %_8 = icmp sge i32 %_0.i, %start1
  br i1 %_8, label %bb6, label %bb7

bb7:                                              ; preds = %bb4
  store i32 0, ptr %_0, align 4
  br label %bb8

bb6:                                              ; preds = %bb4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_0.i, ptr %6, align 4
  store i32 1, ptr %_0, align 4
  br label %bb8

bb8:                                              ; preds = %bb3, %bb6, %bb7
  %7 = load i32, ptr %_0, align 4
  %8 = getelementptr inbounds i8, ptr %_0, i64 4
  %9 = load i32, ptr %8, align 4
  %10 = insertvalue { i32, i32 } poison, i32 %7, 0
  %11 = insertvalue { i32, i32 } %10, i32 %9, 1
  ret { i32, i32 } %11

bb2:                                              ; No predecessors!
  unreachable
}

; <i32 as core::iter::range::Step>::forward_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvXsI_NtNtCsl10jNU3mE6R_4core4iter5rangelNtB5_4Step17forward_uncheckedCscEnaBunu62E_10algorithms(i32 %start1, i64 %n) unnamed_addr #1 !guid !568 {
start:
  %_4 = trunc i64 %n to i32
; call <i32>::checked_add_unsigned
  %0 = call { i32, i32 } @_RNvMs0_NtCsl10jNU3mE6R_4core3numl20checked_add_unsignedCscEnaBunu62E_10algorithms(i32 %start1, i32 %_4) #15
  %_3.0 = extractvalue { i32, i32 } %0, 0
  %_3.1 = extractvalue { i32, i32 } %0, 1
; call <core::option::Option<i32>>::unwrap_unchecked
  %_0 = call i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE16unwrap_uncheckedCsddYV2PBJW9h_3std(i32 %_3.0, i32 %_3.1, ptr align 8 @alloc_33c781d4b73231c4b72218e776044e11) #15
  ret i32 %_0
}

; <usize as core::iter::range::Step>::steps_between
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsL_NtNtCsl10jNU3mE6R_4core4iter5rangejNtB5_4Step13steps_betweenCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %start1, ptr align 8 %end) unnamed_addr #1 !guid !569 {
start:
  %_4 = load i64, ptr %start1, align 8
  %_5 = load i64, ptr %end, align 8
  %_3 = icmp ule i64 %_4, %_5
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 undef, ptr %1, align 8
  br label %bb3

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %end, align 8
  %_8 = load i64, ptr %start1, align 8
  %steps = sub i64 %_7, %_8
  store i64 %steps, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %2, i64 8
  store i64 %steps, ptr %3, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  ret void
}

; <usize as core::iter::range::Step>::forward_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXsL_NtNtCsl10jNU3mE6R_4core4iter5rangejNtB5_4Step17forward_uncheckedCscEnaBunu62E_10algorithms(i64 %start1, i64 %n) unnamed_addr #1 !guid !570 {
start:
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCscEnaBunu62E_10algorithms() #15
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCscEnaBunu62E_10algorithms(i64 %start1, i64 %n, ptr align 8 @alloc_33c781d4b73231c4b72218e776044e11) #18
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i64 %start1, %n
  ret i64 %_0.i
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCscEnaBunu62E_10algorithms() unnamed_addr #1 !guid !571 {
start:
  ret i8 0
}

; <core::slice::iter::Windows<u64> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsY_NtNtCsl10jNU3mE6R_4core5slice4iterINtB5_7WindowsyENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !572 {
start:
  %_3.i.i = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <core::num::nonzero::NonZero<usize>>::get
  %_3 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %_4) #15
  %_13.0 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %_13.1 = load i64, ptr %1, align 8
  %_2 = icmp ugt i64 %_3, %_13.1
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_14.0 = load ptr, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  %_14.1 = load i64, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 16
  %_10 = load i64, ptr %3, align 8
; call <core::num::nonzero::NonZero<usize>>::get
  %_9 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %_10) #15
; call <usize>::checked_sub
  %4 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCscEnaBunu62E_10algorithms(i64 %_9, i64 0) #15
  %5 = extractvalue { i64, i64 } %4, 0
  %6 = extractvalue { i64, i64 } %4, 1
  store i64 %5, ptr %_3.i.i, align 8
  %7 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  store i64 %6, ptr %7, align 8
  %_6.i.i = load i64, ptr %_3.i.i, align 8
  %8 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = trunc nuw i64 %_6.i.i to i1
  br i1 %10, label %bb2.i.i, label %bb5.i.i

bb2.i.i:                                          ; preds = %bb3
  %11 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %new_len.i.i = load i64, ptr %11, align 8
  %_8.i.i = icmp ule i64 %_9, %_14.1
  br i1 %_8.i.i, label %_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSyE5indexCscEnaBunu62E_10algorithms.exit, label %bb5.i.i

bb5.i.i:                                          ; preds = %bb2.i.i, %bb3
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 0, i64 %_9, i64 %_14.1, ptr align 8 @alloc_4174dac9b534508af33ae1f81dabb21d) #14
  unreachable

_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSyE5indexCscEnaBunu62E_10algorithms.exit: ; preds = %bb2.i.i
  %12 = insertvalue { ptr, i64 } poison, ptr %_14.0, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %new_len.i.i, 1
  %14 = insertvalue { ptr, i64 } poison, ptr %_14.0, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %new_len.i.i, 1
  %16 = insertvalue { ptr, i64 } poison, ptr %_14.0, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %new_len.i.i, 1
  %_0.0.i = extractvalue { ptr, i64 } %17, 0
  %_0.1.i = extractvalue { ptr, i64 } %17, 1
  %_7.0 = extractvalue { ptr, i64 } %17, 0
  %_7.1 = extractvalue { ptr, i64 } %17, 1
  %_15.0 = load ptr, ptr %self, align 8
  %18 = getelementptr inbounds i8, ptr %self, i64 8
  %_15.1 = load i64, ptr %18, align 8
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[u64]>>::index
  %19 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSyE5indexCscEnaBunu62E_10algorithms(i64 1, ptr align 8 %_15.0, i64 %_15.1, ptr align 8 @alloc_023f381c9f0987bf7ab9a4d4a6f7a392) #15
  %_0.0.i1 = extractvalue { ptr, i64 } %19, 0
  %_0.1.i2 = extractvalue { ptr, i64 } %19, 1
  %_11.0 = extractvalue { ptr, i64 } %19, 0
  %_11.1 = extractvalue { ptr, i64 } %19, 1
  store ptr %_11.0, ptr %self, align 8, !captures !190
  %20 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %_11.1, ptr %20, align 8
  store ptr %_7.0, ptr %_0, align 8
  %21 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_7.1, ptr %21, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSyE5indexCscEnaBunu62E_10algorithms.exit
  %22 = load ptr, ptr %_0, align 8
  %23 = getelementptr inbounds i8, ptr %_0, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  ret { ptr, i64 } %26
}

; <alloc::vec::Vec<usize> as alloc::vec::spec_extend::SpecExtend<usize, core::ops::range::RangeInclusive<usize>>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB6_3VecjEINtB4_10SpecExtendjINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEE11spec_extendCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %iterator) unnamed_addr #0 !guid !573 {
start:
  %0 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iterator, i64 24, i1 false)
; call <alloc::vec::Vec<usize>>::extend_trusted::<core::ops::range::RangeInclusive<usize>>
  call void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEECscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %0)
  ret void
}

; <alloc::vec::Vec<u64> as alloc::vec::spec_extend::SpecExtend<u64, core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>>::spec_extend
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB6_3VecyEINtB4_10SpecExtendyINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1n_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE11spec_extendB2z_(ptr align 8 %self, ptr align 8 %iterator) unnamed_addr #0 !guid !574 {
start:
  %0 = alloca [16 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %iterator, i64 16, i1 false)
; call <alloc::vec::Vec<u64>>::extend_trusted::<core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>
  call void @_RINvMsk_NtCs7CppTae75M1_5alloc3vecINtB6_3VecyE14extend_trustedINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB17_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EEB2j_(ptr align 8 %self, ptr align 8 %0)
  ret void
}

; <alloc::vec::Vec<usize> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<usize, core::ops::range::RangeInclusive<usize>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB6_3VecjEINtB4_18SpecFromIterNestedjINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEE9from_iterCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %iterator) unnamed_addr #0 personality ptr @rust_eh_personality !guid !575 {
start:
  %0 = alloca [16 x i8], align 8
  %_12 = alloca [1 x i8], align 1
  %_11 = alloca [24 x i8], align 8
  %_3 = alloca [24 x i8], align 8
  %vector = alloca [24 x i8], align 8
  store i8 0, ptr %_12, align 1
  store i8 1, ptr %_12, align 1
; call <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range14RangeInclusivejENtNtNtB7_6traits8iterator8Iterator9size_hintCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %iterator) #15
  br label %bb1

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  %_5 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = trunc nuw i64 %_5 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %bb1
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %upper = load i64, ptr %6, align 8
; call <alloc::vec::Vec<usize>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecjE13with_capacityCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %vector, i64 %upper) #15
  br label %bb4

bb2:                                              ; preds = %bb1
; call <core::fmt::Arguments>::from_str
  %7 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_31365cfefba383c4d2bf6b6a04cc10aa, i64 17) #15
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  br label %bb5

bb4:                                              ; preds = %bb3
  store i8 0, ptr %_12, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_11, ptr align 8 %iterator, i64 24, i1 false)
; invoke <alloc::vec::Vec<usize> as alloc::vec::spec_extend::SpecExtend<usize, core::ops::range::RangeInclusive<usize>>>::spec_extend
  invoke void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB6_3VecjEINtB4_10SpecExtendjINtNtNtCsl10jNU3mE6R_4core3ops5range14RangeInclusivejEE11spec_extendCscEnaBunu62E_10algorithms(ptr align 8 %vector, ptr align 8 %_11)
          to label %bb6 unwind label %cleanup

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<usize>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecjEECscEnaBunu62E_10algorithms(ptr align 8 %vector) #16
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb7

bb6:                                              ; preds = %bb4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %vector, i64 24, i1 false)
  ret void

terminate:                                        ; preds = %bb7
  %12 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb10:                                             ; preds = %bb7
  %13 = load i8, ptr %_12, align 1
  %14 = trunc nuw i8 %13 to i1
  br i1 %14, label %bb9, label %bb8

bb5:                                              ; preds = %bb2
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_8.0, ptr %_8.1, ptr align 8 @alloc_391673418deaa0b14b40e679e64fed1a) #14
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb8:                                              ; preds = %bb9, %bb10
  %15 = load ptr, ptr %0, align 8
  %16 = getelementptr inbounds i8, ptr %0, i64 8
  %17 = load i32, ptr %16, align 8
  %18 = insertvalue { ptr, i32 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i32 } %18, i32 %17, 1
  resume { ptr, i32 } %19

bb9:                                              ; preds = %bb10
  br label %bb8
}

; <alloc::vec::Vec<u64> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<u64, core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>>::from_iter
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec21spec_from_iter_nestedINtB6_3VecyEINtB4_18SpecFromIterNestedyINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1F_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE9from_iterB2R_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %iterator) unnamed_addr #0 personality ptr @rust_eh_personality !guid !576 {
start:
  %0 = alloca [16 x i8], align 8
  %_12 = alloca [1 x i8], align 1
  %_11 = alloca [16 x i8], align 8
  %_3 = alloca [24 x i8], align 8
  %vector = alloca [24 x i8], align 8
  store i8 0, ptr %_12, align 1
  store i8 1, ptr %_12, align 1
; call <core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}> as core::iter::traits::iterator::Iterator>::size_hint
  call void @_RNvXs0_NtNtNtCsl10jNU3mE6R_4core4iter8adapters3mapINtB5_3MapINtNtNtBb_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0ENtNtNtB9_6traits8iterator8Iterator9size_hintB1s_(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %iterator) #15
  br label %bb1

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  %_5 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = trunc nuw i64 %_5 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %bb1
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  %upper = load i64, ptr %6, align 8
; call <alloc::vec::Vec<u64>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecyE13with_capacityCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %vector, i64 %upper) #15
  br label %bb4

bb2:                                              ; preds = %bb1
; call <core::fmt::Arguments>::from_str
  %7 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCscEnaBunu62E_10algorithms(ptr @alloc_31365cfefba383c4d2bf6b6a04cc10aa, i64 17) #15
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  br label %bb5

bb4:                                              ; preds = %bb3
  store i8 0, ptr %_12, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_11, ptr align 8 %iterator, i64 16, i1 false)
; invoke <alloc::vec::Vec<u64> as alloc::vec::spec_extend::SpecExtend<u64, core::iter::adapters::map::Map<core::ops::range::Range<i32>, algorithms::main::{closure#0}>>>::spec_extend
  invoke void @_RNvXs_NtNtCs7CppTae75M1_5alloc3vec11spec_extendINtB6_3VecyEINtB4_10SpecExtendyINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtB1n_3ops5range5RangelENCNvCscEnaBunu62E_10algorithms4main0EE11spec_extendB2z_(ptr align 8 %vector, ptr align 8 %_11)
          to label %bb6 unwind label %cleanup

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u64>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecyEECscEnaBunu62E_10algorithms(ptr align 8 %vector) #16
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb7

bb6:                                              ; preds = %bb4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %vector, i64 24, i1 false)
  ret void

terminate:                                        ; preds = %bb7
  %12 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #17
  unreachable

bb10:                                             ; preds = %bb7
  %13 = load i8, ptr %_12, align 1
  %14 = trunc nuw i8 %13 to i1
  br i1 %14, label %bb9, label %bb8

bb5:                                              ; preds = %bb2
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_8.0, ptr %_8.1, ptr align 8 @alloc_391673418deaa0b14b40e679e64fed1a) #14
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb8:                                              ; preds = %bb9, %bb10
  %15 = load ptr, ptr %0, align 8
  %16 = getelementptr inbounds i8, ptr %0, i64 8
  %17 = load i32, ptr %16, align 8
  %18 = insertvalue { ptr, i32 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i32 } %18, i32 %17, 1
  resume { ptr, i32 } %19

bb9:                                              ; preds = %bb10
  br label %bb8
}

; <core::iter::adapters::step_by::StepBy<core::ops::range::Range<i32>> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvXs_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7step_byINtB4_6StepByINtNtNtBa_3ops5range5RangelEENtNtNtB8_6traits8iterator8Iterator4nextCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #1 !guid !577 {
start:
; call <core::iter::adapters::step_by::StepBy<core::ops::range::Range<i32>> as core::iter::adapters::step_by::StepByImpl<core::ops::range::Range<i32>>>::spec_next
  %0 = call { i32, i32 } @_RNvXs6_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7step_byINtB5_6StepByINtNtNtBb_3ops5range5RangelEEINtB5_10StepByImplB13_E9spec_nextCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_0.0 = extractvalue { i32, i32 } %0, 0
  %_0.1 = extractvalue { i32, i32 } %0, 1
  %1 = insertvalue { i32, i32 } poison, i32 %_0.0, 0
  %2 = insertvalue { i32, i32 } %1, i32 %_0.1, 1
  ret { i32, i32 } %2
}

; <[[i64; 3]; 3] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAAxj3_Bz_NtNtB7_3fmt5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !578 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[[i64; 3]; 3] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAAxj3_Bz_INtNtNtB7_3ops5index5IndexNtNtBK_5range9RangeFullE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #15
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !190
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[[i64; 3]] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSAxj3_NtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[f64; 5] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAdj5_NtNtB7_3fmt5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !579 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[f64; 5] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAdj5_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #15
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !190
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[f64] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSdNtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <[i64; 3] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsa_NtCsl10jNU3mE6R_4core5arrayAxj3_NtNtB7_3fmt5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !580 {
start:
  %_4 = alloca [16 x i8], align 8
; call <[i64; 3] as core::ops::index::Index<core::ops::range::RangeFull>>::index
  %0 = call { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAxj3_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 @alloc_bb689cb4c05c0bf38d31dd7cd71b8150) #15
  %_5.0 = extractvalue { ptr, i64 } %0, 0
  %_5.1 = extractvalue { ptr, i64 } %0, 1
  store ptr %_5.0, ptr %_4, align 8, !captures !190
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_5.1, ptr %1, align 8
; call <&[i64] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRSxNtB6_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %_4, ptr align 8 %f)
  ret i1 %_0
}

; <&[u8; 8] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXsb_NtCsl10jNU3mE6R_4core5arrayRAhj8_NtNtNtNtB7_4iter6traits7collect12IntoIterator9into_iterCscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #0 !guid !581 {
start:
; call <[u8]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterB4_(ptr %self, i64 8) #15
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <alloc::vec::Vec<(u8, u8)> as core::ops::index::Index<core::ops::range::RangeTo<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBP_5range7RangeTojEE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !582 {
start:
  %_3.i.i = alloca [16 x i8], align 8
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<(u8, u8)> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize>::checked_sub
  %2 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCscEnaBunu62E_10algorithms(i64 %index, i64 0) #15
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %_3.i.i, align 8
  %5 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  store i64 %4, ptr %5, align 8
  %_6.i.i = load i64, ptr %_3.i.i, align 8
  %6 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = trunc nuw i64 %_6.i.i to i1
  br i1 %8, label %bb2.i.i, label %bb5.i.i

bb2.i.i:                                          ; preds = %bb1
  %9 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %new_len.i.i = load i64, ptr %9, align 8
  %_8.i.i = icmp ule i64 %index, %_3.1
  br i1 %_8.i.i, label %_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSThhEE5indexCscEnaBunu62E_10algorithms.exit, label %bb5.i.i

bb5.i.i:                                          ; preds = %bb2.i.i, %bb1
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 0, i64 %index, i64 %_3.1, ptr align 8 %0) #14
  unreachable

_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSThhEE5indexCscEnaBunu62E_10algorithms.exit: ; preds = %bb2.i.i
  %10 = insertvalue { ptr, i64 } %1, i64 %new_len.i.i, 1
  %11 = insertvalue { ptr, i64 } %1, i64 %new_len.i.i, 1
  %_0.0.i1 = extractvalue { ptr, i64 } %11, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %new_len.i.i, 1
  %_0.0.i = extractvalue { ptr, i64 } %12, 0
  %_0.1.i = extractvalue { ptr, i64 } %12, 1
  %_0.0 = extractvalue { ptr, i64 } %12, 0
  %_0.1 = extractvalue { ptr, i64 } %12, 1
  br label %bb2

bb2:                                              ; preds = %_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSThhEE5indexCscEnaBunu62E_10algorithms.exit
  %13 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %14 = insertvalue { ptr, i64 } %13, i64 %_0.1, 1
  ret { ptr, i64 } %14

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<bool> as core::ops::index::Index<usize>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !583 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<bool> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[bool]>>::index
  %_0.i = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSbE5indexCscEnaBunu62E_10algorithms(i64 %index, ptr %_3.0, i64 %_3.1, ptr align 8 %0) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<char> as core::ops::index::Index<usize>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !584 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<char> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[char]>>::index
  %_0.i = call align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexScE5indexCscEnaBunu62E_10algorithms(i64 %index, ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %0) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<usize> as core::ops::index::Index<core::ops::range::RangeFrom<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBM_5range9RangeFromjEE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !585 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<usize> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshGsV4pNJ6ra_6object(ptr align 8 %self) #15
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[usize]>>::index
  %2 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSjE5indexCscEnaBunu62E_10algorithms(i64 %index, ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %0) #15
  %_0.0.i = extractvalue { ptr, i64 } %2, 0
  %_0.1.i = extractvalue { ptr, i64 } %2, 1
  %_0.0 = extractvalue { ptr, i64 } %2, 0
  %_0.1 = extractvalue { ptr, i64 } %2, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1, 1
  ret { ptr, i64 } %4

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<usize> as core::ops::index::Index<usize>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !586 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<usize> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshGsV4pNJ6ra_6object(ptr align 8 %self) #15
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[usize]>>::index
  %_0.i = call align 8 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSjE5indexCscEnaBunu62E_10algorithms(i64 %index, ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %0) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u64> as core::ops::index::Index<core::ops::range::RangeTo<usize>>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexINtNtBM_5range7RangeTojEE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !587 {
start:
  %_3.i.i = alloca [16 x i8], align 8
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<u64> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize>::checked_sub
  %2 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCscEnaBunu62E_10algorithms(i64 %index, i64 0) #15
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %_3.i.i, align 8
  %5 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  store i64 %4, ptr %5, align 8
  %_6.i.i = load i64, ptr %_3.i.i, align 8
  %6 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = trunc nuw i64 %_6.i.i to i1
  br i1 %8, label %bb2.i.i, label %bb5.i.i

bb2.i.i:                                          ; preds = %bb1
  %9 = getelementptr inbounds i8, ptr %_3.i.i, i64 8
  %new_len.i.i = load i64, ptr %9, align 8
  %_8.i.i = icmp ule i64 %index, %_3.1
  br i1 %_8.i.i, label %_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSyE5indexCscEnaBunu62E_10algorithms.exit, label %bb5.i.i

bb5.i.i:                                          ; preds = %bb2.i.i, %bb1
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 0, i64 %index, i64 %_3.1, ptr align 8 %0) #14
  unreachable

_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSyE5indexCscEnaBunu62E_10algorithms.exit: ; preds = %bb2.i.i
  %10 = insertvalue { ptr, i64 } %1, i64 %new_len.i.i, 1
  %11 = insertvalue { ptr, i64 } %1, i64 %new_len.i.i, 1
  %_0.0.i1 = extractvalue { ptr, i64 } %11, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %new_len.i.i, 1
  %_0.0.i = extractvalue { ptr, i64 } %12, 0
  %_0.1.i = extractvalue { ptr, i64 } %12, 1
  %_0.0 = extractvalue { ptr, i64 } %12, 0
  %_0.1 = extractvalue { ptr, i64 } %12, 1
  br label %bb2

bb2:                                              ; preds = %_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSyE5indexCscEnaBunu62E_10algorithms.exit
  %13 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %14 = insertvalue { ptr, i64 } %13, i64 %_0.1, 1
  ret { ptr, i64 } %14

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <[[i64; 3]; 3] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAAxj3_Bz_INtNtNtB7_3ops5index5IndexNtNtBK_5range9RangeFullE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %0) unnamed_addr #1 !guid !588 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[[i64; 3]]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSAxj3_E5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 3, ptr align 8 %0) #15
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <[f64; 5] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAdj5_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %0) unnamed_addr #1 !guid !589 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[f64]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSdE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 5, ptr align 8 %0) #15
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <[i64; 3] as core::ops::index::Index<core::ops::range::RangeFull>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsd_NtCsl10jNU3mE6R_4core5arrayAxj3_INtNtNtB7_3ops5index5IndexNtNtBG_5range9RangeFullE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %0) unnamed_addr #1 !guid !590 {
start:
; call <core::ops::range::RangeFull as core::slice::index::SliceIndex<[i64]>>::index
  %1 = call { ptr, i64 } @_RNvXs7_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops5range9RangeFullINtB5_10SliceIndexSxE5indexCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 3, ptr align 8 %0) #15
  %_0.0.i = extractvalue { ptr, i64 } %1, 0
  %_0.1.i = extractvalue { ptr, i64 } %1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::non_null::NonNull<[u8; 8]> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAhj8_ENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %other) unnamed_addr #1 !guid !591 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<[i64; 3]> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullAxj3_ENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %other) unnamed_addr #1 !guid !592 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<(u8, u8)> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullThhEENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %other) unnamed_addr #1 !guid !593 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<f64> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %other) unnamed_addr #1 !guid !594 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<i64> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxENtNtB9_3cmp9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %other) unnamed_addr #1 !guid !595 {
start:
  %_4 = load ptr, ptr %self, align 8
  %_6 = load ptr, ptr %other, align 8
  %_0 = icmp eq ptr %_4, %_6
  ret i1 %_0
}

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::size_hint
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range14RangeInclusivejENtNtNtB7_6traits8iterator8Iterator9size_hintCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !596 {
start:
  %hint = alloca [24 x i8], align 8
; call <core::ops::range::RangeInclusive<usize>>::is_empty
  %_2 = call zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivejE8is_emptyCs2d0hS33vDhg_5gimli(ptr align 8 %self) #15
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_6 = getelementptr inbounds i8, ptr %self, i64 8
; call <usize as core::iter::range::Step>::steps_between
  call void @_RNvXsL_NtNtCsl10jNU3mE6R_4core4iter5rangejNtB5_4Step13steps_betweenCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %hint, ptr align 8 %self, ptr align 8 %_6) #15
  %_8 = load i64, ptr %hint, align 8
  %_0.i = call i64 @llvm.uadd.sat.i64(i64 %_8, i64 1)
  %0 = getelementptr inbounds i8, ptr %hint, i64 8
  %_10.0 = load i64, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  %_10.1 = load i64, ptr %1, align 8
; call <core::option::Option<usize>>::and_then::<usize, <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::size_hint::{closure#0}>
  %2 = call { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE8and_thenjNCNvXsd_NtNtB5_4iter5rangeINtNtNtB5_3ops5range14RangeInclusivejENtNtNtB14_6traits8iterator8Iterator9size_hint0ECscEnaBunu62E_10algorithms(i64 %_10.0, i64 %_10.1) #15
  %_9.0 = extractvalue { i64, i64 } %2, 0
  %_9.1 = extractvalue { i64, i64 } %2, 1
  store i64 %_0.i, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_9.0, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 8
  store i64 %_9.1, ptr %4, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  store i64 0, ptr %6, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  ret void
}

; <alloc::vec::Vec<bool> as core::ops::index::IndexMut<usize>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXse_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbEINtNtNtCsl10jNU3mE6R_4core3ops5index8IndexMutjE9index_mutCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !597 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<bool> as core::ops::deref::DerefMut>::deref_mut
  %1 = call { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[bool]>>::index_mut
  %_0.i = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSbE9index_mutCscEnaBunu62E_10algorithms(i64 %index, ptr %_3.0, i64 %_3.1, ptr align 8 %0) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<usize> as core::ops::index::IndexMut<usize>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvXse_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjEINtNtNtCsl10jNU3mE6R_4core3ops5index8IndexMutjE9index_mutCscEnaBunu62E_10algorithms(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !598 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<usize> as core::ops::deref::DerefMut>::deref_mut
  %1 = call { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[usize]>>::index_mut
  %_0.i = call align 8 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSjE9index_mutCscEnaBunu62E_10algorithms(i64 %index, ptr align 8 %_3.0, i64 %_3.1, ptr align 8 %0) #15
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <bool as alloc::vec::is_zero::IsZero>::is_zero
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsh_NtNtCs7CppTae75M1_5alloc3vec7is_zerobNtB5_6IsZero7is_zeroCscEnaBunu62E_10algorithms(ptr %self) unnamed_addr #1 !guid !599 {
start:
  %0 = load i8, ptr %self, align 1
  %_4 = trunc nuw i8 %0 to i1
; call <bool as alloc::vec::is_zero::IsZero>::is_zero::{closure#0}
  %_0 = call zeroext i1 @_RNCNvXsh_NtNtCs7CppTae75M1_5alloc3vec7is_zerobNtB7_6IsZero7is_zero0CscEnaBunu62E_10algorithms(ptr inttoptr (i64 1 to ptr), i1 zeroext %_4) #15
  ret i1 %_0
}

; <usize as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsj_NtNtCsl10jNU3mE6R_4core3cmp5implsjNtB7_9PartialEq2eqCscEnaBunu62E_10algorithms(ptr align 8 %self, ptr align 8 %other) unnamed_addr #1 !guid !600 {
start:
  %_3 = load i64, ptr %self, align 8
  %_4 = load i64, ptr %other, align 8
  %_0 = icmp eq i64 %_3, %_4
  ret i1 %_0
}

; <alloc::vec::Vec<(u8, u8)> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecThhEENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !601 {
start:
; call <alloc::vec::Vec<(u8, u8)>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecThhEE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut (u8, u8)>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOThhE10cast_sliceCscEnaBunu62E_10algorithms(ptr %_3, i64 %_4) #15
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<bool> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecbENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !602 {
start:
; call <alloc::vec::Vec<bool>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecbE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut bool>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOb10cast_sliceCscEnaBunu62E_10algorithms(ptr %_3, i64 %_4) #15
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<char> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeccENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !603 {
start:
; call <alloc::vec::Vec<char>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeccE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut char>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOc10cast_sliceCscEnaBunu62E_10algorithms(ptr %_3, i64 %_4) #15
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<usize> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !604 {
start:
; call <alloc::vec::Vec<usize>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut usize>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOj10cast_sliceCscEnaBunu62E_10algorithms(ptr %_3, i64 %_4) #15
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<u64> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCscEnaBunu62E_10algorithms(ptr align 8 %self) unnamed_addr #0 !guid !605 {
start:
; call <alloc::vec::Vec<u64>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecyE10as_mut_ptrCscEnaBunu62E_10algorithms(ptr align 8 %self) #15
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u64>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOy10cast_sliceCscEnaBunu62E_10algorithms(ptr %_3, i64 %_4) #15
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <[[i64; 3]] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSAxj3_NtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #0 !guid !606 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[[i64; 3]]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSAxj3_4iterCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1) #15
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&[i64; 3], core::slice::iter::Iter<[i64; 3]>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRAxj3_INtNtNtBa_5slice4iter4IterB14_EECscEnaBunu62E_10algorithms(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[(u8, u8)] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSThhENtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #0 !guid !607 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[(u8, u8)]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSThhE4iterCscEnaBunu62E_10algorithms(ptr %self.0, i64 %self.1) #15
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&(u8, u8), core::slice::iter::Iter<(u8, u8)>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRThhEINtNtNtBa_5slice4iter4IterB14_EECscEnaBunu62E_10algorithms(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[f64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSdNtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #0 !guid !608 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[f64]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSd4iterCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1) #15
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&f64, core::slice::iter::Iter<f64>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRdINtNtNtBa_5slice4iter4IterdEECscEnaBunu62E_10algorithms(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[usize] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSjNtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #0 !guid !609 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[usize]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSj4iterB4_(ptr align 8 %self.0, i64 %self.1) #15
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&usize, core::slice::iter::Iter<usize>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRjINtNtNtBa_5slice4iter4IterjEECscEnaBunu62E_10algorithms(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[i64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSxNtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #0 !guid !610 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[i64]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSx4iterCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1) #15
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&i64, core::slice::iter::Iter<i64>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRxINtNtNtBa_5slice4iter4IterxEECscEnaBunu62E_10algorithms(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <[u64] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSyNtB5_5Debug3fmtCscEnaBunu62E_10algorithms(ptr align 8 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #0 !guid !611 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[u64]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSy4iterCs2d0hS33vDhg_5gimli(ptr align 8 %self.0, i64 %self.1) #15
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&u64, core::slice::iter::Iter<u64>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRyINtNtNtBa_5slice4iter4IteryEECscEnaBunu62E_10algorithms(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <u64 as core::ops::arith::Add<&u64>>::add
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvXsr_NtNtCsl10jNU3mE6R_4core3ops5arithyINtB5_3AddRyE3addCscEnaBunu62E_10algorithms(i64 %self, ptr align 8 %other, ptr align 8 %0) unnamed_addr #1 !guid !612 {
start:
  %_3 = load i64, ptr %other, align 8
; call <u64 as core::ops::arith::Add>::add
  %_0 = call i64 @_RNvXs2_NtNtCsl10jNU3mE6R_4core3ops5arithyNtB5_3Add3addCscEnaBunu62E_10algorithms(i64 %self, i64 %_3, ptr align 8 %0) #15
  ret i64 %_0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCscEnaBunu62E_10algorithms(ptr %_1) unnamed_addr #1 !guid !613 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::step_by
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYINtNtNtCsl10jNU3mE6R_4core3ops5range5RangelENtNtNtNtB9_4iter6traits8iterator8Iterator7step_byCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i32 %self.0, i32 %self.1, i64 %step) unnamed_addr #1 !guid !614 {
start:
; call <core::iter::adapters::step_by::StepBy<core::ops::range::Range<i32>>>::new
  call void @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters7step_byINtB2_6StepByINtNtNtB8_3ops5range5RangelEE3newCscEnaBunu62E_10algorithms(ptr sret([24 x i8]) align 8 %_0, i32 %self.0, i32 %self.1, i64 %step) #15
  ret void
}

; <core::slice::iter::Iter<[u8; 8]> as core::iter::traits::iterator::Iterator>::fuse
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterAhj8_ENtNtNtNtB9_4iter6traits8iterator8Iterator4fuseCscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !615 {
start:
; call <core::iter::adapters::fuse::Fuse<core::slice::iter::Iter<[u8; 8]>>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtNtCsl10jNU3mE6R_4core4iter8adapters4fuseINtB2_4FuseINtNtNtB8_5slice4iter4IterAhj8_EE3newCscEnaBunu62E_10algorithms(ptr %self.0, ptr %self.1)
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::slice::iter::Iter<[u8; 8]> as core::iter::traits::iterator::Iterator>::flatten
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterAhj8_ENtNtNtNtB9_4iter6traits8iterator8Iterator7flattenCscEnaBunu62E_10algorithms(ptr sret([48 x i8]) align 8 %_0, ptr %self.0, ptr %self.1) unnamed_addr #1 !guid !616 {
start:
; call <core::iter::adapters::flatten::Flatten<core::slice::iter::Iter<[u8; 8]>>>::new
  call void @_RNvMs6_NtNtNtCsl10jNU3mE6R_4core4iter8adapters7flattenINtB5_7FlattenINtNtNtBb_5slice4iter4IterAhj8_EE3newCscEnaBunu62E_10algorithms(ptr sret([48 x i8]) align 8 %_0, ptr %self.0, ptr %self.1)
  ret void
}

; <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::max
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBb_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtB9_6traits8iterator8Iterator3maxB1k_(i64 %self.0, i64 %self.1) unnamed_addr #1 !guid !617 {
start:
; call <core::iter::adapters::map::Map<core::ops::range::Range<u64>, algorithms::collatz> as core::iter::traits::iterator::Iterator>::max_by::<<u32 as core::cmp::Ord>::cmp>
  %0 = call { i32, i32 } @_RINvYINtNtNtNtCsl10jNU3mE6R_4core4iter8adapters3map3MapINtNtNtBc_3ops5range5RangeyENvCscEnaBunu62E_10algorithms7collatzENtNtNtBa_6traits8iterator8Iterator6max_byNvYmNtNtBc_3cmp3Ord3cmpEB1l_(i64 %self.0, i64 %self.1) #15
  %_0.0 = extractvalue { i32, i32 } %0, 0
  %_0.1 = extractvalue { i32, i32 } %0, 1
  %1 = insertvalue { i32, i32 } poison, i32 %_0.0, 0
  %2 = insertvalue { i32, i32 } %1, i32 %_0.1, 1
  ret { i32, i32 } %2
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCscEnaBunu62E_10algorithms(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !618 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CscEnaBunu62E_10algorithms(ptr align 8 %_1) #15
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <algorithms::collatz as core::ops::function::FnMut<(u64,)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNvCscEnaBunu62E_10algorithms7collatzINtNtNtCsl10jNU3mE6R_4core3ops8function5FnMutTyEE8call_mutB4_(ptr %_1, i64 %0) unnamed_addr #1 !guid !619 {
start:
  %_2 = alloca [8 x i8], align 8
  store i64 %0, ptr %_2, align 8
  %1 = load i64, ptr %_2, align 8
; call algorithms::collatz
  %_0 = call i32 @_RNvCscEnaBunu62E_10algorithms7collatz(i64 %1)
  ret i32 %_0
}

; <<u32 as core::cmp::Ord>::cmp as core::ops::function::FnMut<(&u32, &u32)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvYNvYmNtNtCsl10jNU3mE6R_4core3cmp3Ord3cmpINtNtNtBa_3ops8function5FnMutTRmB19_EE8call_mutCscEnaBunu62E_10algorithms(ptr %_1, ptr align 4 %0, ptr align 4 %1) unnamed_addr #1 !guid !620 {
start:
  %_2 = alloca [16 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr %1, ptr %2, align 8
  %3 = load ptr, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load ptr, ptr %4, align 8
; call <u32 as core::cmp::Ord>::cmp
  %_0 = call i8 @_RNvXs11_NtNtCsl10jNU3mE6R_4core3cmp5implsmNtB8_3Ord3cmpCscEnaBunu62E_10algorithms(ptr align 4 %3, ptr align 4 %5) #15
  ret i8 %_0
}

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #5

; core::panicking::panic_const::panic_const_sub_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8) unnamed_addr #6

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #6

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #8

; <core::fmt::builders::DebugList>::entry
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8, ptr, ptr align 8) unnamed_addr #0

; <core::slice::iter::Iter<usize> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterjENtNtNtNtBa_4iter6traits8iterator8Iterator4nextBa_(ptr align 8) unnamed_addr #1

; <&usize as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRjNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #0

; <&i64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRxNtB6_5Debug3fmtCs2d0hS33vDhg_5gimli(ptr align 8, ptr align 8) unnamed_addr #0

; <core::slice::iter::Iter<u64> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare align 8 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs2d0hS33vDhg_5gimli(ptr align 8) unnamed_addr #1

; <&u64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #6

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #7

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #9

; core::ptr::drop_glue::<alloc::vec::set_len_on_drop::SetLenOnDrop>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtNtCs7CppTae75M1_5alloc3vec15set_len_on_drop12SetLenOnDropECsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #0

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqB9_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8>>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE20offset_from_unsignedB9_(ptr, ptr) unnamed_addr #1

; <core::ptr::non_null::NonNull<u64> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyENtNtB9_3cmp9PartialEq2eqCs2d0hS33vDhg_5gimli(ptr align 8, ptr align 8) unnamed_addr #1

; <core::ops::range::RangeInclusive<usize>>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMs8_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivejE8is_emptyCs2d0hS33vDhg_5gimli(ptr align 8) unnamed_addr #1

; <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try6branchCs7CppTae75M1_5alloc() unnamed_addr #1

; <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::Try>::from_output
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB4_17NeverShortCircuituENtB4_3Try11from_outputCs7CppTae75M1_5alloc() unnamed_addr #1

; <core::ops::try_trait::NeverShortCircuit<()> as core::ops::try_trait::FromResidual<core::ops::try_trait::NeverShortCircuitResidual>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs0_NtNtCsl10jNU3mE6R_4core3ops9try_traitINtB5_17NeverShortCircuituEINtB5_12FromResidualNtB5_25NeverShortCircuitResidualE13from_residualCs7CppTae75M1_5alloc() unnamed_addr #1

; core::mem::replace::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3mem7replacejECs2d0hS33vDhg_5gimli(ptr align 8, i64) unnamed_addr #1

; <core::ops::control_flow::ControlFlow<usize> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowjENtNtB4_9try_trait3Try6branchCsddYV2PBJW9h_3std(i64, i64) unnamed_addr #1

; <core::ops::control_flow::ControlFlow<usize> as core::ops::try_trait::Try>::from_output
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowjENtNtB4_9try_trait3Try11from_outputCsddYV2PBJW9h_3std() unnamed_addr #1

; <core::ops::control_flow::ControlFlow<usize> as core::ops::try_trait::FromResidual<core::ops::control_flow::ControlFlow<usize, core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB4_11ControlFlowjEINtNtB6_9try_trait12FromResidualIBK_jNtNtB8_7convert10InfallibleEE13from_residualCsddYV2PBJW9h_3std(i64) unnamed_addr #1

; <core::str::iter::Chars as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectNtNtNtB8_3str4iter5CharsNtB2_12IntoIterator9into_iterB8_(ptr, ptr) unnamed_addr #1

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range14RangeInclusivejENtB2_12IntoIterator9into_iterCs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::ops::control_flow::ControlFlow<usize>>::break_value
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB5_11ControlFlowjE11break_valueCsddYV2PBJW9h_3std(i64, i64) unnamed_addr #1

; <core::ops::range::Range<i32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i32, i32 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangelENtNtNtB7_6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 4) unnamed_addr #1

; <core::ops::range::Range<u64> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangeyENtNtNtB7_6traits8iterator8Iterator4nextCs257F0UrNG3U_14rustc_demangle(ptr align 8) unnamed_addr #1

; <core::ops::control_flow::ControlFlow<()> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowuENtNtB4_9try_trait3Try6branchCs257F0UrNG3U_14rustc_demangle(i1 zeroext) unnamed_addr #1

; <core::ops::control_flow::ControlFlow<()> as core::ops::try_trait::FromResidual<core::ops::control_flow::ControlFlow<(), core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB4_11ControlFlowuEINtNtB6_9try_trait12FromResidualIBK_uNtNtB8_7convert10InfallibleEE13from_residualCs257F0UrNG3U_14rustc_demangle() unnamed_addr #1

; <core::ops::control_flow::ControlFlow<()> as core::ops::try_trait::Try>::from_output
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3ops12control_flowINtB2_11ControlFlowuENtNtB4_9try_trait3Try11from_outputCs257F0UrNG3U_14rustc_demangle() unnamed_addr #1

; <core::ops::control_flow::ControlFlow<()> as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtCsl10jNU3mE6R_4core3ops12control_flowINtB5_11ControlFlowuENtNtB9_3cmp9PartialEq2eqCs257F0UrNG3U_14rustc_demangle(ptr, ptr) unnamed_addr #1

; <core::option::Option<u32> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare { i32, i32 } @_RNvXsJ_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmENtNtNtB7_3ops9try_trait3Try6branchB7_(i32, i32) unnamed_addr #1

; <core::option::Option<u32> as core::ops::try_trait::FromResidual<core::option::Option<core::convert::Infallible>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { i32, i32 } @_RNvXsK_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleEE13from_residualB7_() unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64) #10

; <core::ops::range::RangeInclusive<usize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs5_NtNtCsl10jNU3mE6R_4core3ops5rangeINtB5_14RangeInclusivejE3newCs257F0UrNG3U_14rustc_demangle(ptr sret([24 x i8]) align 8, i64, i64) unnamed_addr #1

; <core::ops::range::RangeInclusive<usize> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXsd_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range14RangeInclusivejENtNtNtB7_6traits8iterator8Iterator4nextCs2d0hS33vDhg_5gimli(ptr align 8) unnamed_addr #1

; <usize as core::cmp::Ord>::min
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvYjNtNtCsl10jNU3mE6R_4core3cmp3Ord3minB7_(i64, i64) unnamed_addr #1

; <[u8]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSh4iterB4_(ptr, i64) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #1

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; <[u64]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSy4iterCs2d0hS33vDhg_5gimli(ptr align 8, i64) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <core::fmt::rt::Argument>::new_lower_hex::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexmEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #11

; <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64, i64) unnamed_addr #1

; <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8) unnamed_addr #1

; <core::fmt::rt::Argument>::new_debug::<[u8; 8]>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugAhj8_ECsddYV2PBJW9h_3std(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #1

; <core::ops::range::Range<i32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { i32, i32 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangelENtB2_12IntoIterator9into_iterCsddYV2PBJW9h_3std(i32, i32) unnamed_addr #1

; <core::fmt::rt::Argument>::new_lower_hex::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs2d0hS33vDhg_5gimli(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #6

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #10

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #6

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #10

; <alloc::vec::Vec<usize> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecjENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #1

; <[usize]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSj4iterB4_(ptr align 8, i64) unnamed_addr #1

; <core::slice::iter::Iter<usize> as core::iter::traits::iterator::Iterator>::enumerate
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvYINtNtNtCsl10jNU3mE6R_4core5slice4iter4IterjENtNtNtNtB9_4iter6traits8iterator8Iterator9enumerateCsddYV2PBJW9h_3std(ptr sret([24 x i8]) align 8, ptr, ptr) unnamed_addr #1

; <core::num::nonzero::NonZero<usize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64) unnamed_addr #1

; <core::option::Option<core::num::nonzero::NonZero<usize>>>::expect
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionINtNtNtB4_3num7nonzero7NonZerojEE6expectCsddYV2PBJW9h_3std(i64, ptr, i64, ptr align 8) unnamed_addr #1

; core::option::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6option13unwrap_failed(ptr align 8) unnamed_addr #6

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #6

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8, i64) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::with_capacity_zeroed_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner23with_capacity_zeroed_inCsddYV2PBJW9h_3std(i64, i64, i64) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::reserve
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner7reserveB7_(ptr align 8, i64, i64, i64, i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #10

; core::panicking::panic_const::panic_const_neg_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_neg_overflow(ptr align 8) unnamed_addr #6

; <alloc::raw_vec::RawVecInner>::grow_one
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8grow_oneB7_(ptr align 8, i64, i64) unnamed_addr #1

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64, i64, i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.uadd.sat.i64(i64, i64) #10

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #6

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #6

; <alloc::raw_vec::RawVec<usize>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecjE3ptrCshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #1

; <alloc::vec::Vec<usize>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecjE6as_ptrCshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #1

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr) unnamed_addr #1

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #9

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #12

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #0

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr, i64) unnamed_addr #1

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #12

; core::cmp::max::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64, i64) unnamed_addr #1

; core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
declare { i32, i32 } @_RINvNtNtCsl10jNU3mE6R_4core3str11validations15next_code_pointINtNtNtB6_5slice4iter4IterhEEB6_(ptr align 8) unnamed_addr #1

; <core::option::Option<u32>>::map::<char, <core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
declare i32 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionmE3mapcNCNvXNtNtB5_3str4iterNtBU_5CharsNtNtNtNtB5_4iter6traits8iterator8Iterator4next0EB5_(i32, i32) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.ucmp.i8.i32(i32, i32) #10

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #0

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #0

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #0

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8, i64, i64) unnamed_addr #0

; <f64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs6_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_5Debug3fmt(ptr align 8, ptr align 8) unnamed_addr #0

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64, i64, i64, ptr align 8) unnamed_addr #6

; <core::option::Option<i32>>::unwrap_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
declare i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE16unwrap_uncheckedCsddYV2PBJW9h_3std(i32, i32, ptr align 8) unnamed_addr #1

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::builders::DebugList>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8) unnamed_addr #0

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #13 !guid !621 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECscEnaBunu62E_10algorithms(ptr @_RNvCscEnaBunu62E_10algorithms4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #12 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { nonlazybind "target-cpu"="x86-64" }
attributes #14 = { noinline noreturn }
attributes #15 = { inlinehint }
attributes #16 = { cold }
attributes #17 = { cold noreturn nounwind }
attributes #18 = { inlinehint nounwind }
attributes #19 = { noinline }
attributes #20 = { noreturn }
attributes #21 = { noinline noreturn nounwind }

!llvm.module.flags = !{!140, !141, !142, !143}
!llvm.ident = !{!144}

!0 = !{i64 -2577478200501319976}
!1 = !{i64 -5558606421061386693}
!2 = !{i64 -1599441518712522674}
!3 = !{i64 3999399697908363827}
!4 = !{i64 5776687936074278208}
!5 = !{i64 -3905223389953230447}
!6 = !{i64 1585537202271783794}
!7 = !{i64 -3650702527801819847}
!8 = !{i64 -1015711658679764311}
!9 = !{i64 7273459283617585011}
!10 = !{i64 4509290113455769914}
!11 = !{i64 -934269630240624008}
!12 = !{i64 -733273123178153342}
!13 = !{i64 -6025753174759268875}
!14 = !{i64 8564302454200618455}
!15 = !{i64 -134627229211171124}
!16 = !{i64 1093984162241441280}
!17 = !{i64 6380234398315164747}
!18 = !{i64 -2122083967345137242}
!19 = !{i64 -666113792159802548}
!20 = !{i64 8166260715352348043}
!21 = !{i64 8984819320096978144}
!22 = !{i64 1490348396955359442}
!23 = !{i64 -3656688514767434816}
!24 = !{i64 -6860809174557923516}
!25 = !{i64 -7291266475433041071}
!26 = !{i64 -6842348930240156699}
!27 = !{i64 -4170050110528712967}
!28 = !{i64 3333371319271970444}
!29 = !{i64 3164032493471413253}
!30 = !{i64 5417466799109455274}
!31 = !{i64 -922561038184406124}
!32 = !{i64 7662804373033914152}
!33 = !{i64 -1669129636270907808}
!34 = !{i64 1777804577987497006}
!35 = !{i64 -9210127219471552643}
!36 = !{i64 5623273293317597887}
!37 = !{i64 89894776858811080}
!38 = !{i64 1942981534279797615}
!39 = !{i64 5299361363028364395}
!40 = !{i64 8317881907500990346}
!41 = !{i64 -6917377798284390}
!42 = !{i64 2752855599447909792}
!43 = !{i64 -4276153162176384144}
!44 = !{i64 3880243780728521669}
!45 = !{i64 -4516779921885578284}
!46 = !{i64 -1934858473471732217}
!47 = !{i64 -6260795584836442787}
!48 = !{i64 -7948717514045287132}
!49 = !{i64 -2070202259559473175}
!50 = !{i64 9067957951845393769}
!51 = !{i64 -3670952573465302524}
!52 = !{i64 -6284573919208678568}
!53 = !{i64 -5784929682309114404}
!54 = !{i64 -2613249141387333099}
!55 = !{i64 2922915729930404538}
!56 = !{i64 -3391776539520835602}
!57 = !{i64 6607959217168956944}
!58 = !{i64 -2121399384478032323}
!59 = !{i64 4302620597981116230}
!60 = !{i64 5071330260167898309}
!61 = !{i64 9160864552207584295}
!62 = !{i64 -1429956323950222917}
!63 = !{i64 7963155651056527845}
!64 = !{i64 5462277531867676434}
!65 = !{i64 -778305214168381010}
!66 = !{i64 9059264737457638277}
!67 = !{i64 -2269015135248199160}
!68 = !{i64 -4776001135164412422}
!69 = !{i64 147899324674978798}
!70 = !{i64 -7968568059634234749}
!71 = !{i64 -5457717257130912014}
!72 = !{i64 1473745240928517599}
!73 = !{i64 -8938437431773628204}
!74 = !{i64 1705812707595141656}
!75 = !{i64 5679501890834203265}
!76 = !{i64 4247659514496425970}
!77 = !{i64 -406813811806544644}
!78 = !{i64 -4110403466807626586}
!79 = !{i64 -5121005935818808391}
!80 = !{i64 -8686546435827605577}
!81 = !{i64 6953574813827409073}
!82 = !{i64 -3389946373851160772}
!83 = !{i64 -2085534229505477451}
!84 = !{i64 -8516650230987850579}
!85 = !{i64 6884070131598729184}
!86 = !{i64 -907836912967146971}
!87 = !{i64 1349657159082892896}
!88 = !{i64 7963860053621035189}
!89 = !{i64 9027651670791454627}
!90 = !{i64 414772696375794370}
!91 = !{i64 8764156591359272940}
!92 = !{i64 -5764344005288143504}
!93 = !{i64 -2550154145841581667}
!94 = !{i64 -7249937545186467887}
!95 = !{i64 -7535253053858251692}
!96 = !{i64 -8801549778957699877}
!97 = !{i64 7701393674868888099}
!98 = !{i64 -3203011550053973045}
!99 = !{i64 7622329531413926147}
!100 = !{i64 -1713716565792025872}
!101 = !{i64 -5212008658858974754}
!102 = !{i64 4340661677505088288}
!103 = !{i64 -6692131083492454725}
!104 = !{i64 -6410849866660375530}
!105 = !{i64 -231593275558454930}
!106 = !{i64 -8458597613001699084}
!107 = !{i64 -5743386473814479205}
!108 = !{i64 -4075562130471784728}
!109 = !{i64 -3038761870169371727}
!110 = !{i64 -4149307398817912406}
!111 = !{i64 -3404689649697496886}
!112 = !{i64 -8371909250829930914}
!113 = !{i64 5983711735012556243}
!114 = !{i64 8624560362207215735}
!115 = !{i64 -6801488883370918511}
!116 = !{i64 -6117874992366431724}
!117 = !{i64 3066500581274945670}
!118 = !{i64 7591338318857553239}
!119 = !{i64 -9124734395910246507}
!120 = !{i64 -6012781814420899373}
!121 = !{i64 -6022141268821229631}
!122 = !{i64 -6562725560673280638}
!123 = !{i64 3838047893155478811}
!124 = !{i64 -8392334495708255923}
!125 = !{i64 6496081913192249685}
!126 = !{i64 1756104685272991722}
!127 = !{i64 -5232728459784877009}
!128 = !{i64 -4616475492238310034}
!129 = !{i64 -3857414276470091431}
!130 = !{i64 2917322440960959630}
!131 = !{i64 -5179208940982601164}
!132 = !{i64 4985775591419096553}
!133 = !{i64 -7895331089081795773}
!134 = !{i64 3289206836932167870}
!135 = !{i64 -5667456163181235651}
!136 = !{i64 -482131027840772536}
!137 = !{i64 -5784664119098940598}
!138 = !{i64 -9205376325159697734}
!139 = !{i64 -7945128785066199701}
!140 = !{i32 8, !"PIC Level", i32 2}
!141 = !{i32 7, !"PIE Level", i32 2}
!142 = !{i32 2, !"RtLibUseGOT", i32 1}
!143 = !{i32 7, !"uwtable", i32 2}
!144 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!145 = !{i64 -3134210359483838959}
!146 = !{i64 5384194979088530107}
!147 = !{i64 -8613218555974227071}
!148 = !{i64 2768469316357833104}
!149 = !{i64 6590709976175276831}
!150 = !{i64 2699971071201197039}
!151 = !{i64 2716478853842391525}
!152 = !{i64 -5607740340955609154}
!153 = !{i64 4425425599507841061}
!154 = !{i64 5443170520600857606}
!155 = !{i64 6703781803775037798}
!156 = !{i64 -5653228573769810200}
!157 = !{i64 -8381500214799010062}
!158 = !{i64 -3076651805827587628}
!159 = !{i64 3191706271003612839}
!160 = !{i64 -8551357174304403875}
!161 = !{i64 3653898689492644187}
!162 = !{i64 3890241165391110536}
!163 = !{i64 7369167073368562446}
!164 = !{i64 6258523310144973296}
!165 = !{i64 -3943267114468012265}
!166 = !{i64 -5092212442874400689}
!167 = !{i64 -2884616812599061902}
!168 = !{i64 -8768859382159153492}
!169 = !{i64 -8925933576214720019}
!170 = !{i64 2430881973651522514}
!171 = !{i64 -6686673708273673736}
!172 = !{i64 -7507942512374194787}
!173 = !{i64 -890646215500521838}
!174 = !{i64 -8155150992310639420}
!175 = !{i64 -8649140760184463513}
!176 = !{i64 -4147573332494642913}
!177 = !{i64 -8273932861614099481}
!178 = !{i64 2992399391908098234}
!179 = !{i64 9019637187679893025}
!180 = !{i64 -8912989898363775082}
!181 = !{i64 7660824446950068127}
!182 = !{i64 -3195157008666968975}
!183 = !{i64 2178869260874032245}
!184 = !{i64 6207556869350262666}
!185 = !{i64 8418396016895556431}
!186 = !{i64 -5479737188870817854}
!187 = !{i64 -7711939863899828381}
!188 = !{i64 8152670572474698552}
!189 = !{i64 8206521537294759244}
!190 = !{!"address", !"read_provenance"}
!191 = !{i64 -6716964464631459489}
!192 = !{i64 6184650892275205645}
!193 = !{i64 1792105216385142172}
!194 = !{i64 6716723866829687116}
!195 = !{i64 -8153151712631454505}
!196 = !{i64 -2170879704525062536}
!197 = !{i64 -6139835177475766733}
!198 = !{i64 -8067165512170284662}
!199 = !{i64 2498942282640603037}
!200 = !{i64 1180457342208617903}
!201 = !{i64 1929491748458689612}
!202 = !{i64 6666067317149951500}
!203 = !{i64 2664901540588906592}
!204 = !{i64 7828794251226799787}
!205 = !{i64 -662742555674343139}
!206 = !{i64 -4875377400006158320}
!207 = !{i64 3385104733340511822}
!208 = !{i64 2944600657370368093}
!209 = !{i64 -3860694593079642424}
!210 = !{i64 -8105284461234806952}
!211 = !{i64 -8830973641904860038}
!212 = !{i64 -6736848847478202805}
!213 = !{i64 -4566478535455254070}
!214 = !{i64 5759454398427506022}
!215 = !{i64 -1129733258181026202}
!216 = !{i64 9098466917630446624}
!217 = !{i64 -886290118560140533}
!218 = !{i64 -121320031965433717}
!219 = !{i64 -5906722614609946053}
!220 = !{i64 7061536859309944040}
!221 = !{i64 7043674414081980057}
!222 = !{i64 -6932441132783731617}
!223 = !{i64 -8877010586635067576}
!224 = !{i64 -2558080615899284469}
!225 = !{i64 -6487098364889290233}
!226 = !{i64 -1081975044556189315}
!227 = !{i64 1326264426477080}
!228 = !{i64 927099364777469085}
!229 = !{i64 6014158191011961531}
!230 = !{i64 -4502410152611609117}
!231 = !{i64 393769688804650132}
!232 = !{i64 -2455996287037764617}
!233 = !{i64 4035390854911681644}
!234 = !{i64 -838268998138106917}
!235 = !{i64 -8154268079177340890}
!236 = !{i64 -5395326994955787827}
!237 = !{i64 5502135411631182636}
!238 = !{i64 -1842097981103898914}
!239 = !{i64 9192034184002021041}
!240 = !{i64 2789130910874296382}
!241 = !{i64 -7842425203632323820}
!242 = !{i64 -5939137033173280255}
!243 = !{i64 7246940446079862754}
!244 = !{i64 6917400714177488300}
!245 = !{i64 492061470513195975}
!246 = !{i64 990162852696952170}
!247 = !{i64 9065849836761577061}
!248 = !{i64 -6607453449172979820}
!249 = !{i64 559938644725031305}
!250 = !{i64 -3400919546352095082}
!251 = !{i64 -1762238207675119584}
!252 = !{i64 -5051234805439904644}
!253 = !{i64 2653025222632900052}
!254 = !{i64 6858164202578863167}
!255 = !{i64 -808734840388336861}
!256 = !{i64 5317843932499145938}
!257 = !{i64 4262871666216683885}
!258 = !{i64 -2246361194962455430}
!259 = !{i64 268384972152471215}
!260 = !{i64 8448538219071442761}
!261 = !{i64 -5997143356946112520}
!262 = !{i64 6459158294455310241}
!263 = !{i64 5505752876874963147}
!264 = !{i64 3275054225661143050}
!265 = !{i64 -2758414884759590872}
!266 = !{i64 1656168661439891614}
!267 = !{i64 -5986250359633592103}
!268 = !{i64 2643867903453064831}
!269 = !{i64 8802099242615950828}
!270 = !{i64 -8496156771332467285}
!271 = !{i64 -8951072254037384009}
!272 = !{i64 -4704539645597594827}
!273 = !{i64 1839306642941588792}
!274 = !{i64 8298352576199667919}
!275 = !{i64 -316117112578990477}
!276 = !{i64 8974710151521369774}
!277 = !{i64 -9209292534369075160}
!278 = !{i64 -8359893828888844898}
!279 = !{i64 9086632429709226416}
!280 = !{i64 3282425701504518699}
!281 = !{i64 -8844244686846027150}
!282 = !{i64 4660128135810487172}
!283 = !{i64 -3202034585914149182}
!284 = !{i64 5279103675705470125}
!285 = !{i64 -4214743804303322176}
!286 = !{i64 -3843409600919244213}
!287 = !{i64 5873076457003390823}
!288 = !{i64 3339178527687946187}
!289 = !{i64 5392238848714963061}
!290 = !{i64 6473702801781414710}
!291 = !{i64 1920487104267171747}
!292 = !{i64 5849549957200857018}
!293 = !{i64 -163039437139646496}
!294 = !{i64 5774534858164191002}
!295 = !{i64 1702930767196205398}
!296 = !{i64 -8488980300454602703}
!297 = !{i64 -2114111430218423044}
!298 = !{i64 1093547570574706373}
!299 = !{i64 -7417354008200112430}
!300 = !{i64 4014552851514133027}
!301 = !{i64 338634952418644871}
!302 = !{i64 3601030177315925668}
!303 = !{i64 -4022662306620236835}
!304 = !{i64 714498060143524191}
!305 = !{i64 -516972354910561042}
!306 = !{i64 -1144323859459419200}
!307 = !{i64 7201682007298011256}
!308 = !{i64 -5829439859953702271}
!309 = !{i64 2115587707304996029}
!310 = !{i64 -933801283218409889}
!311 = !{i64 -9059709024100548595}
!312 = !{i64 -1488149025171748375}
!313 = !{i64 -3406530231445246712}
!314 = !{i64 -2077400625518217334}
!315 = !{i64 4028367951398463571}
!316 = !{i64 -5813022360200026198}
!317 = !{i64 -3150418552011543279}
!318 = !{i64 8360092284748558838}
!319 = !{i64 -5973690430735897347}
!320 = !{i64 2140920013869565166}
!321 = !{i64 3787991620169465751}
!322 = !{i64 -1493332293096482395}
!323 = !{i64 4481084073459381738}
!324 = !{i64 -5764299458310215009}
!325 = !{i64 1481458535026119970}
!326 = !{i64 -8286278223450588407}
!327 = !{i64 8338590647546885301}
!328 = !{i64 -6938775773413545871}
!329 = !{i64 -1692967378980672280}
!330 = !{i64 -8769591220436838828}
!331 = !{i64 1094254050509782222}
!332 = !{i64 -1743737415860909699}
!333 = !{i64 -9133985816384580179}
!334 = !{i64 1334846289100185771}
!335 = !{i64 738545010592152099}
!336 = !{i64 -1787454548490358030}
!337 = !{i64 8016619746325994117}
!338 = !{i64 8298994353077924286}
!339 = !{i64 -3191236278177491644}
!340 = !{i64 -1486974324580525404}
!341 = !{i64 -83319116353790134}
!342 = !{i64 3270357207821395025}
!343 = !{i64 2125297749195621686}
!344 = !{i64 -3751390066967237166}
!345 = !{i64 2833179495689193833}
!346 = !{i64 8427753337839376793}
!347 = !{i64 7485106667579180072}
!348 = !{i64 -6019743844191790397}
!349 = !{i64 -2070828440977622125}
!350 = !{i64 -8416035125178826943}
!351 = !{i64 8789871951870472054}
!352 = !{i64 -7550323914079083989}
!353 = !{i64 -893751040086315465}
!354 = !{i64 3324198754956283487}
!355 = !{i64 -7204858202644849056}
!356 = !{i64 508474218520554118}
!357 = !{i64 -2662518711366404748}
!358 = !{i64 7798175324737936058}
!359 = !{i64 456638327235013838}
!360 = !{i64 -497449070940753575}
!361 = !{i64 7949374208294875681}
!362 = !{i64 -1034005437713157179}
!363 = !{i64 2456328564620360220}
!364 = !{i64 -8452189688322966695}
!365 = !{i64 -7745865208143031539}
!366 = !{i64 -5641234831664065439}
!367 = !{i64 3953527295544249512}
!368 = !{i64 -1507076969192080919}
!369 = !{i64 593113510384297060}
!370 = !{i64 -8843312331469808391}
!371 = !{i64 -6680383596098756842}
!372 = !{i64 -6155144771823498649}
!373 = !{i64 3541943161711343545}
!374 = !{i64 8800481076162333567}
!375 = !{i64 3555449677440740675}
!376 = !{i64 4187715025066545484}
!377 = !{i64 4622697090383289491}
!378 = !{i64 -8491513140541021921}
!379 = !{i64 3194417868426680705}
!380 = !{i64 -8322955292344689033}
!381 = !{i64 2229444983427272678}
!382 = !{i64 -4316334594673858286}
!383 = !{i64 3727128000477914639}
!384 = !{i64 3058156629773500307}
!385 = !{i64 -1477806451640026764}
!386 = !{i64 4127380866190672451}
!387 = !{i64 -3841144578087155017}
!388 = !{i64 -1025549505036961749}
!389 = !{i64 -5112346249774896617}
!390 = !{i64 -8332909343436584440}
!391 = !{i64 -2554263276346754958}
!392 = !{i64 -4772872933045742237}
!393 = !{i64 3311869162242177705}
!394 = !{i64 1410657484347299637}
!395 = !{i64 -3950267174206102912}
!396 = !{i64 -5981818751622415364}
!397 = !{i64 -5314912576927109924}
!398 = !{i64 7055457939293620214}
!399 = !{i64 -1362991951337392239}
!400 = !{i64 -2968406394485299149}
!401 = !{i64 -5695908435067412007}
!402 = !{i64 2736554375221782525}
!403 = !{i64 4786702733969321707}
!404 = !{i64 -3246712987481847198}
!405 = !{i64 5893987865392956644}
!406 = !{i64 2402155147507826951}
!407 = !{i64 6944880526525637508}
!408 = !{i64 6651527888014097746}
!409 = !{i64 -2936767356125222464}
!410 = !{i64 -1057283048437427165}
!411 = !{i64 -7835689654311808649}
!412 = !{i64 6109907564203851784}
!413 = !{i64 -573771073323694682}
!414 = !{i64 -5784612061623898}
!415 = !{i64 6669536988432348347}
!416 = !{i64 -4377470685582822519}
!417 = !{i64 5824732393877456996}
!418 = !{i64 -2950427562171964528}
!419 = !{i64 9205872500861427111}
!420 = !{i64 401492269288026111}
!421 = !{i64 -5193153336021241580}
!422 = !{i64 7481522608826722852}
!423 = !{i64 -1162509116906327272}
!424 = !{i64 7670822916066251429}
!425 = !{i64 -5329395324746405141}
!426 = !{i64 -9111682233020281449}
!427 = !{i64 -8259665161581550730}
!428 = !{i64 -7250196190523612854}
!429 = !{i64 9128617734826194260}
!430 = !{i64 9092856361872611647}
!431 = !{i64 1353489672534697988}
!432 = !{i64 -8256076882505058356}
!433 = !{i64 -2994469837722438078}
!434 = !{i64 -8112547071934553828}
!435 = !{i64 -5900850272955625768}
!436 = !{i64 -3540215506041147240}
!437 = !{i64 565086475346151485}
!438 = !{i64 -4515748497630590204}
!439 = !{i64 3400953879676943839}
!440 = !{i64 8622564419640646929}
!441 = !{i64 1100315774350767636}
!442 = !{i64 5863840585738396243}
!443 = !{i64 -2179329756997158374}
!444 = !{i64 -5001435872044298517}
!445 = !{i64 1024558957632540308}
!446 = !{i64 2833740357051164584}
!447 = !{i64 -1863580330779262195}
!448 = !{i64 -442775856158214951}
!449 = !{i64 -1073923289130957610}
!450 = !{i64 -4639379554503063730}
!451 = !{i64 -7262637261175258446}
!452 = !{i64 5981122612774984561}
!453 = !{i64 -2807472688931250345}
!454 = !{i64 -5047489724234628780}
!455 = !{i64 4487009168612703422}
!456 = !{i64 -3262792373189969437}
!457 = !{i64 -3244351642125159807}
!458 = !{i64 -7255216265486459387}
!459 = !{i64 7923289925193503776}
!460 = !{i64 8372405657950830290}
!461 = !{i64 -6411649959269355284}
!462 = !{i64 -118598699405051466}
!463 = !{i64 2238522520244936403}
!464 = !{i64 -4166923930064963404}
!465 = !{i64 8588262844481650122}
!466 = !{i64 -2418983666573353264}
!467 = !{i64 3190074080602597985}
!468 = !{i64 7706434999604408428}
!469 = !{i64 -3224917201699325270}
!470 = !{i64 2322291351412555740}
!471 = !{i64 -7787250746266527403}
!472 = !{i64 5240377817425467949}
!473 = !{i64 8643022154210098852}
!474 = !{i64 -472781102393204854}
!475 = !{i64 2625579025960863042}
!476 = !{i64 4662352216295641089}
!477 = !{i64 3993973734904141497}
!478 = !{i64 -7435445802934339218}
!479 = !{i64 4828369107705126864}
!480 = !{i64 -701663167984745416}
!481 = !{i64 -4547755060115544008}
!482 = !{i64 502863704662151517}
!483 = !{i64 -7359036805144118431}
!484 = !{i64 4135284004875837232}
!485 = !{i64 -7208926380773239180}
!486 = !{i64 5050879925542969114}
!487 = !{i64 -204059161248865432}
!488 = !{i64 5408725083170800752}
!489 = !{i64 -2192740649615040836}
!490 = !{i64 2008694181565858781}
!491 = !{i64 5763890423740766665}
!492 = !{i64 4175559698077349687}
!493 = !{i64 5183581299553304433}
!494 = !{i64 -5399252475041747933}
!495 = !{i64 5546759182908707256}
!496 = !{i64 -3645006064571784005}
!497 = !{i64 305159265121140092}
!498 = !{i64 340326672507282745}
!499 = !{i64 -5891861123014809254}
!500 = !{i64 -6660687406208643059}
!501 = !{i64 -6191174012555924288}
!502 = !{i64 2668904222604617531}
!503 = !{i64 8710630407326319622}
!504 = !{i64 4265385787280574212}
!505 = !{i64 4628974599018614110}
!506 = !{i64 7836350275288541212}
!507 = !{i64 5292249498953109309}
!508 = !{i64 -2282108357768080441}
!509 = !{i64 4509009949944141964}
!510 = !{i64 8860691874569827401}
!511 = !{i64 -5700880930821812163}
!512 = !{i64 -3303317654589089126}
!513 = !{i64 -56405571295219140}
!514 = !{i64 904164518476434414}
!515 = !{i64 5006376259776027410}
!516 = !{i64 3765471713840121604}
!517 = !{i64 6465884663250427376}
!518 = !{i64 1876662325434388984}
!519 = !{i64 -6003211696055402422}
!520 = !{i64 -8390637413850072752}
!521 = !{i64 1706629996362875838}
!522 = !{i64 -8692546362795551817}
!523 = !{i64 -1070435096781720471}
!524 = !{i64 2235792422406848424}
!525 = !{i64 -9100033225587921685}
!526 = !{i64 6337302478871920553}
!527 = !{i64 1067576409137522165}
!528 = !{i64 9207266023312653867}
!529 = !{i64 -631854716141168197}
!530 = !{i64 1411990468488299254}
!531 = !{i64 7180580839507332368}
!532 = !{i64 -2483507539565609397}
!533 = !{i64 7704090838498359773}
!534 = !{i64 5497578032971794747}
!535 = !{i64 -6824900430528385776}
!536 = !{i64 -7027296281626719154}
!537 = !{i64 5735205434554669186}
!538 = !{i64 -6770013209337321443}
!539 = !{i64 -5178191417374790618}
!540 = !{i64 -3896508335838524921}
!541 = !{i64 -161090877328412630}
!542 = !{i64 334646429251690703}
!543 = !{i64 69999482991909389}
!544 = !{i64 9139126401681465074}
!545 = !{i64 8571156419778585359}
!546 = !{i64 5354673430619845441}
!547 = !{i64 3830050846212660024}
!548 = !{i64 3692889692290979442}
!549 = !{i64 4564134920895841699}
!550 = !{i64 -1085930745290656576}
!551 = !{i64 4965063261802063663}
!552 = !{i64 -3683024841697503188}
!553 = !{i64 -3454852135807666432}
!554 = !{i64 6586315322880056123}
!555 = !{i64 -4234104990090334594}
!556 = !{i64 4723682765002850645}
!557 = !{i64 -8723681664707620770}
!558 = !{i64 -4816714376129756289}
!559 = !{i64 2791145277480100680}
!560 = !{i64 -8005543308867687391}
!561 = !{i64 5887533479841376299}
!562 = !{i64 587351243770878031}
!563 = !{i64 7544248892780419262}
!564 = !{i64 1353477516331240393}
!565 = !{i64 1662726600542826758}
!566 = !{i64 -6864620545046379728}
!567 = !{i64 2940807409231870610}
!568 = !{i64 -1174380182201225735}
!569 = !{i64 -1690684307371652969}
!570 = !{i64 4467889108712897409}
!571 = !{i64 5123683284861979297}
!572 = !{i64 -3585125295547744099}
!573 = !{i64 -7998188685703992785}
!574 = !{i64 588096439720763688}
!575 = !{i64 -9110667325748568558}
!576 = !{i64 -8546255796595162284}
!577 = !{i64 -6859445754803539487}
!578 = !{i64 -8517375332312890078}
!579 = !{i64 9134409235890646618}
!580 = !{i64 1774525399952260585}
!581 = !{i64 -5608129612401222530}
!582 = !{i64 3412127512733590010}
!583 = !{i64 1274183126824395928}
!584 = !{i64 8208980840767012963}
!585 = !{i64 -1453881364500510632}
!586 = !{i64 -8188641509210019127}
!587 = !{i64 6141487275011536644}
!588 = !{i64 1017115666746320639}
!589 = !{i64 810369609297201554}
!590 = !{i64 -9152334252280184762}
!591 = !{i64 -4529810101994292838}
!592 = !{i64 6120838939219000493}
!593 = !{i64 -4648211752968565084}
!594 = !{i64 -8116751889981642662}
!595 = !{i64 -5992767211044204243}
!596 = !{i64 6902561478883010557}
!597 = !{i64 2655725400372645356}
!598 = !{i64 3883858741529814127}
!599 = !{i64 -1820879531479991984}
!600 = !{i64 5837380661535326277}
!601 = !{i64 3538722203944050652}
!602 = !{i64 -5597147652733315661}
!603 = !{i64 2045756652373971646}
!604 = !{i64 767722909440130208}
!605 = !{i64 3325476770628121997}
!606 = !{i64 -5752365227146131086}
!607 = !{i64 -8144936664858020109}
!608 = !{i64 -411898865607421427}
!609 = !{i64 373930662263317740}
!610 = !{i64 -8188072540596936300}
!611 = !{i64 1957242684408410142}
!612 = !{i64 118091091504629236}
!613 = !{i64 -780850886955175427}
!614 = !{i64 -3926707533395026226}
!615 = !{i64 -2875040738240638762}
!616 = !{i64 8590024418050858639}
!617 = !{i64 -4092771972797870063}
!618 = !{i64 8504092312380019254}
!619 = !{i64 -8852031582241669668}
!620 = !{i64 2790679076615705244}
!621 = !{i64 -2624081020897602054}
