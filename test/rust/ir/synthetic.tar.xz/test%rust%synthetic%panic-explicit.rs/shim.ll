; ModuleID = 't.civazttarfsjaho27i5q2v4p1.rcgu.bc'
source_filename = "civazttarfsjaho27i5q2v4p1"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
define noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %0, i64 allocalign %1) unnamed_addr #0 !guid !5 {
entry:
  %2 = tail call ptr @_RNvCs6C7K2MLX5zw_7___rustc11___rdl_alloc(i64 %0, i64 %1)
  ret ptr %2
}

declare hidden ptr @_RNvCs6C7K2MLX5zw_7___rustc11___rdl_alloc(i64, i64) unnamed_addr

; Function Attrs: allockind("free") uwtable
define void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address) %0, i64 %1, i64 %2) unnamed_addr #1 !guid !6 {
entry:
  tail call void @_RNvCs6C7K2MLX5zw_7___rustc13___rdl_dealloc(ptr %0, i64 %1, i64 %2)
  ret void
}

declare hidden void @_RNvCs6C7K2MLX5zw_7___rustc13___rdl_dealloc(ptr, i64, i64) unnamed_addr

; Function Attrs: allockind("realloc,aligned") allocsize(3) uwtable
define noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc14___rust_realloc(ptr allocptr %0, i64 %1, i64 allocalign %2, i64 %3) unnamed_addr #2 !guid !7 {
entry:
  %4 = tail call ptr @_RNvCs6C7K2MLX5zw_7___rustc13___rdl_realloc(ptr %0, i64 %1, i64 %2, i64 %3)
  ret ptr %4
}

declare hidden ptr @_RNvCs6C7K2MLX5zw_7___rustc13___rdl_realloc(ptr, i64, i64, i64) unnamed_addr

; Function Attrs: allockind("alloc,zeroed,aligned") allocsize(0) uwtable
define noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %0, i64 allocalign %1) unnamed_addr #3 !guid !8 {
entry:
  %2 = tail call ptr @_RNvCs6C7K2MLX5zw_7___rustc18___rdl_alloc_zeroed(i64 %0, i64 %1)
  ret ptr %2
}

declare hidden ptr @_RNvCs6C7K2MLX5zw_7___rustc18___rdl_alloc_zeroed(i64, i64) unnamed_addr

; Function Attrs: uwtable
define void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #4 !guid !9 {
entry:
  ret void
}

attributes #0 = { allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { allockind("realloc,aligned") allocsize(3) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{i32 2, !"RtLibUseGOT", i32 1}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!5 = !{i64 -7160269985955594206}
!6 = !{i64 -1125011905757154329}
!7 = !{i64 -4276316565829750896}
!8 = !{i64 -3298154745001784099}
!9 = !{i64 -8187026863509695192}
