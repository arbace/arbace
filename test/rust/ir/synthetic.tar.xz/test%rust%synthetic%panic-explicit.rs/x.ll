; ModuleID = 'panic_explicit.1f4a3e2f832b3ce1-cgu.0'
source_filename = "panic_explicit.1f4a3e2f832b3ce1-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs2GytfuIrfC7_14panic_explicit, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs2GytfuIrfC7_14panic_explicit, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs2GytfuIrfC7_14panic_explicit }>, align 8, !guid !0
@alloc_649d3ff82cae9deab35888ae4e861089 = private unnamed_addr constant [6 x i8] c"start\0A", align 1, !guid !1
@alloc_babee5271e6e42dc125a96e0272fa27d = private unnamed_addr constant [3 x i8] c"two", align 1, !guid !2
@alloc_8c0ff41f85eded88d79c00f55b567c31 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @alloc_babee5271e6e42dc125a96e0272fa27d, [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8, !guid !3
@alloc_4f6c0cea7c4187b65ea91a4797195937 = private unnamed_addr constant [15 x i8] c"\09explicit \C0\01 \C0\00", align 1, !guid !4
@alloc_4166ca5b1c7be93f048ef1da23c624b9 = private unnamed_addr constant [38 x i8] c"test/rust/synthetic/panic-explicit.rs\00", align 1, !guid !5
@alloc_08f0de7b1f6e8a9729d737b6065a8309 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_4166ca5b1c7be93f048ef1da23c624b9, [16 x i8] c"%\00\00\00\00\00\00\00\06\00\00\00\05\00\00\00" }>, align 8, !guid !6

; <core::fmt::Arguments>::new::<15, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj2_ECs2GytfuIrfC7_14panic_explicit(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !12 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs2GytfuIrfC7_14panic_explicit(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !13 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs2GytfuIrfC7_14panic_explicit(i32 %dummy) unnamed_addr #0 !guid !14 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !15
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs2GytfuIrfC7_14panic_explicit(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !16 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs2GytfuIrfC7_14panic_explicit(ptr %f) #7
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #7
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs2GytfuIrfC7_14panic_explicit(ptr align 8 %_1) unnamed_addr #0 !guid !17 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs2GytfuIrfC7_14panic_explicit(ptr %_4) #8
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs2GytfuIrfC7_14panic_explicit() #7
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs2GytfuIrfC7_14panic_explicit(i8 %_2) #7
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs2GytfuIrfC7_14panic_explicit(ptr %_1) unnamed_addr #0 !guid !18 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs2GytfuIrfC7_14panic_explicit(ptr %0) #7
  ret i32 %_0
}

; panic_explicit::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs2GytfuIrfC7_14panic_explicit4main() unnamed_addr #1 !guid !19 {
start:
  %_11 = alloca [16 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  %_7 = alloca [4 x i8], align 4
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs2GytfuIrfC7_14panic_explicit(ptr @alloc_649d3ff82cae9deab35888ae4e861089, i64 6) #7
  %_2.0 = extractvalue { ptr, ptr } %0, 0
  %_2.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<i32>
  %1 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs2GytfuIrfC7_14panic_explicit(i32 1) #7
  store i32 %1, ptr %_7, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_10, ptr align 4 %_7) #7
; call <core::fmt::rt::Argument>::new_debug::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECs257F0UrNG3U_14rustc_demangle(ptr sret([16 x i8]) align 8 %_11, ptr align 8 @alloc_8c0ff41f85eded88d79c00f55b567c31) #7
  %2 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %_10, i64 16, i1 false)
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_11, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 2>
  %4 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj2_ECs2GytfuIrfC7_14panic_explicit(ptr @alloc_4f6c0cea7c4187b65ea91a4797195937, ptr align 8 %args) #7
  %_4.0 = extractvalue { ptr, ptr } %4, 0
  %_4.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_4.0, ptr %_4.1, ptr align 8 @alloc_08f0de7b1f6e8a9729d737b6065a8309) #9
  unreachable
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs2GytfuIrfC7_14panic_explicit(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !20 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs2GytfuIrfC7_14panic_explicit(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !21 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs2GytfuIrfC7_14panic_explicit(ptr %s.0, i64 %s.1) #7
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs2GytfuIrfC7_14panic_explicit(ptr %self) unnamed_addr #0 !guid !22 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs2GytfuIrfC7_14panic_explicit(i8 %0) unnamed_addr #0 !guid !23 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs2GytfuIrfC7_14panic_explicit(ptr %self) #7
  ret i32 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs2GytfuIrfC7_14panic_explicit() unnamed_addr #0 !guid !24 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs2GytfuIrfC7_14panic_explicit(ptr %_1) unnamed_addr #0 !guid !25 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs2GytfuIrfC7_14panic_explicit(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !26 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs2GytfuIrfC7_14panic_explicit(ptr align 8 %_1) #7
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::rt::Argument>::new_debug::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugReECs257F0UrNG3U_14rustc_demangle(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #5

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #6 !guid !27 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs2GytfuIrfC7_14panic_explicit(ptr @_RNvCs2GytfuIrfC7_14panic_explicit4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nonlazybind "target-cpu"="x86-64" }
attributes #7 = { inlinehint }
attributes #8 = { noinline }
attributes #9 = { noinline noreturn }

!llvm.module.flags = !{!7, !8, !9, !10}
!llvm.ident = !{!11}

!0 = !{i64 1489112106248673323}
!1 = !{i64 -7146383919299781494}
!2 = !{i64 3531006455070457534}
!3 = !{i64 -3711924439243408554}
!4 = !{i64 1592778944560914483}
!5 = !{i64 7755199202030077457}
!6 = !{i64 -56742801693242643}
!7 = !{i32 8, !"PIC Level", i32 2}
!8 = !{i32 7, !"PIE Level", i32 2}
!9 = !{i32 2, !"RtLibUseGOT", i32 1}
!10 = !{i32 7, !"uwtable", i32 2}
!11 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!12 = !{i64 4479096654280438103}
!13 = !{i64 7878355414161792596}
!14 = !{i64 -1008142898092908803}
!15 = !{i64 1312743869426124}
!16 = !{i64 928924992854506856}
!17 = !{i64 -6266289171080028187}
!18 = !{i64 449107805709447662}
!19 = !{i64 -4150191584009400429}
!20 = !{i64 1264905317671468801}
!21 = !{i64 2366875104649112808}
!22 = !{i64 -5258593089489383119}
!23 = !{i64 1949298592792992654}
!24 = !{i64 -5870999233083609026}
!25 = !{i64 -6059295927046759519}
!26 = !{i64 -853177275610635314}
!27 = !{i64 -2624081020897602054}
