; ModuleID = 'int_ops_u64.796c94a944354593-cgu.0'
source_filename = "int_ops_u64.796c94a944354593-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsaqkWKWdl1xD_11int_ops_u64, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaqkWKWdl1xD_11int_ops_u64, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaqkWKWdl1xD_11int_ops_u64 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_b7f057a700061b96879a1cf049d1c13f = private unnamed_addr constant [4 x i8] c"@\00\00\00", align 4, !guid !3
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !4
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !5
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !6
@alloc_b14bb161abcc1e25b418bf7683984c8b = private unnamed_addr constant [35 x i8] c"test/rust/synthetic/int-ops-u64.rs\00", align 1, !guid !7
@alloc_8a23c0758fbf417fc818cbd8735ef655 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !8
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !9
@alloc_7f34e9163fb18bbebb42b639348843c3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !10
@alloc_16b4e0c063782b4883031e6e0c36e77b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !11
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !12
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !13
@alloc_dd0c98b643347ed36d6d6d8492534cf1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !14
@alloc_8f9d50c9386268ec077df5193767c256 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !15
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !16
@alloc_db4a9b34cd4b0400e0309e7a877f6ab6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !17
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !18
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !19
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !20
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !21
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !22
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !23
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !24
@alloc_ae2de464f9b6df44eca1585c04dc7532 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00*\05\00\00\05\00\00\00" }>, align 8, !guid !25
@alloc_5aa1d1250638a5285856df0c8e3018a3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00K\07\00\00\01\00\00\00" }>, align 8, !guid !26
@anon.3163d8aaa3ec962f62b1dd64a9184856.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !27
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !28
@alloc_dd07830ff498a5ad3af27fc9310868e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E5\00\00\00\12\00\00\00" }>, align 8, !guid !29
@alloc_73a63def61abd19c5b285b7e5bba6f74 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E6\00\00\00\05\00\00\00" }>, align 8, !guid !30
@alloc_c9c619c258f652778f0098fbdacd3593 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F1\00\00\00\12\00\00\00" }>, align 8, !guid !31
@alloc_debe392282102e1a17f340d9b53f07df = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F2\00\00\00\12\00\00\00" }>, align 8, !guid !32
@alloc_d1e64d3a180065bd6a022925cad00717 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F3\00\00\00\05\00\00\00" }>, align 8, !guid !33
@alloc_9a4d1999757609695fb8537fcdec871b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FE\00\00\00\12\00\00\00" }>, align 8, !guid !34
@alloc_ffea377e021bf2f87b4ad4aac9bcd041 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FF\00\00\00\12\00\00\00" }>, align 8, !guid !35
@alloc_3410a5a3f8bc9abd6709ddad50da91f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\00\01\00\00\12\00\00\00" }>, align 8, !guid !36
@alloc_cb646754bd05cd238e749888201337e6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\01\01\00\00\05\00\00\00" }>, align 8, !guid !37
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !38
@alloc_c856595eac66a24654d670eae8c59bb6 = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u64::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !39
@alloc_f4be92229193d4464753072989252627 = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u64::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !40
@alloc_10473b11a7e05bbd7ed679b01f6c847b = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u64::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !41
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !42
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtB8_ }>, align 8, !guid !43
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64 }>, align 8, !guid !44
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !45
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !46
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !47
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !48
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_ }>, align 8, !guid !49
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !50
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !51
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64 }>, align 8, !guid !52

; <str>::parse::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !58 {
start:
; call <u64 as core::str::traits::FromStr>::from_str
  call void @_RNvXsC_NtCsl10jNU3mE6R_4core3numyNtNtNtB7_3str6traits7FromStr8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #17
  ret void
}

; <core::fmt::rt::Argument>::new_binary::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !59 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refB9_(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<u64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsy_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !60 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !61 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !62 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 4 %x) #17
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !63 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refB9_(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<u64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsE_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !64 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<u64>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionyEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<core::option::Option<u64>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionyEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionyENtNtB7_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<u64, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultyNtNtNtB7_3num5error13ParseIntErrorEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !65 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<u64, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultyNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<core::result::Result<u64, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultyNtNtNtBa_3num5error13ParseIntErrorEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultyNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(u64, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTybEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !66 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(u64, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTybEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<(u64, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTybEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTybENtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !67 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr %x) #17
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !68 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refB9_(ptr align 8 %x) #17
; call <core::ptr::non_null::NonNull<u64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuEBa_(ptr %_4) #17
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsA_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::non_null::NonNull<core::option::Option<u64>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionyEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !69 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<u64, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultyNtNtNtBa_3num5error13ParseIntErrorEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !70 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<(u64, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTybEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !71 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !72 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !73 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !74 {
start:
  ret ptr %self
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsaqkWKWdl1xD_11int_ops_u64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !75 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !76 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !77 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsaqkWKWdl1xD_11int_ops_u64(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !78 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_right::<u64>
; Function Attrs: nounwind nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightyECsaqkWKWdl1xD_11int_ops_u64(i64 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !79 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 8 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i64
  %_0 = call i64 @llvm.fshr.i64(i64 %x, i64 %x, i64 %1)
  ret i64 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #19
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsaqkWKWdl1xD_11int_ops_u64(i32 %dummy) unnamed_addr #0 !guid !80 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !81
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 %dummy) unnamed_addr #0 !guid !82 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !81
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 %dummy) unnamed_addr #0 !guid !83 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !81
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsaqkWKWdl1xD_11int_ops_u64(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !84 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr %f) #17
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #17
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1) unnamed_addr #0 !guid !85 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #20
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsaqkWKWdl1xD_11int_ops_u64() #17
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsaqkWKWdl1xD_11int_ops_u64(i8 %_2) #17
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsaqkWKWdl1xD_11int_ops_u64(ptr %_1) unnamed_addr #0 !guid !86 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr %0) #17
  ret i32 %_0
}

; int_ops_u64::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsaqkWKWdl1xD_11int_ops_u644main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !87 {
start:
  %0 = alloca [16 x i8], align 8
  %_288 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_283 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_278 = alloca [24 x i8], align 8
  %_277 = alloca [24 x i8], align 8
  %_273 = alloca [24 x i8], align 8
  %_270 = alloca [8 x i8], align 8
  %_263 = alloca [16 x i8], align 8
  %_262 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_258 = alloca [4 x i8], align 4
  %_256 = alloca [8 x i8], align 8
  %_249 = alloca [16 x i8], align 8
  %_248 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_246 = alloca [4 x i8], align 4
  %_244 = alloca [4 x i8], align 4
  %_237 = alloca [16 x i8], align 8
  %_236 = alloca [16 x i8], align 8
  %_235 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_233 = alloca [8 x i8], align 8
  %_231 = alloca [4 x i8], align 4
  %_227 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_220 = alloca [16 x i8], align 8
  %_219 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_216 = alloca [16 x i8], align 8
  %_214 = alloca [1 x i8], align 1
  %_210 = alloca [16 x i8], align 8
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_200 = alloca [8 x i8], align 8
  %_197 = alloca [8 x i8], align 8
  %_190 = alloca [16 x i8], align 8
  %_189 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_187 = alloca [16 x i8], align 8
  %_184 = alloca [16 x i8], align 8
  %_177 = alloca [16 x i8], align 8
  %_176 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_173 = alloca [8 x i8], align 8
  %_170 = alloca [8 x i8], align 8
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [8 x i8], align 8
  %_156 = alloca [8 x i8], align 8
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [8 x i8], align 8
  %_144 = alloca [8 x i8], align 8
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [8 x i8], align 8
  %_130 = alloca [8 x i8], align 8
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [16 x i8], align 8
  %_98 = alloca [16 x i8], align 8
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [8 x i8], align 8
  %_86 = alloca [8 x i8], align 8
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [8 x i8], align 8
  %_74 = alloca [8 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [8 x i8], align 8
  %_62 = alloca [8 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %_50 = alloca [16 x i8], align 8
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_38 = alloca [16 x i8], align 8
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [8 x i8], align 8
  %min = alloca [8 x i8], align 8
; call core::hint::black_box::<u64>
  %_4 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 0) #17
; call core::hint::black_box::<u64>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 -1) #17
  store i64 %_4, ptr %min, align 8
  store i64 %_5, ptr %max, align 8
; call core::hint::black_box::<u64>
  %one = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 1) #17
; call core::hint::black_box::<u64>
  %three = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 3) #17
  store ptr %min, ptr %args, align 8
  %1 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_b7f057a700061b96879a1cf049d1c13f, ptr %2, align 8
  %_291 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_15, ptr align 8 %_291) #17
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  %_292 = load ptr, ptr %3, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_16, ptr align 8 %_292) #17
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  %_293 = load ptr, ptr %4, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_293) #17
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_15, i64 16, i1 false)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_16, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #17
  %_9.0 = extractvalue { ptr, ptr } %8, 0
  %_9.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %9 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %11, align 8
  %_294 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs2d0hS33vDhg_5gimli(ptr sret([16 x i8]) align 8 %_28, ptr align 8 %_294) #17
  %12 = getelementptr inbounds i8, ptr %args2, i64 8
  %_295 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_binary::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_29, ptr align 8 %_295) #17
  %13 = getelementptr inbounds i8, ptr %args2, i64 16
  %_296 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_octal::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_30, ptr align 8 %_296) #17
  %14 = getelementptr inbounds i8, ptr %args2, i64 24
  %_297 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_31, ptr align 8 %_297) #17
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_28, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_29, i64 16, i1 false)
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_30, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #17
  %_21.0 = extractvalue { ptr, ptr } %19, 0
  %_21.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %20 = load i64, ptr %max, align 8
; call <u64>::checked_add
  %21 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_addCsaqkWKWdl1xD_11int_ops_u64(i64 %20, i64 %one) #17
  %22 = extractvalue { i64, i64 } %21, 0
  %23 = extractvalue { i64, i64 } %21, 1
  store i64 %22, ptr %_38, align 8
  %24 = getelementptr inbounds i8, ptr %_38, i64 8
  store i64 %23, ptr %24, align 8
  %25 = load i64, ptr %min, align 8
; call <u64>::checked_add
  %26 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_addCsaqkWKWdl1xD_11int_ops_u64(i64 %25, i64 %one) #17
  %27 = extractvalue { i64, i64 } %26, 0
  %28 = extractvalue { i64, i64 } %26, 1
  store i64 %27, ptr %_40, align 8
  %29 = getelementptr inbounds i8, ptr %_40, i64 8
  store i64 %28, ptr %29, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_42, ptr align 8 %_38) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_43, ptr align 8 %_40) #17
  %30 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %30, ptr align 8 %_42, i64 16, i1 false)
  %31 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %31, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %32 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #17
  %_35.0 = extractvalue { ptr, ptr } %32, 0
  %_35.1 = extractvalue { ptr, ptr } %32, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %33 = load i64, ptr %max, align 8
  %_5.0.i = add i64 %33, %one
  %_5.1.i = icmp ult i64 %_5.0.i, %33
  %34 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %35 = insertvalue { i64, i1 } %34, i1 %_5.1.i, 1
  %36 = extractvalue { i64, i1 } %35, 0
  %37 = extractvalue { i64, i1 } %35, 1
  store i64 %36, ptr %_50, align 8
  %38 = getelementptr inbounds i8, ptr %_50, i64 8
  %39 = zext i1 %37 to i8
  store i8 %39, ptr %38, align 8
  %40 = load i64, ptr %min, align 8
  %_5.0.i53 = sub i64 %40, %one
  %_5.1.i54 = icmp ult i64 %40, %one
  %41 = insertvalue { i64, i1 } poison, i64 %_5.0.i53, 0
  %42 = insertvalue { i64, i1 } %41, i1 %_5.1.i54, 1
  %43 = extractvalue { i64, i1 } %42, 0
  %44 = extractvalue { i64, i1 } %42, 1
  store i64 %43, ptr %_52, align 8
  %45 = getelementptr inbounds i8, ptr %_52, i64 8
  %46 = zext i1 %44 to i8
  store i8 %46, ptr %45, align 8
; call <core::fmt::rt::Argument>::new_debug::<(u64, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTybEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_54, ptr align 8 %_50) #17
; call <core::fmt::rt::Argument>::new_debug::<(u64, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTybEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_55, ptr align 8 %_52) #17
  %47 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %47, ptr align 8 %_54, i64 16, i1 false)
  %48 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %48, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %49 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #17
  %_47.0 = extractvalue { ptr, ptr } %49, 0
  %_47.1 = extractvalue { ptr, ptr } %49, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %50 = load i64, ptr %max, align 8
  %_0.i35 = add i64 %50, %one
  store i64 %_0.i35, ptr %_62, align 8
  %51 = load i64, ptr %min, align 8
  %_0.i41 = sub i64 %51, %one
  store i64 %_0.i41, ptr %_64, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_66, ptr align 8 %_62) #17
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_67, ptr align 8 %_64) #17
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_66, i64 16, i1 false)
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %54 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #17
  %_59.0 = extractvalue { ptr, ptr } %54, 0
  %_59.1 = extractvalue { ptr, ptr } %54, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %55 = load i64, ptr %max, align 8
  %_0.i49 = call i64 @llvm.uadd.sat.i64(i64 %55, i64 %three)
  store i64 %_0.i49, ptr %_74, align 8
  %56 = load i64, ptr %min, align 8
  %_0.i50 = call i64 @llvm.usub.sat.i64(i64 %56, i64 %three)
  store i64 %_0.i50, ptr %_76, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_78, ptr align 8 %_74) #17
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_79, ptr align 8 %_76) #17
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_78, i64 16, i1 false)
  %58 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %58, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %59 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #17
  %_71.0 = extractvalue { ptr, ptr } %59, 0
  %_71.1 = extractvalue { ptr, ptr } %59, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %60 = load i64, ptr %max, align 8
  %_0.i37 = mul i64 %60, %three
  store i64 %_0.i37, ptr %_86, align 8
  %61 = load i64, ptr %max, align 8
  %62 = load i64, ptr %max, align 8
  %_0.i36 = mul i64 %61, %62
  store i64 %_0.i36, ptr %_88, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_90, ptr align 8 %_86) #17
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_91, ptr align 8 %_88) #17
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_90, i64 16, i1 false)
  %64 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %64, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %65 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #17
  %_83.0 = extractvalue { ptr, ptr } %65, 0
  %_83.1 = extractvalue { ptr, ptr } %65, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %66 = load i64, ptr %max, align 8
; call <u64>::checked_mul
  %67 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %66, i64 %three) #17
  %68 = extractvalue { i64, i64 } %67, 0
  %69 = extractvalue { i64, i64 } %67, 1
  store i64 %68, ptr %_98, align 8
  %70 = getelementptr inbounds i8, ptr %_98, i64 8
  store i64 %69, ptr %70, align 8
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 5) #17
; call <u64>::checked_pow
  %71 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_powCsaqkWKWdl1xD_11int_ops_u64(i64 %three, i32 %_101) #17
  %72 = extractvalue { i64, i64 } %71, 0
  %73 = extractvalue { i64, i64 } %71, 1
  store i64 %72, ptr %_100, align 8
  %74 = getelementptr inbounds i8, ptr %_100, i64 8
  store i64 %73, ptr %74, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_103, ptr align 8 %_98) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_104, ptr align 8 %_100) #17
  %75 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %75, ptr align 8 %_103, i64 16, i1 false)
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %77 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #17
  %_95.0 = extractvalue { ptr, ptr } %77, 0
  %_95.1 = extractvalue { ptr, ptr } %77, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %78 = load i64, ptr %max, align 8
  %79 = call i64 @llvm.ctpop.i64(i64 %78)
  %_0.i = trunc i64 %79 to i32
  store i32 %_0.i, ptr %_111, align 4
  %80 = load i64, ptr %max, align 8
  %81 = call i64 @llvm.ctlz.i64(i64 %80, i1 false)
  %_0.i43 = trunc i64 %81 to i32
  store i32 %_0.i43, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsaqkWKWdl1xD_11int_ops_u64(i32 3) #17
  %_119 = icmp ult i32 %_117, 64
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %82 = and i32 %_117, 63
  %83 = zext i32 %82 to i64
  %_116 = shl i64 %one, %83
  %84 = call i64 @llvm.cttz.i64(i64 %_116, i1 false)
  %_0.i52 = trunc i64 %84 to i32
  store i32 %_0.i52, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %85 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %85, align 8
  %86 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %86, align 8
  %_310 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_310) #17
  %87 = getelementptr inbounds i8, ptr %args10, i64 8
  %_311 = load ptr, ptr %87, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_311) #17
  %88 = getelementptr inbounds i8, ptr %args10, i64 16
  %_312 = load ptr, ptr %88, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_312) #17
  %89 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %89, ptr align 8 %_121, i64 16, i1 false)
  %90 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %90, ptr align 8 %_122, i64 16, i1 false)
  %91 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %91, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %92 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #17
  %_108.0 = extractvalue { ptr, ptr } %92, 0
  %_108.1 = extractvalue { ptr, ptr } %92, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 5) #17
  %93 = load i64, ptr %max, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i31 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %93, i32 %_131) #21
  store i64 %_0.i31, ptr %_130, align 8
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 7) #17
  %94 = load i64, ptr %min, align 8
; call core::intrinsics::rotate_right::<u64>
  %_0.i34 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightyECsaqkWKWdl1xD_11int_ops_u64(i64 %94, i32 %_134) #21
  store i64 %_0.i34, ptr %_133, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_136, ptr align 8 %_130) #17
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_137, ptr align 8 %_133) #17
  %95 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %95, ptr align 8 %_136, i64 16, i1 false)
  %96 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %96, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %97 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #17
  %_127.0 = extractvalue { ptr, ptr } %97, 0
  %_127.1 = extractvalue { ptr, ptr } %97, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %98 = load i64, ptr %max, align 8
  %_0.i30 = call i64 @llvm.bswap.i64(i64 %98)
  store i64 %_0.i30, ptr %_144, align 8
  %99 = load i64, ptr %max, align 8
  %_0.i33 = call i64 @llvm.bitreverse.i64(i64 %99)
  store i64 %_0.i33, ptr %_146, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_148, ptr align 8 %_144) #17
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_149, ptr align 8 %_146) #17
  %100 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %100, ptr align 8 %_148, i64 16, i1 false)
  %101 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %101, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %102 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #17
  %_141.0 = extractvalue { ptr, ptr } %102, 0
  %_141.1 = extractvalue { ptr, ptr } %102, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 70) #17
  %103 = load i64, ptr %max, align 8
  %_3.i = and i32 %_157, 63
; call core::ub_checks::check_language_ub
  %_3.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_3.i44, label %bb2.i, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <u64>::unchecked_shl::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %_3.i, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %104 = zext i32 %_3.i to i64
  %_0.i45 = shl i64 %103, %104
  store i64 %_0.i45, ptr %_156, align 8
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 66) #17
  %105 = load i64, ptr %min, align 8
  %_3.i39 = and i32 %_160, 63
; call core::ub_checks::check_language_ub
  %_3.i46 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_3.i46, label %bb2.i48, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit

bb2.i48:                                          ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit
; call <u64>::unchecked_shr::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %_3.i39, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit: ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit, %bb2.i48
  %106 = zext i32 %_3.i39 to i64
  %_0.i47 = lshr i64 %105, %106
  store i64 %_0.i47, ptr %_159, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_162, ptr align 8 %_156) #17
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_163, ptr align 8 %_159) #17
  %107 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_162, i64 16, i1 false)
  %108 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %108, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %109 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #17
  %_153.0 = extractvalue { ptr, ptr } %109, 0
  %_153.1 = extractvalue { ptr, ptr } %109, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i64 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_8a23c0758fbf417fc818cbd8735ef655) #23
  unreachable

bb85:                                             ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit
  %110 = load i64, ptr %max, align 8
  %111 = udiv i64 %110, %three
  store i64 %111, ptr %_170, align 8
  %_174 = icmp eq i64 %three, 0
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_7f34e9163fb18bbebb42b639348843c3) #23
  unreachable

bb86:                                             ; preds = %bb85
  %112 = load i64, ptr %max, align 8
  %113 = urem i64 %112, %three
  store i64 %113, ptr %_173, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_176, ptr align 8 %_170) #17
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_177, ptr align 8 %_173) #17
  %114 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %114, ptr align 8 %_176, i64 16, i1 false)
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_177, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %116 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #17
  %_167.0 = extractvalue { ptr, ptr } %116, 0
  %_167.1 = extractvalue { ptr, ptr } %116, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<u64>
  %_185 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 0) #17
  %117 = load i64, ptr %max, align 8
; call <u64>::checked_div
  %118 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_divCsaqkWKWdl1xD_11int_ops_u64(i64 %117, i64 %_185) #17
  %119 = extractvalue { i64, i64 } %118, 0
  %120 = extractvalue { i64, i64 } %118, 1
  store i64 %119, ptr %_184, align 8
  %121 = getelementptr inbounds i8, ptr %_184, i64 8
  store i64 %120, ptr %121, align 8
  %122 = load i64, ptr %max, align 8
; call <u64>::checked_rem
  %123 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_remCsaqkWKWdl1xD_11int_ops_u64(i64 %122, i64 %three) #17
  %124 = extractvalue { i64, i64 } %123, 0
  %125 = extractvalue { i64, i64 } %123, 1
  store i64 %124, ptr %_187, align 8
  %126 = getelementptr inbounds i8, ptr %_187, i64 8
  store i64 %125, ptr %126, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_189, ptr align 8 %_184) #17
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_190, ptr align 8 %_187) #17
  %127 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %127, ptr align 8 %_189, i64 16, i1 false)
  %128 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %128, ptr align 8 %_190, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %129 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #17
  %_181.0 = extractvalue { ptr, ptr } %129, 0
  %_181.1 = extractvalue { ptr, ptr } %129, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_181.0, ptr %_181.1)
; call core::hint::black_box::<u32>
  %_198 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 4) #17
; call <u64>::pow
  %130 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy3powCsaqkWKWdl1xD_11int_ops_u64(i64 %three, i32 %_198) #17
  store i64 %130, ptr %_197, align 8
  %131 = load i64, ptr %max, align 8
  %132 = load i64, ptr %min, align 8
; call <u64>::abs_diff
  %133 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8abs_diffCsaqkWKWdl1xD_11int_ops_u64(i64 %131, i64 %132) #17
  store i64 %133, ptr %_200, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_202, ptr align 8 %_197) #17
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_203, ptr align 8 %_200) #17
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_202, i64 16, i1 false)
  %135 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %135, ptr align 8 %_203, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %136 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #17
  %_194.0 = extractvalue { ptr, ptr } %136, 0
  %_194.1 = extractvalue { ptr, ptr } %136, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_194.0, ptr %_194.1)
; call core::hint::black_box::<u32>
  %_212 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 7) #17
; call <u64>::from_str_radix
  call void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy14from_str_radixCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_210, ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_212) #17
; call <str>::parse::<u64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_216, ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #17
; call <core::result::Result<u64, core::num::error::ParseIntError>>::is_ok
  %137 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultyNtNtNtB4_3num5error13ParseIntErrorE5is_okCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_216) #17
  %138 = zext i1 %137 to i8
  store i8 %138, ptr %_214, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<u64, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultyNtNtNtB7_3num5error13ParseIntErrorEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_219, ptr align 8 %_210) #17
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_220, ptr %_214) #17
  %139 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %139, ptr align 8 %_219, i64 16, i1 false)
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_220, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %141 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #17
  %_207.0 = extractvalue { ptr, ptr } %141, 0
  %_207.1 = extractvalue { ptr, ptr } %141, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_207.0, ptr %_207.1)
  %142 = load i64, ptr %max, align 8
  %_229 = uitofp i64 %142 to double
  %_228 = call i64 @llvm.fptoui.sat.i64.f64(double %_229)
  %143 = load i64, ptr %max, align 8
  %144 = icmp eq i64 %_228, %143
  %145 = zext i1 %144 to i8
  store i8 %145, ptr %_227, align 1
  %146 = load i64, ptr %max, align 8
  %147 = uitofp i64 %146 to float
  store float %147, ptr %_231, align 4
  %148 = load i64, ptr %min, align 8
  %149 = uitofp i64 %148 to double
  store double %149, ptr %_233, align 8
  store ptr %_227, ptr %args19, align 8
  %150 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_231, ptr %150, align 8
  %151 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_233, ptr %151, align 8
  %_327 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_235, ptr %_327) #17
  %152 = getelementptr inbounds i8, ptr %args19, i64 8
  %_328 = load ptr, ptr %152, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_236, ptr align 4 %_328) #17
  %153 = getelementptr inbounds i8, ptr %args19, i64 16
  %_329 = load ptr, ptr %153, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_237, ptr align 8 %_329) #17
  %154 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %154, ptr align 8 %_235, i64 16, i1 false)
  %155 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %155, ptr align 8 %_236, i64 16, i1 false)
  %156 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %156, ptr align 8 %_237, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %157 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #17
  %_224.0 = extractvalue { ptr, ptr } %157, 0
  %_224.1 = extractvalue { ptr, ptr } %157, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_224.0, ptr %_224.1)
  %158 = load i64, ptr %max, align 8
  %_2.i = xor i64 %158, -1
  %159 = call i64 @llvm.ctlz.i64(i64 %_2.i, i1 false)
  %_0.i42 = trunc i64 %159 to i32
  store i32 %_0.i42, ptr %_244, align 4
  %160 = load i64, ptr %min, align 8
  %161 = call i64 @llvm.cttz.i64(i64 %160, i1 false)
  %_0.i51 = trunc i64 %161 to i32
  store i32 %_0.i51, ptr %_246, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_248, ptr align 4 %_244) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_249, ptr align 4 %_246) #17
  %162 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %162, ptr align 8 %_248, i64 16, i1 false)
  %163 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %163, ptr align 8 %_249, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %164 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #17
  %_241.0 = extractvalue { ptr, ptr } %164, 0
  %_241.1 = extractvalue { ptr, ptr } %164, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_241.0, ptr %_241.1)
  %165 = load i64, ptr %max, align 8
; call <u64>::isqrt
  %166 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5isqrtCsaqkWKWdl1xD_11int_ops_u64(i64 %165) #17
  store i64 %166, ptr %_256, align 8
  %167 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %three, i64 %three)
  %_260.0 = extractvalue { i64, i1 } %167, 0
  %_260.1 = extractvalue { i64, i1 } %167, 1
  br i1 %_260.1, label %panic27, label %bb125

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_16b4e0c063782b4883031e6e0c36e77b) #23
  unreachable

bb125:                                            ; preds = %bb86
; call <u64>::ilog2
  %168 = call i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %_260.0, ptr align 8 @alloc_8f9d50c9386268ec077df5193767c256) #17
  store i32 %168, ptr %_258, align 4
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_262, ptr align 8 %_256) #17
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_263, ptr align 4 %_258) #17
  %169 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %169, ptr align 8 %_262, i64 16, i1 false)
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_263, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %171 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #17
  %_253.0 = extractvalue { ptr, ptr } %171, 0
  %_253.1 = extractvalue { ptr, ptr } %171, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_253.0, ptr %_253.1)
; call <u64 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringyNtB5_8ToString9to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_273, ptr align 8 %max) #17
; invoke <alloc::string::String>::len
  %_271 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_273)
          to label %bb132 unwind label %cleanup

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_dd0c98b643347ed36d6d6d8492534cf1) #23
  unreachable

bb145:                                            ; preds = %bb144, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_273) #24
          to label %bb146 unwind label %terminate

cleanup:                                          ; preds = %bb141, %bb134, %bb133, %bb132, %bb125
  %172 = landingpad { ptr, i32 }
          cleanup
  %173 = extractvalue { ptr, i32 } %172, 0
  %174 = extractvalue { ptr, i32 } %172, 1
  store ptr %173, ptr %0, align 8
  %175 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %174, ptr %175, align 8
  br label %bb145

bb132:                                            ; preds = %bb125
; invoke <core::fmt::rt::Argument>::new_display::<u64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_283, ptr align 8 %min)
          to label %bb133 unwind label %cleanup

bb133:                                            ; preds = %bb132
  %176 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %176, ptr align 8 %_283, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %177 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb134 unwind label %cleanup

bb134:                                            ; preds = %bb133
  %_279.0 = extractvalue { ptr, ptr } %177, 0
  %_279.1 = extractvalue { ptr, ptr } %177, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_278, ptr %_279.0, ptr %_279.1)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_277, ptr align 8 %_278, i64 24, i1 false)
  br label %bb136

bb136:                                            ; preds = %bb135
; invoke <alloc::string::String>::len
  %_275 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_277)
          to label %bb137 unwind label %cleanup28

bb144:                                            ; preds = %cleanup28
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_277) #24
          to label %bb145 unwind label %terminate

cleanup28:                                        ; preds = %bb140, %bb139, %bb138, %panic29, %bb136
  %178 = landingpad { ptr, i32 }
          cleanup
  %179 = extractvalue { ptr, i32 } %178, 0
  %180 = extractvalue { ptr, i32 } %178, 1
  store ptr %179, ptr %0, align 8
  %181 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %180, ptr %181, align 8
  br label %bb144

bb137:                                            ; preds = %bb136
  %_286.0 = add i64 %_271, %_275
  %_286.1 = icmp ult i64 %_286.0, %_271
  br i1 %_286.1, label %panic29, label %bb138

bb138:                                            ; preds = %bb137
  store i64 %_286.0, ptr %_270, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8 %_288, ptr align 8 %_270)
          to label %bb139 unwind label %cleanup28

panic29:                                          ; preds = %bb137
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_db4a9b34cd4b0400e0309e7a877f6ab6) #19
          to label %unreachable unwind label %cleanup28

unreachable:                                      ; preds = %panic29
  unreachable

bb139:                                            ; preds = %bb138
  %182 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %182, ptr align 8 %_288, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %183 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb140 unwind label %cleanup28

bb140:                                            ; preds = %bb139
  %_267.0 = extractvalue { ptr, ptr } %183, 0
  %_267.1 = extractvalue { ptr, ptr } %183, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_267.0, ptr %_267.1)
          to label %bb141 unwind label %cleanup28

bb141:                                            ; preds = %bb140
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_277)
          to label %bb142 unwind label %cleanup

bb142:                                            ; preds = %bb141
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_273)
  ret void

terminate:                                        ; preds = %bb145, %bb144
  %184 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #18
  unreachable

bb146:                                            ; preds = %bb145
  %185 = load ptr, ptr %0, align 8
  %186 = getelementptr inbounds i8, ptr %0, i64 8
  %187 = load i32, ptr %186, align 8
  %188 = insertvalue { ptr, i32 } poison, ptr %185, 0
  %189 = insertvalue { ptr, i32 } %188, i32 %187, 1
  resume { ptr, i32 } %189
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !88 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8 %self) #17
  ret i64 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsaqkWKWdl1xD_11int_ops_u64(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !89 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::result::Result<u64, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultyNtNtNtB4_3num5error13ParseIntErrorE5is_okCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !90 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %self, i32 %radix) unnamed_addr #0 !guid !91 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #17
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #23
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsaqkWKWdl1xD_11int_ops_u64(i32 %self) unnamed_addr #0 !guid !92 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsaqkWKWdl1xD_11int_ops_u64(i32 %self) #17
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsaqkWKWdl1xD_11int_ops_u64(i32 %self) unnamed_addr #0 !guid !93 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::num::nonzero::NonZero<u64>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE13leading_zerosCsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !94 {
start:
; call <core::num::nonzero::NonZero<u64>>::get
  %_2 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3getB9_(i64 %self) #17
  %0 = call i64 @llvm.ctlz.i64(i64 %_2, i1 true)
  %_0 = trunc i64 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u64>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !95 {
start:
; call <core::num::nonzero::NonZero<u64>>::leading_zeros
  %_3 = call i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE13leading_zerosCsaqkWKWdl1xD_11int_ops_u64(i64 %self) #17
  %_0 = sub i32 63, %_3
  ret i32 %_0
}

; <core::ptr::non_null::NonNull<core::option::Option<u64>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionyEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !96 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<u64, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultyNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !97 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<(u64, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTybEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !98 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr %r) unnamed_addr #0 !guid !99 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !100 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 4 %r) unnamed_addr #0 !guid !101 {
start:
  ret ptr %r
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !102 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #17
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr %_7.0, i64 %_7.1) #17
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !103 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsaqkWKWdl1xD_11int_ops_u64(ptr %s.0, i64 %s.1) #17
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i32 %self, i32 %rhs) unnamed_addr #0 !guid !104 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u64>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy10strict_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !105 {
start:
  %_3 = alloca [16 x i8], align 8
; call <u64>::checked_pow
  %1 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) #17
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_4 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_4 to i1
  br i1 %7, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %a = load i64, ptr %8, align 8
  ret i64 %a

bb4:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #19
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <u64>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_addCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !106 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5.0 = add i64 %self, %rhs
  %_5.1 = icmp ult i64 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <u64>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_divCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !107 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_5 = udiv i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <u64>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !108 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <u64>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %0) unnamed_addr #0 !guid !109 {
start:
  %_49 = alloca [16 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_24 = alloca [16 x i8], align 8
  %_11 = alloca [8 x i8], align 4
  %acc = alloca [8 x i8], align 8
  %base = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i64 %self, ptr %base, align 8
  store i64 1, ptr %acc, align 8
  %_6 = load i64, ptr %base, align 8
  %_5 = call i1 @llvm.is.constant.i64(i64 %_6)
  br i1 %_5, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_16 = load i32, ptr %exp, align 4
  %_15 = icmp eq i32 %_16, 0
  br i1 %_15, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %base, align 8
  %1 = call i64 @llvm.ctpop.i64(i64 %_8)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_10 = load i64, ptr %base, align 8
; call <u64>::ilog2
  %k = call i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %_10, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #17
  %_12 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i32 %k, i32 %_12) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_11, align 4
  %5 = getelementptr inbounds i8, ptr %_11, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_11, align 4
  %7 = getelementptr inbounds i8, ptr %_11, i64 4
  %8 = load i32, ptr %7, align 4
  %_13 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_13 to i1
  br i1 %9, label %bb9, label %bb8

bb12:                                             ; preds = %bb10
  %_18 = load i32, ptr %exp, align 4
  %_17 = call i1 @llvm.is.constant.i32(i32 %_18)
  br i1 %_17, label %bb14, label %bb26

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb37

bb26:                                             ; preds = %bb36, %bb12
  %_39 = load i32, ptr %exp, align 4
  %_38 = and i32 %_39, 1
  %_37 = icmp eq i32 %_38, 1
  br i1 %_37, label %bb27, label %bb32

bb14:                                             ; preds = %bb24, %bb12
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp ugt i32 %_20, 1
  br i1 %_19, label %bb15, label %bb25

bb32:                                             ; preds = %bb30, %bb26
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_50 = load i64, ptr %base, align 8
  %_51 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %13 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_50, i64 %_51) #17
  %14 = extractvalue { i64, i64 } %13, 0
  %15 = extractvalue { i64, i64 } %13, 1
  store i64 %14, ptr %_49, align 8
  %16 = getelementptr inbounds i8, ptr %_49, i64 8
  store i64 %15, ptr %16, align 8
  %_52 = load i64, ptr %_49, align 8
  %17 = getelementptr inbounds i8, ptr %_49, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = trunc nuw i64 %_52 to i1
  br i1 %19, label %bb36, label %bb35

bb27:                                             ; preds = %bb26
  %_41 = load i64, ptr %acc, align 8
  %_42 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %20 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_41, i64 %_42) #17
  %21 = extractvalue { i64, i64 } %20, 0
  %22 = extractvalue { i64, i64 } %20, 1
  store i64 %21, ptr %_40, align 8
  %23 = getelementptr inbounds i8, ptr %_40, i64 8
  store i64 %22, ptr %23, align 8
  %_43 = load i64, ptr %_40, align 8
  %24 = getelementptr inbounds i8, ptr %_40, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = trunc nuw i64 %_43 to i1
  br i1 %26, label %bb30, label %bb29

bb30:                                             ; preds = %bb27
  %27 = getelementptr inbounds i8, ptr %_40, i64 8
  %x = load i64, ptr %27, align 8
  store i64 %x, ptr %acc, align 8
  %_46 = load i32, ptr %exp, align 4
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb31, label %bb32

bb29:                                             ; preds = %bb27
  store i64 0, ptr %_0, align 8
  br label %bb37

bb37:                                             ; preds = %bb9, %bb8, %bb11, %bb23, %bb18, %bb25, %bb31, %bb35, %bb29
  %28 = load i64, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { i64, i64 } poison, i64 %28, 0
  %32 = insertvalue { i64, i64 } %31, i64 %30, 1
  ret { i64, i64 } %32

bb31:                                             ; preds = %bb30
  %_47 = load i64, ptr %acc, align 8
  %33 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_47, ptr %33, align 8
  store i64 1, ptr %_0, align 8
  br label %bb37

bb36:                                             ; preds = %bb32
  %34 = getelementptr inbounds i8, ptr %_49, i64 8
  %x1 = load i64, ptr %34, align 8
  store i64 %x1, ptr %base, align 8
  br label %bb26

bb35:                                             ; preds = %bb32
  store i64 0, ptr %_0, align 8
  br label %bb37

bb25:                                             ; preds = %bb14
  %_35 = load i64, ptr %acc, align 8
  %_36 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %35 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_35, i64 %_36) #17
  %36 = extractvalue { i64, i64 } %35, 0
  %37 = extractvalue { i64, i64 } %35, 1
  store i64 %36, ptr %_0, align 8
  %38 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %37, ptr %38, align 8
  br label %bb37

bb15:                                             ; preds = %bb14
  %_23 = load i32, ptr %exp, align 4
  %_22 = and i32 %_23, 1
  %_21 = icmp eq i32 %_22, 1
  br i1 %_21, label %bb16, label %bb20

bb20:                                             ; preds = %bb19, %bb15
  %39 = load i32, ptr %exp, align 4
  %40 = udiv i32 %39, 2
  store i32 %40, ptr %exp, align 4
  %_31 = load i64, ptr %base, align 8
  %_32 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %41 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_31, i64 %_32) #17
  %42 = extractvalue { i64, i64 } %41, 0
  %43 = extractvalue { i64, i64 } %41, 1
  store i64 %42, ptr %_30, align 8
  %44 = getelementptr inbounds i8, ptr %_30, i64 8
  store i64 %43, ptr %44, align 8
  %_33 = load i64, ptr %_30, align 8
  %45 = getelementptr inbounds i8, ptr %_30, i64 8
  %46 = load i64, ptr %45, align 8
  %47 = trunc nuw i64 %_33 to i1
  br i1 %47, label %bb24, label %bb23

bb16:                                             ; preds = %bb15
  %_25 = load i64, ptr %acc, align 8
  %_26 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %48 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_25, i64 %_26) #17
  %49 = extractvalue { i64, i64 } %48, 0
  %50 = extractvalue { i64, i64 } %48, 1
  store i64 %49, ptr %_24, align 8
  %51 = getelementptr inbounds i8, ptr %_24, i64 8
  store i64 %50, ptr %51, align 8
  %_27 = load i64, ptr %_24, align 8
  %52 = getelementptr inbounds i8, ptr %_24, i64 8
  %53 = load i64, ptr %52, align 8
  %54 = trunc nuw i64 %_27 to i1
  br i1 %54, label %bb19, label %bb18

bb19:                                             ; preds = %bb16
  %55 = getelementptr inbounds i8, ptr %_24, i64 8
  %x2 = load i64, ptr %55, align 8
  store i64 %x2, ptr %acc, align 8
  br label %bb20

bb18:                                             ; preds = %bb16
  store i64 0, ptr %_0, align 8
  br label %bb37

bb24:                                             ; preds = %bb20
  %56 = getelementptr inbounds i8, ptr %_30, i64 8
  %x3 = load i64, ptr %56, align 8
  store i64 %x3, ptr %base, align 8
  br label %bb14

bb23:                                             ; preds = %bb20
  store i64 0, ptr %_0, align 8
  br label %bb37

bb9:                                              ; preds = %bb4
  %57 = getelementptr inbounds i8, ptr %_11, i64 4
  %shift = load i32, ptr %57, align 4
; call <u64>::checked_shl
  %58 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_shlCsaqkWKWdl1xD_11int_ops_u64(i64 1, i32 %shift) #17
  %59 = extractvalue { i64, i64 } %58, 0
  %60 = extractvalue { i64, i64 } %58, 1
  store i64 %59, ptr %_0, align 8
  %61 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %60, ptr %61, align 8
  br label %bb37

bb8:                                              ; preds = %bb4
  store i64 0, ptr %_0, align 8
  br label %bb37

bb7:                                              ; No predecessors!
  unreachable
}

; <u64>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_remCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !110 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_5 = urem i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <u64>::checked_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_shlCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %rhs) unnamed_addr #0 !guid !111 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i32 %rhs, 64
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u64>::unchecked_shl::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %rhs, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i64
  %_0.i = shl i64 %self, %0
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_0.i, ptr %1, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit, %bb3
  %2 = load i64, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = insertvalue { i64, i64 } poison, i64 %2, 0
  %6 = insertvalue { i64, i64 } %5, i64 %4, 1
  ret { i64, i64 } %6
}

; <u64>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_subCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !112 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <u64>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy12wrapping_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) unnamed_addr #0 !guid !113 {
start:
; call <u64>::overflowing_pow
  %0 = call { i64, i1 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy15overflowing_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) #17
  %_3.0 = extractvalue { i64, i1 } %0, 0
  %_3.1 = extractvalue { i64, i1 } %0, 1
  ret i64 %_3.0
}

; <u64>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13checked_ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !114 {
start:
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u64>>::new
  %0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3newB9_(i64 %self) #17
  store i64 %0, ptr %_2, align 8
  %1 = load i64, ptr %_2, align 8
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i64, ptr %_2, align 8
; call <core::num::nonzero::NonZero<u64>>::ilog2
  %_5 = call i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %x) #17
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u64>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unbounded_shlCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %rhs) unnamed_addr #0 !guid !115 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp ult i32 %rhs, 64
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u64>::unchecked_shl::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %rhs, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i64
  %_0.i = shl i64 %self, %0
  store i64 %_0.i, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <u64>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i1 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy15overflowing_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %0) unnamed_addr #0 !guid !116 {
start:
  %_14 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [8 x i8], align 8
  %base = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i64 %self, ptr %base, align 8
  store i64 1, ptr %acc, align 8
  store i8 0, ptr %overflow, align 1
  %_8 = load i64, ptr %base, align 8
  %_7 = call i1 @llvm.is.constant.i64(i64 %_8)
  br i1 %_7, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp eq i32 %_20, 0
  br i1 %_19, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_10 = load i64, ptr %base, align 8
  %1 = call i64 @llvm.ctpop.i64(i64 %_10)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_12 = load i64, ptr %base, align 8
; call <u64>::ilog2
  %k = call i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %_12, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #17
  %_15 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i32 %k, i32 %_15) #17
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_14, align 4
  %5 = getelementptr inbounds i8, ptr %_14, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_14, align 4
  %7 = getelementptr inbounds i8, ptr %_14, i64 4
  %8 = load i32, ptr %7, align 4
  %_16 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_16 to i1
  br i1 %9, label %bb7, label %bb8

bb12:                                             ; preds = %bb10
  %_22 = load i32, ptr %exp, align 4
  %_21 = call i1 @llvm.is.constant.i32(i32 %_22)
  br i1 %_21, label %bb14, label %bb23

bb11:                                             ; preds = %bb10
  store i128 1, ptr %_0, align 8
  br label %bb30

bb23:                                             ; preds = %bb27, %bb12
  %_51 = load i32, ptr %exp, align 4
  %_50 = and i32 %_51, 1
  %_49 = icmp eq i32 %_50, 1
  br i1 %_49, label %bb24, label %bb27

bb14:                                             ; preds = %bb18, %bb12
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp ugt i32 %_24, 1
  br i1 %_23, label %bb15, label %bb21

bb27:                                             ; preds = %bb24, %bb23
  %10 = load i32, ptr %exp, align 4
  %11 = udiv i32 %10, 2
  store i32 %11, ptr %exp, align 4
  %_66 = load i64, ptr %base, align 8
  %_67 = load i64, ptr %base, align 8
  %12 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_66, i64 %_67)
  %_5.0.i5 = extractvalue { i64, i1 } %12, 0
  %_5.1.i6 = extractvalue { i64, i1 } %12, 1
  %_65.0 = extractvalue { i64, i1 } %12, 0
  %_65.1 = extractvalue { i64, i1 } %12, 1
  store i64 %_65.0, ptr %base, align 8
  %13 = zext i1 %_65.1 to i8
  store i8 %13, ptr %tmp_overflow, align 1
  %14 = load i8, ptr %tmp_overflow, align 1
  %_68 = trunc nuw i8 %14 to i1
  %15 = load i8, ptr %overflow, align 1
  %16 = trunc nuw i8 %15 to i1
  %17 = or i1 %16, %_68
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %overflow, align 1
  br label %bb23

bb24:                                             ; preds = %bb23
  %_55 = load i64, ptr %acc, align 8
  %_56 = load i64, ptr %base, align 8
  %19 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_55, i64 %_56)
  %_5.0.i7 = extractvalue { i64, i1 } %19, 0
  %_5.1.i8 = extractvalue { i64, i1 } %19, 1
  %_54.0 = extractvalue { i64, i1 } %19, 0
  %_54.1 = extractvalue { i64, i1 } %19, 1
  store i64 %_54.0, ptr %acc, align 8
  %20 = zext i1 %_54.1 to i8
  store i8 %20, ptr %tmp_overflow, align 1
  %21 = load i8, ptr %tmp_overflow, align 1
  %_57 = trunc nuw i8 %21 to i1
  %22 = load i8, ptr %overflow, align 1
  %23 = trunc nuw i8 %22 to i1
  %24 = or i1 %23, %_57
  %25 = zext i1 %24 to i8
  store i8 %25, ptr %overflow, align 1
  %_59 = load i32, ptr %exp, align 4
  %_58 = icmp eq i32 %_59, 1
  br i1 %_58, label %bb26, label %bb27

bb26:                                             ; preds = %bb24
  %_60 = load i64, ptr %acc, align 8
  %26 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %26 to i1
  store i64 %_60, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  %28 = zext i1 %_61 to i8
  store i8 %28, ptr %27, align 8
  br label %bb30

bb30:                                             ; preds = %bb8, %bb7, %bb11, %bb21, %bb26
  %29 = load i64, ptr %_0, align 8
  %30 = getelementptr inbounds i8, ptr %_0, i64 8
  %31 = load i8, ptr %30, align 8
  %32 = trunc nuw i8 %31 to i1
  %33 = insertvalue { i64, i1 } poison, i64 %29, 0
  %34 = insertvalue { i64, i1 } %33, i1 %32, 1
  ret { i64, i1 } %34

bb21:                                             ; preds = %bb14
  %_44 = load i64, ptr %acc, align 8
  %_45 = load i64, ptr %base, align 8
  %35 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_44, i64 %_45)
  %_5.0.i3 = extractvalue { i64, i1 } %35, 0
  %_5.1.i4 = extractvalue { i64, i1 } %35, 1
  %_43.0 = extractvalue { i64, i1 } %35, 0
  %_43.1 = extractvalue { i64, i1 } %35, 1
  store i64 %_43.0, ptr %acc, align 8
  %36 = zext i1 %_43.1 to i8
  store i8 %36, ptr %tmp_overflow, align 1
  %37 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %37 to i1
  %38 = load i8, ptr %overflow, align 1
  %39 = trunc nuw i8 %38 to i1
  %40 = or i1 %39, %_46
  %41 = zext i1 %40 to i8
  store i8 %41, ptr %overflow, align 1
  %_47 = load i64, ptr %acc, align 8
  %42 = load i8, ptr %overflow, align 1
  %_48 = trunc nuw i8 %42 to i1
  store i64 %_47, ptr %_0, align 8
  %43 = getelementptr inbounds i8, ptr %_0, i64 8
  %44 = zext i1 %_48 to i8
  store i8 %44, ptr %43, align 8
  br label %bb30

bb15:                                             ; preds = %bb14
  %_27 = load i32, ptr %exp, align 4
  %_26 = and i32 %_27, 1
  %_25 = icmp eq i32 %_26, 1
  br i1 %_25, label %bb16, label %bb18

bb18:                                             ; preds = %bb16, %bb15
  %45 = load i32, ptr %exp, align 4
  %46 = udiv i32 %45, 2
  store i32 %46, ptr %exp, align 4
  %_38 = load i64, ptr %base, align 8
  %_39 = load i64, ptr %base, align 8
  %47 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_38, i64 %_39)
  %_5.0.i = extractvalue { i64, i1 } %47, 0
  %_5.1.i = extractvalue { i64, i1 } %47, 1
  %_37.0 = extractvalue { i64, i1 } %47, 0
  %_37.1 = extractvalue { i64, i1 } %47, 1
  store i64 %_37.0, ptr %base, align 8
  %48 = zext i1 %_37.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_40 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_40
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  br label %bb14

bb16:                                             ; preds = %bb15
  %_31 = load i64, ptr %acc, align 8
  %_32 = load i64, ptr %base, align 8
  %54 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_31, i64 %_32)
  %_5.0.i1 = extractvalue { i64, i1 } %54, 0
  %_5.1.i2 = extractvalue { i64, i1 } %54, 1
  %_30.0 = extractvalue { i64, i1 } %54, 0
  %_30.1 = extractvalue { i64, i1 } %54, 1
  store i64 %_30.0, ptr %acc, align 8
  %55 = zext i1 %_30.1 to i8
  store i8 %55, ptr %tmp_overflow, align 1
  %56 = load i8, ptr %tmp_overflow, align 1
  %_33 = trunc nuw i8 %56 to i1
  %57 = load i8, ptr %overflow, align 1
  %58 = trunc nuw i8 %57 to i1
  %59 = or i1 %58, %_33
  %60 = zext i1 %59 to i8
  store i8 %60, ptr %overflow, align 1
  br label %bb18

bb7:                                              ; preds = %bb4
  %61 = getelementptr inbounds i8, ptr %_14, i64 4
  %shift = load i32, ptr %61, align 4
; call <u64>::unbounded_shl
  %_17 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unbounded_shlCsaqkWKWdl1xD_11int_ops_u64(i64 1, i32 %shift) #17
  %_18 = icmp uge i32 %shift, 64
  store i64 %_17, ptr %_0, align 8
  %62 = getelementptr inbounds i8, ptr %_0, i64 8
  %63 = zext i1 %_18 to i8
  store i8 %63, ptr %62, align 8
  br label %bb30

bb8:                                              ; preds = %bb4
  store i128 18446744073709551616, ptr %_0, align 8
  br label %bb30

bb31:                                             ; No predecessors!
  unreachable
}

; <u64>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy3powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) unnamed_addr #0 !guid !117 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <u64>::strict_pow
  %0 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy10strict_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #17
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb2:                                              ; No predecessors!
; call <u64>::wrapping_pow
  %1 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy12wrapping_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) #17
  store i64 %1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i64, ptr %_0, align 8
  ret i64 %2
}

; <u64>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %self, ptr align 8 %0) unnamed_addr #0 !guid !118 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u64>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13checked_ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %self) #17
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #19
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u64>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5isqrtCsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !119 {
start:
; call core::num::imp::int_sqrt::u64
  %result = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64CsaqkWKWdl1xD_11int_ops_u64(i64 %self) #17
  %_3 = icmp ule i64 %result, 4294967295
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_3, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i64 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_3.i, label %bb2.i, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u64>::unchecked_mul::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %result, i64 %result, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i64 %result, %result
  %_8 = icmp ule i64 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_8, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i64 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_11, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i64 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i64 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_6, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <u64>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8abs_diffCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %other) unnamed_addr #0 !guid !120 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsaqkWKWdl1xD_11int_ops_u64(i32 %_0.i) #17
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !121 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <u64>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy14from_str_radixCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !122 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <u64>::from_ascii_bytes_radix_impl
  call void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy27from_ascii_bytes_radix_implCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #17
  ret void
}

; <u64>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy27from_ascii_bytes_radix_implCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !123 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [16 x i8], align 8
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [16 x i8], align 8
  %_74 = alloca [16 x i8], align 8
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [16 x i8], align 8
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [8 x i8], align 8
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_5aa1d1250638a5285856df0c8e3018a3) #23
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr %src.0, i64 %src.1) #17
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb11, %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb9

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !124
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i64 0, ptr %result, align 8
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 16
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; No predecessors!
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i64, ptr %result, align 8
  %33 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_105, ptr %33, align 8
  store i8 0, ptr %_0, align 8
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i64, ptr %result, align 8
  %_86 = zext i32 %radix to i64
; call <u64>::checked_mul
  %40 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_85, i64 %_86) #17
  %41 = extractvalue { i64, i64 } %40, 0
  %42 = extractvalue { i64, i64 } %40, 1
  store i64 %41, ptr %mul1, align 8
  %43 = getelementptr inbounds i8, ptr %mul1, i64 8
  store i64 %42, ptr %43, align 8
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %44 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %_89, i32 %radix) #17
  %45 = extractvalue { i32, i32 } %44, 0
  %46 = extractvalue { i32, i32 } %44, 1
  store i32 %45, ptr %_88, align 4
  %47 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %46, ptr %47, align 4
  %48 = load i32, ptr %_88, align 4
  %49 = getelementptr inbounds i8, ptr %_88, i64 4
  %50 = load i32, ptr %49, align 4
  %_91 = zext i32 %48 to i64
  %51 = trunc nuw i64 %_91 to i1
  br i1 %51, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %52 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %52, align 4
  %x = zext i32 %value to i64
  %_95 = load i64, ptr %mul1, align 8
  %53 = getelementptr inbounds i8, ptr %mul1, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = trunc nuw i64 %_95 to i1
  br i1 %55, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %56 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %56, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb48:                                             ; preds = %bb46
  %57 = getelementptr inbounds i8, ptr %mul1, i64 8
  %value4 = load i64, ptr %57, align 8
  store i64 %value4, ptr %result, align 8
  %_100 = load i64, ptr %result, align 8
; call <u64>::checked_sub
  %58 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_subCsaqkWKWdl1xD_11int_ops_u64(i64 %_100, i64 %x) #17
  %59 = extractvalue { i64, i64 } %58, 0
  %60 = extractvalue { i64, i64 } %58, 1
  store i64 %59, ptr %_99, align 8
  %61 = getelementptr inbounds i8, ptr %_99, i64 8
  store i64 %60, ptr %61, align 8
  %_101 = load i64, ptr %_99, align 8
  %62 = getelementptr inbounds i8, ptr %_99, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = trunc nuw i64 %_101 to i1
  br i1 %64, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %65 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %65, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb51:                                             ; preds = %bb48
  %66 = getelementptr inbounds i8, ptr %_99, i64 8
  %value5 = load i64, ptr %66, align 8
  store i64 %value5, ptr %result, align 8
  store ptr %rest.02, ptr %digits, align 8, !captures !124
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %67, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %68 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %68, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb31:                                             ; preds = %bb30
  %69 = load ptr, ptr %digits, align 8
  %70 = getelementptr inbounds i8, ptr %digits, i64 8
  %71 = load i64, ptr %70, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %69, i64 0
  %72 = load ptr, ptr %digits, align 8
  %73 = getelementptr inbounds i8, ptr %digits, i64 8
  %74 = load i64, ptr %73, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %72, i64 1
  %rest.18 = sub i64 %74, 1
  %_60 = load i64, ptr %result, align 8
  %_61 = zext i32 %radix to i64
; call <u64>::checked_mul
  %75 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_60, i64 %_61) #17
  %76 = extractvalue { i64, i64 } %75, 0
  %77 = extractvalue { i64, i64 } %75, 1
  store i64 %76, ptr %mul, align 8
  %78 = getelementptr inbounds i8, ptr %mul, i64 8
  store i64 %77, ptr %78, align 8
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %79 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %_64, i32 %radix) #17
  %80 = extractvalue { i32, i32 } %79, 0
  %81 = extractvalue { i32, i32 } %79, 1
  store i32 %80, ptr %_63, align 4
  %82 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %81, ptr %82, align 4
  %83 = load i32, ptr %_63, align 4
  %84 = getelementptr inbounds i8, ptr %_63, i64 4
  %85 = load i32, ptr %84, align 4
  %_66 = zext i32 %83 to i64
  %86 = trunc nuw i64 %_66 to i1
  br i1 %86, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %87 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %87, align 4
  %x10 = zext i32 %value9 to i64
  %_70 = load i64, ptr %mul, align 8
  %88 = getelementptr inbounds i8, ptr %mul, i64 8
  %89 = load i64, ptr %88, align 8
  %90 = trunc nuw i64 %_70 to i1
  br i1 %90, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %91, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb37:                                             ; preds = %bb35
  %92 = getelementptr inbounds i8, ptr %mul, i64 8
  %value11 = load i64, ptr %92, align 8
  store i64 %value11, ptr %result, align 8
  %_75 = load i64, ptr %result, align 8
; call <u64>::checked_add
  %93 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_addCsaqkWKWdl1xD_11int_ops_u64(i64 %_75, i64 %x10) #17
  %94 = extractvalue { i64, i64 } %93, 0
  %95 = extractvalue { i64, i64 } %93, 1
  store i64 %94, ptr %_74, align 8
  %96 = getelementptr inbounds i8, ptr %_74, i64 8
  store i64 %95, ptr %96, align 8
  %_76 = load i64, ptr %_74, align 8
  %97 = getelementptr inbounds i8, ptr %_74, i64 8
  %98 = load i64, ptr %97, align 8
  %99 = trunc nuw i64 %_76 to i1
  br i1 %99, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %100 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %100, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb40:                                             ; preds = %bb37
  %101 = getelementptr inbounds i8, ptr %_74, i64 8
  %value12 = load i64, ptr %101, align 8
  store i64 %value12, ptr %result, align 8
  store ptr %rest.07, ptr %digits, align 8, !captures !124
  %102 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %102, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %103 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %103, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %104 = load ptr, ptr %digits, align 8
  %105 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %105, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %106 = load ptr, ptr %digits, align 8
  %107 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %107, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %108 = load ptr, ptr %digits, align 8
  %109 = getelementptr inbounds i8, ptr %digits, i64 8
  %110 = load i64, ptr %109, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %108, i64 0
  %111 = load ptr, ptr %digits, align 8
  %112 = getelementptr inbounds i8, ptr %digits, i64 8
  %113 = load i64, ptr %112, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %111, i64 1
  %rest.115 = sub i64 %113, 1
  %_44 = load i64, ptr %result, align 8
  %_45 = zext i32 %radix to i64
  %114 = mul i64 %_44, %_45
  store i64 %114, ptr %result, align 8
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %115 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %_47, i32 %radix) #17
  %116 = extractvalue { i32, i32 } %115, 0
  %117 = extractvalue { i32, i32 } %115, 1
  store i32 %116, ptr %_46, align 4
  %118 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %117, ptr %118, align 4
  %119 = load i32, ptr %_46, align 4
  %120 = getelementptr inbounds i8, ptr %_46, i64 4
  %121 = load i32, ptr %120, align 4
  %_49 = zext i32 %119 to i64
  %122 = trunc nuw i64 %_49 to i1
  br i1 %122, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %123 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %123, align 4
  %_53 = load i64, ptr %result, align 8
  %_54 = zext i32 %x16 to i64
  %124 = sub i64 %_53, %_54
  store i64 %124, ptr %result, align 8
  store ptr %rest.014, ptr %digits, align 8, !captures !124
  %125 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %125, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %126 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %126, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb19:                                             ; preds = %bb18
  %127 = load ptr, ptr %digits, align 8
  %128 = getelementptr inbounds i8, ptr %digits, i64 8
  %129 = load i64, ptr %128, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %127, i64 0
  %130 = load ptr, ptr %digits, align 8
  %131 = getelementptr inbounds i8, ptr %digits, i64 8
  %132 = load i64, ptr %131, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %130, i64 1
  %rest.119 = sub i64 %132, 1
  %_29 = load i64, ptr %result, align 8
  %_30 = zext i32 %radix to i64
  %133 = mul i64 %_29, %_30
  store i64 %133, ptr %result, align 8
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %134 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %_32, i32 %radix) #17
  %135 = extractvalue { i32, i32 } %134, 0
  %136 = extractvalue { i32, i32 } %134, 1
  store i32 %135, ptr %_31, align 4
  %137 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %136, ptr %137, align 4
  %138 = load i32, ptr %_31, align 4
  %139 = getelementptr inbounds i8, ptr %_31, i64 4
  %140 = load i32, ptr %139, align 4
  %_34 = zext i32 %138 to i64
  %141 = trunc nuw i64 %_34 to i1
  br i1 %141, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %142 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %142, align 4
  %_38 = load i64, ptr %result, align 8
  %_39 = zext i32 %x20 to i64
  %143 = add i64 %_38, %_39
  store i64 %143, ptr %result, align 8
  store ptr %rest.018, ptr %digits, align 8, !captures !124
  %144 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %144, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %145 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %145, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsaqkWKWdl1xD_11int_ops_u64(i8 %0) unnamed_addr #0 !guid !125 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsaqkWKWdl1xD_11int_ops_u64(ptr %self) #17
  ret i32 %_0
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !126 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %args) #17
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #17
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #4 !guid !127 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #0 !guid !128 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !129 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::num::imp::int_sqrt::u16_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsaqkWKWdl1xD_11int_ops_u64(i16 %n) unnamed_addr #0 !guid !130 {
start:
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n1 = lshr i16 %n, 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.3163d8aaa3ec962f62b1dd64a9184856.0, i64 512, i1 false)
  %_9 = zext i16 %n1 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s2 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s2, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_12, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb1, %bb2.i
  %lo = and i16 %n, 255
  %_16 = zext i8 %r to i16
  %_15 = shl i16 %_16, 4
  %_17 = lshr i16 %lo, 4
  %numerator = or i16 %_15, %_17
  %_19 = zext i8 %s2 to i16
  %denominator = shl i16 %_19, 1
  %_21 = icmp eq i16 %denominator, 0
  br i1 %_21, label %panic3, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q = udiv i16 %numerator, %denominator
  %_24 = shl i8 %s2, 4
  %_23 = zext i8 %_24 to i16
  %3 = add i16 %_23, %q
  store i16 %3, ptr %s, align 2
  %_28 = load i16, ptr %s, align 2
  %_29 = load i16, ptr %s, align 2
  %4 = call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %_28, i16 %_29)
  %_5.0.i = extractvalue { i16, i1 } %4, 0
  %_5.1.i = extractvalue { i16, i1 } %4, 1
  %_27.0 = extractvalue { i16, i1 } %4, 0
  %_27.1 = extractvalue { i16, i1 } %4, 1
  br i1 %_27.1, label %bb6, label %bb5

panic3:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_73a63def61abd19c5b285b7e5bba6f74) #23
  unreachable

bb5:                                              ; preds = %bb3
  %_30 = icmp ugt i16 %_27.0, %n
  br i1 %_30, label %bb6, label %bb7

bb6:                                              ; preds = %bb5, %bb3
  %5 = load i16, ptr %s, align 2
  %6 = sub i16 %5, 1
  store i16 %6, ptr %s, align 2
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5
  %_0 = load i16, ptr %s, align 2
  ret i16 %_0
}

; core::num::imp::int_sqrt::u32_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsaqkWKWdl1xD_11int_ops_u64(i32 %n) unnamed_addr #0 !guid !131 {
start:
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n2 = lshr i32 %n, 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.3163d8aaa3ec962f62b1dd64a9184856.0, i64 512, i1 false)
  %_9 = zext i32 %n2 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s3 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r4 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s3, 0
; call core::ub_checks::check_language_ub
  %_2.i15 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i15, label %bb2.i16, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

bb2.i16:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_12, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17: ; preds = %bb1, %bb2.i16
  %_17 = lshr i32 %n, 16
  %n5 = trunc i32 %_17 to i16
  %lo = and i16 %n5, 255
  %_21 = zext i8 %r4 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s3 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic6, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic7, label %bb4

panic6:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s3, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic7:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_45, ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb8, %bb2.i
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %lo8 = and i32 %n, 65535
  %_52 = zext i16 %_48 to i32
  %_51 = shl i32 %_52, 8
  %_53 = lshr i32 %lo8, 8
  %numerator9 = or i32 %_51, %_53
  %_55 = zext i16 %_47 to i32
  %denominator10 = shl i32 %_55, 1
  %_57 = icmp eq i32 %denominator10, 0
  br i1 %_57, label %panic11, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q12 = udiv i32 %numerator9, %denominator10
  %_60 = shl i16 %_47, 8
  %_59 = zext i16 %_60 to i32
  %8 = add i32 %_59, %q12
  store i32 %8, ptr %s1, align 4
  %_64 = load i32, ptr %s1, align 4
  %_65 = load i32, ptr %s1, align 4
  %9 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_64, i32 %_65)
  %_5.0.i13 = extractvalue { i32, i1 } %9, 0
  %_5.1.i14 = extractvalue { i32, i1 } %9, 1
  %_63.0 = extractvalue { i32, i1 } %9, 0
  %_63.1 = extractvalue { i32, i1 } %9, 1
  br i1 %_63.1, label %bb13, label %bb12

panic11:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_d1e64d3a180065bd6a022925cad00717) #23
  unreachable

bb12:                                             ; preds = %bb10
  %_66 = icmp ugt i32 %_63.0, %n
  br i1 %_66, label %bb13, label %bb14

bb13:                                             ; preds = %bb12, %bb10
  %10 = load i32, ptr %s1, align 4
  %11 = sub i32 %10, 1
  store i32 %11, ptr %s1, align 4
  br label %bb14

bb14:                                             ; preds = %bb13, %bb12
  %_0 = load i32, ptr %s1, align 4
  ret i32 %_0
}

; core::num::imp::int_sqrt::u64_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCsaqkWKWdl1xD_11int_ops_u64(i64 %n) unnamed_addr #0 !guid !132 {
start:
  %s3 = alloca [8 x i8], align 8
  %r2 = alloca [4 x i8], align 4
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n4 = lshr i64 %n, 56
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.3163d8aaa3ec962f62b1dd64a9184856.0, i64 512, i1 false)
  %_10 = icmp ult i64 %n4, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %s5 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r6 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s5, 0
; call core::ub_checks::check_language_ub
  %_2.i31 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i31, label %bb2.i32, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

bb2.i32:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_12, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33: ; preds = %bb1, %bb2.i32
  %_17 = lshr i64 %n, 48
  %n7 = trunc i64 %_17 to i16
  %lo = and i16 %n7, 255
  %_21 = zext i8 %r6 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s5 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic8, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %n4, i64 256, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #23
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic9, label %bb4

panic8:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #23
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s5, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic9:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #23
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i28 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i28, label %bb2.i29, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

bb2.i29:                                          ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_45, ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30: ; preds = %bb8, %bb2.i29
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %_53 = lshr i64 %n, 32
  %n10 = trunc i64 %_53 to i32
  %lo11 = and i32 %n10, 65535
  %_57 = zext i16 %_48 to i32
  %_56 = shl i32 %_57, 8
  %_58 = lshr i32 %lo11, 8
  %numerator12 = or i32 %_56, %_58
  %_60 = zext i16 %_47 to i32
  %denominator13 = shl i32 %_60, 1
  %_62 = icmp eq i32 %denominator13, 0
  br i1 %_62, label %panic14, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
  %q15 = udiv i32 %numerator12, %denominator13
  %_64 = icmp eq i32 %denominator13, 0
  br i1 %_64, label %panic16, label %bb11

panic14:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #23
  unreachable

bb11:                                             ; preds = %bb10
  %u17 = urem i32 %numerator12, %denominator13
  %_67 = shl i16 %_47, 8
  %_66 = zext i16 %_67 to i32
  %8 = add i32 %_66, %q15
  store i32 %8, ptr %s1, align 4
  %_72 = shl i32 %u17, 8
  %_73 = and i32 %lo11, 255
  %_71 = or i32 %_72, %_73
  %_74 = mul i32 %q15, %q15
  %_5.0.i24 = sub i32 %_71, %_74
  %_5.1.i25 = icmp ult i32 %_71, %_74
  %9 = insertvalue { i32, i1 } poison, i32 %_5.0.i24, 0
  %10 = insertvalue { i32, i1 } %9, i1 %_5.1.i25, 1
  %_70.0 = extractvalue { i32, i1 } %10, 0
  %_70.1 = extractvalue { i32, i1 } %10, 1
  store i32 %_70.0, ptr %r2, align 4
  br i1 %_70.1, label %bb13, label %bb15

panic16:                                          ; preds = %bb10
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #23
  unreachable

bb15:                                             ; preds = %bb13, %bb11
  %_82 = load i32, ptr %s1, align 4
  %_81 = icmp ne i32 %_82, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #17
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb15
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_81, ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #22
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb15, %bb2.i
  %_83 = load i32, ptr %s1, align 4
  %_84 = load i32, ptr %r2, align 4
  %lo18 = and i64 %n, 4294967295
  %_88 = zext i32 %_84 to i64
  %_87 = shl i64 %_88, 16
  %_89 = lshr i64 %lo18, 16
  %numerator19 = or i64 %_87, %_89
  %_91 = zext i32 %_83 to i64
  %denominator20 = shl i64 %_91, 1
  %_93 = icmp eq i64 %denominator20, 0
  br i1 %_93, label %panic21, label %bb17

bb13:                                             ; preds = %bb11
  %_76 = load i32, ptr %r2, align 4
  %_79 = load i32, ptr %s1, align 4
  %_78 = mul i32 2, %_79
  %_77 = sub i32 %_78, 1
  %_0.i23 = add i32 %_76, %_77
  store i32 %_0.i23, ptr %r2, align 4
  %11 = load i32, ptr %s1, align 4
  %12 = sub i32 %11, 1
  store i32 %12, ptr %s1, align 4
  br label %bb15

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q22 = udiv i64 %numerator19, %denominator20
  %_96 = shl i32 %_83, 16
  %_95 = zext i32 %_96 to i64
  %13 = add i64 %_95, %q22
  store i64 %13, ptr %s3, align 8
  %_100 = load i64, ptr %s3, align 8
  %_101 = load i64, ptr %s3, align 8
  %14 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_100, i64 %_101)
  %_5.0.i26 = extractvalue { i64, i1 } %14, 0
  %_5.1.i27 = extractvalue { i64, i1 } %14, 1
  %_99.0 = extractvalue { i64, i1 } %14, 0
  %_99.1 = extractvalue { i64, i1 } %14, 1
  br i1 %_99.1, label %bb20, label %bb19

panic21:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cb646754bd05cd238e749888201337e6) #23
  unreachable

bb19:                                             ; preds = %bb17
  %_102 = icmp ugt i64 %_99.0, %n
  br i1 %_102, label %bb20, label %bb21

bb20:                                             ; preds = %bb19, %bb17
  %15 = load i64, ptr %s3, align 8
  %16 = sub i64 %15, 1
  store i64 %16, ptr %s3, align 8
  br label %bb21

bb21:                                             ; preds = %bb20, %bb19
  %_0 = load i64, ptr %s3, align 8
  ret i64 %_0
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsaqkWKWdl1xD_11int_ops_u64(i8 %n) unnamed_addr #0 !guid !133 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.3163d8aaa3ec962f62b1dd64a9184856.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #23
  unreachable
}

; core::num::imp::int_sqrt::u16
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsaqkWKWdl1xD_11int_ops_u64(i16 %0) unnamed_addr #0 !guid !134 {
start:
  %_0 = alloca [2 x i8], align 2
  %n = alloca [2 x i8], align 2
  store i16 %0, ptr %n, align 2
  %_3 = load i16, ptr %n, align 2
  %_2 = icmp ule i16 %_3, 255
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i16, ptr %n, align 2
  %1 = call i16 @llvm.ctlz.i16(i16 %_10, i1 false)
  %_0.i = zext i16 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i16, ptr %n, align 2
  %3 = and i32 %normalization_shift, 15
  %4 = trunc i32 %3 to i16
  %5 = shl i16 %2, %4
  store i16 %5, ptr %n, align 2
  %_12 = load i16, ptr %n, align 2
; call core::num::imp::int_sqrt::u16_stages
  %s = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsaqkWKWdl1xD_11int_ops_u64(i16 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 15
  %7 = trunc i32 %6 to i16
  %8 = lshr i16 %s, %7
  store i16 %8, ptr %_0, align 2
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i16, ptr %n, align 2
  %_6 = trunc i16 %_7 to i8
; call core::num::imp::int_sqrt::u8
  %_5 = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsaqkWKWdl1xD_11int_ops_u64(i8 %_6) #17
  %9 = zext i8 %_5 to i16
  store i16 %9, ptr %_0, align 2
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i16, ptr %_0, align 2
  ret i16 %10
}

; core::num::imp::int_sqrt::u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32CsaqkWKWdl1xD_11int_ops_u64(i32 %0) unnamed_addr #0 !guid !135 {
start:
  %_0 = alloca [4 x i8], align 4
  %n = alloca [4 x i8], align 4
  store i32 %0, ptr %n, align 4
  %_3 = load i32, ptr %n, align 4
  %_2 = icmp ule i32 %_3, 65535
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i32, ptr %n, align 4
  %_0.i = call i32 @llvm.ctlz.i32(i32 %_10, i1 false)
  %normalization_shift = and i32 %_0.i, -2
  %1 = load i32, ptr %n, align 4
  %2 = and i32 %normalization_shift, 31
  %3 = shl i32 %1, %2
  store i32 %3, ptr %n, align 4
  %_12 = load i32, ptr %n, align 4
; call core::num::imp::int_sqrt::u32_stages
  %s = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsaqkWKWdl1xD_11int_ops_u64(i32 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %4 = and i32 %denormalization_shift, 31
  %5 = lshr i32 %s, %4
  store i32 %5, ptr %_0, align 4
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i32, ptr %n, align 4
  %_6 = trunc i32 %_7 to i16
; call core::num::imp::int_sqrt::u16
  %_5 = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsaqkWKWdl1xD_11int_ops_u64(i16 %_6) #17
  %6 = zext i16 %_5 to i32
  store i32 %6, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %7 = load i32, ptr %_0, align 4
  ret i32 %7
}

; core::num::imp::int_sqrt::u64
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64CsaqkWKWdl1xD_11int_ops_u64(i64 %0) unnamed_addr #0 !guid !136 {
start:
  %_0 = alloca [8 x i8], align 8
  %n = alloca [8 x i8], align 8
  store i64 %0, ptr %n, align 8
  %_3 = load i64, ptr %n, align 8
  %_2 = icmp ule i64 %_3, 4294967295
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i64, ptr %n, align 8
  %1 = call i64 @llvm.ctlz.i64(i64 %_10, i1 false)
  %_0.i = trunc i64 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i64, ptr %n, align 8
  %3 = and i32 %normalization_shift, 63
  %4 = zext i32 %3 to i64
  %5 = shl i64 %2, %4
  store i64 %5, ptr %n, align 8
  %_12 = load i64, ptr %n, align 8
; call core::num::imp::int_sqrt::u64_stages
  %s = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCsaqkWKWdl1xD_11int_ops_u64(i64 %_12) #17
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 63
  %7 = zext i32 %6 to i64
  %8 = lshr i64 %s, %7
  store i64 %8, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %n, align 8
  %_6 = trunc i64 %_7 to i32
; call core::num::imp::int_sqrt::u32
  %_5 = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32CsaqkWKWdl1xD_11int_ops_u64(i32 %_6) #17
  %9 = zext i32 %_5 to i64
  store i64 %9, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i64, ptr %_0, align 8
  ret i64 %10
}

; <u64>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !137 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_c856595eac66a24654d670eae8c59bb6, i64 184)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <u64>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !138 {
start:
  %_2 = icmp ult i32 %rhs, 64
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_f4be92229193d4464753072989252627, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; <u64>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !139 {
start:
  %_2 = icmp ult i32 %rhs, 64
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_10473b11a7e05bbd7ed679b01f6c847b, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !140 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #18
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #25
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #0 !guid !141 {
start:
  ret i1 true
}

; <(u64, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTybENtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !142 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <u64 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1N_NtCs7CppTae75M1_5alloc6stringyNtB6_12SpecToString14spec_to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !143 {
start:
  %buf = alloca [20 x i8], align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 20, i1 false)
  %_5 = load i64, ptr %self, align 8
; call <u64>::_fmt
  %0 = call { ptr, i64 } @_RNvMsf_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impy4__fmt(i64 %_5, ptr %buf, i64 20)
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8 %_0, ptr %_4.0, i64 %_4.1) #17
  ret void
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !144 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !145 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %_3, ptr align 8 %f) #17
  ret i1 %_0
}

; <u64 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringyNtB5_8ToString9to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !146 {
start:
; call <u64 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1N_NtCs7CppTae75M1_5alloc6stringyNtB6_12SpecToString14spec_to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #17
  ret void
}

; <u64 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsC_NtCsl10jNU3mE6R_4core3numyNtNtNtB7_3str6traits7FromStr8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !147 {
start:
; call <u64>::from_str_radix
  call void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy14from_str_radixCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 10) #17
  ret void
}

; <core::option::Option<u64> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionyENtNtB7_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !148 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %_3 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.1)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #0 !guid !149 {
start:
  ret i8 0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !150 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !151 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::result::Result<u64, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultyNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !152 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr %_1) unnamed_addr #0 !guid !153 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !154 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1) #17
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<u64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refB9_(ptr align 8) unnamed_addr #0

; <core::ptr::non_null::NonNull<u64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuEBa_(ptr) unnamed_addr #0

; <u64 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsy_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_6Binary3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u64 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsE_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8UpperHex3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u64 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsA_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_5Octal3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fshr.i64(i64, i64, i64) #9

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; <core::fmt::rt::Argument>::new_lower_hex::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs2d0hS33vDhg_5gimli(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptoui.sat.i64.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenB6_(ptr align 8) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; <core::num::nonzero::NonZero<u64>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3getB9_(i64) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #10

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshEB6_(ptr, i64, ptr align 8) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctlz.i16(i16, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.umul.with.overflow.i16(i16, i16) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #9

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #11

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #9

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i64(i64) #12

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #12

; core::intrinsics::rotate_left::<u64>
; Function Attrs: nounwind nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64, i32) unnamed_addr #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bitreverse.i64(i64) #9

; <core::num::nonzero::NonZero<u64>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3newB9_(i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.uadd.sat.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.usub.sat.i64(i64, i64) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.cttz.i64(i64, i1 immarg) #10

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #11

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyB4_(ptr, i64) unnamed_addr #0

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECs2d0hS33vDhg_5gimli(ptr sret([24 x i8]) align 8, ptr, i64, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #13

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #14

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <&u64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #15

; <u64>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMsf_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impy4__fmt(i64, ptr, i64) unnamed_addr #1

; <str as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCs3ZOqIoMh3eg_9addr2line(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #0

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #16 !guid !155 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsaqkWKWdl1xD_11int_ops_u64(ptr @_RNvCsaqkWKWdl1xD_11int_ops_u644main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #13 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #16 = { nonlazybind "target-cpu"="x86-64" }
attributes #17 = { inlinehint }
attributes #18 = { cold noreturn nounwind }
attributes #19 = { noreturn }
attributes #20 = { noinline }
attributes #21 = { nounwind }
attributes #22 = { inlinehint nounwind }
attributes #23 = { noinline noreturn }
attributes #24 = { cold }
attributes #25 = { noinline noreturn nounwind }

!llvm.module.flags = !{!53, !54, !55, !56}
!llvm.ident = !{!57}

!0 = !{i64 7938327338976879079}
!1 = !{i64 -109070386805518354}
!2 = !{i64 2246735844356491145}
!3 = !{i64 8755703796242553449}
!4 = !{i64 -7261305892346556305}
!5 = !{i64 5528178722780467347}
!6 = !{i64 798857786609991516}
!7 = !{i64 -4877988758469276444}
!8 = !{i64 2315585346768016276}
!9 = !{i64 1340099557426450802}
!10 = !{i64 6217070906369098870}
!11 = !{i64 6436552939374826905}
!12 = !{i64 9215324736617152384}
!13 = !{i64 888090495040403296}
!14 = !{i64 9198555632046922647}
!15 = !{i64 -6044176112104071840}
!16 = !{i64 -3681473385203712016}
!17 = !{i64 757788644300956645}
!18 = !{i64 -1523824978182727493}
!19 = !{i64 1296081147239773327}
!20 = !{i64 -8312605705889461906}
!21 = !{i64 8309120882261627751}
!22 = !{i64 6265328426664965774}
!23 = !{i64 1157272896255167537}
!24 = !{i64 -3150036093075419246}
!25 = !{i64 -5182390714351297736}
!26 = !{i64 5258143136158706627}
!27 = !{i64 -3955802835283734671}
!28 = !{i64 -3979211527972569883}
!29 = !{i64 8516412466986539181}
!30 = !{i64 -30625496072518029}
!31 = !{i64 -4665618356843850562}
!32 = !{i64 1018782987527740056}
!33 = !{i64 5973441873893200458}
!34 = !{i64 -636863307005789285}
!35 = !{i64 1559288740909412277}
!36 = !{i64 -6855163255179491489}
!37 = !{i64 8080009867882604140}
!38 = !{i64 -6032540243932600782}
!39 = !{i64 -3292621149234371449}
!40 = !{i64 8157536733645029574}
!41 = !{i64 -2552955181169439579}
!42 = !{i64 446528662538533320}
!43 = !{i64 -6871408488924829530}
!44 = !{i64 -2235870228323838579}
!45 = !{i64 -3317795933806447176}
!46 = !{i64 5515343984767116602}
!47 = !{i64 7976718107228562692}
!48 = !{i64 6332281186964487049}
!49 = !{i64 5276547322382775096}
!50 = !{i64 663905389432559625}
!51 = !{i64 7456263123078546678}
!52 = !{i64 8392059085853937974}
!53 = !{i32 8, !"PIC Level", i32 2}
!54 = !{i32 7, !"PIE Level", i32 2}
!55 = !{i32 2, !"RtLibUseGOT", i32 1}
!56 = !{i32 7, !"uwtable", i32 2}
!57 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!58 = !{i64 4598604432072176377}
!59 = !{i64 -3163035758188836344}
!60 = !{i64 8436620925122215103}
!61 = !{i64 -9207250945187463467}
!62 = !{i64 -7970528797176059054}
!63 = !{i64 1319503229847619699}
!64 = !{i64 695347774772586088}
!65 = !{i64 -8617339630766678476}
!66 = !{i64 6338318562965072180}
!67 = !{i64 -4825313884789255364}
!68 = !{i64 9218849494273665989}
!69 = !{i64 -4262925026214832570}
!70 = !{i64 -1627377697008618755}
!71 = !{i64 -2922591977059710389}
!72 = !{i64 7511625827164674474}
!73 = !{i64 -2608727000935219874}
!74 = !{i64 42186360075275663}
!75 = !{i64 5790166327339483146}
!76 = !{i64 -5171023141198713979}
!77 = !{i64 -3963448332835941428}
!78 = !{i64 6246524645047417096}
!79 = !{i64 -6061915748425719849}
!80 = !{i64 -3415355657281130952}
!81 = !{i64 1318421816192758}
!82 = !{i64 -7372870578464189338}
!83 = !{i64 -9065040132769964150}
!84 = !{i64 4065062684607214532}
!85 = !{i64 -3916065205790971371}
!86 = !{i64 -3337375598024144164}
!87 = !{i64 -6072384481081895979}
!88 = !{i64 -7976856525470099590}
!89 = !{i64 3938936552322764790}
!90 = !{i64 9050391400537049710}
!91 = !{i64 7533107914709645929}
!92 = !{i64 -8095622546596976425}
!93 = !{i64 1337966168107413200}
!94 = !{i64 4846436873892184382}
!95 = !{i64 2515683562128846338}
!96 = !{i64 1406947283778291750}
!97 = !{i64 720260308985200625}
!98 = !{i64 -269248032162978403}
!99 = !{i64 -3350798943300075920}
!100 = !{i64 -4778322950972124677}
!101 = !{i64 -6855571009827672949}
!102 = !{i64 2728289856830196920}
!103 = !{i64 7279590991024219152}
!104 = !{i64 8892391336116780560}
!105 = !{i64 -3866327579059496776}
!106 = !{i64 -184302977520553460}
!107 = !{i64 1346407431516218718}
!108 = !{i64 3524171481337899677}
!109 = !{i64 6584544868637230167}
!110 = !{i64 -7329576845016027113}
!111 = !{i64 -3354308861726144285}
!112 = !{i64 8833813407064249582}
!113 = !{i64 8810249560178221974}
!114 = !{i64 8447309241766734749}
!115 = !{i64 5647368559608178870}
!116 = !{i64 -4738980014978525536}
!117 = !{i64 -5058041819172935420}
!118 = !{i64 5587975771484298313}
!119 = !{i64 6707042033982496572}
!120 = !{i64 -6925668523040432656}
!121 = !{i64 -466326505033984838}
!122 = !{i64 -4142831142022185768}
!123 = !{i64 367009040887567627}
!124 = !{!"address", !"read_provenance"}
!125 = !{i64 -1561071384183156027}
!126 = !{i64 9022555215535491106}
!127 = !{i64 8373382471319891027}
!128 = !{i64 -7662377760537027417}
!129 = !{i64 5487361353474060126}
!130 = !{i64 -1398325481744745642}
!131 = !{i64 1789253852056413623}
!132 = !{i64 -4392294270250856224}
!133 = !{i64 4953353209417393232}
!134 = !{i64 5164152049230694844}
!135 = !{i64 2841976868082735308}
!136 = !{i64 -3501058256543413933}
!137 = !{i64 5358980377409072148}
!138 = !{i64 7945436370753363634}
!139 = !{i64 -8975763721634503969}
!140 = !{i64 4681439759542066467}
!141 = !{i64 -3031649311062085522}
!142 = !{i64 -558701064432408242}
!143 = !{i64 6276392682066897435}
!144 = !{i64 9189638898058079224}
!145 = !{i64 1175947219159088360}
!146 = !{i64 8147787680137622774}
!147 = !{i64 -6473584967267895069}
!148 = !{i64 2249711040122262746}
!149 = !{i64 -4298085847484392885}
!150 = !{i64 -8170538480505551888}
!151 = !{i64 5966082782125074017}
!152 = !{i64 -1346890464324994791}
!153 = !{i64 -4842438223868083872}
!154 = !{i64 4339694693084854807}
!155 = !{i64 -2624081020897602054}
